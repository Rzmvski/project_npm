# TCPF Platform Admin API

## Role

Defines API contracts implemented by tcpf-platform-admin-app.

The contracts may be consumed by tcpf-support-admin-ui.

## Rules

Treat backward compatibility as a first-class concern.

Prefer additive API changes.

Do not edit generated code manually.

Modify the OpenAPI source and regenerate artifacts.

## Validation

After contract changes:

1. validate OpenAPI;
2. run code generation;
3. compile generated artifacts;
4. run contract/build checks;
5. inspect generated diffs.
