---
id: "ui-release-jenkins"
name: "ui-release-jenkins"
description: "Запуск генерации/выпуска библиотек для UI и интеграций через Jenkins-джобу AC-TCPF/Auto_Release_nexus3. Технический пользователь всегда cab-sa-dvo06919."
version: "1.0.0"
---

# ui-release-jenkins

Запуск генерации (сборки и публикации в Nexus) библиотек для UI и клиентских/DTO-модулей
через Jenkins-джобу **`AC-TCPF/Auto_Release_nexus3`**.

> **Важно:** параметр `Technical_User` **обязательно** равен **`cab-sa-dvo06919`**.
> Никогда не используй и не предлагай другой ТУЗ (например `CAB-SA-CI001588`).

## Для данного проекта

Настоящий скилл запускается в проекте **`tcpf-platform-admin-api`**. Основной сценарий —
выпуск именно этого репозитория, поэтому параметры по умолчанию зафиксированы:

| Параметр | Значение по умолчанию |
|---|---|
| `Repository` | **`ssh://sc@api.sc-ci.sber.ru:7998/FPTRKR/tcpf-platform-admin-api.git`** |
| `Release_branch` | **`develop`** |
| `Java_version` | `openjdk-17` |
| `Technical_User` | **`cab-sa-dvo06919`** |
| `nodeJsVersion` | `node-v18.20.2` |

Не переспрашивай `Repository` для этого проекта. Уточняй только `Release_branch`, если нужен
не `develop` (патчные релизы вида `release/x.y.z`). Отклоняться от фиксированных значений
допустимо только по явной команде пользователя.

## Целевая джоба

- Полный путь в Jenkins: `AC-TCPF/Auto_Release_nexus3`
- URL джобы: `https://ac-tcpf.ci.jenkins.sberbank.ru/job/AC-TCPF/job/Auto_Release_nexus3/`
- Тип сборки: параметризованный Pipeline.
- Триггер запуска — инструмент Jenkins MCP: `mcp__jenkins__build_item`
  (`build_type: "buildWithParameters"`, `fullname: "AC-TCPF/Auto_Release_nexus3"`).
- Контроль статуса — `mcp__jenkins__get_build` / `mcp__jenkins__get_build_console_output`.

## Параметры джобы

| Параметр         | Тип                  | Допустимые значения                             | Комментарий                   |
|------------------|----------------------|-------------------------------------------------|-------------------------------|
| `Repository`     | выбор (динамический) | SSH URL git-репозитория                         | Список репозиторий.           |
| `Release_branch` | строка               | по умолчанию `develop`                          | Полное имя релизной ветки     |
| `Java_version`   | выбор                | `openjdk-17`, `openjdk-11`, `openjdk-8`         | По умолчанию `openjdk-17`     |
| `Technical_User` | выбор                | **только `cab-sa-dvo06919`**                    | ВСЕГДА фиксированное значение |
| `nodeJsVersion`  | выбор                | `node-v18.20.2`, `node-v20.12.2`, `node-22.5.1` | По умолчанию `node-v18.20.2`  |

## Что делает джоба

1. Чистит workspace (`deleteDir`).
2. Клонирует выбранный `Repository` на ветку `Release_branch` (git tool `Default`).
3. `mvn release:prepare` (Maven 3.8, JDK `Java_version`, Node `nodeJsVersion`), включая
   `-DskipWebpack=true`, теги вида `release/<major>.<minor>.<incremental>`.
4. `mvn release:perform` — публикация артефакта в Nexus.
5. Работает под credential технического пользователя, который задаётся `Technical_User`.

Креды git и maven settings приходят из конфигурации джобы (env-inject).
Агент сам эти креды не вводит — только выбирает `Technical_User = cab-sa-dvo06919`.

## Процедура запуска

При запросе пользователя «выпустить/сгенерировать библиотеку UI», «запустить релиз в nexus»
или «запустить Auto_Release_nexus3» выполни следующее.

### Шаг 1. Собери параметры

Для этого проекта (`tcpf-platform-admin-api`) значения фиксированы (см. раздел «Для данного
проекта»):

1. **`Repository`** — **всегда** `ssh://sc@api.sc-ci.sber.ru:7998/FPTRKR/tcpf-platform-admin-api.git`.
   Не спрашивай и не угадывай.
2. **`Release_branch`** — умолчание `develop`. Если нужен другой — уточни (патчные ветки вида `release/x.y.z`).
3. **`Java_version`** — умолчание `openjdk-17`.
4. **`nodeJsVersion`** — умолчание `node-v18.20.2`.
5. **`Technical_User`** — **всегда `cab-sa-dvo06919`**. Не спрашивай и не меняй.

### Шаг 2. Запусти сборку

Вызови:

```
mcp__jenkins__build_item
  fullname: "AC-TCPF/Auto_Release_nexus3"
  build_type: "buildWithParameters"
  data:
    Repository: ssh://sc@api.sc-ci.sber.ru:7998/FPTRKR/tcpf-platform-admin-api.git
    Release_branch: develop
    Java_version: openjdk-17
    Technical_User: cab-sa-dvo06919
    nodeJsVersion: node-v18.20.2
```

Проверь, что `Technical_User` в `data` равен ровно `cab-sa-dvo06919` перед отправкой.

### Шаг 3. Ожидай завершения

1. Получи очередь/номер сборки из ответа.
2. Периодически опрашивай `mcp__jenkins__get_build(fullname, number)`.
3. При завершении сообщи итог (SUCCESS/FAILURE) и при необходимости открой
   console log через `mcp__jenkins__get_build_console_output`.

## Правила и антипаттерны

- **Technical_User**: никогда не ставь `CAB-SA-CI001588` и не спрашивай, какой ТУЗ выбрать.
- `Repository` для этого проекта фиксирован (см. «Для данного проекта»); не запускай сборку
  другого репозитория без явной команды пользователя — сборка публикует в Nexus и меняет общее состояние.
- Не запрашивай и не логируй никакие пароли/токены. Креды подставляет сама джоба.
- Если джоба недоступна или инструмент Jenkins недоступен — остановись и сообщи, не обходи блокировку
  через shell или curl.
