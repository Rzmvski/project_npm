## Why

Администратор должен управлять узлами и семафорами в разрезе региона: видеть, какой регион обслуживает нагрузку, фильтровать узлы по региону и включать/отключать обслуживание региона. Сейчас узел/шарда не привязаны к региону в UI, а данные о регионах недоступны через admin-контракт, хотя уже существуют в downstream-сервисе `tcpf-routing-app-os`.

## What Changes

- Добавлен passthrough-контракт регионов в `tcpf-platform-admin-api` (тег RegionManagement, по образцу `cluster-management-service`):
  - `GET /invoke/support-admin/region/groups` → группы регионов `RegionGroup[] {startInclusive, endExclusive, region, regionAvailability?}` (из них UI выводит список регионов и их доступность);
  - `PUT /invoke/support-admin/region/groups` (body `RegionGroups`) → изменение принадлежности диапазонов регионам («Перевести диапазоны»);
  - `PUT /invoke/support-admin/region` (body `Regions`) → изменение доступности регионов.
  - Модели `RegionDto`/`RegionsDto`/`RegionGroupDto`/`RegionGroupsDto`; у `Shard` — поле `region` (`RegionDto[]`) для фильтрации в UI.
- В `tcpf-platform-admin-app` реализован passthrough по образцу GeoBalancing: `RegionManagementApiClient` (Reactive Feign, `extend RegionManagementApi`), `RegionManagementService`, `RegionManagementController`, WireMock-тест (GET и обе PUT-операции). Шарды без региона нормализуются к дефолтному региону из конфигурации.
- В UI `tcpf-support-admin-ui` на вкладке «Узлы» (`NodeManagementTab`) добавлен `RegionSelector` (FSD-слайс `entities/region`): выбор региона, фильтрация карточек шардов по региону, индикатор состояния региона (обслуживает/отключён), toggle доступности региона с подтверждением и перевод диапазонов на другой регион. Редакторы нагрузки/диапазонов/семафоров/пулов переиспользуются; несохранённые изменения в них не теряются при обновлении данных.
- Обновлён `mock-server` (endpoints `GET/PUT /region/groups`, `PUT /region`) и SDK `@sber-pprb-tkp/tcpf-platform-admin-api` (публичные exports `getRegionGroups`/`updateRegionGroups`/`updateRegionAvailability` и регион DTO).

## Capabilities

### New Capabilities
- region-management: passthrough-контракт регионов (группы регионов с диапазонами и доступностью, изменение доступности, перевод диапазонов) и его отражение на вкладке «Узлы» — выбор региона, фильтрация, статус, toggle on/off, «Перевести диапазоны».

### Modified Capabilities
- (нет)

## Impact

- **API:** `tcpf-platform-admin-api` (контракт, SDK `@sber-pprb-tkp/tcpf-platform-admin-api`).
- **App:** `tcpf-platform-admin-app` (passthrough региона по образцу GeoBalancing; зависит от `tcpf-routing-api`, где контракт региона уже есть).
- **UI:** `tcpf-support-admin-ui` (`entities/region`, `NodeManagementTab`, mock-server).
- **Downstream:** `tcpf-routing-api` / `tcpf-routing-app-os` — без изменений (контракт региона уже опубликован).

## Scope Clarification

- Регионы добавляются только на вкладке «Узлы» страницы «Управление узлами и семафорами». Отдельной страницы региональной маршрутизации нет.
- «groupId» = регион (идентификатор `Region.region`).
- Вне скоупа: консоль управления трафиком между узлами (item 3 MIN-PRIORITY), полный редизайн node-карточек из mockup (переиспользуются существующие редакторы), произвольное редактирование границ групп регионов (разбиение/слияние диапазонов — UI только переназначает регион у существующих диапазонов через `PUT /region/groups`), `tcpf-support-admin-api` / `tcpf-support-admin-app`.
- **Non-goal:** Redux/отдельный глобальный state manager (кэш — через TanStack Query).