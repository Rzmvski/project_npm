# GigaCode project configuration

The repository uses native project-level GigaCode CLI configuration:

```text
GIGACODE.md
.gigacode/
├── settings.json
├── agents/
│   ├── access-control-agent.md
│   ├── api-contract-agent.md
│   ├── browser-validation-agent.md
│   ├── frontend-engineer-agent.md
│   ├── quality-reviewer-agent.md
│   ├── specification-agent.md
│   └── validation-agent.md
└── skills/
    ├── api-contract-change/SKILL.md
    ├── browser-validation/SKILL.md
    ├── frontend-change/SKILL.md
    ├── project-documentation/SKILL.md
    ├── rbac-change/SKILL.md
    ├── sdd-delivery/SKILL.md
    └── verify-change/SKILL.md
```

This follows the GigaCode CLI project locations documented for
[memory](https://gitverse.ru/docs/ai/ai-assistant-gigacode/gigacode-cli/memory),
[skills](https://gitverse.ru/docs/ai/ai-assistant-gigacode/gigacode-cli/skills)
and
[subagents](https://gitverse.ru/docs/ai/ai-assistant-gigacode/gigacode-cli/subagents).

Project MCP servers are configured in `.gigacode/settings.json` according to
the official
[GigaCode MCP configuration](https://gitverse.ru/docs/ai/ai-assistant-gigacode/gigacode-cli/mcp).

## Responsibility split

- Root `GIGACODE.md` is always-on project memory: stack, sources of truth and
  non-negotiable rules.
- A skill is a repeatable workflow selected by its YAML `description`.
- A subagent is an optional isolated executor/reviewer with its own context.
- `docs/` contains detailed project knowledge loaded only when relevant.

For implementation tasks, the primary agent is the SDD coordinator. It uses
`sdd-delivery` to delegate specification, bounded implementation, read-only
review and independent validation. Findings return to the responsible stage;
the loop closes only when both independent gates pass. See
[`sdd-workflow.md`](sdd-workflow.md).

Avoid copying a complete manual into every layer. Permanent rules belong in
`GIGACODE.md`; procedural steps belong in a skill; role scope and handoff belong
in a subagent; detailed facts belong in canonical project docs.

## Skill format

Every project skill lives at `.gigacode/skills/<name>/SKILL.md`, and its file
starts with YAML frontmatter:

```yaml
---
name: frontend-change
description: Describe precisely when GigaCode should load this skill.
---
```

The `name` matches the parent directory. Supporting references or scripts are
added inside that skill directory only when the workflow genuinely needs them.

## Subagent format

Every project subagent is one Markdown file under `.gigacode/agents/` with
required YAML frontmatter:

```yaml
---
name: frontend-engineer
description: Describe when and how the primary agent should delegate to it.
---
```

Optional `model`, `approvalMode`, `tools` and `disallowedTools` fields should be
added only when the project requires an explicit override. The Markdown body is
the subagent system prompt.

## Browser validation

The project registers a pinned Playwright MCP server in
`.gigacode/settings.json`. It runs in an isolated browser profile, restricts
page requests to the local Vite origin and stores temporary screenshots under
the ignored `.gigacode/browser-artifacts/` directory.

After starting or restarting GigaCode CLI, verify the server through `/mcp`.
Browser-visible acceptance criteria are delegated to
`browser-validation-agent`, which follows the `browser-validation` skill and
returns screenshot, accessibility and console evidence without editing source
files.

## Maintenance

- Verify stack versions and commands against `package.json`.
- Keep each fact in one canonical document and link to it elsewhere.
- Keep skill descriptions specific enough for automatic selection.
- Keep subagent scope bounded; the primary agent remains responsible for the
  integrated result.
- Keep implementation, review and validation in separate subagent contexts; an
  implementer does not approve its own change.
- Validate YAML frontmatter, Markdown formatting and local links after changes.
