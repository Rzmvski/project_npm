# Documentation map

Read the minimum set needed for the current task. GigaCode project memory starts
at [`../GIGACODE.md`](../GIGACODE.md).

## Product and contracts

| Document                                             | Source of truth for                                 |
| ---------------------------------------------------- | --------------------------------------------------- |
| [`../README.md`](../README.md)                       | Setup, scripts and product overview                 |
| [`../API_DOCUMENTATION.md`](../API_DOCUMENTATION.md) | REST endpoints, DTOs, headers and status codes      |
| [`backend-contract.md`](backend-contract.md)         | Frontend/backend integration invariants             |
| [`access-control.md`](access-control.md)             | Roles, permissions, abilities and tenant scope      |
| [`java-user-endpoints.md`](java-user-endpoints.md)   | Reference backend implementation for user endpoints |

## Frontend implementation

| Document                                             | Use it for                                       |
| ---------------------------------------------------- | ------------------------------------------------ |
| [`architecture.md`](architecture.md)                 | FSD, providers, routing and data ownership       |
| [`frontend-conventions.md`](frontend-conventions.md) | Components, hooks, public APIs, state and styles |
| [`design-system.md`](design-system.md)               | Tokens, layout and shared UI ownership           |
| [`forms.md`](forms.md)                               | RHF/Zod architecture and domain form rules       |
| [`vuik.md`](vuik.md)                                 | VUIK integration and shared compositions         |

## Quality and change runbooks

| Document                                             | Use it for                                      |
| ---------------------------------------------------- | ----------------------------------------------- |
| [`testing.md`](testing.md)                           | Test strategy, harness and fixtures             |
| [`code-quality.md`](code-quality.md)                 | ESLint, Stylelint, Prettier and hooks           |
| [`validation.md`](validation.md)                     | Proportional command selection and reporting    |
| [`sdd-workflow.md`](sdd-workflow.md)                 | Closed-loop agent delegation and acceptance     |
| [`gigacode.md`](gigacode.md)                         | GigaCode memory, skills, agents and browser MCP |
| [`api-contract-changes.md`](api-contract-changes.md) | REST contract synchronization workflow          |
| [`rbac-changes.md`](rbac-changes.md)                 | RBAC synchronization workflow                   |

## Duplication policy

- A fact has one canonical document; other files link to it.
- `docs/API_DOCUMENTATION.md` is a compatibility pointer only.
- Skills describe procedures, not copied project manuals.
- Agent profiles describe scope and handoff, not another copy of coding rules.
