# Frontend conventions

This document is the source of truth for TypeScript, React and file-structure
conventions that are specific to this project.

## Components

Define components as typed arrow functions:

```tsx
interface ProcessBadgeProps {
  name: string
}

export const ProcessBadge: FC<ProcessBadgeProps> = ({ name }) => <Tag>{name}</Tag>
```

- Use `FC` and an arrow function for React components.
- Keep the props interface private to the component module.
- Destructure props and domain objects when it makes the accessed fields clear.
- Use single quotes in TSX; Prettier owns final formatting.
- Keep a component focused on rendering and interaction. Move stable column
  declarations, mappings, schemas and transformations into `model` or `lib`.

Each reusable component owns a same-named folder:

```text
ui/ProcessBadge/
├── ProcessBadge.tsx
├── ProcessBadge.module.scss
├── ProcessBadge.test.tsx
├── ProcessBadge.test-model.ts
└── index.ts
```

Only create files that the component actually needs. A component folder may
omit styles, tests or a test model, but its component module and explicit
`index.ts` remain colocated.

Hooks are different: place them as flat modules in the slice `lib` segment.

```text
lib/
├── useProcessFilters.ts
├── buildProcessQuery.ts
└── index.ts
```

Do not create a same-named directory for one hook.

## Public APIs and imports

- Every FSD layer, slice and conventional segment exposes an `index.ts` where
  required by ESLint.
- Public APIs use named exports only. `export *` and `export type *` are
  forbidden.
- Export only symbols used outside the boundary. Props interfaces stay private.
- Import another slice through its root public API; use relative imports inside
  the current slice.
- Do not create sibling-slice dependencies inside a sliced layer.

## State and data flow

- Do not put a router, QueryClient, schema, column declaration or other stable
  object in `useState`. Create it in the owning module/config factory.
- Use local state only for transient UI state that cannot be derived from props,
  Router search, RHF, Query or the VUIK imperative API.
- Catalog filters, pagination, tabs and sorting that must survive refresh or be
  shareable belong in typed TanStack Router search state.
- A refactor must preserve existing sort fields and direction unless sorting is
  explicitly in scope.
- Tenant-aware query keys include tenant UUID and requests send `tenant-id`.

## VUIK and shared UI

- Use controls from `@v-uik/base`; native `button`, `input`, `select` and
  `textarea` are not used when VUIK has the equivalent.
- Pass icons to `Button` with `prefixIcon` or `suffixIcon`.
- Use `shared/ui/DataTable` for application tables. Keep header and pagination
  visible; overflow belongs to the table body, not the page.
- Use shared form adapters (`FormInput`, `FormTextarea`, `FormNumberInput`,
  `FormCodeEditor`) for standard RHF fields.
- Use the shared modal hook/composition backed by the VUIK `modal` API instead
  of duplicating modal `useState` in feature components.
- Add a shared component only for repeated domain-neutral behavior, not to
  rename VUIK props.

## Forms

- Editable forms use React Hook Form and Zod.
- Keep API DTOs separate from form values when shape or nullability differs.
- Container components own defaults, request mapping and mutation lifecycle;
  field groups receive typed RHF state.
- Do not duplicate RHF values in local component state.
- Preserve form state after backend errors and prevent duplicate submissions.

Read [`forms.md`](forms.md) for domain-specific process, schedule and manual
start rules.

## Styles

- Component styles live in `ComponentName.module.scss` beside the component.
- CSS Module names use camelCase and semantic tokens from `shared/styles`.
- Do not use `:global` or `!important` in component styles.
- Prefer VUIK props and theme overrides over styling VUIK internals.
- Avoid nested surfaces and padding that reduce the working area of tables.

Read [`design-system.md`](design-system.md) and [`vuik.md`](vuik.md) for tokens,
layouts and VUIK integration.

## Application composition

- `AppLayout` is an application layout under `app`, not a widget.
- Providers own context only; they do not add decorative DOM or component
  styles solely to inject theme properties.
- Workspace error, forbidden and not-found states render within `AppLayout`.
- Application-level declarations belong in `config`, `model` or `lib`, not in
  an oversized provider or layout component.

## Tests

- Test observable behavior with accessible queries.
- Add regression coverage for fixed behavior when practical.
- Use a colocated `*.test-model.ts` only for a genuinely multi-step UI.
- Run the focused test and ESLint first; add typecheck, stylelint, full tests and
  build according to [`validation.md`](validation.md).
