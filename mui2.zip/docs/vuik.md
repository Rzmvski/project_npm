# VUIK integration runbook

## Use VUIK directly for

- buttons and icon actions;
- text, number, textarea and select inputs;
- checkbox/radio controls and groups;
- tags, avatars and progress indicators;
- tables and pagination primitives;
- bars, menu items, dividers and role selectors;
- modals and inline/global notifications;
- accordions and date controls.

Import from `@v-uik/base`. Do not recreate these primitives in `shared/ui`.

## A shared composition is justified when it owns

- repeated application layout;
- domain-neutral behavior used in several slices;
- React Hook Form controller/error integration;
- standard empty/loading/error presentation;
- application table/pagination coordination;
- modal behavior beyond renaming VUIK props.

## Adding a VUIK component

1. Search existing usage and VUIK types in `node_modules/@v-uik`.
2. Prefer the component's semantic props over CSS overrides.
3. Wire labels, descriptions and `aria-*` attributes.
4. Keep rich value components in a local RHF `Controller` when their contract
   does not fit an existing shared form adapter.
5. Style only surrounding layout in a CSS Module.
6. Add an application composition only after a second real repeated use.

## Notifications and modals

- `AppProviders` mounts the single global notification container.
- Call VUIK `notification.success/error/info/warning` directly.
- Use VUIK modal primitives or an existing shared application modal.
- Do not add a second toast/modal provider.

## Tables

- Use `shared/ui/DataTable` for application catalogs.
- Keep `tableLayout: 'fixed'` behavior.
- Pin primary identity/name columns to the start where needed.
- Pin action columns to the end and give them intentional alignment/padding.
- Do not build a native HTML table or introduce another table-state library
  without a demonstrated missing capability.

## Validation

```bash
npm run lint:eslint
npm run lint:styles
npm test
```

Visually inspect the affected screen because semantic tests do not detect
spacing, clipping or column alignment regressions.
