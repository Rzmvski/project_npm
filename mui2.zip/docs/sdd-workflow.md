# Spec-driven delivery workflow

Use this workflow for every code or behavior change. The primary GigaCode agent
is the coordinator: it owns the task context, delegates bounded work to named
subagents, integrates results and decides whether the acceptance criteria pass.
Do not delegate orchestration itself to a subagent.

## Closed loop

```text
request
  ↓
specification → plan → implementation
      ↑                    ↓
      └── correction ← independent review
                              ↓
                    independent validation
                              ↓
                         pass / repeat
```

The loop is closed because implementation is never accepted only on the
implementer's self-report. A separate reviewer checks the change and a separate
validator proves the acceptance criteria. Findings return to the appropriate
stage and the corrected result is reviewed again.

## 1. Specification

Delegate discovery and specification to `specification-agent` before editing.
Its output must contain:

- goal and user-visible outcome;
- acceptance criteria with stable IDs (`AC-1`, `AC-2`, ...);
- explicit in-scope and out-of-scope behavior;
- contracts and invariants that must remain unchanged;
- affected layers/files discovered from the repository;
- validation evidence required for each acceptance criterion;
- unresolved decisions that require user input.

For a tiny mechanical change, the specification may be short, but it still
states the intended outcome and preserved behavior. For a cross-cutting feature
or contract change, persist the approved specification under `docs/specs/`.

## 2. Plan and delegation

The primary agent converts the specification into bounded work packages. Each
package has one owner, exact files or boundaries, relevant acceptance criteria
and a required handoff.

Use the matching implementation subagent:

| Work package                         | Subagent                  |
| ------------------------------------ | ------------------------- |
| React, layout, forms, tables, styles | `frontend-engineer-agent` |
| REST contract, DTOs, mock API        | `api-contract-agent`      |
| Roles, permissions, abilities        | `access-control-agent`    |

Delegate independent packages in parallel only when they do not edit the same
files or depend on unfinished decisions. The primary agent resolves integration
order and conflicts.

## 3. Implementation handoff

Every implementer returns:

- acceptance criteria addressed;
- changed paths and behavior;
- checks run with actual results;
- assumptions, risks and remaining work.

An implementer's own tests are useful evidence but do not close the loop.

## 4. Independent review

Delegate the integrated change to `quality-reviewer-agent` in read-only mode.
The reviewer checks the request, specification and changed implementation for:

- correctness and regressions;
- API, tenant and RBAC contract compliance;
- FSD ownership and frontend conventions;
- missing error, empty, overflow and read-only behavior;
- missing or weak tests.

The reviewer returns `pass` or findings with severity, exact location, violated
acceptance criterion and remediation direction.

## 5. Independent validation

After review findings are resolved, delegate browser-visible acceptance
criteria to `browser-validation-agent`. Pass its independent evidence to
`validation-agent`, which maps every acceptance criterion to observable
evidence and runs proportional checks from `docs/validation.md`. For API/RBAC
changes it checks the relevant contract and permission paths.

Validation returns an acceptance matrix:

| Criterion | Evidence                    | Result            |
| --------- | --------------------------- | ----------------- |
| `AC-n`    | test, command or inspection | pass/fail/blocked |

## 6. Correction and stopping rule

- Implementation defect: return it to the responsible implementation agent.
- Specification mismatch: return it to `specification-agent` and update the
  plan before more edits.
- Validation gap: assign the missing test/check to the relevant implementer,
  then rerun independent review and validation.
- User decision or unsafe scope expansion: stop and ask the user.

Repeat until both reviewer and validator pass. After three unsuccessful
correction cycles for the same finding, stop and report the blocker with
evidence instead of looping indefinitely.

## Definition of done

A task is complete only when:

1. all acceptance criteria pass;
2. independent review has no unresolved correctness findings;
3. independent validation provides evidence for every criterion;
4. relevant canonical docs are synchronized;
5. the primary agent performs the final integration check and reports actual
   validation results.
