# Validation runbook

Select validation from the changed behavior. Do not copy old validation claims;
run commands in the current worktree and report their actual result.

## Minimum by change type

| Change                 | Minimum validation                                                  |
| ---------------------- | ------------------------------------------------------------------- |
| Markdown only          | Prettier check for changed Markdown and link scan                   |
| Pure TypeScript rule   | Typecheck, focused test, focused ESLint                             |
| React behavior         | Typecheck, focused RTL test, focused ESLint                         |
| Sass/layout            | Stylelint and visual inspection                                     |
| API contract           | Typecheck, entity API test, affected flow test, mock endpoint check |
| RBAC                   | `check:permissions`, access tests, affected route/action tests      |
| Cross-cutting/refactor | Full tests and production build                                     |

## Full validation sequence

```bash
npm run check:permissions
npm run format:check
npm run lint:eslint
npm run lint:styles
npm run typecheck
npm test
npm run build
```

## Focused commands

```bash
npx eslint path/to/changed.tsx
npx prettier --check path/to/changed.md
npx vitest run path/to/changed.test.tsx
node --check mock-server/index.js
```

## API smoke checks

When the mock changes, verify the actual response shape. Representative calls:

```bash
curl http://localhost:8080/api/v1/user

curl \
  -H 'tenant-id: 550e8400-e29b-41d4-a716-446655440000' \
  http://localhost:8080/api/v1/user/permissions
```

Check HTTP status, `ApiResponse` envelope and exact `data` shape.

## Visual checks

Use the running application for CSS/layout changes. Inspect the relevant route,
long text, empty/loading states and ordinary laptop widths. Tests cannot detect
clipping, misaligned tabs, excess padding or table-height regressions.

In the SDD workflow, the primary agent delegates these checks to
`browser-validation-agent` through the project Playwright MCP server, then
passes its evidence to `validation-agent` for the final acceptance matrix.

## Reporting

Final handoff should list:

- checks that passed;
- checks not run and why;
- unrelated pre-existing failures separately from regressions;
- warnings that do not fail the build, such as bundle-size warnings.
