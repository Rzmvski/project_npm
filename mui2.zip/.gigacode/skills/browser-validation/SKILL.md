---
name: browser-validation
description: Inspect and interact with the running Platform Maintenance Manager UI through the project Playwright MCP server. MUST BE USED for layout, styling, overflow, table, modal, navigation or other browser-visible behavior changes and when the user asks to check a local page.
priority: 80
---

# Browser validation

Use the tools exposed by the project `playwright` MCP server. The default target
is the local application at `http://localhost:5173`.

1. Verify that the UI is reachable. If the required local service is not
   running, report the blocker to the primary agent; do not silently replace
   browser validation with a unit test.
2. Navigate to the exact hash route for the acceptance criterion.
3. Read the current accessibility snapshot before interacting. Locate elements
   by role, label or visible text rather than fragile CSS selectors.
4. Reproduce the user flow with semantic actions. Take a fresh snapshot after
   navigation, modal changes or significant DOM updates.
5. Check visible content, interaction, overflow, table-body scrolling,
   pagination position and long-text behavior at the configured desktop
   viewport.
6. Capture a screenshot for visual evidence and inspect warning/error console
   messages relevant to the flow.
7. Return the route, actions, observed result, screenshot path/tool result and
   any console/network failures mapped to acceptance criteria.

Stay inside the local development application and its mock API unless the user
explicitly authorizes another target. Do not enter credentials, inspect browser
secrets or perform destructive product actions merely for validation.
