---
name: project-documentation
description: Create, restructure or synchronize Platform Maintenance Manager UI README files, canonical docs, root GIGACODE.md, project skills or project subagents. Do not use for source-code-only changes that need no documentation update.
---

# Project documentation

1. Read `docs/README.md` and `docs/gigacode.md`. Inspect `package.json`, current
   implementation and tests before changing factual claims about the stack or
   behavior.
2. Identify one canonical location for each fact. Replace duplicated prose with
   links or focused routing guidance.
3. Keep root `GIGACODE.md` concise and always applicable. Project skills live
   in `.gigacode/skills/<name>/SKILL.md`; subagents live in
   `.gigacode/agents/*.md` and use YAML frontmatter.
4. Skills describe reusable workflows and load detailed docs on demand. Agent
   profiles define bounded responsibility, inputs, boundaries and handoff; they
   are not copies of project manuals.
5. Keep names, extension identifiers, paths, versions and commands consistent
   with the repository. Do not preserve historical filenames that obscure a
   document's current purpose.
6. Update `docs/README.md` and all cross-references when documentation routing
   changes.
7. Validate Markdown/JSON formatting, local links and each changed skill. Report
   facts that could not be verified rather than guessing.

Documentation changes do not authorize API, RBAC or product behavior changes.
Load another skill if implementation must change too.
