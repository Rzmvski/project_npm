---
name: rbac-change
description: Change roles, permission IDs, UI abilities, route guards, tenant scope or development role switching in Platform Maintenance Manager UI. Do not use for ordinary visibility changes already covered by an existing Ability.
---

# RBAC change

1. Read `roleModel.xml`, `docs/access-control.md` and `docs/rbac-changes.md`.
2. Inventory the affected permission IDs and every frontend/mock reference.
3. Define the role-to-permission and permission-to-Ability mapping before
   editing.
4. Synchronize the XML model, permission catalog, abilities, guards, action
   visibility and mock authorization as one change.
5. Keep production checks based on `Ability`; preserve dev-only role switching
   and documented tenant scope.
6. Update role-model tests and affected route/action behavior tests, including a
   read-only path where relevant.
7. Run `npm run check:permissions`, focused tests, typecheck and build.

Use `access-control-agent` for a bounded mapping or implementation task. Use
`quality-reviewer-agent` to review privilege escalation and production/dev
separation.

Do not create compatibility aliases without an explicit requirement.
