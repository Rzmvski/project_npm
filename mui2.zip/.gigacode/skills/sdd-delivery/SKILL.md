---
name: sdd-delivery
description: Coordinate any Platform Maintenance Manager UI code or behavior change through specification, bounded implementation delegation, independent review, correction and independent validation. MUST BE USED for implementation and refactoring tasks; do not use for read-only questions or trivial documentation typo fixes.
priority: 100
---

# SDD delivery

The primary GigaCode agent coordinates this workflow. Read
`docs/sdd-workflow.md` and keep the task in a closed loop until it passes or
reaches an explicit stopping condition.

1. Delegate repository discovery and an acceptance-criteria specification to
   `specification-agent` before editing.
2. Convert the specification into bounded work packages and assign each package
   to the relevant implementation subagent. Include exact scope, preserved
   behavior, acceptance IDs and required evidence.
3. Integrate implementation handoffs; do not accept an implementer's
   self-validation as final evidence.
4. Delegate read-only review of the integrated change to
   `quality-reviewer-agent`.
5. Route findings back to the responsible implementer or, for a spec mismatch,
   back to `specification-agent`.
6. Once review passes, delegate browser-visible criteria to
   `browser-validation-agent`, then delegate the complete acceptance-matrix
   validation to `validation-agent`.
7. If either validation gate fails, fix the responsible work package and repeat independent
   review and validation.
8. Finish only when every acceptance criterion passes and both independent
   gates pass. Stop after three repeated failed correction cycles for the same
   finding and report the blocker.

For a small change, keep the spec and plan compact. Do not skip the separation
between implementation, review and validation.
