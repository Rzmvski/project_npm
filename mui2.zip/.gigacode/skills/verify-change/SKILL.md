---
name: verify-change
description: Perform an independent read-only review of completed Platform Maintenance Manager UI changes and select proportional validation before handoff or merge. Do not use to implement fixes.
---

# Verify change

1. Read the request, changed files and only the canonical docs governing the
   affected behavior.
2. Review correctness first: behavior, API contract, tenant scope, permissions,
   FSD ownership and information exposure.
3. Review maintainability against `docs/frontend-conventions.md` without
   presenting personal style preferences as defects.
4. Run the smallest meaningful check first, then expand according to
   `docs/validation.md`. Never infer full-suite success from focused checks.
5. For UI layout changes, inspect the running screen; semantic tests do not
   prove sizing, overflow or alignment.
6. Report findings by severity with exact file/location evidence, followed by
   checks run, checks skipped and the final verdict.

Use `quality-reviewer-agent` for the review. Keep the review read-only and do not
claim a command passed unless it completed successfully in the current worktree.
