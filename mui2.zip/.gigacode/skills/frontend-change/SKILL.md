---
name: frontend-change
description: Implement or review React pages, components, forms, layouts, tables, styles, TanStack Router search state or Query-driven UI in Platform Maintenance Manager UI. Do not use for a contract-only or RBAC-only change.
---

# Frontend change

1. Read `docs/frontend-conventions.md` and the closest production code and
   tests. Read `docs/design-system.md` for visual work and `docs/forms.md` for
   editable forms.
2. Trace ownership before editing: app composition, page search state, widget
   presentation, feature action, entity data or shared domain-neutral behavior.
3. Define the observable behavior, including loading, empty, error, disabled,
   overflow and read-only states that are relevant to the request.
4. Implement through explicit public APIs and existing VUIK/shared
   compositions. Keep component modules small and hooks flat in `lib`.
5. Preserve tenant scoping and the existing API sorting, pagination and query
   semantics unless the request explicitly changes them.
6. Update colocated tests for user-visible behavior. For layout work, inspect
   the running page at a representative viewport and with long/overflowing data.
7. Run focused ESLint/test checks first, then typecheck, Stylelint and broader
   checks according to `docs/validation.md`.

Use `frontend-engineer-agent` only for an isolated implementation subtask. Use
`quality-reviewer-agent` when an independent review materially improves the
result.

If the UI needs a new or changed endpoint, DTO or permission, stop treating it
as a frontend-only task and load the corresponding skill.
