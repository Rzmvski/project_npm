---
name: api-contract-change
description: Synchronize a REST endpoint, DTO, header, status code, query parameter or response field across Platform Maintenance Manager UI, its Express mock and contract tests. Do not use when UI code only consumes an unchanged contract.
---

# API contract change

1. Read `API_DOCUMENTATION.md`, `docs/backend-contract.md` and the affected
   entity API/types/tests.
2. Record the exact old-to-new mapping for method, path, headers, query,
   request, response and status codes. Treat unspecified behavior as unchanged.
3. Update the canonical contract and then synchronize entity types, request
   functions, query options and consumers through their public APIs.
4. Mirror the contract in `mock-server/index.js`, including validation,
   permissions and error behavior.
5. Update fixtures, API tests and the smallest affected user-flow test. Search
   for obsolete paths and fields after editing.
6. Preserve tenant headers/query keys, pagination and sorting unless they are
   explicitly part of the new contract.
7. Run the affected API tests, typecheck and build; add RBAC validation only
   when authorization changed.

Use `api-contract-agent` for bounded synchronization analysis or implementation.
Use `quality-reviewer-agent` to check for stale contract references.

Never infer backend capabilities from a desired UI alone.
