import type { UserAccess } from '@/entities/access'
import type { ProcessSummary, ProcessMutationResponse } from '@/entities/process'
import type {
  ProcessDetail,
  ProcessHistoryItem,
  RouteSessionMonitoring,
  ThreadSessionMonitoring,
} from '@/entities/process-history'
import type { AvailableRoutesResponse } from '@/entities/route'
import type { ScheduleResponse, TenantScheduleInfo } from '@/entities/schedule'
import type { Tenant } from '@/entities/tenant'
import type { UserProfile } from '@/entities/user'
import type { Page } from '@/shared/api'

export const TEST_TENANT_ID = '550e8400-e29b-41d4-a716-446655440000'
export const TEST_PROCESS_ID = '770e8400-e29b-41d4-a716-446655440002'
export const TEST_SESSION_ID = '880e8400-e29b-41d4-a716-446655440003'
export const TEST_ROUTE_SESSION_ID = '990e8400-e29b-41d4-a716-446655440004'

export const tenantFixture: Tenant = {
  id: TEST_TENANT_ID,
  code: 'TENANT_ALPHA',
}

export function userFixture(overrides: Partial<UserProfile> = {}): UserProfile {
  return {
    login: 'tester@example.com',
    displayName: 'Тестовый пользователь',
    roles: ['SUPER_ADMIN'],
    ...overrides,
  }
}

export function userAccessFixture(permissions: string[] = []): UserAccess {
  return permissions
}

export function processFixture(overrides: Partial<ProcessSummary> = {}): ProcessSummary {
  return {
    id: TEST_PROCESS_ID,
    processName: 'Дневная загрузка данных',
    processType: 'DB_PROCESS',
    description: 'Загружает данные из источников в витрины.',
    label: 'Загрузка данных',
    cmd: 'python /opt/etl/daily_load.py --date today',
    routes: [
      { routeKey: 'db-main.users', isLabel: false },
      { routeKey: 'Основные витрины', isLabel: true },
    ],
    ...overrides,
  }
}

export function processMutationFixture(
  overrides: Partial<ProcessMutationResponse> = {},
): ProcessMutationResponse {
  const process = processFixture()
  return {
    processId: process.id,
    processName: process.processName,
    processType: process.processType,
    description: process.description,
    label: process.label,
    ...overrides,
  }
}

export const routesFixture: AvailableRoutesResponse = {
  tenantId: TEST_TENANT_ID,
  routes: [
    { routeKey: 'db-main.users', labels: ['Основные витрины'] },
    { routeKey: 'db-main.orders', labels: ['Основные витрины', 'Архивные данные'] },
  ],
}

export const scheduleFixture: ScheduleResponse = {
  processId: TEST_PROCESS_ID,
  tenantId: TEST_TENANT_ID,
  scheduleDays: [
    {
      dayOfWeek: 'MON',
      startTime: '09:00',
      endTime: '18:00',
      intervalMin: 60,
    },
  ],
}

export function processDetailFixture(overrides: Partial<ProcessDetail> = {}): ProcessDetail {
  return {
    processId: TEST_PROCESS_ID,
    processName: 'Дневная загрузка данных',
    processType: 'DB_PROCESS',
    description: 'Загружает данные из источников в витрины.',
    label: 'Загрузка данных',
    isDeleted: false,
    startDate: '2026-08-05',
    processSession: {
      processSessionId: TEST_SESSION_ID,
      statusCode: 'SUCCESS',
      statusName: 'Завершен',
      startDateTime: '2026-08-05T10:00:00',
      endDateTime: '2026-08-05T10:15:42',
      recordsToProcess: 1000,
      totalRecords: 1000,
      successfulRecords: 980,
      failedRecords: 20,
      additionalParams: null,
      initiatorLogin: 'tester@example.com',
    },
    ...overrides,
  }
}

export function routeSessionFixture(
  overrides: Partial<RouteSessionMonitoring> = {},
): RouteSessionMonitoring {
  return {
    routeSessionId: TEST_ROUTE_SESSION_ID,
    routeKey: 'db-main.users',
    statusCode: 'SUCCESS',
    statusName: 'Завершен',
    startDateTime: '2026-08-05T10:00:05',
    endDateTime: '2026-08-05T10:15:25',
    recordsToProcess: 600,
    totalRecords: 600,
    successfulRecords: 590,
    failedRecords: 10,
    ...overrides,
  }
}

export function threadSessionFixture(
  overrides: Partial<ThreadSessionMonitoring> = {},
): ThreadSessionMonitoring {
  return {
    threadSessionId: 'aa0e8400-e29b-41d4-a716-446655440005',
    routeSessionId: TEST_ROUTE_SESSION_ID,
    threadNumber: 1,
    maxThreads: 3,
    statusCode: 'SUCCESS',
    statusName: 'Завершен',
    startDateTime: '2026-08-05T10:00:10',
    endDateTime: '2026-08-05T10:15:20',
    recordsToProcess: 300,
    totalRecords: 300,
    successfulRecords: 290,
    failedRecords: 10,
    podName: 'pod-1',
    errorDescription: null,
    ...overrides,
  }
}

export function pageFixture<T>(content: T[], overrides: Partial<Page<T>> = {}): Page<T> {
  return {
    content,
    totalElements: content.length,
    totalPages: content.length ? 1 : 0,
    size: 50,
    number: 0,
    numberOfElements: content.length,
    first: true,
    last: true,
    empty: content.length === 0,
    ...overrides,
  }
}

export function historyItemFixture(
  overrides: Partial<ProcessHistoryItem> = {},
): ProcessHistoryItem {
  return {
    processId: TEST_PROCESS_ID,
    processName: 'Дневная загрузка данных',
    processType: 'DB_PROCESS',
    description: 'Загружает данные из источников в витрины.',
    label: 'Загрузка данных',
    isDeleted: false,
    startDate: '2026-08-05',
    statusCode: 'SUCCESS',
    statusName: 'Завершен',
    startDateTime: '2026-08-05T10:00:00',
    endDateTime: '2026-08-05T10:15:42',
    sessionProcessId: TEST_SESSION_ID,
    initiatorLogin: 'tester@example.com',
    ...overrides,
  }
}

export function scheduleListItemFixture(
  overrides: Partial<TenantScheduleInfo> = {},
): TenantScheduleInfo {
  return {
    processId: TEST_PROCESS_ID,
    processName: 'Дневная загрузка данных',
    processType: 'DB_PROCESS',
    description: 'Загружает данные из источников в витрины.',
    label: 'Загрузка данных',
    scheduleDays: scheduleFixture.scheduleDays,
    ...overrides,
  }
}
