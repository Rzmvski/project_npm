import { historyRoute, processSessionRoute } from './historyRoutes'
import {
  processCreateRoute,
  processDetailsRoute,
  processEditRoute,
  processesRoute,
} from './processRoutes'
import { indexRoute, rootRoute, selectTenantRoute } from './rootRoutes'
import { routesRoute } from './routeRoutes'
import { scheduleDetailsRoute, scheduleEditorRoute, schedulesRoute } from './scheduleRoutes'
import { forbiddenRoute, notFoundRoute, workspaceRoute } from './workspaceRoutes'

const workspaceRouteTree = workspaceRoute.addChildren([
  forbiddenRoute,
  processesRoute,
  processCreateRoute,
  processEditRoute,
  processDetailsRoute,
  historyRoute,
  processSessionRoute,
  schedulesRoute,
  scheduleDetailsRoute,
  scheduleEditorRoute,
  routesRoute,
  notFoundRoute,
])

export const routeTree = rootRoute.addChildren([
  indexRoute,
  selectTenantRoute,
  workspaceRouteTree,
])
