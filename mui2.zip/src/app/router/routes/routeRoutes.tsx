import { createLazyRoute, createRoute } from '@tanstack/react-router'

import { Ability } from '@/entities/access'
import { loadRoutesPage } from '@/pages/routes'

import { requireAbility } from '../guards'
import { validateRoutesSearch } from '../model'

import { workspaceRoute } from './workspaceRoutes'

export const routesRoute = createRoute({
  getParentRoute: () => workspaceRoute,
  path: 'routes',
  beforeLoad: requireAbility(Ability.ROUTE_LIST),
  validateSearch: validateRoutesSearch,
}).lazy(() =>
  loadRoutesPage().then(({ RoutesPage }) =>
    createLazyRoute('/_workspace/routes')({ component: RoutesPage }),
  ),
)
