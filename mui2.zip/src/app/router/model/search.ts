import {
  CATALOG_PAGE_SIZES,
  parseOptionalSearchString,
  parsePaginationSearch,
  type PaginationSearch,
  type PaginationSearchInput,
} from '@/shared/lib'

import type { SearchSchemaInput } from '@tanstack/react-router'

interface HistorySearchInput extends SearchSchemaInput, PaginationSearchInput {
  query?: unknown
  status?: unknown
  category?: unknown
  from?: unknown
  to?: unknown
}

interface SchedulesSearchInput extends SearchSchemaInput, PaginationSearchInput {
  query?: unknown
  category?: unknown
  day?: unknown
}

export type RouteCatalogTab = 'routes' | 'db-sets'

interface RoutesSearchInput extends SearchSchemaInput, PaginationSearchInput {
  tab?: unknown
  query?: unknown
}

export interface HistorySearch extends PaginationSearch {
  query?: string
  status?: string
  category?: string
  from?: string
  to?: string
}

export interface SchedulesSearch extends PaginationSearch {
  query?: string
  category?: string
  day?: string
}

export interface RoutesSearch extends PaginationSearch {
  tab: RouteCatalogTab
  query?: string
}

export type PaginatedSearch = PaginationSearch

interface ScheduleEditorSearchInput extends SearchSchemaInput {
  returnTo?: unknown
}

export interface ScheduleEditorSearch {
  returnTo?: 'process'
}

export const validateHistorySearch = (search: HistorySearchInput): HistorySearch => ({
  ...parsePaginationSearch(search, {
    defaultSize: 20,
    defaultSort: 'desc:startDateTime',
    sizeOptions: CATALOG_PAGE_SIZES,
  }),
  query: parseOptionalSearchString(search.query),
  status: parseOptionalSearchString(search.status),
  category: parseOptionalSearchString(search.category),
  from: parseOptionalSearchString(search.from),
  to: parseOptionalSearchString(search.to),
})

export const validateSchedulesSearch = (search: SchedulesSearchInput): SchedulesSearch => ({
  ...parsePaginationSearch(search, {
    defaultSize: 20,
    defaultSort: 'asc:processName',
    sizeOptions: CATALOG_PAGE_SIZES,
  }),
  query: parseOptionalSearchString(search.query),
  category: parseOptionalSearchString(search.category),
  day: parseOptionalSearchString(search.day),
})

export const validateRoutesSearch = (search: RoutesSearchInput): RoutesSearch => ({
  ...parsePaginationSearch(search, {
    defaultSize: 20,
    defaultSort: 'asc:routeKey',
    sizeOptions: CATALOG_PAGE_SIZES,
  }),
  tab: search.tab === 'db-sets' ? 'db-sets' : 'routes',
  query: parseOptionalSearchString(search.query),
})

export const validateScheduleEditorSearch = (
  search: ScheduleEditorSearchInput,
): ScheduleEditorSearch => ({
  returnTo: search.returnTo === 'process' ? 'process' : undefined,
})
