import { CalendarClock, History, Layers3, Route, type LucideIcon } from 'lucide-react'

import { Ability, type AbilityId } from '@/entities/access'

export interface NavigationItem {
  to: '/processes' | '/history' | '/schedules' | '/routes'
  label: string
  icon: LucideIcon
  ability: AbilityId
}

export const navigationItems: readonly NavigationItem[] = [
  {
    to: '/processes',
    label: 'Процессы',
    icon: Layers3,
    ability: Ability.PROCESS_LIST,
  },
  {
    to: '/history',
    label: 'История',
    icon: History,
    ability: Ability.PROCESS_HISTORY,
  },
  {
    to: '/schedules',
    label: 'Расписания',
    icon: CalendarClock,
    ability: Ability.SCHEDULE_LIST,
  },
  {
    to: '/routes',
    label: 'Роуты',
    icon: Route,
    ability: Ability.ROUTE_LIST,
  },
]
