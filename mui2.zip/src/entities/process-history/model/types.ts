import type { Page, PaginationParams } from '@/shared/api'

export type ProcessStatusCode =
  'CREATED' | 'WORKS' | 'SUCCESS' | 'ERROR' | 'CANCELED' | 'STOPPED'

export interface ProcessHistoryItem {
  processId: string
  processName: string
  processType: string
  description: string | null
  label: string | null
  isDeleted: boolean
  startDate: string | null
  statusCode: ProcessStatusCode | null
  statusName: string | null
  startDateTime: string | null
  endDateTime: string | null
  sessionProcessId: string | null
  initiatorLogin: string | null
}

export interface ProcessSessionMonitoring {
  processSessionId: string
  statusCode: ProcessStatusCode
  statusName: string
  startDateTime: string
  endDateTime: string | null
  recordsToProcess: number
  totalRecords: number
  successfulRecords: number
  failedRecords: number
  additionalParams: string | null
  initiatorLogin: string | null
}

export interface ProcessDetail {
  processId: string
  processName: string
  processType: string
  description: string | null
  label: string | null
  isDeleted: boolean
  startDate: string | null
  processSession: ProcessSessionMonitoring
}

export interface RouteSessionMonitoring {
  routeSessionId: string
  routeKey: string
  statusCode: ProcessStatusCode
  statusName: string
  startDateTime: string
  endDateTime: string | null
  recordsToProcess: number
  totalRecords: number
  successfulRecords: number
  failedRecords: number
}

export interface ThreadSessionMonitoring {
  threadSessionId: string
  routeSessionId: string | null
  routeKey?: string | null
  threadNumber: number
  maxThreads: number
  statusCode: ProcessStatusCode
  statusName: string
  startDateTime: string
  endDateTime: string | null
  recordsToProcess: number
  totalRecords: number
  successfulRecords: number
  failedRecords: number
  podName: string | null
  errorDescription: string | null
}

// GET /process/history only sends page, size and sort — q/status/category/from/to
// are UI-only filter state (see pages/history/model) and must not be sent to the backend.
export type HistoryParams = PaginationParams

// GET /process/history/{id}/route-sessions only sends page, size and sort.
export type RouteSessionsParams = PaginationParams

// GET /process/history/{id}/thread-sessions only sends routeSessionId, page, size and sort —
// routeKey/pod/status are UI-only filter state and must not be sent to the backend.
export interface ThreadSessionsParams extends PaginationParams {
  routeSessionId?: string
}

export type ProcessHistoryPage = Page<ProcessHistoryItem>
export type RouteSessionsPage = Page<RouteSessionMonitoring>
export type ThreadSessionsPage = Page<ThreadSessionMonitoring>
