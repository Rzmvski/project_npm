export interface RouteInfo {
  routeKey: string
  labels: string[]
}

export interface AvailableRoutesResponse {
  tenantId: string
  routes: RouteInfo[]
}
