import { Ability, type AbilityId } from '../model/abilities'

import { canAccess } from './canAccess'

export type WorkspacePath = '/processes' | '/history' | '/schedules' | '/routes' | '/forbidden'

const entries: ReadonlyArray<{ ability: AbilityId; path: WorkspacePath }> = [
  { ability: Ability.PROCESS_LIST, path: '/processes' },
  { ability: Ability.PROCESS_HISTORY, path: '/history' },
  { ability: Ability.SCHEDULE_LIST, path: '/schedules' },
  { ability: Ability.ROUTE_LIST, path: '/routes' },
]

export const getDefaultWorkspacePath = (permissions: readonly string[]): WorkspacePath => {
  return entries.find(({ ability }) => canAccess(permissions, ability))?.path ?? '/forbidden'
}
