import { Permission, type PermissionId } from './permissions'

export const Ability = {
  PROCESS_LIST: 'process.list',
  PROCESS_DETAILS: 'process.details',
  PROCESS_CREATE: 'process.create',
  PROCESS_UPDATE: 'process.update',
  PROCESS_DELETE: 'process.delete',
  PROCESS_START: 'process.start',
  PROCESS_START_WITH_PARAMS: 'process.start.with-params',
  PROCESS_STOP: 'process.stop',
  PROCESS_HISTORY: 'process.history',
  PROCESS_HISTORY_DETAILS: 'process.history.details',
  PROCESS_HISTORY_ERROR_DETAILS: 'process.history.error-details',

  SCHEDULE_LIST: 'schedule.list',
  SCHEDULE_READ: 'schedule.read',
  SCHEDULE_EDIT: 'schedule.edit',
  SCHEDULE_CREATE: 'schedule.create',
  SCHEDULE_UPDATE: 'schedule.update',
  SCHEDULE_DELETE: 'schedule.delete',

  ROUTE_LIST: 'route.list',
} as const

export type AbilityId = (typeof Ability)[keyof typeof Ability]

/** Единственная точка соответствия UI-возможностей permission ID. */
export const abilityPolicy: Record<AbilityId, readonly PermissionId[]> = {
  [Ability.PROCESS_LIST]: [Permission.PROCESS_LIST],
  [Ability.PROCESS_DETAILS]: [Permission.PROCESS_LIST],
  [Ability.PROCESS_CREATE]: [Permission.PROCESS_CREATE],
  [Ability.PROCESS_UPDATE]: [Permission.PROCESS_UPDATE],
  [Ability.PROCESS_DELETE]: [Permission.PROCESS_DELETE],
  [Ability.PROCESS_START]: [Permission.PROCESS_START],
  [Ability.PROCESS_START_WITH_PARAMS]: [Permission.PROCESS_START_WITH_PARAMS],
  [Ability.PROCESS_STOP]: [Permission.PROCESS_STOP],
  [Ability.PROCESS_HISTORY]: [Permission.PROCESS_HISTORY],
  [Ability.PROCESS_HISTORY_DETAILS]: [Permission.PROCESS_HISTORY_DETAILS],
  [Ability.PROCESS_HISTORY_ERROR_DETAILS]: [Permission.PROCESS_HISTORY_ERROR_DETAILS],

  [Ability.SCHEDULE_LIST]: [Permission.SCHEDULE_LIST],
  [Ability.SCHEDULE_READ]: [
    Permission.SCHEDULE_LIST,
    Permission.SCHEDULE_READ_PROCESS,
    Permission.SCHEDULE_CREATE,
    Permission.SCHEDULE_UPDATE,
    Permission.SCHEDULE_DELETE,
  ],
  [Ability.SCHEDULE_EDIT]: [Permission.SCHEDULE_CREATE, Permission.SCHEDULE_UPDATE],
  [Ability.SCHEDULE_CREATE]: [Permission.SCHEDULE_CREATE],
  [Ability.SCHEDULE_UPDATE]: [Permission.SCHEDULE_UPDATE],
  [Ability.SCHEDULE_DELETE]: [Permission.SCHEDULE_DELETE],

  // GET /routes requires either tenantService_getAll or processService_getAll.
  [Ability.ROUTE_LIST]: [Permission.TENANT_LIST, Permission.PROCESS_LIST],
}
