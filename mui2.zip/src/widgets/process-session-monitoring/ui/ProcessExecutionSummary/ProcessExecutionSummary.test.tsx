import { render, screen, within } from '@testing-library/react'
import { describe, expect, it } from 'vitest'

import { processDetailFixture } from '@/test'

import { ProcessExecutionSummary } from './ProcessExecutionSummary'

describe('process execution summary', () => {
  it('renders metrics, category and structured launch parameters', () => {
    render(
      <ProcessExecutionSummary
        detail={processDetailFixture({
          processSession: {
            ...processDetailFixture().processSession,
            additionalParams: JSON.stringify({
              source: 'archive',
              nullable: null,
              options: { force: true },
              retries: 3,
            }),
          },
        })}
      />,
    )

    expect(screen.getByText('Загрузка данных')).toBeVisible()
    expect(screen.getByText('tester@example.com')).toBeVisible()
    expect(screen.getByText('К обработке').nextSibling).toHaveTextContent('1 000')
    const params = screen.getByText('Параметры запуска').closest('div')?.parentElement
    expect(params).not.toBeNull()
    expect(within(params!).getByText('archive')).toBeVisible()
    expect(within(params!).getByText('null')).toBeVisible()
    expect(within(params!).getByText('{"force":true}')).toBeVisible()
    expect(within(params!).getByText('3')).toBeVisible()
  })

  it('renders a plain value when parameters are not a JSON object', () => {
    render(
      <ProcessExecutionSummary
        detail={processDetailFixture({
          description: '',
          label: '',
          processSession: {
            ...processDetailFixture().processSession,
            endDateTime: null,
            additionalParams: 'not-json',
          },
        })}
      />,
    )

    expect(screen.getByText('Описание не указано')).toBeVisible()
    expect(screen.getByText('Значение')).toBeVisible()
    expect(screen.getByText('not-json')).toBeVisible()
    expect(screen.queryByText('Загрузка данных')).not.toBeInTheDocument()
  })

  it('does not render an empty parameters section', () => {
    render(<ProcessExecutionSummary detail={processDetailFixture()} />)

    expect(screen.queryByText('Параметры запуска')).not.toBeInTheDocument()
  })
})
