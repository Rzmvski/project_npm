import { screen, waitFor } from '@testing-library/react'
import { describe, expect, it } from 'vitest'

import { Permission } from '@/entities/access'
import { TEST_ROUTE_SESSION_ID } from '@/test'

import { ProcessSessionTestModel } from './ProcessSessionMonitoring.test-model'

describe('process execution monitoring', () => {
  it('shows one session table at a time', async () => {
    const page = await ProcessSessionTestModel.open()

    expect(screen.getByRole('tab', { name: 'Сводка', selected: true })).toBeVisible()
    expect(screen.queryByRole('table')).not.toBeInTheDocument()

    await page.showRoutes()
    page.expectOnlyRouteTable()

    await page.showThreadsFor('db-main.users')

    await screen.findByRole('tab', {
      name: 'Thread-сессии',
      selected: true,
    })
    expect(screen.getAllByRole('table')).toHaveLength(1)
    expect(screen.getByText('pod-1')).toBeVisible()
    await page.user.click(screen.getByRole('button', { name: 'Показать ошибку потока 1' }))
    expect(screen.getByRole('dialog')).toHaveTextContent('SQL statement timeout')
    await waitFor(() =>
      expect(page.router.state.location.search).toMatchObject({
        view: 'threads',
        threadRouteSessionId: TEST_ROUTE_SESSION_ID,
        threadRouteKey: 'db-main.users',
      }),
    )
  }, 10_000)

  it('hides thread error details without its dedicated permission', async () => {
    const page = await ProcessSessionTestModel.open([
      Permission.PROCESS_HISTORY,
      Permission.PROCESS_HISTORY_DETAILS,
    ])

    await page.showRoutes()
    await page.showThreadsFor('db-main.users')
    await screen.findByRole('tab', { name: 'Thread-сессии', selected: true })
    expect(
      screen.queryByRole('button', { name: 'Показать ошибку потока 1' }),
    ).not.toBeInTheDocument()
  })
})
