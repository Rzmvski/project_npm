import { Button, type ColumnProps, type RecordDataSource } from '@v-uik/base'
import { ArrowRight } from 'lucide-react'
import { useMemo, type FC } from 'react'

import { ProcessStatusBadge, type RouteSessionMonitoring } from '@/entities/process-history'
import { formatDateTime, formatDuration } from '@/shared/lib'
import { DataTable } from '@/shared/ui'

import styles from './RouteSessionsTable.module.scss'

type RouteRow = RecordDataSource<RouteSessionMonitoring>

interface RouteSessionsTableProps {
  items: RouteSessionMonitoring[]
  onShowThreads: (route: RouteSessionMonitoring) => void
}

export const RouteSessionsTable: FC<RouteSessionsTableProps> = ({ items, onShowThreads }) => {
  const dataSource = useMemo<RouteRow[]>(
    () => items.map((item) => ({ ...item, key: item.routeSessionId })),
    [items],
  )

  const columns = useMemo<ColumnProps<RouteRow>[]>(
    () => [
      {
        key: 'routeKey',
        dataIndex: 'routeKey',
        title: 'Route',
        width: 210,
        renderCellContent: ({ row }) => <strong>{row.routeKey}</strong>,
      },
      {
        key: 'statusCode',
        dataIndex: 'statusCode',
        title: 'Статус',
        width: 170,
        renderCellContent: ({ row }) => (
          <div className={styles.status}>
            <ProcessStatusBadge code={row.statusCode} name={row.statusName} />
          </div>
        ),
      },
      {
        key: 'startDateTime',
        dataIndex: 'startDateTime',
        title: 'Начало',
        width: 150,
        renderCellContent: ({ row }) => formatDateTime(row.startDateTime),
      },
      {
        key: 'duration',
        title: 'Длительность',
        width: 105,
        renderCellContent: ({ row }) => formatDuration(row.startDateTime, row.endDateTime),
      },
      {
        key: 'recordsToProcess',
        dataIndex: 'recordsToProcess',
        title: 'К обработке',
        width: 115,
        renderCellContent: ({ row }) => row.recordsToProcess.toLocaleString('ru-RU'),
      },
      {
        key: 'successfulRecords',
        dataIndex: 'successfulRecords',
        title: 'Успешно',
        width: 100,
        renderCellContent: ({ row }) => row.successfulRecords.toLocaleString('ru-RU'),
      },
      {
        key: 'failedRecords',
        dataIndex: 'failedRecords',
        title: 'Ошибки',
        width: 85,
        renderCellContent: ({ row }) => (
          <span className={row.failedRecords > 0 ? styles.failed : undefined}>
            {row.failedRecords.toLocaleString('ru-RU')}
          </span>
        ),
      },
      {
        key: 'actions',
        title: 'Действия',
        width: 105,
        align: 'center',
        renderCellContent: ({ row }) => (
          <div className={styles.actions}>
            <Button
              type='button'
              kind='ghost'
              color='secondary'
              size='sm'
              prefixIcon={<ArrowRight size={15} />}
              onClick={() => onShowThreads(row)}
            >
              Потоки
            </Button>
          </div>
        ),
      },
    ],
    [onShowThreads],
  )

  return (
    <DataTable
      fillAvailableHeight
      comfortable
      dataSource={dataSource}
      columns={columns}
      rowKey='routeSessionId'
      aria-label='Route-сессии'
    />
  )
}
