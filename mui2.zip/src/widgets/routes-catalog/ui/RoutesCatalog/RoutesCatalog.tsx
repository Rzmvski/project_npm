import { useQuery } from '@tanstack/react-query'
import { useNavigate, useSearch } from '@tanstack/react-router'
import { Tab, Tabs, type ColumnProps, type RecordDataSource } from '@v-uik/base'
import { Database, Tag as DbSetIcon } from 'lucide-react'
import { useMemo, type FC } from 'react'

import { ProcessTargetBadge } from '@/entities/process'
import { routeListQueryOptions } from '@/entities/route'
import { useRequiredTenantId } from '@/entities/tenant'
import { DataTable, EmptyState, ErrorState, LoadingState, Pagination } from '@/shared/ui'

import { createRouteCatalogItems, type RouteCatalogItem } from '../../lib'
import { RouteFilters } from '../RouteFilters'

import styles from './RoutesCatalog.module.scss'

type RouteRow = RecordDataSource<RouteCatalogItem>

export const RoutesCatalog: FC = () => {
  const tenantId = useRequiredTenantId()
  const search = useSearch({ from: '/_workspace/routes' })
  const navigate = useNavigate({ from: '/routes' })
  // query/page/size/sort are local filter state only — GET /routes takes no
  // parameters and always returns the tenant's full route list, so nothing
  // here is forwarded to the backend.
  const query = useQuery(routeListQueryOptions(tenantId))

  const setSearch = (patch: Partial<typeof search>) => {
    void navigate({
      search: (current) => ({ ...current, ...patch }),
      replace: true,
    })
  }

  const { dbRoutes, dbSets } = useMemo(() => {
    const routes = query.data?.routes ?? []
    return createRouteCatalogItems(routes)
  }, [query.data?.routes])

  if (query.isPending) return <LoadingState label='Загружаем роуты и DB сеты…' />
  if (query.isError) return <ErrorState title='Не удалось загрузить роуты и DB сеты' />

  const renderPanel = (items: RouteCatalogItem[], tab: 'routes' | 'db-sets') => {
    const normalizedQuery = search.query?.trim().toLowerCase()
    const filtered = normalizedQuery
      ? items.filter(
          ({ databases, routeKey }) =>
            routeKey.toLowerCase().includes(normalizedQuery) ||
            databases.some((database) => database.toLowerCase().includes(normalizedQuery)),
        )
      : items

    const totalElements = filtered.length
    const totalPages = Math.max(1, Math.ceil(totalElements / search.size))
    const currentPage = Math.min(search.page, totalPages - 1)
    const pageItems = filtered.slice(
      currentPage * search.size,
      currentPage * search.size + search.size,
    )

    const dataSource: RouteRow[] = pageItems.map((route) => ({ ...route, key: route.routeKey }))
    const Icon = tab === 'db-sets' ? DbSetIcon : Database

    const columns: ColumnProps<RouteRow>[] = [
      {
        key: 'routeKey',
        dataIndex: 'routeKey',
        title: tab === 'db-sets' ? 'DB set' : 'Ключ маршрута',
        width: tab === 'db-sets' ? 300 : undefined,
        renderCellContent: ({ row }) => (
          <div className={styles.routeKey}>
            <Icon size={16} aria-hidden='true' />
            <span>{row.routeKey}</span>
          </div>
        ),
      },
      ...(tab === 'db-sets'
        ? [
            {
              key: 'databases',
              dataIndex: 'databases',
              title: 'Базы данных',
              renderCellContent: ({ row }: { row: RouteRow }) => (
                <div className={styles.databases}>
                  {row.databases.map((routeKey) => (
                    <ProcessTargetBadge key={routeKey} target={{ routeKey, isLabel: false }} />
                  ))}
                </div>
              ),
            } satisfies ColumnProps<RouteRow>,
          ]
        : []),
    ]

    return (
      <div className={styles.panel}>
        <RouteFilters
          query={search.query}
          onChange={(nextQuery) => setSearch({ query: nextQuery, page: 0 })}
        />

        {dataSource.length ? (
          <>
            <DataTable
              fillAvailableHeight
              comfortable
              dataSource={dataSource}
              columns={columns}
              rowKey='routeKey'
            />
            <Pagination
              page={currentPage}
              totalPages={totalPages}
              size={search.size}
              totalElements={totalElements}
              onPageChange={(page) => setSearch({ page })}
              onSizeChange={(size) => setSearch({ size, page: 0 })}
            />
          </>
        ) : (
          <EmptyState
            title={
              normalizedQuery
                ? 'Ничего не найдено'
                : tab === 'db-sets'
                  ? 'DB sets ещё не созданы'
                  : 'Роуты недоступны'
            }
            description={
              normalizedQuery
                ? 'Измените поисковый запрос.'
                : tab === 'db-sets'
                  ? 'DB sets появятся здесь, когда администратор их создаст.'
                  : 'Для тенанта не настроено ни одного маршрута подключения к БД.'
            }
          />
        )}
      </div>
    )
  }

  return (
    <div className={styles.catalog}>
      <Tabs
        className={styles.tabsRoot}
        classes={{ tabs: styles.tabList, content: styles.tabContent }}
        value={search.tab}
        onChange={(value) =>
          setSearch({
            tab: value === 'db-sets' ? 'db-sets' : 'routes',
            page: 0,
            query: undefined,
          })
        }
      >
        <Tab value='routes' header='Роуты'>
          {renderPanel(dbRoutes, 'routes')}
        </Tab>
        <Tab value='db-sets' header='DB сеты'>
          {renderPanel(dbSets, 'db-sets')}
        </Tab>
      </Tabs>
    </div>
  )
}
