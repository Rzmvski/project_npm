import { Button } from '@v-uik/base'
import { FilterX } from 'lucide-react'

import { SearchInput } from '@/shared/ui'

import styles from './RouteFilters.module.scss'

import type { FC } from 'react'

interface RouteFiltersProps {
  query?: string
  onChange: (query: string | undefined) => void
}

export const RouteFilters: FC<RouteFiltersProps> = ({ query, onChange }) => {
  const hasActiveFilters = Boolean(query)

  return (
    <form className={styles.filters} aria-label='Фильтры роутов и DB сетов'>
      <div className={styles.filterGrid}>
        <div className={styles.searchField}>
          <SearchInput
            label='Поиск'
            value={query ?? ''}
            placeholder='Ключ маршрута'
            debounceMs={250}
            onChange={(value) => onChange(value || undefined)}
          />
        </div>

        <Button
          type='button'
          kind='ghost'
          color='secondary'
          prefixIcon={<FilterX size={16} />}
          disabled={!hasActiveFilters}
          onClick={() => onChange(undefined)}
        >
          Сбросить
        </Button>
      </div>
    </form>
  )
}
