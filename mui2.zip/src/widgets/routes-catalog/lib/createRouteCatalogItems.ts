import type { RouteInfo } from '@/entities/route'

export interface RouteCatalogItem {
  routeKey: string
  databases: string[]
}

export const createRouteCatalogItems = (routes: RouteInfo[]) => {
  const databasesBySet = new Map<string, Set<string>>()

  routes.forEach(({ labels, routeKey }) => {
    labels.forEach((label) => {
      const databases = databasesBySet.get(label) ?? new Set<string>()
      databases.add(routeKey)
      databasesBySet.set(label, databases)
    })
  })

  const byRouteKey = (left: RouteCatalogItem, right: RouteCatalogItem) =>
    left.routeKey.localeCompare(right.routeKey, 'ru')

  return {
    dbRoutes: routes.map(({ routeKey }) => ({ routeKey, databases: [] })).sort(byRouteKey),
    dbSets: [...databasesBySet.entries()]
      .map(([routeKey, databases]) => ({
        routeKey,
        databases: [...databases].sort((left, right) => left.localeCompare(right, 'ru')),
      }))
      .sort(byRouteKey),
  }
}
