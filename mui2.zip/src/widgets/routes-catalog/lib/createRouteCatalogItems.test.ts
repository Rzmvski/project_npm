import { describe, expect, it } from 'vitest'

import { createRouteCatalogItems } from './createRouteCatalogItems'

describe('createRouteCatalogItems', () => {
  it('groups databases by DB set without duplicates', () => {
    expect(
      createRouteCatalogItems([
        { routeKey: 'BETA', labels: ['RECON', 'COMMON'] },
        { routeKey: 'ALPHA', labels: ['COMMON', 'COMMON'] },
        { routeKey: 'DELTA', labels: [] },
      ]),
    ).toEqual({
      dbRoutes: [
        { routeKey: 'ALPHA', databases: [] },
        { routeKey: 'BETA', databases: [] },
        { routeKey: 'DELTA', databases: [] },
      ],
      dbSets: [
        { routeKey: 'COMMON', databases: ['ALPHA', 'BETA'] },
        { routeKey: 'RECON', databases: ['BETA'] },
      ],
    })
  })
})
