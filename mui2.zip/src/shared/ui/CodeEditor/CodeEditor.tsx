import { lazy, Suspense } from 'react'

import { appTokens } from '@/shared/config'

import styles from './CodeEditor.module.scss'

import type { FC } from 'react'

const LazyAceEditor = lazy(async () => {
  await import('ace-builds/src-noconflict/ace')
  await Promise.all([
    import('ace-builds/src-noconflict/ext-language_tools'),
    import('ace-builds/src-noconflict/mode-sql'),
    import('ace-builds/src-noconflict/theme-textmate'),
  ])

  const aceModule = await import('react-ace')
  const moduleDefault = aceModule.default as
    typeof aceModule.default | { default: typeof aceModule.default }
  const AceEditor =
    typeof moduleDefault === 'object' && 'default' in moduleDefault
      ? moduleDefault.default
      : moduleDefault

  return { default: AceEditor }
})

const defaultEditorHeight = Number.parseInt(appTokens.size.codeEditorHeight, 10)
const editorFontSize = Number.parseInt(appTokens.typography.fontSize.body, 10)
const editorLineHeight = Math.round(editorFontSize * 1.6)
const autoHeightPadding = 24
const autoHeightMin = 96

interface CodeEditorProps {
  value: string
  onChange?: (value: string) => void
  readOnly?: boolean
  /** Fixed pixel height, 'auto' for content, or 'fill' for the parent height. */
  height?: number | 'auto' | 'fill'
  maxAutoHeight?: number
}

export const CodeEditor: FC<CodeEditorProps> = ({
  value,
  onChange,
  readOnly,
  height = defaultEditorHeight,
  maxAutoHeight = defaultEditorHeight,
}) => {
  const resolvedHeight =
    height === 'fill'
      ? '100%'
      : height === 'auto'
        ? Math.min(
            maxAutoHeight,
            Math.max(
              autoHeightMin,
              value.split('\n').length * editorLineHeight + autoHeightPadding,
            ),
          )
        : height

  const editorHeight =
    typeof resolvedHeight === 'number' ? `${resolvedHeight}px` : resolvedHeight

  return (
    <div
      className={styles.editor}
      data-fill-height={height === 'fill' || undefined}
      style={{ height: editorHeight }}
    >
      <Suspense fallback={null}>
        <LazyAceEditor
          mode='sql'
          theme='textmate'
          value={value}
          onChange={onChange}
          readOnly={readOnly}
          width='100%'
          height='100%'
          fontSize={editorFontSize}
          style={{ fontFamily: appTokens.typography.codeFontFamily }}
          editorProps={{}}
          showPrintMargin={false}
          showGutter
          highlightActiveLine={!readOnly}
          setOptions={{
            useWorker: false,
            tabSize: 2,
            showLineNumbers: true,
            enableBasicAutocompletion: true,
            enableLiveAutocompletion: true,
          }}
        />
      </Suspense>
    </div>
  )
}
