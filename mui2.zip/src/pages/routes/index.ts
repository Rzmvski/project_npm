export const loadRoutesPage = () => import('./ui')
