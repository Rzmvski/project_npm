import { useIsFetching, useQueryClient } from '@tanstack/react-query'
import { Button } from '@v-uik/base'
import { RefreshCw } from 'lucide-react'

import { routeKeys } from '@/entities/route'
import { useRequiredTenantId } from '@/entities/tenant'
import { PageLayout } from '@/shared/ui'
import { RoutesCatalog } from '@/widgets/routes-catalog'

import type { FC } from 'react'

export const RoutesPage: FC = () => {
  const tenantId = useRequiredTenantId()
  const queryClient = useQueryClient()
  const isRefreshing = useIsFetching({ queryKey: routeKeys.list(tenantId) }) > 0

  return (
    <PageLayout
      contentLayout='table'
      title='Роуты и DB сеты'
      description='Маршруты подключения к базам данных и сохранённые DB sets, доступные тенанту.'
      actions={
        <Button
          type='button'
          kind='outlined'
          color='secondary'
          prefixIcon={<RefreshCw size={17} />}
          disabled={isRefreshing}
          onClick={() =>
            void queryClient.invalidateQueries({ queryKey: routeKeys.list(tenantId) })
          }
        >
          {isRefreshing ? 'Обновляем…' : 'Обновить'}
        </Button>
      }
    >
      <RoutesCatalog />
    </PageLayout>
  )
}
