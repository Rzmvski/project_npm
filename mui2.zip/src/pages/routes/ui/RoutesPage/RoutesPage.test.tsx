import { screen, waitFor } from '@testing-library/react'
import { describe, expect, it } from 'vitest'

import { Permission } from '@/entities/access'
import { renderApp, userAccessFixture } from '@/test'

describe('routes catalog page', () => {
  it('shows only DB routes on the routes tab by default', async () => {
    await renderApp({
      route: '/routes',
      access: userAccessFixture([Permission.PROCESS_LIST]),
    })

    await screen.findByRole('heading', { name: 'Роуты и DB сеты' })
    expect(screen.getByText('db-main.users')).toBeVisible()
    expect(screen.getByText('db-main.orders')).toBeVisible()
    expect(screen.queryByText('Основные витрины')).not.toBeInTheDocument()
    expect(screen.queryByRole('button', { name: 'Создать DB set' })).not.toBeInTheDocument()
  })

  it('switches to the DB sets tab without a create action', async () => {
    const app = await renderApp({
      route: '/routes',
      access: userAccessFixture([Permission.PROCESS_LIST]),
    })

    await screen.findByRole('heading', { name: 'Роуты и DB сеты' })
    await app.user.click(screen.getByRole('tab', { name: /DB сеты/ }))

    expect(await screen.findByText('Основные витрины')).toBeVisible()
    expect(screen.getByText('Архивные данные')).toBeVisible()
    expect(screen.getByText('db-main.users')).toBeVisible()

    expect(screen.queryByRole('button', { name: 'Создать DB set' })).not.toBeInTheDocument()
  })

  it('filters the active tab by the route key search query', async () => {
    const app = await renderApp({
      route: '/routes',
      access: userAccessFixture([Permission.PROCESS_LIST]),
    })

    await screen.findByRole('heading', { name: 'Роуты и DB сеты' })
    await app.user.type(screen.getByRole('textbox', { name: 'Ключ маршрута' }), 'orders')

    await waitFor(() => {
      expect(screen.queryByText('db-main.users')).not.toBeInTheDocument()
    })
    expect(screen.getByText('db-main.orders')).toBeVisible()
  })
})
