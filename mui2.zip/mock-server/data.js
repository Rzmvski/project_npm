import crypto from 'node:crypto'

export const tenants = [
  { id: '550e8400-e29b-41d4-a716-446655440000', code: 'TENANT_ALPHA' },
  { id: '660e8400-e29b-41d4-a716-446655440001', code: 'TENANT_BETA' },
]

const statusNames = {
  CREATED: 'Создан',
  WORKS: 'Исполняется',
  SUCCESS: 'Завершен',
  ERROR: 'Ошибка',
  CANCELED: 'Отменен',
  STOPPED: 'Остановлен',
}

const iso = (minutesAgo) =>
  new Date(Date.now() - minutesAgo * 60_000).toISOString().slice(0, 19)
const id = () => crypto.randomUUID()

function createCompletedSession(
  processId,
  statusCode = 'SUCCESS',
  offset = 90,
  routeKeys = [],
  threadsPerRoute = 3,
) {
  const sessionProcessId = id()
  const startDateTime = iso(offset)
  const endDateTime = iso(offset - 14)
  const routeSessions = routeKeys.map((routeKey, routeIndex) => {
    const routeSessionId = id()
    const routeStatus = statusCode === 'ERROR' && routeIndex % 11 === 0 ? 'ERROR' : 'SUCCESS'
    const records = Math.max(threadsPerRoute * 100, 500)
    const failed = routeStatus === 'ERROR' ? Math.ceil(records * 0.12) : 0

    return {
      routeSessionId,
      routeKey,
      statusCode: routeStatus,
      statusName: statusNames[routeStatus],
      startDateTime,
      endDateTime,
      recordsToProcess: records,
      totalRecords: records,
      successfulRecords: records - failed,
      failedRecords: failed,
      threadSessions: Array.from({ length: threadsPerRoute }, (_, index) => {
        const threadFailed = routeStatus === 'ERROR' && index % 4 === 0 ? 12 : 0
        return {
          threadSessionId: id(),
          routeSessionId,
          threadNumber: index + 1,
          maxThreads: threadsPerRoute,
          statusCode: threadFailed ? 'ERROR' : 'SUCCESS',
          statusName: threadFailed ? statusNames.ERROR : statusNames.SUCCESS,
          startDateTime,
          endDateTime,
          recordsToProcess: 100,
          totalRecords: 100,
          successfulRecords: 100 - threadFailed,
          failedRecords: threadFailed,
          podName: `process-worker-${(routeIndex % 8) + 1}-${(index % 16) + 1}`,
          errorDescription: threadFailed ? 'Mock SQL execution error: statement timeout' : null,
        }
      }),
    }
  })

  const totalRecords = routeSessions.reduce((total, route) => total + route.totalRecords, 0)
  const failedRecords = routeSessions.reduce((total, route) => total + route.failedRecords, 0)

  return {
    sessionProcessId,
    processId,
    initiatorLogin: 'mock-user@example.com',
    statusCode,
    statusName: statusNames[statusCode],
    startDate: startDateTime.slice(0, 10),
    startDateTime,
    endDateTime,
    recordsToProcess: totalRecords || 1000,
    totalRecords: totalRecords || 1000,
    successfulRecords: (totalRecords || 1000) - failedRecords,
    failedRecords,
    additionalParams: JSON.stringify({ source: 'mock-server', dryRun: 'false' }),
    routeSessions,
    directThreadSessions: routeKeys.length
      ? []
      : Array.from({ length: 1000 }, (_, index) => ({
          threadSessionId: id(),
          routeSessionId: null,
          threadNumber: index + 1,
          maxThreads: 1000,
          statusCode,
          statusName: statusNames[statusCode],
          startDateTime,
          endDateTime,
          recordsToProcess: 1,
          totalRecords: 1,
          successfulRecords: statusCode === 'SUCCESS' ? 1 : 0,
          failedRecords: statusCode === 'SUCCESS' ? 0 : 1,
          podName: `direct-worker-${(index % 20) + 1}`,
          errorDescription: statusCode === 'ERROR' ? 'Mock worker error' : null,
        })),
  }
}

function seedTenant(tenantId, code) {
  const isAlpha = code === 'TENANT_ALPHA'
  const routes = isAlpha
    ? [
        { routeKey: 'ALPHA', labels: ['GAMMA'] },
        { routeKey: 'BETA', labels: ['GAMMA', 'RECON'] },
        { routeKey: 'DELTA', labels: ['RECON'] },
      ]
    : [
        { routeKey: 'PAYMENTS_MAIN', labels: ['PAYMENTS_ALL'] },
        { routeKey: 'PAYMENTS_ARCHIVE', labels: ['PAYMENTS_ALL'] },
      ]

  const definitions = isAlpha
    ? [
        [
          'EOD Batch Processing',
          'DB_PROCESS',
          'Ежедневная пакетная обработка',
          'Закрытие дня',
          ['GAMMA'],
          ['ALPHA', 'BETA'],
          'execute_eod_batch --force',
        ],
        [
          'Customer Data Archive',
          'DB_PROCESS',
          'Архивирование данных клиентов',
          'Архивирование',
          ['GAMMA', 'RECON'],
          [],
          'ALTER TABLE customer SET (autovacuum_enabled = false);',
        ],
        [
          'Data Reconciliation',
          'DB_PROCESS',
          'Сверка данных между системами',
          'Сверка',
          ['RECON'],
          ['BETA', 'DELTA'],
          'SELECT reconcile_data();',
        ],
        [
          'Fraud Detection Export',
          'DB_PROCESS',
          'Экспорт данных по фроду',
          'Экспорт',
          [],
          ['ALPHA', 'BETA', 'DELTA'],
          'COPY fraud_events TO STDOUT;',
        ],
        [
          'Monthly Aggregation',
          'DB_PROCESS',
          'Ежемесячная агрегация отчётов',
          'Отчётность',
          [],
          ['DELTA'],
          'REFRESH MATERIALIZED VIEW monthly_report;',
        ],
      ]
    : [
        [
          'Payments Reindex',
          'DB_PROCESS',
          'Перестроение индексов платёжных БД',
          'Обслуживание',
          ['PAYMENTS_ALL'],
          ['PAYMENTS_MAIN'],
          'REINDEX DATABASE current_database();',
        ],
        [
          'Payments Archive Cleanup',
          'DB_PROCESS',
          'Очистка архивной БД',
          'Архивирование',
          ['PAYMENTS_ALL'],
          [],
          'VACUUM ANALYZE;',
        ],
      ]

  const expandedDefinitions = Array.from({ length: 30 }, (_, index) => {
    const definition = definitions[index % definitions.length]
    if (index < definitions.length) return definition

    const [processName, ...rest] = definition
    return [`${processName} #${String(index + 1).padStart(2, '0')}`, ...rest]
  })

  const processes = expandedDefinitions.map(
    ([processName, processType, description, label, dbSets, routeKeys, cmd]) => ({
      id: id(),
      processName,
      processType,
      description,
      label,
      dbSets,
      routes: routeKeys.map((routeKey) => ({ routeKey, isLabel: false })),
      cmd,
      deleted: false,
      createdAt: new Date().toISOString(),
    }),
  )

  const sessions = processes.map((process, index) => {
    let keys = [...process.routes.map((route) => route.routeKey), ...(process.dbSets ?? [])]
    let threadsPerRoute = 3

    if (index === 0 && isAlpha) {
      keys = Array.from({ length: 1000 }, (_, routeIndex) => {
        const baseRoute = keys[routeIndex % keys.length]
        return `${baseRoute}_${String(routeIndex + 1).padStart(4, '0')}`
      })
      threadsPerRoute = 1
    }

    return createCompletedSession(
      process.id,
      index === 0 && isAlpha ? 'ERROR' : index === 2 ? 'ERROR' : 'SUCCESS',
      75 + index * 180,
      keys,
      threadsPerRoute,
    )
  })

  const schedules = new Map()
  if (processes[0]) {
    schedules.set(processes[0].id, {
      processId: processes[0].id,
      tenantId,
      scheduleDays: [
        { dayOfWeek: 'MON', startTime: '09:00', endTime: '18:00', intervalMin: 60 },
        { dayOfWeek: 'WED', startTime: '10:00', endTime: '16:00', intervalMin: 120 },
        { dayOfWeek: 'FRI', startTime: '08:00', endTime: '17:00', intervalMin: 30 },
      ],
    })
  }

  const processTypes = new Set(['DB_PROCESS'])

  return { tenantId, routes, processes, sessions, schedules, processTypes }
}

export const stores = new Map(
  tenants.map((tenant) => [tenant.id, seedTenant(tenant.id, tenant.code)]),
)
export { createCompletedSession, statusNames }
