# Platform Maintenance Manager UI

React 18 + TypeScript 6 + Vite 8 interface for managing processes, execution
history and weekly schedules in a selected tenant. The repository includes an
Express mock backend for local development.

## Quick start

Requirements: Node.js `22.12+` and npm `10+`.

```bash
npm install
cp .env.example .env
npm run dev
```

| Service      | URL                                |
| ------------ | ---------------------------------- |
| UI           | `http://localhost:5173`            |
| Mock API     | `http://localhost:8080/api/v1`     |
| Health check | `http://localhost:8080/api/health` |

Run services separately when needed:

```bash
npm run dev:web
npm run dev:api
```

## Environment

```env
VITE_API_URL=/api/v1

# Optional endpoint overrides
# VITE_USER_ENDPOINT=/user
# VITE_PERMISSIONS_ENDPOINT=/user/permissions

# Optional frontend permissions fallback
# VITE_USER_PERMISSIONS=processService_getAll,historyService_getHistory

# Express mock identity and role
# MOCK_USER_ROLES=SUPER_ADMIN
# MOCK_USER_LOGIN=user@example.com
# MOCK_USER_NAME=Тестовый пользователь
```

The Vite dev server proxies `/api` to port `8080`. The UI loads the current
profile from `GET /user` and tenant-scoped permissions from
`GET /user/permissions`.

## Product routes

```text
/#/select-tenant
/#/processes
/#/processes/new
/#/processes/:processId
/#/processes/:processId/edit
/#/history
/#/history/:sessionProcessId
/#/schedules
/#/schedules/:processId
/#/schedules/:processId/edit
```

The application uses TanStack Router hash history to satisfy IAM deployment
requirements. Route paths after `#` are handled entirely by the frontend, so
the hosting server does not need SPA rewrite rules for nested routes.

Tenant UUID is stored in `localStorage` under `ppm.selectedTenantId`; it is not
part of the URL. Tenant-aware requests carry `tenant-id`, and tenant-aware
React Query keys include the same UUID.

## Main capabilities

- process catalog, read-only card, create, edit and soft delete;
- manual start and stop, including optional launch parameters;
- process execution history;
- paginated route and thread monitoring;
- schedule catalog and weekly schedule editor;
- backend-driven user profile and permission-based UI access;
- dev-only role switching against the Express mock.

## Technology

- React 18, TypeScript 6 and Vite 8;
- TanStack Router and Query;
- React Hook Form and Zod;
- Platform V UI Kit (`@v-uik/base`, `@v-uik/theme`);
- Sass Modules and application design tokens;
- Vitest, React Testing Library and `user-event`;
- ESLint, Stylelint, Prettier, Husky and commitlint.

The UI displays its current version from the root `package.json`; update the
package version before preparing a release.

## Quality

```bash
npm run check:permissions
npm run format:check
npm run lint:eslint
npm run lint:styles
npm run typecheck
npm test
npm run build
```

## Documentation

- GigaCode starts with [`GIGACODE.md`](GIGACODE.md).
- GigaCode setup, agents and skills are described in
  [`docs/gigacode.md`](docs/gigacode.md).
- The documentation index is [`docs/README.md`](docs/README.md).
- The canonical REST contract is [`API_DOCUMENTATION.md`](API_DOCUMENTATION.md).
- Access rules are in [`docs/access-control.md`](docs/access-control.md).
- Architecture rules are in [`docs/architecture.md`](docs/architecture.md).
- Component conventions are in
  [`docs/frontend-conventions.md`](docs/frontend-conventions.md).
