# Platform Maintenance Manager UI

React 18, TypeScript 6 and Vite 8 frontend with an Express 5 mock API. The
application manages tenant-scoped maintenance processes, manual execution,
history, route/thread monitoring and weekly schedules.

## Sources of truth

| Concern                      | Canonical source                             |
| ---------------------------- | -------------------------------------------- |
| REST endpoints and DTOs      | `API_DOCUMENTATION.md`                       |
| Frontend/backend integration | `docs/backend-contract.md`                   |
| Roles and permissions        | `roleModel.xml`                              |
| UI abilities                 | `src/entities/access/model/abilities.ts`     |
| Entity types and API clients | `src/entities/*/model`, `src/entities/*/api` |
| Local backend behavior       | `mock-server/index.js`                       |
| Architecture                 | `docs/architecture.md`                       |
| Frontend conventions         | `docs/frontend-conventions.md`               |
| Design system                | `docs/design-system.md`                      |
| Tests and validation         | `docs/testing.md`, `docs/validation.md`      |

When sources disagree, inspect current implementation and tests and report the
conflict. Do not invent a contract or silently preserve obsolete documentation.

## Architecture and code rules

- Preserve FSD direction: `app → pages → widgets → features → entities → shared`.
- Import another slice through its root `index.ts`. Public APIs use explicit
  named exports; `export *` and `export type *` are forbidden.
- App providers, router integration, errors and `AppLayout` stay in `app`.
  Workspace error, forbidden and not-found states render inside `AppLayout`.
- Define React components as arrow functions typed with `FC`. Keep props types
  private and destructure props/domain objects when accessing their fields.
- Put every reusable component in a same-named folder with its component,
  optional styles/test/test-model and explicit `index.ts`.
- Put hooks as flat modules in the slice `lib`; do not wrap one hook in its own
  folder.
- Use VUIK controls instead of native interactive elements. Pass button icons
  through `prefixIcon` or `suffixIcon`.
- Editable forms use React Hook Form and Zod. Do not duplicate form values in
  local state.
- Use `shared/ui/DataTable`; keep pagination visible and overflow inside the
  table body rather than the page.
- Component styles use Sass Modules, semantic tokens and camelCase classes.
  Do not use `:global` or `!important`.
- Keep stable routers, QueryClient instances, schemas and column declarations
  out of `useState`.

## Data and access invariants

- Tenant-aware requests send `tenant-id`; their React Query keys include the
  tenant UUID. `GET /user` is the pre-tenant exception.
- UI authorization uses `Ability`, never role names or raw permission IDs.
- URL-shareable catalog filters use typed TanStack Router search state.
- Preserve API sorting, pagination and query parameter semantics unless the
  request explicitly changes them.
- Do not send UI-only filters to backend endpoints.

## Project workflows

Project skills are discovered from `.gigacode/skills/`:

- `sdd-delivery` — required closed-loop orchestration for code and behavior
  changes;
- `browser-validation` — Playwright MCP inspection of browser-visible changes;
- `frontend-change` — pages, components, forms, tables, styles and routing;
- `api-contract-change` — endpoints, DTOs, entity clients and mock API;
- `rbac-change` — roles, permissions, abilities and guards;
- `project-documentation` — README, docs, GIGACODE, skills and agents;
- `verify-change` — read-only review and proportional validation.

For every implementation or refactoring task, the primary agent MUST use
`sdd-delivery` and coordinate the closed loop from `docs/sdd-workflow.md`:
specification → plan → bounded implementation → independent review → correction
→ independent validation. The implementer cannot approve its own result.

Project subagents are discovered from `.gigacode/agents/`:

- `specification-agent` defines acceptance criteria before edits;
- domain implementers own bounded frontend, API or access work packages;
- `quality-reviewer-agent` reviews the integrated change in read-only mode;
- `browser-validation-agent` checks visual and interactive criteria through the
  local Playwright MCP server;
- `validation-agent` independently proves every acceptance criterion.

The primary agent owns orchestration, integration and the final decision. It
must route findings back to the responsible stage and repeat review and
validation until both pass or the documented stopping rule is reached.

## Working agreement

1. Start implementation tasks with the SDD specification and delegation loop.
2. Inspect the closest production code and tests before editing.
3. Preserve unrelated changes and existing behavior outside the request.
4. Keep modules focused; extract declarations, transformations and hooks when
   they obscure the component's purpose.
5. Add or update observable behavior tests for behavior changes.
6. Run focused checks first, then expand validation according to risk.
7. Report commands actually run and checks intentionally skipped.

Use scripts from `package.json`: `lint`, `typecheck`, `test`, `test:coverage`,
`check:permissions`, `build` and their focused tool equivalents.
