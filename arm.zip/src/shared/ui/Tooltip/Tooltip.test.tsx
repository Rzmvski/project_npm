import { render, screen } from '@testing-library/react'
import React from 'react'

import { Tooltip } from './Tooltip'

const tooltipMock = vi.hoisted(() =>
  vi.fn(({ children }: React.PropsWithChildren<Record<string, any>>) => <>{children}</>),
)

vi.mock('@v-uik/base', () => ({ Tooltip: tooltipMock }))

describe('Tooltip', () => {
  beforeEach(() => {
    tooltipMock.mockClear()
  })

  it('renders the popup in the document portal with stable positioning defaults', () => {
    render(
      <Tooltip dropdownProps={{ content: 'Подсказка' }}>
        <button>Действие</button>
      </Tooltip>,
    )

    expect(screen.getByRole('button', { name: 'Действие' })).toBeVisible()
    expect(tooltipMock).toHaveBeenCalledOnce()

    const props = tooltipMock.mock.calls[0][0]
    expect(props).toMatchObject({
      pointAtCenter: true,
      single: false,
      hideOnScroll: true,
    })
    expect(props.dropdownProps).toMatchObject({
      content: 'Подсказка',
      disablePortal: false,
    })
    expect(props.dropdownProps.container()).toBe(document.body)
  })

  it('allows an exceptional consumer to override a default', () => {
    render(
      <Tooltip
        pointAtCenter={false}
        dropdownProps={{ content: 'Подсказка', disablePortal: true }}
      >
        <button>Действие</button>
      </Tooltip>,
    )

    const props = tooltipMock.mock.calls[0][0]
    expect(props.pointAtCenter).toBe(false)
    expect(props.dropdownProps.disablePortal).toBe(true)
  })
})
