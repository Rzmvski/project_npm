import { fireEvent, render, screen, waitFor } from '@testing-library/react'
import React from 'react'

import { ServiceTabs } from './ServiceTabs'
import { TabContext } from './TabContext'

import type { TabContent } from './ServiceTabs'

const mocks = vi.hoisted(() => ({
  navigate: vi.fn(),
  tab: undefined as string | undefined,
}))

vi.mock('@tanstack/react-router', () => ({
  useNavigate: () => mocks.navigate,
  useParams: () => ({ tab: mocks.tab }),
}))

vi.mock('@v-uik/base', () => ({
  Tabs: ({
    children,
    value,
    classes,
    onChange,
  }: React.PropsWithChildren<{
    value?: string
    onChange?: (value: string) => void
    classes?: { root?: string; content?: string }
  }>) => (
    <div data-testid='tabs' data-value={value} className={`${classes?.root ?? ''}`}>
      <div data-testid='tabs-content' className={`${classes?.content ?? ''}`}>
        {children}
      </div>
      <button onClick={() => onChange?.('tab-b')}>{'Switch to Tab B'}</button>
    </div>
  ),
  Tab: ({
    children,
    header,
    value,
  }: React.PropsWithChildren<{
    header?: React.ReactNode
    value?: string
  }>) => (
    <div data-testid='tab' data-tab-value={value}>
      <button
        data-testid='tab-header'
        onClick={() => {
          // Simulate Tabs onChange behavior — in real component, Tabs handles this
        }}
      >
        {header}
      </button>
      <div data-testid='tab-content'>{children}</div>
    </div>
  ),
  useStorage: (type: string, key: string, defaultValue: string) => {
    void type
    void key
    return React.useState<string>(defaultValue)
  },
}))

const TabA: React.FC = () => <div>Tab A Content</div>
const TabB: React.FC = () => <div>Tab B Content</div>

const tabs: TabContent[] = [
  { tabName: 'tab-a', title: 'Tab A', component: TabA },
  { tabName: 'tab-b', title: 'Tab B', component: TabB },
]

describe('ServiceTabs', () => {
  beforeEach(() => {
    mocks.navigate.mockClear()
    mocks.tab = undefined
  })

  it('renders all tab headers', () => {
    render(<ServiceTabs serviceName='test-service' defaultTabName='tab-a' tabs={tabs} />)

    expect(screen.getByText('Tab A')).toBeInTheDocument()
    expect(screen.getByText('Tab B')).toBeInTheDocument()
  })

  it('renders the default active tab content', () => {
    render(<ServiceTabs serviceName='test-service' defaultTabName='tab-a' tabs={tabs} />)

    expect(screen.getByText('Tab A Content')).toBeInTheDocument()
  })

  it('provides TabContext with activeTab value', () => {
    const Consumer: React.FC = () => {
      const ctx = React.useContext(TabContext)
      return <div data-testid='tab-context'>{ctx?.activeTab}</div>
    }

    const tabsWithConsumer: TabContent[] = [
      { tabName: 'tab-a', title: 'Tab A', component: Consumer },
    ]

    render(
      <ServiceTabs serviceName='test-service' defaultTabName='tab-a' tabs={tabsWithConsumer} />,
    )

    expect(screen.getByTestId('tab-context')).toHaveTextContent('tab-a')
  })

  it('uses externally controlled active tab', () => {
    render(
      <ServiceTabs
        serviceName='test-service'
        defaultTabName='tab-a'
        activeTabName='tab-b'
        tabs={tabs}
      />,
    )

    expect(screen.getByTestId('tabs')).toHaveAttribute('data-value', 'tab-b')
    expect(screen.getByText('Tab B Content')).toBeInTheDocument()
  })

  it('calls onChange when tab is switched', () => {
    const handleChange = vi.fn()

    render(
      <ServiceTabs
        serviceName='test-service'
        defaultTabName='tab-a'
        tabs={tabs}
        onChange={handleChange}
      />,
    )

    fireEvent.click(screen.getByRole('button', { name: 'Switch to Tab B' }))

    expect(handleChange).toHaveBeenCalledWith('tab-b')
  })

  it('synchronizes active tab with route parameter', () => {
    mocks.tab = 'tab-b'

    render(
      <ServiceTabs
        serviceName='test-service'
        defaultTabName='tab-a'
        routePath='/test-service'
        tabs={tabs}
      />,
    )

    expect(screen.getByTestId('tabs')).toHaveAttribute('data-value', 'tab-b')
    expect(mocks.navigate).not.toHaveBeenCalled()

    fireEvent.click(screen.getByRole('button', { name: 'Switch to Tab B' }))
    expect(mocks.navigate).toHaveBeenCalledWith({
      to: '/test-service/{-$tab}',
      params: { tab: 'tab-b' },
    })
  })

  it('writes default tab to route when parameter is missing', async () => {
    render(
      <ServiceTabs
        serviceName='test-service'
        defaultTabName='tab-a'
        routePath='/test-service'
        tabs={tabs}
      />,
    )

    await waitFor(() => {
      expect(mocks.navigate).toHaveBeenCalledWith({
        to: '/test-service/{-$tab}',
        params: { tab: 'tab-a' },
        replace: true,
      })
    })
  })

  it('renders with a single tab', () => {
    const singleTab: TabContent[] = [{ tabName: 'only', title: 'Only Tab', component: TabA }]

    render(<ServiceTabs serviceName='single-service' defaultTabName='only' tabs={singleTab} />)

    expect(screen.getByText('Only Tab')).toBeInTheDocument()
    expect(screen.getByText('Tab A Content')).toBeInTheDocument()
  })
})
