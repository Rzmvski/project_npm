import type { TrafficRestriction } from '@/entities/traffic-restriction'

import {
  fetchCreateRestriction,
  fetchRemoveRestriction,
  fetchUpdateRestriction,
} from './fetchManageRestriction'

const service = vi.hoisted(() => ({
  createTrafficRestrictionStream: vi.fn(() => (async function* () {})()),
  updateTrafficRestrictionStream: vi.fn(() => (async function* () {})()),
  removeTrafficRestrictionByIdStream: vi.fn(() => (async function* () {})()),
}))
vi.mock('@/shared/api', () => ({
  geoBalancingManagementService: service,
}))

const restriction: TrafficRestriction = {
  id: 'restriction-1',
  name: 'Maintenance',
  services: ['payments'],
  dataCenters: ['dc-1'],
  createComment: 'planned',
}

describe('manage restriction api', () => {
  it('переносит доменный createComment в API comment при создании', () => {
    fetchCreateRestriction(restriction)
    expect(service.createTrafficRestrictionStream).toHaveBeenCalledWith(
      expect.objectContaining({ comment: 'planned' }),
    )
  })

  it('обновляет ограничение по id', () => {
    fetchUpdateRestriction(restriction)
    expect(service.updateTrafficRestrictionStream).toHaveBeenCalledWith(
      'restriction-1',
      expect.objectContaining({ comment: 'planned' }),
    )
  })

  it('не отправляет обновление без id', async () => {
    await expect(fetchUpdateRestriction({ ...restriction, id: undefined })).rejects.toThrow(
      'restriction id not provided',
    )
  })

  it('удаляет ограничение по id', () => {
    fetchRemoveRestriction('restriction-1')
    expect(service.removeTrafficRestrictionByIdStream).toHaveBeenCalledWith('restriction-1')
  })
})
