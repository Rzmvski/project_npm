import { type ProcessDtoDto } from '@sber-pprb-tkp/tcpf-support-admin-api'

import { type ClearTaskOutputValues } from '@/entities/clear-task'
import { clientTransferService } from '@/shared/api'
import { toApiLocalDate } from '@/shared/lib'

export const fetchClearing = ({
  attempt,
  clearDate,
  ...transferRequest
}: ClearTaskOutputValues): Promise<ProcessDtoDto> => {
  return clientTransferService.clear({
    ...transferRequest,
    repeat: attempt,
    deleteUpToDate: toApiLocalDate(clearDate),
  })
}
