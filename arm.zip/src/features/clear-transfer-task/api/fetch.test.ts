import { fetchClearing } from './fetch'

const clear = vi.hoisted(() => vi.fn())
vi.mock('@/shared/api', () => ({ clientTransferService: { clear } }))

it('fetchClearing преобразует attempt и календарную дату в поля API', () => {
  fetchClearing({
    attempt: true,
    clearDate: new Date(2026, 7, 13, 23, 30),
    taskId: 42,
  } as never)
  expect(clear).toHaveBeenCalledWith({
    taskId: 42,
    repeat: true,
    deleteUpToDate: new Date('2026-08-13T00:00:00.000Z'),
  })
})
