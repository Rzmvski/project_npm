import { fetchChangeSemaphore } from './fetch'

const updateSemaphoresOfShardByIdStream = vi.hoisted(() =>
  vi.fn(() => (async function* () {})()),
)
vi.mock('@/shared/api', () => ({
  clusterManagementService: { updateSemaphoresOfShardByIdStream },
}))

it('fetchChangeSemaphore отправляет обновлённые диапазоны бакетов выбранной шарды', () => {
  const changedBucketRanges = [{ nodeKey: 'node-1' }]
  fetchChangeSemaphore(42, changedBucketRanges as never)
  expect(updateSemaphoresOfShardByIdStream).toHaveBeenCalledWith(42, {
    changedBucketRanges,
  })
})
