import { fetchSchemaMetadataRefresh } from './fetch'

const refreshMetadataOnNodeStream = vi.hoisted(() => vi.fn(() => (async function* () {})()))
vi.mock('@/shared/api', () => ({
  metadataManagementService: { refreshMetadataOnNodeStream },
}))

it('fetchSchemaMetadataRefresh обновляет метаданные выбранного узла', () => {
  fetchSchemaMetadataRefresh('node-1')
  expect(refreshMetadataOnNodeStream).toHaveBeenCalledWith('node-1')
})
