import { ApplicationStatusDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { renderHook } from '@testing-library/react'

import { useChangeRequestStatus } from './useChangeRequestStatus'

const mocks = vi.hoisted(() => ({
  config: null as Record<string, any> | null,
  fetch: vi.fn(),
  setQueryData: vi.fn(),
  invalidateQueries: vi.fn(),
  success: vi.fn(),
}))
vi.mock('@tanstack/react-query', () => ({
  useQueryClient: () => ({
    setQueryData: mocks.setQueryData,
    invalidateQueries: mocks.invalidateQueries,
  }),
  useMutation: (config: Record<string, any>) => {
    mocks.config = config
    return { mutate: config.mutationFn }
  },
}))
vi.mock('@v-uik/base', () => ({ notification: { success: mocks.success } }))
vi.mock('@/features/manage-script-requests/api', () => ({
  fetchResolveScriptApplication: (...args: unknown[]) => mocks.fetch(...args),
}))

it('useChangeRequestStatus отправляет статус и заменяет обновлённую заявку в кеше', () => {
  const { result } = renderHook(() => useChangeRequestStatus())
  result.current.mutate({
    application: { reasonId: 'REQ-1' } as never,
    targetStatus: ApplicationStatusDto.Approved,
  })
  expect(mocks.fetch).toHaveBeenCalledWith('REQ-1', {
    status: ApplicationStatusDto.Approved,
  })

  const updated = { reasonId: 'REQ-1', status: 'APPROVED' }
  mocks.config?.onSuccess(updated)
  const updater = mocks.setQueryData.mock.calls[0]?.[1]
  expect(updater([{ reasonId: 'REQ-1' }, { reasonId: 'REQ-2' }])).toEqual([
    updated,
    { reasonId: 'REQ-2' },
  ])
  expect(mocks.success).toHaveBeenCalled()
  expect(mocks.invalidateQueries).toHaveBeenCalledWith({ queryKey: ['scriptRequests'] })
})
