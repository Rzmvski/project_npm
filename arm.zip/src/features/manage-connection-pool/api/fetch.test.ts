import { PoolStateDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { fetchChangePoolState } from './fetch'

const changePoolStateStream = vi.hoisted(() => vi.fn(() => (async function* () {})()))
vi.mock('@/shared/api', () => ({
  connectionPoolManagementService: { changePoolStateStream },
}))

it('fetchChangePoolState обновляет пул выбранного узла', () => {
  fetchChangePoolState('node-1', PoolStateDto.Active)
  expect(changePoolStateStream).toHaveBeenCalledWith('node-1', PoolStateDto.Active)
})
