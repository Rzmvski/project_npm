import { ClusterStateDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { fetchChangeSemaphoreState } from './fetchChangeSemaphoreState'

const changeClusterStateStream = vi.hoisted(() => vi.fn(() => (async function* () {})()))
vi.mock('@/shared/api', () => ({
  clusterManagementService: { changeClusterStateStream },
}))

it('fetchChangeSemaphoreState объединяет status и дополнительные параметры', () => {
  fetchChangeSemaphoreState('cluster-1', ClusterStateDto.Active, {
    frozenNode: true,
  } as never)
  expect(changeClusterStateStream).toHaveBeenCalledWith('cluster-1', {
    status: ClusterStateDto.Active,
    frozenNode: true,
  })
})
