import { ClusterStateDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { renderHook } from '@testing-library/react'

import { useSemaphoreDetails } from './useSemaphoreDetails'

const mocks = vi.hoisted(() => ({
  query: null as Record<string, any> | null,
  streamSemaphores: vi.fn(),
  getShardsStream: vi.fn(),
}))
vi.mock('@tanstack/react-query', () => ({
  useQuery: (config: Record<string, any>) => {
    mocks.query = config
    return { data: config.initialData, isLoading: config.initialData === undefined }
  },
}))
vi.mock('@/shared/api', () => ({
  createPollingQueryPolicy: (options: Record<string, any>) => ({
    stopPredicate: options.stopPredicate,
  }),
  clusterManagementService: { getShardsStream: () => mocks.getShardsStream() },
}))
vi.mock('@/entities/semaphore', () => ({
  streamSemaphores: () => mocks.streamSemaphores(),
}))
vi.mock('@/entities/range', () => ({
  convertRange: (value: Record<string, any>) => ({
    start: value.startInclusive,
    end: value.endExclusive,
  }),
}))

it('useSemaphoreDetails объединяет семафоры с диапазонами бакетов их шард', async () => {
  mocks.streamSemaphores.mockImplementation(async function* () {
    yield { clusterKey: 'a', status: ClusterStateDto.Unrecognized }
    yield { clusterKey: 'b', status: ClusterStateDto.Active }
  })
  mocks.getShardsStream.mockImplementation(async function* () {
    yield {
      id: 1,
      bucketRanges: [
        { semaphoreClusterKey: 'a', startInclusive: 0, endExclusive: 10 },
        { semaphoreClusterKey: 'a', startInclusive: 10, endExclusive: 20 },
        { semaphoreClusterKey: 'b', startInclusive: 0, endExclusive: 20 },
      ],
    }
  })
  const { result } = renderHook(() => useSemaphoreDetails())

  expect(result.current.data).toEqual([])
  expect(result.current.isLoading).toBe(true)

  await expect(mocks.query?.queryFn({ signal: new AbortController().signal })).resolves.toEqual(
    [
      expect.objectContaining({
        clusterKey: 'a',
        status: ClusterStateDto.Unrecognized,
        ranges: [
          { start: 0, end: 10 },
          { start: 10, end: 20 },
        ],
      }),
      expect.objectContaining({
        clusterKey: 'b',
        status: ClusterStateDto.Active,
        ranges: [{ start: 0, end: 20 }],
      }),
    ],
  )
  expect(mocks.query?.stopPredicate([{ status: ClusterStateDto.Active }])).toBe(true)
  expect(mocks.query?.stopPredicate([{ status: ClusterStateDto.Creating }])).toBe(false)
})
