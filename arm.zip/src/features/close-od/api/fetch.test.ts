import { ProcessGroupDictionary } from '@/entities/process-group'

import { fetchCloseTradingDay } from './fetch'

const closeOd = vi.hoisted(() => vi.fn())
vi.mock('@/shared/api', () => ({ odService: { closeOd } }))

it('fetchCloseTradingDay передаёт дату и обязательный audit-контекст', () => {
  const date = new Date(2026, 7, 13, 23, 30)
  const apiDate = new Date('2026-08-13T00:00:00.000Z')
  fetchCloseTradingDay(date)
  expect(closeOd).toHaveBeenCalledWith({
    groupId: ProcessGroupDictionary.EOD_AND_OOD_BY_CONTRACT,
    operationDay: apiDate,
    auditInfo: { formName: 'RUN_CLOSING_OPERATION_DAY', date: apiDate },
  })
})
