import { type ProcessDtoDto } from '@sber-pprb-tkp/tcpf-support-admin-api'

import { ProcessGroupDictionary } from '@/entities/process-group'
import { odService } from '@/shared/api'
import { toApiLocalDate } from '@/shared/lib'

export const fetchCloseTradingDay = (od: Date): Promise<ProcessDtoDto> => {
  const operationDay = toApiLocalDate(od)

  return odService.closeOd({
    groupId: ProcessGroupDictionary.EOD_AND_OOD_BY_CONTRACT,
    operationDay,
    auditInfo: {
      formName: 'RUN_CLOSING_OPERATION_DAY',
      date: operationDay,
    },
  })
}
