import { fetchUpdateBucketRatio } from './fetch'

const mocks = vi.hoisted(() => ({
  updateNodes: vi.fn(() => (async function* () {})()),
}))
vi.mock('@/shared/api', () => ({
  clusterManagementService: { updateNodesOfShardByIdStream: mocks.updateNodes },
}))

it('fetchUpdateBucketRatio передаёт границу бакетов для указанной шарды', () => {
  fetchUpdateBucketRatio(42, [128, 256])
  expect(mocks.updateNodes).toHaveBeenCalledWith([42], {
    bucketBoundary: [128, 256],
  })
})
