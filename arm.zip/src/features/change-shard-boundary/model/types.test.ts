import { describe, it, expect } from 'vitest'

import type {
  NodeType,
  Loadable,
  ShardBoundaryValues,
} from '@/features/change-shard-boundary/model/types'

describe('types', () => {
  it('NodeType should be left | right', () => {
    const left: NodeType = 'left'
    const right: NodeType = 'right'
    expect(left).toBe('left')
    expect(right).toBe('right')
  })

  it('should create Loadable type', () => {
    const loadable: Loadable = {
      nodeKey: 'n1',
      type: 'left',
      load: 50,
    }
    expect(loadable.nodeKey).toBe('n1')
    expect(loadable.load).toBe(50)
  })

  it('should create ShardBoundaryValues', () => {
    const values: ShardBoundaryValues = {
      boundary: [100],
      nodes: [
        { nodeKey: 'n1', type: 'left', load: 50 },
        { nodeKey: 'n2', type: 'right', load: 50 },
      ],
    }
    expect(values.boundary).toEqual([100])
    expect(values.nodes).toHaveLength(2)
  })
})
