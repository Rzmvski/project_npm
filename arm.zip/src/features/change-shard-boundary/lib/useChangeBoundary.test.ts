import { act, renderHook } from '@testing-library/react'

import { type Loadable } from '@/features/change-shard-boundary/model'

import { calculateBoundary } from './calculateBoundary'
import { useChangeBoundary } from './useChangeBoundary'

const initialNodes: Loadable[] = [
  { nodeKey: 'node-a', type: 'left', load: 50 },
  { nodeKey: 'node-b', type: 'right', load: 50 },
]

describe('useChangeBoundary', () => {
  it('не сбрасывает несохранённые правки при фоновом обновлении nodes (например, от SSE)', () => {
    const { result, rerender } = renderHook(({ nodes }) => useChangeBoundary({ nodes }), {
      initialProps: { nodes: initialNodes },
    })

    act(() => {
      result.current.boundaryForm.setValue('boundary', [12345], { shouldDirty: true })
    })
    expect(result.current.boundaryForm.formState.isDirty).toBe(true)

    // Пользователь ещё не отправил и не отменил правку, а с сервера уже
    // пришёл новый снапшот нод (новая ссылка на массив) — форма должна
    // остаться нетронутой.
    const freshNodes: Loadable[] = [
      { nodeKey: 'node-a', type: 'left', load: 50 },
      { nodeKey: 'node-b', type: 'right', load: 50 },
    ]
    rerender({ nodes: freshNodes })

    expect(result.current.boundaryForm.getValues('boundary')).toEqual([12345])
    expect(result.current.boundaryForm.formState.isDirty).toBe(true)
  })

  it('подтягивает актуальные nodes и boundary, когда форма не изменена', () => {
    const { result, rerender } = renderHook(({ nodes }) => useChangeBoundary({ nodes }), {
      initialProps: { nodes: initialNodes },
    })

    const freshNodes: Loadable[] = [
      { nodeKey: 'node-a', type: 'left', load: 20 },
      { nodeKey: 'node-b', type: 'right', load: 80 },
    ]
    rerender({ nodes: freshNodes })

    expect(result.current.boundaryForm.getValues('nodes')).toEqual(freshNodes)
    expect(result.current.boundaryForm.getValues('boundary')).toEqual(
      calculateBoundary(freshNodes),
    )
  })
})
