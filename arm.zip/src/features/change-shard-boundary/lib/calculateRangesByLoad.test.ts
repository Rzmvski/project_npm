import { calculateRangesByLoad } from './calculateRangesByLoad'

describe('calculateRangesByLoad', () => {
  it('распределяет все бакеты между тремя нодами без пересечений', () => {
    const ranges = calculateRangesByLoad([
      { nodeKey: 'node-a', type: 'left', load: 33.33 },
      { nodeKey: 'node-b', type: 'right', load: 33.34 },
      { nodeKey: 'node-c', type: 'right', load: 33.33 },
    ])

    expect(ranges).toEqual({
      'node-a': [{ start: 0, end: 10921 }],
      'node-b': [{ start: 10922, end: 21845 }],
      'node-c': [{ start: 21846, end: 32767 }],
    })
  })

  it('не создаёт диапазон для ноды с нулевой нагрузкой', () => {
    expect(
      calculateRangesByLoad([
        { nodeKey: 'node-a', type: 'left', load: 100 },
        { nodeKey: 'node-b', type: 'right', load: 0 },
      ]),
    ).toEqual({
      'node-a': [{ start: 0, end: 32767 }],
      'node-b': [],
    })
  })
})
