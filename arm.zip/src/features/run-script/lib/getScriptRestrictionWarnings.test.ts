import { MonitoringStateDto, PoolStateDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { getScriptRestrictionWarnings } from './getScriptRestrictionWarnings'

describe('getScriptRestrictionWarnings', () => {
  it('создаёт предупреждения для выбранных нод с выключенными коннектами и DOWN-мониторингом', () => {
    expect(
      getScriptRestrictionWarnings(
        ['node-a', 'node-b'],
        [
          { key: 'node-a', status: PoolStateDto.Active },
          { key: 'node-b', status: PoolStateDto.Suspended },
        ],
        {
          'node-a': { state: MonitoringStateDto.Up },
          'node-b': { state: MonitoringStateDto.Down },
        },
      ),
    ).toEqual([
      {
        id: 'node-b:connection-pool-off',
        type: 'connection-pool-off',
        message: 'На ноде node-b выключен пул коннектов.',
      },
      {
        id: 'node-b:monitoring-down',
        type: 'monitoring-down',
        message: 'На ноде node-b мониторинг находится в состоянии DOWN.',
      },
    ])
  })

  it('не предупреждает о статусах невыбранных нод и неизвестных данных', () => {
    expect(
      getScriptRestrictionWarnings(
        ['node-a'],
        [{ key: 'node-b', status: PoolStateDto.Suspended }],
        { 'node-b': { state: MonitoringStateDto.Down } },
      ),
    ).toEqual([])
  })

  it('создаёт предупреждение для выбранной ноды с мониторингом ONLY_READ', () => {
    expect(
      getScriptRestrictionWarnings(
        ['node-a'],
        [{ key: 'node-a', status: PoolStateDto.Active }],
        { 'node-a': { state: MonitoringStateDto.OnlyRead } },
      ),
    ).toEqual([
      {
        id: 'node-a:monitoring-only-read',
        type: 'monitoring-only-read',
        message: 'Нода node-a работает в режиме ONLY_READ.',
      },
    ])
  })
})
