import { saveScriptApplication } from './fetchRun'

const save = vi.hoisted(() => vi.fn())
vi.mock('@/shared/api', () => ({ scriptService: { saveScriptApplication: save } }))

it('saveScriptApplication отправляет create DTO без полей серверного состояния', () => {
  const application = {
    reasonId: 'REQ1',
    jiraId: 'ARM-1',
    scriptBody: 'return true',
    restrictions: { enabled: false, allowedNodes: [] },
  }

  saveScriptApplication(application)

  expect(save).toHaveBeenCalledWith(application)
})
