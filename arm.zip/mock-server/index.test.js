import { afterAll, beforeAll, describe, expect, it } from 'vitest'

import {
  ACTIVE_CREATE_TASK_SESSION_ID,
  ACTIVE_TRANSFER_PROCESS_COUNT,
  ACTIVE_TRANSFER_SESSION_ID,
  BALANCING_SHARD_COUNT,
  createInitialState,
  SCRIPT_TEMPLATE_COUNT,
  TRANSFER_STATUS_COUNT,
} from './fixtures.js'
import {
  createDbMonitoringEmitter,
  createMockServer,
  getEndpointDelay,
  updateTimedProcess,
} from './index.js'

let mock

beforeAll(async () => {
  mock = await createMockServer({ port: 0, quiet: true, responseDelay: () => 0 })
})

afterAll(async () => {
  await mock.close()
})

describe('platform admin mock transport', () => {
  it('generates a substantial template catalog with category paths and bodies', () => {
    const state = createInitialState()
    const categoryPaths = state.templates.map(({ path }) =>
      path.split('/').slice(0, -1).join('/'),
    )

    expect(state.templates).toHaveLength(SCRIPT_TEMPLATE_COUNT)
    expect(state.templates.length).toBeGreaterThanOrEqual(30)
    expect(new Set(state.templates.map(({ hashcode }) => hashcode)).size).toBe(
      state.templates.length,
    )
    expect(new Set(categoryPaths).size).toBeGreaterThanOrEqual(8)
    expect(categoryPaths.every((path) => path && !path.endsWith('.groovy'))).toBe(true)
    expect(state.templates.every(({ hashcode }) => state.templateBodies[hashcode])).toBe(true)
  })

  it('provides 20 shards and five active processes for each balancing stage', () => {
    const state = createInitialState()
    const transferProcess = state.processes[ACTIVE_TRANSFER_SESSION_ID]
    const taskProcess = state.processes[ACTIVE_CREATE_TASK_SESSION_ID]

    expect(state.transferStatus).toHaveLength(TRANSFER_STATUS_COUNT)
    expect(state.transferStatus).toHaveLength(BALANCING_SHARD_COUNT)
    expect(new Set(state.nodes.map(({ shardId }) => shardId)).size).toBe(BALANCING_SHARD_COUNT)
    expect(state.nodes.every(({ key }) => /^[PSR]\d+$/.test(key))).toBe(true)
    expect(state.nodes.filter(({ shardId }) => shardId === 5).map(({ key }) => key)).toEqual([
      'P5',
      'S5',
      'R5',
    ])
    expect(state.nodes.filter(({ shardId }) => shardId === 10).map(({ key }) => key)).toEqual([
      'P10',
      'S10',
    ])
    expect(new Set(state.transferStatus.map(({ shard }) => shard.id)).size).toBe(
      TRANSFER_STATUS_COUNT,
    )
    expect(transferProcess.processGroupId).toBe(71)
    expect(transferProcess.done).toBe(false)
    expect(transferProcess.data.groupOfProcesses.statusGroup).toBe('RUNNING')
    expect(transferProcess.data.groupOfProcesses.fields).toHaveLength(
      ACTIVE_TRANSFER_PROCESS_COUNT,
    )
    expect(taskProcess.processGroupId).toBe(70)
    expect(taskProcess.done).toBe(false)
    expect(taskProcess.data.groupOfProcesses.statusGroup).toBe('RUNNING')
    expect(taskProcess.data.groupOfProcesses.fields).toHaveLength(ACTIVE_TRANSFER_PROCESS_COUNT)
  })

  it('starts with separate shards for a suspended pool and DOWN monitoring', () => {
    const state = createInitialState()
    const monitorings = createDbMonitoringEmitter(state)()
    const suspendedPool = state.pools.find(({ status }) => status === 'SUSPENDED')
    const downMonitoring = monitorings.find(
      ({ state: monitoringState }) => monitoringState === 'DOWN',
    )
    const nodeByKey = new Map(state.nodes.map((node) => [node.key, node]))
    const suspendedNodeLoad = state.shards
      .flatMap(({ bucketRanges }) => bucketRanges)
      .filter(({ nodeKey }) => nodeKey === suspendedPool.key)
      .reduce(
        (total, { startInclusive, endExclusive }) =>
          total + Math.max(0, endExclusive - startInclusive),
        0,
      )

    expect(suspendedPool).toMatchObject({ key: 'P2', status: 'SUSPENDED' })
    expect(suspendedNodeLoad).toBe(0)
    expect(monitorings.find(({ id }) => id === suspendedPool.key)?.state).toBe('UP')
    expect(nodeByKey.get(suspendedPool.key)?.shardId).toBe(2)

    expect(downMonitoring).toMatchObject({ id: 'P3', state: 'DOWN', replicaLag: null })
    expect(nodeByKey.get(downMonitoring.id)?.shardId).toBe(3)
    expect(state.pools.find(({ key }) => key === downMonitoring.id)?.status).toBe('ACTIVE')
  })

  it.each([ACTIVE_TRANSFER_SESSION_ID, ACTIVE_CREATE_TASK_SESSION_ID])(
    'updates and completes balancing process %s according to its timeline',
    (sessionId) => {
      const state = createInitialState()
      const timeline = state.processTimelines[sessionId]
      const midway = timeline.startedAtMs + timeline.durationMs / 2

      updateTimedProcess(state, sessionId, midway)
      const process = state.processes[sessionId]
      expect(process.done).toBe(false)
      expect(Number(process.data.groupOfProcesses.fields[0].recordsProcessed)).toBeGreaterThan(
        0,
      )

      updateTimedProcess(state, sessionId, timeline.startedAtMs + timeline.durationMs)
      expect(process.done).toBe(true)
      expect(process.data.groupOfProcesses.statusGroup).toBe('COMPLETED')
      expect(
        process.data.groupOfProcesses.fields.every(({ status }) => status === 'COMPLETED'),
      ).toBe(true)
    },
  )

  it('generates multi-range nodes without assigning a bucket to multiple nodes', () => {
    const state = createInitialState()
    const multiRangeShard = state.shards.find(({ id }) => id === 1)
    const threeNodeShard = state.shards.find(({ id }) => id === 5)
    const rangesByNode = Object.groupBy(multiRangeShard.bucketRanges, ({ nodeKey }) => nodeKey)

    expect(Object.values(rangesByNode).map((ranges) => ranges.length)).toEqual([2, 2])

    const sortedRanges = [...threeNodeShard.bucketRanges].sort(
      (left, right) => left.startInclusive - right.startInclusive,
    )
    expect(sortedRanges).toHaveLength(3)
    expect(sortedRanges[0].startInclusive).toBe(0)
    expect(sortedRanges.at(-1).endExclusive).toBe(32768)
    sortedRanges.slice(1).forEach((range, index) => {
      expect(range.startInclusive).toBe(sortedRanges[index].endExclusive)
      expect(range.nodeKey).not.toBe(sortedRanges[index].nodeKey)
    })
  })

  it('uses stable endpoint-specific delays while keeping health instant', () => {
    expect(getEndpointDelay('GET', '/health')).toBe(0)
    expect(
      getEndpointDelay('GET', '/invoke/support-admin/cluster-management-service/nodes'),
    ).toBe(360)
    expect(
      getEndpointDelay('GET', '/invoke/support-admin/cluster-management-service/shard'),
    ).toBe(520)
    expect(
      getEndpointDelay('GET', '/invoke/support-admin/cluster-management-service/pools'),
    ).toBe(280)
  })

  it('returns pools only as SSE', async () => {
    const state = createInitialState()
    const sseResponse = await fetch(
      `${mock.url}/invoke/support-admin/cluster-management-service/pools`,
    )
    const sse = await sseResponse.text()
    const jsonOnlyResponse = await fetch(
      `${mock.url}/invoke/support-admin/cluster-management-service/pools`,
      { headers: { Accept: 'application/json' } },
    )

    expect(sseResponse.headers.get('content-type')).toBe('text/event-stream;charset=UTF-8')
    expect(sse.match(/^data:/gm)).toHaveLength(state.pools.length)
    expect(jsonOnlyResponse.status).toBe(406)
  })

  it('preserves a saved script through the pending and approval workflow', async () => {
    const reasonId = `WORKFLOW-${Date.now()}`
    const scriptBody = "return 'saved body'"

    const createResponse = await fetch(
      `${mock.url}/invoke/support-admin/script-service/applications`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          reasonId,
          jiraId: 'ARM-WORKFLOW',
          scriptBody,
          restrictions: { enabled: true, allowedNodes: ['P1'] },
          status: 'APPROVED',
        }),
      },
    )
    expect(createResponse.status).toBe(201)

    const applications = await (
      await fetch(`${mock.url}/invoke/support-admin/script-service/applications`)
    ).json()
    expect(applications.find((application) => application.reasonId === reasonId)).toMatchObject(
      {
        status: 'PENDING',
        scriptBody,
      },
    )

    const savedScript = await (
      await fetch(
        `${mock.url}/invoke/support-admin/script-service/applications/${reasonId}/script`,
      )
    ).text()
    expect(savedScript).toBe(scriptBody)

    const approved = await (
      await fetch(
        `${mock.url}/invoke/support-admin/script-service/applications/${reasonId}/status`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status: 'APPROVED' }),
        },
      )
    ).json()
    expect(approved).toMatchObject({ reasonId, status: 'APPROVED' })
  })

  it('accepts the ShardUpdate wire name from the generated client', async () => {
    await fetch(`${mock.url}/invoke/support-admin/cluster-management-service/shard/1/nodes`, {
      method: 'PUT',
      headers: {
        Accept: 'text/event-stream',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ 'bucket-boundary': [10_000] }),
    })

    const state = await (await fetch(`${mock.url}/__mock/state`)).json()

    expect(state.shards[0].bucketRanges[0].endExclusive).toBe(10_000)
    expect(state.shards[0].bucketRanges[1].startInclusive).toBe(10_000)
  })

  it('accepts N - 1 bucket boundaries for a shard with three nodes', async () => {
    const response = await fetch(
      `${mock.url}/invoke/support-admin/cluster-management-service/shard/5/nodes`,
      {
        method: 'PUT',
        headers: {
          Accept: 'text/event-stream',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 'bucket-boundary': [9_000, 21_000] }),
      },
    )

    expect(response.ok).toBe(true)

    const state = await (await fetch(`${mock.url}/__mock/state`)).json()
    const ranges = state.shards
      .find(({ id }) => id === 5)
      .bucketRanges.sort((left, right) => left.startInclusive - right.startInclusive)

    expect(
      ranges.map(({ startInclusive, endExclusive }) => [startInclusive, endExclusive]),
    ).toEqual([
      [0, 9_000],
      [9_000, 21_000],
      [21_000, 32_768],
    ])
  })
})
