/**
 * API для загрузки конфигурации сервисов
 */

import axios from 'axios';
import { SERVICES_CONFIG_PATH } from '@/shared/config';

/**
 * Загрузка конфигурации сервисов из JSON файла
 * Возвращает массив ID сервисов, которые должны быть включены.
 */
export const fetchServiceConfig = async (): Promise<string[]> => {
  try {
    const response = await axios.get<{ services: { id: string }[] }>(SERVICES_CONFIG_PATH);
    
    // Возвращаем массив ID включенных сервисов
    return response.data.services.map(s => s.id);
  } catch (error) {
    // При ошибке просто пробрасываем ее, чтобы thunk мог ее обработать
    throw new Error('Failed to fetch services-config.json');
  }
};
