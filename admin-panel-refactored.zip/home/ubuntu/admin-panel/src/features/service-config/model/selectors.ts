/**
 * Селекторы для конфигурации сервисов
 */

import type { RootState } from '@/shared/types';

// Экспортируем только флаги enabled, которые являются "публичным API" этой фичи
export const selectServiceConfigData = (state: RootState) => state.serviceConfig.data;

export const selectServicesStatus = (state: RootState) => state.serviceConfig.status;

export const selectServicesError = (state: RootState) => state.serviceConfig.error;