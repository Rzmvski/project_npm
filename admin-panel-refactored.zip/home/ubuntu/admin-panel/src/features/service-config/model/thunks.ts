/**
 * Thunks для конфигурации сервисов
 */

import { createAsyncThunk } from '@reduxjs/toolkit';
import { fetchServiceConfig } from '../api/serviceConfigApi';
import type { RootState } from '@/shared/types';

/**
 * Загрузка конфигурации сервисов (массив ID включенных сервисов)
 */
export const fetchServiceConfig = createAsyncThunk<string[], void>(
  'serviceConfig/fetchConfig',
  async (_, { rejectWithValue }) => {
    try {
      // fetchServiceConfig теперь возвращает массив ID сервисов
      const serviceIds = await fetchServiceConfig();
      return serviceIds;
    } catch (error) {
      // Если конфиг не загрузился, мы не считаем это критической ошибкой,
      // так как slice по умолчанию включает все сервисы из Registry.
      // Просто возвращаем пустой массив, чтобы slice применил логику по умолчанию.
      console.error('Ошибка загрузки конфигурации сервисов:', error);
      return [];
    }
  }
);
