/**
 * Redux slice для конфигурации сервисов
 */

import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { LoadingStatus, Nullable } from '@/shared/types';
import { SERVICE_REGISTRY, Service } from '@/entities/service';

// Состояние будет хранить только флаги enabled для каждого сервиса из Registry
interface ServiceConfigState {
  data: Nullable<Record<string, boolean>>; // Флаги enabled: { 'service-id': true/false }
  status: LoadingStatus;
  error: Nullable<string>;
}

// Инициализируем состояние флагами enabled из Registry
const initialEnabledState = SERVICE_REGISTRY.reduce((acc, service) => {
  acc[service.id] = service.enabled;
  return acc;
}, {} as Record<string, boolean>);

const initialState: ServiceConfigState = {
  data: initialEnabledState,
  status: LoadingStatus.IDLE,
  error: null,
};

export const serviceConfigSlice = createSlice({
  name: 'serviceConfig',
  initialState,
  reducers: {
    // Применяем конфигурацию из Registry (массив ID включенных сервисов)
    applyRegistryConfig: (state, action: PayloadAction<string[]>) => {
      const enabledServiceIds = action.payload;
      
      // По умолчанию все сервисы из Registry выключаются
      const newEnabledState = SERVICE_REGISTRY.reduce((acc, service) => {
        acc[service.id] = false;
        return acc;
      }, {} as Record<string, boolean>);

      // Включаются только те, чьи ID есть в массиве
      enabledServiceIds.forEach(id => {
        if (newEnabledState.hasOwnProperty(id)) {
          newEnabledState[id] = true;
        }
      });

      state.data = newEnabledState;
    },
  },
});

export const { applyRegistryConfig } = serviceConfigSlice.actions;

  extraReducers: (builder) => {
    builder
      .addCase(fetchServiceConfig.pending, (state) => {
        state.status = LoadingStatus.PENDING;
        state.error = null;
      })
      .addCase(fetchServiceConfig.fulfilled, (state, action: PayloadAction<string[]>) => {
        state.status = LoadingStatus.SUCCEEDED;
        
        // Если конфиг пришел (action.payload - массив ID), применяем его
        if (action.payload.length > 0) {
          serviceConfigSlice.caseReducers.applyRegistryConfig(state, action);
        } else {
          // Если конфиг не пришел (или пустой), ничего не выключаем (остается initialEnabledState)
          state.data = initialEnabledState;
        }
      })
      .addCase(fetchServiceConfig.rejected, (state, action) => {
        state.status = LoadingStatus.FAILED;
        state.error = action.error.message || 'Failed to fetch service config';
        // При ошибке ничего не выключаем (остается initialEnabledState)
        state.data = initialEnabledState;
      });
  },
});

export const { applyRegistryConfig } = serviceConfigSlice.actions;

export default serviceConfigSlice.reducer;
