/**
 * Комбинированный селектор для получения финального списка сервисов.
 * Использует reselect для мемоизации и предотвращения лишних перерендеров.
 */

import { createSelector } from '@reduxjs/toolkit';
import { SERVICE_REGISTRY } from '@/entities/service';
import { selectUserPermissions } from '@/entities/user';
import { selectServiceConfigData } from '@/features/service-config';
import { hasPermission } from '@/shared/lib/permissions';
import { ServiceConfig } from '@/shared/types';

// 1. Базовый селектор для Service Registry (константа, не меняется)
const selectServiceRegistry = () => SERVICE_REGISTRY;

// 2. Базовый селектор для флагов enabled (из service-config slice)
const selectEnabledFlags = selectServiceConfigData;

// 3. Базовый селектор для пермишенов пользователя (из user slice)
const selectPermissions = selectUserPermissions;

/**
 * Комбинированный селектор:
 * 1. Берет полный список сервисов (Registry).
 * 2. Объединяет его с флагами enabled (из service-config).
 * 3. Фильтрует по пермишенам пользователя.
 * 
 * Возвращает финальный список сервисов для отображения.
 */
export const selectVisibleServices = createSelector(
  [selectServiceRegistry, selectEnabledFlags, selectPermissions],
  (registry, enabledFlags, permissions) => {
    if (!enabledFlags) {
      // Если конфиг еще не загружен, используем enabled по умолчанию из Registry
      return registry.filter(service => 
        service.enabled && hasPermission(permissions, service.permission)
      );
    }

    // 1. Фильтрация по enabled (настройка через JSON)
    const configuredServices = registry.filter(service => {
      // Если в enabledFlags есть ID сервиса и его значение true, то сервис включен
      return enabledFlags[service.id] === true;
    });

    // 2. Фильтрация по пермишенам пользователя
    const visibleServices = configuredServices.filter(service => {
      return hasPermission(permissions, service.permission);
    });

    // 3. Сортировка по order
    return visibleServices.sort((a, b) => a.order - b.order);
  }
);

/**
 * Селектор для получения списка роутов (для роутинга)
 */
export const selectServiceRoutes = createSelector(
  selectVisibleServices,
  (services) => services.map(service => service.route)
);
