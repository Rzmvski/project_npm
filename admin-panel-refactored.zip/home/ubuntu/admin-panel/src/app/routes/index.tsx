/**
 * Конфигурация роутинга приложения
 */

import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAppSelector } from '../store/hooks';
import { selectServiceRoutes } from '@/features/permission-check';
import { ROUTES } from '@/shared/config';

// Pages
import { MainPage } from '@/pages/main';
import { ForbiddenPage } from '@/pages/forbidden';
import { NotFoundPage } from '@/pages/not-found';
import { ServicePage } from '@/pages/process-groups'; // Используем ProcessGroupsPage как шаблон ServicePage


// Features
import { RoleGuard } from '@/features/role-guard';

// Layout
import { AppLayout } from '../layouts/AppLayout';

export const AppRoutes: React.FC = () => {
  const serviceRoutes = useAppSelector(selectServiceRoutes);

  // Используем ServicePage (шаблон ProcessGroupsPage) для всех динамических роутов
  const dynamicRoutes = serviceRoutes.map((route) => (
    <Route 
      key={route} 
      path={route} 
      element={<ServicePage serviceId={route.replace('/', '')} />} 
    />
  ));

  return (
    <Routes>
      {/* Публичный роут для страницы Forbidden */}
      <Route path={ROUTES.FORBIDDEN} element={<ForbiddenPage />} />

      {/* Защищенные роуты (требуется роль ADMIN) */}
      <Route
        path="/"
        element={
          <RoleGuard>
            <AppLayout />
          </RoleGuard>
        }
      >
        <Route index element={<MainPage />} />
        
        {/* Динамические роуты для сервисов */}
        {dynamicRoutes}

        <Route path={ROUTES.NOT_FOUND} element={<NotFoundPage />} />
        <Route path="*" element={<Navigate to={ROUTES.NOT_FOUND} replace />} />
      </Route>
    </Routes>
  );
};
