# Validation runbook

## Минимум по изменению

| Изменение     | Проверки                                                  |
| ------------- | --------------------------------------------------------- |
| Docs          | `npm run format:check -- docs README.md`, проверка ссылок |
| Pure TS       | typecheck, focused test, focused ESLint                   |
| React         | typecheck, focused RTL, focused ESLint                    |
| SCSS          | Stylelint и визуальная проверка                           |
| API/mock      | `node --check`, запущенный UI и пользовательский сценарий |
| Access        | tests roles/permissions, guard и route                    |
| Cross-cutting | `npm run check`                                           |

## Mock smoke

```bash
npm run start:api
curl http://127.0.0.1:3001/health
curl http://127.0.0.1:3001/invoke/support-admin/user-service/permissions
curl -X POST http://127.0.0.1:3001/__mock/reset
```

Проверяются status, exact DTO shape и изменение state после mutation. Для управления узлами дополнительно проверяется инвариант: нагрузка пары узлов каждой шарды в сумме равна 100% до и после изменения границы.

## Отчёт

Указать выполненные команды и их результат, невыполненные проверки с причиной, известные baseline failures отдельно от regressions и предупреждения сборки отдельно от errors. Формулировка «всё прошло» допустима только после фактического полного run.
