# VUIK integration runbook

VUIK напрямую используется для button, input, select, checkbox, tag, progress, modal, notification, tabs и date controls. Перед созданием своего примитива проверить exports/types `@v-uik/base` и существующее использование.

Shared composition оправдана, когда владеет повторяемым layout, RHF integration, table coordination, application-specific empty/error behavior или modal workflow. Она не должна просто менять имя VUIK props.

При миграции legacy UI:

1. Сохранить пользовательское поведение и accessibility name.
2. Заменить примитив на VUIK с semantic props.
3. Вынести только окружающий layout в SCSS Module.
4. Удалить локальный CSS, имитирующий состояния VUIK.
5. Добавить behavior test и визуально проверить loading/error/long text.

Не смешивать миграцию UI-библиотеки с изменением бизнес-правил без необходимости.
