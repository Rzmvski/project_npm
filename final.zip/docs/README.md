# Карта документации

Документы ниже описывают текущий TCPF Support Admin UI. Ссылки и правила, перенесённые из другого проекта, удалены или адаптированы к фактическому коду.

| Документ                                     | Когда читать                              |
| -------------------------------------------- | ----------------------------------------- |
| [`../README.md`](../README.md)               | Запуск и обзор продукта                   |
| [`architecture.md`](architecture.md)         | Слои, boot, маршруты, состояние и API     |
| [`api-contract.md`](api-contract.md)         | Изменение endpoint, DTO или SDK           |
| [`mock-server.md`](mock-server.md)           | Express mock API, сценарии и отладка      |
| [`access-control.md`](access-control.md)     | Роли, permissions и guards                |
| [`design-system.md`](design-system.md)       | VUIK, токены и SCSS Modules               |
| [`refactoring-rhf.md`](refactoring-rhf.md)   | Формы React Hook Form + Zod               |
| [`testing.md`](testing.md)                   | Уровни тестов и команды                   |
| [`code-quality.md`](code-quality.md)         | Инструменты и обязательные правила        |
| [`validation.md`](validation.md)             | Проверка изменений перед передачей        |
| [`vuik-refactoring.md`](vuik-refactoring.md) | Миграция и расширение UI-компонентов      |
| [`audit.md`](audit.md)                       | Результат аудита и очередь исправлений    |
| [`ui-ux-audit.md`](ui-ux-audit.md)           | UI/UX-аудит всех страниц и вкладок        |
| [`gigacode.md`](gigacode.md)                 | Правила работы автоматизированных агентов |

## Источники истины

- REST-контракты: `apis/openapi.yml` и `apis/openapi2.yml`.
- Версии зависимостей и команды: корневой `package.json`.
- Маршруты: `src/shared/config/routes.ts` и `src/app/routes/AppRoutes.tsx`.
- Права: `src/shared/model/permissionType.ts` и `src/entities/service/model/registry.ts`.
- Тема: `src/shared/styles/tokens.scss` и `src/app/providers/AppThemeProvider.tsx`.

Документация не должна утверждать наличие скрипта, файла или проверки, которых нет в репозитории.
