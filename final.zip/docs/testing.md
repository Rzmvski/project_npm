# Testing guide

Проект использует Vitest, React Testing Library, `user-event` и jsdom. Тестовые
файлы выполняются в изолированных процессах, чтобы моки не протекали между
файлами, а память освобождалась после каждой группы.

| Уровень      | Назначение                               |
| ------------ | ---------------------------------------- |
| Unit         | schema, selector, formatter, mapper      |
| Component    | наблюдаемое UI-поведение                 |
| Store/query  | thunk, cache key, polling и invalidation |
| Route/access | guard, redirect, lazy page               |
| API contract | SDK boundary, request и response shape   |

Тест проверяет результат для пользователя, не VUIK markup или CSS class. Interaction выполняется через `user-event`; async rendering — `findBy*`/`waitFor`, без sleep. Мокировать следует API boundary, сохраняя реальными форму, query и store настолько, насколько это разумно.

Тест размещается рядом с production-модулем: `Component.test.tsx` рядом с
`Component.tsx`, без отдельной папки `__tests__`. Для многошагового UI рядом
создаётся предметный test model: `Component.test-model.tsx`. Он предоставляет
пользовательские действия (`submitRequest`, `selectNode`, `openRanges`), а не
оборачивает все DOM API подряд. Простым компонентам без сценария test model не
нужен.

Coverage собирается по всем production-файлам, в том числе по тем, которые не
импортированы тестами. Обязательные пороги: 80% lines/functions/statements и
60% branches. Полный coverage-прогон должен завершаться ошибкой, если хотя бы
один из этих показателей ниже порога.

```bash
npm test
npx vitest run path/to/file.test.tsx
npx vitest run -t "case name"
npm run test:coverage
```

Express mock не имеет собственных тестов: его контракт проверяется сквозным пользовательским сценарием в запущенном приложении. Unit/component-тесты относятся к фронтенду и остаются частью `npm test`.
