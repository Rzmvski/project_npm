# Form architecture guide

Формы создания transfer task, запуска/очистки процессов, скриптов, ревизии, семафоров, фич и traffic restriction используют React Hook Form и Zod.

## Правила

- Schema владеет пользовательской валидацией; `zodResolver` соединяет её с RHF.
- DTO и form values разделяются, если отличаются nullability, даты, enum или вложенность.
- Form hook задаёт schema, defaults и submit mapping; UI-группа только рендерит поля.
- VUIK control с нестандартным value contract подключается через `Controller`.
- Dynamic arrays используют `useFieldArray`, не параллельный local state.
- Defaults не меняются после mount без `reset`.
- Submit защищён от дубля, сохраняет введённые значения при ошибке и показывает backend message.
- Mutation инвалидирует только связанные query keys.

При добавлении поля обновляются type, schema, defaults, API→form, form→request и тесты. Для conditional field тестируются обе ветви и очистка скрытого значения.
