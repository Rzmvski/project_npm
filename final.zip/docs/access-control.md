# Access control guide

## Модель

При старте `userQueryOptions` через TanStack Query параллельно загружает:

- `GET /invoke/support-admin/user-service/roles`;
- `GET /invoke/support-admin/user-service/permissions`.

Результат хранится в query cache `entities/user`. `AccessGuard` ждёт загрузку и проверяет роль и полный набор permissions. Главная страница требует роль, содержащую `ADMIN`; карточки и сервисные маршруты используют permissions из `serviceRegistry`.

## Правила

- Идентификаторы прав добавляются в `src/shared/model/permissionType.ts`.
- Связь сервиса с правами задаётся один раз в `serviceRegistry`.
- Видимость действия и защита маршрута должны использовать одну permission-модель.
- Проверка роли должна быть точной; substring-проверка допустима только как явно задокументированная совместимость со старыми названиями ролей.
- Ошибка загрузки прав не должна выглядеть как подтверждённый запрет без диагностики.
- Для нового сервиса обязательны тест guard, конфигурация mock permissions и сценарий forbidden.

В mock-профиле пользователь имеет роли `ADMIN`, `TKP_SUPPORT` и полный текущий набор прав, чтобы все экраны были доступны.
