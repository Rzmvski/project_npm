# Architecture guide

## Слои

```text
app → pages → widgets → features → entities → shared
```

| Слой       | Ответственность                                      |
| ---------- | ---------------------------------------------------- |
| `app`      | boot, providers, router, layouts                     |
| `pages`    | композиция экрана маршрута                           |
| `widgets`  | крупные самостоятельные области экрана               |
| `features` | пользовательские действия и mutations                |
| `entities` | доменные данные, API, query hooks и компактный UI    |
| `shared`   | инфраструктура, общие UI и утилиты без бизнес-знаний |

Зависимости направляются вправо. Между slices одного слоя нет прямых deep imports; внешний код использует `index.ts`. Каталог `src/shared/deprecated` удалён и не должен создаваться повторно.

Steiger проверяет структуру командой `npm run lint:architecture`. ESLint дополнительно контролирует допустимые направления FSD-зависимостей через `eslint-plugin-boundaries`.

В `steiger.config.ts` отключены только эвристические правила размера (`excessive-slicing`, `insignificant-slice`): число ссылок само по себе не определяет корректность доменной границы. Запрет зависимостей вверх, sibling cross-imports и обход public API остаются обязательными.

## Запуск приложения

`AppProviders` монтирует HashRouter, TanStack Query, VUIK theme и date adapter. `AppRoutes` использует React Router 6 и ленивую загрузку сервисных страниц. URL имеют вид `/#/cluster-management`.

Главный layout загружает роли и permissions. Dashboard показывает сервисы из `serviceRegistry`, отфильтрованные `/config/services` и доступом пользователя.

## Маршруты

| Путь                   | Сервис                     |
| ---------------------- | -------------------------- |
| `/`                    | Dashboard                  |
| `/close-trading-day`   | Закрытие операционного дня |
| `/start-process-group` | Запуск группы процессов    |
| `/index-management`    | Управление индексами       |
| `/shard-info`          | Поиск шарда                |
| `/script-runner`       | Исправляющие скрипты       |
| `/node-balancing`      | Перенос клиентов           |
| `/feature-toggling`    | Управление фичами          |
| `/cluster-management`  | Ноды и семафоры            |
| `/revise-replication`  | Сверка репликации          |
| `/geo-balancing`       | Ограничения трафика        |

## Состояние и данные

- TanStack Query владеет server state, polling, cache и invalidation.
- React Hook Form владеет состоянием формы; Zod — валидацией.
- React `useState`/`useReducer` владеет локальным UI-состоянием, которое не является серверным или формовым.
- URL хранит состояние навигации и воспроизводимые параметры экрана.

Entity определяет API-функцию и query key. Feature определяет mutation и инвалидирует только затронутые entity keys. Query key должен включать все параметры, меняющие серверный ответ; объекты фильтра сначала нормализуются.

## API

Экземпляры сгенерированных клиентов создаются в `src/shared/api/services.ts`. Конфигурации `/tkp/` и `/platform/` находятся в `src/shared/config/http.ts`. UI не вызывает SDK напрямую.

При добавлении slice: выбрать нижний владеющий слой, создать только нужные segments, экспортировать public API, не создавать sibling dependency и выполнить пропорциональную проверку. Redux-store и Redux-slices в проект не возвращаются.
