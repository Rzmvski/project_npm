# API contract guide

## Контракты

Фронтенд работает с двумя API:

| Префикс     | OpenAPI                     | npm-клиент                               | Dev backend      |
| ----------- | --------------------------- | ---------------------------------------- | ---------------- |
| `/tkp`      | `apis/openapi.yml` (15.0.0) | `@sber-pprb-tkp/tcpf-support-admin-api`  | `127.0.0.1:8092` |
| `/platform` | `apis/openapi2.yml` (2.1)   | `@sber-pprb-tkp/tcpf-platform-admin-api` | `127.0.0.1:8091` |

В development префикс удаляется proxy в `vite.config.ts`. В production `platformRequestConfiguration` дополнительно использует выбранный контур.

## Правила изменения

1. Сначала обновить соответствующий OpenAPI-файл.
2. Обновить сгенерированный клиент командой `npm run update-api` или согласованной фиксированной версией.
3. Вызывать SDK только из `api`-сегмента сущности/фичи; конфигурацию брать из `shared/config`.
4. Не импортировать внутренние `@sber-*/src/*`: публичные типы экспортируются корнем пакета.
5. Обновить Express mock и проверить пользовательский сценарий через запущенный UI.
6. Проверить сериализацию query/body и коды ответов, затем затронутый UI-сценарий.

## SSE

Операции, помеченные в контракте `x-sse: true`, генерируются в классы `*ApiSse` (`ClusterManagementServiceApiSse`, `ConnectionPoolManagementServiceApiSse`, `GeoBalancingManagementServiceApiSse`, `MonitoringManagementServiceApiSse`, `MetadataManagementServiceApiSse`). Класс `*ApiSse` наследует обычные методы без изменений и добавляет `<operationId>Stream()` — `AsyncGenerator` поверх `fetch` с заголовком `Accept: text/event-stream`. Путь у потока тот же, что у обычной операции.

Правила:

1. SSE подключается только к тем сервисам, у которых в библиотеке есть класс `*ApiSse` с методами `*Stream()`. `EventSource` и ручная сборка URL не используются.
2. Экземпляры сервисов, чьи потоки используются в UI, создаются от `*ApiSse` в `src/shared/api/services.ts`: Cluster, ConnectionPool, GeoBalancing, Monitoring. `MetadataManagementService` остаётся на базовом классе — его поток `refreshMetadataOnNodeStream` пока не нужен.
3. Поток оборачивается в фабрику `(signal) => service.xxxStream({ signal })` в `api`-сегменте сущности (`streamNodeInfo`, `streamSemaphores`, `streamRestrictions`, …). Там же выполняется та же нормализация DTO, что и в соответствующем `fetch*`, чтобы поток и запрос писали в кэш одну форму данных.
4. Подписка живёт в хуке через `useSseQuerySync` (`src/shared/lib/react`): первичную загрузку по-прежнему делает `useQuery`, поток только обновляет его кэш по `queryKey`. Отписка — через `AbortSignal`.
5. Хуки принимают `subscribeToUpdates` (по умолчанию `false`), поток включается на экранах, где нужно живое состояние. Каждая включённая подписка — отдельное HTTP-соединение, поэтому на одном экране их держат по минимуму.
6. Переподключение делаем сами: `subscribeToSse` принимает `retryDelay` (в `useSse` по умолчанию 3000 мс). `fetch`-поток, в отличие от `EventSource`, после обрыва или таймаута прокси не восстанавливается.
7. Middleware в `shared/config/http.ts` отменяет клон тела для `text/event-stream`: иначе непрочитанная ветка `tee` буферизуется всё время жизни потока.

## Ошибки

Middleware в `src/shared/config/http.ts` превращает неуспешные ответы в `HttpError` и показывает VUIK notification. Mock возвращает единый JSON-формат ошибки: `timestamp`, `status`, `message`, `path`.

Fallback между новыми и deprecated методами допустим только для ошибок отсутствующего endpoint (`404`/`405`), а не для сетевых ошибок или `5xx`: иначе реальный сбой маскируется переключением API.
