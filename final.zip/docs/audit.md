# Аудит проекта

Дата актуализации: 12 августа 2026.

## Выполнено

- Добавлен stateful Express mock для обоих API; Vite и API запускаются одной командой `npm run dev` через `concurrently`.
- Express, линтеры, Prettier, Husky, lint-staged и Commitlint подключены через npm; приватные API остаются локальными `file:` dependencies.
- Удалён `src/shared/deprecated`: рабочие сценарии поиска шарда, CSV-отчёта, форматирования дат, session login, audit code и error fallback перенесены во владельческие FSD-slices.
- Redux удалён полностью: нет store/provider, Redux hooks, reducers, thunks, типов и npm-зависимостей.
- Server state и polling переведены на TanStack Query; формы используют React Hook Form + Zod; локальное состояние запуска групп процессов хранится в React.
- Убраны вызовы hooks из callback-функций таблиц в управлении индексами, истории ОД и запуске групп процессов.
- Поиск шарда реализован как `features/find-shard-info` с публичным API, RHF-формой и Zod-валидацией.
- Mock управления индексами моделирует `CREATING → ON_LOADING → ACTIVE`; деактивация завершается сразу в `INACTIVE`. Успешное уведомление отложено до финального статуса, ошибка показывается сразу.
- Для каждой шарды mock содержит два узла. Изменение границы сохраняет комплементарные диапазоны, поэтому сумма нагрузки внутри шарды всегда равна 100%.
- Production-сборка и полный ESLint проходят.

## Открытые проблемы

### P0 — проверки

1. TypeScript всё ещё сообщает существующие ошибки совместимости `react-ace`/React types и ошибки в незавершённых feature-моделях. Ошибки удалённых Redux/deprecated-модулей устранены.
2. Полный Vitest run ранее достигал лимита heap около 2 GB; после архитектурной миграции его необходимо стабилизировать отдельной задачей.
3. Stylelint baseline содержит legacy-нарушения SCSS и требует отдельного форматирующего прохода.

### P1 — FSD

- Steiger после миграции и настройки осмысленных структурных правил: 57 errors и 13 warnings против предыдущих 132/25. `deprecated` и Redux больше не участвуют в отчёте; эвристические `excessive-slicing` и `insignificant-slice` отключены как не определяющие корректность доменной границы.
- Оставшиеся содержательные нарушения — sibling imports между entities/features и обход public API. Рекомендательные правила также отмечают большое число мелких slices (`insignificant-slice`, `excessive-slicing`).
- Query keys пока объявляются локально; для связанных сценариев стоит ввести фабрики ключей в public API entity.
- `ApiProxy` всё ещё переключает клиент на fallback после любой ошибки; переход должен выполняться только при `404/405`.

### P2 — зависимости и эксплуатация

- React/ReactDOM имеют major 19, а `@types/react*` — major 18; это основная причина ошибок типов `react-ace`.
- Production sourcemaps включены без отдельного решения по публикации исходников.
- Чанки `mode-sql` и часть vendor bundle превышают 500 kB; нужен bundle-анализ и дополнительный code splitting.
- `.env` содержит `VITE_API_HOST`, но Vite config его не использует.
- `GEO_BALANCING` пока имеет пустой список permissions.

## Следующий порядок работ

1. Выровнять React/type dependency matrix и вернуть зелёный typecheck.
2. Исправить реальные Steiger forbidden-import/public-api нарушения, отдельно согласовав укрупнение slices для рекомендательных правил.
3. Стабилизировать полный Vitest run и обновить тесты после перехода на Query/RHF.
4. Исправить политику fallback в `ApiProxy` и точное сравнение ролей в `AccessGuard`.
5. Выполнить SCSS cleanup и bundle splitting отдельными изменениями.
