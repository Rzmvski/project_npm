const NOW = '2026-08-12T09:30:00.000Z'

export const enabledServices = [
  'closeTradingDay',
  'startProcessGroup',
  'indexManagement',
  'shardInfo',
  'scriptRunner',
  'nodeBalancing',
  'featureToggling',
  'clusterManagement',
  'reviseReplication',
  'geoBalancing',
]

export const permissions = [
  'dictionariesService_getDictionary',
  'closingOperationDayService_getCurrentOperationDay',
  'closingOperationDayService_startClosingOperationDay',
  'closingOperationDayService_getResultOfClosingOperationDay',
  'closingOperationDayService_getFailedContractsWithSteps',
  'closingOperationDayService_getHistory',
  'closingOperationDayService_getHistoryDetailed',
  'closingOperationDayService_getOperationDays',
  'processManagementService_startProcess',
  'processManagementService_getHistory',
  'userService_getPermissions',
  'zoneIndexService_getClusterInfo',
  'shardInfoService_getInfo',
  'scriptService_createScriptRequest',
  'clientTransferService_transfer',
  'featureTogglingService_getInfo',
  'clusterManagementService_getShard',
  'revisionService_runRevision',
]

export const processFields = [
  {
    name: 'Подготовка операционного дня',
    code: 'PREPARE_OD',
    status: 'COMPLETED',
    startTime: '2026-08-12T09:10:00.000Z',
    endTime: '2026-08-12T09:12:00.000Z',
    recordsWillBeProcessed: '1250',
    totalRecords: '1250',
    recordsProcessed: '1250',
    processedCorrectly: '1248',
    processedWithError: '2',
    loading: '1',
    numberMinutesAtWork: '2',
    lastUpdate: '2026-08-12T09:12:00.000Z',
    description: 'Подготовка данных завершена',
    stepInGroup: '1',
    nodeCode: 'tkp-node-1',
  },
  {
    name: 'Расчёт итогов',
    code: 'CALCULATE_TOTALS',
    status: 'RUNNING',
    startTime: '2026-08-12T09:12:00.000Z',
    recordsWillBeProcessed: '850',
    totalRecords: '850',
    recordsProcessed: '510',
    processedCorrectly: '508',
    processedWithError: '2',
    loading: '0.6',
    numberMinutesAtWork: '18',
    lastUpdate: NOW,
    description: 'Выполняется расчёт итоговых записей',
    stepInGroup: '2',
    nodeCode: 'tkp-node-2',
  },
]

const makeRevision = (id, shardId, status = 'NOT_MATCHED') => ({
  id,
  shardId: String(shardId),
  part: 100,
  tablesTotal: 3,
  status,
  job: 'REVISE',
  jobStatus: status === 'WORKING' ? 'RUNNING' : 'COMPLETED',
  rowsTotal: 15000,
  rowsDiff: status === 'MATCHED' ? 0 : 12,
  rowsDiffSaved: 12,
  tasksProcessed: 3,
  tasksTotal: 3,
  jobRowsProcessed: 15000,
  jobRowsTotal: 15000,
  rowsSyncLeft: 7,
  rowsSyncRight: 5,
  cursorFinished: true,
  created: '2026-08-12T08:00:00.000Z',
  updated: NOW,
})

// A larger, spread-out dataset for the "История" tab (revision history),
// which pages through results via useInfiniteScroll + useVirtualization.
// The 2-row `revisions` fixture above is too small to exercise scrolling,
// pagination, or the sticky header while more pages load.
const REVISION_HISTORY_STATUSES = [
  'MATCHED',
  'NOT_MATCHED',
  'MATCHED',
  'FAILED',
  'MATCHED',
  'NOT_MATCHED',
  'ABORTED',
  'MATCHED',
]
const REVISION_HISTORY_SHARD_IDS = [1, 2, 3, 4]

const makeRevisionHistoryList = (count = 140) => {
  const startId = 200
  const nowMs = new Date(NOW).getTime()

  return Array.from({ length: count }, (_, i) => {
    const shardId = REVISION_HISTORY_SHARD_IDS[i % REVISION_HISTORY_SHARD_IDS.length]
    const status = REVISION_HISTORY_STATUSES[i % REVISION_HISTORY_STATUSES.length]
    const daysAgo = Math.floor(i / REVISION_HISTORY_SHARD_IDS.length)
    const updated = new Date(
      nowMs - daysAgo * 24 * 60 * 60 * 1000 - (i % 7) * 60 * 60 * 1000,
    ).toISOString()
    const created = new Date(new Date(updated).getTime() - 4 * 60 * 1000).toISOString()

    return {
      ...makeRevision(startId + i, shardId, status),
      created,
      updated,
    }
  })
}

// У ноды есть нагрузка, если ей назначен непустой диапазон бакетов.
const nodeHasLoad = (node) =>
  (node.semaphores ?? []).some(
    (semaphore) => (semaphore.endExclusive ?? 0) > (semaphore.startInclusive ?? 0),
  )

// Инвариант стартового состояния: у нагруженной ноды коннекты не могут
// быть выключены (SUSPENDED) — иначе шард окажется недоступен.
const withValidConnectionPool = (node) =>
  nodeHasLoad(node) && node.connectionPool === 'SUSPENDED'
    ? { ...node, connectionPool: 'ACTIVE' }
    : node

// Начиная с platform-api 2.1 NodeDto/getNodes(), ShardDto/getShards() и
// semaphoreInfo() — три отдельных, более "плоских" эндпоинта: нода больше не
// содержит вложенные semaphores/connectionPool. Ниже описываем стартовые
// данные в прежнем "богатом" виде (в одном месте на ноду), а фактические
// коллекции state.nodes/state.pools/state.shards/state.semaphores выводим
// из него — так фикстуры остаются читаемыми, а форма ответов соответствует
// новому контракту.
const buildRawNodes = () => [
  {
    shardId: 1,
    nodeKey: 'tkp-node-1',
    dcKey: 'MSK',
    connectionPool: 'ACTIVE',
    semaphores: [
      {
        nodeKey: 'tkp-node-1',
        clusterKey: 'cluster-main',
        startInclusive: 0,
        endExclusive: 16384,
        status: 'ACTIVE',
        recordsAmount: 245000,
        frozenNode: false,
        frozenSemaphoreCluster: false,
        dcKey: 'MSK',
        sameDc: true,
      },
    ],
  },
  {
    shardId: 1,
    nodeKey: 'tkp-node-1-replica',
    dcKey: 'SPB',
    connectionPool: 'ACTIVE',
    semaphores: [
      {
        nodeKey: 'tkp-node-1-replica',
        clusterKey: 'cluster-main',
        startInclusive: 16384,
        endExclusive: 32768,
        status: 'ACTIVE',
        recordsAmount: 245000,
        frozenNode: false,
        frozenSemaphoreCluster: false,
        dcKey: 'SPB',
        sameDc: false,
      },
    ],
  },
  {
    shardId: 2,
    nodeKey: 'tkp-node-2',
    dcKey: 'SPB',
    // У ноды есть нагрузка (назначен диапазон бакетов), поэтому коннекты
    // не могут быть выключены.
    connectionPool: 'ACTIVE',
    semaphores: [
      {
        nodeKey: 'tkp-node-2',
        clusterKey: 'cluster-reserve',
        startInclusive: 0,
        endExclusive: 16384,
        status: 'INACTIVE',
        recordsAmount: 182000,
        frozenNode: false,
        frozenSemaphoreCluster: false,
        dcKey: 'SPB',
        sameDc: true,
      },
    ],
  },
  {
    shardId: 2,
    nodeKey: 'tkp-node-2-replica',
    dcKey: 'MSK',
    // У ноды есть нагрузка (назначен диапазон бакетов), поэтому коннекты
    // не могут быть выключены.
    connectionPool: 'ACTIVE',
    semaphores: [
      {
        nodeKey: 'tkp-node-2-replica',
        clusterKey: 'cluster-reserve',
        startInclusive: 16384,
        endExclusive: 32768,
        status: 'INACTIVE',
        recordsAmount: 182000,
        frozenNode: false,
        frozenSemaphoreCluster: false,
        dcKey: 'MSK',
        sameDc: false,
      },
    ],
  },
  {
    shardId: 3,
    nodeKey: 'tkp-node-3',
    dcKey: 'MSK',
    connectionPool: 'ACTIVE',
    semaphores: [
      {
        nodeKey: 'tkp-node-3',
        clusterKey: 'cluster-archive',
        startInclusive: 0,
        endExclusive: 16384,
        status: 'ACTIVE',
        recordsAmount: 98000,
        frozenNode: false,
        frozenSemaphoreCluster: false,
        dcKey: 'MSK',
        sameDc: true,
      },
    ],
  },
  {
    shardId: 3,
    nodeKey: 'tkp-node-3-replica',
    dcKey: 'SPB',
    connectionPool: 'ACTIVE',
    semaphores: [
      {
        nodeKey: 'tkp-node-3-replica',
        clusterKey: 'cluster-archive',
        startInclusive: 16384,
        endExclusive: 32768,
        status: 'ACTIVE',
        recordsAmount: 98000,
        frozenNode: false,
        frozenSemaphoreCluster: false,
        dcKey: 'SPB',
        sameDc: false,
      },
    ],
  },
  {
    shardId: 4,
    nodeKey: 'tkp-node-4',
    dcKey: 'MSK',
    connectionPool: 'ACTIVE',
    semaphores: [
      {
        nodeKey: 'tkp-node-4',
        clusterKey: 'cluster-backup',
        startInclusive: 0,
        endExclusive: 16384,
        status: 'ACTIVE',
        recordsAmount: 150000,
        frozenNode: false,
        frozenSemaphoreCluster: false,
        dcKey: 'MSK',
        sameDc: true,
      },
    ],
  },
  {
    shardId: 4,
    nodeKey: 'tkp-node-4-replica',
    dcKey: 'SPB',
    connectionPool: 'ACTIVE',
    monitoringState: 'ONLY_READ',
    semaphores: [
      {
        nodeKey: 'tkp-node-4-replica',
        clusterKey: 'cluster-backup',
        startInclusive: 16384,
        endExclusive: 32768,
        status: 'ACTIVE',
        recordsAmount: 150000,
        frozenNode: false,
        frozenSemaphoreCluster: false,
        dcKey: 'SPB',
        sameDc: false,
      },
    ],
  },
  // Шард с тремя нодами: проверяет, что верстка (NodeStatusGrid,
  // распределение нагрузки, редактор диапазонов) не завязана на ровно
  // две ноды. Границу шарда (PUT .../shard/{ids}/nodes) сервер по-прежнему
  // принимает только для шардов из двух нод — на трёх нодах доли
  // нагрузки меняются вручную через .../shard/{id}/semaphores, без авто-баланса.
  {
    shardId: 5,
    nodeKey: 'tkp-node-5',
    dcKey: 'MSK',
    connectionPool: 'ACTIVE',
    semaphores: [
      {
        nodeKey: 'tkp-node-5',
        clusterKey: 'cluster-triple',
        startInclusive: 0,
        endExclusive: 10923,
        status: 'ACTIVE',
        recordsAmount: 120000,
        frozenNode: false,
        frozenSemaphoreCluster: false,
        dcKey: 'MSK',
        sameDc: true,
      },
    ],
  },
  {
    shardId: 5,
    nodeKey: 'tkp-node-5-replica-a',
    dcKey: 'SPB',
    connectionPool: 'ACTIVE',
    semaphores: [
      {
        nodeKey: 'tkp-node-5-replica-a',
        clusterKey: 'cluster-triple',
        startInclusive: 10923,
        endExclusive: 32768,
        // endExclusive: 21845,
        status: 'ACTIVE',
        recordsAmount: 119000,
        frozenNode: false,
        frozenSemaphoreCluster: false,
        dcKey: 'SPB',
        sameDc: false,
      },
    ],
  },
  {
    shardId: 5,
    nodeKey: 'tkp-node-5-replica-b',
    dcKey: 'MSK',
    connectionPool: 'ACTIVE',
    monitoringState: 'ONLY_READ',
    semaphores: [
      // {
      //   nodeKey: 'tkp-node-5-replica-b',
      //   clusterKey: 'cluster-triple',
      //   startInclusive: 21845,
      //   endExclusive: 32768,
      //   status: 'ACTIVE',
      //   recordsAmount: 121000,
      //   frozenNode: true,
      //   frozenSemaphoreCluster: false,
      //   dcKey: 'MSK',
      //   sameDc: true,
      // },
    ],
  },
]

// NodeDto (getNodes()) — только идентификация и статус ноды, без
// вложенных данных о нагрузке/коннектах.
const deriveNodes = (rawNodes) =>
  rawNodes.map((node, index) => ({
    id: index + 1,
    key: node.nodeKey,
    shardId: node.shardId,
    status: 'WORKING',
    dcKey: node.dcKey,
    // Внутреннее поле мока для dbMonitorings(), не часть контракта NodeDto —
    // GET .../nodes явно отбирает только поля NodeDto перед ответом.
    monitoringState: node.monitoringState,
  }))

// PoolDto (ConnectionPoolManagementServiceApi.getPools()) — статус пула
// коннектов теперь отдельный ресурс, привязанный к ноде по ключу.
const derivePools = (rawNodes) =>
  rawNodes.map((node) => ({
    key: node.nodeKey,
    status: node.connectionPool ?? 'UNKNOWN',
    updated: NOW,
  }))

// BucketRangeDto — раньше жил внутри NodeDto.semaphores, теперь это часть
// bucketRanges соответствующей шарды (ShardDto).
const deriveBucketRanges = (rawNodes) =>
  rawNodes.flatMap((node) =>
    (node.semaphores ?? []).map((semaphore) => ({
      startInclusive: semaphore.startInclusive,
      endExclusive: semaphore.endExclusive,
      semaphoreClusterKey: semaphore.clusterKey,
      nodeKey: node.nodeKey,
      frozenNode: semaphore.frozenNode ?? false,
      frozenSemaphoreCluster: semaphore.frozenSemaphoreCluster ?? false,
      sameDC: semaphore.sameDc ?? false,
    })),
  )

// ShardDto (getShards()) — id шарды плюс её диапазоны бакетов.
const deriveShards = (rawNodes) => {
  const bucketRanges = deriveBucketRanges(rawNodes)
  const nodeKeyToShardId = new Map(rawNodes.map((node) => [node.nodeKey, node.shardId]))
  const shardIds = [...new Set(rawNodes.map((node) => node.shardId))].sort((a, b) => a - b)

  return shardIds.map((id) => ({
    id,
    bucketRanges: bucketRanges.filter((range) => nodeKeyToShardId.get(range.nodeKey) === id),
  }))
}

// SemaphoreDto (semaphoreInfo()) — теперь одна запись на семафорный кластер
// (а не на пару кластер+диапазон, как раньше). "Домашний" dcKey и статус
// кластера берём из диапазона его же ДЦ (semaphore.sameDc === true).
const deriveSemaphores = (rawNodes) => {
  const byClusterKey = new Map()

  for (const node of rawNodes) {
    for (const semaphore of node.semaphores ?? []) {
      const isHomeRange = semaphore.sameDc === true || !byClusterKey.has(semaphore.clusterKey)
      if (isHomeRange) {
        byClusterKey.set(semaphore.clusterKey, {
          clusterKey: semaphore.clusterKey,
          status: semaphore.status,
          dcKey: semaphore.dcKey,
          recordsAmount: semaphore.recordsAmount,
          updated: NOW,
        })
      }
    }
  }

  return [...byClusterKey.values()]
}

export const createInitialState = () => ({
  nextProcessId: 7004,
  nextRevisionId: 103,
  nextRestrictionId: 3,
  serviceMode: 'DISABLED',
  operationDays: {
    currentOperationDay: '2026-08-12',
    closedOperationDay: '2026-08-11',
  },
  processes: {},
  processHistory: [
    {
      groupId: '1',
      sessionId: '6901',
      dateOD: '2026-08-11',
      timeStart: '2026-08-11T19:00:00.000Z',
      timeEnd: '2026-08-11T19:14:00.000Z',
      statusGroup: 'COMPLETED',
      numbersMinutesAtWork: '14',
      groupDescription: 'Регламентное закрытие дня',
    },
    {
      groupId: '2',
      sessionId: '6902',
      dateOD: '2026-08-10',
      timeStart: '2026-08-10T18:45:00.000Z',
      timeEnd: '2026-08-10T19:02:00.000Z',
      statusGroup: 'FAILED',
      numbersMinutesAtWork: '17',
      groupDescription: 'Пересчёт клиентских данных',
    },
  ],
  nodes: deriveNodes(buildRawNodes().map(withValidConnectionPool)),
  pools: derivePools(buildRawNodes().map(withValidConnectionPool)),
  shards: deriveShards(buildRawNodes().map(withValidConnectionPool)),
  semaphores: deriveSemaphores(buildRawNodes().map(withValidConnectionPool)),
  replications: {
    1: {
      status: 'DONE',
      startedAt: '2026-08-12T08:00:00.000Z',
      finishedAt: '2026-08-12T08:04:00.000Z',
    },
    2: { status: 'REQUIRED', startedAt: '2026-08-12T09:00:00.000Z' },
    3: {
      status: 'DONE',
      startedAt: '2026-08-12T08:00:00.000Z',
      finishedAt: '2026-08-12T08:04:00.000Z',
    },
    4: {
      status: 'DONE',
      startedAt: '2026-08-12T08:00:00.000Z',
      finishedAt: '2026-08-12T08:04:00.000Z',
    },
    5: {
      status: 'DONE',
      startedAt: '2026-08-12T08:00:00.000Z',
      finishedAt: '2026-08-12T08:04:00.000Z',
    },
  },
  clusters: [
    {
      clusterId: 'client-index',
      state: 'ACTIVE',
      availableActions: 'DEACTIVATE',
      indexesCount: 8,
      updateRequired: false,
    },
    {
      clusterId: 'contract-index',
      state: 'ON_LOADING',
      availableActions: 'CANCEL_LOADING',
      indexesCount: 5,
      updateRequired: true,
      transitionStartedAt: Date.now() - 2000,
    },
  ],
  revisions: [makeRevision(101, 1), makeRevision(102, 2, 'MATCHED')],
  revisionHistory: makeRevisionHistoryList(),
  scriptApplications: [
    {
      id: 501,
      type: 'script',
      reasonId: 'CHG-2026-1042',
      jiraId: 'TKP-1042',
      rqUid: '9a5a7375-1ef2-41b1-a024-3f3a575b4fd4',
      shardId: 1,
      status: 'CREATED',
      restrictions: { enabled: true, allowedNodes: ['tkp-node-1'] },
      created: '2026-08-12T08:20:00.000Z',
      createdBy: 'mock.admin',
      requestTtl: 'PT24H',
    },
  ],
  templates: [
    {
      hashcode: 10101,
      path: 'maintenance/reindex.groovy',
      title: 'Перестроение индекса',
      extension: 'groovy',
      description: 'Безопасный шаблон перестроения индекса',
      tags: ['index', 'maintenance'],
      author: 'platform-team',
    },
    {
      hashcode: 10102,
      path: 'diagnostics/client.sql.groovy',
      title: 'Диагностика клиента',
      extension: 'groovy',
      tags: ['diagnostics'],
      author: 'support-team',
    },
    {
      hashcode: 10103,
      path: 'diagnostics/client_lookup.groovy',
      title: 'Поиск клиента по параметрам',
      extension: 'groovy',
      description: 'Выборка клиентов по таблице, идентификатору и периоду создания',
      tags: ['diagnostics', 'sql'],
      author: 'support-team',
    },
  ],
  templateBodies: {
    10101: "indexService.rebuild('client-index')\nreturn 'OK'",
    10102: "return jdbcTemplate.queryForList('select 1')",
    10103:
      "return jdbcTemplate.queryForList(\"select * from {{TABLE_NAME}} where client_id = '{{CLIENT_ID}}' and region = '{{REGION_CODE}}' and created_at > '{{FROM_DATE}}'\")",
  },
  features: [
    {
      name: 'client-transfer-v2',
      target: { type: 'DIRECT', module: 'tcpf-transfer' },
      hot: true,
      config: {
        activation: { type: 'MANUAL', enabled: true },
        description: 'Новый алгоритм переноса',
        customProperties: [{ name: 'batchSize', value: '500', type: 'INTEGER' }],
      },
      created: '2026-08-01T10:00:00.000Z',
      updated: NOW,
    },
    {
      name: 'revision-auto-sync',
      target: {
        type: 'SHARD',
        nodeKeys: ['tkp-node-1', 'tkp-node-2'],
        module: 'tcpf-revision',
      },
      hot: false,
      config: {
        activation: { type: 'OD_RELEASE', releaseDate: '2026-08-15' },
        description: 'Автосинхронизация расхождений',
        customProperties: [],
      },
      created: '2026-08-02T10:00:00.000Z',
      updated: NOW,
    },
  ],
  featureApplications: [
    {
      id: 601,
      type: 'feature',
      uid: 'feature-request-601',
      reasonId: 'CHG-2026-1050',
      featureName: 'client-transfer-v2',
      target: { type: 'DIRECT', module: 'tcpf-transfer' },
      status: 'PENDING',
      action: 'UPDATE',
      before: {
        activation: { type: 'MANUAL', enabled: false },
        customProperties: [],
      },
      after: {
        activation: { type: 'MANUAL', enabled: true },
        customProperties: [{ name: 'batchSize', value: '500', type: 'INTEGER' }],
      },
      created: NOW,
      createdBy: 'mock.admin',
    },
  ],
  trafficRestrictions: [
    {
      id: '1',
      name: 'Резервный ЦОД',
      services: ['tcpf-client-app'],
      dataCenters: ['SPB'],
      created: '2026-08-10T10:00:00.000Z',
      createdBy: 'mock.admin',
      comment: 'Плановые работы',
    },
    {
      id: '2',
      name: 'Глобальное ограничение MSK',
      services: [],
      dataCenters: ['MSK'],
      created: '2026-08-11T10:00:00.000Z',
      createdBy: 'mock.admin',
      comment: 'Проверка аварийного сценария',
    },
  ],
  transferStatus: [
    {
      shard: { id: 1, name: 'TKP-01', type: 'POSTGRESQL' },
      taskAmount: 18,
      attemptTaskAmount: 2,
    },
    {
      shard: { id: 2, name: 'TKP-02', type: 'POSTGRESQL' },
      taskAmount: 7,
      attemptTaskAmount: 0,
    },
  ],
})

// ===== Spring context beans =====
// A small hand-written set of beans that are actually referenced by the
// example script templates, plus a large deterministically-generated
// registry standing in for the rest of a real application context.

const CURATED_BEANS = [
  {
    name: 'clientService',
    className: 'ClientService',
    packageName: 'ru.sber.tcpf.service.ClientService',
    methods: [
      { name: 'findClient', returnType: 'Client', parameters: ['String'] },
      { name: 'recalculate', returnType: 'void', parameters: ['String', 'LocalDate'] },
    ],
  },
  {
    name: 'indexService',
    className: 'IndexService',
    packageName: 'ru.sber.tcpf.service.IndexService',
    methods: [
      { name: 'rebuild', returnType: 'String', parameters: ['String'] },
      { name: 'dropIndex', returnType: 'void', parameters: ['String'] },
      { name: 'getStatus', returnType: 'IndexStatus', parameters: ['String'] },
    ],
  },
  {
    name: 'jdbcTemplate',
    className: 'JdbcTemplate',
    packageName: 'org.springframework.jdbc.core.JdbcTemplate',
    methods: [
      { name: 'queryForList', returnType: 'List', parameters: ['String'] },
      { name: 'update', returnType: 'int', parameters: ['String', 'Object...'] },
    ],
  },
  {
    name: 'nodeRoutingService',
    className: 'NodeRoutingService',
    packageName: 'ru.sber.tcpf.service.NodeRoutingService',
    methods: [
      { name: 'getActiveNodes', returnType: 'List<Node>', parameters: ['String'] },
      { name: 'freezeNode', returnType: 'void', parameters: ['String'] },
      { name: 'unfreezeNode', returnType: 'void', parameters: ['String'] },
    ],
  },
  {
    name: 'notificationService',
    className: 'NotificationService',
    packageName: 'ru.sber.tcpf.service.NotificationService',
    methods: [{ name: 'notify', returnType: 'void', parameters: ['String', 'String'] }],
  },
]

// Deterministic PRNG (mulberry32) so the generated registry is identical on
// every restart instead of reshuffling and confusing anyone looking at it.
const mulberry32 = (seed) => {
  let a = seed
  return () => {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

const beanRandom = mulberry32(20260814)
const beanRandomInt = (min, max) => min + Math.floor(beanRandom() * (max - min + 1))
const beanPick = (arr) => arr[beanRandomInt(0, arr.length - 1)]
const capitalize = (word) => word.charAt(0).toUpperCase() + word.slice(1)
const lowerFirst = (word) => word.charAt(0).toLowerCase() + word.slice(1)

const BEAN_DOMAIN_WORDS = [
  'client', 'contract', 'node', 'shard', 'script', 'template', 'notification', 'index',
  'routing', 'feature', 'toggle', 'semaphore', 'replica', 'traffic', 'operation', 'process',
  'audit', 'user', 'permission', 'session', 'account', 'balance', 'payment', 'transaction',
  'invoice', 'order', 'product', 'catalog', 'region', 'branch', 'employee', 'role', 'group',
  'event', 'metric', 'health', 'config', 'lock', 'migration', 'encryption', 'integration',
  'gateway', 'report', 'export', 'import', 'document', 'file', 'storage', 'queue', 'message',
  'alert', 'webhook', 'security', 'token', 'certificate', 'cache', 'database', 'connection',
  'pool', 'thread', 'task', 'job', 'workflow', 'approval', 'escalation', 'ticket', 'incident',
  'log', 'trace', 'dashboard', 'statistic', 'aggregation', 'calculation', 'rule', 'policy',
  'limit', 'quota', 'throttle', 'rate', 'currency', 'exchange', 'tariff', 'fee', 'discount',
  'subscription', 'license', 'agreement', 'party', 'counterparty', 'beneficiary', 'signature',
  'verification', 'risk', 'score', 'fraud', 'compliance', 'jurisdiction', 'tax', 'receipt',
  'statement', 'reconciliation', 'settlement', 'clearing', 'portfolio', 'position',
  'instrument', 'loan', 'deposit', 'credit', 'ledger', 'journal', 'entry', 'batch',
  'partition', 'cluster', 'schedule', 'backup', 'restore', 'snapshot', 'archive', 'retention',
  'cleanup', 'validation', 'mapping', 'conversion', 'serialization', 'monitoring', 'sampling',
  'versioning', 'deployment', 'provisioning', 'orchestration', 'discovery', 'registry',
]

const randomBeanParams = () => {
  const templates = [
    [],
    [],
    ['String'],
    ['Long'],
    ['String', 'LocalDate'],
    ['String', 'String'],
    ['Long', 'BigDecimal'],
    ['List<String>'],
    ['String', 'Object...'],
    ['UUID'],
    ['String', 'Map<String, Object>'],
  ]
  return beanPick(templates)
}

// Each archetype describes how a bean/class name is built, which package it
// lives in, and a pool of method factories keyed off the derived entity name.
const BEAN_ARCHETYPES = [
  {
    suffix: 'Service', pkg: 'service',
    methods: (e) => [
      () => ({ name: `find${e}`, returnType: `Optional<${e}>`, parameters: [beanPick(['String', 'Long', 'UUID'])] }),
      () => ({ name: `findAll${e}s`, returnType: `List<${e}>`, parameters: randomBeanParams() }),
      () => ({ name: `create${e}`, returnType: e, parameters: [`${e}Dto`] }),
      () => ({ name: `update${e}`, returnType: e, parameters: [beanPick(['Long', 'String']), `${e}Dto`] }),
      () => ({ name: `delete${e}`, returnType: 'void', parameters: [beanPick(['Long', 'String'])] }),
      () => ({ name: `process${e}`, returnType: 'void', parameters: [beanPick(['String', 'Long'])] }),
      () => ({ name: 'recalculate', returnType: 'void', parameters: ['String', 'LocalDate'] }),
      () => ({ name: `validate${e}`, returnType: 'boolean', parameters: [e] }),
      () => ({ name: `sync${e}`, returnType: 'void', parameters: ['String'] }),
      () => ({ name: 'notify', returnType: 'void', parameters: ['String', 'String'] }),
    ],
  },
  {
    suffix: 'Repository', pkg: 'repository',
    methods: (e) => [
      () => ({ name: 'findById', returnType: `Optional<${e}>`, parameters: [beanPick(['Long', 'String', 'UUID'])] }),
      () => ({ name: 'findAll', returnType: `List<${e}>`, parameters: [] }),
      () => ({ name: 'save', returnType: e, parameters: [e] }),
      () => ({ name: 'deleteById', returnType: 'void', parameters: [beanPick(['Long', 'String'])] }),
      () => ({ name: 'existsById', returnType: 'boolean', parameters: [beanPick(['Long', 'String'])] }),
      () => ({ name: `countBy${capitalize(beanPick(['status', 'code', 'region']))}`, returnType: 'long', parameters: ['String'] }),
      () => ({ name: `findBy${capitalize(beanPick(['status', 'code', 'ownerId']))}`, returnType: `List<${e}>`, parameters: ['String'] }),
    ],
  },
  {
    suffix: 'Mapper', pkg: 'mapper',
    methods: (e) => [
      () => ({ name: 'toDto', returnType: `${e}Dto`, parameters: [e] }),
      () => ({ name: 'toEntity', returnType: e, parameters: [`${e}Dto`] }),
      () => ({ name: 'toDtoList', returnType: `List<${e}Dto>`, parameters: [`List<${e}>`] }),
      () => ({ name: 'merge', returnType: e, parameters: [e, `${e}Dto`] }),
    ],
  },
  {
    suffix: 'Validator', pkg: 'validation',
    methods: (e) => [
      () => ({ name: 'validate', returnType: 'ValidationResult', parameters: [e] }),
      () => ({ name: 'isValid', returnType: 'boolean', parameters: [e] }),
      () => ({ name: 'check', returnType: 'void', parameters: [e] }),
    ],
  },
  {
    suffix: 'Client', pkg: 'client',
    methods: (e) => [
      () => ({ name: `fetch${e}`, returnType: `ResponseEntity<${e}Dto>`, parameters: ['String'] }),
      () => ({ name: 'send', returnType: 'ResponseEntity<String>', parameters: ['String', 'Object'] }),
      () => ({ name: 'call', returnType: 'String', parameters: ['String', 'Map<String, Object>'] }),
      () => ({ name: 'ping', returnType: 'boolean', parameters: [] }),
    ],
  },
  {
    suffix: 'Handler', pkg: 'handler',
    methods: (e) => [
      () => ({ name: 'handle', returnType: 'void', parameters: [`${e}Event`] }),
      () => ({ name: 'canHandle', returnType: 'boolean', parameters: [`${e}Event`] }),
    ],
  },
  {
    suffix: 'Listener', pkg: 'listener',
    methods: (e) => [
      () => ({ name: 'onEvent', returnType: 'void', parameters: [`${e}Event`] }),
      () => ({ name: 'onMessage', returnType: 'void', parameters: ['String'] }),
    ],
  },
  {
    suffix: 'Publisher', pkg: 'publisher',
    methods: (e) => [
      () => ({ name: 'publish', returnType: 'void', parameters: [`${e}Event`] }),
      () => ({ name: 'broadcast', returnType: 'void', parameters: ['String', 'Object'] }),
    ],
  },
  {
    suffix: 'Manager', pkg: 'manager',
    methods: (e) => [
      () => ({ name: `manage${e}`, returnType: 'void', parameters: [beanPick(['String', 'Long'])] }),
      () => ({ name: 'start', returnType: 'void', parameters: [] }),
      () => ({ name: 'stop', returnType: 'void', parameters: [] }),
      () => ({ name: 'getStatus', returnType: `${e}Status`, parameters: ['String'] }),
    ],
  },
  {
    suffix: 'Resolver', pkg: 'resolver',
    methods: (e) => [
      () => ({ name: 'resolve', returnType: e, parameters: ['String'] }),
      () => ({ name: 'canResolve', returnType: 'boolean', parameters: ['String'] }),
    ],
  },
  {
    suffix: 'Provider', pkg: 'provider',
    methods: (e) => [
      () => ({ name: 'provide', returnType: e, parameters: [] }),
      () => ({ name: 'get', returnType: e, parameters: ['String'] }),
    ],
  },
  {
    suffix: 'Factory', pkg: 'factory',
    methods: (e) => [
      () => ({ name: 'create', returnType: e, parameters: [`${e}Dto`] }),
      () => ({ name: 'createDefault', returnType: e, parameters: [] }),
    ],
  },
  {
    suffix: 'Gateway', pkg: 'gateway',
    methods: (e) => [
      () => ({ name: 'send', returnType: 'void', parameters: [e] }),
      () => ({ name: 'receive', returnType: e, parameters: ['String'] }),
    ],
  },
  {
    suffix: 'Cache', pkg: 'cache',
    methods: () => [
      () => ({ name: 'get', returnType: 'Object', parameters: ['String'] }),
      () => ({ name: 'put', returnType: 'void', parameters: ['String', 'Object'] }),
      () => ({ name: 'evict', returnType: 'void', parameters: ['String'] }),
      () => ({ name: 'clear', returnType: 'void', parameters: [] }),
    ],
  },
  {
    suffix: 'Scheduler', pkg: 'scheduler',
    methods: () => [
      () => ({ name: 'schedule', returnType: 'void', parameters: ['String', 'LocalDateTime'] }),
      () => ({ name: 'trigger', returnType: 'void', parameters: ['String'] }),
      () => ({ name: 'cancel', returnType: 'boolean', parameters: ['String'] }),
    ],
  },
  {
    suffix: 'Config', pkg: 'config',
    methods: () => [
      () => ({
        name: `get${capitalize(beanPick(['timeout', 'retryCount', 'batchSize', 'enabled']))}`,
        returnType: beanPick(['int', 'boolean', 'String']),
        parameters: [],
      }),
    ],
  },
  {
    suffix: 'Facade', pkg: 'facade',
    methods: (e) => [
      () => ({ name: `process${e}`, returnType: 'void', parameters: ['String'] }),
      () => ({ name: 'execute', returnType: 'ExecutionResult', parameters: [`${e}Dto`] }),
    ],
  },
  {
    suffix: 'Aggregator', pkg: 'aggregation',
    methods: (e) => [
      () => ({ name: 'aggregate', returnType: `${e}Summary`, parameters: [`List<${e}>`] }),
      () => ({ name: 'merge', returnType: `${e}Summary`, parameters: [`List<${e}Summary>`] }),
    ],
  },
  {
    suffix: 'Registry', pkg: 'registry',
    methods: (e) => [
      () => ({ name: 'register', returnType: 'void', parameters: [e] }),
      () => ({ name: 'unregister', returnType: 'void', parameters: ['String'] }),
      () => ({ name: 'contains', returnType: 'boolean', parameters: ['String'] }),
    ],
  },
]

// A curated set of real, recognizable framework/infrastructure beans that
// would normally show up in a Spring Boot application context, so the list
// doesn't read as purely synthetic.
const FRAMEWORK_BEANS = [
  ['dataSource', 'HikariDataSource', 'com.zaxxer.hikari.HikariDataSource', [
    { name: 'getConnection', returnType: 'Connection', parameters: [] },
    { name: 'getMaximumPoolSize', returnType: 'int', parameters: [] },
  ]],
  ['namedParameterJdbcTemplate', 'NamedParameterJdbcTemplate', 'org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate', [
    { name: 'query', returnType: 'List<Map<String, Object>>', parameters: ['String', 'Map<String, Object>'] },
    { name: 'update', returnType: 'int', parameters: ['String', 'Map<String, Object>'] },
  ]],
  ['transactionManager', 'PlatformTransactionManager', 'org.springframework.transaction.PlatformTransactionManager', [
    { name: 'getTransaction', returnType: 'TransactionStatus', parameters: ['TransactionDefinition'] },
    { name: 'commit', returnType: 'void', parameters: ['TransactionStatus'] },
    { name: 'rollback', returnType: 'void', parameters: ['TransactionStatus'] },
  ]],
  ['entityManagerFactory', 'LocalContainerEntityManagerFactoryBean', 'org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean', [
    { name: 'createEntityManager', returnType: 'EntityManager', parameters: [] },
  ]],
  ['objectMapper', 'ObjectMapper', 'com.fasterxml.jackson.databind.ObjectMapper', [
    { name: 'writeValueAsString', returnType: 'String', parameters: ['Object'] },
    { name: 'readValue', returnType: 'T', parameters: ['String', 'Class<T>'] },
  ]],
  ['restTemplate', 'RestTemplate', 'org.springframework.web.client.RestTemplate', [
    { name: 'getForObject', returnType: 'T', parameters: ['String', 'Class<T>'] },
    { name: 'postForEntity', returnType: 'ResponseEntity<T>', parameters: ['String', 'Object', 'Class<T>'] },
  ]],
  ['webClient', 'WebClient', 'org.springframework.web.reactive.function.client.WebClient', [
    { name: 'get', returnType: 'RequestHeadersUriSpec', parameters: [] },
    { name: 'post', returnType: 'RequestBodyUriSpec', parameters: [] },
  ]],
  ['kafkaTemplate', 'KafkaTemplate', 'org.springframework.kafka.core.KafkaTemplate', [
    { name: 'send', returnType: 'ListenableFuture<SendResult>', parameters: ['String', 'Object'] },
  ]],
  ['redisTemplate', 'RedisTemplate', 'org.springframework.data.redis.core.RedisTemplate', [
    { name: 'opsForValue', returnType: 'ValueOperations', parameters: [] },
    { name: 'delete', returnType: 'Boolean', parameters: ['String'] },
  ]],
  ['stringRedisTemplate', 'StringRedisTemplate', 'org.springframework.data.redis.core.StringRedisTemplate', [
    { name: 'opsForHash', returnType: 'HashOperations', parameters: [] },
  ]],
  ['cacheManager', 'CaffeineCacheManager', 'org.springframework.cache.caffeine.CaffeineCacheManager', [
    { name: 'getCache', returnType: 'Cache', parameters: ['String'] },
  ]],
  ['taskExecutor', 'ThreadPoolTaskExecutor', 'org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor', [
    { name: 'execute', returnType: 'void', parameters: ['Runnable'] },
    { name: 'getActiveCount', returnType: 'int', parameters: [] },
  ]],
  ['taskScheduler', 'ThreadPoolTaskScheduler', 'org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler', [
    { name: 'schedule', returnType: 'ScheduledFuture', parameters: ['Runnable', 'Trigger'] },
  ]],
  ['applicationEventMulticaster', 'SimpleApplicationEventMulticaster', 'org.springframework.context.event.SimpleApplicationEventMulticaster', [
    { name: 'multicastEvent', returnType: 'void', parameters: ['ApplicationEvent'] },
  ]],
  ['messageSource', 'ResourceBundleMessageSource', 'org.springframework.context.support.ResourceBundleMessageSource', [
    { name: 'getMessage', returnType: 'String', parameters: ['String', 'Object[]', 'Locale'] },
  ]],
  ['requestMappingHandlerMapping', 'RequestMappingHandlerMapping', 'org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping', [
    { name: 'getHandler', returnType: 'HandlerExecutionChain', parameters: ['HttpServletRequest'] },
  ]],
  ['multipartResolver', 'StandardServletMultipartResolver', 'org.springframework.web.multipart.support.StandardServletMultipartResolver', [
    { name: 'resolveMultipart', returnType: 'MultipartHttpServletRequest', parameters: ['HttpServletRequest'] },
  ]],
  ['localeResolver', 'AcceptHeaderLocaleResolver', 'org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver', [
    { name: 'resolveLocale', returnType: 'Locale', parameters: ['HttpServletRequest'] },
  ]],
  ['securityFilterChain', 'SecurityFilterChain', 'org.springframework.security.web.SecurityFilterChain', [
    { name: 'matches', returnType: 'boolean', parameters: ['HttpServletRequest'] },
  ]],
  ['authenticationManager', 'ProviderManager', 'org.springframework.security.authentication.ProviderManager', [
    { name: 'authenticate', returnType: 'Authentication', parameters: ['Authentication'] },
  ]],
  ['passwordEncoder', 'BCryptPasswordEncoder', 'org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder', [
    { name: 'encode', returnType: 'String', parameters: ['CharSequence'] },
    { name: 'matches', returnType: 'boolean', parameters: ['CharSequence', 'String'] },
  ]],
  ['corsConfigurationSource', 'UrlBasedCorsConfigurationSource', 'org.springframework.web.cors.UrlBasedCorsConfigurationSource', [
    { name: 'getCorsConfiguration', returnType: 'CorsConfiguration', parameters: ['HttpServletRequest'] },
  ]],
  ['mvcConversionService', 'DefaultFormattingConversionService', 'org.springframework.format.support.DefaultFormattingConversionService', [
    { name: 'convert', returnType: 'T', parameters: ['Object', 'Class<T>'] },
  ]],
  ['jackson2ObjectMapperBuilder', 'Jackson2ObjectMapperBuilder', 'org.springframework.http.converter.json.Jackson2ObjectMapperBuilder', [
    { name: 'build', returnType: 'ObjectMapper', parameters: [] },
  ]],
  ['connectionFactory', 'CachingConnectionFactory', 'org.springframework.jms.connection.CachingConnectionFactory', [
    { name: 'createConnection', returnType: 'Connection', parameters: [] },
  ]],
  ['jmsTemplate', 'JmsTemplate', 'org.springframework.jms.core.JmsTemplate', [
    { name: 'send', returnType: 'void', parameters: ['String', 'MessageCreator'] },
  ]],
  ['javaMailSender', 'JavaMailSenderImpl', 'org.springframework.mail.javamail.JavaMailSenderImpl', [
    { name: 'send', returnType: 'void', parameters: ['SimpleMailMessage'] },
  ]],
  ['flywayInitializer', 'FlywayMigrationInitializer', 'org.springframework.boot.autoconfigure.flyway.FlywayMigrationInitializer', [
    { name: 'afterPropertiesSet', returnType: 'void', parameters: [] },
  ]],
  ['liquibase', 'SpringLiquibase', 'liquibase.integration.spring.SpringLiquibase', [
    { name: 'afterPropertiesSet', returnType: 'void', parameters: [] },
  ]],
  ['validatorFactoryBean', 'LocalValidatorFactoryBean', 'org.springframework.validation.beanvalidation.LocalValidatorFactoryBean', [
    { name: 'validate', returnType: 'Set<ConstraintViolation<T>>', parameters: ['T'] },
  ]],
  ['methodValidationPostProcessor', 'MethodValidationPostProcessor', 'org.springframework.validation.beanvalidation.MethodValidationPostProcessor', [
    { name: 'setValidator', returnType: 'void', parameters: ['Validator'] },
  ]],
  ['healthEndpoint', 'HealthEndpoint', 'org.springframework.boot.actuate.health.HealthEndpoint', [
    { name: 'health', returnType: 'HealthComponent', parameters: [] },
  ]],
  ['metricsEndpoint', 'MetricsEndpoint', 'org.springframework.boot.actuate.metrics.MetricsEndpoint', [
    { name: 'listNames', returnType: 'ListNamesResponse', parameters: [] },
  ]],
  ['meterRegistry', 'PrometheusMeterRegistry', 'io.micrometer.prometheus.PrometheusMeterRegistry', [
    { name: 'counter', returnType: 'Counter', parameters: ['String', 'String[]'] },
    { name: 'timer', returnType: 'Timer', parameters: ['String'] },
  ]],
  ['circuitBreakerRegistry', 'CircuitBreakerRegistry', 'io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry', [
    { name: 'circuitBreaker', returnType: 'CircuitBreaker', parameters: ['String'] },
  ]],
  ['retryRegistry', 'RetryRegistry', 'io.github.resilience4j.retry.RetryRegistry', [
    { name: 'retry', returnType: 'Retry', parameters: ['String'] },
  ]],
  ['springApplicationAdminRegistrar', 'SpringApplicationAdminMXBeanRegistrar', 'org.springframework.boot.admin.SpringApplicationAdminMXBeanRegistrar', [
    { name: 'isReady', returnType: 'boolean', parameters: [] },
  ]],
  ['requestContextFilter', 'RequestContextFilter', 'org.springframework.web.filter.RequestContextFilter', [
    { name: 'doFilter', returnType: 'void', parameters: ['ServletRequest', 'ServletResponse', 'FilterChain'] },
  ]],
  ['characterEncodingFilter', 'CharacterEncodingFilter', 'org.springframework.web.filter.CharacterEncodingFilter', [
    { name: 'doFilterInternal', returnType: 'void', parameters: ['HttpServletRequest', 'HttpServletResponse', 'FilterChain'] },
  ]],
  ['sessionRegistry', 'SessionRegistryImpl', 'org.springframework.security.core.session.SessionRegistryImpl', [
    { name: 'getAllPrincipals', returnType: 'List<Object>', parameters: [] },
  ]],
]

const buildGeneratedBean = (domainWord, archetype, usedNames) => {
  const entity = capitalize(domainWord)
  const beanName = lowerFirst(`${domainWord}${archetype.suffix}`)
  if (usedNames.has(beanName)) return null
  usedNames.add(beanName)

  const factories = archetype.methods(entity)
  const methodCount = beanRandomInt(1, Math.min(4, factories.length))
  const pool = [...factories]
  const methods = []
  const usedMethodNames = new Set()

  for (let i = 0; i < methodCount && pool.length; i += 1) {
    const index = beanRandomInt(0, pool.length - 1)
    const [factory] = pool.splice(index, 1)
    const method = factory()
    if (usedMethodNames.has(method.name)) continue
    usedMethodNames.add(method.name)
    methods.push(method)
  }

  return {
    name: beanName,
    className: `${entity}${archetype.suffix}`,
    packageName: `ru.sber.tcpf.${archetype.pkg}.${entity}${archetype.suffix}`,
    methods,
  }
}

// Deterministically generates ~targetCount beans in total, reusing the given
// bean names as already taken so nothing collides with the curated list.
const generateBeans = (targetCount, reservedNames) => {
  const usedNames = new Set(reservedNames)
  const generated = []

  FRAMEWORK_BEANS.forEach(([name, className, packageName, methods]) => {
    if (usedNames.has(name)) return
    usedNames.add(name)
    generated.push({ name, className, packageName, methods })
  })

  const remaining = targetCount - reservedNames.length - generated.length
  let guard = 0

  while (generated.length < remaining + FRAMEWORK_BEANS.length && guard < remaining * 20) {
    guard += 1
    const domainWord = beanPick(BEAN_DOMAIN_WORDS)
    const archetype = beanPick(BEAN_ARCHETYPES)
    const bean = buildGeneratedBean(domainWord, archetype, usedNames)
    if (bean) generated.push(bean)
  }

  return generated
}

export const beans = [
  ...CURATED_BEANS,
  ...generateBeans(
    500,
    CURATED_BEANS.map(({ name }) => name),
  ),
]
