import express from 'express'
import { pathToFileURL } from 'node:url'
import { beans, createInitialState, enabledServices, permissions, processFields } from './fixtures.js'

const DEFAULT_PORT = 3001
const DEFAULT_HOST = '127.0.0.1'
const clone = (value) => structuredClone(value)
const ok = (body, status = 200) => ({ status, body })
const text = (body, status = 200) => ({ status, body, contentType: 'text' })
const sse = (body, status = 200, interval = 5000) => ({
  status,
  body,
  contentType: 'sse',
  interval,
})
const empty = (status = 204) => ({ status })

const randomInteger = (min, max, random = Math.random) =>
  Math.floor(random() * (max - min + 1)) + min

const reserveUniqueLag = (value, occupiedValues, direction, minLag, maxLag) => {
  if (!occupiedValues.has(value)) return value

  for (let offset = 1; offset <= maxLag - minLag; offset += 1) {
    const preferredValue = value + offset * direction
    if (
      preferredValue >= minLag &&
      preferredValue <= maxLag &&
      !occupiedValues.has(preferredValue)
    ) {
      return preferredValue
    }

    const fallbackValue = value - offset * direction
    if (
      fallbackValue >= minLag &&
      fallbackValue <= maxLag &&
      !occupiedValues.has(fallbackValue)
    ) {
      return fallbackValue
    }
  }

  return value
}

export const createRandomSseInterval =
  ({ min = 1000, max = 5000, random = Math.random } = {}) =>
  () =>
    randomInteger(min, max, random)

const REPLICA_LAG_THRESHOLD = 30

// Лаг большую часть времени "дышит" в безопасном диапазоне ниже порога
// и лишь изредка кратковременно выходит за него, после чего быстро
// восстанавливается обратно к норме.
const NORMAL_MIN_REPLICATION_LAG = 0
const NORMAL_MAX_REPLICATION_LAG = 18
const NORMAL_MIN_REPLICATION_LAG_STEP = 1
const NORMAL_MAX_REPLICATION_LAG_STEP = 4

const SPIKE_MIN_REPLICATION_LAG = 35
const SPIKE_MAX_REPLICATION_LAG = 90
const SPIKE_CHANCE = 0.05
const SPIKE_RECOVERY_MIN_STEP = 8
const SPIKE_RECOVERY_MAX_STEP = 25

const route = (method, path, handler) => ({ method, path, handler })
const expressPath = (path) => path.replace(/\{([^}]+)\}/g, ':$1')

// Сгенерированные классы *ApiSse ходят в тот же путь, что и обычные методы,
// и отличают поток только заголовком Accept: text/event-stream — так же, как
// это делает реальный admin-app. Отдельных /sse/... маршрутов больше нет.
const wantsSse = (request) =>
  String(request?.headers?.accept ?? '').includes('text/event-stream')

/**
 * Маршрут, который на обычный запрос отдаёт снапшот, а на запрос с
 * Accept: text/event-stream — SSE-поток тех же данных.
 */
const streamable =
  (snapshot, { interval = createRandomSseInterval() } = {}) =>
  (context) => {
    if (wantsSse(context.request)) {
      return sse(() => snapshot(context), 200, interval)
    }

    return ok(snapshot(context))
  }

const findProcess = (state, id) =>
  state.processes[id] ?? {
    sessionId: Number(id),
    done: true,
    data: {
      lastUpdate: new Date().toISOString(),
      groupOfProcesses: {
        statusGroup: 'COMPLETED',
        numbersMinutesAtWork: '3',
        timeStart: '2026-08-12T09:00:00.000Z',
        dateOD: state.operationDays.currentOperationDay,
        fields: clone(processFields),
      },
    },
  }

const updateIndexTransitions = (clusters) => {
  const now = Date.now()
  for (const cluster of clusters) {
    if (!cluster.transitionStartedAt) continue
    const elapsed = now - cluster.transitionStartedAt
    if (elapsed < 2000) {
      cluster.state = 'CREATING'
    } else if (elapsed < 6000) {
      cluster.state = 'ON_LOADING'
    } else {
      cluster.state = 'ACTIVE'
      cluster.availableActions = 'DEACTIVATE'
      cluster.updateRequired = false
      delete cluster.transitionStartedAt
    }
  }
}

const publicClusters = (clusters) =>
  clusters.map((cluster) => {
    const { transitionStartedAt, ...rest } = cluster
    void transitionStartedAt
    return rest
  })

const dbMonitorings = (state) =>
  state.nodes.map(({ key, monitoringState }) => {
    // Начиная с platform-api 2.1 статус пула коннектов — отдельный ресурс
    // (getPools()), поэтому для UP/DOWN по умолчанию смотрим на него, а не
    // на саму ноду.
    const connectionState = state.pools.find((pool) => pool.key === key)?.status
    const monitorState = monitoringState ?? (connectionState === 'ACTIVE' ? 'UP' : 'DOWN')
    return {
      id: key,
      state: monitorState,
      lastSwitchTime: '2026-08-12T08:00:00.000Z',
      // Пока мониторинг DOWN, лаг репликации недоступен.
      replicaLag: monitorState === 'DOWN' ? null : key.includes('replica') ? 42 : 0,
    }
  })

export const createDbMonitoringEmitter = (
  state,
  {
    random = Math.random,
    normalMinLag = NORMAL_MIN_REPLICATION_LAG,
    normalMaxLag = NORMAL_MAX_REPLICATION_LAG,
    minStep = NORMAL_MIN_REPLICATION_LAG_STEP,
    maxStep = NORMAL_MAX_REPLICATION_LAG_STEP,
    spikeMinLag = SPIKE_MIN_REPLICATION_LAG,
    spikeMaxLag = SPIKE_MAX_REPLICATION_LAG,
    spikeChance = SPIKE_CHANCE,
    spikeRecoveryMinStep = SPIKE_RECOVERY_MIN_STEP,
    spikeRecoveryMaxStep = SPIKE_RECOVERY_MAX_STEP,
  } = {},
) => {
  const occupiedInitialValues = new Set()
  const lagStates = state.nodes.map(() => {
    const initialValue = reserveUniqueLag(
      randomInteger(normalMinLag, normalMaxLag, random),
      occupiedInitialValues,
      1,
      normalMinLag,
      normalMaxLag,
    )
    occupiedInitialValues.add(initialValue)

    return {
      value: initialValue,
      // Большую часть времени узел находится в "нормальном" режиме и
      // плавно дрейфует в безопасном диапазоне. spiking=true — короткий
      // эпизод превышения порога, из которого лаг быстро восстанавливается.
      spiking: false,
    }
  })

  return () => {
    const occupiedNormalValues = new Set()
    const occupiedSpikeValues = new Set()
    // Состояние узла читаем заново на каждом тике, а не один раз при
    // открытии SSE-соединения — иначе переключение UP/DOWN во время
    // подключения не отражалось бы в потоке.
    const monitorings = dbMonitorings(state)

    return monitorings.map((monitoring, index) => {
      const lagState = lagStates[index]

      if (monitoring.state === 'DOWN') {
        // Мониторинг недоступен: лаг репликации не публикуется и не
        // обновляется, чтобы при восстановлении узел продолжил со своего
        // последнего известного значения, а не со случайного нового.
        return {
          ...monitoring,
          replicaLag: null,
        }
      }

      if (lagState.spiking) {
        // В режиме всплеска лаг быстро снижается обратно к норме.
        const step = randomInteger(spikeRecoveryMinStep, spikeRecoveryMaxStep, random)
        const decayedValue = lagState.value - step

        if (decayedValue <= normalMaxLag) {
          lagState.spiking = false
          lagState.value = reserveUniqueLag(
            randomInteger(normalMinLag, normalMaxLag, random),
            occupiedNormalValues,
            1,
            normalMinLag,
            normalMaxLag,
          )
          occupiedNormalValues.add(lagState.value)
        } else {
          lagState.value = reserveUniqueLag(
            decayedValue,
            occupiedSpikeValues,
            -1,
            spikeMinLag,
            spikeMaxLag,
          )
          occupiedSpikeValues.add(lagState.value)
        }
      } else if (random() < spikeChance) {
        // Редкий кратковременный выход лага за пределы нормы.
        lagState.spiking = true
        lagState.value = reserveUniqueLag(
          randomInteger(spikeMinLag, spikeMaxLag, random),
          occupiedSpikeValues,
          1,
          spikeMinLag,
          spikeMaxLag,
        )
        occupiedSpikeValues.add(lagState.value)
      } else {
        // Обычный дрейф внутри безопасного диапазона.
        const step = randomInteger(minStep, maxStep, random)
        const direction = random() < 0.5 ? -1 : 1
        const wanderedValue = Math.min(
          normalMaxLag,
          Math.max(normalMinLag, lagState.value + step * direction),
        )

        lagState.value = reserveUniqueLag(
          wanderedValue,
          occupiedNormalValues,
          direction,
          normalMinLag,
          normalMaxLag,
        )
        occupiedNormalValues.add(lagState.value)
      }

      return {
        ...monitoring,
        replicaLag: lagState.value,
      }
    })
  }
}

const makeRoutes = () => [
  route('GET', '/health', ({ state }) =>
    ok({
      status: 'ok',
      service: 'tcpf-support-admin-mock',
      processes: Object.keys(state.processes).length,
    }),
  ),
  route('GET', '/__mock/state', ({ state }) => ok(state)),
  route('POST', '/__mock/reset', ({ reset }) => ok(reset())),
  route('GET', '/config/services', () => ok(enabledServices)),

  route('GET', '/invoke/support-admin/user-service/roles', () => ok(['ADMIN', 'TKP_SUPPORT'])),
  route('GET', '/invoke/support-admin/user-service/permissions', () => ok(permissions)),
  route('POST', '/invoke/support-admin/user-service/logout', () => empty()),

  route('POST', '/invoke/support-admin/dictionaries-service/dictionary', ({ body }) => {
    const code = body?.code ?? 'DICTIONARY'
    const dictionaries = {
      PROCESS_TYPE: [
        { id: '1', label: 'Закрытие операционного дня' },
        { id: '2', label: 'Пересчёт клиентских данных' },
      ],
      PROCESS_MONITORING: [
        { id: 'RUNNING', label: 'Выполняется' },
        { id: 'COMPLETED', label: 'Завершён' },
        { id: 'FAILED', label: 'Ошибка' },
      ],
    }
    return ok(
      dictionaries[code] ?? [
        { id: `${code}_1`, label: `${code}: значение 1` },
        { id: `${code}_2`, label: `${code}: значение 2` },
      ],
    )
  }),

  route('GET', '/invoke/support-admin/process-management-service/processes/types', () =>
    ok([
      { id: '1', label: 'Закрытие операционного дня' },
      { id: '2', label: 'Пересчёт данных' },
    ]),
  ),
  route(
    'GET',
    '/invoke/support-admin/process-management-service/processes',
    ({ state, url }) => {
      const sessionId = url.searchParams.get('sessionId')
      if (sessionId) return ok(findProcess(state, sessionId))

      const processGroupId = Number(url.searchParams.get('processGroupId'))
      const activeProcess = Object.values(state.processes).find(
        (process) =>
          !process.done && (!processGroupId || process.processGroupId === processGroupId),
      )

      return ok(
        activeProcess ?? {
          sessionId: processGroupId || 0,
          done: true,
        },
      )
    },
  ),
  route(
    'POST',
    '/invoke/support-admin/process-management-service/processes',
    ({ state, body, url }) => {
      const id = state.nextProcessId++
      const process = clone(findProcess(state, 7001))
      process.sessionId = id
      process.done = false
      process.processGroupId = Number(
        url.searchParams.get('processGroupId') ?? body?.groupId ?? 0,
      )
      process.data.groupOfProcesses.dateOD =
        url.searchParams.get('operationDay') ??
        body?.operationDay ??
        state.operationDays.currentOperationDay
      process.data.groupOfProcesses.statusGroup = 'RUNNING'
      state.processes[id] = process
      return ok({ processName: 'process-group', idOfStartedProcess: id }, 201)
    },
  ),
  route(
    'GET',
    '/invoke/support-admin/process-management-service/processes/{sessionId}',
    ({ state, params }) => ok(findProcess(state, params.sessionId)),
  ),
  route(
    'DELETE',
    '/invoke/support-admin/process-management-service/processes/{sessionId}',
    ({ state, params }) => {
      const process = findProcess(state, params.sessionId)
      process.done = true
      if (process.data?.groupOfProcesses) process.data.groupOfProcesses.statusGroup = 'STOPPED'
      state.processes[params.sessionId] = process
      return ok({
        processName: 'stopped-process',
        idOfStartedProcess: Number(params.sessionId),
      })
    },
  ),
  route('POST', '/invoke/support-admin/process-management-service/history', ({ state }) =>
    ok(state.processHistory),
  ),

  route('POST', '/invoke/support-admin/operation-day-service/close', ({ state }) => {
    const id = state.nextProcessId++
    state.processes[id] = clone(findProcess(state, 7001))
    state.processes[id].sessionId = id
    return ok({ processName: 'close-operation-day', idOfStartedProcess: id })
  }),
  route('POST', '/invoke/support-admin/operation-day-service/result', ({ state, body }) =>
    ok(findProcess(state, body?.process?.idOfStartedProcess ?? 7001)),
  ),
  route('POST', '/invoke/support-admin/operation-day-service/operation-days', ({ state }) =>
    ok(state.operationDays),
  ),
  route(
    'POST',
    '/invoke/support-admin/operation-day-service/current-operation-day',
    ({ state }) => ok(state.operationDays.currentOperationDay),
  ),
  route('POST', '/invoke/support-admin/operation-day-service/history', ({ state }) =>
    ok(state.processHistory),
  ),
  route(
    'POST',
    '/invoke/support-admin/operation-day-service/history-details',
    ({ state, body }) =>
      ok(findProcess(state, body?.sessionId ?? 7001).data?.groupOfProcesses?.fields ?? []),
  ),
  route('POST', '/invoke/support-admin/operation-day-service/failed-contracts-with-steps', () =>
    ok([
      {
        id: 'contract-104',
        number: 'ДК-000104',
        idOfClient: 'client-42',
        errorMessage: 'Не найден обязательный шаг расчёта',
      },
    ]),
  ),

  route('GET', '/invoke/support-admin/client-transfer-service/transfer', ({ state }) =>
    ok(state.transferStatus),
  ),
  route('POST', '/invoke/support-admin/client-transfer-service/transfer', ({ state, body }) => {
    const id = state.nextProcessId++
    state.processes[id] = {
      sessionId: id,
      done: false,
      data: {
        lastUpdate: new Date().toISOString(),
        groupOfProcesses: {
          statusGroup: 'RUNNING',
          dateOD: body?.deleteUpToDate ?? state.operationDays.currentOperationDay,
          fields: [],
        },
      },
    }
    return ok({ processName: 'client-transfer', idOfStartedProcess: id })
  }),
  route('POST', '/invoke/support-admin/client-transfer-service/task', ({ state, body }) => {
    const id = state.nextProcessId++
    const sourceShardIds = body?.sourceShardIds?.length ? body.sourceShardIds : [1]
    state.processes[id] = {
      sessionId: id,
      done: true,
      data: {
        lastUpdate: new Date().toISOString(),
        groupOfProcesses: {
          statusGroup: 'COMPLETED',
          fields: sourceShardIds.map((shardId, index) => ({
            name: 'Формирование задания',
            code: `CREATE_TRANSFER_TASK_${shardId}`,
            status: index === sourceShardIds.length - 1 ? 'COMPLETED' : 'RUNNING',
            nodeCode: String(shardId),
            recordsWillBeProcessed: String(850 + index * 400),
            startTime: '2026-08-12T09:10:00.000Z',
            endTime:
              index === sourceShardIds.length - 1 ? '2026-08-12T09:12:00.000Z' : undefined,
          })),
        },
      },
    }
    return ok({ processName: 'create-transfer-task', idOfStartedProcess: id }, 201)
  }),
  route(
    'GET',
    '/invoke/support-admin/client-transfer-service/result/{processId}',
    ({ state, params }) => ok(findProcess(state, params.processId)),
  ),
  route('GET', '/invoke/support-admin/client-transfer-service/history', ({ state }) =>
    ok(state.processHistory),
  ),
  route('POST', '/invoke/support-admin/client-transfer-service/clear', ({ state }) => {
    const id = state.nextProcessId++
    return ok({ processName: 'clear-transfer-tasks', idOfStartedProcess: id })
  }),
  route('GET', '/invoke/support-admin/client-transfer-service/clear', ({ state }) =>
    ok(state.transferStatus),
  ),

  route(
    'GET',
    '/invoke/support-admin/cluster-management-service/nodes',
    streamable(({ state }) =>
      state.nodes.map(({ id, key, shardId, status, dcKey }) => ({
        id,
        key,
        shardId,
        status,
        dcKey,
      })),
    ),
  ),
  route(
    'GET',
    '/invoke/support-admin/cluster-management-service/shard',
    streamable(({ state }) => state.shards),
  ),
  route(
    'GET',
    '/invoke/support-admin/cluster-management-service/pools',
    streamable(({ state }) => state.pools),
  ),
  route(
    'GET',
    '/invoke/support-admin/cluster-management-service/semaphores',
    streamable(({ state }) => state.semaphores),
  ),
  route(
    'PATCH',
    '/invoke/support-admin/cluster-management-service/semaphores/{clusterKey}/status',
    ({ state, params, body }) => {
      const semaphore = state.semaphores.find((item) => item.clusterKey === params.clusterKey)
      if (semaphore) semaphore.status = body?.status ?? semaphore.status
      return empty()
    },
  ),
  route(
    'PUT',
    '/invoke/support-admin/cluster-management-service/nodes/{nodeKey}/pools',
    ({ state, params, url }) => {
      // Согласно openapi2.yml поле poolState передаётся query-параметром,
      // а не телом запроса: PoolState = ACTIVE | SUSPENDED | UNKNOWN.
      const pool = state.pools.find((item) => item.key === params.nodeKey)
      const poolState = url.searchParams.get('poolState')
      if (pool && poolState) pool.status = poolState
      return empty()
    },
  ),
  route(
    'PUT',
    '/invoke/support-admin/cluster-management-service/nodes/{nodeKey}/metadatas',
    () =>
      ok({
        schemaVersion: '34.1.14-MOCK',
        dictionaryVersion: '3.0.1-MOCK',
      }),
  ),
  route(
    'PUT',
    '/invoke/support-admin/cluster-management-service/shard/{ids}/nodes',
    ({ state, params, body }) => {
      // params.ids соответствует String(Array<number>) из клиента — обычно
      // один shardId, но формально может быть списком через запятую.
      const shardIds = params.ids.split(',').map(Number)
      const bucketBoundary = Array.isArray(body?.bucketBoundary) ? body.bucketBoundary : []

      for (const [index, shardId] of shardIds.entries()) {
        const shard = state.shards.find((item) => item.id === shardId)
        const boundary = bucketBoundary.length === 1 ? bucketBoundary[0] : bucketBoundary[index]
        if (!shard || boundary == null) continue

        if (shard.bucketRanges.length !== 2) {
          continue
        }
        if (!Number.isInteger(boundary) || boundary < 0 || boundary > 32768) {
          return ok({ message: 'bucketNumber must be between 0 and 32768' }, 400)
        }

        const [leftRange, rightRange] = shard.bucketRanges
        leftRange.startInclusive = 0
        leftRange.endExclusive = boundary
        rightRange.startInclusive = boundary
        rightRange.endExclusive = 32768
      }

      return ok(state.shards)
    },
  ),
  route(
    'PUT',
    '/invoke/support-admin/cluster-management-service/shard/{id}/semaphores',
    ({ state, params, body }) => {
      const shard = state.shards.find((item) => item.id === Number(params.id))
      const changedBucketRanges = Array.isArray(body?.changedBucketRanges)
        ? body.changedBucketRanges
        : []

      if (shard && changedBucketRanges.length) {
        shard.bucketRanges = changedBucketRanges
      }

      return ok(state.shards)
    },
  ),
  route('GET', '/invoke/support-admin/cluster-management-service/service-mode', ({ state }) =>
    ok({ status: state.serviceMode, startedAt: '2026-08-12T07:00:00.000Z' }),
  ),
  route(
    'PUT',
    '/invoke/support-admin/cluster-management-service/service-mode',
    ({ state, body }) => {
      state.serviceMode = body?.status ?? state.serviceMode
      return ok({
        code: 0,
        description: `Сервисный режим: ${state.serviceMode}`,
      })
    },
  ),
  route(
    'GET',
    '/invoke/support-admin/cluster-management-service/shards/{shardId}/replication',
    ({ state, params }) =>
      ok(
        state.replications[params.shardId] ?? {
          status: 'REQUIRED',
          startedAt: new Date().toISOString(),
        },
      ),
  ),
  route(
    'POST',
    '/invoke/support-admin/cluster-management-service/shards/{shardId}/replication',
    ({ state, params }) => {
      state.replications[params.shardId] = {
        status: 'IN_PROGRESS',
        startedAt: new Date().toISOString(),
      }
      return ok({ code: 0, description: 'Репликация запущена' })
    },
  ),
  route(
    'DELETE',
    '/invoke/support-admin/cluster-management-service/shards/{shardId}/replication',
    ({ state, params }) => {
      state.replications[params.shardId] = {
        status: 'REQUIRED',
        startedAt: new Date().toISOString(),
      }
      return ok({ code: 0, description: 'Репликация отменена' })
    },
  ),

  route(
    'GET',
    '/invoke/support-admin/monitoring-management-service/monitorings/ignite',
    streamable(({ url }) => {
      const type = url.searchParams.get('type') ?? 'ALL'
      return [
        { id: `${type.toLowerCase()}-cluster-1`, state: 'UP' },
        { id: `${type.toLowerCase()}-cluster-2`, state: 'ONLY_READ' },
      ]
    }),
  ),
  route(
    'GET',
    '/invoke/support-admin/monitoring-management-service/monitorings/db',
    ({ state, request }) => {
      // В потоке отдаём «живые» значения лага репликации, в обычном
      // запросе — текущий снапшот.
      if (wantsSse(request)) {
        return sse(createDbMonitoringEmitter(state), 200, createRandomSseInterval())
      }

      return ok(dbMonitorings(state))
    },
  ),
  route(
    'GET',
    '/invoke/support-admin/monitoring-management-service/monitorings/threshold',
    () => ok({ lag: REPLICA_LAG_THRESHOLD }),
  ),
  route('GET', '/invoke/support-admin/shard-info-service/routing-objects/shard', ({ url }) => {
    const key = url.searchParams.get('key') ?? 'unknown'
    // Контракт, для которого шард сознательно не найден — удобно для проверки
    // состояния ошибки на странице "Шард контракта" (Номер договора: NOTFOUND).
    if (key === 'NOTFOUND') {
      return ok({ status: 404, message: 'Shard not found' }, 404)
    }
    return ok({
      shardId: (Math.abs([...key].reduce((sum, char) => sum + char.charCodeAt(0), 0)) % 3) + 1,
      nodeKey: 'tkp-node-1',
    })
  }),

  route('GET', '/invoke/support-admin/zone-index-service/clusters', ({ state }) => {
    updateIndexTransitions(state.clusters)
    return ok(publicClusters(state.clusters))
  }),
  route('POST', '/invoke/support-admin/zone-index-service/clusters', ({ state, body }) => {
    const action = body?.actionRequest?.action
    const cluster = state.clusters.find(
      (item) => item.clusterId === body?.actionRequest?.clusterId,
    )
    if (!cluster) {
      return ok({
        rqUid: body?.rqUid,
        rqTm: body?.rqTm ?? new Date().toISOString(),
        code: 1,
        description: 'Кластер не найден',
      })
    }
    if (action === 'CREATE_INDEX') {
      cluster.state = 'CREATING'
      cluster.availableActions = 'CANCEL_LOADING'
      cluster.updateRequired = true
      cluster.transitionStartedAt = Date.now()
    } else if (action === 'DEACTIVATE' || action === 'CANCEL_LOADING') {
      cluster.state = 'INACTIVE'
      cluster.availableActions = 'CREATE_INDEX'
      cluster.updateRequired = false
      delete cluster.transitionStartedAt
    } else {
      return ok({
        rqUid: body?.rqUid,
        rqTm: body?.rqTm ?? new Date().toISOString(),
        code: 2,
        description: `Действие ${action ?? 'UNKNOWN'} недоступно`,
      })
    }
    return ok({
      rqUid: body?.rqUid,
      rqTm: body?.rqTm ?? new Date().toISOString(),
      code: 0,
      description: `Действие ${action ?? 'UNKNOWN'} принято`,
    })
  }),

  route('GET', '/invoke/support-admin/revise-replication-service/shards', ({ state }) =>
    ok(state.shards.map(({ id }) => String(id))),
  ),
  route(
    'GET',
    '/invoke/support-admin/revise-replication-service/shards/revisions',
    ({ state }) => ok(state.revisions),
  ),
  route(
    'POST',
    '/invoke/support-admin/revise-replication-service/shards/{shardIds}/revisions',
    ({ state, params, url }) => {
      const shards = decodeURIComponent(params.shardIds).split(',')
      const created = shards.map((shardId) => ({
        ...clone(state.revisions[0]),
        id: state.nextRevisionId++,
        shardId,
        part: Number(url.searchParams.get('part') ?? 100),
        status: 'WORKING',
        jobStatus: 'RUNNING',
        created: new Date().toISOString(),
        updated: new Date().toISOString(),
      }))
      state.revisions.unshift(...created)
      return ok(created, 201)
    },
  ),
  route(
    'GET',
    '/invoke/support-admin/revise-replication-service/shards/{shardIds}/revisions/history',
    ({ state, params, url }) => {
      const ids = decodeURIComponent(params.shardIds).split(',')
      const status = url.searchParams.get('status')
      const revisionId = url.searchParams.get('revisionId')
      const from = url.searchParams.get('from')
      const to = url.searchParams.get('to')
      const fromMs = from ? new Date(from).getTime() : NaN
      const toMs = to ? new Date(to).getTime() : NaN
      // "to" is a day boundary (date-only), so treat it as inclusive of the
      // whole day rather than midnight at its start.
      const toBoundaryMs = Number.isNaN(toMs) ? NaN : toMs + 24 * 60 * 60 * 1000 - 1

      const filtered = state.revisionHistory
        .filter((revision) => ids.includes(revision.shardId))
        .filter((revision) => !status || revision.status === status)
        .filter((revision) => !revisionId || String(revision.id) === revisionId)
        .filter((revision) => {
          if (Number.isNaN(fromMs)) return true
          return new Date(revision.updated).getTime() >= fromMs
        })
        .filter((revision) => {
          if (Number.isNaN(toBoundaryMs)) return true
          return new Date(revision.updated).getTime() <= toBoundaryMs
        })
        .sort((a, b) => new Date(b.updated).getTime() - new Date(a.updated).getTime())

      // 1-based page number, matching the `pageNumber`/`pageSize` query
      // params documented in apis/openapi2.yml (defaults: page 1, size 20).
      const pageNumber = Math.max(1, Number(url.searchParams.get('pageNumber') ?? 1))
      const pageSize = Math.max(1, Number(url.searchParams.get('pageSize') ?? 20))
      const start = (pageNumber - 1) * pageSize

      return ok(filtered.slice(start, start + pageSize))
    },
  ),
  route(
    'GET',
    '/invoke/support-admin/revise-replication-service/shards/{shardId}/revisions/{revisionId}',
    ({ state, params }) => {
      const revision = state.revisions.find(
        (item) => String(item.id) === params.revisionId && item.shardId === params.shardId,
      )
      return revision ? ok(revision) : ok({ status: 404, message: 'Revision not found' }, 404)
    },
  ),
  route(
    'PATCH',
    '/invoke/support-admin/revise-replication-service/shards/{shardId}/revisions/{revisionId}',
    ({ state, params, url }) => {
      const revision = state.revisions.find(
        (item) => String(item.id) === params.revisionId && item.shardId === params.shardId,
      )
      if (!revision) return ok({ status: 404, message: 'Revision not found' }, 404)
      revision.status = url.searchParams.get('status') ?? revision.status
      revision.job = url.searchParams.get('job') ?? revision.job
      revision.updated = new Date().toISOString()
      return ok(revision)
    },
  ),
  route(
    'GET',
    '/invoke/support-admin/revise-replication-service/shards/{shardId}/revisions/{revisionId}/details',
    ({ state, params }) => {
      const revision =
        state.revisions.find((item) => String(item.id) === params.revisionId) ??
        state.revisions[0]
      return ok([
        { ...revision, table: 'client_contract', id: 1 },
        { ...revision, table: 'account_balance', id: 2, rowsDiff: 0 },
      ])
    },
  ),
  route(
    'GET',
    '/invoke/support-admin/revise-replication-service/shards/{shardId}/revisions/{revisionId}/report',
    ({ params }) =>
      ok([
        {
          id: 1,
          revisionTaskId: Number(params.revisionId),
          pkUpdTime: '2026-08-12T08:30:00.000Z',
          table: 'client_contract',
          pk: 'contract-104',
          status: 'DIFF',
          statusTime: new Date().toISOString(),
        },
      ]),
  ),

  route('GET', '/invoke/support-admin/script-service/applications', ({ state }) =>
    ok(state.scriptApplications),
  ),
  route('POST', '/invoke/support-admin/script-service/applications', ({ state, body }) => {
    const app = {
      id: Date.now(),
      type: 'script',
      rqUid: crypto.randomUUID(),
      status: 'CREATED',
      created: new Date().toISOString(),
      createdBy: 'mock.admin',
      ...body,
    }
    state.scriptApplications.unshift(app)
    return empty(201)
  }),
  route(
    'GET',
    '/invoke/support-admin/script-service/applications/{reasonId}',
    ({ state, params }) =>
      ok(
        state.scriptApplications.find((item) => item.reasonId === params.reasonId) ??
          state.scriptApplications[0],
      ),
  ),
  route(
    'PUT',
    '/invoke/support-admin/script-service/applications/{reasonId}/status',
    ({ state, params, body }) => {
      const app = state.scriptApplications.find((item) => item.reasonId === params.reasonId)
      if (app)
        Object.assign(app, body, {
          resolvedAt: new Date().toISOString(),
          resolvedBy: 'mock.admin',
        })
      return ok(app ?? body)
    },
  ),
  route(
    'GET',
    '/invoke/support-admin/script-service/applications/{reasonId}/script',
    ({ params }) => text(`// ${params.reasonId}\nreturn 'mock result'`),
  ),
  route(
    'GET',
    '/invoke/support-admin/script-service/applications/{reasonId}/logs',
    ({ params }) =>
      text(`[INFO] ${params.reasonId}: скрипт принят\n[INFO] Выполнение завершено`),
  ),
  route('GET', '/invoke/support-admin/script-service/templates/metadata', ({ state }) =>
    ok(state.templates),
  ),
  route('GET', '/invoke/support-admin/script-service/templates/{hash}', ({ state, params }) =>
    text(state.templateBodies[params.hash] ?? '// Шаблон не найден'),
  ),
  route('GET', '/invoke/support-admin/script-service/beans', () => ok(beans)),

  route('GET', '/invoke/support-admin/feature-toggling-service/properties/types', () =>
    ok(['STRING', 'INTEGER', 'BOOLEAN', 'DECIMAL']),
  ),
  route('GET', '/invoke/support-admin/feature-toggling-service/features', ({ state }) =>
    ok(state.features),
  ),
  route(
    'PUT',
    '/invoke/support-admin/feature-toggling-service/features/hotconfigs',
    ({ state, body }) => {
      if (Array.isArray(body)) state.features = body
      return empty()
    },
  ),
  route(
    'GET',
    '/invoke/support-admin/feature-toggling-service/features/applications',
    ({ state }) => ok(state.featureApplications),
  ),
  route(
    'POST',
    '/invoke/support-admin/feature-toggling-service/features/applications',
    ({ state, body }) => {
      const created = (Array.isArray(body) ? body : [body]).map((item) => {
        const feature = item?.feature ?? {}
        return {
          id: Date.now(),
          type: 'feature',
          uid: crypto.randomUUID(),
          reasonId: item?.requestId ?? 'MOCK',
          featureName: feature.name ?? 'MOCK_FEATURE',
          target: feature.target ?? { type: 'GLOBAL' },
          status: 'PENDING',
          action: item?.action ?? 'CREATE',
          before: null,
          after: feature.config ?? null,
          created: new Date().toISOString(),
          createdBy: 'mock.admin',
        }
      })
      state.featureApplications.unshift(...created)
      return empty(201)
    },
  ),
  route(
    'POST',
    '/invoke/support-admin/feature-toggling-service/features/applications/dump',
    ({ state }) =>
      ok(
        {
          applications: state.featureApplications,
          imported: state.featureApplications.length,
        },
        201,
      ),
  ),
  route(
    'PUT',
    '/invoke/support-admin/feature-toggling-service/features/applications/{uid}/status',
    ({ state, params, body }) => {
      const application = state.featureApplications.find((item) => item.uid === params.uid)
      if (application) application.status = body?.status ?? application.status
      return ok(application ?? { uid: params.uid, ...body })
    },
  ),
  route('GET', '/invoke/support-admin/feature-toggling-service/statistics', ({ state }) =>
    ok(
      state.features.map((feature, index) => ({
        name: feature.name,
        lastCallDate: '2026-08-12',
        callAmount: 1200 - index * 275,
      })),
    ),
  ),

  route(
    'GET',
    '/invoke/support-admin/geo-balancing/services',
    streamable(() => [
      { name: 'tcpf-client-app', dataCenters: ['MSK', 'SPB'] },
      { name: 'tcpf-contract-app', dataCenters: ['MSK'] },
    ]),
  ),
  route(
    'GET',
    '/invoke/support-admin/geo-balancing/data-centers',
    streamable(() => ['MSK', 'SPB', 'EKB']),
  ),
  route(
    'GET',
    '/invoke/support-admin/geo-balancing/traffic-restrictions',
    streamable(({ state }) => state.trafficRestrictions),
  ),
  route(
    'POST',
    '/invoke/support-admin/geo-balancing/traffic-restrictions',
    ({ state, body }) => {
      const restriction = {
        ...body,
        id: String(state.nextRestrictionId++),
        created: new Date().toISOString(),
        createdBy: 'mock.admin',
      }
      state.trafficRestrictions.push(restriction)
      return ok(restriction, 201)
    },
  ),
  route(
    'GET',
    '/invoke/support-admin/geo-balancing/traffic-restrictions/{id}',
    ({ state, params }) => {
      const restriction = state.trafficRestrictions.find((item) => item.id === params.id)
      return restriction
        ? ok(restriction)
        : ok({ status: 404, message: 'Restriction not found' }, 404)
    },
  ),
  route(
    'PUT',
    '/invoke/support-admin/geo-balancing/traffic-restrictions/{id}',
    ({ state, params, body }) => {
      const index = state.trafficRestrictions.findIndex((item) => item.id === params.id)
      if (index < 0) return ok({ status: 404, message: 'Restriction not found' }, 404)
      state.trafficRestrictions[index] = {
        ...state.trafficRestrictions[index],
        ...body,
        id: params.id,
        updated: new Date().toISOString(),
        updatedBy: 'mock.admin',
      }
      return ok(state.trafficRestrictions[index])
    },
  ),
  route(
    'DELETE',
    '/invoke/support-admin/geo-balancing/traffic-restrictions/{id}',
    ({ state, params }) => {
      state.trafficRestrictions = state.trafficRestrictions.filter(
        (item) => item.id !== params.id,
      )
      return empty()
    },
  ),
]

export const mockRouteManifest = makeRoutes().map(({ method, path }) => ({
  method,
  path,
}))

export const createMockServer = ({
  port = DEFAULT_PORT,
  host = DEFAULT_HOST,
  quiet = false,
} = {}) => {
  let state = createInitialState()
  const routes = makeRoutes()
  const reset = () => {
    state = createInitialState()
    return state
  }

  const app = express()
  app.disable('x-powered-by')
  app.disable('etag')
  app.use(express.json({ limit: '2mb' }))
  app.use((request, response, next) => {
    response.setHeader('cache-control', 'no-store')
    response.setHeader('access-control-allow-origin', '*')
    response.setHeader('access-control-allow-headers', 'content-type, authorization')
    response.setHeader('access-control-allow-methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS')
    if (request.method === 'OPTIONS') return response.sendStatus(204)

    const startedAt = performance.now()
    response.once('finish', () => {
      if (quiet) return
      const duration = Math.round(performance.now() - startedAt)
      process.stdout.write(
        `[mock] ${request.method} ${request.originalUrl} -> ${response.statusCode} (${duration}ms)\n`,
      )
    })
    next()
  })

  const apiRouter = express.Router()
  for (const definition of routes) {
    apiRouter[definition.method.toLowerCase()](
      expressPath(definition.path),
      async (request, response, next) => {
        try {
          const url = new URL(
            request.originalUrl,
            `http://${request.headers.host ?? `${host}:${port}`}`,
          )
          const result = await definition.handler({
            state,
            reset,
            params: request.params,
            body: request.body,
            url,
            request,
          })
          const status = result?.status ?? 200
          if (result?.body === undefined || status === 204) {
            response.sendStatus(status)
          } else if (result.contentType === 'sse') {
            response.status(status)
            response.setHeader('content-type', 'text/event-stream')
            response.setHeader('connection', 'keep-alive')
            response.flushHeaders()

            const sendEvent = () => {
              const body = typeof result.body === 'function' ? result.body() : result.body
              response.write(`data: ${JSON.stringify(body)}\n\n`)
            }
            sendEvent()
            let timeout
            const scheduleEvent = () => {
              const interval =
                typeof result.interval === 'function' ? result.interval() : result.interval
              timeout = setTimeout(() => {
                sendEvent()
                scheduleEvent()
              }, interval)
            }
            scheduleEvent()
            request.once('close', () => clearTimeout(timeout))
          } else if (result.contentType === 'text') {
            response.status(status).type('text/plain').send(result.body)
          } else {
            response.status(status).json(result.body)
          }
        } catch (error) {
          next(error)
        }
      },
    )
  }

  app.use('/', apiRouter)
  app.use('/platform', apiRouter)
  app.use('/tkp', apiRouter)
  app.use((request, response) => {
    response.status(404).json({
      timestamp: new Date().toISOString(),
      status: 404,
      message: `No mock for ${request.method} ${request.path}`,
      path: request.path,
    })
  })
  app.use((error, request, response, _next) => {
    void _next
    response.status(error?.status ?? 400).json({
      timestamp: new Date().toISOString(),
      status: error?.status ?? 400,
      message: error instanceof Error ? error.message : 'Mock request failed',
      path: request.path,
    })
  })

  return new Promise((resolve, reject) => {
    const server = app.listen(port, host)
    server.once('error', reject)
    server.once('listening', () => {
      const address = server.address()
      const actualPort = typeof address === 'object' && address ? address.port : port
      resolve({
        app,
        server,
        url: `http://${host}:${actualPort}`,
        close: () =>
          new Promise((done, fail) => server.close((error) => (error ? fail(error) : done()))),
      })
    })
  })
}

const isDirectRun = process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href

if (isDirectRun) {
  const port = Number(process.env.MOCK_SERVER_PORT ?? DEFAULT_PORT)
  const host = process.env.MOCK_SERVER_HOST ?? DEFAULT_HOST
  const instance = await createMockServer({ port, host })
  process.stdout.write(`TCPF mock server: ${instance.url}\n`)
  process.stdout.write(`Health check: ${instance.url}/health\n`)

  const shutdown = async () => {
    await instance.close()
    process.exit(0)
  }
  process.once('SIGINT', shutdown)
  process.once('SIGTERM', shutdown)
}
