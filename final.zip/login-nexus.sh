#!/bin/bash
read -p "Nexus username: " u
read -sp "Nexus password: " p
echo
token=$(echo -n "$u:$p" | base64)

npm config set //nexus-ci.delta.sbrf.ru/repository/npm-all/:_auth "$token" --location=project

echo "Auth token set in project npmrc"
