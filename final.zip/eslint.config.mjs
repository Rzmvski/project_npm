import path from 'node:path'
import { fileURLToPath } from 'node:url'

import eslint from '@eslint/js'
import boundaries from 'eslint-plugin-boundaries'
import importPlugin from 'eslint-plugin-import'
import reactHooks from 'eslint-plugin-react-hooks'
import reactRefresh from 'eslint-plugin-react-refresh'
import globals from 'globals'
import tseslint from 'typescript-eslint'
import prettier from 'eslint-config-prettier'

const root = path.dirname(fileURLToPath(import.meta.url))

const boundaryPolicies = [
  {
    from: { element: { type: 'app' } },
    allow: {
      to: {
        element: {
          types: { anyOf: ['app', 'page', 'widget', 'feature', 'entity', 'shared'] },
        },
      },
    },
  },
  {
    from: { element: { type: 'page' } },
    allow: {
      to: {
        element: {
          types: { anyOf: ['page', 'widget', 'feature', 'entity', 'shared'] },
        },
      },
    },
  },
  {
    from: { element: { type: 'widget' } },
    allow: {
      to: { element: { types: { anyOf: ['widget', 'feature', 'entity', 'shared'] } } },
    },
  },
  {
    from: { element: { type: 'feature' } },
    allow: { to: { element: { types: { anyOf: ['feature', 'entity', 'shared'] } } } },
  },
  {
    from: { element: { type: 'entity' } },
    allow: { to: { element: { types: { anyOf: ['entity', 'shared'] } } } },
  },
  {
    from: { element: { type: 'shared' } },
    allow: { to: { element: { type: 'shared' } } },
  },
]

export default tseslint.config(
  {
    ignores: [
      'dist/**',
      'node_modules/**',
      'coverage/**',
      '.husky/_/**',
      'src/shared/deprecated/**',
    ],
  },
  {
    files: ['**/*.{js,mjs}'],
    ...eslint.configs.recommended,
    languageOptions: {
      ecmaVersion: 'latest',
      sourceType: 'module',
      globals: globals.node,
    },
  },
  ...tseslint.configs.recommended,
  {
    files: ['src/**/*.{ts,tsx}'],
    languageOptions: {
      ecmaVersion: 'latest',
      sourceType: 'module',
      globals: { ...globals.browser, ...globals.es2022 },
      parserOptions: {
        projectService: true,
        tsconfigRootDir: root,
      },
    },
    plugins: {
      import: importPlugin,
      boundaries,
      'react-hooks': reactHooks,
      'react-refresh': reactRefresh,
    },
    settings: {
      'import/resolver': {
        typescript: { project: './tsconfig.app.json' },
      },
      'boundaries/include': ['src/**/*'],
      'boundaries/elements': [
        { type: 'test', pattern: 'src/test/**' },
        { type: 'app', pattern: 'src/app/**' },
        { type: 'page', pattern: 'src/pages/*/**', capture: ['slice'] },
        { type: 'widget', pattern: 'src/widgets/*/**', capture: ['slice'] },
        { type: 'feature', pattern: 'src/features/*/**', capture: ['slice'] },
        { type: 'entity', pattern: 'src/entities/*/**', capture: ['slice'] },
        { type: 'shared', pattern: 'src/shared/**' },
      ],
    },
    rules: {
      ...reactHooks.configs.recommended.rules,
      ...reactRefresh.configs.vite.rules,
      'boundaries/no-unknown-dependencies': 'error',
      'boundaries/no-unknown-files': 'error',
      'boundaries/dependencies': [
        'error',
        {
          default: 'disallow',
          policies: boundaryPolicies,
        },
      ],
      'import/no-cycle': ['error', { maxDepth: 8, ignoreExternal: true }],
      'import/no-duplicates': 'error',
      'import/order': [
        'error',
        {
          groups: ['builtin', 'external', 'internal', 'parent', 'sibling', 'index', 'type'],
          pathGroups: [{ pattern: '@/**', group: 'internal', position: 'before' }],
          alphabetize: { order: 'asc', caseInsensitive: true },
          'newlines-between': 'always',
        },
      ],
      '@typescript-eslint/consistent-type-imports': [
        'error',
        { prefer: 'type-imports', fixStyle: 'inline-type-imports' },
      ],
      '@typescript-eslint/no-explicit-any': 'error',
      '@typescript-eslint/no-unused-vars': [
        'error',
        { argsIgnorePattern: '^_', varsIgnorePattern: '^_', caughtErrorsIgnorePattern: '^_' },
      ],
      'no-restricted-syntax': [
        'error',
        {
          selector:
            "JSXOpeningElement[name.name='button'], JSXOpeningElement[name.name='input'], JSXOpeningElement[name.name='select'], JSXOpeningElement[name.name='textarea']",
          message: 'Use the corresponding component from @v-uik/base.',
        },
      ],
    },
  },
  {
    files: [
      'src/**/*.{test,spec}.{ts,tsx}',
      'src/**/__tests__/**/*.{ts,tsx}',
      'src/**/*.test-model.{ts,tsx}',
    ],
    rules: {
      'boundaries/no-unknown-dependencies': 'off',
      'boundaries/no-unknown-files': 'off',
      'boundaries/dependencies': 'off',
      'import/no-cycle': 'off',
      'react-refresh/only-export-components': 'off',
      'no-restricted-syntax': 'off',
      '@typescript-eslint/no-explicit-any': 'off',
    },
  },
  {
    files: ['vite.config.ts'],
    languageOptions: { globals: globals.node },
    rules: {
      'boundaries/no-unknown-dependencies': 'off',
      'boundaries/no-unknown-files': 'off',
    },
  },
  prettier,
)
