export { revisionRequestSchema, type RevisionRequestSchemaType } from './model'
