export { serviceRegistry, ServiceId } from './model/registry'
export type { ServiceDefinition } from './model/types'
export { DashboardServiceCard } from './ui'
