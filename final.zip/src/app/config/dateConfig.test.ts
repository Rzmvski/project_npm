import { describe, it, expect, afterAll } from 'vitest'

describe('dateConfig', () => {
  const nativeToISOString = Date.prototype.toISOString

  afterAll(() => {
    Object.defineProperty(Date.prototype, 'toISOString', {
      value: nativeToISOString,
      configurable: true,
      writable: true,
    })
  })

  it('импорт модуля не падает', async () => {
    await expect(import('./dateConfig')).resolves.toBeDefined()
  })

  it('toISOString возвращает валидную ISO-строку', async () => {
    await import('./dateConfig')

    const date = new Date(2024, 0, 15, 10, 30, 0)
    const isoString = date.toISOString()

    expect(typeof isoString).toBe('string')
    expect(isoString).toMatch(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}/)
  })
})
