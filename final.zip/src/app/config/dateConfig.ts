const toISOString = Date.prototype.toISOString

function toLocalISOString(this: Date) {
  const offset = this.getTimezoneOffset() * 60_000
  return toISOString.call(new Date(this.getTime() - offset))
}

export default Object.defineProperty(Date.prototype, 'toISOString', {
  value: toLocalISOString,
  configurable: true,
  writable: false,
})
