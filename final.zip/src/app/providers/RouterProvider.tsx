import { RouterProvider as TanStackRouterProvider } from '@tanstack/react-router'
import React, { type FC } from 'react'

import { queryClient } from '@/app/config/queryClient'
import { createAppRouter } from '@/app/routes/router'

export const RouterProvider: FC = () => {
  const router = createAppRouter(queryClient)

  return <TanStackRouterProvider router={router} />
}
