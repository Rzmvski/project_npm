import { QueryClientProvider } from '@tanstack/react-query'
import React, { type FC } from 'react'

import { queryClient } from '@/app/config/queryClient'
import { AppThemeProvider } from '@/app/providers/AppThemeProvider'
import { DateAdapter } from '@/app/providers/DateAdapter'

import { RouterProvider } from './RouterProvider'


export const AppProviders: FC = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <AppThemeProvider>
        <DateAdapter>
          <RouterProvider />
        </DateAdapter>
      </AppThemeProvider>
    </QueryClientProvider>
  )
}
