import { createTheme, ThemeProvider } from '@v-uik/base'
import React, { type FC, type PropsWithChildren } from 'react'

export const AppThemeProvider: FC<PropsWithChildren> = ({ children }) => {
  const theme = createTheme({
    sys: {
      color: {
        primaryAlpha: 'var(--color-primary-400)',
        primaryBeta: 'var(--color-primary-600)',
        primaryGamma: 'var(--color-primary-light)',

        secondaryAlpha: 'var(--color-secondary-400)',
        secondaryBeta: 'var(--color-secondary-500)',
        secondaryGamma: 'var(--color-secondary-600)',

        neutralAlpha: 'var(--color-secondary-100)',
        neutralBeta: 'var(--color-secondary-200)',
        neutralGamma: 'var(--color-secondary-300)',

        focus: 'var(--color-primary-400)',

        backgroundComponent: 'white',
      },
    },

    comp: {
      backwardCompatibilityMode: false,

      underlay: {
        colorBackgroundFilledNeutral: 'var(--bg-gray-50)',
        colorBorderFilledNeutral: 'var(--border-color)',

        colorBackgroundFilledInfo: 'var(--bg-blue-50)',
        colorBorderFilledInfo: 'var(--text-blue-500)',

        colorBackgroundFilledSuccess: 'var(--bg-green-50)',
        colorBorderFilledSuccess: 'var(--text-green-500)',

        colorBackgroundFilledWarning: 'var(--bg-orange-50)',
        colorBorderFilledWarning: 'var(--text-yellow-500)',
      },

      card: {
        colorBackgroundClickableHover: 'var(--bg-gray-50)',
      },

      tooltip: {
        typographyFontSize: 'var(--font-size-xs)',
        typographyLineHeight: '1rem',
      },

      accordion: {
        colorBorder: 'transparent',
      },

      accordionItem: {
        // @ts-expect-error not part of the @v-uik/base theme type definitions
        shapeBorderRadiusBottomLeft: 'var(--border-radius)',
        // @ts-expect-error not part of the @v-uik/base theme type definitions
        shapeBorderRadiusBottomRight: 'var(--border-radius)',
        // @ts-expect-error not part of the @v-uik/base theme type definitions
        shapeBorderRadiusTopLeft: 'var(--border-radius)',
        // @ts-expect-error not part of the @v-uik/base theme type definitions
        shapeBorderRadiusTopRight: 'var(--border-radius)',
        colorBorder: 'transparent',
        colorBackgroundHover: 'var(--border-color)',
        colorText: 'var(--text-gray-600)',
      },

      tag: {
        shapeBorderRadiusBottomLeft: 'var(--border-radius-xl)',
        shapeBorderRadiusBottomRight: 'var(--border-radius-xl)',
        shapeBorderRadiusTopLeft: 'var(--border-radius-xl)',
        shapeBorderRadiusTopRight: 'var(--border-radius-xl)',

        colorBackgroundLiteSelected: 'var(--bg-gray-50)',
        colorBorderLite: 'var(--border-color)',
        colorTextLite: 'var(--text-gray-700)',

        colorBackgroundGreen: '#dcfce7',
        colorTextGreen: '#166534',

        colorBackgroundRed: '#fee2e2',
        colorTextRed: '#991b1b',

        typographyFontSize: 'var(--font-size-xs)',
        // @ts-expect-error not part of the @v-uik/base theme type definitions
        typographyFontWeight: 'var(--font-weight-medium)',
      },

      inputLabel: {
        colorText: 'var(--text-gray-500)',
        typographyFontSize: 'var(--font-size-xs)',
      },
    },
  })

  return <ThemeProvider theme={theme}>{children}</ThemeProvider>
}
