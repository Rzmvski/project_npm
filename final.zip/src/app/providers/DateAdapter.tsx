import { DateLibAdapterProvider } from '@v-uik/base'
import { DateFnsAdapter } from '@v-uik/date-picker/dist/adapters/esm/date-fns'
import { ru } from 'date-fns/locale'
import React, { type FC, type PropsWithChildren } from 'react'

export const DateAdapter: FC<PropsWithChildren> = ({ children }) => {
  return (
    <DateLibAdapterProvider
      dateAdapter={DateFnsAdapter}
      options={{
        locale: ru,
        formats: {
          weekdayShort: 'EEEEEE',
        },
      }}
    >
      {children}
    </DateLibAdapterProvider>
  )
}
