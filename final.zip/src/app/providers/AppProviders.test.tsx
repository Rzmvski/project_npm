import { useQueryClient } from '@tanstack/react-query'
import { render, screen } from '@testing-library/react'
import { describe, it, expect, vi } from 'vitest'

import { AppProviders } from './index'

vi.mock('./RouterProvider', () => ({
  RouterProvider: () => {
    const queryClient = useQueryClient()
    return <div data-testid='router-provider'>{queryClient ? 'ready' : 'missing'}</div>
  },
}))

describe('AppProviders', () => {
  it('рендерит RouterProvider внутри композиции провайдеров приложения', () => {
    render(<AppProviders />)

    expect(screen.getByTestId('router-provider')).toBeInTheDocument()
  })

  it('RouterProvider получает доступ к QueryClient из QueryClientProvider', () => {
    render(<AppProviders />)

    expect(screen.getByTestId('router-provider')).toHaveTextContent('ready')
  })
})
