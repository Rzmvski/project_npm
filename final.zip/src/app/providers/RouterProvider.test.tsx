import { render, screen } from '@testing-library/react'
import { describe, it, expect, vi } from 'vitest'

const mocks = vi.hoisted(() => ({
  routerProviderMock: vi.fn(() => <div data-testid='tanstack-router-provider' />),
  createAppRouterMock: vi.fn(() => 'mock-router'),
}))

vi.mock('@tanstack/react-router', async (importOriginal) => {
  const actual = await importOriginal<typeof TanStackReactRouter>()
  return {
    ...actual,
    RouterProvider: mocks.routerProviderMock,
  }
})

vi.mock('@/app/routes/router', () => ({
  createAppRouter: mocks.createAppRouterMock,
}))

import { RouterProvider } from './RouterProvider'

import type * as TanStackReactRouter from '@tanstack/react-router'

describe('RouterProvider', () => {
  it('рендерит TanStack RouterProvider, настроенный на роутер приложения', () => {
    render(<RouterProvider />)

    expect(mocks.createAppRouterMock).toHaveBeenCalledTimes(1)
    expect(screen.getByTestId('tanstack-router-provider')).toBeInTheDocument()
    expect(mocks.routerProviderMock).toHaveBeenCalledWith(
      expect.objectContaining({ router: 'mock-router' }),
      undefined,
    )
  })
})
