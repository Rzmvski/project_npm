import React, { type FC } from 'react'

import { AppProviders } from '@/app/providers'
import './styles/global.scss'
import '@/shared/styles/tokens.scss'
import '@/app/config/dateConfig'

export const App: FC = () => {
  return <AppProviders />
}
