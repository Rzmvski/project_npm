import {
  createRootRouteWithContext,
  createRoute,
  lazyRouteComponent,
  redirect,
  type RouteComponent,
} from '@tanstack/react-router'

import { AppLayout, ServiceLayout } from '@/app/layouts'
import { type RouterContext } from '@/app/routes/routerContext'
import { ServiceId, serviceRegistry } from '@/entities/service'
import { DesktopPage } from '@/pages/desktop'
import { ErrorPage } from '@/pages/error'
import { ForbiddenPage } from '@/pages/forbidden'
import { NotFoundPage } from '@/pages/not-found'
import { ROUTES } from '@/shared/config'
import { userQueryOptions } from '@/entities/user'
import { hasAllAuthorities, hasAuthorityWithSubstring } from '@/features/access-check/lib'
import { PermissionType } from '@/shared/model'

const CloseTradingDayPage = lazyRouteComponent(
  () => import('@/pages/close-od'),
  'CloseTradingDayPage',
)

const StartProcessGroupPage = lazyRouteComponent(
  () => import('@/pages/start-process-group'),
  'StartProcessGroupPage',
)

const IndexManagementPage = lazyRouteComponent(
  () => import('@/pages/index-management'),
  'IndexManagementPage',
)

const ShardInfoPage = lazyRouteComponent(() => import('@/pages/shard-info'), 'ShardInfoPage')

const ScriptRunnerPage = lazyRouteComponent(
  () => import('@/pages/script-runner'),
  'ScriptRunnerPage',
)

const NodeBalancingPage = lazyRouteComponent(
  () => import('@/pages/node-balancing'),
  'NodeBalancingPage',
)

const FeatureTogglingPage = lazyRouteComponent(
  () => import('@/pages/feature-toggling'),
  'FeatureTogglingPage',
)

const ClusterManagementPage = lazyRouteComponent(
  () => import('@/pages/cluster-management'),
  'ClusterManagementPage',
)

const ReviseReplicationPage = lazyRouteComponent(
  () => import('@/pages/revise-replication'),
  'ReviseReplicationPage',
)

const GeoBalancingPage = lazyRouteComponent(
  () => import('@/pages/geo-balancing'),
  'GeoBalancingPage',
)

export const rootRoute = createRootRouteWithContext<RouterContext>()({
  component: AppLayout,

  notFoundComponent: () => (
    <ServiceLayout>
      <NotFoundPage />
    </ServiceLayout>
  ),
})

const indexRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/',

  beforeLoad: async ({ context }) => {
    const { roles } = await context.queryClient.ensureQueryData(userQueryOptions())
    if (!hasAuthorityWithSubstring(roles, 'ADMIN')) {
      throw redirect({
        to: ROUTES.FORBIDDEN,
        replace: true,
      })
    }
  },

  component: DesktopPage,
})

const serviceLayoutRoute = createRoute({
  getParentRoute: () => rootRoute,
  id: 'service-layout',
  component: ServiceLayout,

  errorComponent: ({ reset }) => (
    <ServiceLayout>
      <ErrorPage onRetry={reset} />
    </ServiceLayout>
  ),
})

function createSecuredServiceRoute(serviceId: ServiceId, component: RouteComponent) {
  const service = serviceRegistry[serviceId]

  return createRoute({
    getParentRoute: () => serviceLayoutRoute,
    path: service.route,

    beforeLoad: async ({ context }) => {
      const { permissions } = await context.queryClient.ensureQueryData(userQueryOptions())
      const required = service.permissions
      if (!hasAllAuthorities(permissions, required)) {
        throw redirect({
          to: ROUTES.FORBIDDEN,
          replace: true,
        })
      }
    },

    head: () => ({
      meta: [
        {
          title: service.title,
        },
      ],
    }),

    component,
  })
}

const closeTradingDayRoute = createSecuredServiceRoute(
  ServiceId.CLOSE_TRADING_DAY,
  CloseTradingDayPage,
)

const startProcessGroupRoute = createSecuredServiceRoute(
  ServiceId.START_PROCESS_GROUP,
  StartProcessGroupPage,
)

const indexManagementRoute = createSecuredServiceRoute(
  ServiceId.INDEX_MANAGEMENT,
  IndexManagementPage,
)

const shardInfoRoute = createSecuredServiceRoute(ServiceId.SHARD_INFO, ShardInfoPage)

const scriptRunnerRoute = createSecuredServiceRoute(ServiceId.SCRIPT_RUNNER, ScriptRunnerPage)

const nodeBalancingRoute = createSecuredServiceRoute(
  ServiceId.NODE_BALANCING,
  NodeBalancingPage,
)

const featureTogglingRoute = createSecuredServiceRoute(
  ServiceId.FEATURE_TOGGLING,
  FeatureTogglingPage,
)

const clusterManagementRoute = createSecuredServiceRoute(
  ServiceId.CLUSTER_MANAGEMENT,
  ClusterManagementPage,
)

const reviseReplicationRoute = createSecuredServiceRoute(
  ServiceId.REVISE_REPLICATION,
  ReviseReplicationPage,
)

const geoBalancingRoute = createSecuredServiceRoute(ServiceId.GEO_BALANCING, GeoBalancingPage)

const forbiddenRoute = createRoute({
  getParentRoute: () => serviceLayoutRoute,
  path: ROUTES.FORBIDDEN,

  head: () => ({
    meta: [{ title: 'Нет доступа' }],
  }),

  component: ForbiddenPage,
})

const notFoundRoute = createRoute({
  getParentRoute: () => serviceLayoutRoute,
  path: ROUTES.NOT_FOUND,

  head: () => ({
    meta: [{ title: 'Страница не найдена' }],
  }),

  component: NotFoundPage,
})

const errorRoute = createRoute({
  getParentRoute: () => serviceLayoutRoute,
  path: ROUTES.ERROR,

  head: () => ({
    meta: [{ title: 'Ошибка' }],
  }),

  component: ErrorPage,
})

const serviceRoutes = serviceLayoutRoute.addChildren([
  closeTradingDayRoute,
  startProcessGroupRoute,
  indexManagementRoute,
  shardInfoRoute,
  scriptRunnerRoute,
  nodeBalancingRoute,
  featureTogglingRoute,
  clusterManagementRoute,
  reviseReplicationRoute,
  geoBalancingRoute,

  forbiddenRoute,
  notFoundRoute,
  errorRoute,
])

export const routeTree = rootRoute.addChildren([indexRoute, serviceRoutes])
