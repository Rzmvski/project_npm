import { Outlet } from '@tanstack/react-router'
import { screen } from '@testing-library/react'
import { describe, expect, it, vi } from 'vitest'

import { AppRoutesTestModel } from './routeTree.test-model'

vi.mock('@/app/layouts', () => ({
  AppLayout: () => (
    <main aria-label='Приложение'>
      <Outlet />
    </main>
  ),
  ServiceLayout: ({ children }: { children?: React.ReactNode }) => (
    <section aria-label='Сервис'>{children ?? <Outlet />}</section>
  ),
}))

vi.mock('@/pages/desktop', () => ({
  DesktopPage: () => <h1>Главная страница</h1>,
}))

vi.mock('@/pages/forbidden', () => ({
  ForbiddenPage: () => <h1>Доступ запрещён</h1>,
}))

vi.mock('@/pages/error', () => ({
  ErrorPage: () => <h1>Что-то пошло не так</h1>,
}))

vi.mock('@/pages/not-found', () => ({
  NotFoundPage: () => <h1>Страница не найдена</h1>,
}))

vi.mock('@/pages/close-od', () => ({ CloseTradingDayPage: () => <h1>Закрытие дня</h1> }))
vi.mock('@/pages/start-process-group', () => ({
  StartProcessGroupPage: () => <h1>Запуск процессов</h1>,
}))
vi.mock('@/pages/index-management', () => ({
  IndexManagementPage: () => <h1>Индексы</h1>,
}))
vi.mock('@/pages/shard-info', () => ({ ShardInfoPage: () => <h1>Поиск шарда</h1> }))
vi.mock('@/pages/script-runner', () => ({ ScriptRunnerPage: () => <h1>Скрипты</h1> }))
vi.mock('@/pages/node-balancing', () => ({ NodeBalancingPage: () => <h1>Ноды</h1> }))
vi.mock('@/pages/feature-toggling', () => ({
  FeatureTogglingPage: () => <h1>Фичи</h1>,
}))
vi.mock('@/pages/cluster-management', () => ({
  ClusterManagementPage: () => <h1>Кластеры</h1>,
}))
vi.mock('@/pages/revise-replication', () => ({
  ReviseReplicationPage: () => <h1>Сверка</h1>,
}))
vi.mock('@/pages/geo-balancing', () => ({ GeoBalancingPage: () => <h1>Трафик</h1> }))

vi.mock('@/features/access-check', () => ({
  AccessGuard: ({ children }: { children: React.ReactNode }) => children,
}))

vi.mock('@/shared/ui/ErrorBoundary', () => ({
  ErrorBoundary: () => <h1>Ошибка сервиса</h1>,
}))

// `beforeLoad` on the routes calls `ensureQueryData(userQueryOptions())`, which
// would otherwise hit the real API client. Resolve it with harmless data and
// let the guard checks always pass, since permission logic itself is covered
// by `features/access-check/lib/checks.test.ts`.
vi.mock('@/entities/user', () => ({
  userQueryOptions: () => ({
    queryKey: ['user'],
    queryFn: async () => ({ roles: [], permissions: [] }),
  }),
}))

vi.mock('@/features/access-check/lib', () => ({
  hasAllAuthorities: () => true,
  hasAuthorityWithSubstring: () => true,
}))

describe('application routes', () => {
  it.each([
    ['/', 'Главная страница'],
    ['/forbidden', 'Доступ запрещён'],
    ['/error', 'Что-то пошло не так'],
    ['/unknown', 'Страница не найдена'],
    ['/close-trading-day', 'Закрытие дня'],
    ['/start-process-group', 'Запуск процессов'],
    ['/index-management', 'Индексы'],
    ['/shard-info', 'Поиск шарда'],
    ['/script-runner', 'Скрипты'],
    ['/node-balancing', 'Ноды'],
    ['/feature-toggling', 'Фичи'],
    ['/cluster-management', 'Кластеры'],
    ['/revise-replication', 'Сверка'],
    ['/geo-balancing', 'Трафик'],
  ])('renders the page assigned to %s', async (path, heading) => {
    const app = AppRoutesTestModel.open(path)

    expect(await app.expectPage(heading)).toBeVisible()
  })

  it.each(['/forbidden', '/error', '/not-found', '/unknown'])(
    'renders the system page %s inside ServiceLayout',
    async (path) => {
      AppRoutesTestModel.open(path)

      expect(await screen.findByRole('region', { name: 'Сервис' })).toBeVisible()
    },
  )
})
