import { createMemoryHistory, createRouter, RouterProvider } from '@tanstack/react-router'
import { render, screen } from '@testing-library/react'

import { queryClient } from '@/app/config/queryClient'

import { routeTree } from './routeTree'

export class AppRoutesTestModel {
  private constructor() {}

  static open(path: string) {
    const router = createRouter({
      routeTree,
      history: createMemoryHistory({ initialEntries: [path] }),
      context: {
        queryClient,
      },
    })

    render(<RouterProvider router={router} />)

    return new AppRoutesTestModel()
  }

  expectPage(name: string) {
    return screen.findByRole('heading', { name })
  }
}
