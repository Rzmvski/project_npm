export { IndexManagementPage } from './ui/IndexManagementPage'
