import { ClusterStateDto, IndexActionsDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

export const PENDING_INDEX_ACTIONS_QUERY_KEY = ['pending-index-actions'] as const

export interface PendingIndexAction {
  action: IndexActionsDto
  message: string
  finalState: ClusterStateDto
}

export type PendingIndexActions = Record<string, PendingIndexAction>

export const getFinalState = (action: IndexActionsDto): ClusterStateDto =>
  action === IndexActionsDto.CreateIndex ? ClusterStateDto.Active : ClusterStateDto.Inactive
