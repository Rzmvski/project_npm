import { type IndexActionResponseDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { type IndexCluster } from '@/entities/index-cluster'

export type ManagedClusterItem = Pick<IndexCluster, 'clusterId' | 'availableActions'> &
  IndexActionResponseDto
