import { type IndexActionsDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { notification } from '@v-uik/base'

import { actionConfig, fetchChangeState } from '@/features/manage-indexes'

import {
  getFinalState,
  PENDING_INDEX_ACTIONS_QUERY_KEY,
  type PendingIndexActions,
} from '../model/pendingAction'

interface UseManageIndexesParams {
  clusterId: string
  action: IndexActionsDto
}

export const useManageIndexes = ({ clusterId, action }: UseManageIndexesParams) => {
  const queryClient = useQueryClient()
  const { mutate, isPending } = useMutation({
    mutationFn: () => fetchChangeState(clusterId, action),
    onSuccess: ({ code, description }) => {
      const config = actionConfig[action]
      if (code !== 0 || !config) {
        notification.error(description, { direction: 'vertical' })
        return
      }
      queryClient.setQueryData<PendingIndexActions>(
        PENDING_INDEX_ACTIONS_QUERY_KEY,
        (current = {}) => ({
          ...current,
          [clusterId]: {
            action,
            message: config.message,
            finalState: getFinalState(action),
          },
        }),
      )
      return queryClient.invalidateQueries({
        queryKey: ['clusters'],
      })
    },
  })

  return { mutate, isPending }
}
