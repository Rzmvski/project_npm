import { renderHook } from '@testing-library/react'

import { useIndexActionNotifications } from './useIndexActionNotifications'

const mocks = vi.hoisted(() => ({
  success: vi.fn(),
  setQueryData: vi.fn(),
  pending: {
    done: { finalState: 'ACTIVE', message: 'Индекс создан' },
    waiting: { finalState: 'ACTIVE', message: 'Ещё выполняется' },
  },
}))
vi.mock('@v-uik/base', () => ({ notification: { success: mocks.success } }))
vi.mock('@tanstack/react-query', () => ({
  useQueryClient: () => ({ setQueryData: mocks.setQueryData }),
  useQuery: (config: Record<string, any>) => {
    config.queryFn()
    return { data: mocks.pending }
  },
}))
vi.mock('../model/pendingAction', () => ({ PENDING_INDEX_ACTIONS_QUERY_KEY: ['pending'] }))

it('useIndexActionNotifications уведомляет о завершении и удаляет только завершённые ожидания', () => {
  renderHook(() =>
    useIndexActionNotifications([
      { clusterId: 'done', state: 'ACTIVE', updateRequired: false },
      { clusterId: 'waiting', state: 'ACTIVE', updateRequired: true },
    ] as never),
  )

  expect(mocks.success).toHaveBeenCalledWith('Индекс создан', { direction: 'vertical' })
  const updater = mocks.setQueryData.mock.calls[0]?.[1]
  expect(updater(mocks.pending)).toEqual({ waiting: mocks.pending.waiting })
})

it('useIndexActionNotifications ничего не меняет без завершённых действий', () => {
  mocks.setQueryData.mockClear()
  mocks.success.mockClear()
  renderHook(() => useIndexActionNotifications([]))
  expect(mocks.setQueryData).not.toHaveBeenCalled()
  expect(mocks.success).not.toHaveBeenCalled()
})
