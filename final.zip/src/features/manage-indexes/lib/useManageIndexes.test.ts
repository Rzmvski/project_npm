import { act, renderHook } from '@testing-library/react'

import { useManageIndexes } from './useManageIndexes'

const mocks = vi.hoisted(() => ({
  config: null as Record<string, any> | null,
  fetch: vi.fn(),
  error: vi.fn(),
  setQueryData: vi.fn(),
  invalidate: vi.fn(),
}))
vi.mock('@tanstack/react-query', () => ({
  useQueryClient: () => ({ setQueryData: mocks.setQueryData, invalidateQueries: mocks.invalidate }),
  useMutation: (config: Record<string, any>) => {
    mocks.config = config
    return { mutate: () => config.mutationFn(), isPending: false }
  },
}))
vi.mock('@v-uik/base', () => ({ notification: { error: mocks.error } }))
vi.mock('@/features/manage-indexes', () => ({
  actionConfig: { CREATE: { message: 'Индекс создаётся' } },
  fetchChangeState: (...args: unknown[]) => mocks.fetch(...args),
}))
vi.mock('../model/pendingAction', () => ({
  PENDING_INDEX_ACTIONS_QUERY_KEY: ['pending'],
  getFinalState: () => 'ACTIVE',
}))

describe('useManageIndexes', () => {
  it('запускает действие, сохраняет ожидание и обновляет кластеры', () => {
    const { result } = renderHook(() => useManageIndexes({ clusterId: 'cluster-1', action: 'CREATE' as never }))
    act(() => result.current.mutate())
    expect(mocks.fetch).toHaveBeenCalledWith('cluster-1', 'CREATE')

    mocks.config?.onSuccess({ code: 0 })
    const updater = mocks.setQueryData.mock.calls.at(-1)?.[1]
    expect(updater()).toEqual({
      'cluster-1': { action: 'CREATE', message: 'Индекс создаётся', finalState: 'ACTIVE' },
    })
    expect(mocks.invalidate).toHaveBeenCalledWith({ queryKey: ['clusters'] })
  })

  it('показывает ошибку отказа сервера', () => {
    renderHook(() => useManageIndexes({ clusterId: 'cluster-1', action: 'CREATE' as never }))
    mocks.config?.onSuccess({ code: 5, description: 'Недоступно' })
    expect(mocks.error).toHaveBeenCalledWith('Недоступно', { direction: 'vertical' })
  })
})
