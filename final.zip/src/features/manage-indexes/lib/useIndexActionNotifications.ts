import { useQuery, useQueryClient } from '@tanstack/react-query'
import { notification } from '@v-uik/base'
import { useEffect } from 'react'

import { type IndexCluster } from '@/entities/index-cluster'

import { PENDING_INDEX_ACTIONS_QUERY_KEY, type PendingIndexActions } from '../model/pendingAction'

export const useIndexActionNotifications = (clusters: IndexCluster[]) => {
  const queryClient = useQueryClient()
  const { data: pendingActions = {} } = useQuery<PendingIndexActions>({
    queryKey: PENDING_INDEX_ACTIONS_QUERY_KEY,
    queryFn: () => ({}),
    initialData: {},
    staleTime: Number.POSITIVE_INFINITY,
  })

  useEffect(() => {
    const completedIds = Object.entries(pendingActions)
      .filter(([clusterId, pending]) => {
        const cluster = clusters.find((item) => item.clusterId === clusterId)
        return cluster && !cluster.updateRequired && cluster.state === pending.finalState
      })
      .map(([clusterId, pending]) => {
        notification.success(pending.message, { direction: 'vertical' })
        return clusterId
      })

    if (!completedIds.length) return
    queryClient.setQueryData<PendingIndexActions>(
      PENDING_INDEX_ACTIONS_QUERY_KEY,
      (current = {}) =>
        Object.fromEntries(
          Object.entries(current).filter(([id]) => !completedIds.includes(id)),
        ),
    )
  }, [clusters, pendingActions, queryClient])
}
