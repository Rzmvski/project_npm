import { type IndexActionsDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

type ConfirmConfig = {
  title: string
  text: string
}

type ActionsConfig = {
  text: string
  tooltip: string
  message: string
  confirmConfig?: ConfirmConfig
}

export const actionConfig: Record<IndexActionsDto, Nullable<ActionsConfig>> = {
  CANCEL_LOADING: {
    text: 'Отмена',
    tooltip: 'Переход к статусу INACTIVE (not read/not write)',
    message: 'Загрузка отменена',
  },
  CREATE_INDEX: {
    text: 'Пересоздать индексы',
    tooltip:
      'Переход к статусу ON_LOADING (write only). Потребуется некоторое время для пересоздания индексов',
    message: 'Обработка кластера выполнена успешно',
    confirmConfig: {
      title: 'Пересоздать',
      text: 'Вы действительно хотите пересоздать индексы? Процесс займет некоторое время',
    },
  },
  DEACTIVATE: {
    text: 'Деактивировать',
    tooltip: 'Переход к статусу INACTIVE (not read/not write)',
    message: 'Обработка кластера выполнена успешно',
  },
  UNRECOGNIZED: null,
} as const
