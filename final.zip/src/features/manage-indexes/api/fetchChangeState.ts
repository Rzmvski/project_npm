import { type IndexActionResponseDto, type IndexActionsDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { v4 as uuid } from 'uuid'

import { zoneIndexService } from '@/shared/api'

const generateUid = () => uuid().replace(/-/g, '')

export function fetchChangeState(
  clusterId: string,
  action: IndexActionsDto,
): Promise<IndexActionResponseDto> {
  const rqUid = generateUid()
  return zoneIndexService.indexesExecute({
    actionRequest: {
      clusterId,
      action,
    },
    rqUid,
    rqTm: new Date(),
    auditInfo: {
      additionalParams: {
        clusterId,
        action,
      },
    },
  })
}
