import { IndexActionsDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { fetchChangeState } from './fetchChangeState'

const indexesExecute = vi.hoisted(() => vi.fn())
vi.mock('@/shared/api', () => ({ zoneIndexService: { indexesExecute } }))
vi.mock('uuid', () => ({ v4: () => '1234-5678-abcd' }))

it('fetchChangeState формирует команду с audit и uid без дефисов', () => {
  fetchChangeState('cluster-1', IndexActionsDto.Deactivate)
  expect(indexesExecute).toHaveBeenCalledWith({
    actionRequest: {
      clusterId: 'cluster-1',
      action: IndexActionsDto.Deactivate,
    },
    rqUid: '12345678abcd',
    rqTm: expect.any(Date),
    auditInfo: {
      additionalParams: {
        clusterId: 'cluster-1',
        action: IndexActionsDto.Deactivate,
      },
    },
  })
})
