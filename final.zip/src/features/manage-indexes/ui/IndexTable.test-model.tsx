import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'

import { IndexTable } from './IndexTable'

export class IndexTableTestModel {
  private constructor() {}

  static open() {
    render(<IndexTable />)
    return new IndexTableTestModel()
  }

  action(name: string) {
    return screen.getByRole('button', { name })
  }

  async run(name: string) {
    await userEvent.click(this.action(name))
  }
}
