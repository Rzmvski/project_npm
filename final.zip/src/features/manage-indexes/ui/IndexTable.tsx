import { type ClusterStateDto, IgniteTypeDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { type ColumnDef } from '@tanstack/react-table'
import { Button, CircularProgress, LinearProgress, Tooltip } from '@v-uik/base'
import React, { type FC, useMemo } from 'react'

import { type IndexCluster, IndexStatus, useIndexClusters } from '@/entities/index-cluster'
import { MonitoringStatus, useMonitoring } from '@/entities/monitoring'
import {
  actionConfig,
  useIndexActionNotifications,
  useManageIndexes,
} from '@/features/manage-indexes'
import { useConfirm, useManagedRow, usePinnedColumns } from '@/shared/lib'
import { Table } from '@/shared/ui/Table'

import styles from './IndexTable.module.scss'

const IndexActionCell: FC<{ cluster: IndexCluster }> = ({ cluster }) => {
  const { clusterId, availableActions } = cluster
  const { mutate, isPending } = useManageIndexes({
    clusterId,
    action: availableActions,
  })
  const confirm = useConfirm()
  const config = actionConfig[availableActions]

  if (!config) return null
  const { text, tooltip, confirmConfig } = config

  const handleClick = async () => {
    if (confirmConfig) {
      const isConfirmed = await confirm(confirmConfig)
      if (!isConfirmed) return
    }
    mutate()
  }

  return (
    <CircularProgress isLoading={isPending}>
      <Tooltip dropdownProps={{ content: tooltip }}>
        <Button kind={'ghost'} onClick={handleClick}>
          {text}
        </Button>
      </Tooltip>
    </CircularProgress>
  )
}

export const IndexTable: FC = () => {
  const { clusters, isLoading, isPolling } = useIndexClusters()
  useIndexActionNotifications(clusters)
  const { monitoringEntities } = useMonitoring({
    monitoringType: IgniteTypeDto.Index,
  })

  const columns: ColumnDef<IndexCluster>[] = useMemo(
    () => [
      {
        header: 'ID кластера',
        accessorKey: 'clusterId',
      },
      {
        header: 'Кол-во записей',
        accessorKey: 'indexesCount',
        cell: ({ getValue }) => {
          const indexesCount = getValue<number>()
          if (indexesCount < 0) return 'неизвестно'
          return indexesCount
        },
      },
      {
        header: 'Мониторинг',
        cell: ({ row: { original } }) => {
          const { clusterId } = original
          return <MonitoringStatus monitoring={monitoringEntities[clusterId]} />
        },
      },
      {
        header: 'Статус',
        accessorKey: 'state',
        cell: ({ getValue }) => {
          const status = getValue<ClusterStateDto>()
          return <IndexStatus status={status} />
        },
      },
    ],
    [monitoringEntities],
  )
  const pinnedColumnsPlugin = usePinnedColumns<IndexCluster>({
    left: ['clusterId'],
  })
  const managedRowPlugin = useManagedRow<IndexCluster>({
    options: {
      header: 'Действие',
      minSize: 150,
    },
    template: ({ row: { original } }) => <IndexActionCell cluster={original} />,
  })

  return (
    <div className={styles.content}>
      <Table
        data={clusters}
        columns={columns}
        loading={isLoading}
        plugins={[pinnedColumnsPlugin, managedRowPlugin]}
      />
      {isPolling && <LinearProgress />}
    </div>
  )
}
