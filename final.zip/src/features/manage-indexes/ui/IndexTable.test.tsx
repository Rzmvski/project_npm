import { ClusterStateDto, IndexActionsDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { screen, waitFor } from '@testing-library/react'

import { IndexTableTestModel } from './IndexTable.test-model'

const mocks = vi.hoisted(() => ({
  cluster: {
    clusterId: 'cluster-1',
    indexesCount: 42,
    state: 'ACTIVE',
    availableActions: 'DEACTIVATE',
  } as Record<string, unknown>,
  mutate: vi.fn(),
  notify: vi.fn(),
  confirm: vi.fn().mockResolvedValue(true),
  polling: false,
}))

vi.mock('@/entities/index-cluster', () => ({
  useIndexClusters: () => ({
    clusters: [mocks.cluster],
    isLoading: false,
    isPolling: mocks.polling,
  }),
  IndexStatus: ({ status }: { status: string }) => <span>{`Статус: ${status}`}</span>,
}))

vi.mock('@/entities/monitoring', () => ({
  useMonitoring: () => ({
    monitoringEntities: { 'cluster-1': { status: 'UP' } },
  }),
  MonitoringStatus: ({ monitoring }: { monitoring?: { status: string } }) => (
    <span>{`Мониторинг: ${monitoring?.status ?? 'нет'}`}</span>
  ),
}))

vi.mock('@/features/manage-indexes', async () => {
  const actual = await vi.importActual<object>('@/features/manage-indexes')
  return {
    ...actual,
    useManageIndexes: () => ({ mutate: mocks.mutate, isPending: false }),
    useIndexActionNotifications: mocks.notify,
  }
})

vi.mock('@/shared/lib', async () => {
  const actual = await vi.importActual<object>('@/shared/lib')
  return {
    ...actual,
    useConfirm: () => mocks.confirm,
    useManagedRow: (config: unknown) => ({ kind: 'managed', config }),
  }
})

vi.mock('@/shared/ui/Table', () => ({
  Table: ({
    data,
    columns,
    plugins = [],
  }: {
    data: Array<Record<string, unknown>>
    columns: Array<Record<string, any>>
    plugins?: Array<Record<string, any>>
  }) => {
    const original = data[0]
    const managed = plugins.find(({ kind }) => kind === 'managed')
    return (
      <div role='table'>
        {columns.map((column, index) => {
          if (!column.cell || !original) return null
          const key = column.accessorKey
          return (
            <div key={column.id ?? key ?? index}>
              {column.cell({
                row: { original },
                getValue: () => (key ? original[key] : undefined),
              })}
            </div>
          )
        })}
        {original && managed?.config.template({ row: { original } })}
      </div>
    )
  },
}))

vi.mock('@v-uik/base', async () => {
  const actual = await vi.importActual<object>('@v-uik/base')
  return {
    ...actual,
    Button: ({ children, onClick }: React.ButtonHTMLAttributes<HTMLButtonElement>) => (
      <button onClick={onClick}>{children}</button>
    ),
    CircularProgress: ({ children }: React.PropsWithChildren) => <>{children}</>,
    Tooltip: ({ children }: React.PropsWithChildren) => <>{children}</>,
    LinearProgress: () => <div role='progressbar' />,
  }
})

describe('IndexTable', () => {
  beforeEach(() => {
    mocks.cluster = {
      clusterId: 'cluster-1',
      indexesCount: 42,
      state: ClusterStateDto.Active,
      availableActions: IndexActionsDto.Deactivate,
    }
    mocks.polling = false
    mocks.mutate.mockClear()
    mocks.notify.mockClear()
    mocks.confirm.mockReset().mockResolvedValue(true)
  })

  it('показывает данные кластера и запускает действие без подтверждения', async () => {
    const model = IndexTableTestModel.open()

    expect(screen.getByText('42')).toBeVisible()
    expect(screen.getByText('Мониторинг: UP')).toBeVisible()
    expect(screen.getByText('Статус: ACTIVE')).toBeVisible()
    await model.run('Деактивировать')

    expect(mocks.mutate).toHaveBeenCalledOnce()
    expect(mocks.notify).toHaveBeenCalledWith([mocks.cluster])
  })

  it('подтверждает потенциально долгое пересоздание индексов', async () => {
    mocks.cluster.availableActions = IndexActionsDto.CreateIndex
    const model = IndexTableTestModel.open()

    await model.run('Пересоздать индексы')

    await waitFor(() => expect(mocks.confirm).toHaveBeenCalledOnce())
    expect(mocks.mutate).toHaveBeenCalledOnce()
  })

  it('не запускает действие после отказа от подтверждения', async () => {
    mocks.cluster.availableActions = IndexActionsDto.CreateIndex
    mocks.confirm.mockResolvedValue(false)
    const model = IndexTableTestModel.open()

    await model.run('Пересоздать индексы')

    await waitFor(() => expect(mocks.confirm).toHaveBeenCalledOnce())
    expect(mocks.mutate).not.toHaveBeenCalled()
  })

  it('показывает неизвестное количество и polling progress', () => {
    mocks.cluster.indexesCount = -1
    mocks.cluster.availableActions = IndexActionsDto.Unrecognized
    mocks.polling = true
    IndexTableTestModel.open()

    expect(screen.getByText('неизвестно')).toBeVisible()
    expect(screen.getByRole('progressbar')).toBeVisible()
    expect(screen.queryByRole('button')).not.toBeInTheDocument()
  })
})
