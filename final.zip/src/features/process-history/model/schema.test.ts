import { describe, it, expect } from 'vitest'

import { processHistoryFilterSchema } from '@/features/process-history/model/schema'

describe('processHistoryFilterSchema', () => {
  it('should validate correct filter input', () => {
    const result = processHistoryFilterSchema.safeParse({
      period: [new Date('2024-01-01'), new Date('2024-01-31')],
      groupIds: [1, 2, 3],
    })

    expect(result.success).toBe(true)
    if (result.success) {
      expect(result.data.period).toHaveLength(2)
      expect(result.data.groupIds).toEqual([1, 2, 3])
    }
  })

  it('should fail when groupIds is null', () => {
    const result = processHistoryFilterSchema.safeParse({
      period: [new Date('2024-01-01'), new Date('2024-01-31')],
      groupIds: null,
    })

    expect(result.success).toBe(false)
  })

  it('should fail when groupIds is empty array', () => {
    const result = processHistoryFilterSchema.safeParse({
      period: [new Date('2024-01-01'), new Date('2024-01-31')],
      groupIds: [],
    })

    expect(result.success).toBe(false)
  })
})
