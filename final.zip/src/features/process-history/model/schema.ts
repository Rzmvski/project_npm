import z from 'zod'

const dateSchema = z.date().nullable().pipe(z.date())

export const processHistoryFilterSchema = z.object({
  period: z.tuple([dateSchema, dateSchema]),
  groupIds: z.number().array().nullable().pipe(z.number().array().nonempty()),
})

export type ProcessHistoryFilterInputValues = z.input<
  typeof processHistoryFilterSchema
>

export type ProcessHistoryFilterOutputValues = z.output<
  typeof processHistoryFilterSchema
>
