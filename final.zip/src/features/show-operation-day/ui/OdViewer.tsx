import { CircularProgress } from '@v-uik/base'
import React, { type FC } from 'react'

import { useOperationDay } from '@/entities/operation-day'
import { formatDate } from '@/shared/lib'

import styles from './OdViewer.module.scss'

export const OdViewer: FC = () => {
  const { od, isLoading, isError } = useOperationDay()

  const Content = () => {
    if (isLoading) {
      return (
        <div className={styles.state}>
          <CircularProgress />
        </div>
      )
    }
    if (isError) {
      return (
        <div className={styles.state}>
          <span className={styles.error}>{'Ошибка загрузки данных операционного дня!'}</span>
        </div>
      )
    }
    return (
      <>
        <div className={styles.title}>{'Дата ОД'}</div>
        <div className={styles.row}>
          <span>{'Текущего:'}</span>
          <span className={styles.value}>
            {formatDate(od?.current ?? null, 'dd.MM.yyyy')}
          </span>
        </div>
        <div className={styles.row}>
          <span>{'Последнего закрытого:'}</span>
          <span className={styles.value}>
            {formatDate(od?.lastClosed ?? null, 'dd.MM.yyyy')}
          </span>
        </div>
      </>
    )
  }

  return (
    <div className={styles.viewer}>
      <Content />
    </div>
  )
}
