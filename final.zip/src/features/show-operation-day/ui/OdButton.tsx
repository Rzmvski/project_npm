import { BarButton } from '@v-uik/base'
import { CalendarSearchIcon } from 'lucide-react'
import React, { type FC, useRef } from 'react'

import { Popup } from '@/shared/ui/Popup'

import { OdViewer } from './OdViewer'

export const OdButton: FC = () => {
  const anchorRef = useRef<Nullable<HTMLDivElement>>(null)

  return (
    <Popup content={<OdViewer />}>
      <BarButton
        ref={anchorRef}
        aria-label={'Операционный день'}
        title={'Операционный день'}
      >
        <CalendarSearchIcon />
      </BarButton>
    </Popup>
  )
}
