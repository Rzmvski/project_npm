import {
  ApplicationStatusDto,
  FeatureApplicationActionDto,
  type FeatureApplicationDto,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { act, renderHook } from '@testing-library/react'

import { useFeatureApplicationsFilters } from './useFeatureApplicationsFilters'

const application = (
  reasonId: string,
  featureName: string,
  action: FeatureApplicationActionDto,
  status: ApplicationStatusDto,
  module?: string,
): FeatureApplicationDto =>
  ({
    reasonId,
    featureName,
    action,
    status,
    target: { type: 'DIRECT', module },
    uid: reasonId,
    createdBy: 'author',
  }) as FeatureApplicationDto

const applications = [
  application(
    'REQ-1',
    'PAYMENTS',
    FeatureApplicationActionDto.Create,
    ApplicationStatusDto.Pending,
    'billing',
  ),
  application(
    'REQ-2',
    'REPORTS',
    FeatureApplicationActionDto.Update,
    ApplicationStatusDto.Approved,
    'analytics',
  ),
  application(
    'REQ-3',
    'LIMITS',
    FeatureApplicationActionDto.Delete,
    ApplicationStatusDto.Decline,
    'billing',
  ),
]

describe('useFeatureApplicationsFilters', () => {
  it('возвращает все заявки и уникальные модули по умолчанию', () => {
    const { result } = renderHook(() => useFeatureApplicationsFilters({ applications }))

    expect(result.current.result).toEqual(applications)
    expect(result.current.moduleOptions.map(({ value }) => value)).toEqual([
      null,
      'billing',
      'analytics',
    ])
  })

  it('комбинирует action, status, module и текстовый поиск', () => {
    const { result } = renderHook(() => useFeatureApplicationsFilters({ applications }))

    act(() => {
      result.current.setSelectedAction(FeatureApplicationActionDto.Create)
      result.current.setSelectedStatus(ApplicationStatusDto.Pending)
      result.current.setSelectedModule('billing')
      result.current.setSearchQuery('payments')
    })

    expect(result.current.result.map(({ reasonId }) => reasonId)).toEqual(['REQ-1'])
  })

  it('переключает каждый фильтр независимо', () => {
    const { result } = renderHook(() => useFeatureApplicationsFilters({ applications }))

    act(() => result.current.setSelectedStatus(ApplicationStatusDto.Approved))
    expect(result.current.result.map(({ reasonId }) => reasonId)).toEqual(['REQ-2'])

    act(() => {
      result.current.setSelectedStatus(null)
      result.current.setSelectedAction(FeatureApplicationActionDto.Delete)
    })
    expect(result.current.result.map(({ reasonId }) => reasonId)).toEqual(['REQ-3'])
  })
})
