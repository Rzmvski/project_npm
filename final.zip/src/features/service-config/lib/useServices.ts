import { useQuery } from '@tanstack/react-query'

import { serviceRegistry } from '@/entities/service'

import { fetchServicesConfig } from '../api/fetchConfig'

export const useServices = () => {
  const query = useQuery({
    queryKey: ['service-config'],
    queryFn: fetchServicesConfig,
    staleTime: Number.POSITIVE_INFINITY,
  })
  const enabledIds = query.data
  const services = Object.values(serviceRegistry).map((service) => ({
    ...service,
    disabled: enabledIds ? !enabledIds.includes(service.id) : false,
  }))

  return { services, isLoading: query.isLoading, isError: query.isError }
}
