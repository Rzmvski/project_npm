import { fetchServicesConfig } from './fetchConfig'

describe('fetchServicesConfig', () => {
  it('возвращает конфигурацию успешного ответа', async () => {
    vi.spyOn(globalThis, 'fetch').mockResolvedValueOnce({
      ok: true,
      json: vi.fn().mockResolvedValue(['cluster-management']),
    } as unknown as Response)

    await expect(fetchServicesConfig()).resolves.toEqual(['cluster-management'])
    expect(fetch).toHaveBeenCalledWith('/config/services')
  })

  it('возвращает null для HTTP-ошибки и пустой список при сетевой ошибке', async () => {
    vi.spyOn(globalThis, 'fetch').mockResolvedValueOnce({ ok: false } as Response)
    await expect(fetchServicesConfig()).resolves.toBeNull()

    vi.spyOn(globalThis, 'fetch').mockRejectedValueOnce(new Error('offline'))
    await expect(fetchServicesConfig()).resolves.toEqual([])
  })
})
