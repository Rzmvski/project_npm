import { type ServiceId } from '@/entities/service'

export const fetchServicesConfig = async (): Promise<ServiceId[]> => {
  return fetch('/config/services')
    .then((res) => (res.ok ? res.json() : null))
    .catch(() => [])
}
