import { z } from 'zod'

import { hasUnfilledPlaceholders } from '@/entities/script-placeholder'

type RestrictionModeStatus = 'enabled' | 'disabled'

const empty = ''

const enableRestrictionsSchema = z.object({
  restrictionMode: z.literal<RestrictionModeStatus>('enabled'),
  nodes: z.string().array().nonempty(),
})

const disableRestrictionsSchema = z.object({
  restrictionMode: z.literal<RestrictionModeStatus>('disabled'),
  nodes: z.string().array().optional(),
})

const restrictions = z.discriminatedUnion('restrictionMode', [
  enableRestrictionsSchema,
  disableRestrictionsSchema,
])

const base = z.object({
  jiraId: z
    .string()
    .nonempty(empty)
    .regex(/^[a-zA-Z0-9-]+$/, 'Допускаются только латинские буквы, цифры и -'),
  reasonId: z
    .string()
    .nonempty(empty)
    .min(3, 'Строка должна содержать как минимум 3 символа')
    .regex(/^[\p{L}\p{N}]+$/u, 'Допускаются только цифры и буквы'),
  script: z
    .string()
    .nonempty()
    .refine(
      (value) => !hasUnfilledPlaceholders(value),
      'Заполните параметры шаблона'
    ),
})

export const scriptSchema = base.and(restrictions)

export type ScriptSchemaType = z.infer<typeof scriptSchema>
