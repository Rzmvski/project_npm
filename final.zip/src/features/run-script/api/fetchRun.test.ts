import {
  ApplicationStatusDto,
  ApplicationTypeDto,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { saveScriptApplication } from './fetchRun'

const save = vi.hoisted(() => vi.fn())
vi.mock('@/shared/api', () => ({ scriptService: { saveScriptApplication: save } }))

it('saveScriptApplication добавляет обязательные type и pending status', () => {
  saveScriptApplication({ reasonId: 'REQ1', script: 'return true' } as never)
  expect(save).toHaveBeenCalledWith(
    expect.objectContaining({
      reasonId: 'REQ1',
      type: ApplicationTypeDto.Script,
      status: ApplicationStatusDto.Pending,
    }),
  )
})
