import {
  ApplicationStatusDto,
  ApplicationTypeDto,
  type ScriptApplicationDto,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { scriptService } from '@/shared/api'

export const saveScriptApplication = (
  application: Omit<ScriptApplicationDto, 'type' | 'status'>
) => {
  return scriptService.saveScriptApplication({
    ...application,
    type: ApplicationTypeDto.Script,
    status: ApplicationStatusDto.Pending,
  })
}
