import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'

import { scriptSchema } from '../model/schema'

export const useScriptForm = () => {
  return useForm({
    resolver: zodResolver(scriptSchema),
    defaultValues: {
      restrictionMode: 'enabled',
      script: '',
      reasonId: '',
      jiraId: '',
      nodes: [],
    },
  })
}
