import { type Ace, Range } from 'ace-builds'
import classNames from 'classnames'
import { type MutableRefObject, useCallback, useEffect } from 'react'

import { type Placeholder, usePlaceholders } from '@/entities/script-placeholder'

const BRACKET_AMOUNT = 4

interface UseHighlightEditorParams {
  editorRef: MutableRefObject<Nullable<Ace.Editor>>
  scriptValue: string
}

export const useHighlightEditor = ({
  editorRef,
  scriptValue,
}: UseHighlightEditorParams) => {
  const {
    placeholders,
    activePlaceholderIndex,
    setFirstActivePlaceholder,
    setActivePlaceholderIndex,
    clearActivePlaceholder,
  } = usePlaceholders({ value: scriptValue })

  const getRange = ({
    position,
    name,
  }: Pick<Placeholder, 'name' | 'position'>) => {
    const { row, column } = position
    const endColumn = column + name.length + BRACKET_AMOUNT
    return new Range(row, column, row, endColumn)
  }

  const navigateToPlaceholder = useCallback(() => {
    if (
      !editorRef.current ||
      activePlaceholderIndex === null ||
      activePlaceholderIndex < 0 ||
      activePlaceholderIndex >= placeholders.length
    )
      return
    const editor = editorRef.current

    const { position, name } = placeholders[activePlaceholderIndex]
    const { row, column } = position

    editor.gotoLine(row + 1, column, true)
    editor.focus()

    const range = getRange({ position, name })
    editor.selection.setRange(range)
  }, [activePlaceholderIndex, placeholders])

  const updateMarkers = useCallback(() => {
    if (!editorRef.current) return

    const session = editorRef.current.session
    const markers = session.getMarkers()

    Object.keys(markers).forEach((marker) => {
      const markerId = Number(marker)
      if (markers[markerId].clazz?.includes('placeholder-marker')) {
        session.removeMarker(markerId)
      }
    })

    placeholders.forEach((placeholder, index) => {
      if (!placeholder?.position) return

      const range = getRange(placeholder)
      const className = classNames('placeholder-marker', {
        'active-placeholder': index === activePlaceholderIndex,
      })

      session.addMarker(range, className, 'text', false)
    })
  }, [placeholders, activePlaceholderIndex])

  const onLoad = useCallback(
    (editor: Ace.Editor) => {
      editorRef.current = editor

      editorRef.current.session.on('change', updateMarkers)
    },
    [updateMarkers]
  )

  useEffect(() => {
    navigateToPlaceholder()
  }, [navigateToPlaceholder])

  useEffect(() => {
    updateMarkers()
  }, [updateMarkers])

  return {
    onLoad,
    placeholders,
    setFirstActivePlaceholder,
    clearActivePlaceholder,
    setActivePlaceholderIndex,
  }
}
