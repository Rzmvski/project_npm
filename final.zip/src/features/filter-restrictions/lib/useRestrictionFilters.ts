import { useMemo } from 'react'

import {
  type TrafficRestriction,
  useTypePartition,
  useFilter,
} from '@/entities/traffic-restriction'
import { createObjectMatcher, useSearch } from '@/shared/lib'

const matcher = createObjectMatcher({ caseSensitive: false, deep: false })

interface UseRestrictionFiltersOptions {
  restrictions: TrafficRestriction[]
  allDataCenters: string[]
  allApplications: string[]
}

export const useRestrictionFilters = ({
  restrictions,
  allApplications,
  allDataCenters,
}: UseRestrictionFiltersOptions) => {
  const {
    selectedPartition,
    setSelectedPartition,
    result: partitionRestrictions,
  } = useTypePartition({
    items: restrictions,
  })

  const {
    result: searchedRestrictions,
    searchQuery,
    setSearchQuery,
  } = useSearch({
    items: partitionRestrictions,
    searchFn: (items, query) =>
      items.filter((item) => {
        return matcher(item, query)
      }),
  })

  const {
    options: appOptions,
    selectedValue: selectedApp,
    setSelectedValue: setSelectedApp,
  } = useFilter({ optionValues: allApplications })

  const {
    options: dcOptions,
    selectedValue: selectedDc,
    setSelectedValue: setSelectedDc,
  } = useFilter({ optionValues: allDataCenters })

  const result = useMemo(() => {
    return searchedRestrictions.filter(({ services, dataCenters }) => {
      const isGlobal = services.length === 0
      const matchesApp =
        isGlobal || !selectedApp || services.includes(selectedApp)

      const matchesDc = !selectedDc || dataCenters.includes(selectedDc)

      return matchesApp && matchesDc
    })
  }, [searchedRestrictions, selectedApp, selectedDc])

  return {
    selectedPartition,
    setSelectedPartition,
    searchQuery,
    setSearchQuery,
    dcOptions,
    appOptions,
    selectedApp,
    selectedDc,
    setSelectedDc,
    setSelectedApp,
    result,
  }
}
