import { act, renderHook } from '@testing-library/react'

import type { TrafficRestriction } from '@/entities/traffic-restriction'

import { useRestrictionFilters } from './useRestrictionFilters'

const restriction = (
  id: string,
  services: string[],
  dataCenters: string[],
): TrafficRestriction => ({ id, name: id, services, dataCenters })

const restrictions = [
  restriction('global-dc-1', [], ['dc-1']),
  restriction('payments-dc-1', ['payments'], ['dc-1']),
  restriction('reports-dc-2', ['reports'], ['dc-2']),
]

describe('useRestrictionFilters', () => {
  const renderFilters = () =>
    renderHook(() =>
      useRestrictionFilters({
        restrictions,
        allApplications: ['payments', 'reports'],
        allDataCenters: ['dc-1', 'dc-2'],
      }),
    )

  it('возвращает все ограничения и варианты фильтров по умолчанию', () => {
    const { result } = renderFilters()

    expect(result.current.result).toEqual(restrictions)
    expect(result.current.appOptions.map(({ value }) => value)).toEqual(['payments', 'reports'])
    expect(result.current.dcOptions.map(({ value }) => value)).toEqual(['dc-1', 'dc-2'])
  })

  it('разделяет глобальные и сервисные ограничения', () => {
    const { result } = renderFilters()

    act(() => result.current.setSelectedPartition('global'))
    expect(result.current.result.map(({ id }) => id)).toEqual(['global-dc-1'])

    act(() => result.current.setSelectedPartition('service'))
    expect(result.current.result.map(({ id }) => id)).toEqual(['payments-dc-1', 'reports-dc-2'])
  })

  it('сочетает поиск, приложение и дата-центр', () => {
    const { result } = renderFilters()

    act(() => {
      result.current.setSearchQuery('dc-1')
      result.current.setSelectedApp('payments')
      result.current.setSelectedDc('dc-1')
    })

    expect(result.current.result.map(({ id }) => id)).toEqual(['global-dc-1', 'payments-dc-1'])
  })

  it('не считает глобальное ограничение совпадением другого дата-центра', () => {
    const { result } = renderFilters()

    act(() => {
      result.current.setSelectedApp('payments')
      result.current.setSelectedDc('dc-2')
    })

    expect(result.current.result).toEqual([])
  })
})
