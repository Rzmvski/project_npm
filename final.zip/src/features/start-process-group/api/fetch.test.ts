import { fetchStartProcessGroup } from './fetch'

const startProcess = vi.hoisted(() => vi.fn())
vi.mock('@/shared/api', () => ({ processManagementService: { startProcess } }))

it('fetchStartProcessGroup нормализует id группы в число', () => {
  const od = new Date('2026-08-13')
  fetchStartProcessGroup({ od, group: { id: '42' } } as never)
  expect(startProcess).toHaveBeenCalledWith(42, od)
})
