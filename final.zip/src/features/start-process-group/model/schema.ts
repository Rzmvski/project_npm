import z from 'zod'

export const startProcessSchema = z.object({
  group: z.object({
    id: z.string(),
    label: z.string(),
  }),
  od: z.date().nullable().pipe(z.date()),
})

export type StartProcessInputValues = z.input<typeof startProcessSchema>
export type StartProcessOutputValues = z.output<typeof startProcessSchema>
