export interface ActiveProcessGroup {
  groupId: string
  activeProcessId: number
  startDate: Date
}
