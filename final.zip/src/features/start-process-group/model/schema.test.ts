import { describe, it, expect } from 'vitest'

import { startProcessSchema } from '@/features/start-process-group/model/schema'

describe('startProcessSchema', () => {
  it('should validate correct input', () => {
    const result = startProcessSchema.safeParse({
      group: {
        id: 'group-1',
        label: 'Test Group',
      },
      od: new Date('2024-01-01'),
    })

    expect(result.success).toBe(true)
    if (result.success) {
      expect(result.data.group.id).toBe('group-1')
      expect(result.data.group.label).toBe('Test Group')
    }
  })

  it('should fail without group', () => {
    const result = startProcessSchema.safeParse({
      od: new Date(),
    })

    expect(result.success).toBe(false)
  })

  it('should fail with invalid od type', () => {
    const result = startProcessSchema.safeParse({
      group: { id: 'g1', label: 'Test' },
      od: 'invalid-date',
    })

    expect(result.success).toBe(false)
  })
})
