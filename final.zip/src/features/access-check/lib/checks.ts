import { type PermissionType } from '@/shared/model'

export const hasAuthority = (
  userPermissions: PermissionType[],
  requiredPermission: PermissionType
): boolean => {
  return userPermissions.includes(requiredPermission)
}

export const hasAnyAuthority = (
  userPermissions: PermissionType[],
  requiredPermissions: PermissionType[]
): boolean => {
  return requiredPermissions.some((permission) =>
    userPermissions.includes(permission)
  )
}

export const hasAllAuthorities = (
  userPermissions: PermissionType[],
  requiredPermissions: PermissionType[]
): boolean => {
  return requiredPermissions.every((permission) =>
    userPermissions.includes(permission)
  )
}

export const hasAuthorityWithSubstring = (
  userRoles: string[],
  substring: string
): boolean => {
  return userRoles.some((role) => role.includes(substring))
}
