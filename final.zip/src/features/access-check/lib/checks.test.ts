import { describe, it, expect } from 'vitest'

import {
  hasAuthority,
  hasAnyAuthority,
  hasAllAuthorities,
  hasAuthorityWithSubstring,
} from '@/features/access-check/lib/checks'

const mockPermissions = ['admin', 'user', 'viewer']

describe('hasAuthority', () => {
  it('should return true when user has the permission', () => {
    expect(hasAuthority(mockPermissions, 'admin')).toBe(true)
  })

  it('should return false when user does not have the permission', () => {
    expect(hasAuthority(mockPermissions, 'superadmin')).toBe(false)
  })
})

describe('hasAnyAuthority', () => {
  it('should return true when user has any of the permissions', () => {
    expect(hasAnyAuthority(mockPermissions, ['admin', 'superadmin'])).toBe(true)
  })

  it('should return false when user has none of the permissions', () => {
    expect(hasAnyAuthority(mockPermissions, ['superadmin', 'root'])).toBe(false)
  })
})

describe('hasAllAuthorities', () => {
  it('should return true when user has all permissions', () => {
    expect(hasAllAuthorities(mockPermissions, ['admin', 'user', 'viewer'])).toBe(true)
  })

  it('should return false when user lacks any permission', () => {
    expect(hasAllAuthorities(mockPermissions, ['admin', 'superadmin'])).toBe(false)
  })
})

describe('hasAuthorityWithSubstring', () => {
  it('should return true when any role contains the substring', () => {
    expect(hasAuthorityWithSubstring(['admin-tkp', 'user'], 'tkp')).toBe(true)
  })

  it('should return false when no role contains the substring', () => {
    expect(hasAuthorityWithSubstring(['admin', 'user'], 'tkp')).toBe(false)
  })

  it('should return false for empty roles array', () => {
    expect(hasAuthorityWithSubstring([], 'admin')).toBe(false)
  })
})
