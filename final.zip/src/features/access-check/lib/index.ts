export {
  hasAllAuthorities,
  hasAnyAuthority,
  hasAuthority,
  hasAuthorityWithSubstring,
} from './checks'
