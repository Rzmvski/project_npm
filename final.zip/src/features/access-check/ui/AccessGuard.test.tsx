import { useQuery } from '@tanstack/react-query'
import { render, screen } from '@testing-library/react'
import { describe, it, expect, vi, beforeEach } from 'vitest'

import { AccessGuard } from '@/features/access-check/ui/AccessGuard'

vi.mock('@tanstack/react-query', () => ({
  useQuery: vi.fn(),
}))

vi.mock('@/entities/user', () => ({
  userQueryOptions: vi.fn(),
}))

describe('AccessGuard', () => {
  beforeEach(() => {
    vi.mocked(useQuery).mockReturnValue({
      isLoading: false,
      isError: false,
      data: { roles: ['admin-tkp'], permissions: ['edit', 'view'] },
    } as unknown as ReturnType<typeof useQuery>)
  })

  it('should render children when user has required role', () => {
    render(
      <AccessGuard requiredRole='tkp'>
        <div>Protected Content</div>
      </AccessGuard>,
    )
    expect(screen.getByText('Protected Content')).toBeInTheDocument()
  })

  it('should render fallback when user lacks required role', () => {
    render(
      <AccessGuard requiredRole='superadmin' fallback={<div>No Access</div>}>
        <div>Protected Content</div>
      </AccessGuard>,
    )
    expect(screen.getByText('No Access')).toBeInTheDocument()
  })

  it('should not render children when status is PENDING (loading)', () => {
    vi.mocked(useQuery).mockReturnValue({
      isLoading: true,
      isError: false,
      data: undefined,
    } as unknown as ReturnType<typeof useQuery>)

    render(
      <AccessGuard>
        <div>Content</div>
      </AccessGuard>,
    )
    expect(screen.queryByText('Content')).not.toBeInTheDocument()
  })

  it('should render children when no restrictions are set', () => {
    render(
      <AccessGuard>
        <div>Always Visible</div>
      </AccessGuard>,
    )
    expect(screen.getByText('Always Visible')).toBeInTheDocument()
  })
})
