import { useQuery } from '@tanstack/react-query'
import { CircularProgress } from '@v-uik/base'
import React, { type PropsWithChildren } from 'react'

import { userQueryOptions } from '@/entities/user'
import {
  hasAllAuthorities,
  hasAuthorityWithSubstring,
} from '@/features/access-check/lib/checks'
import { type PermissionType } from '@/shared/model'

interface AccessGuardProps extends PropsWithChildren {
  requiredRole?: string
  requiredPermissions?: PermissionType[]
  fallback?: React.ReactNode
}

export const AccessGuard: React.FC<AccessGuardProps> = ({
  children,
  requiredRole,
  requiredPermissions,
  fallback = null,
}) => {
  const { isLoading, data } = useQuery(userQueryOptions())

  if (isLoading) {
    return <CircularProgress isFullScreen />
  }

  const hasRequiredRole = !requiredRole || hasAuthorityWithSubstring(data?.roles ?? [], requiredRole)

  const hasRequiredPermissions =
    !requiredPermissions || hasAllAuthorities(data?.permissions ?? [], requiredPermissions)

  const isAllowed = hasRequiredRole && hasRequiredPermissions

  if (!isAllowed) {
    return <>{fallback}</>
  }

  return <>{children}</>
}
