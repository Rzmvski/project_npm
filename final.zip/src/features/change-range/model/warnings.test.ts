import { describe, it, expect } from 'vitest'

import { crossDistributionWarning } from '@/features/change-range/model/warnings'

describe('crossDistributionWarning', () => {
  it('should have correct type', () => {
    expect(crossDistributionWarning.type).toBe('cross-distribution')
  })

  it('should return ActiveWarning when semaphoreDc matches nodeDc', () => {
    const result = crossDistributionWarning.build({
      rangeId: 'n1:0:100',
      nodeDc: 'dc1',
      semaphoreDc: 'dc1',
    })

    expect(result).toEqual({
      id: 'n1:0:100',
      type: 'cross-distribution',
      message: 'Семафор и база данных находятся в одном дата-центре',
    })
  })

  it('check should return true when semaphoreDc equals nodeDc', () => {
    const result = crossDistributionWarning.check({
      rangeId: 'n1:0:100',
      nodeDc: 'dc1',
      semaphoreDc: 'dc1',
    })

    expect(result).toBe(true)
  })

  it('check should return false when semaphoreDc differs from nodeDc', () => {
    const result = crossDistributionWarning.check({
      rangeId: 'n1:0:100',
      nodeDc: 'dc1',
      semaphoreDc: 'dc2',
    })

    expect(result).toBe(false)
  })

  it('check should return false when semaphoreDc is undefined', () => {
    const result = crossDistributionWarning.check({
      rangeId: 'n1:0:100',
      nodeDc: 'dc1',
    })

    expect(result).toBe(false)
  })
})
