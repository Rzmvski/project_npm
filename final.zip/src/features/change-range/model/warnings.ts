import { type RangeId } from '@/entities/range'
import { type ActiveWarning, type Warning } from '@/entities/warning'

type CrossDistributionWarningContext = {
  rangeId: RangeId
  nodeDc?: string
  semaphoreDc?: string
}

const warningId = 'cross-distribution'

export type WarningsMap = Record<RangeId, ActiveWarning<RangeId>[]>

export const crossDistributionWarning: Warning<
  CrossDistributionWarningContext,
  RangeId
> = {
  type: warningId,
  check: ({ nodeDc, semaphoreDc }) => !!semaphoreDc && semaphoreDc === nodeDc,
  build: ({ rangeId }) => ({
    id: rangeId,
    type: warningId,
    message: 'Семафор и база данных находятся в одном дата-центре',
  }),
}
