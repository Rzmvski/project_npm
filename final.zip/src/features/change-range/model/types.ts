import { type Range, type RangeId } from '@/entities/range'

export type RangesFormValues = {
  ranges: Record<RangeId, Range>
}
