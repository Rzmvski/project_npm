import { keyBy } from 'lodash-es'
import { useEffect } from 'react'
import { useForm } from 'react-hook-form'

import { type Range , getRangeId } from '@/entities/range'

import { type RangesFormValues } from '../model'


type UseChangeRangesOptions = {
  ranges: Range[]
}

const buildDictionary = (ranges: Range[]) => keyBy(ranges, getRangeId)

export const useChangeRanges = ({ ranges }: UseChangeRangesOptions) => {
  const form = useForm<RangesFormValues>({
    defaultValues: {
      ranges: buildDictionary(ranges),
    },
  })

  const {
    reset,
    formState: { isDirty },
  } = form

  useEffect(() => {
    // См. комментарий в useChangeBoundary: не сбрасываем форму (в том числе
    // выбор семафора в RangeEditor) поверх несохранённых правок пользователя
    // из-за фонового обновления диапазонов/семафоров.
    if (isDirty) return

    reset({
      ranges: buildDictionary(ranges),
    })
  }, [ranges, reset, isDirty])

  return {
    rangesForm: form,
    isPending: isDirty,
  }
}
