import { renderHook } from '@testing-library/react'

import type { Range } from '@/entities/range'
import type { Semaphore } from '@/entities/semaphore'

import { useRangeWarnings } from './useRangeWarnings'

describe('useRangeWarnings', () => {
  it('группирует предупреждения совпадающих дата-центров по диапазонам', () => {
    const ranges = [
      { nodeKey: 'node-1', clusterKey: 'cluster-1', dcKey: 'dc-a', start: 0, end: 10 },
      { nodeKey: 'node-2', clusterKey: 'cluster-1', dcKey: 'dc-b', start: 10, end: 20 },
    ] as Range[]
    const semaphores = [
      { nodeKey: 'sem-1', clusterKey: 'cluster-1', dcKey: 'dc-a' },
    ] as Semaphore[]

    const { result } = renderHook(() => useRangeWarnings(ranges, semaphores))

    expect(result.current.warnings).toHaveLength(1)
    expect(Object.values(result.current.warningsMap).flat()).toHaveLength(1)
  })

  it('не создаёт предупреждений при распределении по разным дата-центрам', () => {
    const ranges = [
      { nodeKey: 'node-1', clusterKey: 'cluster-1', dcKey: 'dc-a', start: 0, end: 10 },
    ] as Range[]
    const semaphores = [
      { nodeKey: 'sem-1', clusterKey: 'cluster-1', dcKey: 'dc-b' },
    ] as Semaphore[]

    const { result } = renderHook(() => useRangeWarnings(ranges, semaphores))
    expect(result.current).toEqual({ warnings: [], warningsMap: {} })
  })
})
