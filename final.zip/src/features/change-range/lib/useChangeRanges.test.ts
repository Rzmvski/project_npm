import { act, renderHook } from '@testing-library/react'

import { type Range } from '@/entities/range'

import { useChangeRanges } from './useChangeRanges'

const initialRanges: Range[] = [
  { nodeKey: 'node-a', clusterKey: 'cluster-1', start: 0, end: 10 },
  { nodeKey: 'node-b', clusterKey: 'cluster-2', start: 10, end: 20 },
]

describe('useChangeRanges', () => {
  it('не сбрасывает выбор семафора, пока есть несохранённые правки', () => {
    const { result, rerender } = renderHook(({ ranges }) => useChangeRanges({ ranges }), {
      initialProps: { ranges: initialRanges },
    })

    act(() => {
      result.current.rangesForm.setValue('ranges.node-a:0:10.clusterKey', 'cluster-3', {
        shouldDirty: true,
      })
    })
    expect(result.current.rangesForm.formState.isDirty).toBe(true)

    // Фоновое обновление диапазонов (SSE/поллинг) не должно затирать ещё не
    // отправленный выбор семафора.
    const freshRanges: Range[] = [
      { nodeKey: 'node-a', clusterKey: 'cluster-1', start: 0, end: 10 },
      { nodeKey: 'node-b', clusterKey: 'cluster-2', start: 10, end: 20 },
    ]
    rerender({ ranges: freshRanges })

    expect(result.current.rangesForm.getValues('ranges.node-a:0:10.clusterKey')).toBe(
      'cluster-3',
    )
  })

  it('подтягивает новые диапазоны, когда форма не изменена', () => {
    const { result, rerender } = renderHook(({ ranges }) => useChangeRanges({ ranges }), {
      initialProps: { ranges: initialRanges },
    })

    const freshRanges: Range[] = [
      { nodeKey: 'node-a', clusterKey: 'cluster-9', start: 0, end: 10 },
      { nodeKey: 'node-b', clusterKey: 'cluster-2', start: 10, end: 20 },
    ]
    rerender({ ranges: freshRanges })

    expect(result.current.rangesForm.getValues('ranges.node-a:0:10.clusterKey')).toBe(
      'cluster-9',
    )
  })
})
