import { renderHook } from '@testing-library/react'

import { useChangeRangesMutation } from './useChangeRangesMutation'

const mocks = vi.hoisted(() => ({ config: null as any, fetch: vi.fn(), success: vi.fn(), invalidate: vi.fn() }))
vi.mock('@tanstack/react-query', () => ({
  useQueryClient: () => ({ invalidateQueries: mocks.invalidate }),
  useMutation: (config: any) => ((mocks.config = config), { mutate: config.mutationFn }),
}))
vi.mock('@v-uik/base', () => ({ notification: { success: mocks.success } }))
vi.mock('@/features/change-range/api/fetch.ts', () => ({ fetchChangeSemaphore: (...args: any[]) => mocks.fetch(...args) }))
vi.mock('@/entities/node', () => ({ nodesQueryKey: ['nodes'] }))
vi.mock('@/entities/routing-shard', () => ({ availableShardsQueryKey: ['available-shards'] }))

it('useChangeRangesMutation переводит границы в API-формат и обновляет узлы', () => {
  const { result } = renderHook(() => useChangeRangesMutation(42))
  result.current.mutate([{ clusterKey: 'a', start: 0, end: 9 } as never])
  expect(mocks.fetch).toHaveBeenCalledWith(42, [
    { semaphoreClusterKey: 'a', startInclusive: 0, endExclusive: 10, frozenSemaphoreCluster: undefined },
  ])
  mocks.config.onSuccess()
  expect(mocks.success).toHaveBeenCalled()
  expect(mocks.invalidate).toHaveBeenCalledWith({ queryKey: ['nodes'] })
  expect(mocks.invalidate).toHaveBeenCalledWith({ queryKey: ['available-shards'] })
})
