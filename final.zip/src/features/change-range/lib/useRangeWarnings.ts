import { uniqBy } from 'lodash-es'
import { useMemo } from 'react'

import { getRangeId, type Range, type RangeId } from '@/entities/range'
import { type Semaphore } from '@/entities/semaphore'
import { type ActiveWarning, evaluateWarning } from '@/entities/warning'
import {
  crossDistributionWarning,
  type WarningsMap,
} from '@/features/change-range/model'



const buildWarnings = (
  ranges: Range[],
  semaphores: Semaphore[]
): ActiveWarning<RangeId>[] => {
  return ranges
    .flatMap((range) => {
      const { clusterKey, dcKey } = range
      const semaphore = semaphores.find(
        (semaphore) => semaphore.clusterKey === clusterKey
      )

      return evaluateWarning(crossDistributionWarning, {
        rangeId: getRangeId(range),
        nodeDc: dcKey,
        semaphoreDc: semaphore?.dcKey,
      })
    })
    .filter((warning) => warning !== null)
}

export const useRangeWarnings = (ranges: Range[], semaphores: Semaphore[]) => {
  return useMemo(() => {
    const warnings = buildWarnings(ranges, semaphores)

    const warningsMap = warnings.reduce<WarningsMap>((acc, warning) => {
      const { id } = warning
      acc[id] ??= []
      acc[id].push(warning)

      return acc
    }, {})

    return {
      warnings: uniqBy(warnings, ({ type }) => type),
      warningsMap,
    }
  }, [ranges, semaphores])
}
