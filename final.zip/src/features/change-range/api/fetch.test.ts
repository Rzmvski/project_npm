import { fetchChangeSemaphore } from './fetch'

const updateSemaphoresOfShardById = vi.hoisted(() => vi.fn())
vi.mock('@/shared/api', () => ({
  clusterManagementService: { updateSemaphoresOfShardById },
}))

it('fetchChangeSemaphore отправляет обновлённые диапазоны бакетов выбранной шарды', () => {
  const changedBucketRanges = [{ nodeKey: 'node-1' }]
  fetchChangeSemaphore(42, changedBucketRanges as never)
  expect(updateSemaphoresOfShardById).toHaveBeenCalledWith(42, {
    changedBucketRanges,
  })
})
