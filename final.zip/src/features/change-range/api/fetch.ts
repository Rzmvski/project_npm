import { type BucketRangeDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { clusterManagementService } from '@/shared/api'

export const fetchChangeSemaphore = (
  shardId: number,
  changedBucketRanges: BucketRangeDto[]
) => {
  return clusterManagementService.updateSemaphoresOfShardById(shardId, {
    changedBucketRanges,
  })
}
