import { renderHook } from '@testing-library/react'

import { useNodeDictionariesMutation } from './useNodeDictionariesMutation'

const mocks = vi.hoisted(() => ({ config: null as any, fetch: vi.fn(), success: vi.fn() }))
vi.mock('@tanstack/react-query', () => ({ useMutation: (config: any) => ((mocks.config = config), { mutate: config.mutationFn }) }))
vi.mock('@v-uik/base', () => ({ notification: { success: mocks.success } }))
vi.mock('@/features/sync-node-dictionaries/api', () => ({ fetchSchemaMetadataRefresh: (...args: any[]) => mocks.fetch(...args) }))

it('useNodeDictionariesMutation синхронизирует и уведомляет по выбранной ноде', () => {
  const { result } = renderHook(() => useNodeDictionariesMutation())
  result.current.mutate({ nodeKey: 'node-a' })
  expect(mocks.fetch).toHaveBeenCalledWith('node-a')
  mocks.config.onSuccess(null, { nodeKey: 'node-a' })
  expect(mocks.success).toHaveBeenCalledWith(expect.stringContaining('node-a'))
})
