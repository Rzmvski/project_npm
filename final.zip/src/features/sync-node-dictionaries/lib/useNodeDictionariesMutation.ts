import { useMutation } from '@tanstack/react-query'
import { notification } from '@v-uik/base'

import { fetchSchemaMetadataRefresh } from '@/features/sync-node-dictionaries/api'

type UseNodeDictionariesMutationParams = {
  nodeKey: string
}

export const useNodeDictionariesMutation = () => {
  return useMutation({
    mutationFn: ({ nodeKey }: UseNodeDictionariesMutationParams) =>
      fetchSchemaMetadataRefresh(nodeKey),
    onSuccess: (_data, { nodeKey }) => {
      notification.success(
        `Синхронизация метаданных на ноде ${nodeKey} завершена, событие отправлено`
      )
    },
  })
}
