import { fetchSchemaMetadataRefresh } from './fetch'

const refreshMetadataOnNode = vi.hoisted(() => vi.fn())
vi.mock('@/shared/api', () => ({
  metadataManagementService: { refreshMetadataOnNode },
}))

it('fetchSchemaMetadataRefresh обновляет метаданные выбранного узла', () => {
  fetchSchemaMetadataRefresh('node-1')
  expect(refreshMetadataOnNode).toHaveBeenCalledWith('node-1')
})
