import { type MetadataDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { metadataManagementService } from '@/shared/api'

/**
 * Отправка запроса на обновление метаданных схем базы данных и справочников
 * Method: PUT
 * URL: /invoke/support-admin/cluster-management-service/nodes/{nodeKey}/metadatas
 * @returns {Promise}
 */
export const fetchSchemaMetadataRefresh = (
  nodeKey: string
): Promise<MetadataDto> => {
  return metadataManagementService.refreshMetadataOnNode(nodeKey)
}
