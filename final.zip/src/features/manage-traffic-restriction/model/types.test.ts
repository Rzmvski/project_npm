import { describe, it, expect } from 'vitest'

import type { ManageMode } from '@/features/manage-traffic-restriction/model/types'

describe('ManageMode type', () => {
  it('should accept create mode', () => {
    const mode: ManageMode = 'create'
    expect(mode).toBe('create')
  })

  it('should accept edit mode', () => {
    const mode: ManageMode = 'edit'
    expect(mode).toBe('edit')
  })

  it('should accept view mode', () => {
    const mode: ManageMode = 'view'
    expect(mode).toBe('view')
  })
})
