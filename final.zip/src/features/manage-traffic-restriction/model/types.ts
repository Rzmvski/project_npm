export type ManageMode = 'create' | 'edit' | 'view'
