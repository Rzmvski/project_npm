import { type TrafficRestriction } from '@/entities/traffic-restriction'
import { geoBalancingManagementService } from '@/shared/api'

export const fetchCreateRestriction = (restriction: TrafficRestriction) => {
  const { createComment } = restriction
  return geoBalancingManagementService.createTrafficRestriction({
    ...restriction,
    comment: createComment,
  })
}

export const fetchUpdateRestriction = (restriction: TrafficRestriction) => {
  const { id, createComment } = restriction
  if (!id) {
    throw Error('restriction id not provided')
  }
  return geoBalancingManagementService.updateTrafficRestriction(id, {
    ...restriction,
    comment: createComment,
  })
}

export const fetchRemoveRestriction = (id: string) => {
  return geoBalancingManagementService.removeTrafficRestrictionById(id)
}
