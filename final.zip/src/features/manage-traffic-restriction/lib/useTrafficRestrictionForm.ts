import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import { v4 as uuid } from 'uuid'

import {
  type TrafficRestriction,
  trafficRestrictionSchema,
  type TrafficRestrictionInputValues,
} from '@/entities/traffic-restriction'


const trafficRestrictionValues: TrafficRestrictionInputValues = {
  id: uuid(),
  name: '',
  applications: [],
  dataCenters: [],
  updateComment: '',
  createComment: '',
}

interface UseTrafficRestrictionFormOptions {
  restriction?: TrafficRestriction
}

export const useTrafficRestrictionForm = ({
  restriction,
}: UseTrafficRestrictionFormOptions) => {
  const getDefaultValues = (): TrafficRestrictionInputValues => {
    if (restriction) {
      const { services, id } = restriction
      return {
        ...restriction,
        id: id ?? 'unknown',
        applications: services,
      }
    }

    return trafficRestrictionValues
  }

  return useForm({
    defaultValues: getDefaultValues(),
    resolver: zodResolver(trafficRestrictionSchema),
  })
}
