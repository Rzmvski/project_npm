import { useMutation, useQueryClient } from '@tanstack/react-query'

import {
  type TrafficRestriction,
  trafficRestrictionQueryKey,
} from '@/entities/traffic-restriction'
import { fetchCreateRestriction } from '@/features/manage-traffic-restriction/api'

export const useRestrictionCreate = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (restriction: TrafficRestriction) =>
      fetchCreateRestriction(restriction),
    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: trafficRestrictionQueryKey }),
  })
}
