import { useMutation, useQueryClient } from '@tanstack/react-query'

import {
  trafficRestrictionQueryKey,
  type TrafficRestriction,
} from '@/entities/traffic-restriction'
import { fetchUpdateRestriction } from '@/features/manage-traffic-restriction/api'

export const useRestrictionUpdate = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (restriction: TrafficRestriction) =>
      fetchUpdateRestriction(restriction),
    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: trafficRestrictionQueryKey }),
  })
}
