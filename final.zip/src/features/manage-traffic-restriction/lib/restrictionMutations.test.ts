import { renderHook } from '@testing-library/react'

import { useRestrictionCreate } from './useRestrictionCreate'
import { useRestrictionDelete } from './useRestrictionDelete'
import { useRestrictionUpdate } from './useRestrictionUpdate'

const mocks = vi.hoisted(() => ({ configs: [] as any[], create: vi.fn(), update: vi.fn(), remove: vi.fn(), invalidate: vi.fn() }))
vi.mock('@tanstack/react-query', () => ({
  useQueryClient: () => ({ invalidateQueries: mocks.invalidate }),
  useMutation: (config: any) => (mocks.configs.push(config), { mutate: config.mutationFn }),
}))
vi.mock('@/features/manage-traffic-restriction/api', () => ({
  fetchCreateRestriction: (...args: any[]) => mocks.create(...args),
  fetchUpdateRestriction: (...args: any[]) => mocks.update(...args),
  fetchRemoveRestriction: (...args: any[]) => mocks.remove(...args),
}))
vi.mock('@/entities/traffic-restriction', () => ({ trafficRestrictionQueryKey: ['restrictions'] }))

it('мутации ограничений создают, обновляют, удаляют и инвалидируют список', () => {
  const restriction = { id: 'one', name: 'Ограничение' }
  renderHook(() => useRestrictionCreate()).result.current.mutate(restriction as never)
  renderHook(() => useRestrictionUpdate()).result.current.mutate(restriction as never)
  renderHook(() => useRestrictionDelete()).result.current.mutate('one')
  expect(mocks.create).toHaveBeenCalledWith(restriction)
  expect(mocks.update).toHaveBeenCalledWith(restriction)
  expect(mocks.remove).toHaveBeenCalledWith('one')
  mocks.configs.forEach((config) => config.onSuccess())
  expect(mocks.invalidate).toHaveBeenCalledTimes(3)
})
