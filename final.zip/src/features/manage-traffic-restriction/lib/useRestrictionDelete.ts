import { useMutation, useQueryClient } from '@tanstack/react-query'

import { trafficRestrictionQueryKey } from '@/entities/traffic-restriction'
import { fetchRemoveRestriction } from '@/features/manage-traffic-restriction/api'

export const useRestrictionDelete = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (id: string) => fetchRemoveRestriction(id),
    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: trafficRestrictionQueryKey }),
  })
}
