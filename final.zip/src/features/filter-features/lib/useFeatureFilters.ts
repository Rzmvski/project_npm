import { useMemo, useState } from 'react'

import {
  type Feature,
  FeatureType,
  type FeatureView,
  FeatureStatus,
} from '@/entities/feature'
import { createObjectMatcher, useOptions, useSearch } from '@/shared/lib'

const typeDictionary: Record<FeatureType, string> = {
  [FeatureType.HotConfig]: 'hot config',
  [FeatureType.Regular]: 'обычный',
}

const matcher = createObjectMatcher<Feature>({
  deep: false,
  caseSensitive: false,
  fields: ['name'],
})

interface UseFeatureFiltersOptions {
  features: FeatureView[]
}

export const useFeatureFilters = ({ features }: UseFeatureFiltersOptions) => {
  const [selectedType, setSelectedType] = useState<Nullable<FeatureType>>(null)
  const [selectedStatus, setSelectedStatus] =
    useState<Nullable<FeatureStatus | 'flipStrat'>>(null)
  const [selectedModule, setSelectedModule] = useState<Nullable<string>>(null)

  const filteredByType = useMemo(() => {
    if (!selectedType) return features

    return features.filter(({ hot }) => {
      if (selectedType === FeatureType.HotConfig) {
        return hot === true
      }
      return hot !== true
    })
  }, [features, selectedType])

  const filteredByStatus = useMemo(() => {
    if (!selectedStatus) return filteredByType

    return filteredByType.filter(({ config: { activation } }) => {
      switch (activation.type) {
        case 'MANUAL': {
          const status = activation.enabled
            ? FeatureStatus.Active
            : FeatureStatus.Inactive
          return selectedStatus === status
        }
        case 'OD_RELEASE':
          return selectedStatus === 'flipStrat'
      }
    })
  }, [filteredByType, selectedStatus])

  const filteredByModule = useMemo(() => {
    if (!selectedModule) return filteredByStatus

    return filteredByStatus.filter(
      ({ target: { module } }) => module === selectedModule
    )
  }, [filteredByStatus, selectedModule])

  const {
    result: filteredFeatures,
    searchQuery,
    setSearchQuery,
  } = useSearch({
    items: filteredByModule,
    searchFn: (items, query) =>
      items.filter((application) => {
        return matcher(application, query)
      }),
  })

  const modules = useMemo(() => {
    return [
      ...new Set(
        features
          .map(({ target: { module } }: Feature) => module)
          .filter((module) => module !== undefined)
      ),
    ]
  }, [features])

  const moduleOptions = useOptions({
    values: [null, ...modules],
    getLabel: (value) => value ?? 'Все',
  })

  const typeOptions = useOptions({
    values: [null, ...Object.values(FeatureType)],
    getLabel: (value) => (value && typeDictionary[value]) ?? 'Все',
  })

  const statusOptions = useOptions({
    values: [null, ...Object.values(FeatureStatus), 'flipStrat'],
    getLabel: (value) => value ?? 'Все',
  })

  return {
    result: filteredFeatures,
    searchQuery,
    setSearchQuery,
    selectedStatus,
    setSelectedStatus,
    selectedType,
    setSelectedType,
    selectedModule,
    setSelectedModule,
    moduleOptions,
    typeOptions,
    statusOptions,
  }
}
