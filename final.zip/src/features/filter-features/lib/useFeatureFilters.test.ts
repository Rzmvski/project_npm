import { act, renderHook } from '@testing-library/react'

import {
  FeatureActivationType,
  FeatureStatus,
  FeatureTargetType,
  FeatureType,
  type FeatureView,
} from '@/entities/feature'

import { useFeatureFilters } from './useFeatureFilters'

const feature = (
  name: string,
  options: {
    hot?: boolean
    enabled?: boolean
    release?: boolean
    module?: string
  } = {},
): FeatureView => ({
  uid: name,
  name,
  hot: options.hot,
  target: {
    type: FeatureTargetType.Direct,
    module: options.module,
  },
  config: {
    activation: options.release
      ? {
          type: FeatureActivationType.OdRelease,
          releaseDate: new Date('2026-08-13'),
        }
      : {
          type: FeatureActivationType.Manual,
          enabled: options.enabled ?? false,
        },
  },
  change: 'none',
})

const features = [
  feature('PAYMENTS', { hot: true, enabled: true, module: 'billing' }),
  feature('REPORTS', { module: 'analytics' }),
  feature('LIMITS', { release: true, module: 'billing' }),
]

describe('useFeatureFilters', () => {
  it('по умолчанию возвращает все фичи и уникальные модули', () => {
    const { result } = renderHook(() => useFeatureFilters({ features }))

    expect(result.current.result).toEqual(features)
    expect(result.current.moduleOptions.map(({ value }) => value)).toEqual([
      null,
      'billing',
      'analytics',
    ])
  })

  it('комбинирует фильтры типа, статуса, модуля и поиска', () => {
    const { result } = renderHook(() => useFeatureFilters({ features }))

    act(() => {
      result.current.setSelectedType(FeatureType.HotConfig)
      result.current.setSelectedStatus(FeatureStatus.Active)
      result.current.setSelectedModule('billing')
      result.current.setSearchQuery('pay')
    })

    expect(result.current.result.map(({ name }) => name)).toEqual(['PAYMENTS'])
  })

  it('отделяет обычные, выключенные и release-date фичи', () => {
    const { result } = renderHook(() => useFeatureFilters({ features }))

    act(() => result.current.setSelectedType(FeatureType.Regular))
    expect(result.current.result.map(({ name }) => name)).toEqual(['REPORTS', 'LIMITS'])

    act(() => result.current.setSelectedStatus(FeatureStatus.Inactive))
    expect(result.current.result.map(({ name }) => name)).toEqual(['REPORTS'])

    act(() => result.current.setSelectedStatus('flipStrat'))
    expect(result.current.result.map(({ name }) => name)).toEqual(['LIMITS'])
  })

  it('предоставляет понятные подписи фильтров', () => {
    const { result } = renderHook(() => useFeatureFilters({ features }))

    expect(result.current.typeOptions.map(({ label }) => label)).toEqual([
      'Все',
      'hot config',
      'обычный',
    ])
    expect(result.current.statusOptions.map(({ label }) => label)).toEqual([
      'Все',
      FeatureStatus.Active,
      FeatureStatus.Inactive,
      'flipStrat',
    ])
  })
})
