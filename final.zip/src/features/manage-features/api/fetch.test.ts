import { fetchUpdateHotConfigs } from './fetch'

const editHotConfigFeatures = vi.hoisted(() => vi.fn())
vi.mock('@/shared/api', () => ({
  featureTogglingService: { editHotConfigFeatures },
}))

it('fetchUpdateHotConfigs передаёт обновлённые hot-config фичи', () => {
  const features = [{ uid: 'feature-1' }]
  fetchUpdateHotConfigs(features as never)
  expect(editHotConfigFeatures).toHaveBeenCalledWith(features)
})
