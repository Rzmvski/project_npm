import { type LogicalFeatureDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { featureTogglingService } from '@/shared/api'

/**
 * Запрос для обновления хотконфигов
 * Method: PATCH
 * URL: /invoke/support-admin/feature-toggling-service/features/hotconfigs
 * @param features - список измененных фич
 */
export function fetchUpdateHotConfigs(
  features: LogicalFeatureDto[]
): Promise<void> {
  return featureTogglingService.editHotConfigFeatures(features)
}
