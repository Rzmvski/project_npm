import { type FeatureApplicationDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { isEmpty } from 'lodash-es'
import { z } from 'zod'

import {
  type Feature,
  FeatureActivationType,
  type FeatureDraft,
  featureSchema,
  FeatureScope,
  FeatureStatus,
  FeatureTargetType,
  hasFeatureConflict,
} from '@/entities/feature'
import { permissionIdSchema } from '@/entities/feature-application'


const notUniqueFeatureMessage = 'Данная фича уже существует'
const notUniqueApplicationIdMessage = 'Заявка с таким номером уже существует'

export const commonFeatureSchema = featureSchema
  .extend({
    uid: z.string(),
    scope: z.nativeEnum(FeatureScope),
    ...permissionIdSchema,
  })
  .refine(
    ({ target: { module }, scope }) =>
      scope === FeatureScope.APP ? !isEmpty(module) : true,
    {
      path: ['target.module'],
      message: '',
    }
  )

export const createFeatureSchema = (
  features: Feature[],
  drafts: FeatureDraft[],
  applications: Pick<FeatureApplicationDto, 'reasonId'>[]
) =>
  commonFeatureSchema
    .refine(
      (candidate) => {
        return !features.some((feature) =>
          hasFeatureConflict(candidate, feature)
        )
      },
      {
        message: notUniqueFeatureMessage,
        path: ['name'],
      }
    )
    .refine(
      ({ permissionId }) => {
        const ids = [
          ...applications.map(({ reasonId }) => reasonId),
          ...drafts.map(({ permissionId }) => permissionId),
        ]

        return !ids.includes(permissionId)
      },
      {
        message: notUniqueApplicationIdMessage,
        path: ['permissionId'],
      }
    )

export type CreateFormSchema = z.input<ReturnType<typeof createFeatureSchema>>

export const defaultValues: CreateFormSchema = {
  name: '',
  config: {
    description: '',
    activation: {
      type: FeatureActivationType.Manual,
      enabled: FeatureStatus.Inactive,
    },
    customProperties: [],
  },
  hot: false,
  target: {
    type: FeatureTargetType.Direct,
    module: '',
  },
  uid: '',
  permissionId: '',
  scope: FeatureScope.GLOBAL,
}

export type DeleteFormSchema = z.infer<ReturnType<typeof deleteFeatureSchema>>

export const deleteFeatureSchema = (
  drafts: FeatureDraft[],
  applications: Pick<FeatureApplicationDto, 'reasonId'>[]
) =>
  z
    .object({
      scope: z.nativeEnum(FeatureScope),
      ...permissionIdSchema,
    })
    .refine(
      ({ permissionId }) => {
        const ids = [
          ...applications.map(({ reasonId }) => reasonId),
          ...drafts.map(({ permissionId }) => permissionId),
        ]

        return !ids.includes(permissionId)
      },
      {
        message: notUniqueApplicationIdMessage,
        path: ['permissionId'],
      }
    )

export type EditFormSchema = z.output<ReturnType<typeof editFeatureSchema>>

const editHotConfigSchema = featureSchema.extend({
  hot: z.literal(true),
  permissionId: z.string().optional(),
})

const editRegularSchema = featureSchema.extend({
  hot: z.literal(false),
  ...permissionIdSchema,
})

export const editFeatureSchema = (
  drafts: FeatureDraft[],
  applications: Pick<FeatureApplicationDto, 'reasonId'>[]
) =>
  z.discriminatedUnion('hot', [editHotConfigSchema, editRegularSchema]).refine(
    ({ permissionId }) => {
      const ids = [
        ...applications.map(({ reasonId }) => reasonId),
        ...drafts.map(({ permissionId }) => permissionId),
      ]

      return !permissionId || !ids.includes(permissionId)
    },
    {
      message: notUniqueApplicationIdMessage,
      path: ['permissionId'],
    }
  )
