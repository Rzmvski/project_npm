import { FeatureApplicationActionDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import {
  FeatureActivationType,
  FeatureScope,
  FeatureStatus,
  FeatureTargetType,
  type Feature,
  type FeatureDraft,
} from '@/entities/feature'

import { createFeatureSchema, deleteFeatureSchema, editFeatureSchema } from './schema'

const featureInput = {
  uid: 'feature-1',
  name: 'payments_enabled',
  hot: false,
  scope: FeatureScope.GLOBAL,
  permissionId: 'REQ123',
  target: { type: FeatureTargetType.Direct },
  config: {
    activation: {
      type: FeatureActivationType.Manual,
      enabled: FeatureStatus.Active,
    },
  },
}

describe('manage feature schemas', () => {
  it('принимает уникальную глобальную фичу и нормализует её', () => {
    const result = createFeatureSchema([], [], []).parse(featureInput)

    expect(result).toMatchObject({
      name: 'PAYMENTS_ENABLED',
      config: { activation: { enabled: true } },
    })
  })

  it('требует module для APP scope', () => {
    const result = createFeatureSchema([], [], []).safeParse({
      ...featureInput,
      scope: FeatureScope.APP,
      target: { type: FeatureTargetType.Direct, module: '' },
    })

    expect(result.success).toBe(false)
  })

  it('отклоняет конфликтующую фичу', () => {
    const existing = {
      ...featureInput,
      name: 'PAYMENTS_ENABLED',
      config: {
        activation: { type: FeatureActivationType.Manual, enabled: true },
      },
    } as Feature

    const result = createFeatureSchema([existing], [], []).safeParse(featureInput)

    expect(result.success).toBe(false)
    if (!result.success) {
      expect(result.error.issues).toEqual(
        expect.arrayContaining([
          expect.objectContaining({
            path: ['name'],
            message: 'Данная фича уже существует',
          }),
        ]),
      )
    }
  })

  it('не допускает повторный номер заявки из сервера или черновиков', () => {
    const draft = {
      uid: 'draft',
      permissionId: 'DRAFT1',
      feature: {} as Feature,
      type: FeatureApplicationActionDto.Create,
    } satisfies FeatureDraft

    expect(
      createFeatureSchema([], [draft], []).safeParse({
        ...featureInput,
        permissionId: 'DRAFT1',
      }).success,
    ).toBe(false)
    expect(
      deleteFeatureSchema([], [{ reasonId: 'SERVER1' }]).safeParse({
        scope: FeatureScope.GLOBAL,
        permissionId: 'SERVER1',
      }).success,
    ).toBe(false)
  })

  it('разрешает hot-config редактирование без заявки, но требует её для regular', () => {
    const common = {
      uid: 'feature-1',
      name: 'FEATURE_ONE',
      target: { type: FeatureTargetType.Direct },
      config: {
        activation: {
          type: FeatureActivationType.Manual,
          enabled: FeatureStatus.Active,
        },
      },
    }

    expect(editFeatureSchema([], []).safeParse({ ...common, hot: true }).success).toBe(true)
    expect(editFeatureSchema([], []).safeParse({ ...common, hot: false }).success).toBe(false)
    expect(
      editFeatureSchema([], [{ reasonId: 'REQ123' }]).safeParse({
        ...common,
        hot: false,
        permissionId: 'REQ123',
      }).success,
    ).toBe(false)
  })
})
