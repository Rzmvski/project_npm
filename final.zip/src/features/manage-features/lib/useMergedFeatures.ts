import { FeatureApplicationActionDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { useMemo } from 'react'

import { type Feature, type FeatureDraft, type FeatureView } from '@/entities/feature'

interface UseMergedFeaturesOptions {
  features: Feature[]
  drafts: FeatureDraft[]
}

export const useMergedFeatures = ({
  features,
  drafts,
}: UseMergedFeaturesOptions) => {
  return useMemo(() => {
    const result: FeatureView[] = features.map((feature) => ({
      ...feature,
      change: 'none',
    }))

    drafts.forEach(({ type, feature, uid }) => {
      switch (type) {
        case FeatureApplicationActionDto.Create: {
          result.unshift({
            ...feature,
            change: FeatureApplicationActionDto.Create,
          })
          break
        }
        case FeatureApplicationActionDto.Update: {
          const index = result.findIndex((f) => f.uid === uid)

          if (index !== -1) {
            result[index] = {
              ...feature,
              change: FeatureApplicationActionDto.Update,
            }
          }
          break
        }
        case FeatureApplicationActionDto.Delete: {
          const index = result.findIndex((f) => f.uid === uid)

          if (index !== -1) {
            result[index] = {
              ...feature,
              change: FeatureApplicationActionDto.Delete,
            }
          }
          break
        }
      }
    })

    return result
  }, [drafts, features])
}
