import { type FeatureApplicationDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { useMemo } from 'react'

import { type FeatureDraft } from '@/entities/feature'
import { deleteFeatureSchema } from '@/features/manage-features/model'

export const useDeleteFeatureValidationSchema = (
  drafts: FeatureDraft[],
  applications: Pick<FeatureApplicationDto, 'reasonId'>[]
): ReturnType<typeof deleteFeatureSchema> => {
  return useMemo(
    () => deleteFeatureSchema(drafts, applications),
    [applications, drafts]
  )
}
