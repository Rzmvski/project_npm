import {
  type CreateFeaturesRequestInnerDto,
  FeatureApplicationActionDto,
  type LogicalFeatureDto,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { notification } from '@v-uik/base'
import { useCallback, useState } from 'react'

import {
  type Feature,
  type FeatureDraft,
  featuresQueryKey,
  getFeatureKey,
} from '@/entities/feature'
import {
  fetchCreateFeatureRequests,
  featureApplicationQueryKey,
} from '@/entities/feature-application'
import { fetchUpdateHotConfigs } from '@/features/manage-features/api'



export const useDrafts = () => {
  const [drafts, setDrafts] = useState<FeatureDraft[]>([])
  const queryClient = useQueryClient()

  const addToDrafts = useCallback(
    (feature: Feature, changeType: FeatureApplicationActionDto, permissionId?: string) => {
      setDrafts((prev) => {
        const uid = getFeatureKey(feature)
        const filtered = prev.filter((f) => f.uid !== uid)
        return [
          ...filtered,
          {
            uid,
            feature: { ...feature, uid },
            type: changeType,
            permissionId,
          },
        ]
      })
    },
    [],
  )

  const removeFromDrafts = useCallback((feature: Feature) => {
    setDrafts((prev) => prev.filter((f) => f.uid !== feature.uid))
  }, [])

  const clearDrafts = useCallback(() => setDrafts([]), [])

  const submitMutation = useMutation({
    mutationFn: async () => {
      const processedDrafts: CreateFeaturesRequestInnerDto[] = []
      const updateHotDrafts: LogicalFeatureDto[] = []

      drafts.forEach((draft) => {
        const { type, feature, permissionId } = draft
        if (type === FeatureApplicationActionDto.Update && feature.hot) {
          updateHotDrafts.push(feature)
        } else {
          if (!permissionId) {
            throw Error('permission id is required')
          }
          const { name, target } = feature
          processedDrafts.push({
            feature: type === FeatureApplicationActionDto.Delete ? { name, target } : feature,
            requestId: permissionId,
            action: type,
          })
        }
      })

      await Promise.all([
        updateHotDrafts.length && fetchUpdateHotConfigs(updateHotDrafts),
        processedDrafts.length && fetchCreateFeatureRequests(processedDrafts),
      ])
    },
    onSuccess: async () => {
      clearDrafts()
      notification.success('Изменения успешно отправлены на сервер', {
        direction: 'vertical',
      })
      await queryClient.invalidateQueries({ queryKey: featuresQueryKey })
      await queryClient.invalidateQueries({
        queryKey: featureApplicationQueryKey,
      })
    },
    onError: () => {
      notification.error('Ошибка при сохранении изменений')
    },
  })

  return {
    drafts,
    addToDrafts,
    removeFromDrafts,
    clearDrafts,
    submit: submitMutation.mutate,
    isSending: submitMutation.isPending,
  }
}
