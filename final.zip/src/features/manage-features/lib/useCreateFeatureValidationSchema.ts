import { type FeatureApplicationDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { useMemo } from 'react'

import { type Feature, type FeatureDraft } from '@/entities/feature'
import { createFeatureSchema } from '@/features/manage-features/model'

export const useCreateFeatureValidationSchema = (
  features: Feature[],
  drafts: FeatureDraft[],
  applications: Pick<FeatureApplicationDto, 'reasonId'>[]
): ReturnType<typeof createFeatureSchema> => {
  return useMemo(
    () => createFeatureSchema(features, drafts, applications),
    [applications, drafts, features]
  )
}
