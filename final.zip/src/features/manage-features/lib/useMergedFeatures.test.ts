import { FeatureApplicationActionDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { renderHook } from '@testing-library/react'

import {
  FeatureActivationType,
  FeatureTargetType,
  type Feature,
  type FeatureDraft,
} from '@/entities/feature'

import { useMergedFeatures } from './useMergedFeatures'

const feature = (uid: string, name = uid.toUpperCase()): Feature => ({
  uid,
  name,
  target: { type: FeatureTargetType.Direct },
  config: {
    activation: { type: FeatureActivationType.Manual, enabled: false },
  },
})

const draft = (type: FeatureApplicationActionDto, value: Feature): FeatureDraft => ({
  uid: value.uid,
  type,
  feature: value,
})

describe('useMergedFeatures', () => {
  it('помечает исходные фичи как неизменённые', () => {
    const source = [feature('one'), feature('two')]
    const { result } = renderHook(() => useMergedFeatures({ features: source, drafts: [] }))

    expect(result.current.map(({ change }) => change)).toEqual(['none', 'none'])
  })

  it('применяет create, update и delete черновики к отображаемому списку', () => {
    const source = [feature('one'), feature('two'), feature('three')]
    const drafts = [
      draft(FeatureApplicationActionDto.Create, feature('new')),
      draft(FeatureApplicationActionDto.Update, feature('two', 'TWO_UPDATED')),
      draft(FeatureApplicationActionDto.Delete, feature('three')),
      draft(FeatureApplicationActionDto.Update, feature('missing')),
    ]

    const { result } = renderHook(() => useMergedFeatures({ features: source, drafts }))

    expect(result.current).toEqual([
      expect.objectContaining({
        uid: 'new',
        change: FeatureApplicationActionDto.Create,
      }),
      expect.objectContaining({ uid: 'one', change: 'none' }),
      expect.objectContaining({
        uid: 'two',
        name: 'TWO_UPDATED',
        change: FeatureApplicationActionDto.Update,
      }),
      expect.objectContaining({
        uid: 'three',
        change: FeatureApplicationActionDto.Delete,
      }),
    ])
  })
})
