import { FeatureApplicationActionDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import React from 'react'

import { type Feature, type FeatureDraft, type FeatureView } from '@/entities/feature'
import { CreateFeatureForm } from '@/features/manage-features/ui/CreateFeatureForm'
import { DeleteFeatureForm } from '@/features/manage-features/ui/DeleteFeatureForm'
import { EditFeatureForm } from '@/features/manage-features/ui/EditFeatureForm'
import { useModal } from '@/shared/lib'


type OperationType = FeatureApplicationActionDto | 'watch'

interface UseManageFeatureModalOptions {
  operationType: OperationType
  onAction: (
    feature: Feature,
    change: FeatureApplicationActionDto,
    permissionId?: string
  ) => void
  selectedFeature?: Feature
}

export const useManageFeatureModal = (
  features: FeatureView[],
  drafts: FeatureDraft[]
) => {
  const { open: openModal, close } = useModal()

  const open = ({
    operationType,
    onAction,
    ...options
  }: UseManageFeatureModalOptions) => {
    const handleAgree = (
      feature: Feature,
      changeType: FeatureApplicationActionDto,
      permissionId?: string
    ) => {
      onAction(feature, changeType, permissionId)
      close()
    }

    const { selectedFeature } = options

    const renderModal = () => {
      switch (operationType) {
        case 'watch': {
          return (
            selectedFeature && (
              <EditFeatureForm
                watchMode
                selectedFeature={selectedFeature}
                drafts={drafts}
                onClose={close}
                onAction={handleAgree}
              />
            )
          )
        }
        case FeatureApplicationActionDto.Create:
          return (
            <CreateFeatureForm
              features={features}
              drafts={drafts}
              onClose={close}
              onAction={handleAgree}
            />
          )
        case FeatureApplicationActionDto.Update: {
          return (
            selectedFeature && (
              <EditFeatureForm
                selectedFeature={selectedFeature}
                drafts={drafts}
                onClose={close}
                onAction={handleAgree}
              />
            )
          )
        }
        case FeatureApplicationActionDto.Delete: {
          return (
            selectedFeature && (
              <DeleteFeatureForm
                selectedFeature={selectedFeature}
                drafts={drafts}
                onClose={close}
                onAction={handleAgree}
              />
            )
          )
        }
      }
    }

    openModal({ width: 'fit-content', renderModal })
  }

  return {
    open,
    close,
  }
}
