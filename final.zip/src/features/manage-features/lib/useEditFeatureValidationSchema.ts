import { type FeatureApplicationDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { useMemo } from 'react'

import { type FeatureDraft } from '@/entities/feature'
import { editFeatureSchema } from '@/features/manage-features/model'

export const useEditFeatureValidationSchema = (
  drafts: FeatureDraft[],
  featureApplications: Pick<FeatureApplicationDto, 'reasonId'>[]
): ReturnType<typeof editFeatureSchema> => {
  return useMemo(
    () => editFeatureSchema(drafts, featureApplications),
    [drafts, featureApplications]
  )
}
