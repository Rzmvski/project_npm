import { FeatureApplicationActionDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { QueryClientProvider } from '@tanstack/react-query'
import { act, renderHook, waitFor } from '@testing-library/react'

import { FeatureActivationType, FeatureTargetType, type Feature } from '@/entities/feature'
import { createTestQueryClient } from '@/test'

import { useDrafts } from './useDrafts'

import type { PropsWithChildren } from 'react'


const api = vi.hoisted(() => ({
  updateHotConfigs: vi.fn().mockResolvedValue(undefined),
  createRequests: vi.fn().mockResolvedValue(undefined),
  success: vi.fn(),
  error: vi.fn(),
}))

vi.mock('@/features/manage-features/api', () => ({
  fetchUpdateHotConfigs: api.updateHotConfigs,
}))

vi.mock('@/entities/feature-application', async () => {
  const actual = await vi.importActual<object>('@/entities/feature-application')
  return {
    ...actual,
    fetchCreateFeatureRequests: api.createRequests,
  }
})

vi.mock('@v-uik/base', async () => {
  const actual = await vi.importActual<object>('@v-uik/base')
  return {
    ...actual,
    notification: { success: api.success, error: api.error },
  }
})

const feature = (name: string, hot = false): Feature => ({
  uid: name,
  name,
  hot,
  target: { type: FeatureTargetType.Direct },
  config: {
    activation: { type: FeatureActivationType.Manual, enabled: false },
  },
})

const renderDrafts = () => {
  const queryClient = createTestQueryClient()
  const wrapper = ({ children }: PropsWithChildren) => (
    <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>
  )

  return { queryClient, ...renderHook(() => useDrafts(), { wrapper }) }
}

describe('useDrafts', () => {
  beforeEach(() => {
    api.updateHotConfigs.mockClear()
    api.createRequests.mockClear()
    api.success.mockClear()
    api.error.mockClear()
  })

  it('добавляет, заменяет и удаляет черновик по доменному ключу', () => {
    const { result } = renderDrafts()

    act(() => {
      result.current.addToDrafts(
        feature('PAYMENTS'),
        FeatureApplicationActionDto.Create,
        'REQ1',
      )
      result.current.addToDrafts(feature('REPORTS'), FeatureApplicationActionDto.Create, 'REQ2')
    })
    expect(result.current.drafts).toHaveLength(2)

    act(() => {
      result.current.addToDrafts(
        feature('PAYMENTS'),
        FeatureApplicationActionDto.Update,
        'REQ3',
      )
    })
    expect(result.current.drafts).toHaveLength(2)
    expect(result.current.drafts[1]).toMatchObject({
      type: FeatureApplicationActionDto.Update,
      permissionId: 'REQ3',
    })

    act(() => result.current.removeFromDrafts(result.current.drafts[0]!.feature))
    expect(result.current.drafts).toHaveLength(1)

    act(() => result.current.clearDrafts())
    expect(result.current.drafts).toEqual([])
  })

  it('отправляет hot updates отдельно от заявок и очищает список', async () => {
    const { result } = renderDrafts()

    act(() => {
      result.current.addToDrafts(
        feature('HOT_CONFIG', true),
        FeatureApplicationActionDto.Update,
      )
      result.current.addToDrafts(
        feature('NEW_FEATURE'),
        FeatureApplicationActionDto.Create,
        'REQ123',
      )
      result.current.addToDrafts(
        feature('OLD_FEATURE'),
        FeatureApplicationActionDto.Delete,
        'REQ456',
      )
    })

    act(() => result.current.submit())

    await waitFor(() => expect(api.success).toHaveBeenCalledOnce())
    expect(api.updateHotConfigs).toHaveBeenCalledWith([
      expect.objectContaining({ name: 'HOT_CONFIG' }),
    ])
    expect(api.createRequests).toHaveBeenCalledWith([
      expect.objectContaining({
        action: FeatureApplicationActionDto.Create,
        requestId: 'REQ123',
      }),
      expect.objectContaining({
        action: FeatureApplicationActionDto.Delete,
        requestId: 'REQ456',
        feature: {
          name: 'OLD_FEATURE',
          target: { type: FeatureTargetType.Direct },
        },
      }),
    ])
    expect(result.current.drafts).toEqual([])
  })

  it('показывает ошибку, если для обычной заявки не указан permission id', async () => {
    const { result } = renderDrafts()

    act(() => {
      result.current.addToDrafts(feature('NEW_FEATURE'), FeatureApplicationActionDto.Create)
      result.current.submit()
    })

    await waitFor(() => expect(api.error).toHaveBeenCalledOnce())
    expect(api.createRequests).not.toHaveBeenCalled()
    expect(result.current.drafts).toHaveLength(1)
  })
})
