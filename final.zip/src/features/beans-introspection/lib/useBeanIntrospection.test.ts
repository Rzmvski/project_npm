import { renderHook } from '@testing-library/react'

import { useBeanIntrospection } from './useBeanIntrospection'

const useBeans = vi.hoisted(() => vi.fn())
vi.mock('@/entities/bean', () => ({ useBeans }))

const createEditor = () => {
  let afterExec: ((event: Record<string, any>) => void) | undefined
  const editor = {
    commands: {
      on: vi.fn((_name, callback) => {
        afterExec = callback
      }),
    },
    completers: [] as Array<Record<string, any>>,
    execCommand: vi.fn(),
  }

  return {
    editor,
    afterExec: () => afterExec!,
  }
}

const completionsFor = (completer: Record<string, any>, line: string, prefix: string) => {
  const callback = vi.fn()
  completer.getCompletions(
    {},
    { getLine: () => line },
    { row: 0, column: line.length },
    prefix,
    callback,
  )
  return callback.mock.calls[0]?.[1]
}

describe('useBeanIntrospection', () => {
  beforeEach(() => {
    useBeans.mockReturnValue({
      data: [
        {
          name: 'paymentService',
          methods: [
            { name: 'find', parameters: ['id'] },
            { name: 'flush', parameters: [] },
          ],
        },
        { name: 'reportService', methods: [] },
      ],
    })
  })

  it('без editor только возвращает состояние загрузки beans', () => {
    const beansResult = { data: undefined, isLoading: true }
    useBeans.mockReturnValueOnce(beansResult)

    const { result } = renderHook(() => useBeanIntrospection(null))

    expect(result.current).toBe(beansResult)
  })

  it('запускает autocomplete после ввода точки', () => {
    const { editor, afterExec } = createEditor()
    renderHook(() => useBeanIntrospection(editor as never))

    afterExec()({
      command: { name: 'insertstring' },
      args: '.',
      editor,
    })
    expect(editor.execCommand).toHaveBeenCalledWith('startAutocomplete')

    afterExec()({ command: { name: 'backspace' }, args: '.', editor })
    afterExec()({ command: { name: 'insertstring' }, args: 'x', editor })
    expect(editor.execCommand).toHaveBeenCalledOnce()
  })

  it('предлагает beans по префиксу', () => {
    const { editor } = createEditor()
    renderHook(() => useBeanIntrospection(editor as never))

    expect(completionsFor(editor.completers[0]!, 'pay', 'pay')).toEqual([
      {
        caption: 'paymentService',
        value: 'paymentService',
        meta: 'bean',
        score: 1000,
      },
    ])
  })

  it('предлагает методы bean с сигнатурой', () => {
    const { editor } = createEditor()
    renderHook(() => useBeanIntrospection(editor as never))

    expect(completionsFor(editor.completers[0]!, 'paymentService.fi', 'fi')).toEqual([
      {
        caption: 'find(id)',
        value: 'find(',
        meta: 'method',
        score: 900,
      },
    ])
    expect(completionsFor(editor.completers[0]!, 'unknown.fi', 'fi')).toEqual([])
  })

  it('возвращает пустые варианты до загрузки данных', () => {
    useBeans.mockReturnValueOnce({ data: undefined })
    const { editor } = createEditor()
    renderHook(() => useBeanIntrospection(editor as never))

    expect(completionsFor(editor.completers[0]!, 'pay', 'pay')).toEqual([])
  })

  it('сигнализирует о выражении без bean перед точкой', () => {
    const { editor } = createEditor()
    renderHook(() => useBeanIntrospection(editor as never))

    expect(() => completionsFor(editor.completers[0]!, '.find', 'find')).toThrow(
      'bean name not found',
    )
  })
})
