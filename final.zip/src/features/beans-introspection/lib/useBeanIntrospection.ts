import { type Ace } from 'ace-builds'
import { useEffect } from 'react'

import { useBeans } from '@/entities/bean'

export const useBeanIntrospection = (editor: Nullable<Ace.Editor>) => {
  const useBeansResult = useBeans()
  const { data } = useBeansResult

  useEffect(() => {
    if (!editor) return

    editor.commands.on('afterExec', ({ command, args, editor }) => {
      if (command.name == 'insertstring' && args.includes('.')) {
        editor.execCommand('startAutocomplete')
      }
    })

    const completer: Ace.Completer = {
      getCompletions(
        _editor: Ace.Editor,
        session: Ace.EditSession,
        position: Ace.Point,
        prefix: string,
        callback: Ace.CompleterCallback
      ) {
        const line = session.getLine(position.row)
        const beforeCursor = line.slice(0, position.column)
        const dotIndex = beforeCursor.lastIndexOf('.')

        if (dotIndex === -1) {
          callback(null, beanCompletions(prefix))
          return
        }

        const beanName = extractBeanName(beforeCursor, dotIndex)
        const methodPrefix = beforeCursor.slice(dotIndex + 1)
        callback(null, methodCompletions(beanName, methodPrefix))
      },
    }

    function beanCompletions(prefix: string): Ace.Completion[] {
      if (!data) return []
      return data
        .filter(({ name }) => name.startsWith(prefix))
        .map(({ name }) => ({
          caption: name,
          value: name,
          meta: 'bean',
          score: 1000,
        }))
    }

    function methodCompletions(
      beanName: string,
      prefix: string
    ): Ace.Completion[] {
      const bean = data?.find(({ name }) => name === beanName)
      if (!bean) return []
      const { methods } = bean
      return methods
        .filter(({ name }) => name.startsWith(prefix))
        .map(({ name, parameters }) => ({
          caption: `${name}(${parameters.join(', ')})`,
          value: `${name}(`,
          meta: 'method',
          score: 900,
        }))
    }

    function extractBeanName(line: string, dotIndex: number): string {
      const beanName = line.slice(0, dotIndex).trim().split(/\s+/).pop()

      if (!beanName) throw Error('bean name not found')

      return beanName
    }

    editor.completers.push(completer)
  }, [data, editor])

  return useBeansResult
}
