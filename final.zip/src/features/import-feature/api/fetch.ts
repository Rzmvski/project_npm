import { type LogicalFeatureDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { featureTogglingService } from '@/shared/api'

export const fetchLoadDump = (
  permissionId: string,
  dump: LogicalFeatureDto[]
) => {
  return featureTogglingService.loadFeatureDump({
    requestId: permissionId,
    dump,
  })
}
