import { fetchLoadDump } from './fetch'

const loadFeatureDump = vi.hoisted(() => vi.fn())
vi.mock('@/shared/api', () => ({ featureTogglingService: { loadFeatureDump } }))

it('fetchLoadDump объединяет permission id и dump', () => {
  const dump = [{ uid: 'feature-1' }]
  fetchLoadDump('REQ123', dump as never)
  expect(loadFeatureDump).toHaveBeenCalledWith({ requestId: 'REQ123', dump })
})
