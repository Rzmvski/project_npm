export class InvalidJsonError extends Error {}
