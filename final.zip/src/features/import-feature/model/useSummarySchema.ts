import { useMemo } from 'react'
import { z } from 'zod'

import { permissionIdSchema } from '@/entities/feature-application'

export const useSummarySchema = (ids: string[]) => {
  return useMemo(() => summarySchema(ids), [ids])
}

const summarySchema = (ids: string[]) => {
  return z
    .object({
      ...permissionIdSchema,
      confirm: z.literal(true),
    })
    .refine(
      ({ permissionId }) => {
        return !permissionId || !ids.includes(permissionId)
      },
      {
        message: 'Заявка с таким номером уже существует',
        path: ['permissionId'],
      }
    )
}
export type SummarySchema = z.infer<ReturnType<typeof useSummarySchema>>
