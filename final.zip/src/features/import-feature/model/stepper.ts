export type ImportStep = 'upload' | 'preview' | 'confirm'
