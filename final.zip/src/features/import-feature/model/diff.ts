import { type Feature } from '@/entities/feature'

export type PreviewTabName = 'all' | 'skip' | 'create' | 'update'

export type FeatureChange = {
  field: string
  before: unknown
  after: unknown
}

type PreviewImportDiff = {
  type: 'create' | 'skip'
  uid: string
  feature: Feature
}

type UpdateImportDiff = {
  type: 'update'
  uid: string
  current: Feature
  imported: Feature
  changes: FeatureChange[]
}

export type FeatureImportDiff = PreviewImportDiff | UpdateImportDiff
