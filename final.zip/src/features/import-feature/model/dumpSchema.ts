import { z } from 'zod'

import {
  customParameterSchema,
  FeatureActivationType,
  featureTargetSchema,
} from '@/entities/feature'

const manualActivationSchema = z.object({
  type: z.literal(FeatureActivationType.Manual),
  enabled: z.boolean(),
})

const odReleaseActivationSchema = z.object({
  type: z.literal(FeatureActivationType.OdRelease),
  releaseDate: z.coerce.date(),
})

const featureActivationSchema = z.discriminatedUnion('type', [
  manualActivationSchema,
  odReleaseActivationSchema,
])

const featureConfigurationSchema = z.object({
  activation: featureActivationSchema,
  description: z.string().optional(),
  customProperties: z.array(customParameterSchema).optional(),
})

export const featureDumpSchema = z
  .object({
    uid: z.string(),
    name: z
      .string()
      .nonempty()
      .regex(/^[^\d\W][a-zA-Z\d_]*$/, 'Допустимы символы: A-Z, цифры и "_"'),
    hot: z.coerce.boolean().optional(),
    target: featureTargetSchema,
    config: featureConfigurationSchema,
    created: z.coerce.date().optional(),
    updated: z.coerce.date().optional(),
  })
  .array()
