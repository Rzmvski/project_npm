import { type ZodIssue } from 'zod'

type DumpIssue = {
  issue: ZodIssue
  name?: string
}

export class InvalidDumpError extends Error {
  constructor(public readonly issues: DumpIssue[]) {
    super('Некорректная структура данных')
    this.cause = issues
  }
}
