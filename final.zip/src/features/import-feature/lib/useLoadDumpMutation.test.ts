import { renderHook } from '@testing-library/react'

import { useLoadDumpMutation } from './useLoadDumpMutation'

const mocks = vi.hoisted(() => ({ config: null as any, fetch: vi.fn(), success: vi.fn(), invalidate: vi.fn() }))
vi.mock('@tanstack/react-query', () => ({
  useQueryClient: () => ({ invalidateQueries: mocks.invalidate }),
  useMutation: (config: any) => ((mocks.config = config), { mutate: config.mutationFn }),
}))
vi.mock('@v-uik/base', () => ({ notification: { success: mocks.success } }))
vi.mock('@/features/import-feature/api', () => ({ fetchLoadDump: (...args: any[]) => mocks.fetch(...args) }))
vi.mock('@/entities/feature-application', () => ({ featureApplicationQueryKey: ['applications'] }))

it('useLoadDumpMutation импортирует dump, сообщает итог и обновляет заявки', async () => {
  const { result } = renderHook(() => useLoadDumpMutation())
  const dump = [{ uid: 'one' }]
  result.current.mutate({ permissionId: 'REQ', dump } as never)
  expect(mocks.fetch).toHaveBeenCalledWith('REQ', dump)
  await mocks.config.onSuccess({ created: 1, updated: 2, skipped: 3 })
  expect(mocks.success).toHaveBeenCalledWith(expect.stringContaining('Создано заявок'), { direction: 'vertical' })
  expect(mocks.invalidate).toHaveBeenCalledWith({ queryKey: ['applications'] })
})
