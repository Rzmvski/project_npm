import { useMemo, useState } from 'react'

import { useDiffGroups } from '@/features/import-feature/lib/useDiffGroups.ts'
import { type FeatureImportDiff } from '@/features/import-feature/model'

type PreviewTabName = 'all' | 'skip' | 'create' | 'update'

type PreviewTab = {
  value: PreviewTabName
  header: string
}

interface UseDiffTabsOptions {
  diff: FeatureImportDiff[]
}

export const useDiffTabs = ({ diff }: UseDiffTabsOptions) => {
  const [currentTab, setCurrentTab] = useState<PreviewTabName>('all')

  const groupedCards = useDiffGroups({ diff })
  const { create, update, skip, all } = groupedCards

  const tabs: PreviewTab[] = useMemo(
    () => [
      {
        value: 'all',
        header: `Все (${all.length})`,
      },
      {
        value: 'create',
        header: `Новые (${create.length})`,
      },
      {
        value: 'update',
        header: `Изменённые (${update.length})`,
      },
      {
        value: 'skip',
        header: `Без изменений (${skip.length})`,
      },
    ],
    [all.length, create.length, skip.length, update.length]
  )

  const currentItems = groupedCards[currentTab]

  return {
    currentTab,
    currentItems,
    tabs,
    setCurrentTab,
  }
}
