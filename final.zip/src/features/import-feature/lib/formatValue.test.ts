import { NOTHING } from '@/shared/model'

import { formatValue } from './formatValue'

describe('formatValue', () => {
  it.each([null, undefined, '', []])('показывает отсутствие значения для %j', (value) => {
    expect(formatValue(value)).toBe(NOTHING)
  })

  it('форматирует дату с временем или только календарную дату', () => {
    const value = new Date(2026, 7, 13, 14, 5, 9)

    expect(formatValue(value)).toBe('13.08.2026 14:05:09')
    expect(formatValue(value, true)).toBe('13.08.2026')
  })

  it.each([
    [[1, 2], '[1,2]'],
    [{ enabled: true }, '{"enabled":true}'],
    [false, 'false'],
    [42, '42'],
  ])('форматирует %j как %s', (value, expected) => {
    expect(formatValue(value)).toBe(expected)
  })
})
