import { act, renderHook } from '@testing-library/react'

import type { FeatureImportDiff } from '@/features/import-feature/model'

import { useDiffTabs } from './useDiffTabs'

const diff = [
  { type: 'create', uid: 'new' },
  { type: 'update', uid: 'changed' },
  { type: 'skip', uid: 'same' },
] as FeatureImportDiff[]

it('useDiffTabs показывает счётчики и переключает текущую группу', () => {
  const { result } = renderHook(() => useDiffTabs({ diff }))

  expect(result.current.tabs.map(({ header }) => header)).toEqual([
    'Все (3)',
    'Новые (1)',
    'Изменённые (1)',
    'Без изменений (1)',
  ])
  expect(result.current.currentItems).toBe(diff)

  act(() => result.current.setCurrentTab('update'))
  expect(result.current.currentItems.map(({ uid }) => uid)).toEqual(['changed'])
})
