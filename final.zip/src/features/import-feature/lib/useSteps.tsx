import { useState } from 'react'

import { type ImportStep } from '@/features/import-feature/model'

const STEP_ORDER: ImportStep[] = ['upload', 'preview', 'confirm']

export const useSteps = () => {
  const [activeStep, setActiveStep] = useState<ImportStep>('upload')

  const onNextStep = () => {
    setActiveStep((prev) => {
      const currentIndex = STEP_ORDER.indexOf(prev)

      return STEP_ORDER[currentIndex + 1] ?? prev
    })
  }

  const onPreviousStep = () => {
    setActiveStep((prev) => {
      const currentIndex = STEP_ORDER.indexOf(prev)

      return STEP_ORDER[currentIndex - 1] ?? prev
    })
  }

  return {
    activeStep,
    onPreviousStep,
    onNextStep,
    isLast: activeStep === 'confirm',
    isFirst: activeStep === 'upload',
  }
}
