import { useMemo } from 'react'

import {
  type FeatureImportDiff,
  type PreviewTabName,
} from '@/features/import-feature/model'

type GroupedCards = Record<PreviewTabName, FeatureImportDiff[]>

interface UseDiffGroupsOptions {
  diff: FeatureImportDiff[]
}

export const useDiffGroups = ({ diff }: UseDiffGroupsOptions) => {
  return useMemo(() => {
    const initial: GroupedCards = {
      create: [],
      all: diff,
      skip: [],
      update: [],
    }

    return diff.reduce<GroupedCards>((acc, item) => {
      const { type } = item
      switch (type) {
        case 'create': {
          acc.create.push(item)
          break
        }
        case 'update':
          acc.update.push(item)
          break
        case 'skip': {
          acc.skip.push(item)
          break
        }
      }

      return acc
    }, initial)
  }, [diff])
}
