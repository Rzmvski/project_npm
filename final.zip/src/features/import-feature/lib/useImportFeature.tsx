import { createUseStyles } from '@v-uik/base'

import { type Feature } from '@/entities/feature'
import { ImportFeatureModal } from '@/features/import-feature/ui/ImportFeatureModal'
import { useModal } from '@/shared/lib'

const useStyles = createUseStyles({
  modalContent: {
    height: '90vh',
    minWidth: '60vw',
  },
})

export const useImportFeature = (features: Feature[], ids: string[]) => {
  const { modalContent } = useStyles()
  const { open: openModal, close } = useModal()

  const open = () => {
    openModal({
      classes: { modalContent },
      renderModal: () => (
        <ImportFeatureModal features={features} onClose={close} ids={ids} />
      ),
    })
  }

  return {
    open,
    close,
  }
}
