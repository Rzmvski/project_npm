import { type ZodIssue } from 'zod'

import { type Feature } from '@/entities/feature'
import {
  featureDumpSchema,
  InvalidDumpError,
} from '@/features/import-feature/model'
import { InvalidJsonError } from '@/features/import-feature/model/InvalidJsonError.ts'

const getFeatureName = (json: unknown, issue: ZodIssue): string | undefined => {
  if (!Array.isArray(json)) return undefined

  const index = issue.path.find(
    (segment): segment is number => typeof segment === 'number'
  )

  if (index === undefined) return undefined

  const item = json[index]

  if (typeof item === 'object' && 'name' in item) {
    return item.name
  }

  return undefined
}

export const parseDump = async (file: File): Promise<Feature[]> => {
  const text = await file.text()

  let json: unknown

  try {
    json = JSON.parse(text)
  } catch {
    throw new InvalidJsonError('Ошибка парсинга файла в JSON')
  }

  const result = featureDumpSchema.safeParse(json)

  if (!result.success) {
    throw new InvalidDumpError(
      result.error.issues.map((issue) => ({
        issue,
        name: getFeatureName(json, issue),
      }))
    )
  }

  return result.data
}
