import { formatDate } from '@/shared/lib'
import { NOTHING } from '@/shared/model'

export const formatValue = (value: unknown, onlyDate?: boolean) => {
  if (value === null || value === undefined || value === '') return NOTHING

  if (value instanceof Date) {
    const dateFormat = onlyDate ? 'dd.MM.yyyy' : 'dd.MM.yyyy HH:mm:ss'
    return formatDate(value, dateFormat)
  }

  if (Array.isArray(value)) {
    return value.length ? JSON.stringify(value) : NOTHING
  }

  if (typeof value === 'object') {
    return JSON.stringify(value)
  }

  return String(value)
}
