import { renderHook } from '@testing-library/react'

import type { FeatureImportDiff } from '@/features/import-feature/model'

import { useDiffGroups } from './useDiffGroups'

describe('useDiffGroups', () => {
  it('группирует карточки preview, сохраняя полный исходный порядок', () => {
    const diff = [
      { type: 'create', uid: 'new' },
      { type: 'skip', uid: 'same' },
      { type: 'update', uid: 'changed' },
    ] as FeatureImportDiff[]

    const { result } = renderHook(() => useDiffGroups({ diff }))

    expect(result.current.all).toBe(diff)
    expect(result.current.create.map(({ uid }) => uid)).toEqual(['new'])
    expect(result.current.skip.map(({ uid }) => uid)).toEqual(['same'])
    expect(result.current.update.map(({ uid }) => uid)).toEqual(['changed'])
  })

  it('возвращает пустые группы для пустого diff', () => {
    const { result } = renderHook(() => useDiffGroups({ diff: [] }))

    expect(result.current).toEqual({
      all: [],
      create: [],
      update: [],
      skip: [],
    })
  })
})
