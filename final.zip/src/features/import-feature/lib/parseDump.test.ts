import { FeatureActivationType, FeatureTargetType } from '@/entities/feature'
import { InvalidDumpError } from '@/features/import-feature/model'
import { InvalidJsonError } from '@/features/import-feature/model/InvalidJsonError'

import { parseDump } from './parseDump'

const fileWith = (content: string): File =>
  ({ text: vi.fn().mockResolvedValue(content) }) as unknown as File

describe('parseDump', () => {
  it('читает валидный dump и преобразует даты', async () => {
    const result = await parseDump(
      fileWith(
        JSON.stringify([
          {
            uid: 'feature-1',
            name: 'FEATURE_ONE',
            target: { type: FeatureTargetType.Direct },
            config: {
              activation: {
                type: FeatureActivationType.OdRelease,
                releaseDate: '2026-08-13T00:00:00.000Z',
              },
            },
            created: '2026-08-01T00:00:00.000Z',
          },
        ]),
      ),
    )

    expect(result[0]?.config.activation).toMatchObject({
      releaseDate: new Date('2026-08-13T00:00:00.000Z'),
    })
    expect(result[0]?.created).toEqual(new Date('2026-08-01T00:00:00.000Z'))
  })

  it('отличает синтаксическую ошибку JSON', async () => {
    await expect(parseDump(fileWith('{not-json'))).rejects.toBeInstanceOf(InvalidJsonError)
  })

  it('возвращает имя фичи вместе с ошибкой её структуры', async () => {
    const promise = parseDump(fileWith(JSON.stringify([{ name: 'BROKEN_FEATURE' }])))

    await expect(promise).rejects.toBeInstanceOf(InvalidDumpError)
    await expect(promise).rejects.toMatchObject({
      issues: expect.arrayContaining([expect.objectContaining({ name: 'BROKEN_FEATURE' })]),
    })
  })

  it('обрабатывает ошибку верхнего уровня без имени фичи', async () => {
    await expect(parseDump(fileWith('{}'))).rejects.toMatchObject({
      issues: [expect.objectContaining({ name: undefined })],
    })
  })
})
