import { FeatureActivationType, FeatureTargetType, type Feature } from '@/entities/feature'

import { calculateDiff, getFeatureChanges } from './calculateDiff'

const manualFeature = (
  uid: string,
  enabled: boolean,
  overrides: Partial<Feature> = {},
): Feature => ({
  uid,
  name: uid.toUpperCase(),
  target: { type: FeatureTargetType.Direct },
  config: {
    description: 'description',
    activation: { type: FeatureActivationType.Manual, enabled },
    customProperties: [],
  },
  ...overrides,
})

describe('calculateDiff', () => {
  it('разделяет новые, неизменённые и изменённые фичи', () => {
    const current = [manualFeature('same', true), manualFeature('changed', true)]
    const imported = [
      manualFeature('same', true),
      manualFeature('changed', false),
      manualFeature('new', true),
    ]

    expect(calculateDiff(current, imported)).toEqual([
      expect.objectContaining({ type: 'skip', uid: 'same' }),
      expect.objectContaining({
        type: 'update',
        uid: 'changed',
        changes: [{ field: 'enabled', before: true, after: false }],
      }),
      expect.objectContaining({ type: 'create', uid: 'new' }),
    ])
  })

  it('показывает изменение описания и пользовательских параметров', () => {
    const current = manualFeature('feature', true, {
      config: {
        description: 'before',
        activation: { type: FeatureActivationType.Manual, enabled: true },
        customProperties: [
          { name: 'changed', type: 'string', value: 'old' },
          { name: 'removed', type: 'boolean', value: 'true' },
        ],
      },
    })
    const imported = manualFeature('feature', true, {
      config: {
        description: 'after',
        activation: { type: FeatureActivationType.Manual, enabled: true },
        customProperties: [
          { name: 'changed', type: 'number', value: '10' },
          { name: 'added', type: 'string', value: 'new' },
        ],
      },
    })

    expect(getFeatureChanges(current.config, imported.config)).toEqual(
      expect.arrayContaining([
        { field: 'description', before: 'before', after: 'after' },
        {
          field: 'customProperties.changed.type',
          before: 'string',
          after: 'number',
        },
        {
          field: 'customProperties.changed.value',
          before: 'old',
          after: '10',
        },
        {
          field: 'customProperties.removed.type',
          before: 'boolean',
          after: undefined,
        },
        {
          field: 'customProperties.added.value',
          before: undefined,
          after: 'new',
        },
      ]),
    )
  })

  it('описывает смену manual-стратегии на дату релиза', () => {
    const date = new Date('2026-08-13T10:00:00.000Z')
    const changes = getFeatureChanges(
      { activation: { type: FeatureActivationType.Manual, enabled: false } },
      {
        activation: { type: FeatureActivationType.OdRelease, releaseDate: date },
      },
    )

    expect(changes).toEqual([
      {
        field: 'strategy',
        before: FeatureActivationType.Manual,
        after: FeatureActivationType.OdRelease,
      },
      { field: 'releaseDate', before: undefined, after: date },
    ])
  })

  it('описывает смену даты по календарному дню, а не времени', () => {
    const sameDayMorning = new Date('2026-08-13T01:00:00.000Z')
    const sameDayEvening = new Date('2026-08-13T20:00:00.000Z')
    const nextDay = new Date('2026-08-14T01:00:00.000Z')

    const base = {
      activation: {
        type: FeatureActivationType.OdRelease as const,
        releaseDate: sameDayMorning,
      },
    }

    expect(
      getFeatureChanges(base, {
        activation: {
          type: FeatureActivationType.OdRelease,
          releaseDate: sameDayEvening,
        },
      }),
    ).toEqual([])
    expect(
      getFeatureChanges(base, {
        activation: {
          type: FeatureActivationType.OdRelease,
          releaseDate: nextDay,
        },
      }),
    ).toEqual([{ field: 'releaseDate', before: sameDayMorning, after: nextDay }])
  })

  it('при возврате к manual-стратегии сообщает итоговый enabled', () => {
    const changes = getFeatureChanges(
      {
        activation: {
          type: FeatureActivationType.OdRelease,
          releaseDate: new Date('2026-08-13'),
        },
      },
      { activation: { type: FeatureActivationType.Manual, enabled: true } },
    )

    expect(changes).toEqual([
      {
        field: 'strategy',
        before: FeatureActivationType.OdRelease,
        after: FeatureActivationType.Manual,
      },
      { field: 'enabled', before: undefined, after: true },
    ])
  })
})
