import { act, renderHook } from '@testing-library/react'

import { useSteps } from './useSteps'

describe('useSteps', () => {
  it('проходит шаги вперёд и назад, не выходя за границы', () => {
    const { result } = renderHook(() => useSteps())

    expect(result.current).toMatchObject({
      activeStep: 'upload',
      isFirst: true,
      isLast: false,
    })

    act(() => result.current.onPreviousStep())
    expect(result.current.activeStep).toBe('upload')

    act(() => result.current.onNextStep())
    expect(result.current.activeStep).toBe('preview')

    act(() => result.current.onNextStep())
    expect(result.current).toMatchObject({
      activeStep: 'confirm',
      isFirst: false,
      isLast: true,
    })

    act(() => result.current.onNextStep())
    expect(result.current.activeStep).toBe('confirm')

    act(() => result.current.onPreviousStep())
    expect(result.current.activeStep).toBe('preview')
  })
})
