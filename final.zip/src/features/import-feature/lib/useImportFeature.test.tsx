import { renderHook } from '@testing-library/react'

import { useImportFeature } from './useImportFeature'

const mocks = vi.hoisted(() => ({ open: vi.fn(), close: vi.fn() }))

vi.mock('@/shared/lib', () => ({
  useModal: () => ({ open: mocks.open, close: mocks.close }),
}))

vi.mock('@v-uik/base', () => ({
  createUseStyles: () => () => ({ modalContent: 'modal-content' }),
}))

vi.mock('@/features/import-feature/ui/ImportFeatureModal', () => ({
  ImportFeatureModal: () => <span>Импорт</span>,
}))

it('useImportFeature открывает modal с переданными features и ids', () => {
  const features = [{ uid: 'feature-1' }]
  const { result } = renderHook(() => useImportFeature(features as never, ['REQ1']))

  result.current.open()

  const config = mocks.open.mock.calls[0]?.[0]
  expect(config.classes).toEqual({ modalContent: 'modal-content' })
  expect(config.renderModal().props).toMatchObject({
    features,
    ids: ['REQ1'],
    onClose: mocks.close,
  })
  expect(result.current.close).toBe(mocks.close)
})
