import { act, renderHook } from '@testing-library/react'

import { useGraphAnimation } from './useGraphAnimation'

vi.mock('@v-uik/base', async () => {
  const React = await import('react')
  return { useStorage: () => React.useState('enabled') }
})

it('useGraphAnimation переключает сохранённый режим анимации', () => {
  const { result } = renderHook(() => useGraphAnimation())
  expect(result.current.isAnimated).toBe(true)
  act(() => result.current.toggle())
  expect(result.current.isAnimated).toBe(false)
  act(() => result.current.toggle())
  expect(result.current.isAnimated).toBe(true)
})
