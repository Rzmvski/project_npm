import { describe, it, expect } from 'vitest'

import { generateGraph } from '@/features/build-restriction-graph/lib/generateGraph'

describe('generateGraph', () => {
  it('should generate graph with data centers and services', () => {
    const result = generateGraph(
      ['dc1', 'dc2'],
      [],
      [],
      [{ name: 'App1', dataCenters: new Set(['dc1', 'dc2']) }],
      undefined,
    )

    expect(result.nodes.length).toBeGreaterThan(0)
    expect(result.edges.length).toBeGreaterThan(0)
  })

  it('should create allApps node when no services provided', () => {
    const result = generateGraph(['dc1'], [], [], [], undefined)

    const allAppsNode = result.nodes.find((n) => n.type === 'allApps')
    expect(allAppsNode).toBeDefined()
    expect(allAppsNode?.data.label).toBe('Все приложения')
  })

  it('should create edges between apps and DCs', () => {
    const result = generateGraph(
      ['dc1', 'dc2'],
      [],
      [],
      [{ name: 'App1', dataCenters: new Set(['dc1']) }],
      undefined,
    )

    const appEdge = result.edges.find((e) => e.source === 'app-App1' && e.target === 'dc-dc1')
    expect(appEdge).toBeDefined()
  })
})
