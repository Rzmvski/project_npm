import { useReactFlow } from '@xyflow/react'
import { type DependencyList, useEffect } from 'react'

export const useGraphFitView = (deps: DependencyList) => {
  const { fitView } = useReactFlow()

  useEffect(() => {
    const frame = requestAnimationFrame(() => {
      return fitView({ padding: { top: 0.3 }, duration: 1000 })
    })

    return () => cancelAnimationFrame(frame)
  }, [fitView, deps])
}
