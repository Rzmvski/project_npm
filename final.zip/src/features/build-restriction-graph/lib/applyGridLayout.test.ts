import { describe, it, expect } from 'vitest'

import { applyGridLayout } from '@/features/build-restriction-graph/lib/applyGridLayout'
import { generateGraph } from '@/features/build-restriction-graph/lib/generateGraph'

describe('applyGridLayout', () => {
  it('should position all nodes', () => {
    const graph = generateGraph(
      ['dc1', 'dc2'],
      [],
      [],
      [{ name: 'App1', dataCenters: new Set(['dc1', 'dc2']) }],
      undefined,
    )

    const result = applyGridLayout(graph)

    result.nodes.forEach((node) => {
      expect(node.position).toBeDefined()
      expect(typeof node.position.x).toBe('number')
      expect(typeof node.position.y).toBe('number')
    })
  })

  it('should preserve edges', () => {
    const graph = generateGraph(
      ['dc1'],
      [],
      [],
      [{ name: 'App1', dataCenters: new Set(['dc1']) }],
      undefined,
    )

    const result = applyGridLayout(graph)
    expect(result.edges).toEqual(graph.edges)
  })

  it('should place DC nodes below app nodes', () => {
    const graph = generateGraph(
      ['dc1', 'dc2', 'dc3'],
      [],
      [],
      [
        { name: 'App1', dataCenters: new Set(['dc1']) },
        { name: 'App2', dataCenters: new Set(['dc2']) },
      ],
      undefined,
    )

    const result = applyGridLayout(graph)

    const appNode = result.nodes.find((n) => n.type === 'application')
    const dcNode = result.nodes.find((n) => n.type === 'dataCenter')

    if (appNode && dcNode) {
      expect(dcNode.position.y).toBeGreaterThan(appNode.position.y)
    }
  })
})
