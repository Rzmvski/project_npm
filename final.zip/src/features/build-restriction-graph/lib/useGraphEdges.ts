import { MarkerType } from '@xyflow/system'
import { useMemo } from 'react'

import { type GraphEdge } from '@/features/build-restriction-graph/model'

interface UseGraphEdgesOptions {
  graphEdges: GraphEdge[]
  isAnimated: boolean
  isHighlighted: (restrictionIds: string[]) => boolean
}

export const useGraphEdges = ({
  graphEdges,
  isAnimated,
  isHighlighted,
}: UseGraphEdgesOptions) => {
  return useMemo(() => {
    return graphEdges.map((edge): GraphEdge => {
      const { restricted, restrictionIds } = edge.data!
      const highlighted = isHighlighted(restrictionIds)

      const baseColor = restricted ? '#94a3b8' : '#3b82f6'
      const strokeColor = highlighted ? '#f59e0b' : baseColor
      const strokeWidth = highlighted ? 2 : restricted ? 1.5 : 2

      return {
        ...edge,
        data: {
          ...edge.data!,
          isAnimated,
          isHighlighted: highlighted,
        },
        animated: !restricted && isAnimated,
        style: {
          stroke: strokeColor,
          strokeWidth,
        },
        markerEnd: {
          type: MarkerType.ArrowClosed,
          color: strokeColor,
          width: 12,
          height: 12,
        },
      }
    })
  }, [graphEdges, isAnimated, isHighlighted])
}
