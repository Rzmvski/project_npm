import { useToggle } from '@v-uik/base'
import { useCallback } from 'react'

export const useRestrictionHighlight = (currentRestrictionId?: string) => {
  const [enabled, toggle] = useToggle(true)

  const isHighlighted = useCallback(
    (restrictionIds: string[]) => {
      return (
        enabled &&
        !!currentRestrictionId &&
        restrictionIds.includes(currentRestrictionId)
      )
    },
    [currentRestrictionId, enabled]
  )

  return {
    highlightEnabled: enabled,
    toggle,
    isHighlighted,
  }
}
