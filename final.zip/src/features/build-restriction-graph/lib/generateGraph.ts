import { type GeoBalancingServiceDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { type TrafficRestriction } from '@/entities/traffic-restriction'

import { type GraphEdge, type GraphNode, type GraphNodeType } from '../model'

export function generateGraph(
  allDataCenters: string[],
  existingRestrictions: TrafficRestriction[],
  dataCenters: string[],
  services: GeoBalancingServiceDto[],
  currentRestrictionId?: string
) {
  const nodes: GraphNode[] = []
  const edges: GraphEdge[] = []
  const appNodeIds: string[] = []
  const dcNodeIds: string[] = []

  const ensureNode = (id: string, type: GraphNodeType, label: string) => {
    if (nodes.find((node) => node.id === id)) return
    if (type === 'dataCenter') {
      dcNodeIds.push(id)
    } else {
      appNodeIds.push(id)
    }

    nodes.push({
      id,
      type,
      position: { x: 0, y: 0 },
      data: {
        label,
      },
    })
  }

  const ensureEdge = (appId: string, dcId: string, restrictionId?: string) => {
    const edgeId = `${appId}-${dcId}`
    const existingEdge = edges.find((edge) => edge.id === edgeId)
    if (existingEdge) {
      const edgeData = existingEdge.data!

      if (restrictionId) {
        existingEdge.type = 'restricted'
        edgeData.restricted = true

        if (!edgeData.restrictionIds.includes(restrictionId)) {
          edgeData.restrictionIds.push(restrictionId)
        }
      }
    } else {
      const restricted = !!restrictionId
      edges.push({
        id: edgeId,
        type: restricted ? 'restricted' : 'active',
        source: appId,
        target: dcId,
        data: {
          restricted,
          restrictionIds: restrictionId ? [restrictionId] : [],
        },
      })
    }
  }

  const isGlobal = services.length === 0

  if (isGlobal) {
    ensureNode('app-all', 'allApps', 'Все приложения')
  } else {
    services.forEach(({ name }) => {
      ensureNode(`app-${name}`, 'application', name)
    })
  }

  const visibleApps = isGlobal
    ? [{ name: 'Все приложения', dataCenters: new Set(allDataCenters) }]
    : services

  allDataCenters.forEach((dc) => {
    const dcId = `dc-${dc}`
    ensureNode(dcId, 'dataCenter', dc)
  })

  if (isGlobal) {
    allDataCenters.forEach((dc) => {
      ensureEdge('app-all', `dc-${dc}`)
    })
  } else {
    services.forEach(({ name, dataCenters = [] }) => {
      const appId = `app-${name}`

      dataCenters.forEach((dc) => {
        ensureEdge(appId, `dc-${dc}`)
      })
    })
  }

  const filteredExisting = existingRestrictions.filter(
    ({ id }) => id !== currentRestrictionId
  )

  const restrictions = [
    ...filteredExisting,
    {
      id: currentRestrictionId,
      dataCenters,
      services: services.map(({ name }) => name),
    } as TrafficRestriction,
  ]

  restrictions.forEach((restriction) => {
    const {
      services: restrictionServices,
      dataCenters: restrictionDataCenters,
      id: restId,
    } = restriction
    const isRestrictionGlobal = restrictionServices.length === 0
    const affectedApps = isRestrictionGlobal
      ? visibleApps
      : services.filter(({ name }) => restrictionServices.includes(name))

    affectedApps.forEach(({ name, dataCenters }) => {
      const appId = isRestrictionGlobal && isGlobal ? 'app-all' : `app-${name}`
      if (!nodes.some((n) => n.id === appId)) return
      restrictionDataCenters.forEach((dc) => {
        const hasRouteToDc = Array.from(dataCenters ?? []).includes(dc)
        if (!hasRouteToDc) return

        const dcId = `dc-${dc}`
        ensureEdge(appId, dcId, restId)
      })
    })
  })

  return { nodes, edges, appNodeIds, dcNodeIds }
}
