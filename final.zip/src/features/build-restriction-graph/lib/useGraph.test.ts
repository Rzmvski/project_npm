import { renderHook } from '@testing-library/react'

import { useGraph } from './useGraph'

const mocks = vi.hoisted(() => ({ generate: vi.fn(), layout: vi.fn(), setNodes: vi.fn() }))
vi.mock('@/features/build-restriction-graph/lib', () => ({
  generateGraph: (...args: any[]) => mocks.generate(...args),
  applyGridLayout: (graph: unknown) => mocks.layout(graph),
}))
vi.mock('@xyflow/react', () => ({
  useNodesState: (nodes: unknown[]) => [nodes, mocks.setNodes, vi.fn()],
}))

it('useGraph фильтрует выбранные сервисы, строит layout и синхронизирует ноды', () => {
  const graph = { nodes: [{ id: 'n1' }], edges: [{ id: 'e1' }] }
  mocks.generate.mockReturnValue(graph)
  mocks.layout.mockReturnValue(graph)
  const services = [{ name: 'payments' }, { name: 'reports' }]
  const { result } = renderHook(() =>
    useGraph({
      allDataCenters: ['dc-1'],
      services: services as never,
      existingRestrictions: [],
      restrictedApplications: ['reports'],
      restrictedDataCenters: ['dc-1'],
      currentRestrictionId: 'restriction-1',
    }),
  )
  expect(mocks.generate).toHaveBeenCalledWith(
    ['dc-1'], [], ['dc-1'], [{ name: 'reports' }], 'restriction-1',
  )
  expect(mocks.layout).toHaveBeenCalledWith(graph)
  expect(mocks.setNodes).toHaveBeenCalledWith(graph.nodes)
  expect(result.current).toMatchObject({ graphEdges: graph.edges, nodes: graph.nodes })
})
