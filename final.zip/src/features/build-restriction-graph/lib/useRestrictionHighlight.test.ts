import { act, renderHook } from '@testing-library/react'

import { useRestrictionHighlight } from './useRestrictionHighlight'

vi.mock('@v-uik/base', async () => {
  const React = await import('react')
  return { useToggle: (initial: boolean) => {
    const [value, setValue] = React.useState(initial)
    return [value, () => setValue((current: boolean) => !current)]
  } }
})

it('useRestrictionHighlight подсвечивает только текущее ограничение и умеет отключаться', () => {
  const { result } = renderHook(() => useRestrictionHighlight('current'))
  expect(result.current.isHighlighted(['other', 'current'])).toBe(true)
  expect(result.current.isHighlighted(['other'])).toBe(false)
  act(() => result.current.toggle())
  expect(result.current.highlightEnabled).toBe(false)
  expect(result.current.isHighlighted(['current'])).toBe(false)
})

it('useRestrictionHighlight не подсвечивает без текущего id', () => {
  const { result } = renderHook(() => useRestrictionHighlight())
  expect(result.current.isHighlighted(['current'])).toBe(false)
})
