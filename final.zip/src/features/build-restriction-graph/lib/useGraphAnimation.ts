import { useStorage } from '@v-uik/base'

type AnimationMode = 'enabled' | 'disabled'

export const useGraphAnimation = () => {
  const [mode, setMode] = useStorage<AnimationMode>(
    'local',
    'graphAnimationMode',
    'enabled'
  )

  const toggle = () => {
    setMode((prev) => (prev === 'enabled' ? 'disabled' : 'enabled'))
  }

  return {
    isAnimated: mode === 'enabled',
    toggle,
  }
}
