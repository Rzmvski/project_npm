import { renderHook } from '@testing-library/react'

import { useGraphFitView } from './useGraphFitView'

const mocks = vi.hoisted(() => ({ fitView: vi.fn(), cancel: vi.fn() }))
vi.mock('@xyflow/react', () => ({ useReactFlow: () => ({ fitView: mocks.fitView }) }))

it('useGraphFitView подгоняет граф на следующем кадре и отменяет кадр при cleanup', () => {
  vi.stubGlobal('requestAnimationFrame', (callback: FrameRequestCallback) => {
    callback(0)
    return 17
  })
  vi.stubGlobal('cancelAnimationFrame', mocks.cancel)
  const { unmount } = renderHook(() => useGraphFitView(['dependency']))
  expect(mocks.fitView).toHaveBeenCalledWith({ padding: { top: 0.3 }, duration: 1000 })
  unmount()
  expect(mocks.cancel).toHaveBeenCalledWith(17)
})
