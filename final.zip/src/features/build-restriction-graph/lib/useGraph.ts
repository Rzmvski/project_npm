import { type GeoBalancingServiceDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { useNodesState } from '@xyflow/react'
import { useEffect, useMemo } from 'react'

import { type TrafficRestriction } from '@/entities/traffic-restriction'
import {
  applyGridLayout,
  generateGraph,
} from '@/features/build-restriction-graph/lib'

interface UseGraphOptions {
  allDataCenters: string[]
  services: GeoBalancingServiceDto[]
  restrictedDataCenters: string[]
  restrictedApplications: string[]
  existingRestrictions: TrafficRestriction[]
  currentRestrictionId?: string
}

export const useGraph = ({
  allDataCenters,
  services,
  existingRestrictions,
  restrictedApplications,
  restrictedDataCenters,
  currentRestrictionId,
}: UseGraphOptions) => {
  const restrictedServices = useMemo(
    () => services.filter(({ name }) => restrictedApplications.includes(name)),
    [restrictedApplications, services]
  )
  const { edges: graphEdges, nodes: graphNodes } = useMemo(() => {
    const graph = generateGraph(
      allDataCenters,
      existingRestrictions,
      restrictedDataCenters,
      restrictedServices,
      currentRestrictionId
    )

    return applyGridLayout(graph)
  }, [
    allDataCenters,
    currentRestrictionId,
    existingRestrictions,
    restrictedDataCenters,
    restrictedServices,
  ])

  const [nodes, setNodes, onNodesChange] = useNodesState(graphNodes)

  useEffect(() => {
    setNodes(graphNodes)
  }, [graphNodes, setNodes])

  return {
    graphEdges,
    nodes,
    onNodesChange,
  }
}
