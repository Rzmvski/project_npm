import { renderHook } from '@testing-library/react'

import { useGraphEdges } from './useGraphEdges'

it('useGraphEdges оформляет свободные, ограниченные и подсвеченные связи', () => {
  const graphEdges = [
    { id: 'free', data: { restricted: false, restrictionIds: [] } },
    { id: 'restricted', data: { restricted: true, restrictionIds: ['other'] } },
    { id: 'highlighted', data: { restricted: true, restrictionIds: ['current'] } },
  ] as never
  const { result } = renderHook(() =>
    useGraphEdges({ graphEdges, isAnimated: true, isHighlighted: (ids) => ids.includes('current') }),
  )
  expect(result.current[0]).toMatchObject({ animated: true, style: { stroke: '#3b82f6', strokeWidth: 2 } })
  expect(result.current[1]).toMatchObject({ animated: false, style: { stroke: '#94a3b8', strokeWidth: 1.5 } })
  expect(result.current[2]).toMatchObject({ data: { isHighlighted: true }, style: { stroke: '#f59e0b', strokeWidth: 2 } })
})
