import { type generateGraph } from '@/features/build-restriction-graph/lib/generateGraph.ts'
import { type Graph } from '@/features/build-restriction-graph/model'

const NODE_WIDTH = 180
const NODE_HEIGHT = 40
const SECTION_GAP = 180
const COL_GAP = 60
const ROW_GAP = 80
const GRID_BREAKPOINT = 4

const calculateRowWidth = (itemWidth: number) =>
  itemWidth * NODE_WIDTH + (itemWidth - 1) * COL_GAP

export function applyGridLayout({
  nodes,
  edges,
  appNodeIds,
  dcNodeIds,
}: ReturnType<typeof generateGraph>): Graph {
  const nodeMap = new Map(nodes.map((node) => [node.id, node]))
  const fullRowWidth = calculateRowWidth(GRID_BREAKPOINT)
  const dcIdSet = new Set(dcNodeIds)

  const dcPositions = new Map<string, number>()

  dcNodeIds.forEach((id, index) => {
    dcPositions.set(id, index)
  })

  const appToDcs = new Map<string, string[]>()

  edges.forEach(({ source, target }) => {
    const sourceIsDc = dcIdSet.has(source)
    const targetIsDc = dcIdSet.has(target)

    if (sourceIsDc && !targetIsDc) {
      const dcs = appToDcs.get(target) ?? []
      dcs.push(source)
      appToDcs.set(target, dcs)
    }

    if (targetIsDc && !sourceIsDc) {
      const dcs = appToDcs.get(source) ?? []
      dcs.push(target)
      appToDcs.set(source, dcs)
    }
  })

  const getBarycenter = (appId: string): number => {
    const dcs = appToDcs.get(appId)
    if (!dcs?.length) {
      return Number.MAX_SAFE_INTEGER
    }

    const sum = dcs.reduce((acc, dcId) => acc + (dcPositions.get(dcId) ?? 0), 0)

    return sum / dcs.length
  }

  const sortedAppNodeIds = [...appNodeIds].sort((a, b) => {
    const barycenterDiff = getBarycenter(a) - getBarycenter(b)

    if (barycenterDiff !== 0) {
      return barycenterDiff
    }

    return a.localeCompare(b)
  })

  const placeGridNodes = (ids: string[], startY: number) => {
    const totalRows = Math.ceil(ids.length / GRID_BREAKPOINT)

    for (let row = 0; row < totalRows; row++) {
      const rowStart = row * GRID_BREAKPOINT
      const rowItems = ids.slice(rowStart, rowStart + GRID_BREAKPOINT)
      const rowWidth = calculateRowWidth(rowItems.length)
      const rowOffsetX = (fullRowWidth - rowWidth) / 2

      rowItems.forEach((id, colIndex) => {
        const node = nodeMap.get(id)
        if (node) {
          node.position = {
            x: rowOffsetX + colIndex * (NODE_WIDTH + COL_GAP),
            y: startY + row * (NODE_HEIGHT + ROW_GAP),
          }
        }
      })
    }
  }

  placeGridNodes(sortedAppNodeIds, 0)

  const appRows = Math.max(
    Math.ceil(sortedAppNodeIds.length / GRID_BREAKPOINT),
    1
  )
  const appHeight = appRows * (NODE_HEIGHT + ROW_GAP)
  const dcStartY = appHeight + SECTION_GAP

  placeGridNodes(dcNodeIds, dcStartY)

  return {
    nodes: Array.from(nodeMap.values()),
    edges,
  }
}
