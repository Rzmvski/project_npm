import { describe, it, expect } from 'vitest'

import type {
  Graph,
  ViewMode,
  GraphNodeType,
  EdgeTypes,
} from '@/features/build-restriction-graph/model/types'

describe('types', () => {
  it('GraphNodeType should accept valid values', () => {
    const dc: GraphNodeType = 'dataCenter'
    const app: GraphNodeType = 'application'
    const all: GraphNodeType = 'allApps'

    expect(dc).toBe('dataCenter')
    expect(app).toBe('application')
    expect(all).toBe('allApps')
  })

  it('EdgeTypes should accept valid values', () => {
    const active: EdgeTypes = 'active'
    const restricted: EdgeTypes = 'restricted'

    expect(active).toBe('active')
    expect(restricted).toBe('restricted')
  })

  it('ViewMode should accept valid values', () => {
    const dimmed: ViewMode = 'dimmed'
    const restricted: ViewMode = 'restricted-only'
    const all: ViewMode = 'all'

    expect(dimmed).toBe('dimmed')
    expect(restricted).toBe('restricted-only')
    expect(all).toBe('all')
  })

  it('should create a Graph', () => {
    const graph: Graph = {
      nodes: [
        { id: '1', type: 'dataCenter', position: { x: 0, y: 0 }, data: { label: 'DC1' } },
        { id: '2', type: 'application', position: { x: 100, y: 0 }, data: { label: 'App1' } },
      ],
      edges: [
        {
          id: 'e1',
          source: '1',
          target: '2',
          type: 'active',
          data: { restricted: false, restrictionIds: [] },
        },
      ],
    }

    expect(graph.nodes).toHaveLength(2)
    expect(graph.edges).toHaveLength(1)
    expect(graph.edges[0].data?.restricted).toBe(false)
  })
})
