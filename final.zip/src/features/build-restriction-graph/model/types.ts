import { type Edge, type Node } from '@xyflow/react'

type GraphNodeData = {
  label: string
}

type GraphEdgeData = {
  restricted: boolean
  restrictionIds: string[]
  isHighlighted?: boolean
  isAnimated?: boolean
}

export type EdgeTypes = 'active' | 'restricted'
export type GraphNodeType = 'dataCenter' | 'application' | 'allApps'

export type GraphNode = Node<GraphNodeData, GraphNodeType>
export type GraphEdge = Edge<GraphEdgeData, EdgeTypes>

export type Graph = {
  nodes: GraphNode[]
  edges: GraphEdge[]
}

export type ViewMode = 'dimmed' | 'restricted-only' | 'all'
