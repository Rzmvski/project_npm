import { fetchStartReplication, fetchUndoReplication } from './fetchChangeReplication'

const service = vi.hoisted(() => ({ startReplication: vi.fn(), undoReplication: vi.fn() }))
vi.mock('@/shared/api', () => ({ clusterManagementService: service }))

it('управляет репликацией выбранной шарды', () => {
  fetchStartReplication(42)
  fetchUndoReplication(42)
  expect(service.startReplication).toHaveBeenCalledWith(42)
  expect(service.undoReplication).toHaveBeenCalledWith(42)
})
