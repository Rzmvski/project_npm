import { clusterManagementService } from '@/shared/api'

export const fetchStartReplication = (shardId: number) => {
  return clusterManagementService.startReplication(shardId)
}

export const fetchUndoReplication = (shardId: number) => {
  return clusterManagementService.undoReplication(shardId)
}
