import { useMutation, useQueryClient } from '@tanstack/react-query'

import {
  fetchStartReplication,
  fetchUndoReplication,
} from '@/features/run-shard-replication/api'

export const useStartShardReplicationMutation = (shardId: number) => {
  const client = useQueryClient()
  return useMutation({
    mutationFn: () => fetchStartReplication(shardId),
    onSuccess: () => {
      return client.invalidateQueries({
        queryKey: ['shard-replication', shardId],
      })
    },
  })
}

export const useUndoShardReplicationMutation = (shardId: number) => {
  const client = useQueryClient()
  return useMutation({
    mutationFn: () => fetchUndoReplication(shardId),
    onSuccess: () => {
      return client.invalidateQueries({
        queryKey: ['shard-replication', shardId],
      })
    },
  })
}
