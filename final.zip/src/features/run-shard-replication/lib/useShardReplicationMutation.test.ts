import { renderHook } from '@testing-library/react'

import { useStartShardReplicationMutation, useUndoShardReplicationMutation } from './useShardReplicationMutation'

const mocks = vi.hoisted(() => ({ configs: [] as any[], start: vi.fn(), undo: vi.fn(), invalidate: vi.fn() }))
vi.mock('@tanstack/react-query', () => ({
  useQueryClient: () => ({ invalidateQueries: mocks.invalidate }),
  useMutation: (config: any) => (mocks.configs.push(config), { mutate: config.mutationFn }),
}))
vi.mock('@/features/run-shard-replication/api', () => ({
  fetchStartReplication: (...args: any[]) => mocks.start(...args),
  fetchUndoReplication: (...args: any[]) => mocks.undo(...args),
}))

it('мутации репликации запускают и откатывают процесс с обновлением статуса', () => {
  renderHook(() => useStartShardReplicationMutation(42)).result.current.mutate()
  renderHook(() => useUndoShardReplicationMutation(42)).result.current.mutate()
  expect(mocks.start).toHaveBeenCalledWith(42)
  expect(mocks.undo).toHaveBeenCalledWith(42)
  mocks.configs.forEach((config) => config.onSuccess())
  expect(mocks.invalidate).toHaveBeenNthCalledWith(1, { queryKey: ['shard-replication', 42] })
})
