import { type PoolStateDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { connectionPoolManagementService } from '@/shared/api'

/**
 * Запрос на изменение пула коннектов
 * Method: PUT
 * URL: /invoke/support-admin/cluster-management-service/nodes/{nodeKey}/pools
 */
export const fetchChangePoolState = (
  nodeKey: string,
  poolState: PoolStateDto
): Promise<void> => {
  return connectionPoolManagementService.changePoolState(nodeKey, poolState)
}
