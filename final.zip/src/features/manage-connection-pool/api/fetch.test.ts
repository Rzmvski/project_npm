import { PoolStateDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { fetchChangePoolState } from './fetch'

const changePoolState = vi.hoisted(() => vi.fn())
vi.mock('@/shared/api', () => ({ connectionPoolManagementService: { changePoolState } }))

it('fetchChangePoolState обновляет пул выбранного узла', () => {
  fetchChangePoolState('node-1', PoolStateDto.Active)
  expect(changePoolState).toHaveBeenCalledWith('node-1', PoolStateDto.Active)
})
