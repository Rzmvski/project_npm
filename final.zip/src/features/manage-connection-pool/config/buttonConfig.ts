import { PoolStateDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { Power, PowerOff } from 'lucide-react'
import { type ComponentType } from 'react'

type ButtonType = 'regular' | 'warning'

type PoolConfig = {
  text: string
  type: ButtonType
  targetState: PoolStateDto
  Icon: ComponentType
  disabled?: boolean
}

export const buttonConfig: Record<PoolStateDto, PoolConfig> = {
  [PoolStateDto.Active]: {
    type: 'regular',
    text: 'Деактивировать пул коннектов',
    targetState: PoolStateDto.Suspended,
    Icon: PowerOff,
  },
  [PoolStateDto.Suspended]: {
    type: 'warning',
    text: 'Активировать пул коннектов',
    targetState: PoolStateDto.Active,
    Icon: Power,
  },
  [PoolStateDto.Unknown]: {
    text: '',
    type: 'regular',
    targetState: PoolStateDto.Unknown,
    Icon: Power,
    disabled: true,
  },
}
