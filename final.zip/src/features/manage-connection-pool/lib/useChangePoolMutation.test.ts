import { renderHook } from '@testing-library/react'

import { useChangePoolMutation } from './useChangePoolMutation'

const mocks = vi.hoisted(() => ({ config: null as any, fetch: vi.fn(), success: vi.fn(), invalidate: vi.fn() }))
vi.mock('@tanstack/react-query', () => ({
  useQueryClient: () => ({ invalidateQueries: mocks.invalidate }),
  useMutation: (config: any) => ((mocks.config = config), { mutate: config.mutationFn }),
}))
vi.mock('@v-uik/base', () => ({ notification: { success: mocks.success } }))
vi.mock('@/features/manage-connection-pool/api', () => ({ fetchChangePoolState: (...args: any[]) => mocks.fetch(...args) }))
vi.mock('@/entities/node', () => ({ nodesQueryKey: ['nodes'] }))
vi.mock('@/entities/connection-pool', () => ({ poolsQueryKey: ['pools'] }))

it('useChangePoolMutation меняет пул и обновляет узлы и пулы', () => {
  const { result } = renderHook(() => useChangePoolMutation())
  const values = { nodeKey: 'node-a', targetState: 'ACTIVE' }
  result.current.mutate(values as never)
  expect(mocks.fetch).toHaveBeenCalledWith('node-a', 'ACTIVE')
  mocks.config.onSuccess(null, values)
  expect(mocks.success).toHaveBeenCalledWith(expect.stringContaining('node-a'))
  expect(mocks.invalidate).toHaveBeenCalledWith({ queryKey: ['nodes'] })
  expect(mocks.invalidate).toHaveBeenCalledWith({ queryKey: ['pools'] })
})
