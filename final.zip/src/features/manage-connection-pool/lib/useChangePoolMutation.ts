import { type PoolStateDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { notification } from '@v-uik/base'

import { poolsQueryKey } from '@/entities/connection-pool'
import { nodesQueryKey } from '@/entities/node'
import { fetchChangePoolState } from '@/features/manage-connection-pool/api'

type UseChangePoolMutationParams = {
  nodeKey: string
  targetState: PoolStateDto
}

export const useChangePoolMutation = () => {
  const client = useQueryClient()
  return useMutation({
    mutationFn: ({ nodeKey, targetState }: UseChangePoolMutationParams) =>
      fetchChangePoolState(nodeKey, targetState),
    onSuccess: (_data, { nodeKey }) => {
      notification.success(
        `Изменение статуса пула коннектов на ноде ${nodeKey} выполнено успешно`
      )
      return Promise.all([
        client.invalidateQueries({ queryKey: nodesQueryKey }),
        client.invalidateQueries({ queryKey: poolsQueryKey }),
      ])
    },
  })
}
