import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'

import {
  transferClientSchema,
  type TransferClientInputValues,
} from '@/entities/transfer-client'

const defaultValues: TransferClientInputValues = {
  attempt: false,
  threadsAmount: 10,
  taskLimit: '',
  shardIds: [],
}

export const useTransferClientForm = () => {
  return useForm({
    defaultValues,
    resolver: zodResolver(transferClientSchema),
  })
}
