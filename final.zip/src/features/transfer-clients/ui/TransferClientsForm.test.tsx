import { screen, waitFor } from '@testing-library/react'

import { TransferClientsFormTestModel } from './TransferClientsForm.test-model'

const mocks = vi.hoisted(() => ({
  setValue: vi.fn(),
  fetch: vi.fn().mockResolvedValue([{ shard: { id: 7 } }]),
  isSubmitting: false,
  attempt: true,
}))

vi.mock('react-hook-form', () => ({
  useFormContext: () => ({
    control: {},
    setValue: mocks.setValue,
    formState: { isSubmitting: mocks.isSubmitting },
    getFieldState: () => ({ invalid: true }),
    watch: () => mocks.attempt,
  }),
  Controller: ({ name, render }: Record<string, any>) =>
    render({
      field: { name, value: name === 'attempt' ? mocks.attempt : '4', onChange: vi.fn() },
      fieldState: { invalid: false },
    }),
}))
vi.mock('@tanstack/react-query', () => ({
  useQuery: (config: Record<string, any>) => {
    config.queryFn()
    return { data: [{ shard: { id: 7 } }], isLoading: false }
  },
}))
vi.mock('@/entities/transfer-task', () => ({
  fetchTransferTasks: () => mocks.fetch(),
}))
vi.mock('@/shared/lib', () => ({
  useTaskColumns: (attempt: boolean) => [{ header: `Докат: ${attempt}` }],
  useRowSelection: ({ getRowId }: Record<string, any>) => {
    expect(getRowId({ shard: { id: 7 } })).toBe('7')
    return { plugin: { name: 'selection' }, selectedIds: ['7'] }
  },
}))
vi.mock('@/shared/ui/Table', () => ({
  Table: ({ data, columns, disabled, invalid, plugins }: Record<string, any>) => (
    <div>
      <span>{`${data.length} задача; ${columns[0].header}`}</span>
      <span>{disabled ? 'Таблица заблокирована' : 'Таблица доступна'}</span>
      <span>{invalid ? 'Выбор обязателен' : 'Выбор корректен'}</span>
      <span>{plugins[0].name}</span>
    </div>
  ),
}))
vi.mock('@/shared/ui/Button', () => ({
  Button: ({ type = 'button', ...props }: React.ButtonHTMLAttributes<HTMLButtonElement>) => (
    <button type={type} {...props} />
  ),
}))
vi.mock('@v-uik/base', () => ({
  Underlay: ({ children }: React.PropsWithChildren) => <section>{children}</section>,
  Input: ({ label, disabled, value }: Record<string, any>) => (
    <input aria-label={label} disabled={disabled} value={value} readOnly />
  ),
  Switch: () => <input type='checkbox' readOnly />,
  LabelControl: ({ label, checked, disabled }: Record<string, any>) => (
    <span>{`${label}: ${checked}; ${disabled ? 'заблокирован' : 'доступен'}`}</span>
  ),
}))

describe('TransferClientsForm', () => {
  beforeEach(() => {
    mocks.isSubmitting = false
    mocks.attempt = true
  })

  it('показывает задания, режим доката и синхронизирует выбранные шарды', async () => {
    TransferClientsFormTestModel.render()
    expect(screen.getByText('1 задача; Докат: true')).toBeVisible()
    expect(screen.getByText('Докат: true; доступен')).toBeVisible()
    await waitFor(() => expect(mocks.setValue).toHaveBeenCalledWith('shardIds', ['7']))
    expect(mocks.fetch).toHaveBeenCalled()
  })

  it('отправляет доступную форму', async () => {
    const model = TransferClientsFormTestModel.render()
    await model.click('Выполнить')
    expect(model.onSubmit).toHaveBeenCalledOnce()
  })

  it('при активном процессе блокирует редактирование и разрешает остановку', async () => {
    const model = TransferClientsFormTestModel.render(true)
    expect(screen.getByText('Таблица заблокирована')).toBeVisible()
    expect(screen.getByRole('button', { name: 'Выполнить' })).toBeDisabled()
    await model.click('Остановить')
    expect(model.onCancel).toHaveBeenCalledOnce()
  })

  it('не позволяет останавливать отсутствующий процесс', () => {
    TransferClientsFormTestModel.render(false)
    expect(screen.getByRole('button', { name: 'Остановить' })).toBeDisabled()
  })
})
