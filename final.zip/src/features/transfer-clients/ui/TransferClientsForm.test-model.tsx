import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'

import { TransferClientsForm } from './TransferClientsForm'

export class TransferClientsFormTestModel {
  readonly onSubmit = vi.fn(function (...args: unknown[]) {
    const event = args[0] as Event | undefined
    event?.preventDefault()
  })
  readonly onCancel = vi.fn()

  private constructor(hasActiveProcesses: boolean) {
    render(
      <TransferClientsForm
        onSubmit={this.onSubmit}
        onCancel={this.onCancel}
        hasActiveProcesses={hasActiveProcesses}
      />,
    )
  }

  static render(hasActiveProcesses = false) {
    return new TransferClientsFormTestModel(hasActiveProcesses)
  }

  async click(name: string) {
    await userEvent.click(screen.getByRole('button', { name }))
  }
}
