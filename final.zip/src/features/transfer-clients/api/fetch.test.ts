import { fetchTransfer } from './fetch'

const transfer = vi.hoisted(() => vi.fn())
vi.mock('@/shared/api', () => ({ clientTransferService: { transfer } }))

it('fetchTransfer преобразует attempt в repeat', () => {
  fetchTransfer({ attempt: false, clientIds: [1, 2] } as never)
  expect(transfer).toHaveBeenCalledWith({ clientIds: [1, 2], repeat: false })
})
