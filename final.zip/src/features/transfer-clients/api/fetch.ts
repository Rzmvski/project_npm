import { type ProcessDtoDto } from '@sber-pprb-tkp/tcpf-support-admin-api'

import { type TransferClientOutputValues } from '@/entities/transfer-client'
import { clientTransferService } from '@/shared/api'

export const fetchTransfer = ({
  attempt,
  ...transferRequest
}: TransferClientOutputValues): Promise<ProcessDtoDto> => {
  return clientTransferService.transfer({
    ...transferRequest,
    repeat: attempt,
  })
}
