import { ComboBox } from '@v-uik/base'
import React, { type FC } from 'react'

import { Contours, type Option, contourLocalStorage } from '@/shared/model'

import styles from './ContourSelector.module.scss'

const contourDictionary: Record<Contours, string> = {
  [Contours.TKP]: 'ТКП',
  [Contours.HUB]: 'ХАБ',
  [Contours.DATA_CACHE]: 'Data cache',
}

export const ContourSelector: FC = () => {
  const { get: getCurrentContour, set: setContour } = contourLocalStorage
  const options: Option<Contours>[] = Object.entries(Contours).map(
    ([_, value]) => ({
      value,
      label: contourDictionary[value],
    })
  )
  const value = options.find(({ value }) => value == getCurrentContour())

  const handleChangeContour = ({ value }: Option<Contours>) => {
    setContour(value)
    location.reload()
  }

  return (
    <div className={styles.container}>
      <ComboBox
        options={options}
        value={value}
        onChange={(_value, _event, fullValue) =>
          fullValue && handleChangeContour(fullValue)
        }
      />
    </div>
  )
}
