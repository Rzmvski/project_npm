import { fetchResolveScriptApplication } from './fetchManageRequest'

const resolveScriptApplication = vi.hoisted(() => vi.fn())
vi.mock('@/shared/api', () => ({ scriptService: { resolveScriptApplication } }))

it('fetchResolveScriptApplication отправляет решение по reason id', () => {
  const request = { status: 'APPROVED' }
  fetchResolveScriptApplication('REQ1', request as never)
  expect(resolveScriptApplication).toHaveBeenCalledWith('REQ1', request)
})
