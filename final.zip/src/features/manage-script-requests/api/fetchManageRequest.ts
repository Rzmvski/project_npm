import { type ResolveScriptApplicationRequestDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { scriptService } from '@/shared/api'

export const fetchResolveScriptApplication = (
  reasonId: string,
  request: ResolveScriptApplicationRequestDto,
) => {
  return scriptService.resolveScriptApplication(reasonId, request)
}
