import { ApplicationStatusDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { describe, it, expect } from 'vitest'

import { buttonConfigs } from '@/features/manage-script-requests/config/buttonConfigs'

describe('buttonConfigs', () => {
  it('should have run button with condition for Approved status', () => {
    const runBtn = buttonConfigs.find((b) => b.tooltip === 'Запустить выполнение скрипта')
    expect(runBtn).toBeDefined()
    expect(runBtn?.condition(ApplicationStatusDto.Approved)).toBe(true)
    expect(runBtn?.condition(ApplicationStatusDto.Pending)).toBe(false)
  })

  it('should have approve button with condition for Pending', () => {
    const approveBtn = buttonConfigs.find((b) => b.tooltip === 'Одобрить заявку')
    expect(approveBtn).toBeDefined()
    expect(approveBtn?.condition(ApplicationStatusDto.Pending)).toBe(true)
    expect(approveBtn?.condition(ApplicationStatusDto.Approved)).toBe(false)
    expect(approveBtn?.targetStatus).toBe(ApplicationStatusDto.Approved)
  })

  it('should have decline button with condition for Pending', () => {
    const declineBtn = buttonConfigs.find((b) => b.tooltip === 'Отклонить заявку')
    expect(declineBtn).toBeDefined()
    expect(declineBtn?.condition(ApplicationStatusDto.Pending)).toBe(true)
    expect(declineBtn?.targetStatus).toBe(ApplicationStatusDto.Decline)
  })

  it('should have stop button with condition for Works', () => {
    const stopBtn = buttonConfigs.find((b) => b.tooltip === 'Остановить')
    expect(stopBtn).toBeDefined()
    expect(stopBtn?.condition(ApplicationStatusDto.Works)).toBe(true)
    expect(stopBtn?.targetStatus).toBe(ApplicationStatusDto.Canceled)
  })

  it('should have view script button with always-true condition', () => {
    const viewScriptBtn = buttonConfigs.find((b) => b.tooltip === 'Посмотреть скрипт')
    expect(viewScriptBtn).toBeDefined()
    expect(viewScriptBtn?.condition(ApplicationStatusDto.Pending)).toBe(true)
    expect(viewScriptBtn?.condition(ApplicationStatusDto.Works)).toBe(true)
  })

  it('should have log viewer button with appropriate condition', () => {
    const logBtn = buttonConfigs.find((b) => b.tooltip === 'Посмотреть логи')
    expect(logBtn).toBeDefined()
    expect(logBtn?.condition(ApplicationStatusDto.Pending)).toBe(false)
    expect(logBtn?.condition(ApplicationStatusDto.Works)).toBe(true)
  })
})
