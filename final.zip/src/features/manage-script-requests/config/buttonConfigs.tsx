import {
  ApplicationStatusDto,
  type ScriptApplicationDto,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { CheckIcon, FileSearchIcon, LogsIcon, PlayIcon, SquareIcon, XIcon } from 'lucide-react'
import React, { type FC, type ReactNode } from 'react'

import { LogViewer, ScriptViewer } from '@/features/manage-script-requests/ui'
import { sessionUserLogin } from '@/shared/lib'

interface ButtonConfig {
  tooltip: string
  icon: ReactNode
  title: string
  condition: (status: ApplicationStatusDto) => boolean
  content: FC<{ selected: ScriptApplicationDto }>
  targetStatus?: ApplicationStatusDto
  disabled?: (application: ScriptApplicationDto) => boolean
}

const isCreatedByResolver = ({ createdBy }: ScriptApplicationDto) => {
  const resolver = sessionUserLogin.get()
  return resolver === createdBy
}

export const buttonConfigs: ButtonConfig[] = [
  {
    tooltip: 'Запустить выполнение скрипта',
    icon: <PlayIcon />,
    title: 'Подтвердите запуск скрипта',
    targetStatus: ApplicationStatusDto.Works,
    condition: (status) => ApplicationStatusDto.Approved == status,
    content: ScriptViewer,
  },
  {
    tooltip: 'Одобрить заявку',
    icon: <CheckIcon />,
    title: 'Подтвердите одобрение заявки',
    targetStatus: ApplicationStatusDto.Approved,
    condition: (status) => ApplicationStatusDto.Pending == status,
    disabled: (application) => isCreatedByResolver(application),
    content: ScriptViewer,
  },
  {
    tooltip: 'Отклонить заявку',
    icon: <XIcon />,
    title: 'Подтвердите отклонение заявки',
    targetStatus: ApplicationStatusDto.Decline,
    condition: (status) => ApplicationStatusDto.Pending == status,
    disabled: (application) => isCreatedByResolver(application),
    content: ScriptViewer,
  },
  {
    tooltip: 'Остановить',
    icon: <SquareIcon />,
    title: 'Подтвердите остановку выполнения скрипта',
    targetStatus: ApplicationStatusDto.Canceled,
    condition: (status) => ApplicationStatusDto.Works == status,
    content: ScriptViewer,
  },
  {
    tooltip: 'Посмотреть логи',
    icon: <LogsIcon />,
    title: 'Журнал логов',
    condition: (status) =>
      ![
        ApplicationStatusDto.Pending,
        ApplicationStatusDto.Approved,
        ApplicationStatusDto.Decline,
      ].includes(status),
    content: LogViewer,
  },
  {
    tooltip: 'Посмотреть скрипт',
    icon: <FileSearchIcon />,
    title: 'Просмотр скрипта',
    condition: () => true,
    content: ScriptViewer,
  },
  // {
  //   tooltip: 'Архивировать',
  //   icon: <ArchiveIcon/>,
  //   title: 'Подтвердите архивирование заявки',
  //   targetStatus: ApplicationStatusDto.Archived,
  //   condition: (status) => ![ ApplicationStatusDto.Works, ApplicationStatusDto.Archived ].includes(status),
  //   content: ScriptViewer,
  // },
]
