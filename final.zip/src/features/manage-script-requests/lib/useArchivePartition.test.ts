import { ApplicationStatusDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { act, renderHook } from '@testing-library/react'

import { useArchivePartition } from './useArchivePartition'

it('useArchivePartition переключает активные и архивные заявки', () => {
  const items = [
    { reasonId: 'active', status: ApplicationStatusDto.Created },
    { reasonId: 'archived', status: ApplicationStatusDto.Archived },
  ] as never
  const { result } = renderHook(() => useArchivePartition(items))
  expect(result.current.partitionedApplications).toEqual([expect.objectContaining({ reasonId: 'active' })])
  act(() => result.current.toggleShowArchived())
  expect(result.current.showArchived).toBe(true)
  expect(result.current.partitionedApplications).toEqual([expect.objectContaining({ reasonId: 'archived' })])
})
