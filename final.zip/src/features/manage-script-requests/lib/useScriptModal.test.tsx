import { act, render, renderHook, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'

import { useScriptModal } from './useScriptModal'

const mocks = vi.hoisted(() => ({ show: vi.fn(), close: vi.fn() }))
vi.mock('@v-uik/base', () => ({
  createUseStyles: () => () => ({ modal: 'modal' }),
  generateId: () => 'script-modal',
  modal: { show: mocks.show, close: mocks.close },
}))
vi.mock('@/shared/ui/Modal', () => ({
  Modal: ({ title, children, onClose, onClickAgreeBtn }: Record<string, any>) => (
    <div><h2>{title}</h2>{children}<button onClick={onClickAgreeBtn}>Сохранить</button><button onClick={onClose}>Закрыть</button></div>
  ),
}))

it('useScriptModal открывает содержимое, отправляет и закрывает окно', async () => {
  const onSubmit = vi.fn()
  const Content = ({ selected }: Record<string, any>) => <span>{selected.reasonId}</span>
  const { result } = renderHook(() =>
    useScriptModal({ title: 'Заявка', selectedApplication: { reasonId: 'REQ-1' } as never, ContentComponent: Content, onSubmit }),
  )
  act(() => result.current.openModal())
  render(mocks.show.mock.calls[0][1].content)
  expect(screen.getByText('REQ-1')).toBeVisible()
  await userEvent.click(screen.getByRole('button', { name: 'Сохранить' }))
  await userEvent.click(screen.getByRole('button', { name: 'Закрыть' }))
  expect(onSubmit).toHaveBeenCalled()
  expect(mocks.close).toHaveBeenCalledWith('script-modal')
})
