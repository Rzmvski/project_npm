import {
  type ApplicationStatusDto,
  type ScriptApplicationDto,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { type ColumnDef } from '@tanstack/react-table'
import React, { useMemo } from 'react'

import { RequestStatusTag } from '@/entities/request-status'
import { formatDate } from '@/shared/lib'

const NOTHING = '\u2013'

export const useScriptRequestsColumns = (): ColumnDef<ScriptApplicationDto>[] => {
  return useMemo(
    () => [
      {
        header: 'Номер заявки',
        accessorKey: 'reasonId',
        size: 150,
      },
      {
        header: 'jira',
        accessorKey: 'jiraId',
        minSize: 200,
      },
      {
        header: 'Создано',
        accessorKey: 'created',
        cell: ({ getValue }) => {
          const created = getValue<Date>()
          return formatDate(created, 'dd.MM.yyyy') ?? NOTHING
        },
      },
      {
        header: 'Инициатор',
        accessorKey: 'createdBy',
      },
      {
        header: 'Статус',
        accessorKey: 'status',
        cell: ({ getValue }) => {
          const status = getValue<ApplicationStatusDto>()
          return <RequestStatusTag status={status} />
        },
        size: 120,
      },
      {
        header: 'Согласующее лицо',
        accessorKey: 'resolvedBy',
        cell: ({ getValue }) => {
          const resolver = getValue<string>()
          return resolver ?? NOTHING
        },
      },
      {
        header: 'Исполнитель',
        accessorKey: 'executedBy',
        cell: ({ getValue }) => {
          const executor = getValue<string>()
          return executor ?? NOTHING
        },
      },
    ],
    [],
  )
}
