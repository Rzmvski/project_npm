import {
  type ApplicationDto,
  ApplicationStatusDto,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { useToggle } from '@v-uik/base'
import { useMemo } from 'react'

type ArchivePartitionResult<T> = {
  archived: T[]
  active: T[]
}

export const useArchivePartition = <T extends ApplicationDto>(items: T[]) => {
  const [showArchived, toggleShowArchived] = useToggle(false)

  const { archived, active } = useMemo(() => {
    return items.reduce<ArchivePartitionResult<T>>(
      (acc, item) => {
        const { active, archived } = acc
        const { status } = item
        if (status == ApplicationStatusDto.Archived) {
          archived.push(item)
        } else {
          active.push(item)
        }

        return acc
      },
      { active: [], archived: [] }
    )
  }, [items])

  return {
    partitionedApplications: showArchived ? archived : active,
    toggleShowArchived,
    showArchived,
  }
}
