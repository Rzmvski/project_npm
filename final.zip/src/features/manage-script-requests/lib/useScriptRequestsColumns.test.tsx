import { ApplicationStatusDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { renderHook } from '@testing-library/react'

import { useScriptRequestsColumns } from './useScriptRequestsColumns'

import type { ColumnDef } from '@tanstack/react-table'

type Row = Record<string, unknown>
type TestColumn = ColumnDef<Row> & { cell?: (context: never) => unknown }

const column = (columns: TestColumn[], headerOrId: string) =>
  columns.find((candidate) => candidate.header === headerOrId || candidate.id === headerOrId)!

const cell = (candidate: TestColumn, original: Row = {}, value?: unknown) =>
  candidate.cell?.({ row: { original }, getValue: () => value } as never)

describe('useScriptRequestsColumns', () => {
  const columns = () =>
    renderHook(() => useScriptRequestsColumns()).result.current as TestColumn[]

  it('форматирует дату создания', () => {
    expect(cell(column(columns(), 'Создано'), {}, new Date(2026, 7, 13))).toBe('13.08.2026')
  })

  it('показывает тире для отсутствующего согласующего и исполнителя', () => {
    expect(cell(column(columns(), 'Согласующее лицо'), {}, undefined)).toBe('–')
    expect(cell(column(columns(), 'Исполнитель'), {}, null)).toBe('–')
    expect(cell(column(columns(), 'Исполнитель'), {}, 'operator')).toBe('operator')
  })

  it('передаёт status в интерактивную ячейку', () => {
    const status = cell(
      column(columns(), 'Статус'),
      {},
      ApplicationStatusDto.Pending,
    ) as React.ReactElement<Record<string, unknown>>
    expect(status.props).toMatchObject({ status: ApplicationStatusDto.Pending })
    expect(columns().some(({ id }) => id === 'action' || id === 'managed')).toBe(false)
  })
})
