import { type ApplicationStatusDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { useCallback, useMemo } from 'react'

import { useScriptRequests } from '@/entities/script-request'
import { useChangeRequestStatus } from '@/features/manage-script-requests/lib/useChangeRequestStatus'

interface UseManageSelectedRequestsOptions {
  selectedRequestIds: string[]
  removeRowSelection: (id: string) => void
}

export const useManageSelectedRequests = ({
  selectedRequestIds,
  removeRowSelection,
}: UseManageSelectedRequestsOptions) => {
  const { mutate, ...rest } = useChangeRequestStatus()
  const { requests } = useScriptRequests()
  const requestEntities = useMemo(
    () => Object.fromEntries(requests.map((request) => [request.reasonId, request])),
    [requests],
  )

  const selectedEntities = useMemo(() => {
    return selectedRequestIds
      .map((id) => requestEntities[id])
      .filter((request) => request !== undefined)
  }, [selectedRequestIds, requestEntities])

  const batchMutate = useCallback(
    (targetStatus: ApplicationStatusDto) => {
      selectedEntities.forEach((application) => {
        mutate({ application, targetStatus })
        const { reasonId } = application
        removeRowSelection(reasonId)
      })
    },
    [selectedEntities, mutate],
  )

  return {
    ...rest,
    mutate: batchMutate,
  }
}
