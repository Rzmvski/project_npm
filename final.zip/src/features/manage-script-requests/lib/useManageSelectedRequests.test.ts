import { ApplicationStatusDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { act, renderHook } from '@testing-library/react'

import { useManageSelectedRequests } from './useManageSelectedRequests'

const mocks = vi.hoisted(() => ({ mutate: vi.fn() }))
vi.mock('./useChangeRequestStatus', () => ({
  useChangeRequestStatus: () => ({ mutate: mocks.mutate, isPending: false }),
}))
vi.mock('@/entities/script-request', () => ({
  useScriptRequests: () => ({
    requests: [
      { reasonId: 'REQ-1', script: 'one' },
      { reasonId: 'REQ-2', script: 'two' },
    ],
  }),
}))

it('useManageSelectedRequests меняет только существующие выбранные заявки и снимает выбор', () => {
  const removeRowSelection = vi.fn()
  const { result } = renderHook(() =>
    useManageSelectedRequests({
      selectedRequestIds: ['REQ-2', 'missing', 'REQ-1'],
      removeRowSelection,
    }),
  )

  act(() => result.current.mutate(ApplicationStatusDto.Approved))

  expect(mocks.mutate).toHaveBeenCalledTimes(2)
  expect(mocks.mutate).toHaveBeenNthCalledWith(1, {
    application: expect.objectContaining({ reasonId: 'REQ-2' }),
    targetStatus: ApplicationStatusDto.Approved,
  })
  expect(removeRowSelection.mock.calls.flat()).toEqual(['REQ-2', 'REQ-1'])
  expect(result.current.isPending).toBe(false)
})
