import { type ScriptApplicationDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { createUseStyles, generateId, modal, type ShowOptions } from '@v-uik/base'
import React, { type FC } from 'react'

import { Modal } from '@/shared/ui/Modal'

const useStyles = createUseStyles(() => ({
  modal: {
    minHeight: '80vh',
  },
}))

export interface UseScriptModalParams {
  title: string
  selectedApplication: ScriptApplicationDto
  ContentComponent: FC<{ selected: ScriptApplicationDto }>
  onSubmit?: () => void
}

export const useScriptModal = ({
  title,
  selectedApplication,
  ContentComponent,
  onSubmit,
}: UseScriptModalParams) => {
  const id = generateId()
  const classes = useStyles()

  const openModal = () => {
    modal.show(id, {
      content: (
        <React.Fragment>
          <Modal
            title={title}
            className={classes.modal}
            isOpen
            onClose={closeModal}
            onClickCancelBtn={closeModal}
            onClickAgreeBtn={onSubmit}
          >
            <ContentComponent selected={selectedApplication} />
          </Modal>
        </React.Fragment>
      ),
    } as ShowOptions)
  }

  const closeModal = () => {
    modal.close(id)
  }

  return {
    openModal,
    closeModal,
  }
}
