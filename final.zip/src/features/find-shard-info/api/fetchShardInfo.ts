import {
  type RoutingTypeDto,
  type ShardInfoDto,
  ShardInfoServiceApi,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { platformRequestConfiguration } from '@/shared/config'

const client = new ShardInfoServiceApi(platformRequestConfiguration)

export const fetchShardInfo = (type: RoutingTypeDto, key: string): Promise<ShardInfoDto> =>
  client.getShardInfo(type, key)
