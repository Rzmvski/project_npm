import { zodResolver } from '@hookform/resolvers/zod'
import { type RoutingTypeDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { useMutation } from '@tanstack/react-query'
import { CircularProgress, Input } from '@v-uik/base'
import classNames from 'classnames'
import { AlertTriangleIcon, EraserIcon, Layers3, SearchIcon } from 'lucide-react'
import React, { type FC } from 'react'
import { Controller, useForm, useWatch } from 'react-hook-form'

import { Button } from '@/shared/ui/Button'

import { fetchShardInfo } from '../api/fetchShardInfo'
import { shardSearchFields } from '../model/config'
import { shardSearchSchema, type ShardSearchValues } from '../model/schema'

import styles from './FindShardInfo.module.scss'

interface FindShardInfoProps {
  className?: string
  resultClassName?: string
}

const defaultValues: ShardSearchValues = {
  contractNumber: '',
  contractId: '',
  clientId: '',
  accountNumber: '',
  dpan: '',
}

export const FindShardInfo: FC<FindShardInfoProps> = ({ className, resultClassName }) => {
  const form = useForm<ShardSearchValues>({
    defaultValues,
    resolver: zodResolver(shardSearchSchema),
    mode: 'onChange',
  })
  const values = useWatch({ control: form.control })
  const activeField = shardSearchFields.find(({ name }) => values[name])
  const query = useMutation({
    mutationFn: ({ type, key }: { type: RoutingTypeDto; key: string }) =>
      fetchShardInfo(type, key),
  })

  const clear = () => {
    form.reset(defaultValues)
    query.reset()
  }

  const submit = form.handleSubmit((formValues) => {
    const field = shardSearchFields.find(({ name }) => formValues[name])
    if (!field) return
    query.mutate({ type: field.type, key: formValues[field.name] })
  })

  return (
    <>
      <form className={className} onSubmit={submit}>
        {shardSearchFields.map(({ name, type, title }) => (
          <Controller
            key={type}
            name={name}
            control={form.control}
            render={({ field, fieldState }) => (
              <Input
                label={title}
                placeholder={'Введите'}
                value={field.value}
                onChange={(value) => {
                  field.onChange(value.toUpperCase().trim())
                  if (query.isError || query.isSuccess) query.reset()
                }}
                onBlur={field.onBlur}
                disabled={Boolean(activeField && activeField.name !== name)}
                error={fieldState.invalid || (query.isError && activeField?.name === name)}
                showErrorIcon={false}
              />
            )}
          />
        ))}
        <div className={styles.actions}>
          <Button
            type={'submit'}
            kind={'outlined'}
            color={'primary'}
            prefixIcon={<SearchIcon aria-hidden />}
            disabled={!form.formState.isValid || query.isPending}
          >
            {'Найти'}
          </Button>
          <Button
            type={'button'}
            kind={'ghost'}
            color={'secondary'}
            prefixIcon={<EraserIcon aria-hidden />}
            onClick={clear}
          >
            {'Очистить фильтр'}
          </Button>
        </div>
      </form>
      <div className={resultClassName}>
        <CircularProgress isLoading={query.isPending}>
          {!query.isPending && !query.isError && !query.isSuccess && (
            <div className={styles.state}>
              <span className={styles.stateIcon} aria-hidden={'true'}>
                <SearchIcon />
              </span>
              <span className={styles.stateTitle}>
                {'Заполните одно из полей слева и нажмите «Найти»'}
              </span>
            </div>
          )}
          {query.isError && (
            <div className={classNames(styles.state, styles.stateError)}>
              <span className={styles.stateIcon} aria-hidden={'true'}>
                <AlertTriangleIcon />
              </span>
              <span className={styles.stateTitle}>{'Не удалось получить данные о шарде'}</span>
            </div>
          )}
          {query.isSuccess && (
            <div className={styles.resultCard}>
              <div className={styles.resultHeader}>
                <span className={styles.resultIcon} aria-hidden={'true'}>
                  <Layers3 />
                </span>
                <span className={styles.resultTitle}>{'Шард найден'}</span>
              </div>
              <dl className={styles.resultList}>
                <div className={styles.resultRow}>
                  <dt className={styles.resultLabel}>{'ID шарда'}</dt>
                  <dd className={styles.resultValue}>{query.data.shardId}</dd>
                </div>
                <div className={styles.resultRow}>
                  <dt className={styles.resultLabel}>{'Ключ ноды'}</dt>
                  <dd className={styles.resultValue}>{query.data.nodeKey}</dd>
                </div>
              </dl>
            </div>
          )}
        </CircularProgress>
      </div>
    </>
  )
}
