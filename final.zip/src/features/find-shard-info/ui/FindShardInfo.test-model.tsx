import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'

import { FindShardInfo } from './FindShardInfo'

export class FindShardInfoTestModel {
  private readonly view: ReturnType<typeof render>

  private constructor() {
    this.view = render(<FindShardInfo />)
  }

  static render() {
    return new FindShardInfoTestModel()
  }

  async enter(label: string, value: string) {
    await userEvent.type(screen.getByLabelText(label), value)
  }

  async find() {
    const button = screen.getByRole('button', { name: 'Найти' })
    await waitFor(() => expect(button).toBeEnabled())
    await userEvent.click(button)
  }

  async clear() {
    await userEvent.click(screen.getByRole('button', { name: 'Очистить фильтр' }))
  }

  rerender() {
    this.view.rerender(<FindShardInfo />)
  }

  field(label: string) {
    return screen.getByLabelText(label)
  }
}
