import { RoutingTypeDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { screen, waitFor } from '@testing-library/react'

import { FindShardInfoTestModel } from './FindShardInfo.test-model'

const mocks = vi.hoisted(() => ({
  mutate: vi.fn(),
  reset: vi.fn(),
  state: { isPending: false, isError: false, isSuccess: false, data: undefined as any },
}))

vi.mock('@tanstack/react-query', () => ({
  useMutation: () => ({ ...mocks.state, mutate: mocks.mutate, reset: mocks.reset }),
}))

vi.mock('@v-uik/base', () => ({
  Input: ({ label, onChange, error, showErrorIcon: _showErrorIcon, ...props }: Record<string, any>) => (
    <label>
      {label}
      <input
        {...props}
        aria-label={label}
        aria-invalid={Boolean(error)}
        onChange={(event) => onChange(event.target.value)}
      />
    </label>
  ),
  CircularProgress: ({ children }: React.PropsWithChildren) => <div>{children}</div>,
}))

vi.mock('@/shared/ui/Button', () => ({
  Button: (props: React.ButtonHTMLAttributes<HTMLButtonElement>) => <button {...props} />,
}))

describe('FindShardInfo', () => {
  beforeEach(() => {
    mocks.state = { isPending: false, isError: false, isSuccess: false, data: undefined }
  })

  it('нормализует ключ, блокирует остальные поля и запускает поиск нужного типа', async () => {
    const model = FindShardInfoTestModel.render()

    await model.enter('Номер договора', ' ab-42 ')
    expect(model.field('ID договора')).toBeDisabled()
    await model.find()

    await waitFor(() =>
      expect(mocks.mutate).toHaveBeenCalledWith({
        type: RoutingTypeDto.ContractNumber,
        key: 'AB-42',
      }),
    )
  })

  it('показывает успешный результат и очищает форму вместе с запросом', async () => {
    mocks.state = {
      isPending: false,
      isError: false,
      isSuccess: true,
      data: { shardId: 'shard-1', nodeKey: 'node-a' },
    }
    const model = FindShardInfoTestModel.render()

    expect(screen.getByText('ID шарда')).toBeVisible()
    expect(screen.getByText('shard-1')).toBeVisible()
    expect(screen.getByText('Ключ ноды')).toBeVisible()
    expect(screen.getByText('node-a')).toBeVisible()
    await model.enter('ID договора', '42')
    expect(mocks.reset).toHaveBeenCalled()
    await model.clear()

    expect(model.field('ID договора')).toHaveValue('')
    expect(mocks.reset).toHaveBeenCalled()
  })

  it('показывает ошибку запроса у активного поля', async () => {
    mocks.state = { isPending: false, isError: true, isSuccess: false, data: undefined }
    const model = FindShardInfoTestModel.render()
    await model.enter('Номер счета', '40817')

    expect(screen.getByText('Не удалось получить данные о шарде')).toBeVisible()
    expect(model.field('Номер счета')).toHaveAttribute('aria-invalid', 'true')
  })
})
