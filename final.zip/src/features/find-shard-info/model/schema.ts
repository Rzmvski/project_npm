import { z } from 'zod'

const textValue = (maxLength?: number) => {
  let schema = z.string().regex(/^[\p{L}\d\- ]*$/u, 'Недопустимые символы')
  if (maxLength) schema = schema.max(maxLength, `Не более ${maxLength} символов`)
  return schema
}

const numericValue = (maxLength?: number) => {
  let schema = z.string().regex(/^\d*$/, 'Допустимы только цифры')
  if (maxLength) schema = schema.max(maxLength, `Не более ${maxLength} символов`)
  return schema
}

export const shardSearchSchema = z
  .object({
    contractNumber: textValue(),
    contractId: numericValue(25),
    clientId: numericValue(19),
    accountNumber: numericValue(),
    dpan: textValue(20),
  })
  .refine(
    (values) => Object.values(values).filter(Boolean).length === 1,
    'Заполните одно поле поиска',
  )

export type ShardSearchValues = z.input<typeof shardSearchSchema>
