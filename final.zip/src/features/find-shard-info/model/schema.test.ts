import { shardSearchSchema } from './schema'

const empty = {
  contractNumber: '',
  contractId: '',
  clientId: '',
  accountNumber: '',
  dpan: '',
}

describe('shardSearchSchema', () => {
  it.each([
    ['contractNumber', 'ДОГОВОР-42'],
    ['contractId', '1234567890123456789012345'],
    ['clientId', '1234567890123456789'],
    ['accountNumber', '40817810000000000001'],
    ['dpan', 'CARD-123'],
  ])('принимает поиск только по полю %s', (field, value) => {
    expect(shardSearchSchema.safeParse({ ...empty, [field]: value }).success).toBe(true)
  })

  it.each([
    [{ ...empty }, 'одно поле'],
    [{ ...empty, contractId: '1', clientId: '2' }, 'одно поле'],
    [{ ...empty, contractId: '12A' }, 'цифры'],
    [{ ...empty, clientId: '1'.repeat(20) }, '19'],
    [{ ...empty, dpan: 'A'.repeat(21) }, '20'],
    [{ ...empty, contractNumber: 'abc@' }, 'символы'],
  ])('отклоняет некорректный запрос %#', (value, message) => {
    const result = shardSearchSchema.safeParse(value)
    expect(result.success).toBe(false)
    if (!result.success) expect(result.error.issues[0]?.message).toContain(message)
  })
})
