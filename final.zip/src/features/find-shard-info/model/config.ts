import { RoutingTypeDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

export interface ShardSearchField {
  name: 'contractNumber' | 'contractId' | 'clientId' | 'accountNumber' | 'dpan'
  type: RoutingTypeDto
  title: string
}

export const shardSearchFields: ShardSearchField[] = [
  {
    name: 'contractNumber',
    type: RoutingTypeDto.ContractNumber,
    title: 'Номер договора',
  },
  {
    name: 'contractId',
    type: RoutingTypeDto.ContractId,
    title: 'ID договора',
  },
  {
    name: 'clientId',
    type: RoutingTypeDto.ClientId,
    title: 'Идентификатор клиента в ЕПК',
  },
  {
    name: 'accountNumber',
    type: RoutingTypeDto.AccountNumber,
    title: 'Номер счета',
  },
  {
    name: 'dpan',
    type: RoutingTypeDto.Dpan,
    title: 'Номер карты (DPAN)',
  },
]
