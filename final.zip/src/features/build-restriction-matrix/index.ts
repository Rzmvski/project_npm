export { useMatrix } from './lib'
export type { MatrixCell, MatrixRow } from './model'
