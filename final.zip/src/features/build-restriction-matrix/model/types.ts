export type MatrixCell = {
  dc: string
  app: string
  available: boolean
  restricted: boolean
  restrictionIds: string[]
}

export type MatrixRow = {
  app: string
  [dc: string]: string | MatrixCell
}
