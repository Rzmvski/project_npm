import { render, renderHook, screen } from '@testing-library/react'

import { useMatrix } from './useMatrix'

import type { GeoBalancingServiceDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'


vi.mock('lucide-react', () => ({
  MinusIcon: () => <span aria-label='Недоступно' />,
  OctagonMinusIcon: () => <span aria-label='Ограничено' />,
  CheckIcon: () => <span aria-label='Доступно' />,
}))

const services = [
  { name: 'payments', dataCenters: new Set(['dc-1', 'dc-2']) },
  { name: 'reports', dataCenters: new Set(['dc-2']) },
] as GeoBalancingServiceDto[]

const renderCell = (column: Record<string, any>, value: Record<string, unknown>) => {
  const Cell = column.cell
  render(<Cell getValue={() => value} />)
}

describe('useMatrix', () => {
  it('строит строки и доступные пользователю колонки', () => {
    const { result } = renderHook(() =>
      useMatrix({ services, allDataCenters: ['dc-1', 'dc-2'], existingRestrictions: [] }),
    )

    expect(result.current.data).toHaveLength(2)
    expect(result.current.data[0]).toMatchObject({
      app: 'payments',
      'dc-1': { available: true, restricted: false },
    })
    expect(result.current.columns.map((column) => column.header)).toEqual([
      'Приложения',
      'dc-1',
      'dc-2',
    ])
    expect((result.current.columns[0] as any).accessorFn(result.current.data[0])).toBe(
      'payments',
    )
    expect((result.current.columns[1] as any).accessorFn(result.current.data[0])).toMatchObject({
      dc: 'dc-1',
      app: 'payments',
    })
  })

  it('различает недоступную, ограниченную и доступную ячейки', () => {
    const { result } = renderHook(() =>
      useMatrix({ services, allDataCenters: ['dc-1'], existingRestrictions: [] }),
    )
    const column = result.current.columns[1] as Record<string, any>

    renderCell(column, { available: false, restricted: false })
    expect(screen.getByLabelText('Недоступно')).toBeInTheDocument()

    renderCell(column, { available: true, restricted: true })
    expect(screen.getByLabelText('Ограничено')).toBeInTheDocument()

    renderCell(column, { available: true, restricted: false })
    expect(screen.getByLabelText('Доступно')).toBeInTheDocument()
  })

  it('создаёт безопасную недоступную ячейку при неполной матрице', async () => {
    const matrix = await import('./buildMatrix')
    const spy = vi.spyOn(matrix, 'buildMatrix').mockReturnValueOnce([])

    const { result } = renderHook(() =>
      useMatrix({ services: services.slice(0, 1), allDataCenters: ['dc-1'], existingRestrictions: [] }),
    )

    expect(result.current.data[0]?.['dc-1']).toMatchObject({
      available: false,
      restricted: false,
      restrictionIds: [],
    })
    spy.mockRestore()
  })
})
