import { type GeoBalancingServiceDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { type ColumnDef } from '@tanstack/react-table'
import { CheckIcon, MinusIcon, OctagonMinusIcon } from 'lucide-react'
import React, { useMemo } from 'react'

import { type TrafficRestriction } from '@/entities/traffic-restriction'
import { buildMatrix } from '@/features/build-restriction-matrix/lib'
import {
  type MatrixCell,
  type MatrixRow,
} from '@/features/build-restriction-matrix/model'

interface UseMatrixOptions {
  services: GeoBalancingServiceDto[]
  allDataCenters: string[]
  existingRestrictions: TrafficRestriction[]
}

export const useMatrix = ({
  services,
  allDataCenters,
  existingRestrictions,
}: UseMatrixOptions) => {
  const matrix = useMemo(
    () => buildMatrix(services, allDataCenters, existingRestrictions),
    [services, allDataCenters, existingRestrictions]
  )

  const data = useMemo<MatrixRow[]>(
    () =>
      services.map(({ name }, i) => ({
        app: name,
        ...Object.fromEntries(
          allDataCenters.map((dc, j) => [
            dc,
            matrix[i]?.[j] ?? {
              dc,
              app: name,
              available: false,
              restricted: false,
              restrictionIds: [],
            },
          ])
        ),
      })),
    [services, allDataCenters, matrix]
  )

  const columns = useMemo<ColumnDef<MatrixRow, MatrixCell>[]>(
    () => [
      {
        header: 'Приложения',
        accessorFn: ({ app }) => app,
        minSize: 300,
      },
      ...allDataCenters.map<ColumnDef<MatrixRow, MatrixCell>>((dataCenter) => ({
        id: dataCenter,
        header: dataCenter,
        enableSorting: false,
        accessorFn: (row): MatrixCell => row[dataCenter] as MatrixCell,
        cell: ({ getValue }) => {
          const { restricted, available } = getValue<MatrixCell>()

          if (!available) {
            return <MinusIcon />
          }

          return restricted ? <OctagonMinusIcon /> : <CheckIcon />
        },
      })),
    ],
    [allDataCenters]
  )

  return { data, columns }
}
