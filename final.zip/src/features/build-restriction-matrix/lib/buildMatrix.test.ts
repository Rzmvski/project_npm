import type { TrafficRestriction } from '@/entities/traffic-restriction'

import { buildMatrix } from './buildMatrix'

import type { GeoBalancingServiceDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'


const services = [
  { name: 'payments', dataCenters: new Set(['dc-1', 'dc-2']) },
  { name: 'reports', dataCenters: new Set(['dc-2']) },
] as GeoBalancingServiceDto[]

const restriction = (
  id: string | undefined,
  applications: string[],
  dataCenters: string[],
): TrafficRestriction => ({
  id,
  name: id ?? 'draft',
  services: applications,
  dataCenters,
})

describe('buildMatrix', () => {
  it('описывает доступность сервисов без ограничений', () => {
    expect(buildMatrix(services, ['dc-1', 'dc-2'], [])).toEqual([
      [
        {
          app: 'payments',
          dc: 'dc-1',
          available: true,
          restricted: false,
          restrictionIds: [],
        },
        {
          app: 'payments',
          dc: 'dc-2',
          available: true,
          restricted: false,
          restrictionIds: [],
        },
      ],
      [
        {
          app: 'reports',
          dc: 'dc-1',
          available: false,
          restricted: false,
          restrictionIds: [],
        },
        {
          app: 'reports',
          dc: 'dc-2',
          available: true,
          restricted: false,
          restrictionIds: [],
        },
      ],
    ])
  })

  it('применяет глобальные и адресные ограничения только к доступным ячейкам', () => {
    const matrix = buildMatrix(
      services,
      ['dc-1', 'dc-2'],
      [
        restriction('global-dc-2', [], ['dc-2']),
        restriction('payments-dc-1', ['payments'], ['dc-1']),
        restriction(undefined, ['reports'], ['dc-1']),
      ],
    )

    expect(matrix[0]?.[0]).toMatchObject({
      restricted: true,
      restrictionIds: ['payments-dc-1'],
    })
    expect(matrix[0]?.[1]).toMatchObject({
      restricted: true,
      restrictionIds: ['global-dc-2'],
    })
    expect(matrix[1]?.[0]).toMatchObject({
      available: false,
      restricted: false,
      restrictionIds: [],
    })
    expect(matrix[1]?.[1]).toMatchObject({
      restricted: true,
      restrictionIds: ['global-dc-2'],
    })
  })

  it('сохраняет все идентификаторы пересекающихся ограничений', () => {
    const [[cell]] = buildMatrix(
      services.slice(0, 1),
      ['dc-1'],
      [restriction('first', [], ['dc-1']), restriction('second', ['payments'], ['dc-1'])],
    )

    expect(cell?.restrictionIds).toEqual(['first', 'second'])
  })
})
