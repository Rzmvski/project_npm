import { type GeoBalancingServiceDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { type TrafficRestriction } from '@/entities/traffic-restriction'
import { type MatrixCell } from '@/features/build-restriction-matrix/model'

type RestrictionMap = Map<string, string[]>

const isGlobal = ({ services }: TrafficRestriction) => {
  return services.length === 0
}

const createKey = (app: string, dc: string) => {
  return `${app}::${dc}`
}

const createRestrictionMap = (
  applications: string[],
  restrictions: TrafficRestriction[]
) => {
  const map: RestrictionMap = new Map()

  const addRestriction = (app: string, dc: string, id?: string) => {
    if (!id) return
    const key = createKey(app, dc)
    const existing = map.get(key)
    if (existing) {
      existing.push(id)
    } else {
      map.set(key, [id])
    }
  }

  restrictions.forEach((restriction) => {
    const apps = isGlobal(restriction) ? applications : restriction.services
    const { dataCenters, id } = restriction

    apps.forEach((app) => {
      dataCenters.forEach((dc) => {
        addRestriction(app, dc, id)
      })
    })
  })

  return map
}

export const buildMatrix = (
  services: GeoBalancingServiceDto[],
  dataCenters: string[],
  restrictions: TrafficRestriction[]
) => {
  const serviceNames = services.map(({ name }) => name)
  const restrictionMap = createRestrictionMap(serviceNames, restrictions)

  return services.map(({ name, dataCenters: serviceDcs }) =>
    dataCenters.map((dc): MatrixCell => {
      const key = createKey(name, dc)
      const restrictionIds = restrictionMap.get(key) ?? []
      const available = Array.from(serviceDcs ?? [])?.includes(dc) ?? false

      return {
        app: name,
        dc,
        available,
        restricted: available && restrictionIds.length > 0,
        restrictionIds,
      }
    })
  )
}
