import { zodResolver } from '@hookform/resolvers/zod'
import { DeleteFlagDto } from '@sber-pprb-tkp/tcpf-support-admin-api'
import { useForm } from 'react-hook-form'

import {
  transferTaskSchema,
  type TransferTaskValues,
} from '@/entities/transfer-task'

const defaultValues: TransferTaskValues = {
  receiverShardId: '',
  sourceMode: 'script',
  script: '',
  deleteFlag: DeleteFlagDto.DO_NOT_DELETE,
  shards: [],
}

export const useCreateTransferTaskForm = () => {
  const form = useForm({
    defaultValues,
    resolver: zodResolver(transferTaskSchema),
  })

  const { watch } = form

  const mode = watch('sourceMode')

  return { form, mode }
}
