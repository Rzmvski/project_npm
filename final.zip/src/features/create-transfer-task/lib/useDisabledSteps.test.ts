import { renderHook } from '@testing-library/react'

import { useDisabledSteps } from './useDisabledSteps'

describe('useDisabledSteps', () => {
  const steps = [
    { id: 'source', fields: ['sourceMode', 'script'] },
    { id: 'target', fields: ['receiverShardId'], dependsOn: 'source' },
    { id: 'options', fields: ['deleteFlag'], dependsOn: 'target' },
  ] as never

  it('оставляет первый шаг доступным и блокирует зависимые незаполненные шаги', () => {
    const { result } = renderHook(() => useDisabledSteps({}, steps))

    expect(result.current).toMatchObject({
      source: false,
      target: true,
      options: true,
    })
  })

  it('открывает следующий шаг после изменения всех полей предыдущего', () => {
    const { result } = renderHook(() =>
      useDisabledSteps({ sourceMode: true, script: true, receiverShardId: true }, steps),
    )

    expect(result.current).toMatchObject({
      source: false,
      target: false,
      options: false,
    })
  })

  it('отклоняет конфигурацию с неизвестной зависимостью', () => {
    expect(() =>
      renderHook(() =>
        useDisabledSteps({}, [{ id: 'target', fields: [], dependsOn: 'missing' }] as never),
      ),
    ).toThrow('step target depends on unknown step')
  })
})
