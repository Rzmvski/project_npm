import { useMemo } from 'react'
import { type FieldNamesMarkedBoolean, type FieldValues } from 'react-hook-form'

import { type StepDef, type StepId } from '@/features/create-transfer-task/config'

export const useDisabledSteps = <T extends FieldValues>(
  dirtyFields: Partial<Readonly<FieldNamesMarkedBoolean<T>>>,
  steps: StepDef<T>[]
) => {
  return useMemo(() => {
    const disabled: Record<string, boolean> = {}

    for (const step of steps) {
      const { dependsOn, id } = step
      if (!dependsOn) {
        disabled[id] = false
        continue
      }

      const prevStep = steps.find((s) => s.id === dependsOn)
      if (!prevStep) throw new Error(`step ${id} depends on unknown step`)

      const isCompleted = prevStep.fields.every(
        (field) => !!dirtyFields[field as string] ?? true
      )
      disabled[id] = !isCompleted
    }
    return disabled as Record<StepId, boolean>
  }, [dirtyFields, steps])
}
