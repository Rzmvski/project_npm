import { describe, it, expect } from 'vitest'

import { STEP_DEFS, type StepId } from '@/features/create-transfer-task/config/stepConfig'

describe('stepConfig', () => {
  it('should have mode step', () => {
    const modeStep = STEP_DEFS.find((s) => s.id === 'mode')
    expect(modeStep).toBeDefined()
    expect(modeStep?.fields).toContain('sourceMode')
  })

  it('should have target step with dependency', () => {
    const targetStep = STEP_DEFS.find((s) => s.id === 'target')
    expect(targetStep).toBeDefined()
    expect(targetStep?.dependsOn).toBe('source')
  })

  it('should have options step with dependency', () => {
    const optionsStep = STEP_DEFS.find((s) => s.id === 'options')
    expect(optionsStep).toBeDefined()
    expect(optionsStep?.dependsOn).toBe('target')
  })

  it('StepId should be valid values', () => {
    const ids: StepId[] = ['mode', 'source', 'target', 'options']
    expect(ids).toContain('mode')
    expect(ids).toContain('options')
  })
})
