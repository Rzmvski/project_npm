import { type ListModeValues, type ScriptModeValues } from '@/entities/transfer-task'

export type StepId = 'mode' | 'source' | 'target' | 'options'

export type StepDef<T> = {
  id: StepId
  fields: Array<keyof T>
  dependsOn?: StepId
}

export const STEP_DEFS: StepDef<ListModeValues & ScriptModeValues>[] = [
  {
    id: 'mode',
    fields: ['sourceMode'],
  },
  {
    id: 'target',
    fields: ['receiverShardId'],
    dependsOn: 'source',
  },
  {
    id: 'options',
    fields: ['deleteFlag'],
    dependsOn: 'target',
  },
]
