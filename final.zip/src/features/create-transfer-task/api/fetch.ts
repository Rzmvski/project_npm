import { type CreateTaskRequestDto, DeleteFlagDto } from '@sber-pprb-tkp/tcpf-support-admin-api'

import { ProcessGroupDictionary } from '@/entities/process-group'
import { type TransferTaskValues } from '@/entities/transfer-task'
import { clientTransferService } from '@/shared/api'

/**
 * Формирование задания
 * Method: POST
 * URL: /invoke/support-admin/client-transfer-service/task
 */
export const fetchCreateTask = (createTaskForm: TransferTaskValues) => {
  const task =
    createTaskForm.sourceMode == 'script'
      ? { query: createTaskForm.script, shards: createTaskForm.shards }
      : { clientList: createTaskForm.clientIds }

  const createTaskRequestDto: CreateTaskRequestDto = {
    query: task.query,
    clientList: task.clientList?.map((v) => v.toString()),
    deleteFlag: createTaskForm.deleteFlag ? DeleteFlagDto.DELETE : DeleteFlagDto.DO_NOT_DELETE,
    sourceShardIds: task.shards,
    targetShardId: Number(createTaskForm.receiverShardId),
    auditInfo: {
      formName: 'RUN_PROCESS',
      groupId: ProcessGroupDictionary.GET_TASK_TO_TRANSFERRING.toString(),
    },
  }
  return clientTransferService.createTask(createTaskRequestDto)
}
