import { DeleteFlagDto } from '@sber-pprb-tkp/tcpf-support-admin-api'

import { fetchCreateTask } from './fetch'

const createTask = vi.hoisted(() => vi.fn())
vi.mock('@/shared/api', () => ({ clientTransferService: { createTask } }))

describe('fetchCreateTask', () => {
  it('формирует задание из script-источника', () => {
    fetchCreateTask({
      sourceMode: 'script',
      script: 'select id from clients',
      shards: [1, 2],
      receiverShardId: '3',
      deleteFlag: true,
    } as never)

    expect(createTask).toHaveBeenCalledWith(
      expect.objectContaining({
        query: 'select id from clients',
        sourceShardIds: [1, 2],
        targetShardId: 3,
        deleteFlag: DeleteFlagDto.DELETE,
      }),
    )
  })

  it('формирует задание из списка клиентов', () => {
    fetchCreateTask({
      sourceMode: 'list',
      clientIds: [101, 202],
      receiverShardId: 3,
      deleteFlag: false,
    } as never)

    expect(createTask).toHaveBeenCalledWith(
      expect.objectContaining({
        clientList: ['101', '202'],
        query: undefined,
        deleteFlag: DeleteFlagDto.DO_NOT_DELETE,
      }),
    )
  })
})
