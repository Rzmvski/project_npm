import { renderHook } from '@testing-library/react'

import { useChangeNodeBoundaryMutation } from './useChangeNodeBoundaryMutation'

const mocks = vi.hoisted(() => ({ config: null as any, fetch: vi.fn(), success: vi.fn(), error: vi.fn(), invalidate: vi.fn() }))
vi.mock('@tanstack/react-query', () => ({
  useQueryClient: () => ({ invalidateQueries: mocks.invalidate }),
  useMutation: (config: any) => ((mocks.config = config), { mutate: config.mutationFn }),
}))
vi.mock('@v-uik/base', () => ({ notification: { success: mocks.success, error: mocks.error } }))
vi.mock('@/features/change-shard-boundary/api', () => ({ fetchUpdateBucketRatio: (...args: any[]) => mocks.fetch(...args) }))
vi.mock('@/entities/node', () => ({ nodesQueryKey: ['nodes'] }))
vi.mock('@/entities/routing-shard', () => ({ availableShardsQueryKey: ['available-shards'] }))

it('useChangeNodeBoundaryMutation изменяет границу, уведомляет и обновляет узлы и шарды', () => {
  const { result } = renderHook(() => useChangeNodeBoundaryMutation(7))
  result.current.mutate(70)
  expect(mocks.fetch).toHaveBeenCalledWith(7, 70)
  mocks.config.onSuccess()
  mocks.config.onError()
  expect(mocks.success).toHaveBeenCalled()
  expect(mocks.error).toHaveBeenCalled()
  expect(mocks.invalidate).toHaveBeenCalledWith({ queryKey: ['nodes'] })
  expect(mocks.invalidate).toHaveBeenCalledWith({ queryKey: ['available-shards'] })
})
