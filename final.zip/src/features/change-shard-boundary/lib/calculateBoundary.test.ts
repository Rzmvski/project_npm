import { MAX_BUCKET_VALUE } from '@/entities/range'

import { calculateBoundary } from './calculateBoundary'

describe('calculateBoundary', () => {
  it('вычисляет границу пропорционально нагрузке первого узла', () => {
    expect(calculateBoundary([{ load: 25 }, { load: 75 }] as never)).toBe(
      Math.round(MAX_BUCKET_VALUE * 0.25),
    )
  })

  it('учитывает округление bucket boundary', () => {
    expect(calculateBoundary([{ load: 33.3 }, { load: 66.7 }] as never)).toBe(
      Math.round(MAX_BUCKET_VALUE * 0.333),
    )
  })
})
