import { useEffect } from 'react'
import { useForm, useWatch } from 'react-hook-form'

import {
  type Loadable,
  type ShardBoundaryValues,
} from '@/features/change-shard-boundary/model'

import { calculateBoundary } from './calculateBoundary'

interface UseChangeBoundaryOptions {
  nodes: Loadable[]
}

export const useChangeBoundary = ({ nodes }: UseChangeBoundaryOptions) => {
  const initialBoundary = calculateBoundary(nodes)

  const boundaryForm = useForm<ShardBoundaryValues>({
    defaultValues: {
      boundary: initialBoundary,
      nodes,
    },
  })

  const {
    reset,
    control,
    formState: { isDirty },
  } = boundaryForm
  const currentBoundary = useWatch({ control, name: 'boundary' })
  const currentNodes = useWatch({ control, name: 'nodes' })

  useEffect(() => {
    // Пока есть несохранённые правки (форма "грязная"), не затираем их
    // свежим снапшотом с сервера — иначе любое фоновое обновление (SSE
    // приходит каждые несколько секунд) сбрасывает то, что пользователь
    // ещё не отправил и не отменил. Как только правок не остаётся —
    // после успешного сабмита (см. LoadTab) или нажатия «Отмена» —
    // isDirty становится false, эффект перезапускается и подтягивает
    // актуальные nodes.
    if (isDirty) return

    reset({
      boundary: calculateBoundary(nodes),
      nodes,
    })
  }, [nodes, reset, isDirty])

  return {
    boundaryForm,
    isPending: isDirty,
    reset,
    currentBoundary,
    currentNodes,
  }
}
