import { fetchUpdateBucketRatio } from './fetch'

const updateNodesOfShardById = vi.hoisted(() => vi.fn())
vi.mock('@/shared/api', () => ({
  clusterManagementService: { updateNodesOfShardById },
}))

it('fetchUpdateBucketRatio передаёт границу бакетов для указанной шарды', () => {
  fetchUpdateBucketRatio(42, 128)
  expect(updateNodesOfShardById).toHaveBeenCalledWith([42], {
    bucketBoundary: [128],
  })
})
