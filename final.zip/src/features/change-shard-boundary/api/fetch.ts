import { clusterManagementService } from '@/shared/api'

export const fetchUpdateBucketRatio = (
  shardId: number,
  bucketNumber: number
) => {
  return clusterManagementService.updateNodesOfShardById([shardId], {
    bucketBoundary: [bucketNumber],
  })
}
