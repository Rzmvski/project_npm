import { type ProcessDtoDto } from '@sber-pprb-tkp/tcpf-support-admin-api'

import { ProcessGroupDictionary } from '@/entities/process-group'
import { odService } from '@/shared/api'

export const fetchCloseTradingDay = (od: Date): Promise<ProcessDtoDto> => {
  return odService.closeOd({
    groupId: ProcessGroupDictionary.EOD_AND_OOD_BY_CONTRACT,
    operationDay: od,
    auditInfo: {
      formName: 'RUN_CLOSING_OPERATION_DAY',
      date: od,
    },
  })
}
