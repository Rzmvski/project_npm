import { ProcessGroupDictionary } from '@/entities/process-group'

import { fetchCloseTradingDay } from './fetch'

const closeOd = vi.hoisted(() => vi.fn())
vi.mock('@/shared/api', () => ({ odService: { closeOd } }))

it('fetchCloseTradingDay передаёт дату и обязательный audit-контекст', () => {
  const date = new Date('2026-08-13')
  fetchCloseTradingDay(date)
  expect(closeOd).toHaveBeenCalledWith({
    groupId: ProcessGroupDictionary.EOD_AND_OOD_BY_CONTRACT,
    operationDay: date,
    auditInfo: { formName: 'RUN_CLOSING_OPERATION_DAY', date },
  })
})
