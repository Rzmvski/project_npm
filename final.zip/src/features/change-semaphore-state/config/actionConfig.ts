import { ClusterStateDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { type AdditionalOption } from '@/features/change-semaphore-state/model'

type ActionConfig = {
  defaultAction: string
  additionalOptions: AdditionalOption[]
  targetState: ClusterStateDto
}

type ClusterState = ClusterStateDto.Active | ClusterStateDto.Inactive

export const ACTIONS_CONFIG: Record<ClusterState, ActionConfig> = {
  [ClusterStateDto.Active]: {
    defaultAction: 'деактивировать',
    additionalOptions: [
      {
        label: 'переключить диапазоны бакетов',
        name: 'switchRanges',
      },
    ],
    targetState: ClusterStateDto.Inactive,
  },
  [ClusterStateDto.Inactive]: {
    defaultAction: 'активировать',
    additionalOptions: [
      {
        label: 'пересоздать модель семафоров',
        name: 'createModel',
      },
      {
        label: 'восстановить диапазоны бакетов',
        name: 'restoreRanges',
      },
    ],
    targetState: ClusterStateDto.Active,
  },
}
