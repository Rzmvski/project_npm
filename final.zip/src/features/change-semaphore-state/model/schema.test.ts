import { describe, it, expect } from 'vitest'

import { actionFormSchema } from '@/features/change-semaphore-state/model/schema'

describe('actionFormSchema', () => {
  it('should validate with all optional fields', () => {
    const result = actionFormSchema.safeParse({
      switchRanges: true,
      createModel: false,
      restoreRanges: true,
    })

    expect(result.success).toBe(true)
    if (result.success) {
      expect(result.data.switchRanges).toBe(true)
      expect(result.data.restoreRanges).toBe(true)
    }
  })

  it('should accept empty object', () => {
    const result = actionFormSchema.safeParse({})
    expect(result.success).toBe(true)
  })
})
