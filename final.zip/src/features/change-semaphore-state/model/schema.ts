import { z } from 'zod'

export const actionFormSchema = z.object({
  switchRanges: z.boolean().optional(),
  createModel: z.boolean().optional(),
  restoreRanges: z.boolean().optional(),
})

export type ActionFormValues = z.infer<typeof actionFormSchema>
