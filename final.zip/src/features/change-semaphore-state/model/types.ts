import { type ChangeClusterStateRequestDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

export type AdditionalFlagName = keyof Omit<
  ChangeClusterStateRequestDto,
  'status'
>

export type AdditionalOption = {
  label: string
  name: AdditionalFlagName
}
