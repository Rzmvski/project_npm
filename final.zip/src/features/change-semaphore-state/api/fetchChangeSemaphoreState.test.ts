import { ClusterStateDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { fetchChangeSemaphoreState } from './fetchChangeSemaphoreState'

const changeClusterState = vi.hoisted(() => vi.fn())
vi.mock('@/shared/api', () => ({ clusterManagementService: { changeClusterState } }))

it('fetchChangeSemaphoreState объединяет status и дополнительные параметры', () => {
  fetchChangeSemaphoreState('cluster-1', ClusterStateDto.Active, {
    frozenNode: true,
  } as never)
  expect(changeClusterState).toHaveBeenCalledWith('cluster-1', {
    status: ClusterStateDto.Active,
    frozenNode: true,
  })
})
