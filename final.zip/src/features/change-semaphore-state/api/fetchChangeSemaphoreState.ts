import { type ClusterStateDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { type ActionFormValues } from '@/features/change-semaphore-state/model'
import { clusterManagementService } from '@/shared/api'

export const fetchChangeSemaphoreState = (
  clusterKey: string,
  status: ClusterStateDto,
  additionalOptions?: ActionFormValues
): Promise<void> => {
  return clusterManagementService.changeClusterState(clusterKey, {
    ...additionalOptions,
    status,
  })
}
