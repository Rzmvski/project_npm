import { ClusterStateDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { type ColumnDef } from '@tanstack/react-table'
import { groupBy } from 'lodash-es'
import { useMemo } from 'react'

import { type Range, type Rangeble, RangeGroups } from '@/entities/range'
import { type Semaphore } from '@/entities/semaphore'
import { standardSorting } from '@/shared/lib'
import { Badge, type BadgeConfig } from '@/shared/ui/Badge'

const groupRanges = (data: Range[]) =>
  Object.entries(groupBy(data, (ranges) => ranges.nodeKey))
    .sort(([nodeKey], [anotherKey]) => standardSorting(nodeKey, anotherKey))
    .map(([nodeKey, ranges]) => {
      const frozenNode = ranges.some(({ frozenNode }) => frozenNode)

      return {
        nodeKey,
        frozenNode,
        ranges,
      }
    })

const SEMAPHORE_STATUS_BADGE_COLOR: Record<ClusterStateDto, Omit<BadgeConfig, 'text'>> = {
  [ClusterStateDto.Active]: { color: 'green' },
  [ClusterStateDto.Inactive]: { color: 'gray' },
  [ClusterStateDto.Creating]: { color: 'blue' },
  [ClusterStateDto.OnLoading]: { color: 'blue' },
  [ClusterStateDto.Unrecognized]: { color: 'yellow' },
}

const getSemaphoreBadgeConfig = (status: ClusterStateDto): BadgeConfig => {
  const config = SEMAPHORE_STATUS_BADGE_COLOR[status]
  return { text: status, ...config }
}

export const useSemaphoreColumns = (): ColumnDef<Rangeble<Semaphore>>[] => {
  return useMemo(
    () => [
      {
        header: 'ID кластера',
        accessorKey: 'clusterKey',
        size: 120,
        enableSorting: false,
      },
      {
        header: 'Кол-во записей',
        accessorKey: 'recordsAmount',
        cell: ({ getValue }) => (getValue<number>() >= 0 ? getValue() : 'неизвестно'),
        enableSorting: false,
        size: 150,
        minSize: 150,
        maxSize: 150,
      },
      {
        header: 'Диапазон бакетов',
        accessorKey: 'ranges',
        cell: ({ getValue }) => {
          const ranges = getValue<Range[]>()
          const groups = groupRanges(ranges)
          return <RangeGroups groups={groups} />
        },
        enableSorting: false,
      },
      {
        header: 'Статус',
        accessorKey: 'status',
        cell: ({ getValue }) => (
          <Badge {...getSemaphoreBadgeConfig(getValue<ClusterStateDto>())} />
        ),
        enableSorting: false,
        size: 140,
        minSize: 140,
        maxSize: 140,
      },
    ],
    [],
  )
}
