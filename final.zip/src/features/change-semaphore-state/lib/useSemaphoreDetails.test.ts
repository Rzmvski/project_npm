import { ClusterStateDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { renderHook } from '@testing-library/react'

import { useSemaphoreDetails } from './useSemaphoreDetails'

const mocks = vi.hoisted(() => ({
  query: null as Record<string, any> | null,
  fetchSemaphores: vi.fn(),
  getShards: vi.fn(),
}))
vi.mock('@tanstack/react-query', () => ({
  useQuery: (config: Record<string, any>) => {
    mocks.query = config
    return { data: config.initialData }
  },
}))
vi.mock('@/shared/api', () => ({
  createPollingQueryPolicy: (options: Record<string, any>) => ({
    stopPredicate: options.stopPredicate,
  }),
  clusterManagementService: { getShards: () => mocks.getShards() },
}))
vi.mock('@/entities/semaphore', () => ({
  fetchSemaphores: () => mocks.fetchSemaphores(),
}))
vi.mock('@/entities/range', () => ({
  convertRange: (value: Record<string, any>) => ({
    start: value.startInclusive,
    end: value.endExclusive,
  }),
}))

it('useSemaphoreDetails объединяет семафоры с диапазонами бакетов их шард', async () => {
  mocks.fetchSemaphores.mockResolvedValue([
    { clusterKey: 'a', status: ClusterStateDto.Unrecognized },
    { clusterKey: 'b', status: ClusterStateDto.Active },
  ])
  mocks.getShards.mockResolvedValue([
    {
      id: 1,
      bucketRanges: [
        { semaphoreClusterKey: 'a', startInclusive: 0, endExclusive: 10 },
        { semaphoreClusterKey: 'a', startInclusive: 10, endExclusive: 20 },
        { semaphoreClusterKey: 'b', startInclusive: 0, endExclusive: 20 },
      ],
    },
  ])
  renderHook(() => useSemaphoreDetails())

  await expect(mocks.query?.queryFn()).resolves.toEqual([
    expect.objectContaining({
      clusterKey: 'a',
      status: ClusterStateDto.Unrecognized,
      ranges: [
        { start: 0, end: 10 },
        { start: 10, end: 20 },
      ],
    }),
    expect.objectContaining({
      clusterKey: 'b',
      status: ClusterStateDto.Active,
      ranges: [{ start: 0, end: 20 }],
    }),
  ])
  expect(mocks.query?.stopPredicate([{ status: ClusterStateDto.Active }])).toBe(true)
  expect(mocks.query?.stopPredicate([{ status: ClusterStateDto.Creating }])).toBe(false)
})
