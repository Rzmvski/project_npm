import {
  ClusterStateDto,
  type ShardDto,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { useQuery } from '@tanstack/react-query'
import { groupBy } from 'lodash-es'

import { convertRange, type Rangeble } from '@/entities/range'
import { fetchSemaphores, type Semaphore } from '@/entities/semaphore'
import {
  clusterManagementService,
  createPollingQueryPolicy,
} from '@/shared/api'

// Начиная с platform-api 2.1 semaphoreInfo() отдаёт только данные семафорного
// кластера (без диапазонов бакетов), а диапазоны переехали в bucketRanges
// шард (getShards()). Собираем их вместе по ключу семафорного кластера:
// BucketRangeDto.semaphoreClusterKey === Semaphore.clusterKey.
const convert = (
  semaphores: Semaphore[],
  shards: ShardDto[]
): Rangeble<Semaphore>[] => {
  const bucketRanges = shards.flatMap((shard) => shard.bucketRanges ?? [])
  const rangesByCluster = groupBy(
    bucketRanges,
    (range) => range.semaphoreClusterKey
  )

  return semaphores.map((semaphore) => ({
    ...semaphore,
    ranges: (rangesByCluster[semaphore.clusterKey] ?? []).map(convertRange),
  }))
}

export const useSemaphoreDetails = () => {
  return useQuery({
    initialData: [],
    queryKey: ['semaphores-details'],
    queryFn: () =>
      Promise.all([
        fetchSemaphores(),
        clusterManagementService.getShards(),
      ]).then(([semaphores, shards]) => convert(semaphores, shards)),
    ...createPollingQueryPolicy({
      stopPredicate: (data: Rangeble<Semaphore>[]) =>
        data.every((s) => s.status !== ClusterStateDto.Creating),
    }),
  })
}
