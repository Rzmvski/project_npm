import { ClusterStateDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { renderHook } from '@testing-library/react'

import { useSemaphoreColumns } from './useSemaphoreColumns'

import type { ColumnDef } from '@tanstack/react-table'


type Row = Record<string, unknown>
type TestColumn = ColumnDef<Row> & { cell?: (context: never) => unknown }

const column = (columns: TestColumn[], header: string) =>
  columns.find((candidate) => candidate.header === header)!

const cell = (candidate: TestColumn, value: unknown) =>
  candidate.cell?.({ getValue: () => value } as never)

describe('useSemaphoreColumns', () => {
  const columns = () => renderHook(() => useSemaphoreColumns()).result.current as TestColumn[]

  it('показывает известное и неизвестное количество записей', () => {
    const records = column(columns(), 'Кол-во записей')

    expect(cell(records, 0)).toBe(0)
    expect(cell(records, 42)).toBe(42)
    expect(cell(records, -1)).toBe('неизвестно')
  })

  it('группирует диапазоны по нодам и отмечает замороженную ноду', () => {
    const ranges = column(columns(), 'Диапазон бакетов')
    const result = cell(ranges, [
      { nodeKey: 'node-b', from: 20, to: 30, frozenNode: false },
      { nodeKey: 'node-a', from: 0, to: 10, frozenNode: false },
      { nodeKey: 'node-a', from: 10, to: 20, frozenNode: true },
    ]) as React.ReactElement<{ groups: Array<Record<string, unknown>> }>

    expect(result.props.groups).toEqual([
      expect.objectContaining({
        nodeKey: 'node-a',
        frozenNode: true,
        ranges: expect.arrayContaining([
          expect.objectContaining({ from: 0 }),
          expect.objectContaining({ from: 10 }),
        ]),
      }),
      expect.objectContaining({ nodeKey: 'node-b', frozenNode: false }),
    ])
  })

  it.each(Object.values(ClusterStateDto))('создаёт badge статуса %s', (status) => {
    expect(cell(column(columns(), 'Статус'), status)).toBeTruthy()
  })
})
