import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'

import {
  actionFormSchema,
  type ActionFormValues,
  type AdditionalOption,
} from '@/features/change-semaphore-state/model'

interface UseActionFormOptions {
  additionalOptions: AdditionalOption[]
}

export const useActionForm = ({ additionalOptions }: UseActionFormOptions) => {
  return useForm<ActionFormValues>({
    resolver: zodResolver(actionFormSchema),
    defaultValues: additionalOptions?.reduce((acc, { name }) => {
      acc[name] = false
      return acc
    }, {} as ActionFormValues),
  })
}
