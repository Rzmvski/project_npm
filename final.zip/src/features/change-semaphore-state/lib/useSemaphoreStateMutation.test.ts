import { ClusterStateDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { renderHook } from '@testing-library/react'

import { useSemaphoreStateMutation } from './useSemaphoreStateMutation'

const mocks = vi.hoisted(() => ({ config: null as any, fetch: vi.fn(), success: vi.fn() }))
vi.mock('@tanstack/react-query', () => ({ useMutation: (config: any) => ((mocks.config = config), { mutate: config.mutationFn }) }))
vi.mock('@v-uik/base', () => ({ notification: { success: mocks.success } }))
vi.mock('@/features/change-semaphore-state/api', () => ({ fetchChangeSemaphoreState: (...args: any[]) => mocks.fetch(...args) }))

it('useSemaphoreStateMutation меняет состояние с дополнительными параметрами', () => {
  const { result } = renderHook(() => useSemaphoreStateMutation('cluster-a'))
  result.current.mutate({
    targetState: ClusterStateDto.Active,
    additionalOptions: { switchRanges: true },
  })
  expect(mocks.fetch).toHaveBeenCalledWith('cluster-a', ClusterStateDto.Active, {
    switchRanges: true,
  })
  mocks.config.onSuccess()
  expect(mocks.success).toHaveBeenCalledWith(expect.stringContaining('cluster-a'))
})
