import { type ClusterStateDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { useMutation } from '@tanstack/react-query'
import { notification } from '@v-uik/base'

import { fetchChangeSemaphoreState } from '@/features/change-semaphore-state/api'
import { type ActionFormValues } from '@/features/change-semaphore-state/model'

interface StateMutationOptions {
  targetState: ClusterStateDto
  additionalOptions?: ActionFormValues
}

export const useSemaphoreStateMutation = (clusterKey: string) => {
  return useMutation({
    mutationFn: ({ targetState, additionalOptions }: StateMutationOptions) =>
      fetchChangeSemaphoreState(clusterKey, targetState, additionalOptions),
    onSuccess: () =>
      notification.success(
        `Изменение статуса семафора ${clusterKey} выполнено успешно`
      ),
  })
}
