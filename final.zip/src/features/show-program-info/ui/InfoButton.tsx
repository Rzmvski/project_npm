import { BarButton } from '@v-uik/base'
import { CircleHelp } from 'lucide-react'
import React, { type FC, useRef } from 'react'

import { Popup } from '@/shared/ui/Popup'

export const InfoButton: FC = () => {
  const anchorRef = useRef<Nullable<HTMLDivElement>>(null)

  return (
    <Popup content={<span>{`Версия программы ${__APP_VERSION__}`}</span>}>
      <BarButton
        ref={anchorRef}
        aria-label={'О программе'}
        title={'О программе'}
      >
        <CircleHelp />
      </BarButton>
    </Popup>
  )
}
