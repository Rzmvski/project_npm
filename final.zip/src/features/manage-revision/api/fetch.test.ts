import { RevisionStatusDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { fetchChangeRevisionState } from './fetchChangeRevisionState'
import { fetchRunRevision } from './fetchRunRevision'

const service = vi.hoisted(() => ({
  changeRevisionStatus: vi.fn(),
  revise: vi.fn(),
}))
vi.mock('@/shared/api', () => ({ reviseReplicationService: service }))

describe('manage revision api', () => {
  it('передаёт команду смены статуса в API-порядке', () => {
    fetchChangeRevisionState(
      'shard-1',
      42,
      'request-id',
      RevisionStatusDto.Aborted,
      undefined,
      'accounts',
    )
    expect(service.changeRevisionStatus).toHaveBeenCalledWith(
      42,
      'request-id',
      'shard-1',
      RevisionStatusDto.Aborted,
      undefined,
      'accounts',
    )
  })

  it('запускает полную ревизию по умолчанию', () => {
    fetchRunRevision(['shard-1'], 'request-id')
    expect(service.revise).toHaveBeenCalledWith('request-id', ['shard-1'], 1)
  })

  it('передаёт выбранную долю ревизии', () => {
    fetchRunRevision(['shard-1', 'shard-2'], 'request-id', 0.25)
    expect(service.revise).toHaveBeenCalledWith('request-id', ['shard-1', 'shard-2'], 0.25)
  })
})
