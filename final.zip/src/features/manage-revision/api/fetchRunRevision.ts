import { type RevisionInfoDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { reviseReplicationService } from '@/shared/api'

/**
 * Запуск процесса сверки
 * Method: POST
 * URL: /invoke/support-admin/revise-replication-service/shards/{shardId}/revisions
 * @param shardIds - id шард, на которых будет проводиться сверка
 * @param uuid - uuid запущенной сверки
 * @param part - доля сверки
 * @returns {Promise}
 */
export const fetchRunRevision = (
  shardIds: string[],
  uuid: string,
  part = 1
): Promise<RevisionInfoDto[]> => {
  return reviseReplicationService.revise(uuid, shardIds, part)
}
