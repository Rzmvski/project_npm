import {
  type RevisionInfoDto,
  type RevisionJobDto,
  type RevisionStatusDto,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { reviseReplicationService } from '@/shared/api'

/**
 * Изменение статуса сверки
 * Method: PATCH
 * URL: /invoke/support-admin/revise-replication-service/shards/{shardId}/revisions/{revisionId}
 * @param shardId - id шарда, на которой проводится сверка
 * @param revisionId - id запущенной сверки
 * @param uuid - uuid запущенной сверки
 * @param status - новый статус сверки
 * @param job - работа, которую необходимо запустить
 * @param table - таблица, на которой необходимо запустить работу
 * @returns {Promise}
 */
export const fetchChangeRevisionState = (
  shardId: string,
  revisionId: number,
  uuid: string,
  status?: RevisionStatusDto,
  job?: RevisionJobDto,
  table?: string
): Promise<RevisionInfoDto> => {
  return reviseReplicationService.changeRevisionStatus(
    revisionId,
    uuid,
    shardId,
    status,
    job,
    table
  )
}
