import {
  type CommonRevisionInfoDto,
  RevisionJobDto,
  RevisionStatusDto,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { type QueryKey } from '@tanstack/react-query'
import {
  ArrowLeftRightIcon,
  DownloadIcon,
  ListIcon,
  PlayIcon,
  RotateCcwIcon,
  StopCircleIcon,
} from 'lucide-react'
import React, { type ReactNode } from 'react'

import { isFinal, type RevisionActions } from '@/entities/revision'
import { useLoadRevisionReport } from '@/entities/revision-report'
import { useRevisionStatusMutation } from '@/features/manage-revision'
import { useConfirm } from '@/shared/lib'


type ActionConfig = {
  label: string
  icon: ReactNode
  onClick: () => void
  disabled?: boolean
  confirmable?: boolean
  confirmTitle?: string
  confirmText?: string
}

export interface RevisionContext extends CommonRevisionInfoDto {
  shardId: string
  updated?: Date
  table?: string
}

export interface UseRevisionActionsParams {
  queryKey?: QueryKey
  detailsAction?: (context: RevisionContext) => void
}

export const useRevisionActions = ({
  queryKey,
  detailsAction,
  ...context
}: UseRevisionActionsParams & RevisionContext): Record<
  RevisionActions,
  ActionConfig
> => {
  const {
    shardId,
    id,
    status,
    updated,
    table,
    jobStatus,
    cursorFinished,
    rowsDiffSaved,
  } = context
  const revisionStatus = jobStatus ?? status
  if (!id || !revisionStatus) {
    throw Error('revision id and status should be provided')
  }
  const { mutate: changeStatus, isPending: isChangeStatusPending } =
    useRevisionStatusMutation({ queryKey, table })
  const { mutate: loadReport, isPending: isReportPending } =
    useLoadRevisionReport()
  const confirm = useConfirm()

  const createConfirmableHandler = (
    onClick: () => void,
    confirmTitle: string,
    confirmText: string
  ) => {
    return async () => {
      const isConfirmed = await confirm({
        title: confirmTitle,
        text: confirmText,
      })
      if (isConfirmed) {
        onClick()
      }
    }
  }

  return {
    RUN: {
      label: 'Сверить',
      icon: <PlayIcon />,
      disabled:
        isChangeStatusPending || !isFinal(revisionStatus) || cursorFinished,
      onClick: createConfirmableHandler(
        () =>
          changeStatus({ shardId, revisionId: id, job: RevisionJobDto.Revise }),
        'Сверить данные',
        'Вы уверены, что хотите начать сверку?'
      ),
    },
    ALIGN_LEFT: {
      label: 'Выравнить левую ноду',
      icon: <ArrowLeftRightIcon />,
      disabled: isChangeStatusPending || !isFinal(revisionStatus),
      onClick: createConfirmableHandler(
        () =>
          changeStatus({
            shardId,
            revisionId: id,
            job: RevisionJobDto.Syncl,
          }),
        'Выравнивание левой ноды',
        'Применить выравнивание к левой ноде?'
      ),
    },
    ALIGN_RIGHT: {
      label: 'Выравнить правую ноду',
      icon: <ArrowLeftRightIcon />,
      disabled: isChangeStatusPending || !isFinal(revisionStatus),
      onClick: createConfirmableHandler(
        () =>
          changeStatus({
            shardId,
            revisionId: id,
            job: RevisionJobDto.Syncr,
          }),
        'Выравнивание правой ноды',
        'Применить выравнивание к правой ноде?'
      ),
    },
    DETAILS: {
      label: 'Детализация',
      icon: <ListIcon />,
      onClick: () => detailsAction && detailsAction(context),
    },
    DOWNLOAD: {
      label: 'Скачать отчет',
      icon: <DownloadIcon />,
      disabled: isReportPending || status !== RevisionStatusDto.NotMatched,
      onClick: createConfirmableHandler(
        () =>
          loadReport({ revisionId: id, shardId, statusTime: updated, table }),
        'Скачать отчет',
        'Загрузить отчет о несовпадениях?'
      ),
    },
    RECHECK: {
      label: 'Перепроверить',
      icon: <RotateCcwIcon />,
      disabled:
        isChangeStatusPending || !isFinal(revisionStatus) || !rowsDiffSaved,
      onClick: createConfirmableHandler(
        () =>
          changeStatus({
            shardId,
            revisionId: id,
            updatedStatus: RevisionStatusDto.Rechecking,
            job: RevisionJobDto.Recheck,
          }),
        'Перепроверить',
        'Начать повторную проверку данных?'
      ),
    },
    STOP: {
      label: 'Остановить',
      icon: <StopCircleIcon />,
      disabled: isChangeStatusPending || isFinal(revisionStatus),
      onClick: createConfirmableHandler(
        () =>
          changeStatus({
            shardId,
            revisionId: id,
            updatedStatus: RevisionStatusDto.Aborted,
            job: RevisionJobDto.None,
          }),
        'Остановить процесс',
        'Остановить текущий процесс?'
      ),
    },
  }
}
