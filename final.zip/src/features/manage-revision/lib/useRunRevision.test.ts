import { act, renderHook } from '@testing-library/react'

import { useRunRevision } from './useRunRevision'

const mocks = vi.hoisted(() => ({ config: null as Record<string, any> | null, fetch: vi.fn(), invalidate: vi.fn() }))
vi.mock('@tanstack/react-query', () => ({
  useQueryClient: () => ({ invalidateQueries: mocks.invalidate }),
  useMutation: (config: Record<string, any>) => {
    mocks.config = config
    return { mutate: (value: unknown) => config.mutationFn(value) }
  },
}))
vi.mock('uuid', () => ({ v4: () => 'uuid-1' }))
vi.mock('@/features/manage-revision/api', () => ({
  fetchRunRevision: (...args: unknown[]) => mocks.fetch(...args),
}))

it.each([
  [undefined, undefined],
  ['', undefined],
  ['1', undefined],
  ['1/4', 4],
])('useRunRevision преобразует долю %s', (share, expected) => {
  const { result } = renderHook(() => useRunRevision({ queryKey: ['revisions'] }))
  act(() => result.current.mutate({ shardIds: ['a'], share }))
  expect(mocks.fetch).toHaveBeenLastCalledWith(['a'], 'uuid-1', expected)
  mocks.config?.onSuccess()
  expect(mocks.invalidate).toHaveBeenCalledWith({ queryKey: ['revisions'] })
})
