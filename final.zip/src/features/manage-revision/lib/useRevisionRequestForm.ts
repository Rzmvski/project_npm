import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'

import {
  revisionRequestSchema,
  type RevisionRequestSchemaType,
} from '@/entities/revision-request'

const defaultValues: RevisionRequestSchemaType = {
  shardIds: [],
  share: '1',
}

export const useRevisionRequestForm = () => {
  return useForm({
    resolver: zodResolver(revisionRequestSchema),
    defaultValues,
  })
}
