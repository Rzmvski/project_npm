import { type QueryKey, useMutation, useQueryClient } from '@tanstack/react-query'
import { v4 as generateUuid } from 'uuid'

import { fetchRunRevision } from '@/features/manage-revision/api'

type RunRevisionMutationParams = {
  shardIds: string[]
  share?: string
}

interface UseRunRevisionParams {
  queryKey: QueryKey
}

export const useRunRevision = ({ queryKey }: UseRunRevisionParams) => {
  const client = useQueryClient()
  return useMutation({
    mutationFn: ({ shardIds, share }: RunRevisionMutationParams) => {
      const uuid = generateUuid()
      const part = processShare(share)
      return fetchRunRevision(shardIds, uuid, part)
    },
    onSuccess: () => {
      return client.invalidateQueries({ queryKey })
    },
  })
}

const processShare = (reviseShare?: string) => {
  if (!reviseShare || reviseShare.length === 1) return undefined
  return reviseShare.split('/').map((p) => Number.parseInt(p))[1]
}
