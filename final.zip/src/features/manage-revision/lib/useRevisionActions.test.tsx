import {
  RevisionJobDto,
  RevisionJobStatusDto,
  RevisionStatusDto,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { renderHook } from '@testing-library/react'

import { RevisionActions } from '@/entities/revision'

import { useRevisionActions } from './useRevisionActions'

const mocks = vi.hoisted(() => ({
  changeStatus: vi.fn(),
  loadReport: vi.fn(),
  confirm: vi.fn().mockResolvedValue(true),
  changePending: false,
  reportPending: false,
}))

vi.mock('@/features/manage-revision', () => ({
  useRevisionStatusMutation: () => ({
    mutate: mocks.changeStatus,
    isPending: mocks.changePending,
  }),
}))

vi.mock('@/entities/revision-report', () => ({
  useLoadRevisionReport: () => ({
    mutate: mocks.loadReport,
    isPending: mocks.reportPending,
  }),
}))

vi.mock('@/shared/lib', async () => {
  const actual = await vi.importActual<object>('@/shared/lib')
  return { ...actual, useConfirm: () => mocks.confirm }
})

const context = {
  shardId: 'shard-1',
  id: 42,
  status: RevisionStatusDto.NotMatched,
  updated: new Date('2026-08-13'),
  rowsDiffSaved: 5,
}

describe('useRevisionActions', () => {
  beforeEach(() => {
    mocks.changeStatus.mockClear()
    mocks.loadReport.mockClear()
    mocks.confirm.mockReset().mockResolvedValue(true)
    mocks.changePending = false
    mocks.reportPending = false
  })

  it('требует id и status', () => {
    expect(() =>
      renderHook(() =>
        useRevisionActions({ ...context, id: undefined } as never),
      ),
    ).toThrow('revision id and status should be provided')
    expect(() =>
      renderHook(() =>
        useRevisionActions({ ...context, status: undefined } as never),
      ),
    ).toThrow('revision id and status should be provided')
  })

  it('использует jobStatus с приоритетом для доступности действий', () => {
    const { result } = renderHook(() =>
      useRevisionActions({
        ...context,
        status: RevisionStatusDto.Working,
        jobStatus: RevisionJobStatusDto.Completed,
      }),
    )

    expect(result.current[RevisionActions.RUN].disabled).toBeFalsy()
    expect(result.current[RevisionActions.STOP].disabled).toBe(true)
  })

  it('открывает детализацию с исходным контекстом', () => {
    const detailsAction = vi.fn()
    const { result } = renderHook(() =>
      useRevisionActions({ ...context, detailsAction }),
    )

    result.current[RevisionActions.DETAILS].onClick()

    expect(detailsAction).toHaveBeenCalledWith(context)
  })

  it.each([
    [RevisionActions.RUN, RevisionJobDto.Revise, undefined],
    [RevisionActions.ALIGN_LEFT, RevisionJobDto.Syncl, undefined],
    [RevisionActions.ALIGN_RIGHT, RevisionJobDto.Syncr, undefined],
    [RevisionActions.RECHECK, RevisionJobDto.Recheck, RevisionStatusDto.Rechecking],
    [RevisionActions.STOP, RevisionJobDto.None, RevisionStatusDto.Aborted],
  ])('подтверждает и запускает действие %s', async (type, job, updatedStatus) => {
    const actionContext =
      type === RevisionActions.STOP
        ? { ...context, status: RevisionStatusDto.Working }
        : context
    const { result } = renderHook(() => useRevisionActions(actionContext))

    await result.current[type].onClick()

    expect(mocks.confirm).toHaveBeenCalledOnce()
    expect(mocks.changeStatus).toHaveBeenCalledWith({
      shardId: 'shard-1',
      revisionId: 42,
      job,
      ...(updatedStatus ? { updatedStatus } : {}),
    })
  })

  it('не запускает действие после отказа', async () => {
    mocks.confirm.mockResolvedValue(false)
    const { result } = renderHook(() => useRevisionActions(context))

    await result.current[RevisionActions.RUN].onClick()

    expect(mocks.changeStatus).not.toHaveBeenCalled()
  })

  it('скачивает отчёт с полным контекстом', async () => {
    const { result } = renderHook(() =>
      useRevisionActions({ ...context, table: 'accounts' }),
    )

    await result.current[RevisionActions.DOWNLOAD].onClick()

    expect(mocks.loadReport).toHaveBeenCalledWith({
      revisionId: 42,
      shardId: 'shard-1',
      statusTime: context.updated,
      table: 'accounts',
    })
  })

  it('вычисляет disabled из статуса, прогресса и данных', () => {
    mocks.changePending = true
    mocks.reportPending = true
    const { result } = renderHook(() =>
      useRevisionActions({
        ...context,
        cursorFinished: true,
        rowsDiffSaved: 0,
      }),
    )

    expect(result.current[RevisionActions.RUN].disabled).toBe(true)
    expect(result.current[RevisionActions.ALIGN_LEFT].disabled).toBe(true)
    expect(result.current[RevisionActions.ALIGN_RIGHT].disabled).toBe(true)
    expect(result.current[RevisionActions.RECHECK].disabled).toBe(true)
    expect(result.current[RevisionActions.DOWNLOAD].disabled).toBe(true)
  })
})
