import { describe, it, expect } from 'vitest'

import { odHistoryFilterSchema } from '@/features/od-history/model/schema'

describe('odHistoryFilterSchema', () => {
  it('should validate correct period', () => {
    const result = odHistoryFilterSchema.safeParse({
      period: [new Date('2024-01-01'), new Date('2024-01-31')],
    })

    expect(result.success).toBe(true)
    if (result.success) {
      expect(result.data.period).toHaveLength(2)
    }
  })

  it('should fail for invalid period', () => {
    const result = odHistoryFilterSchema.safeParse({
      period: [new Date('2024-01-01')],
    })

    expect(result.success).toBe(false)
  })
})
