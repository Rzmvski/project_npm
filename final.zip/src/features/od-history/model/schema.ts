import z from 'zod'

const dateSchema = z.date().nullable().pipe(z.date())

export const odHistoryFilterSchema = z.object({
  period: z.tuple([dateSchema, dateSchema]),
})

export type OdHistoryFilterInputValues = z.input<typeof odHistoryFilterSchema>

export type OdHistoryFilterOutputValues = z.output<typeof odHistoryFilterSchema>
