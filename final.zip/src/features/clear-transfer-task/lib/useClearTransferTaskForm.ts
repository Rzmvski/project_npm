import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'

import { clearTaskSchema, type ClearTaskInputValues } from '@/entities/clear-task'

const defaultValues: ClearTaskInputValues = {
  attempt: false,
  threadsAmount: 10,
  taskLimit: '',
  shardIds: [],
  clearDate: new Date(),
}

export const useClearTransferTaskForm = () => {
  return useForm({
    defaultValues,
    resolver: zodResolver(clearTaskSchema),
  })
}
