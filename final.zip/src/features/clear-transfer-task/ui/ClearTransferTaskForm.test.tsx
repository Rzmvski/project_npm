import { screen, waitFor } from '@testing-library/react'

import { ClearTransferTaskFormTestModel } from './ClearTransferTaskForm.test-model'

const clearDate = new Date('2026-08-12')
const mocks = vi.hoisted(() => ({
  setValue: vi.fn(),
  fetch: vi.fn(),
  isSubmitting: false,
  attempt: false,
}))

vi.mock('react-hook-form', () => ({
  useFormContext: () => ({
    control: {},
    watch: (name: string) => (name === 'clearDate' ? clearDate : mocks.attempt),
    setValue: mocks.setValue,
    formState: { isSubmitting: mocks.isSubmitting },
    getFieldState: () => ({ invalid: false }),
  }),
  Controller: ({ name, render }: Record<string, any>) =>
    render({
      field: {
        name,
        value: name === 'clearDate' ? clearDate : name === 'attempt' ? mocks.attempt : '8',
        onChange: vi.fn(),
      },
      fieldState: { invalid: false },
    }),
}))
vi.mock('@tanstack/react-query', () => ({
  useQuery: (config: Record<string, any>) => {
    config.queryFn()
    return { data: [{ shard: { id: 11 } }], isLoading: false }
  },
}))
vi.mock('@/entities/clear-task', () => ({
  fetchClearTasks: (date: Date) => mocks.fetch(date),
}))
vi.mock('@/shared/lib', () => ({
  TODAY: new Date('2026-08-13'),
  useTaskColumns: (attempt: boolean) => [{ header: `Докат: ${attempt}` }],
  useRowSelection: ({ getRowId }: Record<string, any>) => {
    expect(getRowId({ shard: { id: 11 } })).toBe('11')
    return { plugin: { name: 'selection' }, selectedIds: ['11'] }
  },
}))
vi.mock('@/shared/ui/Table', () => ({
  Table: ({ data, columns, disabled, loading }: Record<string, any>) => (
    <div>
      <span>{`${data.length} задача; ${columns[0].header}`}</span>
      <span>{disabled ? 'Таблица заблокирована' : 'Таблица доступна'}</span>
      <span>{loading ? 'Загрузка' : 'Загружено'}</span>
    </div>
  ),
}))
vi.mock('@/shared/ui/Button', () => ({
  Button: ({ type = 'button', ...props }: React.ButtonHTMLAttributes<HTMLButtonElement>) => (
    <button type={type} {...props} />
  ),
}))
vi.mock('@/shared/ui/DatePicker', () => ({
  DatePicker: ({ label, value, maxDate, disabled }: Record<string, any>) => (
    <span>{`${label}: ${value.toISOString()}; max ${maxDate.toISOString()}; ${
      disabled ? 'заблокирована' : 'доступна'
    }`}</span>
  ),
}))
vi.mock('@v-uik/base', () => ({
  Underlay: ({ children }: React.PropsWithChildren) => <section>{children}</section>,
  Input: ({ label, disabled, value }: Record<string, any>) => (
    <input aria-label={label} disabled={disabled} value={value} readOnly />
  ),
  Switch: () => <input type='checkbox' readOnly />,
  LabelControl: ({ label, checked, disabled }: Record<string, any>) => (
    <span>{`${label}: ${checked}; ${disabled ? 'заблокирован' : 'доступен'}`}</span>
  ),
}))

describe('ClearTransferTaskForm', () => {
  beforeEach(() => {
    mocks.isSubmitting = false
    mocks.attempt = false
  })

  it('загружает задания на выбранную дату и синхронизирует шарды', async () => {
    ClearTransferTaskFormTestModel.render()
    expect(screen.getByText(/Очистить до даты.*2026-08-12/)).toBeVisible()
    expect(screen.getByText('1 задача; Докат: false')).toBeVisible()
    expect(mocks.fetch).toHaveBeenCalledWith(clearDate)
    await waitFor(() => expect(mocks.setValue).toHaveBeenCalledWith('shardIds', ['11']))
  })

  it('отправляет форму без активного процесса', async () => {
    const model = ClearTransferTaskFormTestModel.render()
    await model.click('Выполнить')
    expect(model.onSubmit).toHaveBeenCalledOnce()
  })

  it('блокирует изменение при активном процессе и позволяет его остановить', async () => {
    const model = ClearTransferTaskFormTestModel.render(true)
    expect(screen.getByText('Таблица заблокирована')).toBeVisible()
    await model.click('Остановить')
    expect(model.onCancel).toHaveBeenCalledOnce()
  })

  it('блокирует остановку, пока запрос уже выполняется', () => {
    ClearTransferTaskFormTestModel.render(true, true)
    expect(screen.getByRole('button', { name: 'Остановить' })).toBeDisabled()
  })
})
