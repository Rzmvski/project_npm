import { type ClientTransferStatusDto } from '@sber-pprb-tkp/tcpf-support-admin-api'
import { useQuery } from '@tanstack/react-query'
import { Input, LabelControl, Switch, Underlay } from '@v-uik/base'
import classNames from 'classnames'
import React, { type FC, useEffect } from 'react'
import { Controller, useFormContext } from 'react-hook-form'

import { type ClearTaskInputValues, fetchClearTasks } from '@/entities/clear-task'
import { TODAY, useTaskColumns , useRowSelection } from '@/shared/lib'
import { Button } from '@/shared/ui/Button'
import { DatePicker } from '@/shared/ui/DatePicker'
import { Table } from '@/shared/ui/Table'


import styles from './ClearTransferTaskForm.module.scss'



interface ClearTransferTaskFormProps {
  onSubmit: () => void
  onCancel: () => void
  hasActiveProcesses: boolean
  isStopPending: boolean
}

export const ClearTransferTaskForm: FC<ClearTransferTaskFormProps> = ({
  onSubmit,
  onCancel,
  hasActiveProcesses,
  isStopPending,
}) => {
  const { control, watch, setValue, formState, getFieldState } =
    useFormContext<ClearTaskInputValues>()
  const { isSubmitting } = formState
  const clearDate = watch('clearDate')

  const { data, isLoading } = useQuery({
    queryKey: ['clearTransfer', clearDate],
    queryFn: () => {
      return fetchClearTasks(clearDate)
    },
  })

  const columns = useTaskColumns(watch('attempt'))

  const { plugin: selectionPlugin, selectedIds } =
    useRowSelection<ClientTransferStatusDto>({
      getRowId: ({ shard }) => shard.id.toString(),
    })

  useEffect(() => {
    setValue('shardIds', selectedIds)
  }, [selectedIds])

  return (
    <form className={styles.container} onSubmit={onSubmit}>
      <Underlay
        className={classNames(styles.section, styles.leftSection)}
        classes={{ content: styles.sectionContent }}
      >
        <div>
          <Controller
            name={'threadsAmount'}
            control={control}
            render={({ field, fieldState: { invalid } }) => (
              <Input
                label={'Количество потоков на один шард'}
                error={invalid}
                disabled={isSubmitting || hasActiveProcesses}
                showErrorIcon={false}
                {...field}
              />
            )}
          />
          <Controller
            name={'taskLimit'}
            control={control}
            render={({ field, fieldState: { invalid } }) => (
              <Input
                label={'Лимит заданий на поток'}
                error={invalid}
                disabled={isSubmitting || hasActiveProcesses}
                showErrorIcon={false}
                {...field}
              />
            )}
          />
          <Controller
            name={'clearDate'}
            control={control}
            render={({
              field: { value, onChange },
              fieldState: { invalid },
            }) => (
              <DatePicker
                label={'Очистить до даты (включительно)'}
                error={invalid}
                maxDate={TODAY}
                disabled={isSubmitting || hasActiveProcesses}
                value={value}
                onChange={onChange}
              />
            )}
          />
        </div>
        <div className={styles.sectionFooter}>
          <Button
            kind={'outlined'}
            type={'submit'}
            disabled={isSubmitting || hasActiveProcesses}
          >
            {'Выполнить'}
          </Button>
          <Button
            kind={'outlined'}
            color={'secondary'}
            onClick={onCancel}
            disabled={!hasActiveProcesses || isStopPending}
          >
            {'Остановить'}
          </Button>
        </div>
      </Underlay>
      <Underlay
        className={classNames(styles.section, styles.rightSection)}
        classes={{ content: styles.sectionContent }}
      >
        <Table
          data={data ?? []}
          columns={columns}
          disabled={isSubmitting || hasActiveProcesses}
          invalid={getFieldState('shardIds', formState).invalid}
          loading={isLoading}
          plugins={[selectionPlugin]}
        />
        <div className={styles.sectionFooter}>
          <Controller
            name={'attempt'}
            control={control}
            render={({ field: { value, ...field } }) => (
              <LabelControl
                label={'Докат'}
                control={<Switch />}
                checked={value}
                size={'sm'}
                disabled={isSubmitting || hasActiveProcesses}
                {...field}
              />
            )}
          />
        </div>
      </Underlay>
    </form>
  )
}
