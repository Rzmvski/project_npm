import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'

import { ClearTransferTaskForm } from './ClearTransferTaskForm'

export class ClearTransferTaskFormTestModel {
  readonly onSubmit = vi.fn(function (...args: unknown[]) {
    const event = args[0] as Event | undefined
    event?.preventDefault()
  })
  readonly onCancel = vi.fn()

  private constructor(hasActiveProcesses: boolean, isStopPending: boolean) {
    render(
      <ClearTransferTaskForm
        onSubmit={this.onSubmit}
        onCancel={this.onCancel}
        hasActiveProcesses={hasActiveProcesses}
        isStopPending={isStopPending}
      />,
    )
  }

  static render(hasActiveProcesses = false, isStopPending = false) {
    return new ClearTransferTaskFormTestModel(hasActiveProcesses, isStopPending)
  }

  async click(name: string) {
    await userEvent.click(screen.getByRole('button', { name }))
  }
}
