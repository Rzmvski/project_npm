import { type ProcessDtoDto } from '@sber-pprb-tkp/tcpf-support-admin-api'

import { type ClearTaskOutputValues } from '@/entities/clear-task'
import { clientTransferService } from '@/shared/api'

export const fetchClearing = ({
  attempt,
  ...transferRequest
}: ClearTaskOutputValues): Promise<ProcessDtoDto> => {
  return clientTransferService.clear({
    ...transferRequest,
    repeat: attempt,
  })
}
