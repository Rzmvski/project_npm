import { fetchClearing } from './fetch'

const clear = vi.hoisted(() => vi.fn())
vi.mock('@/shared/api', () => ({ clientTransferService: { clear } }))

it('fetchClearing преобразует attempt в repeat', () => {
  fetchClearing({ attempt: true, taskId: 42 } as never)
  expect(clear).toHaveBeenCalledWith({ taskId: 42, repeat: true })
})
