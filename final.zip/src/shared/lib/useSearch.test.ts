import { renderHook, act } from '@testing-library/react'
import { describe, it, expect, vi } from 'vitest'

import { useSearch } from './collections/useSearch'

describe('useSearch', () => {
  const items = [
    { id: 1, name: 'Apple' },
    { id: 2, name: 'Banana' },
    { id: 3, name: 'Cherry' },
    { id: 4, name: 'apricot' },
  ]

  const searchByName = (data: typeof items, query: string) =>
    data.filter((item) => item.name.toLowerCase().includes(query))

  it('should return all items when searchQuery is empty', () => {
    const { result } = renderHook(() => useSearch({ items, searchFn: searchByName }))

    expect(result.current.result).toEqual(items)
    expect(result.current.searchQuery).toBe('')
    expect(result.current.isSearching).toBe(false)
  })

  it('should update searchQuery via setSearchQuery', () => {
    const { result } = renderHook(() => useSearch({ items, searchFn: searchByName }))

    act(() => {
      result.current.setSearchQuery('banana')
    })

    expect(result.current.searchQuery).toBe('banana')
  })

  it('should filter items based on search query (case-insensitive)', () => {
    const { result } = renderHook(() => useSearch({ items, searchFn: searchByName }))

    act(() => {
      result.current.setSearchQuery('apricot')
    })

    expect(result.current.result).toEqual([{ id: 4, name: 'apricot' }])
  })

  it('should return empty array when no items match', () => {
    const { result } = renderHook(() => useSearch({ items, searchFn: searchByName }))

    act(() => {
      result.current.setSearchQuery('xyz')
    })

    expect(result.current.result).toEqual([])
  })

  it('should call searchFn with lowercased query', () => {
    const searchFn = vi.fn().mockReturnValue([])

    const { result } = renderHook(() => useSearch({ items, searchFn }))

    act(() => {
      result.current.setSearchQuery('Hello')
    })

    expect(searchFn).toHaveBeenCalledWith(items, 'hello')
  })

  it('should have isSearching as false initially and after state settles', () => {
    const { result } = renderHook(() => useSearch({ items, searchFn: searchByName }))

    expect(result.current.isSearching).toBe(false)

    act(() => {
      result.current.setSearchQuery('apple')
    })

    expect(result.current.searchQuery).toBe('apple')
  })
})
