import { describe, it, expect } from 'vitest'

import { humanize, formatDate, TODAY } from './datetime/date'

describe('TODAY', () => {
  it('should be a Date instance', () => {
    expect(TODAY).toBeInstanceOf(Date)
  })
})

describe('humanize', () => {
  it('should return null if startTime is not provided', () => {
    expect(humanize(undefined, new Date())).toBeNull()
  })

  it('should return null if endTime is not provided', () => {
    expect(humanize(new Date(), undefined)).toBeNull()
  })

  it('should return null if both arguments are missing', () => {
    expect(humanize(undefined, undefined)).toBeNull()
  })

  it('should return null if both arguments are null', () => {
    expect(humanize(null, null)).toBeNull()
  })

  it('should return a formatted distance between two dates', () => {
    const start = new Date(2023, 0, 1)
    const end = new Date(2023, 0, 15)

    const result = humanize(start, end)

    expect(result).toBeTruthy()
    expect(typeof result).toBe('string')
  })

  it('should return "less than a minute" for very close dates', () => {
    const start = new Date(2023, 0, 1, 12, 0, 0)
    const end = new Date(2023, 0, 1, 12, 0, 5)

    const result = humanize(start, end)

    expect(result).toBeTruthy()
  })
})

describe('formatDate', () => {
  it('should return null if date is not provided', () => {
    expect(formatDate(undefined)).toBeNull()
  })

  it('should return null if date is null', () => {
    expect(formatDate(null)).toBeNull()
  })

  it('should format date with default format string (dd.MM.yyyy)', () => {
    const date = new Date(2023, 0, 15)

    const result = formatDate(date)

    expect(result).toBe('15.01.2023')
  })

  it('should format date with custom format string', () => {
    const date = new Date(2023, 0, 15)

    const result = formatDate(date, 'yyyy-MM-dd')

    expect(result).toBe('2023-01-15')
  })

  it('should format date with HH:mm format', () => {
    const date = new Date(2023, 0, 15, 10, 30)

    const result = formatDate(date, 'HH:mm')

    expect(result).toBe('10:30')
  })

  it('should throw RangeError for an invalid date', () => {
    expect(() => formatDate(new Date('invalid'))).toThrow(RangeError)
  })
})
