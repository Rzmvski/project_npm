import { renderHook } from '@testing-library/react'
import React from 'react'
import { describe, it, expect } from 'vitest'

import { TabContext } from '@/shared/ui/ServiceTabs'

import { useTab } from './react/useTab'

describe('useTab', () => {
  it('should throw error when used outside TabProvider', () => {
    expect(() => {
      renderHook(() => useTab())
    }).toThrow('useTab must be used inside TabProvider')
  })

  it('should return activeTab from context', () => {
    const wrapper = ({ children }: { children: React.ReactNode }) => (
      <TabContext.Provider value={{ activeTab: 'test-tab' }}>{children}</TabContext.Provider>
    )

    const { result } = renderHook(() => useTab(), { wrapper })

    expect(result.current).toEqual({ activeTab: 'test-tab' })
  })

  it('should return activeTab when it changes', () => {
    const wrapper = ({ children }: { children: React.ReactNode }) => (
      <TabContext.Provider value={{ activeTab: 'second-tab' }}>{children}</TabContext.Provider>
    )

    const { result } = renderHook(() => useTab(), { wrapper })

    expect(result.current.activeTab).toBe('second-tab')
  })
})
