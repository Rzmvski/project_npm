import { render, renderHook, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import React from 'react'
import { describe, it, expect, vi } from 'vitest'

import { useConfirm } from './modal/useConfirm'

vi.mock('@v-uik/base', () => ({
  generateId: vi.fn(() => 'test-modal-id'),
  modal: {
    show: vi.fn(),
    close: vi.fn(),
  },
  ModalBody: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
  ModalHeader: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
  ModalFooter: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
  Checkbox: () => null,
  LabelControl: ({
    checked,
    label,
    onChange,
  }: {
    checked: boolean
    label: React.ReactNode
    onChange: (event: React.ChangeEvent<HTMLInputElement>) => void
  }) => (
    <label>
      <input type='checkbox' checked={checked} onChange={onChange} />
      {label}
    </label>
  ),
}))

vi.mock('@/shared/ui/Button', () => ({
  Button: ({
    children,
    onClick,
    disabled,
  }: {
    children: React.ReactNode
    onClick?: () => void
    disabled?: boolean
    kind?: string
    color?: string
  }) => (
    <button disabled={disabled} onClick={onClick}>
      {children}
    </button>
  ),
}))

vi.mock('@v-uik/combo-box/dist/esm/components', () => ({}))
vi.mock('@v-uik/combo-box/dist/esm/config', () => ({}))

describe('useConfirm', () => {
  it('should return a function', () => {
    const { result } = renderHook(() => useConfirm())
    expect(typeof result.current).toBe('function')
  })

  it('should call modal.show with correct parameters', async () => {
    const { result } = renderHook(() => useConfirm())
    const { modal } = await import('@v-uik/base')

    result.current({
      title: 'Test Title',
      text: 'Test Text',
    })

    expect(modal.show).toHaveBeenCalled()

    const [[id]] = (modal.show as any as ReturnType<typeof vi.fn>).mock.calls

    expect(id).toBe('test-modal-id')
  })

  it('требует отметить чекбокс перед подтверждением', async () => {
    const { result } = renderHook(() => useConfirm())
    const { modal } = await import('@v-uik/base')
    const confirmation = result.current({
      title: 'Изменение нагрузки',
      text: 'Проверьте параметры',
      confirmationLabel: 'Я понимаю последствия',
      confirmText: 'Применить изменения',
    })
    const call = (modal.show as any as ReturnType<typeof vi.fn>).mock.calls.at(-1)
    expect(call).toBeDefined()
    const [, options] = call!

    render(options.content)
    const submit = screen.getByRole('button', { name: 'Применить изменения' })
    expect(submit).toBeDisabled()

    await userEvent.click(screen.getByRole('checkbox'))
    expect(submit).toBeEnabled()

    await userEvent.click(submit)
    await expect(confirmation).resolves.toBe(true)
  })
})
