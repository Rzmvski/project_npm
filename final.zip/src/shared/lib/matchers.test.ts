import { describe, it, expect } from 'vitest'

import { createObjectMatcher } from './collections/matchers'

describe('createObjectMatcher', () => {
  describe('caseSensitive: false, deep: false', () => {
    const matcher = createObjectMatcher({
      caseSensitive: false,
      deep: false,
    })

    it('should return true for empty query', () => {
      expect(matcher({ a: 'hello' }, '')).toBe(true)
    })

    it('should return true for whitespace-only query', () => {
      expect(matcher({ a: 'hello' }, '   ')).toBe(true)
    })

    it('should match string values case-insensitively', () => {
      expect(matcher({ a: 'Hello World' }, 'hello')).toBe(true)
      expect(matcher({ a: 'Hello World' }, 'HELLO')).toBe(true)
    })

    it('should match when value is in the middle of a string', () => {
      expect(matcher({ a: 'Hello World' }, 'lo w')).toBe(true)
    })

    it('should not match when value is absent', () => {
      expect(matcher({ a: 'Cat' }, 'Dog')).toBe(false)
    })

    it('should not match when query is not a substring', () => {
      expect(matcher({ a: 'Hello' }, 'xyz')).toBe(false)
    })
  })

  describe('caseSensitive: true, deep: false', () => {
    const matcher = createObjectMatcher({
      caseSensitive: true,
      deep: false,
    })

    it('should match case-sensitively', () => {
      expect(matcher({ a: 'Hello World' }, 'Hello')).toBe(true)
      expect(matcher({ a: 'Hello World' }, 'hello')).toBe(false)
    })
  })

  describe('fields', () => {
    const matcher = createObjectMatcher({
      caseSensitive: false,
      deep: false,
      fields: ['name', 'description'] as Array<
        keyof { name: string; description: string; extra: string }
      >,
    })

    it('should only search within specified fields', () => {
      const obj = { name: 'John', description: 'Developer', extra: 'Hidden' }
      expect(matcher(obj, 'john')).toBe(true)
      expect(matcher(obj, 'dev')).toBe(true)
      expect(matcher(obj, 'hidden')).toBe(false)
    })
  })

  describe('deep: true with nested objects', () => {
    const matcher = createObjectMatcher({
      caseSensitive: false,
      deep: true,
    })

    it('should search deep into nested objects', () => {
      const obj = {
        user: { name: 'John', role: 'Admin' },
        active: true,
      }
      expect(matcher(obj, 'john')).toBe(true)
      expect(matcher(obj, 'admin')).toBe(true)
    })

    it('should not match if no nested value matches', () => {
      const obj = {
        user: { name: 'Jane', role: 'User' },
        active: false,
      }
      expect(matcher(obj, 'admin')).toBe(false)
    })
  })

  describe('deep: false with nested objects', () => {
    const matcher = createObjectMatcher({
      caseSensitive: false,
      deep: false,
    })

    it('should not search into nested objects', () => {
      const obj = {
        user: { name: 'John' },
      }

      expect(matcher(obj, 'john')).toBe(false)
    })
  })

  describe('number values', () => {
    const matcher = createObjectMatcher({
      caseSensitive: false,
      deep: false,
    })

    it('should match numeric values as strings', () => {
      expect(matcher({ a: 12345 }, '123')).toBe(true)
      expect(matcher({ a: 12345 }, '234')).toBe(true)
    })

    it('should not match non-matching numeric substrings', () => {
      expect(matcher({ a: 12345 }, '678')).toBe(false)
    })
  })

  describe('null values', () => {
    const matcher = createObjectMatcher({
      caseSensitive: false,
      deep: false,
    })

    it('should return false for null values', () => {
      expect(matcher({ a: null }, 'test')).toBe(false)
    })
  })
})
