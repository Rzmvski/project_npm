import { renderHook, render } from '@testing-library/react'
import React from 'react'
import { describe, it, expect, vi } from 'vitest'

import { useTaskColumns } from './task/useTaskColumns'

vi.mock('@v-uik/base', () => ({
  createUseStyles: () => () => ({
    activeColumn: 'active-column-mock',
    inactiveColumn: 'inactive-column-mock',
  }),
}))

describe('useTaskColumns', () => {
  it('should return 3 column definitions', () => {
    const { result } = renderHook(() => useTaskColumns(false))

    expect(result.current).toHaveLength(3)
  })

  it('should have correct headers', () => {
    const { result } = renderHook(() => useTaskColumns(false))

    expect(result.current[0].header).toBe('Шарды')
    expect(result.current[1].header).toBe('Кол-во новых заданий по клиентам')
    expect(result.current[2].header).toBe('Количество заданий по докату клиентов')
  })

  it('should format shard as "id - name" via accessorFn', () => {
    const { result } = renderHook(() => useTaskColumns(false))

    const shardFn = (
      result.current[0] as unknown as { accessorFn: (row: any) => string }
    ).accessorFn
    const output = shardFn({ shard: { id: 5, name: 'TestShard' } })

    expect(output).toBe('5 - TestShard')
  })

  it('should use accessorKey "taskAmount" for second column', () => {
    const { result } = renderHook(() => useTaskColumns(false))

    expect(result.current[1]).toHaveProperty('accessorKey', 'taskAmount')
  })

  it('should render taskAmount cell value', () => {
    const { result } = renderHook(() => useTaskColumns(false))

    const cellRenderer = result.current[1].cell as (info: {
      getValue: () => string
    }) => React.ReactNode

    const rendered = cellRenderer({ getValue: () => '42' })
    const { container } = render(<>{rendered}</>)
    expect(container.textContent).toBe('42')
  })

  it('should render attemptTaskAmount cell value', () => {
    const { result } = renderHook(() => useTaskColumns(false))

    const cellRenderer = result.current[2].cell as (info: {
      getValue: () => string
    }) => React.ReactNode

    const rendered = cellRenderer({ getValue: () => '10' })
    const { container } = render(<>{rendered}</>)
    expect(container.textContent).toBe('10')
  })

  it('should memoize columns when isAttemptActive does not change', () => {
    const { result, rerender } = renderHook(
      ({ isAttemptActive }: { isAttemptActive: boolean }) => useTaskColumns(isAttemptActive),
      { initialProps: { isAttemptActive: false } },
    )

    const firstRender = result.current

    rerender({ isAttemptActive: false })

    expect(result.current).toBe(firstRender)
  })
})
