import { renderHook } from '@testing-library/react'
import { describe, it, expect } from 'vitest'

import { useTree } from './collections/useTree'

describe('useTree', () => {
  type Item = { id: string; path: string; name: string }
  const items: Item[] = [
    { id: 'a', path: 'root/child1', name: 'Child1' },
    { id: 'b', path: 'root/child2', name: 'Child2' },
    { id: 'c', path: 'root/child1/grandchild', name: 'GrandChild' },
  ]

  it('should build a tree from flat array with nested keys', () => {
    const { result } = renderHook(() =>
      useTree<Item>({
        targetArray: items,
        nodeCreator: (item) => ({
          key: item.id,
          label: item.name,
        }),
        keySelector: (item) => item.path,
        idSelector: (item) => item.id,
      }),
    )

    expect(result.current).toBeInstanceOf(Array)
    expect(result.current).toHaveLength(1)

    const root = result.current[0]
    expect(root.label).toBe('root')
    expect(root.key).toBe('root')
    expect(root.children).toBeDefined()
    expect(root.children).toHaveLength(2)
  })

  it('should handle empty targetArray', () => {
    const { result } = renderHook(() =>
      useTree<Item>({
        targetArray: [],
        nodeCreator: (item) => ({
          key: item.id,
          label: item.name,
        }),
        keySelector: (item) => item.path,
        idSelector: (item) => item.id,
      }),
    )

    expect(result.current).toEqual([])
  })

  it('should preserve leaf nodes with payload', () => {
    const { result } = renderHook(() =>
      useTree<Item>({
        targetArray: items,
        nodeCreator: (item) => ({
          key: item.id,
          label: item.name,
          payload: item,
        }),
        keySelector: (item) => item.path,
        idSelector: (item) => item.id,
      }),
    )

    expect(result.current).toBeInstanceOf(Array)
    expect(result.current.length).toBeGreaterThan(0)
  })

  it('should create correct tree structure for single item', () => {
    const singleItem = [{ id: 'x', path: 'single', name: 'Single' }]

    const { result } = renderHook(() =>
      useTree<Item>({
        targetArray: singleItem,
        nodeCreator: (item) => ({
          key: item.id,
          label: item.name,
        }),
        keySelector: (item) => item.path,
        idSelector: (item) => item.id,
      }),
    )

    expect(result.current).toBeInstanceOf(Array)
    expect(result.current[0].label).toBe('single')
  })

  it('should create nested grandchildren', () => {
    const { result } = renderHook(() =>
      useTree<Item>({
        targetArray: items,
        nodeCreator: (item) => ({
          key: item.id,
          label: item.name,
        }),
        keySelector: (item) => item.path,
        idSelector: (item) => item.id,
      }),
    )

    const root = result.current[0]
    const child1 = root.children?.[0]
    expect(child1).toBeDefined()
    expect(child1!.label).toBe('child1')

    const grandchildren = child1!.children
    expect(grandchildren).toBeDefined()
    // child1 has two children: the leaf node "a" (Child1) and the grandchild branch
    expect(grandchildren).toHaveLength(2)

    const grandchildBranch = grandchildren?.find((c) => c.key === 'root/child1/grandchild')
    expect(grandchildBranch).toBeDefined()
    expect(grandchildBranch?.label).toBe('grandchild')

    const grandchildLeaf = grandchildBranch?.children?.[0]
    expect(grandchildLeaf).toBeDefined()
    expect(grandchildLeaf?.label).toBe('GrandChild')
    expect(grandchildLeaf?.key).toBe('c')
  })
})
