import { describe, it, expect } from 'vitest'

import { standardSorting } from './collections/sorting'

describe('standardSorting', () => {
  it('should return negative number when a < b for numbers', () => {
    expect(standardSorting(1, 5)).toBeLessThan(0)
  })

  it('should return negative number when a < b for strings', () => {
    expect(standardSorting('apple', 'banana')).toBeLessThan(0)
  })

  it('should return positive number when a > b for numbers', () => {
    expect(standardSorting(5, 1)).toBeGreaterThan(0)
  })

  it('should return positive number when a > b for strings', () => {
    expect(standardSorting('banana', 'apple')).toBeGreaterThan(0)
  })

  it('should work as a compare function for Array.sort (numbers)', () => {
    const numbers = [3, 1, 4, 1, 5, 9, 2, 6]

    const sorted = [...numbers].sort(standardSorting)

    expect(sorted).toEqual([1, 1, 2, 3, 4, 5, 6, 9])
  })

  it('should work as a compare function for Array.sort (strings)', () => {
    const words = ['banana', 'apple', 'cherry', 'date']

    const sorted = [...words].sort(standardSorting)

    expect(sorted).toEqual(['apple', 'banana', 'cherry', 'date'])
  })

  it('should handle equal values', () => {
    expect(standardSorting(42, 42)).toBe(-1)
  })

  it('should work with object values that support comparison', () => {
    expect(standardSorting('a', 'b')).toBeLessThan(0)
    expect(standardSorting('b', 'a')).toBeGreaterThan(0)
  })
})
