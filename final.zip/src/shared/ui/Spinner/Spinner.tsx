import { CircularProgress } from '@v-uik/base'
import { type CircularProgressProps } from '@v-uik/progress/dist/esm/CircularProgress/CircularProgress'
import React, { type FC } from 'react'

import styles from './Spinner.module.scss'

export const Spinner: FC<CircularProgressProps> = (props) => {
  return (
    <div className={styles.container} role={'status'} aria-live={'polite'}>
      <CircularProgress size={'md'} {...props} />
      <span className={styles.label}>{'Загрузка…'}</span>
    </div>
  )
}
