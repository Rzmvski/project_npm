import { render, screen } from '@testing-library/react'
import React from 'react'

import { Spinner } from './Spinner'

vi.mock('@v-uik/base', () => ({
  CircularProgress: () => <div data-testid='circular-progress' />,
}))

describe('Spinner', () => {
  it('renders without crashing', () => {
    const { container } = render(<Spinner />)
    expect(container.firstChild).toBeInTheDocument()
  })

  it('renders CircularProgress component', () => {
    render(<Spinner />)
    expect(screen.getByTestId('circular-progress')).toBeInTheDocument()
  })

  it('passes props to CircularProgress', () => {
    render(<Spinner size={16} />)
    // smoke test — component renders with additional props without error
    expect(screen.getByTestId('circular-progress')).toBeInTheDocument()
  })
})
