import { render, screen } from '@testing-library/react'
import React from 'react'

import { DatePicker } from './DatePicker'

vi.mock('@v-uik/base', () => ({
  DatePicker: ({
    inputProps,
    mask,
  }: {
    inputProps?: {
      suffix?: React.ReactNode
      showErrorIcon?: boolean
      placeholder?: string
    }
    mask?: string
  }) => (
    <div data-testid='date-picker'>
      <input data-testid='date-input' placeholder={inputProps?.placeholder} data-mask={mask} />
      {inputProps?.suffix && <div data-testid='suffix-icon' />}
    </div>
  ),
}))

describe('DatePicker', () => {
  it('renders with default placeholder', () => {
    render(<DatePicker />)

    const input = screen.getByTestId('date-input')
    expect(input).toHaveAttribute('placeholder', 'ДД.ММ.ГГГГ')
  })

  it('renders with custom placeholder', () => {
    render(<DatePicker placeholder='YYYY.MM.DD' />)

    const input = screen.getByTestId('date-input')
    expect(input).toHaveAttribute('placeholder', 'YYYY.MM.DD')
  })

  it('renders with mask attribute', () => {
    render(<DatePicker />)

    const input = screen.getByTestId('date-input')
    expect(input).toHaveAttribute('data-mask', '11.11.1111')
  })

  it('renders suffix icon', () => {
    render(<DatePicker />)

    expect(screen.getByTestId('suffix-icon')).toBeInTheDocument()
  })
})
