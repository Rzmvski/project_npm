import { DatePicker as PlatformDatePicker, type DatePickerProps } from '@v-uik/base'
import { CalendarDaysIcon } from 'lucide-react'
import React, { type FC } from 'react'

import styles from './DatePicker.module.scss'

export const DatePicker: FC<DatePickerProps> = ({
  placeholder = 'ДД.ММ.ГГГГ',
  ...props
}) => {
  return (
    <PlatformDatePicker
      inputProps={{
        suffix: <CalendarDaysIcon className={styles.suffixIcon} />,
        showErrorIcon: false,
        placeholder,
        ...props.inputProps
      }}
      classes={{
        inputRoot: styles.inputRoot,
        ...props.classes
      }}
      mask={'11.11.1111'}
      {...props}
    />
  )
}
