import { Card, Dropdown } from '@v-uik/base'
import { type DropdownProps } from '@v-uik/dropdown/dist/esm/Dropdown'
import React, { type FC } from 'react'

interface PopupProps extends DropdownProps {
  className?: string
}

export const Popup: FC<PopupProps> = ({
  children,
  className,
  content,
  ...props
}) => {
  return (
    <Dropdown
      className={className}
      content={<Card kind={'container'}>{content}</Card>}
      {...props}
    >
      {children}
    </Dropdown>
  )
}
