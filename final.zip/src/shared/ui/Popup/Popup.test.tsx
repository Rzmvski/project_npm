import { render, screen } from '@testing-library/react'
import { describe, expect, it, vi } from 'vitest'

import { Popup } from './Popup'

vi.mock('@v-uik/base', () => ({
  Card: ({ children }: React.PropsWithChildren) => <section>{children}</section>,
  Dropdown: ({ children, content }: React.PropsWithChildren<{ content: React.ReactNode }>) => (
    <div>
      <button>{children}</button>
      <div role='dialog'>{content}</div>
    </div>
  ),
}))

describe('Popup', () => {
  it('connects the trigger with popup content', () => {
    render(
      <Popup content={<p>Детали ограничения</p>}>
        <span>Показать детали</span>
      </Popup>,
    )

    expect(screen.getByRole('button', { name: 'Показать детали' })).toBeVisible()
    expect(screen.getByRole('dialog')).toHaveTextContent('Детали ограничения')
  })
})
