import { render, screen } from '@testing-library/react'
import React from 'react'

import { VirtualList } from './VirtualList'

vi.mock('@tanstack/react-virtual', () => ({
  useVirtualizer: ({ count }: { count: number; estimateSize?: () => number }) => {
    const items = Array.from({ length: count }, (_, index) => ({
      index,
      start: index * 50,
    }))

    return {
      getVirtualItems: () => items,
      getTotalSize: () => count * 50,
      measureElement: vi.fn(),
    }
  },
}))

vi.mock('@v-uik/base', () => ({
  Skeleton: ({ width, height }: { width?: string; height?: number }) => (
    <div data-testid='skeleton' style={{ width, height }} />
  ),
}))

describe('VirtualList', () => {
  const data = [
    { id: 1, text: 'Item 1' },
    { id: 2, text: 'Item 2' },
    { id: 3, text: 'Item 3' },
  ]

  it('renders all data items', () => {
    render(
      <VirtualList
        data={data}
        renderItem={(item) => <div>{item.text}</div>}
        estimateItemSize={50}
      />,
    )

    expect(screen.getByText('Item 1')).toBeInTheDocument()
    expect(screen.getByText('Item 2')).toBeInTheDocument()
    expect(screen.getByText('Item 3')).toBeInTheDocument()
  })

  it('renders skeleton items when loading', () => {
    render(
      <VirtualList
        data={data}
        renderItem={(item) => <div>{item.text}</div>}
        estimateItemSize={50}
        loading
      />,
    )

    const skeletons = screen.getAllByTestId('skeleton')
    expect(skeletons).toHaveLength(4)
  })

  it('renders custom amount of skeleton items', () => {
    render(
      <VirtualList
        data={data}
        renderItem={(item) => <div>{item.text}</div>}
        estimateItemSize={50}
        loading
        skeletonItemsAmount={2}
      />,
    )

    const skeletons = screen.getAllByTestId('skeleton')
    expect(skeletons).toHaveLength(2)
  })

  it('hides data items when loading', () => {
    render(
      <VirtualList
        data={data}
        renderItem={(item) => <div>{item.text}</div>}
        estimateItemSize={50}
        loading
      />,
    )

    expect(screen.queryByText('Item 1')).not.toBeInTheDocument()
  })

  it('renders with empty data', () => {
    render(
      <VirtualList
        data={[]}
        renderItem={(item) => <div>{(item as { text: string }).text}</div>}
        estimateItemSize={50}
      />,
    )

    // Should render but no virtual items
    const container = screen.getByText((_content, element) => {
      return (element as HTMLElement | null)?.style.overflow === 'auto'
    })
    expect(container).toBeInTheDocument()
  })
})
