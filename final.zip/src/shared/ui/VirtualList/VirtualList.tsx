import { useVirtualizer } from '@tanstack/react-virtual'
import { Skeleton } from '@v-uik/base'
import React, { type ReactNode, useMemo, useRef } from 'react'

interface VirtualListProps<TData> {
  data: TData[]
  renderItem: (item: TData) => ReactNode
  estimateItemSize: number
  skeletonItemsAmount?: number
  loading?: boolean
}

export function VirtualList<TData>({
  data,
  renderItem,
  estimateItemSize,
  loading,
  skeletonItemsAmount = 4,
}: VirtualListProps<TData>) {
  const containerRef = useRef<HTMLDivElement>(null)

  const virtualizer = useVirtualizer({
    count: data.length,
    getScrollElement: () => containerRef.current,
    measureElement: (element) => element.getBoundingClientRect().height,
    estimateSize: () => estimateItemSize,
    gap: 10,
  })

  const virtualItems = virtualizer.getVirtualItems()

  const skeletonItems = useMemo(
    () =>
      Array.from({ length: skeletonItemsAmount }, (_, index) => (
        <Skeleton key={index} width={'100%'} height={estimateItemSize} />
      )),
    []
  )

  return (
    <div ref={containerRef} style={{ overflow: 'auto', height: '100%' }}>
      {loading ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {skeletonItems}
        </div>
      ) : (
        <div
          style={{ position: 'relative', height: virtualizer.getTotalSize() }}
        >
          {virtualItems.map(({ index, start }) => {
            const item = data[index]
            return (
              <div
                key={index}
                ref={(node) => virtualizer.measureElement(node)}
                data-index={index}
                style={{
                  position: 'absolute',
                  transform: `translateY(${start}px)`,
                  width: '100%',
                }}
              >
                {renderItem(item)}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
