import { render } from '@testing-library/react'
import React from 'react'

import { Checkbox } from './Checkbox'

vi.mock('@v-uik/base', () => ({
  Checkbox: ({ classes, ...props }: Record<string, unknown>) => {
    const checkboxClass = (classes as { checkbox?: string } | undefined)?.checkbox
    return <input type='checkbox' className={checkboxClass} {...props} />
  },
}))

describe('Checkbox', () => {
  it('renders without crashing', () => {
    const { container } = render(<Checkbox />)
    expect(container.querySelector('input[type="checkbox"]')).toBeInTheDocument()
  })

  it('applies invalid class when invalid prop is true', () => {
    const { container } = render(<Checkbox invalid />)
    const input = container.querySelector('input[type="checkbox"]')
    expect(input?.className).toContain('checkboxInvalid')
  })

  it('does not apply invalid class when invalid prop is false', () => {
    const { container } = render(<Checkbox invalid={false} />)
    const input = container.querySelector('input[type="checkbox"]')
    expect(input?.className).not.toContain('checkboxInvalid')
  })

  it('does not apply invalid class when invalid prop is not set', () => {
    const { container } = render(<Checkbox />)
    const input = container.querySelector('input[type="checkbox"]')
    expect(input?.className).not.toContain('checkboxInvalid')
  })
})
