import {
  Checkbox as PlatformCheckbox,
  type CheckboxProps as PlatformCheckboxProps,
} from '@v-uik/base'
import classNames from 'classnames'
import React, { type FC } from 'react'

import styles from './Checkbox.module.scss'


interface CheckboxProps extends PlatformCheckboxProps {
  invalid?: boolean
}

export const Checkbox: FC<CheckboxProps> = ({ invalid, classes, ...props }) => {
  return (
    <PlatformCheckbox
      classes={{
        ...classes,
        checkbox: classNames({ [styles.checkboxInvalid]: invalid }),
      }}
      {...props}
    />
  )
}
