import { Switch } from '@v-uik/base'
import classNames from 'classnames'
import React, { type FC, useEffect, useState } from 'react'

import styles from './ToggleSwitch.module.scss'

interface SwitchProps {
  isChecked: boolean
  onChange: (checked: boolean) => void
  isDisabled?: boolean
  leftLabel: string
  rightLabel: string
}

/**
 * Компонент переключателя
 */
export const ToggleSwitch: FC<SwitchProps> = ({
  isChecked: propsIsChecked,
  onChange,
  isDisabled = false,
  leftLabel,
  rightLabel,
}) => {
  const [isChecked, setIsChecked] = useState(false)

  useEffect(() => {
    setIsChecked(propsIsChecked)
  }, [propsIsChecked])

  const handleOnClick = () => {
    const newCheckedState = !isChecked
    setIsChecked(newCheckedState)
    onChange(newCheckedState)
  }

  return (
    <div className={classNames(styles.toggle)}>
      <span
        className={classNames(styles.toggleOption, {
          [styles.toggleOptionActive]: !isChecked,
        })}
      >
        {leftLabel}
      </span>
      <Switch
        checked={isChecked}
        onClick={handleOnClick}
        disabled={isDisabled}
      />
      <span
        className={classNames(styles.toggleOption, {
          [styles.toggleOptionActive]: isChecked,
        })}
      >
        {rightLabel}
      </span>
    </div>
  )
}
