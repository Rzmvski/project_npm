import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { describe, expect, it, vi } from 'vitest'

import { ToggleSwitch } from './ToggleSwitch'

vi.mock('@v-uik/base', () => ({
  Switch: ({
    checked,
    onClick,
    disabled,
  }: {
    checked?: boolean
    onClick?: () => void
    disabled?: boolean
  }) => <button role='switch' aria-checked={checked} disabled={disabled} onClick={onClick} />,
}))

describe('ToggleSwitch', () => {
  it('shows both choices and reports the next value after interaction', async () => {
    const onChange = vi.fn()
    render(
      <ToggleSwitch
        isChecked={false}
        onChange={onChange}
        leftLabel='Выключено'
        rightLabel='Включено'
      />,
    )
    const toggle = screen.getByRole('switch')

    expect(screen.getByText('Выключено')).toBeVisible()
    expect(screen.getByText('Включено')).toBeVisible()
    expect(toggle).not.toBeChecked()

    await userEvent.click(toggle)

    expect(toggle).toBeChecked()
    expect(onChange).toHaveBeenCalledWith(true)
  })

  it('cannot be changed while disabled', async () => {
    const onChange = vi.fn()
    render(
      <ToggleSwitch
        isChecked={false}
        onChange={onChange}
        isDisabled
        leftLabel='Выключено'
        rightLabel='Включено'
      />,
    )

    await userEvent.click(screen.getByRole('switch'))
    expect(onChange).not.toHaveBeenCalled()
  })
})
