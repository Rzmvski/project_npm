import {
  RangePicker as PlatformRangePicker,
  type RangePickerProps,
} from '@v-uik/base'
import { CalendarRangeIcon } from 'lucide-react'
import React, { type FC } from 'react'

import styles from './RangePicker.module.scss'

const placeholder = 'ДД.ММ.ГГГГ'

export const RangePicker: FC<RangePickerProps> = (props) => {
  return (
    <PlatformRangePicker
      suffix={<CalendarRangeIcon className={styles.icon} />}
      mask={'11.11.1111'}
      classes={{
        errorIcon: styles.errorIcon,
      }}
      startInputProps={{
        placeholder,
      }}
      endInputProps={{
        placeholder,
      }}
      {...props}
    />
  )
}
