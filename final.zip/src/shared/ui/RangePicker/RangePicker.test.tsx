import { render, screen } from '@testing-library/react'
import React from 'react'

import { RangePicker } from './RangePicker'

vi.mock('@v-uik/base', () => ({
  RangePicker: ({
    suffix,
    mask,
    startInputProps,
    endInputProps,
  }: {
    suffix?: React.ReactNode
    mask?: string
    startInputProps?: { placeholder?: string }
    endInputProps?: { placeholder?: string }
  }) => (
    <div data-testid='range-picker'>
      <input
        data-testid='start-input'
        placeholder={startInputProps?.placeholder}
        data-mask={mask}
      />
      <input
        data-testid='end-input'
        placeholder={endInputProps?.placeholder}
        data-mask={mask}
      />
      {suffix && <div data-testid='suffix-icon' />}
    </div>
  ),
}))

describe('RangePicker', () => {
  it('renders start and end inputs with placeholder', () => {
    render(<RangePicker />)

    const startInput = screen.getByTestId('start-input')
    const endInput = screen.getByTestId('end-input')

    expect(startInput).toHaveAttribute('placeholder', 'ДД.ММ.ГГГГ')
    expect(endInput).toHaveAttribute('placeholder', 'ДД.ММ.ГГГГ')
  })

  it('renders with mask attribute', () => {
    render(<RangePicker />)

    const startInput = screen.getByTestId('start-input')
    expect(startInput).toHaveAttribute('data-mask', '11.11.1111')
  })

  it('renders suffix icon', () => {
    render(<RangePicker />)

    expect(screen.getByTestId('suffix-icon')).toBeInTheDocument()
  })
})
