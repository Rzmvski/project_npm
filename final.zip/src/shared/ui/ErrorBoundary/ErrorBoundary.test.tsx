import { render, screen } from '@testing-library/react'
import React from 'react'

import { ErrorBoundary } from './ErrorBoundary'

describe('ErrorBoundary', () => {
  it('renders without errors by default', () => {
    render(
      <ErrorBoundary>
        <div>test</div>
      </ErrorBoundary>,
    )

    expect(screen.findByText('test')).toBeTruthy()
  })

  it('should render for exception', () => {
    const Boom = () => {
      throw new Error()
    }

    render(
      <ErrorBoundary>
        <Boom />
      </ErrorBoundary>,
    )

    expect(screen.getByRole('heading')).toHaveTextContent('Что-то пошло не так')
  })

  it('should render for exception with message', () => {
    const errorMessage = 'Oops!'
    const Boom = () => {
      throw new Error()
    }

    render(
      <ErrorBoundary message={errorMessage}>
        <Boom />
      </ErrorBoundary>,
    )

    expect(screen.getByText(errorMessage)).toBeInTheDocument()
  })
})
