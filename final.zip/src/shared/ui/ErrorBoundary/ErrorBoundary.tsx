import { TriangleAlert } from 'lucide-react'
import React, { Component, type ErrorInfo, type PropsWithChildren } from 'react'

import { StatusPage } from '@/shared/ui/StatusPage'

const DEFAULT_ERROR_MESSAGE = 'Что-то пошло не так'

type ErrorBoundaryState = {
  hasError: boolean
  error: Nullable<Error>
}

interface ErrorBoundaryProps extends PropsWithChildren {
  message?: string
}

/**
 * Рендеринг обертки обработки ошибок
 */
export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props)
    this.state = { hasError: false, error: null }
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error }
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo)
  }

  private handleRetry = () => {
    this.setState({ hasError: false, error: null })
  }

  render() {
    const { children, message } = this.props

    const { hasError, error } = this.state

    if (hasError) {
      return (
        <StatusPage
          code={'500'}
          description={
            error?.message ||
            'Не удалось загрузить страницу. Попробуйте ещё раз — если ошибка повторится, сообщите в поддержку.'
          }
          Icon={TriangleAlert}
          primaryAction={{ label: 'Попробовать снова', onClick: this.handleRetry }}
          secondaryAction={{ label: 'На главную', to: '/' }}
          title={message || DEFAULT_ERROR_MESSAGE}
        />
      )
    }

    return children
  }
}
