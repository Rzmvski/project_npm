import { createContext } from 'react'

export type TabName = string

export type TabContextType<TName extends TabName = TabName> = {
  activeTab: TName
}

export const TabContext = createContext<Nullable<TabContextType>>(null)
