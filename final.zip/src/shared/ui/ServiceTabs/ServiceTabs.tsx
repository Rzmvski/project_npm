import { Tab, Tabs, useStorage } from '@v-uik/base'
import React, {
  type ReactNode,
  useEffect,
  useMemo,
  useState,
  type ComponentType,
} from 'react'

import styles from './ServiceTabs.module.scss'
import { TabContext, type TabName } from './TabContext'

type TabNames<TTabs extends readonly TabContent[]> = TTabs[number]['tabName']

interface ServiceTabsProps<TTabs extends readonly TabContent[]> {
  serviceName: string
  defaultTabName: TabNames<TTabs>
  tabs: TTabs
  onChange?: (tab: TabNames<TTabs>) => void
}

export interface TabContent<TName extends TabName = TabName> {
  tabName: TName
  title: ReactNode
  component: ComponentType
  tabProps?: object
  className?: string
}

export function ServiceTabs<TTabs extends readonly TabContent[]>({
  serviceName,
  defaultTabName,
  tabs,
  onChange,
}: ServiceTabsProps<TTabs>) {
  const [activeTab, setActiveTab] = useStorage('session', serviceName, defaultTabName)
  const [mountedTabs, setMountedTabs] = useState<Set<string>>(
    () => new Set([defaultTabName, activeTab]),
  )

  useEffect(() => {
    setMountedTabs((current) => {
      if (current.has(activeTab)) return current
      return new Set(current).add(activeTab)
    })
  }, [activeTab])

  const handleChange = (tab: string) => {
    setMountedTabs((current) => {
      if (current.has(tab)) return current
      return new Set(current).add(tab)
    })
    setActiveTab(tab)
    onChange?.(tab)
  }

  const contextValue = useMemo(() => ({ activeTab }), [activeTab])

  return (
    <Tabs
      keepMounted
      value={activeTab}
      onChange={(value) => handleChange(value as string)}
      classes={{ root: styles.container, content: styles.content }}
    >
      {tabs.map((config) => {
        const { tabName, component, title } = config
        const Content = component
        return (
          <Tab key={tabName} header={title} value={tabName}>
            <TabContext.Provider value={contextValue}>
              {mountedTabs.has(tabName) ? <Content /> : null}
            </TabContext.Provider>
          </Tab>
        )
      })}
    </Tabs>
  )
}
