import { LinearProgress, useTheme } from '@v-uik/base'
import React, { type FC } from 'react'

import styles from './ProgressBar.module.scss'

const numberFormatter = new Intl.NumberFormat('ru-RU')

const MAX_VALUE = 100

interface ProgressRevisionProps {
  currentValue: number
  totalValue: number
}

export const ProgressBar: FC<ProgressRevisionProps> = ({
  currentValue,
  totalValue,
}) => {
  const percentage = (currentValue / totalValue) * MAX_VALUE
  const theme = useTheme()

  return (
    <div className={styles.container}>
      <span>
        {numberFormatter.format(currentValue)}/
        {numberFormatter.format(totalValue)}{' '}
      </span>
      <LinearProgress
        value={percentage}
        max={MAX_VALUE}
        color={
          percentage >= MAX_VALUE
            ? theme.ref.palette.green60
            : theme.sys.color.primaryAlpha
        }
      />
      <span className={styles.percentage}>({percentage.toFixed(1)}%)</span>
    </div>
  )
}
