import { describe, it, expect, vi } from 'vitest'

import { HttpError } from './httpError'

describe('HttpError', () => {
  describe('constructor', () => {
    it('should create an HttpError with status and message', () => {
      const error = new HttpError(500, 'Server error')
      expect(error).toBeInstanceOf(Error)
      expect(error).toBeInstanceOf(HttpError)
      expect(error.name).toBe('HttpError')
      expect(error.status).toBe(500)
      expect(error.message).toBe('Server error')
      expect(error.cause).toBeUndefined()
    })

    it('should create an HttpError with cause', () => {
      const error = new HttpError(400, 'Bad request', 'validation_error')
      expect(error.status).toBe(400)
      expect(error.message).toBe('Bad request')
      expect(error.cause).toBe('validation_error')
    })

    it('should set timestamp to current date', () => {
      const before = Date.now()
      const error = new HttpError(403, 'Forbidden')
      const after = Date.now()
      expect(error.timestamp.getTime()).toBeGreaterThanOrEqual(before)
      expect(error.timestamp.getTime()).toBeLessThanOrEqual(after)
    })
  })

  describe('isNotFound()', () => {
    it('should return true for status 404', () => {
      const error = new HttpError(404, 'Not found')
      expect(error.isNotFound()).toBe(true)
    })

    it('should return false for status 500', () => {
      const error = new HttpError(500, 'Server error')
      expect(error.isNotFound()).toBe(false)
    })

    it('should return false for status 403', () => {
      const error = new HttpError(403, 'Forbidden')
      expect(error.isNotFound()).toBe(false)
    })

    it('should return false for status 200', () => {
      const error = new HttpError(200, 'OK')
      expect(error.isNotFound()).toBe(false)
    })
  })

  describe('fromResponse()', () => {
    const mockResponse = (status: number, body?: unknown) =>
      ({
        status,
        json: vi.fn().mockResolvedValue(body),
      }) as unknown as Response

    it('should create HttpError from response with error and message', async () => {
      const response = mockResponse(500, {
        error: 'internal_error',
        message: 'Something went wrong',
      })
      const error = await HttpError.fromResponse(response)
      expect(error).toBeInstanceOf(HttpError)
      expect(error.status).toBe(500)
      expect(error.message).toBe('Something went wrong')
      expect(error.cause).toBe('internal_error')
    })

    it('should use error as message when message is missing', async () => {
      const response = mockResponse(400, { error: 'bad_request' })
      const error = await HttpError.fromResponse(response)
      expect(error.status).toBe(400)
      expect(error.message).toBe('bad_request')
      expect(error.cause).toBe('bad_request')
    })

    it('should use default message when response body is invalid', async () => {
      const response = mockResponse(503, { unexpected: 'data' })
      const error = await HttpError.fromResponse(response)
      expect(error.status).toBe(503)
      expect(error.message).toBe('Internal error')
      expect(error.cause).toBeUndefined()
    })

    it('should use server message from real backend ErrorResponse shape (no `error` field)', async () => {
      // Matches apis/openapi.yml / apis/openapi2.yml ErrorResponse schema:
      // { timestamp, status, message, path } — there is no `error` field.
      const response = mockResponse(500, {
        timestamp: '2026-08-15T12:00:00.000Z',
        status: 500,
        message: 'User with id 42 is locked',
        path: '/api/users/42',
      })
      const error = await HttpError.fromResponse(response)
      expect(error.status).toBe(500)
      expect(error.message).toBe('User with id 42 is locked')
      expect(error.cause).toBeUndefined()
    })

    it('should use default message when JSON parsing fails', async () => {
      const response = {
        status: 502,
        json: vi.fn().mockRejectedValue(new Error('parse error')),
      } as unknown as Response
      const error = await HttpError.fromResponse(response)
      expect(error.status).toBe(502)
      expect(error.message).toBe('Internal error')
    })
  })
})
