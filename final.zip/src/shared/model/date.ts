export type DateRange = [Nullable<Date>, Nullable<Date>]
