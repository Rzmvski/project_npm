export const NOTHING = '\u2013'
