import { describe, it, expect } from 'vitest'

import type { Unknowable, Indexable, StatusConfig } from './utils'

describe('utils', () => {
  describe('Unknowable type', () => {
    it('should allow T value', () => {
      const value: Unknowable<string> = 'hello'
      expect(value).toBe('hello')
    })

    it('should allow "unknown" literal', () => {
      const value: Unknowable<number> = 'unknown'
      expect(value).toBe('unknown')
    })

    it('should not allow other strings', () => {
      const value: Unknowable<boolean> = 'unknown'
      expect(value).toBe('unknown')
    })
  })

  describe('Indexable type', () => {
    it('should add index property to T', () => {
      const item: Indexable<{ name: string }> = { name: 'test', index: 0 }
      expect(item.name).toBe('test')
      expect(item.index).toBe(0)
    })

    it('should allow index of any number', () => {
      const item: Indexable<{ id: number }> = { id: 42, index: 5 }
      expect(item.id).toBe(42)
      expect(item.index).toBe(5)
    })
  })

  describe('StatusConfig type', () => {
    it('should require title and icons', () => {
      const config: StatusConfig<'active' | 'inactive'> = {
        title: 'Status',
        icons: {
          active: () => null,
          inactive: () => null,
        },
      }
      expect(config.title).toBe('Status')
      expect(config.icons.active).toBeDefined()
      expect(config.icons.inactive).toBeDefined()
    })

    it('should allow optional label', () => {
      const config: StatusConfig<'ok'> = {
        title: 'OK',
        label: 'All good',
        icons: {
          ok: () => null,
        },
      }
      expect(config.label).toBe('All good')
    })
  })
})
