import { z } from 'zod'

const DEFAULT_MESSAGE = 'Internal error'
const NOT_FOUND_STATUS_CODE = 404

// Backend error responses commonly look like `{ timestamp, status, message, path }`
// (see apis/openapi.yml / apis/openapi2.yml ErrorResponse schema) and have no
// `error` field. Some legacy responses use `{ error, message? }` instead.
// Both fields are optional here so either shape parses successfully; if neither
// is present we fall back to DEFAULT_MESSAGE below.
const ErrorResponseSchema = z.object({
  error: z.string().optional(),
  message: z.string().optional(),
})

export class HttpError extends Error {
  readonly status: number
  readonly timestamp: Date
  readonly cause?: string

  constructor(status: number, message: string, cause?: string) {
    super(message)
    this.name = 'HttpError'
    this.status = status
    this.timestamp = new Date()
    this.cause = cause
  }

  public isNotFound(): boolean {
    return this.status === NOT_FOUND_STATUS_CODE
  }

  public static async fromResponse(response: Response): Promise<HttpError> {
    const { status } = response
    try {
      const body = await response.json()
      const { success, data } = ErrorResponseSchema.safeParse(body)

      if (!success) {
        return new HttpError(status, DEFAULT_MESSAGE)
      }

      const { error, message } = data
      const resolvedMessage = message ?? error ?? DEFAULT_MESSAGE

      return new HttpError(status, resolvedMessage, error)
    } catch {
      return new HttpError(status, DEFAULT_MESSAGE)
    }
  }
}
