import { describe, it, expect, beforeEach } from 'vitest'

import { Contours, contourKey, contourLocalStorage } from './contours'

const DEFAULT_CONTOUR = Contours.TKP

describe('contours', () => {
  describe('Contours enum', () => {
    it('should have correct values', () => {
      expect(Contours.TKP).toBe('tkp')
      expect(Contours.HUB).toBe('hub')
      expect(Contours.DATA_CACHE).toBe('data-cache')
    })
  })

  describe('contourKey', () => {
    it('should be a string constant', () => {
      expect(contourKey).toBe('contour')
    })
  })

  describe('contourLocalStorage', () => {
    beforeEach(() => {
      localStorage.clear()
    })

    describe('get()', () => {
      it('should return default contour when nothing is stored', () => {
        expect(contourLocalStorage.get()).toBe(DEFAULT_CONTOUR)
      })

      it('should return stored contour when it exists', () => {
        localStorage.setItem(contourKey, Contours.HUB)
        expect(contourLocalStorage.get()).toBe(Contours.HUB)
      })

      it('should return stored value for DATA_CACHE', () => {
        localStorage.setItem(contourKey, Contours.DATA_CACHE)
        expect(contourLocalStorage.get()).toBe(Contours.DATA_CACHE)
      })
    })

    describe('set()', () => {
      it('should store contour in localStorage', () => {
        contourLocalStorage.set(Contours.HUB)
        expect(localStorage.getItem(contourKey)).toBe(Contours.HUB)
      })

      it('should overwrite previously stored contour', () => {
        localStorage.setItem(contourKey, Contours.HUB)
        contourLocalStorage.set(Contours.TKP)
        expect(localStorage.getItem(contourKey)).toBe(Contours.TKP)
      })
    })
  })
})
