import { type ComponentType } from 'react'

type IconDictionary<S extends string> = Record<S, ComponentType>

export type Unknowable<T> = T | 'unknown'

export type Indexable<T> = T & {
  index: number
}

export type StatusTone = 'neutral' | 'success' | 'warning' | 'danger'

export type StatusConfig<S extends string> = {
  title: string
  label?: string
  icons: IconDictionary<S>
  tones?: Record<S, StatusTone>
}
