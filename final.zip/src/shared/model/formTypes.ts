import { type ReactNode } from 'react'

export type Option<T> = {
  value: T
  label?: string
  prefix?: ReactNode
  suffix?: ReactNode
}
