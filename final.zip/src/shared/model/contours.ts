export enum Contours {
  TKP = 'tkp',
  HUB = 'hub',
  DATA_CACHE = 'data-cache',
}

export const contourKey = 'contour'

const defaultContour = Contours.TKP

export const contourLocalStorage = {
  get: () => localStorage.getItem(contourKey) ?? defaultContour,
  set: (contour: Contours) => localStorage.setItem(contourKey, contour),
}
