import { createElement } from 'react'
import { describe, it, expect } from 'vitest'

import type { Option } from './formTypes'

describe('formTypes', () => {
  it('should export Option type', () => {
    const option: Option<string> = { value: 'test' }
    expect(option.value).toBe('test')
  })

  it('should allow Option with label', () => {
    const option: Option<number> = { value: 1, label: 'One' }
    expect(option.value).toBe(1)
    expect(option.label).toBe('One')
  })

  it('should allow Option with prefix', () => {
    const option: Option<string> = { value: 'x', prefix: createElement('span') }
    expect(option.value).toBe('x')
    expect(option.prefix).toBeDefined()
  })

  it('should allow Option with suffix', () => {
    const option: Option<string> = { value: 'y', suffix: createElement('div') }
    expect(option.value).toBe('y')
    expect(option.suffix).toBeDefined()
  })

  it('should allow Option with all fields', () => {
    const option: Option<boolean> = {
      value: true,
      label: 'Yes',
      prefix: createElement('i'),
      suffix: createElement('b'),
    }
    expect(option.value).toBe(true)
    expect(option.label).toBe('Yes')
  })
})
