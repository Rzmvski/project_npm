export const enum Permissions {
  GET_DICTIONARY = 'dictionariesService_getDictionary',

  GET_CURRENT_OPERATIONS_DAY = 'closingOperationDayService_getCurrentOperationDay',
  START_CLOSING_OPERATION_DAY = 'closingOperationDayService_startClosingOperationDay',
  GET_RESULT_OF_CLOSING_OPERATIONS_DAY = 'closingOperationDayService_getResultOfClosingOperationDay',
  GET_FAILED_CONTRACTS_WITH_STEPS = 'closingOperationDayService_getFailedContractsWithSteps',
  GET_HISTORY_OF_CLOSING_OPERATIONS_DAY = 'closingOperationDayService_getHistory',
  GET_HISTORY_DETAILED_OF_CLOSING_OPERATIONS_DAY = 'closingOperationDayService_getHistoryDetailed',

  START_FOR_PROCESSES_GROUP = 'processManagementService_startProcess',
  GET_HISTORY_FOR_PROCESSES_GROUP = 'processManagementService_getHistory',

  // Инф-я в шапке страницы
  GET_OPERATION_DAYS_IN_HEADER = 'closingOperationDayService_getOperationDays',
  GET_STAND_IN_STATUS = 'standInService_getStandInStatus',

  // Административные процессы
  ADMIN_PROCESSES = 'userService_getPermissions', // для того, чтобы открепить зависимость на пермишене сервиса SI
  CLUSTER_INFO = 'zoneIndexService_getClusterInfo',
  SHARD_INFO = 'shardInfoService_getInfo',
  RUN_SCRIPT = 'scriptService_createScriptRequest',
  CLIENT_TRANSFER = 'clientTransferService_transfer',
  FEATURE_TOGGLING = 'featureTogglingService_getInfo',
  CLUSTER_MANAGEMENT = 'clusterManagementService_getShard',
  REVISE_REPLICATION = 'revisionService_runRevision',
}

export type PermissionType = Permissions | string
