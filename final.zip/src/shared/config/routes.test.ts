import { describe, it, expect } from 'vitest'

import { ROUTES, TITLE_DICTIONARY } from './routes'

describe('routes', () => {
  describe('ROUTES', () => {
    it('should have FORBIDDEN route', () => {
      expect(ROUTES.FORBIDDEN).toBe('/forbidden')
    })

    it('should have ERROR route', () => {
      expect(ROUTES.ERROR).toBe('/error')
    })

    it('should have NOT_FOUND route', () => {
      expect(ROUTES.NOT_FOUND).toBe('/not-found')
    })

    it('should have CLOSE_TRADING_DAY route', () => {
      expect(ROUTES.CLOSE_TRADING_DAY).toBe('/close-trading-day')
    })

    it('should have START_PROCESS_GROUP route', () => {
      expect(ROUTES.START_PROCESS_GROUP).toBe('/start-process-group')
    })

    it('should have INDEX_MANAGEMENT route', () => {
      expect(ROUTES.INDEX_MANAGEMENT).toBe('/index-management')
    })

    it('should have SHARD_INFO route', () => {
      expect(ROUTES.SHARD_INFO).toBe('/shard-info')
    })

    it('should have SCRIPT_RUNNER route', () => {
      expect(ROUTES.SCRIPT_RUNNER).toBe('/script-runner')
    })

    it('should have CLUSTER_MANAGEMENT route', () => {
      expect(ROUTES.CLUSTER_MANAGEMENT).toBe('/cluster-management')
    })

    it('should have NODE_BALANCING route', () => {
      expect(ROUTES.NODE_BALANCING).toBe('/node-balancing')
    })

    it('should have FEATURE_TOGGLING route', () => {
      expect(ROUTES.FEATURE_TOGGLING).toBe('/feature-toggling')
    })

    it('should have REVISE_REPLICATION route', () => {
      expect(ROUTES.REVISE_REPLICATION).toBe('/revise-replication')
    })

    it('should have GEO_BALANCING route', () => {
      expect(ROUTES.GEO_BALANCING).toBe('/geo-balancing')
    })

    it('should have all 13 routes defined', () => {
      const routeKeys = Object.keys(ROUTES)
      expect(routeKeys).toHaveLength(13)
    })
  })

  describe('TITLE_DICTIONARY', () => {
    it('should have title for every route', () => {
      const routeKeys = Object.keys(ROUTES)
      routeKeys.forEach((key) => {
        expect(TITLE_DICTIONARY).toHaveProperty(key)
        expect(typeof TITLE_DICTIONARY[key as keyof typeof ROUTES]).toBe('string')
      })
    })

    it('should have correct title for NOT_FOUND', () => {
      expect(TITLE_DICTIONARY.NOT_FOUND).toBe('Страница не найдена')
    })

    it('should have correct title for ERROR', () => {
      expect(TITLE_DICTIONARY.ERROR).toBe('Ошибка')
    })

    it('should have correct title for FORBIDDEN', () => {
      expect(TITLE_DICTIONARY.FORBIDDEN).toBe('Доступ запрещен')
    })

    it('should have correct title for INDEX_MANAGEMENT', () => {
      expect(TITLE_DICTIONARY.INDEX_MANAGEMENT).toBe('Управление индексами')
    })

    it('should have correct title for SHARD_INFO', () => {
      expect(TITLE_DICTIONARY.SHARD_INFO).toBe('Шард контракта')
    })

    it('should have correct title for SCRIPT_RUNNER', () => {
      expect(TITLE_DICTIONARY.SCRIPT_RUNNER).toBe('Запуск исправляющих скриптов')
    })

    it('should have correct title for NODE_BALANCING', () => {
      expect(TITLE_DICTIONARY.NODE_BALANCING).toBe('Балансировка нод')
    })

    it('should have correct title for FEATURE_TOGGLING', () => {
      expect(TITLE_DICTIONARY.FEATURE_TOGGLING).toBe('Управление фичами')
    })

    it('should have correct title for CLUSTER_MANAGEMENT', () => {
      expect(TITLE_DICTIONARY.CLUSTER_MANAGEMENT).toBe('Управление узлами и семафорами')
    })

    it('should have correct title for REVISE_REPLICATION', () => {
      expect(TITLE_DICTIONARY.REVISE_REPLICATION).toBe('Сверка репликации нод')
    })

    it('should have correct title for CLOSE_TRADING_DAY', () => {
      expect(TITLE_DICTIONARY.CLOSE_TRADING_DAY).toBe('Закрытие операционного дня')
    })

    it('should have correct title for START_PROCESS_GROUP', () => {
      expect(TITLE_DICTIONARY.START_PROCESS_GROUP).toBe('Запуск группы процессов')
    })

    it('should have correct title for GEO_BALANCING', () => {
      expect(TITLE_DICTIONARY.GEO_BALANCING).toBe('Управление трафиком')
    })

    it('should have exactly 13 keys matching ROUTES', () => {
      const routeKeys = Object.keys(ROUTES)
      const titleKeys = Object.keys(TITLE_DICTIONARY)
      expect(titleKeys.sort()).toEqual(routeKeys.sort())
    })
  })

  describe('type safety', () => {
    it('TITLE_DICTIONARY keys should match ROUTES keys', () => {
      type RouteKeys = keyof typeof ROUTES
      const titleKey: RouteKeys = 'FORBIDDEN'
      expect(TITLE_DICTIONARY[titleKey]).toBe('Доступ запрещен')
    })
  })
})
