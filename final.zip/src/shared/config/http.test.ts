import { describe, it, expect, vi, beforeEach } from 'vitest'

import { Contours } from '@/shared/model'
import type * as SharedModel from '@/shared/model'

// Mock notification
vi.mock('@v-uik/base', () => ({
  notification: vi.fn(),
}))

// Mock HttpError
vi.mock('@/shared/model', async (importOriginal) => {
  const actual = await importOriginal<typeof SharedModel>()
  return {
    ...actual,
    HttpError: {
      fromResponse: vi
        .fn()
        .mockResolvedValue(new actual.HttpError(500, 'Mocked error', 'mock_error')),
    },
    contourLocalStorage: {
      get: vi.fn(() => Contours.TKP),
      set: vi.fn(),
    },
    Contours: actual.Contours,
  }
})

// Need to re-setup for localStorage mock for contourKey
vi.mock('@/shared/model', async (importOriginal) => {
  const actual = await importOriginal<typeof SharedModel>()
  return {
    Contours: actual.Contours,
    contourKey: 'contour',
    HttpError: actual.HttpError,
    contourLocalStorage: {
      get: vi.fn(() => Contours.TKP),
      set: vi.fn(),
    },
  }
})

describe('http config', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  it('should export tkpRequestConfiguration', async () => {
    const { tkpRequestConfiguration } = await import('./http')
    expect(tkpRequestConfiguration).toBeDefined()
  })

  it('should export platformRequestConfiguration', async () => {
    const { platformRequestConfiguration } = await import('./http')
    expect(platformRequestConfiguration).toBeDefined()
  })

  it('tkpRequestConfiguration should be an instance of Configuration', async () => {
    const { tkpRequestConfiguration } = await import('./http')
    // Check it has middleware (Configuration injects middleware)
    expect(tkpRequestConfiguration).toBeDefined()
    // Runtime check: middleware is an array
    expect(
      (tkpRequestConfiguration as unknown as { middleware: unknown[] }).middleware,
    ).toBeInstanceOf(Array)
  })

  it('platformRequestConfiguration should be an instance of Configuration', async () => {
    const { platformRequestConfiguration } = await import('./http')
    expect(platformRequestConfiguration).toBeDefined()
    expect(
      (
        platformRequestConfiguration as unknown as {
          middleware: unknown[]
        }
      ).middleware,
    ).toBeInstanceOf(Array)
  })
})
