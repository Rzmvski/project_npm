import {
  Configuration as PlatformConfiguration,
  type ConfigurationParameters,
  type ResponseContext,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { Configuration as TkpConfiguration } from '@sber-pprb-tkp/tcpf-support-admin-api'
import { notification } from '@v-uik/base'
import { type TNotificationStatus } from '@v-uik/notification/dist/esm/types'

import { contourLocalStorage, Contours, HttpError } from '@/shared/model'

const STATUS_CONFIG: Record<number, TNotificationStatus> = {
  500: 'error',
  404: 'info',
  401: 'warning',
  400: 'warning',
}

const handleError = async (response: Response) => {
  const { status: statusCode } = response

  switch (statusCode) {
    case 401: {
      location.reload()
      break
    }
    default: {
      const httpError = await HttpError.fromResponse(response)
      const { message } = httpError
      const status = STATUS_CONFIG[statusCode] ?? 'default'
      notification(message, {
        status,
        direction: 'vertical',
      })
      console.error(httpError)
      return Promise.reject(httpError)
    }
  }
}

/**
 * SSE-подписку узнаём по запросу, а не по ответу: у ошибочного ответа
 * content-type будет JSON, а Accept выставляют классы `*ApiSse`.
 */
const isSseRequest = (init: RequestInit) => {
  return new Headers(init.headers).get('accept')?.includes('text/event-stream') === true
}

const configuration: ConfigurationParameters = {
  middleware: [
    {
      post: async (context: ResponseContext) => {
        const { response, init, url } = context

        // Рантайм отдаёт в middleware клон ответа (внутри — tee тела). Для
        // обычного запроса клон дочитывается и освобождается, а на долгом
        // SSE-потоке непрочитанная ветка буферизуется всё время его жизни.
        // Поэтому клон отменяем и возвращаем undefined — рантайм оставит
        // исходный ответ и сам бросит ResponseError на не-2xx.
        if (isSseRequest(init)) {
          void response.body?.cancel().catch(() => {})

          if (!response.ok) {
            // Нотификацию не показываем: подписка переподключается сама, и на
            // каждой попытке всплывал бы новый тост.
            console.error(`SSE-поток ${url} ответил ${response.status}`)
            if (response.status === 401) location.reload()
          }

          return undefined
        }

        if (response.ok) return response

        return handleError(response)
      },
    },
  ],
}

export const tkpRequestConfiguration = new TkpConfiguration({
  ...configuration,
  basePath: import.meta.env.PROD ? Contours.TKP : 'tkp/',
})

export const platformRequestConfiguration = new PlatformConfiguration({
  ...configuration,
  basePath: import.meta.env.PROD
    ? `platform/${contourLocalStorage.get()}`
    : 'platform/',
})
