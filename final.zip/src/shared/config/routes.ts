export const ROUTES = {
  ERROR: '/error',
  FORBIDDEN: '/forbidden',
  NOT_FOUND: '/not-found',
  CLOSE_TRADING_DAY: '/close-trading-day',
  START_PROCESS_GROUP: '/start-process-group',
  INDEX_MANAGEMENT: '/index-management',
  SHARD_INFO: '/shard-info',
  SCRIPT_RUNNER: '/script-runner',
  CLUSTER_MANAGEMENT: '/cluster-management',
  NODE_BALANCING: '/node-balancing',
  FEATURE_TOGGLING: '/feature-toggling',
  REVISE_REPLICATION: '/revise-replication',
  GEO_BALANCING: '/geo-balancing',
} as const

export type RoutePath = (typeof ROUTES)[keyof typeof ROUTES]

export const TITLE_DICTIONARY: Record<keyof typeof ROUTES, string> = {
  ERROR: 'Ошибка',
  NOT_FOUND: 'Страница не найдена',
  FORBIDDEN: 'Доступ запрещен',
  INDEX_MANAGEMENT: 'Управление индексами',
  SHARD_INFO: 'Шард контракта',
  SCRIPT_RUNNER: 'Запуск исправляющих скриптов',
  NODE_BALANCING: 'Балансировка нод',
  FEATURE_TOGGLING: 'Управление фичами',
  CLUSTER_MANAGEMENT: 'Управление узлами и семафорами',
  REVISE_REPLICATION: 'Сверка репликации нод',
  CLOSE_TRADING_DAY: 'Закрытие операционного дня',
  START_PROCESS_GROUP: 'Запуск группы процессов',
  GEO_BALANCING: 'Управление трафиком',
}
