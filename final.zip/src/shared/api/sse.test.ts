import { isAbortError, joinApiUrl, subscribeToSse } from './sse'

const createDeferred = () => {
  let resolve!: () => void
  const promise = new Promise<void>((nextResolve) => {
    resolve = nextResolve
  })

  return { promise, resolve }
}

/** Поток, который отдаёт значения из очереди и завершается по `finish()`. */
const createControllableStream = <T>() => {
  const queue: T[] = []
  let notify = createDeferred()
  let finished = false

  const stream = async function* () {
    while (!finished || queue.length > 0) {
      if (queue.length === 0) {
        await notify.promise
        continue
      }

      yield queue.shift() as T
    }
  }

  const flush = async () => {
    notify.resolve()
    notify = createDeferred()
    // Двух микротасков хватает, чтобы генератор дошёл до следующего yield.
    await Promise.resolve()
    await Promise.resolve()
  }

  return {
    stream,
    push: async (value: T) => {
      queue.push(value)
      await flush()
    },
    finish: async () => {
      finished = true
      await flush()
    },
  }
}

describe('SSE helpers', () => {
  it('соединяет basePath и путь без двойных слешей', () => {
    expect(joinApiUrl('platform/tkp/', '/api/v1/events')).toBe('platform/tkp/api/v1/events')
  })

  it('распознаёт отмену подписки', () => {
    expect(isAbortError(new DOMException('aborted', 'AbortError'))).toBe(true)
    // Рантайм сгенерированного клиента заворачивает ошибку fetch в FetchError.
    expect(
      isAbortError({ name: 'FetchError', cause: new DOMException('aborted', 'AbortError') }),
    ).toBe(true)
    expect(isAbortError(new Error('boom'))).toBe(false)
    expect(isAbortError(null)).toBe(false)
  })

  it('переподключается после обрыва потока', async () => {
    const onMessage = vi.fn()
    let attempt = 0

    const subscription = subscribeToSse<number>({
      retryDelay: 0,
      // Каждое «соединение» отдаёт одно событие и завершается — так же
      // выглядит обрыв потока со стороны сервера.
      stream: () =>
        (async function* () {
          attempt += 1
          yield attempt
        })(),
      onMessage,
    })

    await vi.waitFor(() => {
      expect(onMessage.mock.calls.length).toBeGreaterThanOrEqual(3)
    })

    subscription.close()
    await subscription.done

    expect(onMessage.mock.calls.slice(0, 3)).toEqual([[1], [2], [3]])
  })

  it('не переподключается, когда retryDelay не задан', async () => {
    const stream = vi.fn(async function* () {
      yield 1
    })

    const subscription = subscribeToSse<number>({ stream, onMessage: vi.fn() })
    await subscription.done

    expect(stream).toHaveBeenCalledOnce()
  })

  it('передаёт события подписчику и сообщает об открытии потока один раз', async () => {
    const source = createControllableStream<{ id: number }>()
    const onMessage = vi.fn()
    const onOpen = vi.fn()

    const subscription = subscribeToSse({
      stream: source.stream,
      onMessage,
      onOpen,
    })

    await source.push({ id: 1 })
    await source.push({ id: 2 })
    await source.finish()
    await subscription.done

    expect(onOpen).toHaveBeenCalledOnce()
    expect(onMessage).toHaveBeenNthCalledWith(1, { id: 1 })
    expect(onMessage).toHaveBeenNthCalledWith(2, { id: 2 })
  })

  it('прокидывает signal в фабрику потока и не отдаёт события после close()', async () => {
    const stream = vi.fn(async function* (signal: AbortSignal) {
      await new Promise<void>((resolve) => {
        signal.addEventListener('abort', () => resolve(), { once: true })
      })
      yield 'too-late'
    })
    const onMessage = vi.fn()

    const subscription = subscribeToSse<string>({ stream, onMessage })
    subscription.close()
    await subscription.done

    expect(stream).toHaveBeenCalledOnce()
    expect(subscription.signal.aborted).toBe(true)
    expect(onMessage).not.toHaveBeenCalled()
  })

  it('сообщает об ошибке потока', async () => {
    const failure = new Error('stream failed')
    const onError = vi.fn()

    const subscription = subscribeToSse<string>({
      stream: () =>
        (async function* () {
          await Promise.resolve()
          throw failure
        })(),
      onMessage: vi.fn(),
      onError,
    })

    await subscription.done

    expect(onError).toHaveBeenCalledWith(failure)
  })

  it('не считает ошибкой отмену подписки', async () => {
    const onError = vi.fn()

    const subscription = subscribeToSse<string>({
      stream: (signal) =>
        (async function* () {
          await new Promise<void>((resolve) => {
            signal.addEventListener('abort', () => resolve(), { once: true })
          })
          throw new DOMException('aborted', 'AbortError')
        })(),
      onMessage: vi.fn(),
      onError,
    })

    subscription.close()
    await subscription.done

    expect(onError).not.toHaveBeenCalled()
  })
})
