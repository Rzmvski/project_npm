import type { QueryKey, UseQueryOptions } from '@tanstack/react-query'

type CreatePollingQueryPolicyResult<TData, TQueryKey extends QueryKey> = Pick<
  UseQueryOptions<TData, unknown, TData, TQueryKey>,
  'refetchInterval' | 'retry'
>

interface CreatePollingQueryPolicyParams<TData> {
  stopPredicate: (data: TData) => boolean
  retry?: boolean
  intervalMs?: number
}

export function createPollingQueryPolicy<TData, TQueryKey extends QueryKey>({
  stopPredicate,
  retry = false,
  intervalMs = 2000,
}: CreatePollingQueryPolicyParams<TData>): CreatePollingQueryPolicyResult<
  TData,
  TQueryKey
> {
  return {
    refetchInterval: ({ state }) => {
      const { status, data } = state
      if (status == 'error') return false
      const shouldStop = !!data && stopPredicate(data)
      if (shouldStop) return false
      return intervalMs
    },
    retry,
  }
}
