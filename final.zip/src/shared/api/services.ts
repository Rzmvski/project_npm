import {
  ClusterManagementServiceApiSse,
  ConnectionPoolManagementServiceApiSse,
  FeatureTogglingServiceApi,
  GeoBalancingManagementServiceApiSse,
  MetadataManagementServiceApi,
  MonitoringManagementServiceApiSse,
  ReviseReplicationServiceApi,
  ScriptServiceApi,
  UserServiceApi,
  ZoneIndexServiceApi,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'
import {
  ClientTransferServiceApi,
  OperationDayServiceApi,
  ProcessManagementServiceApi,
} from '@sber-pprb-tkp/tcpf-support-admin-api'

import {
  platformRequestConfiguration,
  tkpRequestConfiguration,
} from '@/shared/config'

// Сервисы, у которых в контракте есть операции с `x-sse: true`, создаются от
// классов `*ApiSse`: они наследуют все обычные методы без изменений и
// дополнительно дают `<operationId>Stream()` для подписки на события.
// Остальные сервисы остаются на базовых классах — потоков у них нет.

export const featureTogglingService = new FeatureTogglingServiceApi(
  platformRequestConfiguration
)
export const reviseReplicationService = new ReviseReplicationServiceApi(
  platformRequestConfiguration
)
export const scriptService = new ScriptServiceApi(platformRequestConfiguration)
export const userService = new UserServiceApi(platformRequestConfiguration)
export const zoneIndexService = new ZoneIndexServiceApi(
  platformRequestConfiguration
)
export const metadataManagementService = new MetadataManagementServiceApi(
  platformRequestConfiguration
)

export const clusterManagementService = new ClusterManagementServiceApiSse(
  platformRequestConfiguration
)
export const monitoringManagementService = new MonitoringManagementServiceApiSse(
  platformRequestConfiguration
)
export const geoBalancingManagementService =
  new GeoBalancingManagementServiceApiSse(platformRequestConfiguration)
export const connectionPoolManagementService =
  new ConnectionPoolManagementServiceApiSse(platformRequestConfiguration)

export const clientTransferService = new ClientTransferServiceApi(
  tkpRequestConfiguration
)
export const odService = new OperationDayServiceApi(tkpRequestConfiguration)
export const processManagementService = new ProcessManagementServiceApi(
  tkpRequestConfiguration
)
