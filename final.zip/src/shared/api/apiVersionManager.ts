class ApiVersionManager {
  private _useDeprecatedMethods: boolean | null = null

  set useDeprecatedMethods(value: boolean | null) {
    this._useDeprecatedMethods = value
  }

  get useDeprecatedMethods(): boolean | null {
    return this._useDeprecatedMethods
  }
}

export const apiVersionManager = new ApiVersionManager()
