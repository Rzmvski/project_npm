import { describe, it, expect, beforeEach } from 'vitest'

import { apiVersionManager } from './apiVersionManager'
import * as apiVersionManagerModule from './apiVersionManager'

describe('apiVersionManager', () => {
  beforeEach(() => {
    apiVersionManager.useDeprecatedMethods = null
  })

  it('should initially be null', () => {
    expect(apiVersionManager.useDeprecatedMethods).toBeNull()
  })

  it('should set and get true', () => {
    apiVersionManager.useDeprecatedMethods = true
    expect(apiVersionManager.useDeprecatedMethods).toBe(true)
  })

  it('should set and get false', () => {
    apiVersionManager.useDeprecatedMethods = false
    expect(apiVersionManager.useDeprecatedMethods).toBe(false)
  })

  it('should set and get null', () => {
    apiVersionManager.useDeprecatedMethods = true
    apiVersionManager.useDeprecatedMethods = null
    expect(apiVersionManager.useDeprecatedMethods).toBeNull()
  })

  it('should be a singleton', () => {
    const anotherRef = apiVersionManagerModule.apiVersionManager
    anotherRef.useDeprecatedMethods = true
    expect(apiVersionManager.useDeprecatedMethods).toBe(true)
  })

  it('should switch from true to false', () => {
    apiVersionManager.useDeprecatedMethods = true
    expect(apiVersionManager.useDeprecatedMethods).toBe(true)

    apiVersionManager.useDeprecatedMethods = false
    expect(apiVersionManager.useDeprecatedMethods).toBe(false)
  })

  it('should return the same instance via module import', () => {
    const { apiVersionManager: directImport } = apiVersionManagerModule
    expect(directImport).toBe(apiVersionManager)
  })
})
