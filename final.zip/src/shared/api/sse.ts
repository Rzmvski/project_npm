/**
 * Тонкая обёртка над SSE-потоками сгенерированного клиента.
 *
 * Потоки приходят из классов `*ApiSse` библиотеки
 * `@sber-pprb-tkp/tcpf-platform-admin-api`: у каждой операции с `x-sse: true`
 * есть метод `<operationId>Stream()`, возвращающий `AsyncGenerator`. Под
 * капотом это `fetch` с заголовком `Accept: text/event-stream`, поэтому
 * basePath, `credentials` и middleware конфигурации применяются сами, а
 * отписка выполняется через `AbortSignal`, а не через `EventSource`.
 */

export type SseStream<T> = AsyncGenerator<T, void, unknown>

/** Фабрика потока: `(signal) => service.somethingStream({ signal })`. */
export type SseStreamFactory<T> = (signal: AbortSignal) => SseStream<T>

export interface SubscribeToSseOptions<T> {
  stream: SseStreamFactory<T>
  onMessage: (data: T) => void
  /** Вызывается на первом событии каждого установленного соединения. */
  onOpen?: () => void
  onError?: (error: unknown) => void
  /**
   * Базовая пауза перед переподключением, мс. `null` — не переподключаться.
   *
   * `EventSource` переподключался сам, поток на `fetch` — нет: после обрыва
   * или таймаута прокси генератор просто завершается, и UI молча остаётся с
   * устаревшими данными. Поэтому переподключение делаем явно, с
   * экспоненциальным ростом паузы и джиттером — иначе после рестарта бэкенда
   * все подписки ломятся в него синхронно.
   */
  retryDelay?: number | null
}

/** Потолок множителя паузы: при базовых 3 с это до 24 с между попытками. */
const MAX_RETRY_FACTOR = 8

export const joinApiUrl = (basePath: string, path: string) => {
  return `${basePath.replace(/\/+$/, '')}/${path.replace(/^\/+/, '')}`
}

/**
 * Отмена приходит либо как нативный `AbortError`, либо завёрнутой в
 * `FetchError` сгенерированного рантайма — тогда исходная ошибка лежит в
 * `cause`.
 */
export const isAbortError = (error: unknown): boolean => {
  if (typeof error !== 'object' || error === null) return false

  const { name, cause } = error as { name?: unknown; cause?: { name?: unknown } }

  return name === 'AbortError' || cause?.name === 'AbortError'
}

export const subscribeToSse = <T>({
  stream,
  onMessage,
  onOpen,
  onError,
  retryDelay = null,
}: SubscribeToSseOptions<T>) => {
  const controller = new AbortController()

  /** Пауза, которая прерывается досрочно, если подписку закрыли. */
  const wait = (delay: number) => {
    // На уже прерванном сигнале событие 'abort' больше не придёт, поэтому
    // выходим сразу, а не ждём таймер до конца.
    if (controller.signal.aborted) return Promise.resolve()

    return new Promise<void>((resolve) => {
      const timer = setTimeout(() => {
        controller.signal.removeEventListener('abort', onAbort)
        resolve()
      }, delay)

      function onAbort() {
        clearTimeout(timer)
        resolve()
      }

      controller.signal.addEventListener('abort', onAbort, { once: true })
    })
  }

  const done = (async () => {
    let failures = 0

    while (!controller.signal.aborted) {
      let opened = false

      try {
        for await (const chunk of stream(controller.signal)) {
          // Между abort() и реальным закрытием соединения поток может успеть
          // отдать ещё одно событие — такие данные UI уже не нужны.
          if (controller.signal.aborted) return

          if (!opened) {
            opened = true
            onOpen?.()
          }

          onMessage(chunk)
        }
      } catch (error) {
        // Отписка со стороны UI — это не ошибка потока.
        if (controller.signal.aborted || isAbortError(error)) return
        onError?.(error)
      }

      if (retryDelay === null) return

      // Соединение, которое успело отдать данные, считаем удачным и
      // сбрасываем накопленный backoff.
      failures = opened ? 0 : failures + 1

      const factor = Math.min(2 ** (failures - 1), MAX_RETRY_FACTOR)
      const jitter = 0.5 + Math.random() / 2

      await wait(retryDelay * Math.max(factor, 1) * jitter)
    }
  })()

  return {
    signal: controller.signal,
    /** Промис завершения подписки — удобен в тестах. */
    done,
    close: () => controller.abort(),
  }
}
