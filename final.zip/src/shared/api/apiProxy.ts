import { type BaseAPI } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { apiVersionManager } from './apiVersionManager'

// TODO: Переделать под версионирование API
export class ApiProxy<T extends BaseAPI> {
  private readonly client: T
  private versionManager = apiVersionManager

  constructor(client: T) {
    this.client = client
  }

  async call<K extends keyof T, D extends keyof T>(
    newMethod: K,
    deprecatedMethod: D,
    ...args: unknown[]
  ): // @ts-expect-error T[K] is not known to be callable with generic args
  ReturnType<T[K]> {
    const isDeprecated = this.versionManager.useDeprecatedMethods

    if (isDeprecated === true) {
      // @ts-expect-error T[D] is not known to be callable with generic args
      return await this.client[deprecatedMethod](...args)
    }

    if (isDeprecated === false) {
      // @ts-expect-error T[K] is not known to be callable with generic args
      return await this.client[newMethod](...args)
    }

    try {
      // @ts-expect-error T[K] is not known to be callable with generic args
      const response = await this.client[newMethod](...args)
      this.versionManager.useDeprecatedMethods = false
      return response
    } catch {
      this.versionManager.useDeprecatedMethods = true
      // @ts-expect-error T[D] is not known to be callable with generic args
      return await this.client[deprecatedMethod](...args)
    }
  }
}
