---
name: sourcecontrol-pr
description: >
  Формирует Pull Request для Source Control на основе фактического git diff,
  коммитов и OpenSpec change. Использовать перед созданием PR.
---

# Source Control Pull Request

## Purpose

Подготовить корректные title и description Pull Request.

PR должен описывать только фактически внесённые изменения.
Не придумывать выполненные проверки, причины изменений, связанные PR или риски.

Для cross-repository изменений использовать один и тот же OpenSpec change-id
во всех связанных PR.

## Context collection

Перед формированием PR обязательно собрать контекст:

```bash
git status --short
git branch --show-current
git log --oneline --decorate -10
git diff --stat origin/<target>...HEAD
git diff origin/<target>...HEAD
```

Если используется OpenSpec, прочитать:

```text
openspec/changes/<change-id>/proposal.md
openspec/changes/<change-id>/tasks.md
openspec/changes/<change-id>/specs/**
```

Не формировать описание PR только по commit message.

Главный источник истины:

1. git diff;
2. выполненные OpenSpec tasks;
3. commit history;
4. proposal/specification.

## PR title

Формат:

```text
<TICKET>: <short description>
```

Пример:

```text
TPTCP-4033: Add environment banner to admin UI
```

Требования:

- ticket брать из OpenSpec, имени branch или задачи;
- описание должно отражать результат, а не процесс;
- использовать imperative/action-oriented wording;
- не ставить точку в конце;
- не использовать `WIP`, `fix stuff`, `changes`, `updates`;
- не перечислять несколько низкоуровневых изменений через запятую;
- стараться укладываться в 100 символов;
- один PR — одна логическая цель.

Для multi-repository change title должен отражать роль конкретного repository.

Например:

```text
TPTCP-4033: Expose environment metadata in platform API
TPTCP-4033: Provide environment metadata in platform backend
TPTCP-4033: Add environment banner to admin UI
```

## PR description

Использовать следующий формат:

```markdown
## Что изменено

- <логическое изменение 1>
- <логическое изменение 2>

## Зачем

<кратко объяснить цель изменения>

## Проверка

- `<command>` — passed
- `<command>` — passed

## OpenSpec

`<change-id>`

## Связанные PR

- `<repository>` — <PR URL>

## Риски

<риски, ограничения или "Существенных рисков не выявлено">
```

## Description rules

### Что изменено

Описывать поведение системы, API или UI.

Хорошо:

```text
- Добавлен REST endpoint для получения environment metadata.
- UI отображает environment banner на non-production окружениях.
```

Плохо:

```text
- Изменён EnvironmentService.java.
- Добавлено несколько компонентов.
- Исправлен код.
```

Не перечислять файлы, если это не помогает понять изменение.

### Зачем

Брать motivation из OpenSpec proposal.

Не копировать proposal целиком.

Обычно достаточно 1–3 предложений.

### Проверка

Указывать только реально выполненные проверки.

Например:

```markdown
## Проверка

- `mvn test` — passed
- `pnpm test` — passed
- `pnpm lint` — passed
```

Никогда не писать `passed`, если команда не запускалась.

Если проверка не запускалась:

```text
- Unit tests — not run
```

и при наличии причины:

```text
- Integration tests — not run (require external environment)
```

### OpenSpec

Если изменение связано с OpenSpec, секция обязательна.

Использовать точный change-id:

```markdown
## OpenSpec

`add-environment-banner`
```

Не придумывать change-id.

### Связанные PR

Для изменения, затрагивающего несколько repository, добавить связанные PR.

Например:

```markdown
## Связанные PR

- `tcpf-platform-admin-api` — <URL>
- `tcpf-platform-admin-app` — <URL>
- `tcpf-support-admin-ui` — <URL>
```

Не указывать несуществующие URL.

Если PR ещё не создан:

```text
- `tcpf-platform-admin-app` — pending
```

После создания остальных PR обновить описание, если Source Control позволяет это сделать.

### Риски

Указывать конкретные риски:

```text
Изменяется публичный API между admin UI и platform admin app.
```

или:

```text
Существенных рисков не выявлено.
```

Не придумывать rollback plan без необходимости.

## Multi-repository changes

Если один OpenSpec change реализуется в нескольких repository:

```text
tcpf-platform-admin-api
tcpf-platform-admin-app
tcpf-support-admin-api
tcpf-support-admin-app
tcpf-support-admin-ui
```

каждый PR должен:

- иметь тот же ticket;
- иметь тот же OpenSpec change-id;
- описывать только изменения своего repository;
- содержать связанные PR;
- не копировать description другого repository;
- иметь самостоятельный понятный title.

## Before PR creation

Перед созданием PR обязательно проверить:

```bash
git status --short
git log origin/<target>..HEAD --oneline
git diff --check origin/<target>...HEAD
git diff --stat origin/<target>...HEAD
```

Убедиться, что:

- PR не содержит unrelated changes;
- target branch выбран правильно;
- feature branch опубликован в origin;
- нет случайно добавленных credentials, secrets или локальных файлов;
- выполненные проверки отражены в description.

## Output

Вернуть структурированный результат:

```text
PR_TITLE=<title>

PR_BODY<<EOF
<body>
EOF
```

Если вызывающий agent умеет создавать PR самостоятельно, передать эти значения
в Source Control PR creation command.

Не спрашивать пользователя сформулировать title или description, если их можно
однозначно получить из git diff и OpenSpec.

## Forbidden

Никогда:

- не создавать описание PR до анализа diff;
- не утверждать, что тесты прошли, если они не запускались;
- не включать unrelated changes;
- не auto-merge PR;
- не force-push;
- не создавать PR непосредственно из `main`, `master`, `dev` или другой protected branch;
- не использовать текст вроде "Generated by AI";
- не добавлять выдуманные ticket, OpenSpec change-id или PR URLs.