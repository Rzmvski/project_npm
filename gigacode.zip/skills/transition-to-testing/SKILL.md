---
name: transition-to-testing
description: Use when the user asks to send Jira tickets to testing — provide ticket key(s) and the tester name; skill sets assignee + tester role, sets developer, checks "Требуется НТ", and transitions status to ST
---

# Transition to Testing

## Params

| Param | Required | Type | Description |
|-------|----------|------|-------------|
| `tickets` | ✅ Yes | `string[]` | Массив ключей тикетов Jira (e.g. `["TPTCP-4124", "TPTCP-4125"]`) |
| `tester_name` | ✅ Yes | `string` | Полное имя тестировщика для назначения (e.g. `"Иванов Иван Иванович"`) |

Если параметры не переданы — спроси у пользователя перед началом работы.

## Overview

**Core principle:** Перевод тикета на тестирование — это не просто смена статуса. Назначаем тестировщика на Assignee и роль "Тестировщик", проверяем, что все поля роли заполнены корректно и статус переведён в ST.

**Violating the letter of this rule is violating the spirit of the process.**

## Jira Field Reference (this project)

| Field | Custom Field Key | Type | Description |
|-------|------------------|------|-------------|
| Разработчик | `customfield_10301` | user | Главный разработчик тикета |
| Тестировщик | `customfield_10302` | user | Главный тестировщик |
| Требуется НТ | `customfield_18201` | select/option | Флаг: требуется ли нагрузочное тестирование |
| Стандартный assignee | `fields.assignee` | user | Основной исполнитель (также используется как Разработчик) |

## Workflow

### Step 1: Read params

Read `tickets` and `tester_name` from the skill params.

If either is missing, ask the user before proceeding.

### Step 1b. Get current user identity

Call `mcp__atlassian__jira_get_user_profile` or `mcp__atlassian__jira_search` with JQL:
```
assignee = currentUser()
```
to find a ticket assigned to the current user and extract their user object:
- `displayName`
- `name` (username)
- `accountID` (or `key`)

Store these values as `{current_user}`. This is the developer who will be set on all tickets.

### Step 2: Process each ticket sequentially

For each ticket key:

#### 2a. Get ticket details

Call `mcp__atlassian__jira_get_issue` with the `issueKey`.

Verify the response is valid and not an error.

#### 2b. Set "Разработчик" = current user

Check `fields.customfield_10301` on the ticket:
- **If already set** to `{current_user}.displayName` → continue to 2c.
- **If not set / different** → update it via `mcp__atlassian__jira_update_issue` with body containing:
  ```json
  {
    "fields": {
      "customfield_10301": { "name": "{current_user.name}" }
    }
  }
  ```

#### 2c. Check "Требуется НТ"

Check `fields.customfield_18201` on the ticket:
- **If already populated** → continue to 2d.
- **If NOT populated** → STOP and ask the user: "В тикете [key] поле 'Требуется НТ' пустое. Чем заполнить?"
- Wait for the user's answer, then update via `mcp__atlassian__jira_update_issue`:
  ```json
  {
    "fields": {
      "customfield_18201": { "value": "<user's answer>" }
    }
  }
  ```

#### 2d. Set "Тестировщик" = пользователь

Find the tester's user object. Search by Jira account `key` (numerical username):

```
key = "<tester key>"
```

If the tester key is unknown, it can be obtained from the Jira profile URL:
`https://jira.<host>/secure/ViewProfile.jspa?name=<KEY>`

Extract the result's `name` from the user object.

Update the ticket via `mcp__atlassian__jira_update_issue` (assignee + custom field):
```json
{
  "fields": {
    "assignee": { "name": "<tester username>" },
    "customfield_10302": { "name": "<tester username>" }
  }
}
```

This sets both the ticket Assignee and the "Тестировщик" role field to the tester.

**If search returns no results** → ask the user for the Jira key of the tester (found in profile URL).

#### 2e. Transition to ST

1. Call `mcp__atlassian__jira_get_transitions` with `issueKey`.
2. Find the transition whose target status `name` matches `"ST"`.
3. Call `mcp__atlassian__jira_transition_issue`:
   - `issueKey`: the current ticket key
   - `transitionId`: the ID found above

If no transition leads to status "ST" → report this and ask the user what the correct target status or transition should be.

#### 2f. Confirm success

After all updates and transition are done, call `mcp__atlassian__jira_get_issue` once more and confirm:
- `assignee` = назначенный тестировщик
- `customfield_10301` (Разработчик) = `{current_user}.displayName`
- `customfield_18201` (Требуется НТ) = populated
- `customfield_10302` (Тестировщик) = назначенный тестировщик
- Status = `ST`

If any check fails, report the failure immediately. Do not proceed to the next ticket until the failed one is resolved.

### Step 3: Report results

After processing all tickets, produce a summary table:

| Ticket | Разработчик | Требуется НТ | Тестировщик | Статус | Result |
|--------|-------------|--------------|-------------|--------|--------|
| TPTCP-1234 | {current_user.display_name} | Да | Иванов И.И. | ST | OK |
| TPTCP-5678 | — | ❓ | — | To Do | SKIPPED: "Требуется НТ" not set |

## Error Handling

| Problem | Action |
|---------|--------|
| Ticket not found | Skip, report key, ask user |
| Разработчик field update fails | Retry once; if fails, report and stop |
| "Требуется НТ" empty | Ask user before continuing |
| Tester not found in JIRA | Ask user for Jira key (from profile URL) |
| No transition to ST | Report, ask user for correct ID/status |
| Transition API error | Retry once; if still failing, stop and report |

## Red Flags - STOP

- Skipping "Требуется НТ" check because "it will be set later"
- Assuming the tester name without searching for it in Jira first
- Transitioning without confirming all role fields are filled
- Bulk-transitioning all tickets before reporting any failure
- Using a hardcoded transition ID without verifying it exists per ticket type
- Mass-transitions without per-ticket verification

## Rationalization Prevention

| Excuse | Reality |
|--------|---------|
| "Разработчик и так там" | Поле `customfield_10301` — отдельное от assignee. Проверяй явно. |
| "Требуется НТ — потом заполнят" | Это обязательное требование процесса. Спроси у пользователя. |
| "Все тикеты одинаковые" | Каждый тикет может иметь разные workflow/fields. Проверяй каждый отдельно. |
| "Я исправлю проблемный позже" | Остановись на первой ошибке. Не наращивай проблемы. |
| "Key тестировщика недостаточно" | Jira требует user object с `name`. Найди через jira_search(key=...) и возьми `name` из результата. |

## Quick Reference

```
User provides: tickets + tester name
  ↓
1b. jira_search(currentUser)        → get current user identity
  ↓
For each ticket (sequentially):
  1. jira_get_issue(key)           → read current state
  2. jira_update_issue → customfield_10301 = current user → set developer
  3. Check customfield_18201 (Требуется НТ)
       → if empty → ask user → then update
  4. jira_search(key)            → find tester's user object by account key
  5. jira_update_issue           → assignee + customfield_10302 = tester
  6. jira_get_transitions(key)     → find transition to "ST"
  7. jira_transition_issue(...)    → apply transition
  8. jira_get_issue(key)           → confirm all fields + status
  ↓
Summary table
```
