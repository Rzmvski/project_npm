---
name: deliver-to-ift
description: Use when the user wants to send a delivery notification email to IFT for an application release ("поставка app_name version")
---

# deliver-to-ift

Send a delivery notification email to IFT following the established format for application releases.

## When to Use

When the user says "поставка {app_name} {version}" or equivalent delivery request.

## Quick Reference

```
User: "поставка tcpf-script-engine-app 8.0"
  -> Parse inputs -> Source Control -> Git pom.xml -> Extract JIRA_RELEASE
  -> Jira get release issue -> DPM find RC -> Collect tasks
  -> DPM SQG + CI/DEV check -> Format as table -> Draft -> Confirm -> Send
  -> Save wiki URL to Jira -> Transition release to "Готов к стабилизации"
```

## Step-by-Step Flow

### 1. Parse input

Extract `app_name` and `release_version` from the user message.

### 2. Get project info from Source Control

Call `mcp__source-control__get_repo` with:
- **tenant:** `167df516-b484-48d5-ac64-d8645d456db9`
- **project:** `FPTRKR`
- **repo:** the extracted `app_name`

Retrieve the repository metadata and get the default branch name (usually `master` or `main`).

### 3. Read build artifacts from Git

Read `pom.xml` or `package.json` from the default branch:
- **Maven:** extract `groupId`, `artifactId`, and full version from `<version>`
- **Node.js:** extract `name` and `version` from `package.json`

### 4. Extract Jira release issue key

Read `pom.xml` or the devops config file from the default branch and look for the `jiraRelease` / `JIRA_RELEASE` property:
- **Maven (`pom.xml`):** look for `<jiraRelease>CCTCP-XXXXX</jiraRelease>` or a property `<jiraRelease>CCTCP-XXXXX</jiraRelease>` inside `<properties>` used via `${jiraRelease}` in the relevant field.
- **Devops file:** look for the key `JIRA_RELEASE` (e.g. `JIRA_RELEASE=CCTCP-XXXXX` or the equivalent YAML / JSON value).

If the property is found, extract its value as the Jira issue key (e.g. `CCTCP-25226`).

**If the property is NOT found -- stop the skill and inform the user.** Do not proceed further.

### 5. Extract data from the release issue

Call `mcp__atlassian__jira_get_issue` with `fields=*all` and `expand=changelog` for the found CCTCP issue. Extract:

| Field | Source |
|-------|--------|
| **Distribution URL** | Custom field `Ссылка на дистрибутив_` |
| **Wiki URL** (Инструкция) | Parse `description` for SberTrack wiki link (`sbertrack.sberbank.ru`) |
| **Dependencies** | Parse changelog for entries with field `Link` and to_string containing "depends on" |

#### If wiki URL is missing in description

**Ask the user for the SberTrack wiki instruction link.** Do NOT proceed without it (this field is mandatory). Save it back to the issue description using `mcp__atlassian__jira_update_issue` after confirming.

#### Dependencies handling

If there are dependency links, list each as `[CCTCP-xxx](https://jira.delta.sbrf.ru/browse/CCTCP-xxx)`. If none, put `--` in the table cell.

#### Full build version

Extract from the distribution URL pattern. The URL path contains the full version:
```
https://int.nexus.sigma.sbrf.ru/repository/maven-distr/{prefix}/{project}/{FULL_VERSION}/...
```
Example: from `CI04310814_tcpf-platform-admin-app/13.0.0_5/` -> full version is `13.0.0_5`.

### 6. Find RAO (service) and Release Candidate in DPM

Use a strict **general-to-specific** approach. Do NOT guess RAO keys or RC IDs.

#### Step 6a — Get functional subsystems of the TCPF project

Call `mcp__dpm__dpm_public_automated_systems_functional_subsy_0j8vw6x` with `as_key=TCPF`.

From the returned list find the functional subsystem that corresponds to the application. The distribution URL path prefix (e.g. `CI04310814`) or the git repository name are the primary matching signals.

#### Step 6b — List RAO services in the subsystem

Call `mcp__dpm__dpm_public_functional_subsystems_release_acti_17tlybs` with the correct `fss_key` from step 6a.

From the result find the RAO whose `name` matches `app_name` (e.g. `tcpf-support-admin-ui`). Record:
- **RAO key** (field `key`), e.g. `CI04310814_TCPF-2A044BCA`
- **FS key** (field `fssKey`)

#### Step 6c — Search for the Release Candidate

Call `mcp__dpm__dpm_public_release_candidates_search` with `raoKey={RAO key from 6b}`.

Extract the RC `id` and store it as `{rc_id}`.

#### Step 6d — Fetch task keys from release notes / changelog

If the RC object contains release notes, extract all Jira keys. Otherwise fall back to parsing the `Link` entries from the CCTCP issue changelog.

### 7. Fetch task details from Jira

For each task key from the DPM release notes, call `mcp__atlassian__jira_get_issue` to extract:
- `issuetype.name` (Тип)
- `key` (Ключ)
- `summary` (Название)
- `status.name` (Статус)

Build a markdown table sorted by issue type priority (Bug -> Story -> Improvement).

### 7b. Verify DPM quality gates and pipeline steps

Use the RC already found in step 6c (`{rc_id}`). Do NOT attempt to derive RC ID from the branch name (e.g. `release/15.0.0` → `15.0.0`) — this is fragile and often wrong. The RC ID is an internal integer (e.g. `1891896142`).

1. Get the steps via `mcp__dpm__dpm_public_release_candidate_steps_get(rc_id={rc_id})`.
2. Inspect each step by its `name` field:
   - **CI** — exact name may be `"CI "` (with trailing space). Status must be `STEP_COMPLETED`.
   - **DEV** — exact name `"DEV"`. Status must be `STEP_COMPLETED`.
   - **SQG flags** — if present in RC details, every flag must be **approved** (none blocked, none pending).
3. Step names are case-sensitive and may contain trailing whitespace. Match on `name`, not on `label`.

**If any condition is NOT met -- stop the skill.** Inform the user exactly which check failed (SQG blocked, CI failed, or DEV failed) and do not proceed to draft creation.

### 8. Format the email body

#### Mandatory fields validation (GATE)

**BEFORE creating a draft, validate ALL of the following fields are present and non-empty.** If ANY field is missing or empty, **STOP the skill and inform the user**. Do NOT create a draft with placeholders.

| Field | Source | Required | Placeholder if empty |
|-------|--------|----------|---------------------|
| Номер релиза (CCTCP key) | Jira issue key from pom.xml `jiraRelease` | ✅ Yes | **STOP** |
| Инструкция (wiki URL) | Parsed from Jira issue `description` | ✅ Yes | **STOP** |
| Дистрибутив (distribution URL) | Jira custom field `Ссылка на дистрибутив_` | ✅ Yes | **STOP** |
| Артефакт в registry | Extracted from distribution field (after `;`) | ✅ Yes | **STOP** |
| Состав сборки (app_name + full_version) | Built from artifact data | ✅ Yes | **STOP** |
| Комментарий | User input | ⬜ No | `--` |
| Зависимости | Parsed from Jira changelog | ⬜ No | `--` |

**Rule:** All 5 mandatory fields must have real values. If the distribution URL exists but the registry artifact part (after `;`) is missing, ASK the user — do NOT proceed without it.

#### Pre-flight checks (optional fields)

For fields that accept user input (these are NOT required, but validated if present):

1. **Comment text** — ASK the user for a short release comment. If user provides nothing, use `--`.

#### Recipients

Set the following fixed recipients using **email addresses separated by commas** (no name `<email>` wrapping). The `create_draft` / `send_email` tool resolves addresses by comma-separated emails.

**To (comma-separated):**
```
ALL-TESTERS@sberbank.ru,PPRB_TCPF_TEST@sberbank.ru,Solynin.A.Al@sberbank.ru,AMPolunina@sberbank.ru
```

**Cc (comma-separated):**
```
AAleksaTsarev@sberbank.ru,tcp_rmc@sberbank.ru,KEvgMarkelov@sberbank.ru,SNKhamatkhanov@sberbank.ru,Kuzmin.P.Vy@sberbank.ru
```

#### Body (HTML, not Markdown)

Outlook renders only HTML in the body parameter -- **markdown tables are displayed as raw text**. Build the entire body as an HTML string with proper `<table>`, `<tr>`, `<td>`, `<b>`, `<br>`, and `<a href>` tags. Do not use `|` table syntax in the body.

Example:
```html
<table border="1" cellpadding="4" cellspacing="0" style="border-collapse:collapse">
<tr><th>Параметр</th><th>Значение</th></tr>
<tr><td>Номер релиза</td><td><a href="https://jira.delta.sbrf.ru/browse/CCTCP-25841">CCTCP-25841</a></td></tr>
...
</table><br>

<b>Задачи в релизе:</b><br><br>

<table border="1" cellpadding="4" cellspacing="0" style="border-collapse:collapse">
<tr><th>Тип</th><th>Ключ</th><th>Название</th><th>Статус</th></tr>
<tr><td>Bug</td><td><a href="https://jira.delta.sbrf.ru/browse/TPTCP-4126">TPTCP-4126</a></td><td>(PAA) Неправильное отображение статуса</td><td>Зарегистрирован</td></tr>
...
</table>
```

Field details:
- **Зависимости:** each as `<a href="https://jira.delta.sbrf.ru/browse/CCTCP-xxx">CCTCP-xxx</a>`, joined with `<br>`, or `--` if none.
- **Дистрибутив:** display the FULL URL as the link text: `<a href="{distribution_url}">{distribution_url}</a>`. Do NOT use shortened labels like "nexus URL".
- **Артефакт в registry:** use `<code>registry_url</code>`. If missing, write `--`.
- **Комментарии table:** one `<tr>` per task from DPM release notes.
- **Timestamp:** current date/time in Russia timezone (millisecond epoch or formatted string).

### 9. Create a draft email

Use `mcp__outlook__create_draft` to create a **draft** (НЕ отправляется) with the prepared subject and body.

Show the draft to the user for review. Ask: "Создан черновик письма. Отправить? (yes/no)". Do NOT send anything until the user explicitly confirms.

### 10. Send the email

On explicit confirmation ("yes" / "да"), use `mcp__outlook__send_email` to send the draft.

### 11. Save wiki URL to Jira issue description

After sending the email, check the Jira release issue (`{jira_release_key}`) description. If it does **not** already contain the wiki URL (check for `sbertrack.sberbank.ru` in the description), append it to the end of the description using `mcp__atlassian__jira_update_issue`.

Format to append:
```markdown

**Инструкция:** [sbertrack.sberbank.ru]({wiki_url})
```

If the wiki URL is **already present** in the description (contains `sbertrack.sberbank.ru`), skip this step silently.

### 12. Transition release to "Ready for Stabilization"

After sending the email and saving the wiki URL, transition the Jira release issue (`{jira_release_key}`) through the **two-step status workflow**:

1. **Step A — "На формирование".** Call `mcp__atlassian__jira_get_transitions` for the issue. If the current status is "Создан" (or equivalent initial state), find the transition whose `name` contains "На формирование". Apply it via `mcp__atlassian__jira_transition_issue`.

2. **Step B — "Готов к стабилизации".** Immediately after step A succeeds, call `mcp__atlassian__jira_get_transitions` again (the available transitions change after the first transition). Find the transition whose `name` contains "Готов к стабилизации". Apply it via `mcp__atlassian__jira_transition_issue`.

**Edge cases:**
- **If step A transition is NOT found** — check the current issue status via `mcp__atlassian__jira_get_issue`. If it already contains "Формирование" in `status.name`, skip step A and go directly to step B. If it is in a different unexpected state, log a warning and still attempt step B.
- **If step B transition is NOT found** — log a warning but do NOT block the flow. The email was already sent successfully.

## Email Template

**Subject:** Поставка {app_name} {release_version}

**Body (HTML):**

```html
<table border="1" cellpadding="4" cellspacing="0" style="border-collapse:collapse">
<tr><th>Параметр</th><th>Значение</th></tr>
<tr><td>Номер релиза</td><td><a href="https://jira.delta.sbrf.ru/browse/CCTCP-{key}">CCTCP-{key}</a></td></tr>
<tr><td>Зависимости</td><td>{dependencies_list_or_dash}</td></tr>
<tr><td>Инструкция</td><td><a href="{wiki_url}">sbertrack.sberbank.ru</a></td></tr>
<tr><td>Дистрибутив</td><td><a href="{distribution_url}">{distribution_url}</a></td></tr>
<tr><td>Артефакт в registry</td><td><code>{registry_url}</code></td></tr>
<tr><td>Комментарий</td><td>{comment_text}</td></tr>
<tr><td>Состав сборки</td><td>{app_name} {full_build_version}</td></tr>
</table><br>

<b>Задачи в релизе:</b><br><br>

<table border="1" cellpadding="4" cellspacing="0" style="border-collapse:collapse">
<tr><th>Тип</th><th>Ключ</th><th>Название</th><th>Статус</th></tr>
<tr><td>{type}</td><td><a href="{jira_url}">{key}</a></td><td>{summary}</td><td>{status}</td></tr>
...
</table>
```

#### Footer (empty — Outlook auto-signature)

**Do NOT add any footer manually.** The `mcp__outlook__create_draft` / `send_email` tools let Outlook automatically append the user's configured email signature when the draft is opened or sent. Adding a manual footer would duplicate the signature.

Leave the email body ending directly after the task table — no `<hr>`, no `<br>`, no signature block.

### Field details

- **Зависимости:** each as `<a href="https://jira.delta.sbrf.ru/browse/CCTCP-xxx">CCTCP-xxx</a>` joined with `<br>`, or `--` if none.
- **Дистрибутив:** display the FULL URL as the link text: `<a href="{distribution_url}">{distribution_url}</a>`. Do NOT use shortened labels.
- **Артефакт в registry:** use `<code>registry_url</code>`. If missing, write `--`.
- **Комментарий (parameters table):** optional — ask the user for a comment text for this release. If not provided, write `--`.
- **Задачи в релизе:** renamed heading (was "Комментарии"). One `<tr>` per task from DPM release notes. Jira key is a clickable link.

### Example filled template (HTML)

```html
<table border="1" cellpadding="4" cellspacing="0" style="border-collapse:collapse">
<tr><th>Параметр</th><th>Значение</th></tr>
<tr><td>Номер релиза</td><td><a href="https://jira.delta.sbrf.ru/browse/CCTCP-24651">CCTCP-24651</a></td></tr>
<tr><td>Зависимости</td><td>--</td></tr>
<tr><td>Инструкция</td><td><a href="https://sbertrack.sberbank.ru/swtr/wiki/unit/TPTCP-4129">sbertrack.sberbank.ru</a></td></tr>
<tr><td>Дистрибутив</td><td><a href="https://int.nexus.sigma.sbrf.ru/repository/maven-distr/CI04310814/CI04310814_tcpf-script-engine-app/8.0.0_12/">https://int.nexus.sigma.sbrf.ru/repository/maven-distr/CI04310814/CI04310814_tcpf-script-engine-app/8.0.0_12/</a></td></tr>
<tr><td>Артефакт в registry</td><td><code>registry.sigma.sbrf.ru/ci04310814/ci04310814/tcpf-script-engine-app:8.0.0_12@sha256:...</code></td></tr>
<tr><td>Комментарий</td><td>Первичная поставка на ПСИ</td></tr>
<tr><td>Состав сборки</td><td>tcpf-script-engine-app 8.0.0_12</td></tr>
</table><br>

<b>Задачи в релизе:</b><br><br>

<table border="1" cellpadding="4" cellspacing="0" style="border-collapse:collapse">
<tr><th>Тип</th><th>Ключ</th><th>Название</th><th>Статус</th></tr>
<tr><td>Story</td><td><a href="https://jira.delta.sbrf.ru/browse/TPTCP-4043">TPTCP-4043</a></td><td>МПР RSK00147843. Обновить jackson-core</td><td>In Review</td></tr>
<tr><td>Bug</td><td><a href="https://jira.delta.sbrf.ru/browse/TPTCP-4106">TPTCP-4106</a></td><td>Недоступность UI (500 ошибка)</td><td>Зарегистрирован</td></tr>
</table>
```

## Error Handling

| Problem | Action |
|---------|--------|
| `jiraRelease` / `JIRA_RELEASE` not found in pom.xml / devops file | **Stop the skill.** Inform the user that the property is missing and no further processing is possible. |
| DPM SQG flags not all approved OR CI/DEV step not `Success` | **Stop the skill.** Report exactly which check failed (SQG blocked, CI failed, DEV failed) and do not proceed. |
| Cannot find CCTCP release issue | Ask user for the Jira key directly |
| Distribution URL not set in Jira | Ask the user; save to Jira after confirming |
| Registry artifact missing (no `;` in distribution field) | **Ask the user.** This is mandatory — do NOT proceed without it. |
| Wiki URL missing in description | **Ask the user.** This field is mandatory — do NOT proceed without it. |
| Comment not provided by user | Write `--` (dash) in the Комментарий row. |
| DPM not available or no RC found | Fall back to collecting tasks from Jira changelog (consists of entries) |
| No tasks found in release notes | Omit the Задачи в релизе section entirely |
| User says no to preview | Do not send; let them revise the request |
| No matching transition found in Step 12 | **Do NOT block.** Log a warning; email was already sent. |

## Important Notes

- **`jiraRelease` / `JIRA_RELEASE` is required.** If the property is missing from `pom.xml` or devops file, stop immediately -- do not attempt a Jira search.
- **DPM SQG + CI/DEV gates are required.** Step 7b checks SQG flags, CI step, and DEV step before any draft is created. If any fails, stop and report the exact failure.
- **Draft first, send only on confirmation.** Step 9 creates an Outlook draft; step 10 sends it only after explicit "yes". Never auto-send.
- **Registry artifact** is typically the part after the semicolon in the distribution field, containing the registry URL and SHA256 digest.
- **Task statuses** come from the `status.name` field of each Jira task. Update statuses may lag -- note if a task shows an unexpected status.
- **Recipients format:** Use comma-separated emails only (`email1,email2,email3`). Do NOT use `Name <email>` format -- it breaks parsing for all except the last address.
- **Body format:** Must be valid HTML. Outlook does not render Markdown tables -- use `<table>/<tr>/<td>` tags instead.
- **Wiki URL is mandatory:** If not found in Jira issue description, ASK the user. Never skip this field or put `--` as a placeholder.
- **Comment field is optional:** Ask the user for a comment text for the release. If not provided, write `--`. The row appears in the parameters table, NOT in the task table.
- **Distribution link text:** Always display the FULL URL as both href and text content. Never shorten it to labels like "nexus URL".
- **Task table heading:** Use "Задачи в релизе:" (not "Комментарии:").
- **Mandatory fields GATE:** Before creating a draft, ALL 5 fields must be present and non-empty: Номер релиза (CCTCP key), Инструкция (wiki URL), Дистрибутив (distribution URL), Артефакт в registry, Состав сборки (app_name + full_version). If ANY is missing — **STOP**, do NOT create a draft with placeholders.
- **Footer signature:** Do NOT add a manual footer. Outlook automatically appends the user's configured email signature when the draft is opened or sent. Adding a manual footer would duplicate it. Body ends directly after the task table.
- **No sender_info header:** Do NOT include `{sender_name}`, `{sender_title}`, `[timestamp]`, or `_____________________________` before the parameters table. Body starts directly with the table.
- **Wiki link text:** In the email body, the Инструкция link text must be `sbertrack.sberbank.ru` (host only), not "wiki" or other labels. The full URL is in the href.
- **Step 12 — Two-step status transition is non-blocking.** The release issue must be transitioned through **two sequential steps**: first "На формирование" (if the issue is in "Создан"), then "Готов к стабилизации". Transitions are fetched dynamically via `jira_get_transitions` after each step because the available transitions change. If step A ("На формирование") is not found, check if the issue is already in "Формирование" — skip to step B. If step B is not found, log a warning and continue — the delivery notification was already delivered.
- **DPM service search (CRITICAL).** Never guess RAO keys or RC IDs. Always follow the 4-step sequence: (1) `dpm_public_automated_systems_functional_subsy_0j8vw6x` → list subsystems; (2) `dpm_public_functional_subsystems_release_acti_17tlybs` with the correct `fss_key` → list RAOs; (3) find RAO whose `name` matches `app_name`, record its `key`; (4) `dpm_public_release_candidates_search` with `raoKey={RAO key}` → get RC `id`. The RC ID is an **internal integer** (e.g. `1891896142`), NOT derived from the branch name. Step names in `dpm_public_release_candidate_steps_get` are matched on the `name` field (case-sensitive, may have trailing whitespace like `"CI "`).
