---
name: workspace-project-context
description: >
  Load the correct project-specific GigaCode context when the CLI is started
  from a workspace root containing multiple sibling repositories.
---

# Workspace project context

Use this skill whenever the current directory contains multiple TCPF
repositories or when an OpenSpec task names a repository in brackets.

## Goal

Keep the workspace root available for cross-repository work while preventing
all project instructions from being loaded into every task.

## Procedure

1. Resolve the target repository from the user request or the OpenSpec task
   tag. Use the exact child directory name.
2. Confirm the target is a direct child of the current workspace root.
3. Read, in this order:
   - `<repo>/GIGACODE.md`;
   - `<repo>/openspec/config.yaml`;
   - the relevant files under `<repo>/.gigacode/agents`;
   - the relevant files under `<repo>/.gigacode/skills`.
4. For a central planning task, read `tcpf-context/GIGACODE.md` and then route
   through `tcpf-context/index.md`; do not start by scanning all modules.
5. Keep the loaded project context scoped to the current repository task.
6. Run commands with the target repository as their working directory.
7. At handoff, report the repository, tasks, changed files, validation and
   blockers so the next repository can start with a clean context.

## Required handoff format

```text
CHANGE_ID:
REPOSITORY:
TASKS:
CHANGED_FILES:
CONTRACTS_OR_EXPORTS:
VALIDATION:
SECURITY_SCAN:
BLOCKERS:
NEXT_REPOSITORY:
```

## Important boundaries

- Do not assume a child `.gigacode` was automatically loaded.
- Do not copy project instructions into the root rules.
- Do not edit code in a repository that is not the current task target.
- Do not use a repository-local MCP setting as evidence that the MCP is
  available in workspace-root mode.
