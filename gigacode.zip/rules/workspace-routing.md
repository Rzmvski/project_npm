---
apply: ALWAYS
mode: AGENT
---

# TCPF workspace routing

This GigaCode scope is the workspace root for several sibling repositories.
The CLI is normally started from the workspace root, so project-local
`.gigacode` directories are NOT automatically loaded. They must be loaded
explicitly for the repository being worked on.

## Workspace root

The workspace root is the current directory when it contains these children:

- `tcpf-context` — shared context and OpenSpec store;
- `tcpf-support-admin-ui` — React UI;
- `tcpf-support-admin-api` — support API contract;
- `tcpf-platform-admin-api` — platform API contract;
- `tcpf-support-admin-app` — support backend;
- `tcpf-platform-admin-app` — platform backend.

The directory names above are canonical. Do not reintroduce an `arm` alias or
invent a second repository map.

## Before any repository change

1. Identify the target repository from the user's request or the OpenSpec task
   tag, for example `[tcpf-platform-admin-app]`.
2. Read `<repo>/GIGACODE.md`.
3. Read `<repo>/openspec/config.yaml`.
4. Discover only relevant files under `<repo>/.gigacode/agents` and
   `<repo>/.gigacode/skills`; read the selected agent/skill files before use.
5. Treat `<repo>/.gigacode/settings.json` as direct-repository startup
   configuration only. It is not merged into this workspace-root scope.
6. Execute repository commands with `<repo>` as the working directory. Do not
   rely on the workspace root as the Maven/npm working directory.

Do not load every repository's project context into one prompt. For a
cross-repository change, load the central OpenSpec artifacts once, then load
each repository's local context only when its task starts.

## OpenSpec routing

- Product behavior and cross-repository changes are planned in
  `tcpf-context/openspec`.
- Code repositories use `store: tcpf-context` in `openspec/config.yaml`.
- A task tagged with a repository applies only to that repository.
- Never mark another repository's task complete from the current repository.
- When running OpenSpec commands from the workspace root, pass
  `--store tcpf-context` explicitly.

## MCP routing

User/workspace MCP configuration is authoritative in this scope.

- `sprut` is used for dependency, SBOM and security checks.
- `playwright` is used only for UI/browser validation of
  `tcpf-support-admin-ui`.
- Do not use Playwright for backend or context-store tasks.
- Do not run secret scanning unless the user explicitly authorizes it.

## Direct repository mode

If the CLI is started inside one repository instead of the workspace root,
follow that repository's local `GIGACODE.md` and `.gigacode` configuration.
For cross-repository work, return to the workspace root for planning and use
the repository-specific context-loading procedure above for implementation.
