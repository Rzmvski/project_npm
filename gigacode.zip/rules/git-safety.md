---
apply: ALWAYS
mode: AGENT
---

# Git workflow

Never implement directly on:
- main
- master
- develop

unless explicitly requested.

Before modifying code:

- check the current branch;
- run git status;
- preserve unrelated changes.

In workspace-root mode, repeat these checks with the target repository as the
working directory. The workspace root is not a Git repository for the purpose
of committing implementation changes.

Use the same feature branch name across repositories belonging
to the same cross-repository change.

Preferred branch format:

feat/<ticket>-<change-name>
fix/<ticket>-<change-name>
refactor/<ticket>-<change-name>

## Commits

Create commits for coherent logical changes.

For a cross-repository change, use the same feature branch name in the central
context store and every affected code repository, but commit each repository
independently.

Before committing:

1. inspect git status;
2. inspect the complete diff;
3. run project Fast validation;
4. stage only intentional files;
5. inspect the staged diff;
6. create the commit only when validation succeeds.

Never blindly use:

git add .

Prefer Conventional Commits unless the repository defines
another convention.

Examples:

feat(environment): add environment badge
fix(environment): handle missing environment
test(environment): cover environment rendering

## Safety

Never automatically:

- force push;
- reset --hard;
- delete branches;
- rewrite shared history;
- amend commits belonging to another developer;
- merge protected branches.

Push only when explicitly requested.

Merge only when explicitly requested.
