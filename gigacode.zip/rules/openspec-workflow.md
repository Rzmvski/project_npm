---
apply: ALWAYS
mode: AGENT
---

# OpenSpec workflow

When the current repository uses OpenSpec, OpenSpec is the source
of truth for planned behavior.

Use the lifecycle:

explore
→ propose
→ review/update
→ apply
→ verify
→ archive

## Project-specific agent context

Before implementing an OpenSpec task in a repository:

1. Read the repository GIGACODE.md and/or .gigacode/agents.
2. Discover repository-local rules.
3. Discover relevant repository-local skills and agents.
4. Read referenced project documentation when applicable.
5. Follow repository-specific implementation guidance in addition to
   the OpenSpec requirements.

When the CLI is started from the TCPF workspace root, project-local
`.gigacode` files are not implicitly active. Resolve the repository from the
task tag, then explicitly read that repository's `GIGACODE.md`,
`openspec/config.yaml`, relevant agents and relevant skills. Run commands with
that repository as the working directory.

OpenSpec defines WHAT must change.

Repository-specific agents, skills, rules and documentation define HOW
the change should be implemented.

Do not bypass existing project-specific agent workflows merely because
the change originates from OpenSpec.

## Explore

Investigate the problem and existing code.

Do not modify implementation code.

## Propose

Create or update:

- proposal
- specs
- design
- tasks

Do not implement application code.

Implementation starts only after the plan has been reviewed.

## Apply

Read all relevant OpenSpec artifacts before changing implementation.

Work through tasks in dependency order.

For multi-repository changes, implement only tasks applicable to
the repository currently being modified.

Keep the central change in `tcpf-context`, and use a fresh,
repository-scoped context for each implementation block.

## Incorrect plan discovered during implementation

If implementation reveals that requirements, design or tasks are wrong:

STOP implementation of the affected part.

Run openspec-update-change.

Update the planning artifacts first.

Then resume openspec-apply-change.

Never silently diverge from the specification.

## Verify

Before considering the change complete run openspec-verify-change.

Unresolved CRITICAL findings block completion.

## Archive

Archive only after implementation and verification are complete.

Never archive simply because tasks are checked off.
