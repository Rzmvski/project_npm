---
apply: ALWAYS
mode: AGENT
---

# Agentic development

For non-trivial development tasks use this lifecycle:

understand
→ plan
→ implement
→ validate
→ commit
→ verify
→ review

Do not jump directly from a vague requirement to implementation.

When the CLI is started from a multi-repository workspace root, apply this
lifecycle per target repository. The workspace root coordinates the change;
the target repository owns its implementation, validation and task updates.
Load the target repository's `GIGACODE.md` and relevant `.gigacode` agents and
skills explicitly before changing code.

Before changing code:

1. Understand the repository and existing implementation.
2. Inspect repository state.
3. Determine whether OpenSpec is configured.
4. If OpenSpec is configured, use it as the planning source of truth.

For a cross-repository change, do not load all repositories into one context.
Load the central change artifacts once, then open each repository scope only
when its tagged tasks are being implemented.

Implementation must happen in small coherent steps.

After every logical implementation step:

- inspect the diff;
- run appropriate fast validation;
- fix failures before continuing.

Before declaring work complete:

- run full project validation;
- review the complete branch diff;
- verify requirements against implementation.

Do not confuse:
- code compiling;
- tests passing;
- requirements being satisfied.

All three are separate checks.

Do not hide failures, skipped tests, warnings or unresolved issues.
