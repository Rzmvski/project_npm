---
name: verify-change
description: Review and validate completed changes in Platform Process Manager UI before handoff or merge. Use to select proportional checks, inspect regressions, verify documentation synchronization and report evidence without changing implementation.
---

# Verify change

1. Read the original request, changed files and relevant canonical docs.
2. Trace affected behavior across UI, query state, API, mock and RBAC layers.
3. Run the smallest relevant test first.
4. Add explicit checks according to risk:
   - RBAC: `npm run check:permissions`;
   - formatting: `npm run format:check`;
   - TypeScript/React: `npm run lint:eslint` and `npm run typecheck`;
   - styles: `npm run lint:styles`;
   - behavior: `npm test` or a focused Vitest invocation;
   - integration and production output: `npm run build`.
5. Confirm canonical docs and mock behavior match the implementation.
6. Report commands actually run, their results and any skipped checks.

Use `quality-reviewer-agent` for read-only review. Do not use or recreate
aggregate validation aliases; run the explicit commands relevant to the change.
