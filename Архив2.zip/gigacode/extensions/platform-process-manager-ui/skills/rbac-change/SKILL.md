---
name: rbac-change
description: Change roles, permissions, UI abilities, route guards or authorization behavior in Platform Process Manager UI. Use for roleModel.xml, permission catalogs, Ability mappings, dev role switching and mock authorization.
---

# RBAC change

1. Read `docs/access-control.md`, `docs/rbac-validation.md` and
   `roleModel.xml`.
2. Inventory the current permission IDs and all frontend references.
3. Define the desired role-to-permission and permission-to-Ability mappings.
4. Update `roleModel.xml`, `permissions.ts`, `abilities.ts`, guards and mock
   authorization as one synchronized change.
5. Keep production UI checks based on `Ability`, not role codes or raw
   permission IDs.
6. Preserve dev-only role switching and the tenant scope of each role.
7. Update access tests, including a read-only `USER` path when relevant.
8. Run `npm run check:permissions`, focused tests, typecheck and build.

Use `access-control-agent` for implementation or mapping analysis. Use
`quality-reviewer-agent` to review privilege escalation and production/dev
separation.
