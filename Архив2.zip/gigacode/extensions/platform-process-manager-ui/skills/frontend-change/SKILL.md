---
name: frontend-change
description: Implement or review changes to React pages, components, forms, layouts, routing and user-visible behavior in Platform Process Manager UI. Use for TSX, SCSS, VUIK, React Hook Form, TanStack Router or Query work.
---

# Frontend change

1. Read `docs/architecture.md` and the closest production code and tests.
2. For visual work, read `docs/design-system.md` and `docs/vuik-refactoring.md`.
3. For editable forms, read `docs/refactoring-rhf.md`.
4. Trace the complete user interaction, including loading, empty, error,
   disabled and read-only states.
5. Implement through public slice APIs and existing `@v-uik/base` controls.
6. Keep tenant-aware queries keyed by tenant UUID and requests supplied with
   `tenant-id`.
7. Add or update tests for observable behavior.
8. Run the focused test, then relevant lint, typecheck and build checks.

Use `frontend-engineer-agent` for a bounded implementation subtask. Use
`quality-reviewer-agent` for an independent final review.

Do not change API or RBAC contracts silently. If the UI requires such a change,
switch to the corresponding skill and update its source of truth.
