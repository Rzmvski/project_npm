---
name: api-contract-change
description: Change a REST endpoint, DTO, header, query parameter or response behavior consumed by Platform Process Manager UI. Use when frontend API clients, TypeScript types, Express mock routes, tests and API documentation must remain synchronized.
---

# API contract change

1. Read `API_DOCUMENTATION.md`, `docs/backend-contract.md` and the relevant
   entity types and API client.
2. Write an explicit old-to-new mapping for paths, methods, headers, query
   parameters and DTO fields.
3. Update the canonical contract, entity types and API implementation.
4. Update `mock-server/index.js` with the same success and error behavior.
5. Update call sites, fixtures, mocks and API tests.
6. Search for the obsolete path, field or identifier and resolve every relevant
   occurrence.
7. Run focused tests, typecheck and build. Add RBAC checks if authorization was
   affected.

Use `api-contract-agent` for the synchronization work. Ask
`quality-reviewer-agent` to verify that no stale contract references remain.

Never add speculative backend capabilities. Preserve tenant headers and tenant
UUID in React Query keys.
