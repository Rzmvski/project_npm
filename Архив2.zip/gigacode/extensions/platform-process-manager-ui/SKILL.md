# Platform Process Manager UI extension

This extension provides project-specific instructions for GigaCode.

## Entry points

- `skills/frontend-change/SKILL.md` - implement React, form and layout changes.
- `skills/api-contract-change/SKILL.md` - synchronize REST contract changes.
- `skills/rbac-change/SKILL.md` - synchronize roles, permissions and abilities.
- `skills/verify-change/SKILL.md` - review and validate a completed change.

## Project subagents

- `agents/frontend-engineer-agent.md`;
- `agents/api-contract-agent.md`;
- `agents/access-control-agent.md`;
- `agents/quality-reviewer-agent.md`.

Always start with `GIGACODE.md`. Use only the skill relevant to the current
task and load detailed documents referenced by that skill on demand.
