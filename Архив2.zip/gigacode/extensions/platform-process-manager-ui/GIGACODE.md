# Platform Process Manager UI

You are working on a React 19, TypeScript and Vite application with an Express
mock API. The product manages processes, manual execution, execution history
and weekly schedules in a selected tenant.

## Sources of truth

| Subject                           | Source                                   |
| --------------------------------- | ---------------------------------------- |
| REST contract consumed by UI      | `API_DOCUMENTATION.md`                   |
| Permission and role definitions   | `roleModel.xml`                          |
| UI ability mapping                | `src/entities/access/model/abilities.ts` |
| Entity request and response types | `src/entities/*/model/types.ts`          |
| Local API behavior                | `mock-server/index.js`                   |
| Architecture                      | `docs/architecture.md`                   |
| Documentation map                 | `docs/README.md`                         |

When sources disagree, do not choose silently. For frontend behavior, inspect
the current TypeScript implementation and tests, then update the canonical
contract or report the mismatch.

## Required invariants

- Preserve FSD dependency direction:
  `app -> pages -> widgets -> features -> entities -> shared`.
- Import another slice only through its public `index.ts`.
- Do not import sibling slices from inside `entities`, `features`, `widgets` or
  `pages`.
- Production routing uses TanStack `createHashHistory`; internal `Link` and
  `navigate` targets remain hash-free paths such as `/processes`.
- Tenant UUID is application context, not a route parameter.
- Every tenant-aware request sends the `tenant-id` header.
- Every tenant-aware React Query key contains tenant UUID.
- `GET /user` returns profile data without `tenant-id`.
- `GET /user/permissions` requires `tenant-id` and returns
  `ApiResponse<string[]>`.
- UI code checks `Ability`, never raw permission IDs or role codes.
- Keep `roleModel.xml`, `permissions.ts`, `abilities.ts` and mock authorization
  synchronized.
- Role switching is available only in Vite dev mode.
- Use controls from `@v-uik/base`; do not recreate them in `shared/ui`.
- Read the displayed UI version from the root `package.json`; do not hardcode a
  second version value in components.
- Editable forms use React Hook Form and Zod.
- Monitoring and schedule catalogs remain server-paginated.
- Do not send UI-only filters to backend endpoints.

## Skill routing

| Change                             | Skill                 | Read first                                          |
| ---------------------------------- | --------------------- | --------------------------------------------------- |
| Page, component, form or layout    | `frontend-change`     | `docs/architecture.md`, `docs/design-system.md`     |
| Endpoint, DTO, query or mock API   | `api-contract-change` | `API_DOCUMENTATION.md`, `docs/backend-contract.md`  |
| Role, permission, ability or guard | `rbac-change`         | `docs/access-control.md`, `docs/rbac-validation.md` |
| Review or pre-merge validation     | `verify-change`       | `docs/testing.md`, `docs/validation.md`             |

## Subagent routing

- Delegate isolated React and styling work to `frontend-engineer-agent`.
- Delegate API contract synchronization to `api-contract-agent`.
- Delegate RBAC synchronization to `access-control-agent`.
- Delegate independent review and verification to `quality-reviewer-agent`.
- Give each subagent exact files, constraints and expected evidence.
- Do not delegate the final integration decision or complete validation.

## Commands

```bash
npm install
npm run dev
npm run check:permissions
npm run format:check
npm run lint:eslint
npm run lint:styles
npm run typecheck
npm test
npm run build
```

Run the smallest relevant check first, then add checks proportional to the
risk.

## Working rules

1. Inspect the closest production code and tests before editing.
2. Preserve unrelated user changes.
3. Add or update tests for behavior changes.
4. Update the canonical documentation in the same change.
5. Do not invent endpoints, query parameters, permissions or DTO fields.
6. Report checks actually run and any checks skipped.
