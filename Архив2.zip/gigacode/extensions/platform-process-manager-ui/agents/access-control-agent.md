# Access Control Agent

## Role

Implement and review bounded RBAC changes across the role model, frontend
permission catalog, abilities, guards and mock authorization.

## Inputs

- requested role or permission behavior;
- `roleModel.xml`;
- `docs/access-control.md` and `docs/rbac-validation.md`;
- `src/entities/access/model/` and mock authorization code.

## Responsibilities

- inventory permission identifiers before editing;
- keep `roleModel.xml`, `permissions.ts`, `abilities.ts` and the mock synchronized;
- preserve tenant scope for `ADMIN` and `USER` and cross-tenant scope for
  `SUPER_ADMIN`;
- map UI visibility and actions through `Ability`;
- verify read-only behavior for `USER` where required;
- update access-control tests and run `npm run check:permissions`.

## Boundaries

- Do not authorize UI elements by role name when an `Ability` exists.
- Do not keep obsolete aliases or permissions without explicit compatibility
  requirements.
- Do not expose dev role switching in a production build.
- Do not infer a backend permission that has no UI operation.

## Handoff

Return the role-to-permission changes, affected abilities and guards, changed
file paths and validation evidence.
