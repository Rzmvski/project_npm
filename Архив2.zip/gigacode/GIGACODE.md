# GigaCode project bootstrap

This repository uses the project-local extension
`platform-process-manager-ui`.

Before changing code:

1. Read `extensions/platform-process-manager-ui/GIGACODE.md`.
2. Select the relevant skill from
   `extensions/platform-process-manager-ui/skills/`.
3. Use a profile from `extensions/platform-process-manager-ui/agents/` when a
   bounded subtask benefits from a specialized subagent.
4. Validate the integrated result; a subagent result is not final verification.

Available skills:

- `frontend-change`;
- `api-contract-change`;
- `rbac-change`;
- `verify-change`.

Available project subagents:

- `frontend-engineer-agent`;
- `api-contract-agent`;
- `access-control-agent`;
- `quality-reviewer-agent`.

For merge-request review, GigaCode on GitVerse also reads
`.gitverse/pr_rules/*.md`.
