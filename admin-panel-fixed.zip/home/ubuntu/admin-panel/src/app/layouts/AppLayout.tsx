/**
 * Основной layout приложения
 */

import React from 'react';
import { Outlet } from 'react-router-dom';
import { Sidebar } from '@/widgets/sidebar';
import { Header } from '@/widgets/header';
import styles from './AppLayout.module.scss';

export const AppLayout: React.FC = () => {
  return (
    <div className={styles['app-layout']}>
      <Sidebar />
      <div className={styles['app-layout__main']}>
        <Header />
        <main className={styles['app-layout__content']}>
          <Outlet />
        </main>
      </div>
    </div>
  );
};
