/**
 * API для работы с пользователем
 */

import { generatedClient } from '@/shared/api';
import type { UserData } from '../model/types';
import type { UserRole, PermissionType } from '@/shared/types';

// Типы// Типы, которые будут сгенерированы openapi-fetch-generator
export interface FetchUserResponse {
  user: {
    id: string;
    username: string;
    email: string;
    firstName: string;
    lastName: string;
  };
  roles: UserRole[];
  permissions: PermissionType[];
}missionType[];
}

/**
 * Получить данные текущего пользователя
 */
/**
 * Получить данные текущего пользователя
 */
export const fetchCurrentUser = async (): Promise<UserData> => {
  // Используем сгенерированный клиент
  const { data, error } = await generatedClient.GET("/user/current");

  if (error || !data || !data.success) {
    throw new Error(data?.message || 'Ошибка получения данных пользователя');
  }
  
  const { user, roles, permissions } = data.data;
  
  return {
    ...user,
    roles,
    permissions,
  };
};

/**
 * Получить роли пользователя
 */
export const fetchUserRoles = async (): Promise<UserRole[]> => {
  // Заглушка: в реальном проекте использовать generatedClient
  return [UserRole.ADMIN];
};

/**
 * Получить пермишены пользователя
 */
export const fetchUserPermissions = async (): Promise<PermissionType[]> => {
  // Заглушка: в реальном проекте использовать generatedClient
  return [
    PermissionType.PROCESS_GROUPS_VIEW,
    PermissionType.OPERATIONAL_DAY_VIEW,
    PermissionType.CONTACT_SEARCH_VIEW,
    PermissionType.IGNITE_INDEXES_VIEW,
    PermissionType.NODES_SEMAPHORES_VIEW,
    PermissionType.GROOVY_SCRIPTS_VIEW,
    PermissionType.FEATURE_TOGGLING_VIEW,
    PermissionType.SHARD_MIGRATION_VIEW,
  ];
};
