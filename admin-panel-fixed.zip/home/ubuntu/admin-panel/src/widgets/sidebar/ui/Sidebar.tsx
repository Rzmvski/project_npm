/**
 * Боковое меню навигации
 */

import React from 'react';
import { NavLink } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { selectFilteredServices } from '@/features/service-config';
import { ROUTES } from '@/shared/config';
import styles from './Sidebar.module.scss';

export const Sidebar: React.FC = () => {
  const services = useSelector(selectFilteredServices);

  return (
    <aside className={styles.sidebar}>
      <div className={styles.sidebar__header}>
        <h2 className={styles.sidebar__title}>Admin Panel</h2>
      </div>

      <nav className={styles.sidebar__nav}>
        <NavLink
          to={ROUTES.MAIN}
          className={({ isActive }) =>
            cn(styles.sidebar__link, isActive && styles['sidebar__link--active'])
          }
          end
        >
          <span className={styles['sidebar__link-icon']}>🏠</span>
          <span className={styles['sidebar__link-text']}>Главная</span>
        </NavLink>

        {services.length > 0 && (
          <>
            <div className={styles.sidebar__divider} />
            <div className={styles['sidebar__section-title']}>Сервисы</div>

            {services.map((service) => (
              <NavLink
                key={service.id}
                to={service.route}
                className={({ isActive }) =>
                  cn(styles.sidebar__link, isActive && styles['sidebar__link--active'])
                }
              >
                <span className={styles['sidebar__link-icon']}>{getServiceIcon(service.icon)}</span>
                <span className={styles['sidebar__link-text']}>{service.title}</span>
              </NavLink>
            ))}
          </>
        )}
      </nav>
    </aside>
  );
};

// Маппинг иконок (можно заменить на react-icons или другую библиотеку)
const getServiceIcon = (iconName: string): string => {
  const iconMap: Record<string, string> = {
    PlayCircle: '▶️',
    Calendar: '📅',
    Search: '🔍',
    Database: '💾',
    Server: '🖥️',
    Code: '💻',
    ToggleLeft: '🔀',
    ArrowRightLeft: '↔️',
  };

  return iconMap[iconName] || '📦';
};
