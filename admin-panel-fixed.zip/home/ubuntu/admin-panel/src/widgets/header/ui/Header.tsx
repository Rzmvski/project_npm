/**
 * Шапка приложения
 */

import React from 'react';
import { useSelector } from 'react-redux';
import { selectUserProfile } from '@/entities/user';
import styles from './Header.module.scss';

export const Header: React.FC = () => {
  const userProfile = useSelector(selectUserProfile);

  const displayName = userProfile
    ? `${userProfile.firstName || ''} ${userProfile.lastName || ''}`.trim() || userProfile.username
    : 'Пользователь';

  return (
    <header className={styles.header}>
      <div className={styles.header__content}>
        <div className={styles.header__left}>
          <h1 className={styles['header__page-title']}>Панель администратора</h1>
        </div>

        <div className={styles.header__right}>
          <div className={styles.header__user}>
            <div className={styles['header__user-avatar']}>
              {userProfile?.avatar ? (
                <img src={userProfile.avatar} alt={displayName} />
              ) : (
                <span>{displayName.charAt(0).toUpperCase()}</span>
              )}
            </div>
            <div className={styles['header__user-info']}>
              <div className={styles['header__user-name']}>{displayName}</div>
              <div className={styles['header__user-role']}>Администратор</div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
