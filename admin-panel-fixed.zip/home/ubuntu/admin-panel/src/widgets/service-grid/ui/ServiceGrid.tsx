/**
 * Сетка сервисов на главной странице
 */

import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { selectFilteredServices } from '@/features/service-config';
import { Card } from '@/shared/ui';
import styles from './ServiceGrid.module.scss';

export const ServiceGrid: React.FC = () => {
  const navigate = useNavigate();
  const services = useSelector(selectFilteredServices);

  const handleServiceClick = (route: string) => {
    navigate(route);
  };

  if (services.length === 0) {
    return (
      <div className={styles['service-grid__empty']}>
        <h3>Нет доступных сервисов</h3>
        <p>У вас нет прав доступа ни к одному сервису</p>
      </div>
    );
  }

  return (
    <div className={styles['service-grid']}>
      {services.map((service) => (
        <Card
          key={service.id}
          variant="outlined"
          hoverable
          className={styles['service-card']}
          onClick={() => handleServiceClick(service.route)}
        >
          <div className={styles['service-card__icon']}>{getServiceIcon(service.icon)}</div>
          <h3 className={styles['service-card__title']}>{service.title}</h3>
          <p className={styles['service-card__description']}>{service.description}</p>
        </Card>
      ))}
    </div>
  );
};

// Маппинг иконок
const getServiceIcon = (iconName: string): string => {
  const iconMap: Record<string, string> = {
    PlayCircle: '▶️',
    Calendar: '📅',
    Search: '🔍',
    Database: '💾',
    Server: '🖥️',
    Code: '💻',
    ToggleLeft: '🔀',
    ArrowRightLeft: '↔️',
  };

  return iconMap[iconName] || '📦';
};
