/**
 * Страница: Миграция шардов
 */

import React from 'react';
import { Card } from '@/shared/ui';
import styles from './shard-migration.module.scss';

export const ShardMigrationPage: React.FC = () => {
  return (
    <div className={styles['service-page']}>
      <div className={styles['service-page__header']}>
        <h1 className={styles['service-page__title']}>Миграция шардов</h1>
        <p className={styles['service-page__description']}>
          Функционал сервиса будет реализован здесь
        </p>
      </div>

      <Card variant="outlined" className={styles['service-page__content']}>
        <p>Содержимое страницы "Миграция шардов"</p>
      </Card>
    </div>
  );
};
