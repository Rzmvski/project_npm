/**
 * Страница: Управление узлами и семафорами
 */

import React from 'react';
import { Card } from '@/shared/ui';
import styles from './nodes-semaphores.module.scss';

export const NodesSemaphoresPage: React.FC = () => {
  return (
    <div className={styles['service-page']}>
      <div className={styles['service-page__header']}>
        <h1 className={styles['service-page__title']}>Управление узлами и семафорами</h1>
        <p className={styles['service-page__description']}>
          Функционал сервиса будет реализован здесь
        </p>
      </div>

      <Card variant="outlined" className={styles['service-page__content']}>
        <p>Содержимое страницы "Управление узлами и семафорами"</p>
      </Card>
    </div>
  );
};
