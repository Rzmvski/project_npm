/**
 * Страница отказа в доступе
 */

import React from 'react';
import { Button } from '@/shared/ui';
import styles from './ForbiddenPage.module.scss';

export const ForbiddenPage: React.FC = () => {
  return (
    <div className={styles['forbidden-page']}>
      <div className={styles['forbidden-page__content']}>
        <div className={styles['forbidden-page__icon']}>🚫</div>
        <h1 className="forbidden-page__title">Доступ запрещен</h1>
        <p className={styles['forbidden-page__message']}>
          У вас нет прав доступа к этому приложению.
          <br />
          Для доступа требуется роль администратора.
        </p>
        <p className={styles['forbidden-page__hint']}>
          Если вы считаете, что это ошибка, обратитесь к системному администратору.
        </p>
        <Button onClick={() => window.location.reload()}>
          Обновить страницу
        </Button>
      </div>
    </div>
  );
};
