/**
 * Главная страница с сеткой сервисов
 */

import React from 'react';
import { ServiceGrid } from '@/widgets/service-grid';
import styles from './MainPage.module.scss';

export const MainPage: React.FC = () => {
  return (
    <div className={styles['main-page']}>
      <div className={styles['main-page__header']}>
        <h1 className="main-page__title">Доступные сервисы</h1>
        <p className={styles['main-page__description']}>
          Выберите сервис для работы из списка ниже
        </p>
      </div>

      <ServiceGrid />
    </div>
  );
};
