/**
 * Страница: Поиск контакта
 */

import React from 'react';
import { Card } from '@/shared/ui';
import styles from './contact-search.module.scss';

export const ContactSearchPage: React.FC = () => {
  return (
    <div className={styles['service-page']}>
      <div className={styles['service-page__header']}>
        <h1 className={styles['service-page__title']}>Поиск контакта</h1>
        <p className={styles['service-page__description']}>
          Функционал сервиса будет реализован здесь
        </p>
      </div>

      <Card variant="outlined" className={styles['service-page__content']}>
        <p>Содержимое страницы "Поиск контакта"</p>
      </Card>
    </div>
  );
};
