/**
 * Страница: Запуск Groovy скриптов
 */

import React from 'react';
import { Card } from '@/shared/ui';
import styles from './groovy-scripts.module.scss';

export const GroovyScriptsPage: React.FC = () => {
  return (
    <div className={styles['service-page']}>
      <div className={styles['service-page__header']}>
        <h1 className={styles['service-page__title']}>Запуск Groovy скриптов</h1>
        <p className={styles['service-page__description']}>
          Функционал сервиса будет реализован здесь
        </p>
      </div>

      <Card variant="outlined" className={styles['service-page__content']}>
        <p>Содержимое страницы "Запуск Groovy скриптов"</p>
      </Card>
    </div>
  );
};
