/**
 * Страница: Управление индексами Ignite
 */

import React from 'react';
import { Card } from '@/shared/ui';
import styles from './ignite-indexes.module.scss';

export const IgniteIndexesPage: React.FC = () => {
  return (
    <div className={styles['service-page']}>
      <div className={styles['service-page__header']}>
        <h1 className={styles['service-page__title']}>Управление индексами Ignite</h1>
        <p className={styles['service-page__description']}>
          Функционал сервиса будет реализован здесь
        </p>
      </div>

      <Card variant="outlined" className={styles['service-page__content']}>
        <p>Содержимое страницы "Управление индексами Ignite"</p>
      </Card>
    </div>
  );
};
