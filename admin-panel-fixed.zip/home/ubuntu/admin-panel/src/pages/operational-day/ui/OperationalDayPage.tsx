/**
 * Страница: Операционный день
 */

import React from 'react';
import { Card } from '@/shared/ui';
import styles from './operational-day.module.scss';

export const OperationalDayPage: React.FC = () => {
  return (
    <div className={styles['service-page']}>
      <div className={styles['service-page__header']}>
        <h1 className={styles['service-page__title']}>Операционный день</h1>
        <p className={styles['service-page__description']}>
          Функционал сервиса будет реализован здесь
        </p>
      </div>

      <Card variant="outlined" className={styles['service-page__content']}>
        <p>Содержимое страницы "Операционный день"</p>
      </Card>
    </div>
  );
};
