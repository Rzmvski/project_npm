/**
 * Страница: Управление Feature Toggling
 */

import React from 'react';
import { Card } from '@/shared/ui';
import styles from './feature-toggling.module.scss';

export const FeatureTogglingPage: React.FC = () => {
  return (
    <div className={styles['service-page']}>
      <div className={styles['service-page__header']}>
        <h1 className={styles['service-page__title']}>Управление Feature Toggling</h1>
        <p className={styles['service-page__description']}>
          Функционал сервиса будет реализован здесь
        </p>
      </div>

      <Card variant="outlined" className={styles['service-page__content']}>
        <p>Содержимое страницы "Управление Feature Toggling"</p>
      </Card>
    </div>
  );
};
