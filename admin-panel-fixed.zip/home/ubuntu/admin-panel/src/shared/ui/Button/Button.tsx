/**
 * Компонент кнопки
 */

import React from 'react';
import { cn } from '../../lib';
import styles from './Button.module.scss';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  loading?: boolean;
  fullWidth?: boolean;
}

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  loading = false,
  fullWidth = false,
  disabled,
  className,
  ...props
}) => {
  return (
    <button
      className={cn(
        styles.button,
        styles[`button--${variant}`],
        styles[`button--${size}`],
        fullWidth && styles['button--full-width'],
        loading && styles['button--loading'],
        className
      )}
      disabled={disabled || loading}
      {...props}
    >
      {loading      <span className={styles.button__spinner} />      <span className={styles.button__content}>{children}</span>
    </button>
  );
};
