/**
 * Компонент поля ввода
 */

import React from 'react';
import { cn } from '../../lib';
import styles from './Input.module.scss';

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  fullWidth?: boolean;
}

export const Input: React.FC<InputProps> = ({
  label,
  error,
  fullWidth = false,
  className,
  id,
  ...props
}) => {
  const inputId = id || `input-${Math.random().toString(36).substr(2, 9)}`;

  return (
    <div className={cn(styles['input-wrapper'], fullWidth && styles['input-wrapper--full-width'])}>
      {label && (
        <label htmlFor={inputId} className={styles['input-label']}>
          {label}
        </label>
      )}
        <input
        id={inputId}
        className={cn(styles.input, error && styles['input--error'], className)}
        {...props}
      />
      {error && <span className={styles['input-error']}>{error}</span>}
    </div>
  );
};
