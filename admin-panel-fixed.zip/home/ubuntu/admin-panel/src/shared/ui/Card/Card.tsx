/**
 * Компонент карточки
 */

import React from 'react';
import { cn } from '../../lib';
import styles from './Card.module.scss';

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'default' | 'outlined' | 'elevated';
  padding?: 'none' | 'sm' | 'md' | 'lg';
  hoverable?: boolean;
}

export const Card: React.FC<CardProps> = ({
  children,
  variant = 'default',
  padding = 'md',
  hoverable = false,
  className,
  ...props
}) => {
  return (
    <div
      className={cn(
        styles.card,
        styles[`card--${variant}`],
        styles[`card--padding-${padding}`],
        hoverable && styles['card--hoverable'],
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
};
