/**
 * Компонент индикатора загрузки
 */

import React from 'react';
import { cn } from '../../lib';
import styles from './Spinner.module.scss';

export interface SpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export const Spinner: React.FC<SpinnerProps> = ({ size = 'md', className }) => {
  return (
    <div className={cn(styles.spinner, styles[`spinner--${size}`], className)}>
      <div className={styles.spinner__circle} />
    </div>
  );
};
