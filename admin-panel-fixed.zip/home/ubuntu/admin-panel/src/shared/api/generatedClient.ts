/**
 * ЗАГЛУШКА для клиента, сгенерированного openapi-fetch-generator
 *
 * В реальном проекте этот файл будет сгенерирован автоматически
 * на основе вашей OpenAPI/Swagger спецификации.
 *
 * Пример использования:
 * import { client } from './generatedClient';
 * const { data, error } = await client.GET("/user/current");
 */

import type { UserData, UserRole, PermissionType, ApiResponse } from '../types';

// --- Типы, которые будут сгенерированы ---

// Тип для API-клиента
export interface GeneratedClient {
  GET: <T extends keyof Paths>(url: T, options?: RequestInit) => Promise<{ data: Paths[T]['responses']['200']['content']['application/json'], error: unknown }>;
  // ... другие методы (POST, PUT, DELETE)
}

// Типы путей (Paths)
interface Paths {
  "/user/current": {
    GET: {
      responses: {
        200: {
          content: {
            "application/json": ApiResponse<{
              user: Omit<UserData, 'roles' | 'permissions'>;
              roles: UserRole[];
              permissions: PermissionType[];
            }>;
          };
        };
      };
    };
  };
  // ... другие пути
}

// --- Реализация заглушки ---

const mockUserData: Omit<UserData, 'token'> = {
  id: 'admin-123',
  username: 'admin.user',
  email: 'admin@example.com',
  firstName: 'Иван',
  lastName: 'Админов',
  roles: [UserRole.ADMIN], // Обязательная роль ADMIN
  permissions: [
    PermissionType.PROCESS_GROUPS_VIEW,
    PermissionType.PROCESS_GROUPS_EXECUTE,
    PermissionType.OPERATIONAL_DAY_VIEW,
    PermissionType.OPERATIONAL_DAY_EXECUTE,
    PermissionType.CONTACT_SEARCH_VIEW,
    PermissionType.IGNITE_INDEXES_VIEW,
    PermissionType.IGNITE_INDEXES_MANAGE,
    PermissionType.NODES_SEMAPHORES_VIEW,
    PermissionType.NODES_SEMAPHORES_MANAGE,
    PermissionType.GROOVY_SCRIPTS_VIEW,
    PermissionType.GROOVY_SCRIPTS_EXECUTE,
    PermissionType.FEATURE_TOGGLING_VIEW,
    PermissionType.FEATURE_TOGGLING_MANAGE,
    PermissionType.SHARD_MIGRATION_VIEW,
    PermissionType.SHARD_MIGRATION_EXECUTE,
  ],
};

/**
 * Заглушка сгенерированного клиента openapi-fetch-generator
 */
export const client: GeneratedClient = {
  async GET(url, options) {
    await new Promise(resolve => setTimeout(resolve, 500)); // Имитация задержки сети

    if (url === "/user/current") {
      const responseData = {
        data: {
          user: {
            id: mockUserData.id,
            username: mockUserData.username,
            email: mockUserData.email,
            firstName: mockUserData.firstName,
            lastName: mockUserData.lastName,
          },
          roles: mockUserData.roles,
          permissions: mockUserData.permissions,
        },
        message: "Success",
        success: true,
      };
      
      return { data: responseData as Paths["/user/current"]["GET"]["responses"]["200"]["content"]["application/json"], error: undefined };
    }

    // Имитация 404 для других путей
    return { data: undefined, error: { message: "Not Found", status: 404 } };
  },
  // ... другие методы
};
