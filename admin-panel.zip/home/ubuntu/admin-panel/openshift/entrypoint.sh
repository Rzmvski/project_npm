#!/bin/sh

# Entrypoint скрипт для инициализации приложения в OpenShift

echo "Starting Admin Panel application..."

# Подстановка переменных окружения в nginx конфигурацию
if [ -n "$API_URL" ]; then
    echo "Configuring API proxy to: $API_URL"
    sed -i "s|\${API_URL}|$API_URL|g" /etc/nginx/conf.d/default.conf
else
    echo "API_URL not set, using default"
    sed -i "s|proxy_pass \${API_URL};|# proxy_pass not configured;|g" /etc/nginx/conf.d/default.conf
fi

# Подстановка переменных окружения в runtime конфигурацию приложения
if [ -f /usr/share/nginx/html/config.js ]; then
    echo "Updating runtime configuration..."
    # Здесь можно добавить логику для обновления конфигурации
fi

# Проверка прав доступа
echo "Setting permissions..."
chmod -R 755 /usr/share/nginx/html
chown -R nginx:nginx /usr/share/nginx/html 2>/dev/null || true

echo "Application initialized successfully"

# Запуск nginx
exec "$@"
