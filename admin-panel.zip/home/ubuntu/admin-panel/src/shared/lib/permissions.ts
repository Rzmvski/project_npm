/**
 * Утилиты для работы с пермишенами
 */

import type { PermissionType, UserRole } from '../types';

/**
 * Проверяет наличие пермишена у пользователя
 */
export const hasPermission = (
  userPermissions: PermissionType[],
  requiredPermission: PermissionType
): boolean => {
  return userPermissions.includes(requiredPermission);
};

/**
 * Проверяет наличие хотя бы одного из указанных пермишенов
 */
export const hasAnyPermission = (
  userPermissions: PermissionType[],
  requiredPermissions: PermissionType[]
): boolean => {
  return requiredPermissions.some((permission) =>
    userPermissions.includes(permission)
  );
};

/**
 * Проверяет наличие всех указанных пермишенов
 */
export const hasAllPermissions = (
  userPermissions: PermissionType[],
  requiredPermissions: PermissionType[]
): boolean => {
  return requiredPermissions.every((permission) =>
    userPermissions.includes(permission)
  );
};

/**
 * Проверяет наличие роли у пользователя
 */
export const hasRole = (
  userRoles: UserRole[],
  requiredRole: UserRole
): boolean => {
  return userRoles.includes(requiredRole);
};

/**
 * Проверяет наличие хотя бы одной из указанных ролей
 */
export const hasAnyRole = (
  userRoles: UserRole[],
  requiredRoles: UserRole[]
): boolean => {
  return requiredRoles.some((role) => userRoles.includes(role));
};

/**
 * Проверяет, является ли пользователь администратором
 */
export const isAdmin = (userRoles: UserRole[]): boolean => {
  return hasRole(userRoles, UserRole.ADMIN);
};
