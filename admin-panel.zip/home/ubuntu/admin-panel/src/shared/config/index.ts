/**
 * Конфигурация приложения
 */

// API базовый URL
export const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || '/api';

// Timeout для API запросов (мс)
export const API_TIMEOUT = 30000;

// Путь к JSON конфигурации сервисов
export const SERVICES_CONFIG_PATH = '/services-config.json';

// Роуты приложения
export const ROUTES = {
  MAIN: '/',
  FORBIDDEN: '/forbidden',
  NOT_FOUND: '/404',
  
  // Сервисы
  PROCESS_GROUPS: '/process-groups',
  OPERATIONAL_DAY: '/operational-day',
  CONTACT_SEARCH: '/contact-search',
  IGNITE_INDEXES: '/ignite-indexes',
  NODES_SEMAPHORES: '/nodes-semaphores',
  GROOVY_SCRIPTS: '/groovy-scripts',
  FEATURE_TOGGLING: '/feature-toggling',
  SHARD_MIGRATION: '/shard-migration',
} as const;

// Ключи для localStorage
export const STORAGE_KEYS = {
  AUTH_TOKEN: 'auth_token',
  USER_PREFERENCES: 'user_preferences',
} as const;

// Дефолтная конфигурация сервисов (если JSON не загружен)
export const DEFAULT_SERVICES_CONFIG = {
  services: [
    {
      id: 'process-groups',
      title: 'Запуск группы процессов',
      description: 'Управление группами бизнес-процессов',
      icon: 'PlayCircle',
      permission: 'PROCESS_GROUPS_VIEW',
      route: ROUTES.PROCESS_GROUPS,
      enabled: true,
      order: 1,
    },
    {
      id: 'operational-day',
      title: 'Операционный день',
      description: 'Закрытие операционного дня',
      icon: 'Calendar',
      permission: 'OPERATIONAL_DAY_VIEW',
      route: ROUTES.OPERATIONAL_DAY,
      enabled: true,
      order: 2,
    },
    {
      id: 'contact-search',
      title: 'Поиск контакта',
      description: 'Поиск информации о контактах',
      icon: 'Search',
      permission: 'CONTACT_SEARCH_VIEW',
      route: ROUTES.CONTACT_SEARCH,
      enabled: true,
      order: 3,
    },
    {
      id: 'ignite-indexes',
      title: 'Управление индексами Ignite',
      description: 'Управление индексами Apache Ignite',
      icon: 'Database',
      permission: 'IGNITE_INDEXES_VIEW',
      route: ROUTES.IGNITE_INDEXES,
      enabled: true,
      order: 4,
    },
    {
      id: 'nodes-semaphores',
      title: 'Узлы и семафоры',
      description: 'Управление узлами и семафорами системы',
      icon: 'Server',
      permission: 'NODES_SEMAPHORES_VIEW',
      route: ROUTES.NODES_SEMAPHORES,
      enabled: true,
      order: 5,
    },
    {
      id: 'groovy-scripts',
      title: 'Groovy скрипты',
      description: 'Запуск и управление Groovy скриптами',
      icon: 'Code',
      permission: 'GROOVY_SCRIPTS_VIEW',
      route: ROUTES.GROOVY_SCRIPTS,
      enabled: true,
      order: 6,
    },
    {
      id: 'feature-toggling',
      title: 'Feature Toggling',
      description: 'Управление feature toggles',
      icon: 'ToggleLeft',
      permission: 'FEATURE_TOGGLING_VIEW',
      route: ROUTES.FEATURE_TOGGLING,
      enabled: true,
      order: 7,
    },
    {
      id: 'shard-migration',
      title: 'Миграция шардов',
      description: 'Перенос клиентов между шардами',
      icon: 'ArrowRightLeft',
      permission: 'SHARD_MIGRATION_VIEW',
      route: ROUTES.SHARD_MIGRATION,
      enabled: true,
      order: 8,
    },
  ],
};
