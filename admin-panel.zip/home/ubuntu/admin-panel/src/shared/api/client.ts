/**
 * Базовый HTTP клиент на основе Axios
 */

import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse, AxiosError } from 'axios';
import { API_BASE_URL, API_TIMEOUT, STORAGE_KEYS } from '../config';
import type { ApiResponse, ApiError } from '../types';

// Создание экземпляра axios
const apiClient: AxiosInstance = axios.create({
  baseURL: API_BASE_URL,
  timeout: API_TIMEOUT,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptor для добавления токена аутентификации
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
    
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Interceptor для обработки ответов
apiClient.interceptors.response.use(
  (response: AxiosResponse<ApiResponse>) => {
    return response;
  },
  (error: AxiosError<ApiError>) => {
    // Обработка ошибок
    if (error.response) {
      // Сервер вернул ошибку
      const apiError: ApiError = {
        message: error.response.data?.message || 'Произошла ошибка на сервере',
        code: error.response.status.toString(),
        details: error.response.data?.details,
      };
      
      // Если 401 - пользователь не авторизован
      if (error.response.status === 401) {
        // Можно добавить редирект на страницу логина
        console.error('Unauthorized access');
      }
      
      // Если 403 - нет прав доступа
      if (error.response.status === 403) {
        console.error('Forbidden access');
      }
      
      return Promise.reject(apiError);
    } else if (error.request) {
      // Запрос был отправлен, но ответа не получено
      const apiError: ApiError = {
        message: 'Сервер не отвечает. Проверьте подключение к сети.',
        code: 'NETWORK_ERROR',
      };
      return Promise.reject(apiError);
    } else {
      // Ошибка при настройке запроса
      const apiError: ApiError = {
        message: error.message || 'Неизвестная ошибка',
        code: 'REQUEST_ERROR',
      };
      return Promise.reject(apiError);
    }
  }
);

// Типизированные методы API
export const api = {
  get: <T = unknown>(url: string, config?: AxiosRequestConfig) =>
    apiClient.get<ApiResponse<T>>(url, config),
    
  post: <T = unknown>(url: string, data?: unknown, config?: AxiosRequestConfig) =>
    apiClient.post<ApiResponse<T>>(url, data, config),
    
  put: <T = unknown>(url: string, data?: unknown, config?: AxiosRequestConfig) =>
    apiClient.put<ApiResponse<T>>(url, data, config),
    
  patch: <T = unknown>(url: string, data?: unknown, config?: AxiosRequestConfig) =>
    apiClient.patch<ApiResponse<T>>(url, data, config),
    
  delete: <T = unknown>(url: string, config?: AxiosRequestConfig) =>
    apiClient.delete<ApiResponse<T>>(url, config),
};

export default apiClient;
