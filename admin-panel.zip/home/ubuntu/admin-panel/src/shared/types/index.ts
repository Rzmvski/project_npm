/**
 * Общие типы приложения
 */

// Базовые типы
export type Nullable<T> = T | null;
export type Optional<T> = T | undefined;

// Статусы загрузки
export enum LoadingStatus {
  IDLE = 'idle',
  PENDING = 'pending',
  SUCCEEDED = 'succeeded',
  FAILED = 'failed',
}

// Базовый тип для API ответов
export interface ApiResponse<T = unknown> {
  data: T;
  message?: string;
  success: boolean;
}

// Тип для ошибок API
export interface ApiError {
  message: string;
  code?: string;
  details?: Record<string, unknown>;
}

// Роли пользователя
export enum UserRole {
  ADMIN = 'ADMIN',
  USER = 'USER',
  OPERATOR = 'OPERATOR',
}

// Пермишены системы
export enum Permission {
  // Process Groups
  PROCESS_GROUPS_VIEW = 'PROCESS_GROUPS_VIEW',
  PROCESS_GROUPS_EXECUTE = 'PROCESS_GROUPS_EXECUTE',
  
  // Operational Day
  OPERATIONAL_DAY_VIEW = 'OPERATIONAL_DAY_VIEW',
  OPERATIONAL_DAY_EXECUTE = 'OPERATIONAL_DAY_EXECUTE',
  
  // Contact Search
  CONTACT_SEARCH_VIEW = 'CONTACT_SEARCH_VIEW',
  
  // Ignite Indexes
  IGNITE_INDEXES_VIEW = 'IGNITE_INDEXES_VIEW',
  IGNITE_INDEXES_MANAGE = 'IGNITE_INDEXES_MANAGE',
  
  // Nodes & Semaphores
  NODES_SEMAPHORES_VIEW = 'NODES_SEMAPHORES_VIEW',
  NODES_SEMAPHORES_MANAGE = 'NODES_SEMAPHORES_MANAGE',
  
  // Groovy Scripts
  GROOVY_SCRIPTS_VIEW = 'GROOVY_SCRIPTS_VIEW',
  GROOVY_SCRIPTS_EXECUTE = 'GROOVY_SCRIPTS_EXECUTE',
  
  // Feature Toggling
  FEATURE_TOGGLING_VIEW = 'FEATURE_TOGGLING_VIEW',
  FEATURE_TOGGLING_MANAGE = 'FEATURE_TOGGLING_MANAGE',
  
  // Shard Migration
  SHARD_MIGRATION_VIEW = 'SHARD_MIGRATION_VIEW',
  SHARD_MIGRATION_EXECUTE = 'SHARD_MIGRATION_EXECUTE',
}

// Тип для пермишенов (строка или enum)
export type PermissionType = Permission | string;

// Базовый тип пользователя
export interface User {
  id: string;
  username: string;
  email: string;
  roles: UserRole[];
  permissions: PermissionType[];
  firstName?: string;
  lastName?: string;
  avatar?: string;
}

// Конфигурация сервиса
export interface ServiceConfig {
  id: string;
  title: string;
  description: string;
  icon: string;
  permission: PermissionType;
  route: string;
  enabled: boolean;
  order: number;
  category?: string;
}

// Конфигурация всех сервисов
export interface ServicesConfig {
  services: ServiceConfig[];
}

// Тип для состояния с загрузкой
export interface LoadableState<T> {
  data: Nullable<T>;
  status: LoadingStatus;
  error: Nullable<string>;
}
