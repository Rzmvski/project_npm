/**
 * Компонент индикатора загрузки
 */

import React from 'react';
import { cn } from '../../lib';
import './Spinner.css';

export interface SpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export const Spinner: React.FC<SpinnerProps> = ({ size = 'md', className }) => {
  return (
    <div className={cn('spinner', `spinner--${size}`, className)}>
      <div className="spinner__circle" />
    </div>
  );
};
