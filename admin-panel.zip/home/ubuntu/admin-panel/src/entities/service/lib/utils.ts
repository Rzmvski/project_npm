/**
 * Утилиты для работы с сервисами
 */

import type { Service } from '../model/types';
import type { PermissionType } from '@/shared/types';

/**
 * Фильтрация сервисов по пермишенам пользователя
 */
export const filterServicesByPermissions = (
  services: Service[],
  userPermissions: PermissionType[]
): Service[] => {
  return services
    .filter((service) => service.enabled)
    .filter((service) => userPermissions.includes(service.permission))
    .sort((a, b) => a.order - b.order);
};

/**
 * Группировка сервисов по категориям
 */
export const groupServicesByCategory = (
  services: Service[]
): Record<string, Service[]> => {
  return services.reduce((acc, service) => {
    const category = service.category || 'Общие';
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(service);
    return acc;
  }, {} as Record<string, Service[]>);
};

/**
 * Поиск сервиса по ID
 */
export const findServiceById = (
  services: Service[],
  id: string
): Service | undefined => {
  return services.find((service) => service.id === id);
};

/**
 * Проверка доступности сервиса для пользователя
 */
export const isServiceAvailable = (
  service: Service,
  userPermissions: PermissionType[]
): boolean => {
  return service.enabled && userPermissions.includes(service.permission);
};
