/**
 * Типы для сущности Service
 */

import type { PermissionType, LoadableState } from '@/shared/types';

export interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
  permission: PermissionType;
  route: string;
  enabled: boolean;
  order: number;
  category?: string;
}

export interface ServicesState extends LoadableState<Service[]> {
  filtered: Service[];
}

export enum ServiceId {
  PROCESS_GROUPS = 'process-groups',
  OPERATIONAL_DAY = 'operational-day',
  CONTACT_SEARCH = 'contact-search',
  IGNITE_INDEXES = 'ignite-indexes',
  NODES_SEMAPHORES = 'nodes-semaphores',
  GROOVY_SCRIPTS = 'groovy-scripts',
  FEATURE_TOGGLING = 'feature-toggling',
  SHARD_MIGRATION = 'shard-migration',
}
