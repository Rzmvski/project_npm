/**
 * Константы для пермишенов
 */

import { Permission } from '@/shared/types';

/**
 * Описания пермишенов
 */
export const PERMISSION_DESCRIPTIONS: Record<Permission, string> = {
  [Permission.PROCESS_GROUPS_VIEW]: 'Просмотр групп процессов',
  [Permission.PROCESS_GROUPS_EXECUTE]: 'Запуск групп процессов',
  [Permission.OPERATIONAL_DAY_VIEW]: 'Просмотр операционного дня',
  [Permission.OPERATIONAL_DAY_EXECUTE]: 'Закрытие операционного дня',
  [Permission.CONTACT_SEARCH_VIEW]: 'Поиск контактов',
  [Permission.IGNITE_INDEXES_VIEW]: 'Просмотр индексов Ignite',
  [Permission.IGNITE_INDEXES_MANAGE]: 'Управление индексами Ignite',
  [Permission.NODES_SEMAPHORES_VIEW]: 'Просмотр узлов и семафоров',
  [Permission.NODES_SEMAPHORES_MANAGE]: 'Управление узлами и семафорами',
  [Permission.GROOVY_SCRIPTS_VIEW]: 'Просмотр Groovy скриптов',
  [Permission.GROOVY_SCRIPTS_EXECUTE]: 'Выполнение Groovy скриптов',
  [Permission.FEATURE_TOGGLING_VIEW]: 'Просмотр feature toggles',
  [Permission.FEATURE_TOGGLING_MANAGE]: 'Управление feature toggles',
  [Permission.SHARD_MIGRATION_VIEW]: 'Просмотр миграции шардов',
  [Permission.SHARD_MIGRATION_EXECUTE]: 'Выполнение миграции шардов',
};

/**
 * Группы пермишенов по сервисам
 */
export const PERMISSION_GROUPS = {
  processGroups: [
    Permission.PROCESS_GROUPS_VIEW,
    Permission.PROCESS_GROUPS_EXECUTE,
  ],
  operationalDay: [
    Permission.OPERATIONAL_DAY_VIEW,
    Permission.OPERATIONAL_DAY_EXECUTE,
  ],
  contactSearch: [Permission.CONTACT_SEARCH_VIEW],
  igniteIndexes: [
    Permission.IGNITE_INDEXES_VIEW,
    Permission.IGNITE_INDEXES_MANAGE,
  ],
  nodesSemaphores: [
    Permission.NODES_SEMAPHORES_VIEW,
    Permission.NODES_SEMAPHORES_MANAGE,
  ],
  groovyScripts: [
    Permission.GROOVY_SCRIPTS_VIEW,
    Permission.GROOVY_SCRIPTS_EXECUTE,
  ],
  featureToggling: [
    Permission.FEATURE_TOGGLING_VIEW,
    Permission.FEATURE_TOGGLING_MANAGE,
  ],
  shardMigration: [
    Permission.SHARD_MIGRATION_VIEW,
    Permission.SHARD_MIGRATION_EXECUTE,
  ],
};
