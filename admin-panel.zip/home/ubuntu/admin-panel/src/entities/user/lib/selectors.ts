/**
 * Селекторы для сущности User
 */

import type { RootState } from '@/app/store';
import { UserRole } from '@/shared/types';

export const selectUser = (state: RootState) => state.user.data;

export const selectUserStatus = (state: RootState) => state.user.status;

export const selectUserError = (state: RootState) => state.user.error;

export const selectIsAuthenticated = (state: RootState) => state.user.isAuthenticated;

export const selectUserRoles = (state: RootState) => state.user.data?.roles || [];

export const selectUserPermissions = (state: RootState) => state.user.data?.permissions || [];

export const selectIsAdmin = (state: RootState) => {
  const roles = selectUserRoles(state);
  return roles.includes(UserRole.ADMIN);
};

export const selectUserProfile = (state: RootState) => {
  const user = state.user.data;
  if (!user) return null;
  
  return {
    id: user.id,
    username: user.username,
    email: user.email,
    firstName: user.firstName,
    lastName: user.lastName,
    avatar: user.avatar,
  };
};
