/**
 * API для работы с пользователем
 */

import { api } from '@/shared/api';
import type { UserData } from '../model/types';
import type { UserRole, PermissionType } from '@/shared/types';

export interface FetchUserResponse {
  user: {
    id: string;
    username: string;
    email: string;
    firstName?: string;
    lastName?: string;
    avatar?: string;
  };
  roles: UserRole[];
  permissions: PermissionType[];
}

/**
 * Получить данные текущего пользователя
 */
export const fetchCurrentUser = async (): Promise<UserData> => {
  const response = await api.get<FetchUserResponse>('/user/current');
  
  const { user, roles, permissions } = response.data.data;
  
  return {
    ...user,
    roles,
    permissions,
  };
};

/**
 * Получить роли пользователя
 */
export const fetchUserRoles = async (): Promise<UserRole[]> => {
  const response = await api.get<{ roles: UserRole[] }>('/user/roles');
  return response.data.data.roles;
};

/**
 * Получить пермишены пользователя
 */
export const fetchUserPermissions = async (): Promise<PermissionType[]> => {
  const response = await api.get<{ permissions: PermissionType[] }>('/user/permissions');
  return response.data.data.permissions;
};
