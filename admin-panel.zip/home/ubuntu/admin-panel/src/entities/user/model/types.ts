/**
 * Типы для сущности User
 */

import type { UserRole, PermissionType, LoadableState } from '@/shared/types';

export interface UserProfile {
  id: string;
  username: string;
  email: string;
  firstName?: string;
  lastName?: string;
  avatar?: string;
}

export interface UserAuth {
  roles: UserRole[];
  permissions: PermissionType[];
  token?: string;
}

export interface UserData extends UserProfile, UserAuth {}

export interface UserState extends LoadableState<UserData> {
  isAuthenticated: boolean;
}
