/**
 * Redux slice для сущности User
 */

import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { LoadingStatus } from '@/shared/types';
import type { UserState, UserData } from './types';

const initialState: UserState = {
  data: null,
  status: LoadingStatus.IDLE,
  error: null,
  isAuthenticated: false,
};

export const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    setUser: (state, action: PayloadAction<UserData>) => {
      state.data = action.payload;
      state.isAuthenticated = true;
      state.status = LoadingStatus.SUCCEEDED;
      state.error = null;
    },
    
    setUserLoading: (state) => {
      state.status = LoadingStatus.PENDING;
      state.error = null;
    },
    
    setUserError: (state, action: PayloadAction<string>) => {
      state.status = LoadingStatus.FAILED;
      state.error = action.payload;
      state.isAuthenticated = false;
    },
    
    clearUser: (state) => {
      state.data = null;
      state.isAuthenticated = false;
      state.status = LoadingStatus.IDLE;
      state.error = null;
    },
    
    updateUserPermissions: (state, action: PayloadAction<string[]>) => {
      if (state.data) {
        state.data.permissions = action.payload;
      }
    },
  },
});

export const {
  setUser,
  setUserLoading,
  setUserError,
  clearUser,
  updateUserPermissions,
} = userSlice.actions;

export default userSlice.reducer;
