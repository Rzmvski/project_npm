/**
 * Страница запуска группы процессов
 */

import React, { useState } from 'react';
import { Button, Card, Input } from '@/shared/ui';
import { usePermission } from '@/features/permission-check';
import { Permission } from '@/shared/types';
import './ProcessGroupsPage.css';

export const ProcessGroupsPage: React.FC = () => {
  const canExecute = usePermission(Permission.PROCESS_GROUPS_EXECUTE);
  const [groupName, setGroupName] = useState('');
  const [loading, setLoading] = useState(false);

  const handleExecute = async () => {
    if (!groupName.trim()) {
      alert('Введите название группы процессов');
      return;
    }

    setLoading(true);
    try {
      // Здесь будет вызов API для запуска группы процессов
      await new Promise((resolve) => setTimeout(resolve, 2000));
      alert(`Группа процессов "${groupName}" успешно запущена`);
      setGroupName('');
    } catch (error) {
      alert('Ошибка при запуске группы процессов');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="service-page">
      <div className="service-page__header">
        <h1 className="service-page__title">Запуск группы процессов</h1>
        <p className="service-page__description">
          Управление группами бизнес-процессов системы
        </p>
      </div>

      <Card variant="outlined" className="service-page__content">
        <div className="service-page__form">
          <Input
            label="Название группы процессов"
            placeholder="Введите название группы"
            value={groupName}
            onChange={(e) => setGroupName(e.target.value)}
            fullWidth
          />

          <Button
            onClick={handleExecute}
            disabled={!canExecute || loading}
            loading={loading}
            fullWidth
          >
            {canExecute ? 'Запустить' : 'Нет прав на выполнение'}
          </Button>
        </div>
      </Card>
    </div>
  );
};
