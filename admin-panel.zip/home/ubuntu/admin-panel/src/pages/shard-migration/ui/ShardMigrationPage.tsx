/**
 * Страница: Миграция шардов
 */

import React from 'react';
import { Card } from '@/shared/ui';

export const ShardMigrationPage: React.FC = () => {
  return (
    <div className="service-page">
      <div className="service-page__header">
        <h1 className="service-page__title">Миграция шардов</h1>
        <p className="service-page__description">
          Функционал сервиса будет реализован здесь
        </p>
      </div>

      <Card variant="outlined" className="service-page__content">
        <p>Содержимое страницы "Миграция шардов"</p>
      </Card>
    </div>
  );
};
