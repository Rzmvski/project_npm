/**
 * Главная страница с сеткой сервисов
 */

import React from 'react';
import { ServiceGrid } from '@/widgets/service-grid';
import './MainPage.css';

export const MainPage: React.FC = () => {
  return (
    <div className="main-page">
      <div className="main-page__header">
        <h1 className="main-page__title">Доступные сервисы</h1>
        <p className="main-page__description">
          Выберите сервис для работы из списка ниже
        </p>
      </div>

      <ServiceGrid />
    </div>
  );
};
