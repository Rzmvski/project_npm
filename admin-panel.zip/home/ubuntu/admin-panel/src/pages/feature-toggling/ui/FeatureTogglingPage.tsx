/**
 * Страница: Управление Feature Toggling
 */

import React from 'react';
import { Card } from '@/shared/ui';

export const FeatureTogglingPage: React.FC = () => {
  return (
    <div className="service-page">
      <div className="service-page__header">
        <h1 className="service-page__title">Управление Feature Toggling</h1>
        <p className="service-page__description">
          Функционал сервиса будет реализован здесь
        </p>
      </div>

      <Card variant="outlined" className="service-page__content">
        <p>Содержимое страницы "Управление Feature Toggling"</p>
      </Card>
    </div>
  );
};
