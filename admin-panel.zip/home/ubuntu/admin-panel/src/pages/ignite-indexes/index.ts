export { IgniteIndexesPage } from './ui/IgniteIndexesPage';
