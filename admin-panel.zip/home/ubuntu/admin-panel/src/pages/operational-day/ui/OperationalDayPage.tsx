/**
 * Страница: Операционный день
 */

import React from 'react';
import { Card } from '@/shared/ui';

export const OperationalDayPage: React.FC = () => {
  return (
    <div className="service-page">
      <div className="service-page__header">
        <h1 className="service-page__title">Операционный день</h1>
        <p className="service-page__description">
          Функционал сервиса будет реализован здесь
        </p>
      </div>

      <Card variant="outlined" className="service-page__content">
        <p>Содержимое страницы "Операционный день"</p>
      </Card>
    </div>
  );
};
