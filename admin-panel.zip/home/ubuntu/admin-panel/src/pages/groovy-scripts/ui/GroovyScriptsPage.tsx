/**
 * Страница: Запуск Groovy скриптов
 */

import React from 'react';
import { Card } from '@/shared/ui';

export const GroovyScriptsPage: React.FC = () => {
  return (
    <div className="service-page">
      <div className="service-page__header">
        <h1 className="service-page__title">Запуск Groovy скриптов</h1>
        <p className="service-page__description">
          Функционал сервиса будет реализован здесь
        </p>
      </div>

      <Card variant="outlined" className="service-page__content">
        <p>Содержимое страницы "Запуск Groovy скриптов"</p>
      </Card>
    </div>
  );
};
