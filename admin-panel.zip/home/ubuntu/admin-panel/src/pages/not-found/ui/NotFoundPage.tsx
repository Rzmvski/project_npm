/**
 * Страница 404
 */

import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/shared/ui';
import { ROUTES } from '@/shared/config';
import './NotFoundPage.css';

export const NotFoundPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="not-found-page">
      <div className="not-found-page__content">
        <div className="not-found-page__code">404</div>
        <h1 className="not-found-page__title">Страница не найдена</h1>
        <p className="not-found-page__message">
          Запрашиваемая страница не существует или была удалена.
        </p>
        <Button onClick={() => navigate(ROUTES.MAIN)}>
          Вернуться на главную
        </Button>
      </div>
    </div>
  );
};
