/**
 * Страница: Управление узлами и семафорами
 */

import React from 'react';
import { Card } from '@/shared/ui';

export const NodesSemaphoresPage: React.FC = () => {
  return (
    <div className="service-page">
      <div className="service-page__header">
        <h1 className="service-page__title">Управление узлами и семафорами</h1>
        <p className="service-page__description">
          Функционал сервиса будет реализован здесь
        </p>
      </div>

      <Card variant="outlined" className="service-page__content">
        <p>Содержимое страницы "Управление узлами и семафорами"</p>
      </Card>
    </div>
  );
};
