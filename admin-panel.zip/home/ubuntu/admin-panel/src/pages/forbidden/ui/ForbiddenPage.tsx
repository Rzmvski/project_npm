/**
 * Страница отказа в доступе
 */

import React from 'react';
import { Button } from '@/shared/ui';
import './ForbiddenPage.css';

export const ForbiddenPage: React.FC = () => {
  return (
    <div className="forbidden-page">
      <div className="forbidden-page__content">
        <div className="forbidden-page__icon">🚫</div>
        <h1 className="forbidden-page__title">Доступ запрещен</h1>
        <p className="forbidden-page__message">
          У вас нет прав доступа к этому приложению.
          <br />
          Для доступа требуется роль администратора.
        </p>
        <p className="forbidden-page__hint">
          Если вы считаете, что это ошибка, обратитесь к системному администратору.
        </p>
        <Button onClick={() => window.location.reload()}>
          Обновить страницу
        </Button>
      </div>
    </div>
  );
};
