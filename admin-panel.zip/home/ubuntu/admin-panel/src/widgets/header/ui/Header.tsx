/**
 * Шапка приложения
 */

import React from 'react';
import { useSelector } from 'react-redux';
import { selectUserProfile } from '@/entities/user';
import './Header.css';

export const Header: React.FC = () => {
  const userProfile = useSelector(selectUserProfile);

  const displayName = userProfile
    ? `${userProfile.firstName || ''} ${userProfile.lastName || ''}`.trim() || userProfile.username
    : 'Пользователь';

  return (
    <header className="header">
      <div className="header__content">
        <div className="header__left">
          <h1 className="header__page-title">Панель администратора</h1>
        </div>

        <div className="header__right">
          <div className="header__user">
            <div className="header__user-avatar">
              {userProfile?.avatar ? (
                <img src={userProfile.avatar} alt={displayName} />
              ) : (
                <span>{displayName.charAt(0).toUpperCase()}</span>
              )}
            </div>
            <div className="header__user-info">
              <div className="header__user-name">{displayName}</div>
              <div className="header__user-role">Администратор</div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
