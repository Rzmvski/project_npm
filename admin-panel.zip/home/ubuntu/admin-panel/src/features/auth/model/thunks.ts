/**
 * Thunks для авторизации
 */

import { createAsyncThunk } from '@reduxjs/toolkit';
import { fetchCurrentUser } from '@/entities/user';
import { setUser, setUserLoading, setUserError } from '@/entities/user';
import type { UserData } from '@/entities/user';

/**
 * Инициализация пользователя при загрузке приложения
 */
export const initializeAuth = createAsyncThunk<UserData, void>(
  'auth/initialize',
  async (_, { dispatch, rejectWithValue }) => {
    try {
      dispatch(setUserLoading());
      const userData = await fetchCurrentUser();
      dispatch(setUser(userData));
      return userData;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Ошибка авторизации';
      dispatch(setUserError(errorMessage));
      return rejectWithValue(errorMessage);
    }
  }
);
