/**
 * Компонент для проверки роли пользователя
 */

import React, { useEffect } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { selectIsAdmin, selectUserStatus } from '@/entities/user';
import { LoadingStatus } from '@/shared/types';
import { Spinner } from '@/shared/ui';
import { ROUTES } from '@/shared/config';

interface RoleGuardProps {
  children: React.ReactNode;
  fallbackPath?: string;
}

/**
 * Guard для проверки наличия роли ADMIN
 * Если роли нет - редирект на страницу запрета доступа
 */
export const RoleGuard: React.FC<RoleGuardProps> = ({
  children,
  fallbackPath = ROUTES.FORBIDDEN,
}) => {
  const navigate = useNavigate();
  const isAdmin = useSelector(selectIsAdmin);
  const userStatus = useSelector(selectUserStatus);

  useEffect(() => {
    // Если данные загружены и пользователь не админ - редирект
    if (userStatus === LoadingStatus.SUCCEEDED && !isAdmin) {
      navigate(fallbackPath, { replace: true });
    }
  }, [isAdmin, userStatus, navigate, fallbackPath]);

  // Показываем загрузку пока данные пользователя загружаются
  if (userStatus === LoadingStatus.PENDING || userStatus === LoadingStatus.IDLE) {
    return (
      <div style={{ 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center', 
        height: '100vh' 
      }}>
        <Spinner size="lg" />
      </div>
    );
  }

  // Если произошла ошибка при загрузке
  if (userStatus === LoadingStatus.FAILED) {
    return (
      <div style={{ 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center', 
        height: '100vh',
        flexDirection: 'column',
        gap: '16px'
      }}>
        <h2>Ошибка загрузки данных пользователя</h2>
        <p>Пожалуйста, обновите страницу</p>
      </div>
    );
  }

  // Если пользователь админ - показываем контент
  if (isAdmin) {
    return <>{children}</>;
  }

  // В остальных случаях ничего не показываем (идет редирект)
  return null;
};
