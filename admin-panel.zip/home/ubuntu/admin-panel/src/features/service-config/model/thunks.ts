/**
 * Thunks для конфигурации сервисов
 */

import { createAsyncThunk } from '@reduxjs/toolkit';
import { fetchServicesConfig } from '../api/serviceConfigApi';
import { setServices, setServicesLoading, setServicesError, setFilteredServices } from './slice';
import { filterServicesByPermissions } from '@/entities/service';
import type { Service } from '@/entities/service';
import type { PermissionType } from '@/shared/types';
import type { RootState } from '@/app/store';

/**
 * Загрузка конфигурации сервисов
 */
export const loadServicesConfig = createAsyncThunk<Service[], void>(
  'serviceConfig/load',
  async (_, { dispatch, rejectWithValue }) => {
    try {
      dispatch(setServicesLoading());
      const services = await fetchServicesConfig();
      dispatch(setServices(services));
      return services;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Ошибка загрузки конфигурации';
      dispatch(setServicesError(errorMessage));
      return rejectWithValue(errorMessage);
    }
  }
);

/**
 * Фильтрация сервисов по пермишенам пользователя
 */
export const filterServices = createAsyncThunk<Service[], PermissionType[]>(
  'serviceConfig/filter',
  async (userPermissions, { dispatch, getState }) => {
    const state = getState() as RootState;
    const allServices = state.serviceConfig.data || [];
    
    const filtered = filterServicesByPermissions(allServices, userPermissions);
    dispatch(setFilteredServices(filtered));
    
    return filtered;
  }
);
