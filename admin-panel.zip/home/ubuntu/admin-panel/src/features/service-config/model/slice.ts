/**
 * Redux slice для конфигурации сервисов
 */

import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { LoadingStatus } from '@/shared/types';
import type { Service, ServicesState } from '@/entities/service';

const initialState: ServicesState = {
  data: null,
  filtered: [],
  status: LoadingStatus.IDLE,
  error: null,
};

export const serviceConfigSlice = createSlice({
  name: 'serviceConfig',
  initialState,
  reducers: {
    setServices: (state, action: PayloadAction<Service[]>) => {
      state.data = action.payload;
      state.status = LoadingStatus.SUCCEEDED;
      state.error = null;
    },
    
    setServicesLoading: (state) => {
      state.status = LoadingStatus.PENDING;
      state.error = null;
    },
    
    setServicesError: (state, action: PayloadAction<string>) => {
      state.status = LoadingStatus.FAILED;
      state.error = action.payload;
    },
    
    setFilteredServices: (state, action: PayloadAction<Service[]>) => {
      state.filtered = action.payload;
    },
    
    updateService: (state, action: PayloadAction<Service>) => {
      if (state.data) {
        const index = state.data.findIndex((s) => s.id === action.payload.id);
        if (index !== -1) {
          state.data[index] = action.payload;
        }
      }
    },
  },
});

export const {
  setServices,
  setServicesLoading,
  setServicesError,
  setFilteredServices,
  updateService,
} = serviceConfigSlice.actions;

export default serviceConfigSlice.reducer;
