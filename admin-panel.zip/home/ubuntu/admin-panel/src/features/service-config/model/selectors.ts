/**
 * Селекторы для конфигурации сервисов
 */

import type { RootState } from '@/app/store';

export const selectAllServices = (state: RootState) => state.serviceConfig.data || [];

export const selectFilteredServices = (state: RootState) => state.serviceConfig.filtered;

export const selectServicesStatus = (state: RootState) => state.serviceConfig.status;

export const selectServicesError = (state: RootState) => state.serviceConfig.error;
