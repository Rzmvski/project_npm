export { default as serviceConfigReducer } from './model/slice';
export * from './model/slice';
export * from './model/thunks';
export * from './model/selectors';
