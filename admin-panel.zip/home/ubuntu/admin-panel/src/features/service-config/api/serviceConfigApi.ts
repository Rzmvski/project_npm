/**
 * API для загрузки конфигурации сервисов
 */

import axios from 'axios';
import { SERVICES_CONFIG_PATH, DEFAULT_SERVICES_CONFIG } from '@/shared/config';
import type { Service } from '@/entities/service';

interface ServicesConfigResponse {
  services: Service[];
}

/**
 * Загрузка конфигурации сервисов из JSON файла
 * Если файл не найден или произошла ошибка - используется дефолтная конфигурация
 */
export const fetchServicesConfig = async (): Promise<Service[]> => {
  try {
    const response = await axios.get<ServicesConfigResponse>(SERVICES_CONFIG_PATH);
    return response.data.services;
  } catch (error) {
    console.warn('Не удалось загрузить services-config.json, используется дефолтная конфигурация');
    return DEFAULT_SERVICES_CONFIG.services;
  }
};
