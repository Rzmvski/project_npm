/**
 * Хук для проверки пермишенов
 */

import { useSelector } from 'react-redux';
import { selectUserPermissions } from '@/entities/user';
import { hasPermission, hasAnyPermission, hasAllPermissions } from '@/shared/lib';
import type { PermissionType } from '@/shared/types';

/**
 * Проверяет наличие конкретного пермишена
 */
export const usePermission = (permission: PermissionType): boolean => {
  const userPermissions = useSelector(selectUserPermissions);
  return hasPermission(userPermissions, permission);
};

/**
 * Проверяет наличие хотя бы одного из указанных пермишенов
 */
export const useAnyPermission = (permissions: PermissionType[]): boolean => {
  const userPermissions = useSelector(selectUserPermissions);
  return hasAnyPermission(userPermissions, permissions);
};

/**
 * Проверяет наличие всех указанных пермишенов
 */
export const useAllPermissions = (permissions: PermissionType[]): boolean => {
  const userPermissions = useSelector(selectUserPermissions);
  return hasAllPermissions(userPermissions, permissions);
};

/**
 * Возвращает все пермишены пользователя
 */
export const useUserPermissions = (): PermissionType[] => {
  return useSelector(selectUserPermissions);
};
