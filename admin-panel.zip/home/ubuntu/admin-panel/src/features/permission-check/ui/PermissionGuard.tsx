/**
 * Компонент для проверки пермишенов
 */

import React from 'react';
import type { PermissionType } from '@/shared/types';
import { usePermission, useAnyPermission, useAllPermissions } from '../lib/usePermission';

interface PermissionGuardProps {
  children: React.ReactNode;
  permission?: PermissionType;
  anyPermissions?: PermissionType[];
  allPermissions?: PermissionType[];
  fallback?: React.ReactNode;
}

/**
 * Guard для проверки пермишенов
 * Показывает контент только если у пользователя есть необходимые пермишены
 */
export const PermissionGuard: React.FC<PermissionGuardProps> = ({
  children,
  permission,
  anyPermissions,
  allPermissions,
  fallback = null,
}) => {
  const hasSinglePermission = usePermission(permission || '');
  const hasAny = useAnyPermission(anyPermissions || []);
  const hasAll = useAllPermissions(allPermissions || []);

  let hasAccess = false;

  if (permission) {
    hasAccess = hasSinglePermission;
  } else if (anyPermissions && anyPermissions.length > 0) {
    hasAccess = hasAny;
  } else if (allPermissions && allPermissions.length > 0) {
    hasAccess = hasAll;
  }

  if (!hasAccess) {
    return <>{fallback}</>;
  }

  return <>{children}</>;
};
