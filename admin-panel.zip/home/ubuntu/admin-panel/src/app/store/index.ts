/**
 * Конфигурация Redux Store
 */

import { configureStore } from '@reduxjs/toolkit';
import { userReducer } from '@/entities/user';
import { serviceConfigReducer } from '@/features/service-config';

export const store = configureStore({
  reducer: {
    user: userReducer,
    serviceConfig: serviceConfigReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        // Игнорируем проверку сериализуемости для некоторых actions если нужно
        ignoredActions: [],
      },
    }),
  devTools: process.env.NODE_ENV !== 'production',
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
