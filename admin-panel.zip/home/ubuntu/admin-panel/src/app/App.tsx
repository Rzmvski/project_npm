/**
 * Корневой компонент приложения
 */

import React from 'react';
import { AppProviders } from './providers';
import { AppRoutes } from './routes';
import './styles/global.css';

export const App: React.FC = () => {
  return (
    <AppProviders>
      <AppRoutes />
    </AppProviders>
  );
};
