/**
 * Конфигурация роутинга приложения
 */

import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { ROUTES } from '@/shared/config';

// Pages
import { MainPage } from '@/pages/main';
import { ForbiddenPage } from '@/pages/forbidden';
import { NotFoundPage } from '@/pages/not-found';
import { ProcessGroupsPage } from '@/pages/process-groups';
import { OperationalDayPage } from '@/pages/operational-day';
import { ContactSearchPage } from '@/pages/contact-search';
import { IgniteIndexesPage } from '@/pages/ignite-indexes';
import { NodesSemaphoresPage } from '@/pages/nodes-semaphores';
import { GroovyScriptsPage } from '@/pages/groovy-scripts';
import { FeatureTogglingPage } from '@/pages/feature-toggling';
import { ShardMigrationPage } from '@/pages/shard-migration';

// Features
import { RoleGuard } from '@/features/role-guard';

// Layout
import { AppLayout } from '../layouts/AppLayout';

export const AppRoutes: React.FC = () => {
  return (
    <Routes>
      {/* Публичный роут для страницы Forbidden */}
      <Route path={ROUTES.FORBIDDEN} element={<ForbiddenPage />} />

      {/* Защищенные роуты (требуется роль ADMIN) */}
      <Route
        path="/"
        element={
          <RoleGuard>
            <AppLayout />
          </RoleGuard>
        }
      >
        <Route index element={<MainPage />} />
        <Route path={ROUTES.PROCESS_GROUPS} element={<ProcessGroupsPage />} />
        <Route path={ROUTES.OPERATIONAL_DAY} element={<OperationalDayPage />} />
        <Route path={ROUTES.CONTACT_SEARCH} element={<ContactSearchPage />} />
        <Route path={ROUTES.IGNITE_INDEXES} element={<IgniteIndexesPage />} />
        <Route path={ROUTES.NODES_SEMAPHORES} element={<NodesSemaphoresPage />} />
        <Route path={ROUTES.GROOVY_SCRIPTS} element={<GroovyScriptsPage />} />
        <Route path={ROUTES.FEATURE_TOGGLING} element={<FeatureTogglingPage />} />
        <Route path={ROUTES.SHARD_MIGRATION} element={<ShardMigrationPage />} />
        <Route path={ROUTES.NOT_FOUND} element={<NotFoundPage />} />
        <Route path="*" element={<Navigate to={ROUTES.NOT_FOUND} replace />} />
      </Route>
    </Routes>
  );
};
