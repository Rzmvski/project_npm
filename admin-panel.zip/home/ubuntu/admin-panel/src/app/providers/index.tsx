/**
 * Композиция всех провайдеров приложения
 */

import React from 'react';
import { ReduxProvider } from './ReduxProvider';
import { RouterProvider } from './RouterProvider';
import { AppInitProvider } from './AppInitProvider';

interface AppProvidersProps {
  children: React.ReactNode;
}

export const AppProviders: React.FC<AppProvidersProps> = ({ children }) => {
  return (
    <ReduxProvider>
      <RouterProvider>
        <AppInitProvider>
          {children}
        </AppInitProvider>
      </RouterProvider>
    </ReduxProvider>
  );
};
