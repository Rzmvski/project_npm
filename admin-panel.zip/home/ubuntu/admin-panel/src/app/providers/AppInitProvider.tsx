/**
 * Провайдер инициализации приложения
 */

import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { initializeAuth } from '@/features/auth';
import { loadServicesConfig, filterServices } from '@/features/service-config';
import { selectUserPermissions } from '@/entities/user';
import { useAppSelector } from '../store/hooks';
import type { AppDispatch } from '../store';

interface AppInitProviderProps {
  children: React.ReactNode;
}

export const AppInitProvider: React.FC<AppInitProviderProps> = ({ children }) => {
  const dispatch = useDispatch<AppDispatch>();
  const userPermissions = useAppSelector(selectUserPermissions);

  useEffect(() => {
    // Инициализация пользователя
    dispatch(initializeAuth());
    
    // Загрузка конфигурации сервисов
    dispatch(loadServicesConfig());
  }, [dispatch]);

  useEffect(() => {
    // Фильтрация сервисов при изменении пермишенов
    if (userPermissions.length > 0) {
      dispatch(filterServices(userPermissions));
    }
  }, [dispatch, userPermissions]);

  return <>{children}</>;
};
