#!/bin/bash

# Массив с названиями сервисов
declare -A services=(
  ["operational-day"]="Операционный день"
  ["contact-search"]="Поиск контакта"
  ["ignite-indexes"]="Управление индексами Ignite"
  ["nodes-semaphores"]="Управление узлами и семафорами"
  ["groovy-scripts"]="Запуск Groovy скриптов"
  ["feature-toggling"]="Управление Feature Toggling"
  ["shard-migration"]="Миграция шардов"
)

for key in "${!services[@]}"; do
  title="${services[$key]}"
  component_name=$(echo "$key" | sed -r 's/(^|-)(\w)/\U\2/g')Page
  
  # Создаем компонент страницы
  cat > "/home/ubuntu/admin-panel/src/pages/${key}/ui/${component_name}.tsx" << EOPAGE
/**
 * Страница: ${title}
 */

import React from 'react';
import { Card } from '@/shared/ui';

export const ${component_name}: React.FC = () => {
  return (
    <div className="service-page">
      <div className="service-page__header">
        <h1 className="service-page__title">${title}</h1>
        <p className="service-page__description">
          Функционал сервиса будет реализован здесь
        </p>
      </div>

      <Card variant="outlined" className="service-page__content">
        <p>Содержимое страницы "${title}"</p>
      </Card>
    </div>
  );
};
EOPAGE

  # Создаем index.ts
  cat > "/home/ubuntu/admin-panel/src/pages/${key}/index.ts" << EOINDEX
export { ${component_name} } from './ui/${component_name}';
EOINDEX

done

echo "Страницы сервисов созданы"
