---
name: security-review
description: Security review of pending changes on the current branch or a given diff — XSS, unsafe HTML, token and secret handling, authorization gaps in routes and guards, unsafe URL construction, dependency risks. Read-only; reports only concrete, exploitable findings.
priority: 10
---

# Security review

Review only the changed scope: `git diff` against the base branch, or the files/diff the user names. Do not modify files.

## Gather

1. `git status`, `git diff --stat <base>...HEAD` and the full diff of changed files.
2. Read `GIGACODE.md` and the direct dependencies needed to confirm a finding (guards, SDK wrappers, `shared/lib`).

## Check

- **Injection / XSS**: `dangerouslySetInnerHTML`, `innerHTML`, `eval`, `new Function`, `href`/`src` from user or API data without scheme check (`javascript:`).
- **Secrets**: tokens, passwords, internal hosts or keys in code, `.env*`, mock data, logs or error messages; secrets in URL query strings.
- **Auth / access**: routes and actions without the permission guard; UI hiding used instead of an access check; role checks by display name.
- **Requests**: URLs built by string concatenation instead of SDK/`*ApiSse`; unvalidated redirects; credentials sent to non-project hosts.
- **Data exposure**: sensitive fields rendered, cached in TanStack Query longer than needed, or written to `localStorage`/`sessionStorage`.
- **Dependencies**: new or bumped packages in `package.json`/lockfile — name typosquatting, install scripts, unpinned sources (`git+`, `file:` outside the known temporary SDK path).
- **Mock server**: code in `mock-server/` that could leak into production bundle.

Ignore style, theoretical issues without an attack path, and pre-existing code outside the diff.

## Report

For each finding: severity (high/medium/low), `file:line`, attack scenario (input → impact), and the minimal fix. Finish with:

```text
VERDICT: pass | changes_requested
FINDINGS: <count by severity or none>
```
