---
name: verify-in-browser
description: Launch the app with the mock API and verify a UI change in a real browser through the playwright MCP server — render, console errors, network, interactions, responsive layout — then report proof. Use after any change visible in the browser.
priority: 10
---

# Verify in browser

Use when a change is observable in the browser (component, SCSS, route, mock API response). Skip for types, tests or tooling — run commands instead.

## Steps

1. **Server.** Check whether the dev server is already running (`curl -s -o /dev/null -w '%{http_code}' http://localhost:5173`). If not, start `pnpm run dev`
   (Vite on `5173` + mock API on `3001`) as a background process and wait until the port responds. Do not start a second copy.
2. **Open.** `browser_navigate` to the affected route. Use `browser_snapshot` (accessibility tree) to read text and structure — prefer it over screenshots.
3. **Errors.** `browser_console_messages` and `browser_network_requests`: no uncaught errors, no failed requests to the mock API caused by the change.
4. **Interact.** Exercise the changed scenario with `browser_click` / `browser_type` / `browser_fill_form`, then `browser_snapshot` to confirm the result, including
   loading/empty/error/pending states where applicable. To reset mock state: `curl -X POST http://127.0.0.1:3001/__mock/reset`.
5. **Layout.** For layout or style changes use `browser_resize` (e.g. 1440×900 and 1024×768) and check the page next to the sidebar with long Russian strings.
6. **Fix loop.** If something is wrong, read the source, fix it, reload and repeat from step 3.
7. **Proof.** `browser_take_screenshot` of the final state for visual changes; for API changes cite the relevant network request.

`browser_evaluate` is for inspection only (computed styles, DOM state) — never implement the fix through it.

## Report

Route checked, scenario performed, console/network result, screenshot or request as evidence, and anything not verified with the reason. Leave the dev server
running only if the user is actively working with it; otherwise stop the process you started.
