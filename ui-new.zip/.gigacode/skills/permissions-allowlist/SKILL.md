---
name: permissions-allowlist
description: Reduce repeated confirmation prompts by adding safe read-only and project-script shell commands to the permissions allowlist in .gigacode/settings.json. Use when the user complains about too many approval prompts or asks to allow a command.
priority: 5
---

# Permissions allowlist

1. Read `.gigacode/settings.json` (project) and, if present, `~/.gigacode/settings.json` (user). Preserve all existing keys, including `$version`.
2. Collect candidate commands: those the user named, plus shell commands repeatedly approved in this session.
3. Allow only commands that are read-only or run project scripts:
   - OK: `pnpm run *`, `pnpm test`, `pnpm exec tsgo *`, `pnpm exec vitest *`, `pnpm exec eslint *`, `pnpm exec stylelint *`, `pnpm exec prettier --check *`, `pnpm exec steiger *`,
     `git status`, `git diff *`, `git log *`, `ls *`, `cat *`, `rg *`.
   - Never: `rm`, `git push`, `git reset`, `git checkout`, `pnpm add`/`pnpm install`/`pnpm publish`, `curl` with POST to non-local hosts, `sudo`, broad `Bash(*)`, `node *`,
     `python3 *`, `cd *` (they allow arbitrary code).
4. Use the existing pattern format: `"Bash(<command prefix> *)"`. Do not duplicate entries already covered by a wider pattern.
5. Show the diff of `settings.json` and say which scope (project vs user) was changed. Project scope is shared with the team through git.
