import { execFileSync } from 'node:child_process'
import console from 'node:console'
import { existsSync } from 'node:fs'
import process from 'node:process'

if (process.env.CI || process.env.HUSKY === '0') {
  process.exit(0)
}

if (!existsSync('.git')) {
  console.info('Husky setup skipped: .git directory was not found.')
  process.exit(0)
}

const pnpmExecutable = process.platform === 'win32' ? 'pnpm.cmd' : 'pnpm'
execFileSync(pnpmExecutable, ['exec', 'husky'], { stdio: 'inherit' })
