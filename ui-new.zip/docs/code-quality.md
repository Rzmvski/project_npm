# Code quality guide

## Команды

| Команда                      | Что проверяет                               |
| ---------------------------- | ------------------------------------------- |
| `pnpm run format:check`      | Форматирование исходников и docs            |
| `pnpm run lint:eslint`       | TypeScript, imports, hooks и FSD boundaries |
| `pnpm run lint:styles`       | SCSS через Stylelint 16                     |
| `pnpm run lint`              | ESLint + Stylelint + Prettier               |
| `pnpm run lint:architecture` | FSD через Steiger                           |
| `pnpm run typecheck`         | `tsgo --noEmit` для app и node              |
| `pnpm test`                  | Vitest run, не более двух workers           |
| `pnpm run test:coverage`     | Vitest с coverage                           |
| `pnpm run build`             | typecheck + production Vite bundle          |
| `pnpm run check`             | Полная последовательность проверок          |

`build` сначала запускает typecheck и падает на ошибках типов. Если полный baseline не зелёный, в отчёте отдельно указываются существующие ошибки и новые regressions с командами, которыми они воспроизведены.

## Обязательные правила

- Не подавлять TypeScript/ESLint без локального объяснения; предпочитать `@ts-expect-error` с причиной.
- Не оставлять `console.log`, тестовые данные и временные feature flags в production-коде.
- Не импортировать `src/*` из npm-пакетов и внутренности чужого slice.
- Hooks вызываются только в компонентах или custom hooks, не в произвольных table callbacks.
- Async effect должен иметь cleanup/abort, если результат может прийти после unmount.
- Ошибка API не маскируется успешным fallback без проверки причины.
- Форматирование большого legacy-массива выполняется отдельным изменением.

## Git hooks

- `pre-commit` запускает `pnpm run lint:staged`.
- `commit-msg` запускает Commitlint с conventional config.
- `pre-push` намеренно отсутствует: полный Vitest, typecheck, build и архитектурный анализ слишком медленные или нестабильные для каждого push.

Hooks должны давать обратную связь за секунды и проверять только локально изменяемый контекст. Vitest и production build выполняются в Docker/CI; focused-тесты разработчик запускает перед commit по таблице из `validation.md`. Полный `pnpm run validate` используется для cross-cutting изменений и как целевой quality gate после устранения известных baseline-ошибок.

`prepare` устанавливает Husky только внутри git-репозитория. При изменении hooks одновременно обновляются `code-quality.md` и `validation.md`.
