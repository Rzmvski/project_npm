export { ManageFeatureApplicationsTab } from './ui'
