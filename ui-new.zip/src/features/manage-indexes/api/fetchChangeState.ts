import {
  type IndexActionResponseDto,
  type IndexActionsDto,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { zoneIndexService } from '@/shared/api'
import { randomUuid } from '@/shared/lib/browser'

const generateUid = () => randomUuid().replace(/-/g, '')

export function fetchChangeState(
  clusterId: string,
  action: IndexActionsDto,
): Promise<IndexActionResponseDto> {
  const rqUid = generateUid()
  return zoneIndexService.indexesExecute({
    actionRequest: {
      clusterId,
      action,
    },
    rqUid,
    rqTm: new Date(),
    auditInfo: {
      additionalParams: {
        clusterId,
        action,
      },
    },
  })
}
