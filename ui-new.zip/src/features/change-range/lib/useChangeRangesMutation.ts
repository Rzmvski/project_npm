import { type BucketRangeDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { notification } from '@v-uik/base'

import { nodesQueryKey } from '@/entities/node'
import { type Range } from '@/entities/range'
import { availableShardsQueryKey } from '@/entities/routing-shard'
import { fetchChangeSemaphore } from '@/features/change-range/api/fetch.ts'

export const useChangeRangesMutation = (shardId: number, region?: string) => {
  const client = useQueryClient()
  return useMutation({
    mutationFn: (updatedRanges: Range[]) => {
      const dtos: BucketRangeDto[] = updatedRanges.map(
        // dcKey — только для UI, в DTO диапазона его нет.
        ({ start, end, clusterKey, frozen, dcKey: _dcKey, ...range }) => ({
          ...range,
          semaphoreClusterKey: clusterKey,
          startInclusive: start,
          endExclusive: end + 1,
          frozenSemaphoreCluster: frozen,
        }),
      )
      return fetchChangeSemaphore(shardId, dtos, region)
    },
    onSuccess: () => {
      notification.success(`Изменение семафоров на шарде ${shardId} выполнено успешно`, {
        direction: 'vertical',
      })
      return Promise.all([
        client.invalidateQueries({ queryKey: nodesQueryKey }),
        client.invalidateQueries({ queryKey: availableShardsQueryKey }),
      ])
    },
  })
}
