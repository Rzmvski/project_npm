import { type BucketRangeDto, type ShardDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { clusterManagementService } from '@/shared/api'

/**
 * Ответ приходит SSE-потоком шард — собираем его целиком.
 * `region` уходит в заголовок X-Region: routing применяет изменение в этом регионе.
 */
export const fetchChangeSemaphore = async (
  shardId: number,
  changedBucketRanges: BucketRangeDto[],
  region?: string,
) => {
  const shards: ShardDto[] = []
  for await (const shard of clusterManagementService.updateSemaphoresOfShardByIdStream(
    shardId,
    { changedBucketRanges },
    region,
  )) {
    shards.push(shard)
  }
  return shards
}
