import { useQuery } from '@tanstack/react-query'

import { fetchEnvironment } from '../api/fetchEnvironment'

export const ENVIRONMENT_QUERY_KEY = ['environment'] as const

/**
 * Серверное состояние типа стенда: единый источник в react-query кэше,
 * кэшируется на сессию (staleTime: Infinity), без polling и без retry
 * (глобальный defaultOptions.queries.retry = false).
 */
export const useEnvironment = () => {
  return useQuery({
    queryKey: ENVIRONMENT_QUERY_KEY,
    queryFn: fetchEnvironment,
    staleTime: Number.POSITIVE_INFINITY,
  })
}
