import { type EnvironmentTypeDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { environmentInfoService } from '@/shared/api'

/**
 * Читает тип среды стенда через SDK. GET /config/environment — не SSE-эндпоинт,
 * поэтому abort signal НЕ пробрасывается. При ошибке пробрасывает ошибку в
 * useQuery — UI показывает "Среда не определена". Toast не показывается.
 */
export const fetchEnvironment = async (): Promise<EnvironmentTypeDto> => {
  return environmentInfoService.getEnvironmentInfo()
}
