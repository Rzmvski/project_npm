import { EnvironmentTypeDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import React, { type FC } from 'react'

import { useEnvironment } from '../lib/useEnvironment'

import styles from './EnvironmentIndicator.module.scss'

type EnvironmentTone = 'gray' | 'amber' | 'blue' | 'red' | 'green'

type EnvironmentView = {
  tone: EnvironmentTone
  label: string
}

const ENVIRONMENT_VIEWS: Record<EnvironmentTypeDto, EnvironmentView> = {
  [EnvironmentTypeDto.Dev]: { tone: 'gray', label: 'Среда разработки' },
  [EnvironmentTypeDto.Ift]: { tone: 'amber', label: 'Среда интеграционного тестирования' },
  [EnvironmentTypeDto.Psi]: { tone: 'green', label: 'Среда приёмо-сдаточных испытаний' },
  [EnvironmentTypeDto.Lt]: { tone: 'blue', label: 'Среда нагрузочного тестирования' },
  [EnvironmentTypeDto.Prom]: { tone: 'red', label: 'Промышленная среда' },
  [EnvironmentTypeDto.Unknown]: { tone: 'gray', label: 'Среда не определена' },
}

export const EnvironmentIndicator: FC = () => {
  const { data, isLoading, isError } = useEnvironment()

  if (isLoading) {
    return (
      <span role='status' className={styles.indicator} data-tone='gray'>
        <span className={styles.dot} aria-hidden='true' />
        <span>Определение среды…</span>
      </span>
    )
  }

  const view =
    !isError && data !== undefined
      ? ENVIRONMENT_VIEWS[data]
      : ENVIRONMENT_VIEWS[EnvironmentTypeDto.Unknown]

  return (
    <span role='status' className={styles.indicator} data-tone={view.tone}>
      <span className={styles.dot} aria-hidden='true' />
      <span>{view.label}</span>
    </span>
  )
}
