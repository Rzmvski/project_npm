export { fetchUpdateHotConfigs } from './fetch'
