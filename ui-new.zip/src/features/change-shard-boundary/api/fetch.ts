import { type ShardDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { clusterManagementService } from '@/shared/api'

/**
 * Ответ приходит SSE-потоком шард — собираем его целиком.
 * `region` уходит в заголовок X-Region: routing применяет изменение в этом регионе.
 */
export const fetchUpdateBucketRatio = async (
  shardId: number,
  bucketBoundary: number[],
  region?: string,
) => {
  const shards: ShardDto[] = []
  for await (const shard of clusterManagementService.updateNodesOfShardByIdStream(
    [shardId],
    { bucketBoundary },
    region,
  )) {
    shards.push(shard)
  }
  return shards
}
