import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'

import {
  type TrafficRestriction,
  trafficRestrictionSchema,
  type TrafficRestrictionInputValues,
} from '@/entities/traffic-restriction'
import { randomUuid } from '@/shared/lib/browser'

const trafficRestrictionValues: TrafficRestrictionInputValues = {
  id: randomUuid(),
  name: '',
  applications: [],
  dataCenters: [],
  updateComment: '',
  createComment: '',
}

interface UseTrafficRestrictionFormOptions {
  restriction?: TrafficRestriction
}

export const useTrafficRestrictionForm = ({
  restriction,
}: UseTrafficRestrictionFormOptions) => {
  const getDefaultValues = (): TrafficRestrictionInputValues => {
    if (restriction) {
      const { services, id } = restriction
      return {
        ...restriction,
        id: id ?? 'unknown',
        applications: services,
      }
    }

    return trafficRestrictionValues
  }

  return useForm({
    defaultValues: getDefaultValues(),
    resolver: zodResolver(trafficRestrictionSchema),
  })
}
