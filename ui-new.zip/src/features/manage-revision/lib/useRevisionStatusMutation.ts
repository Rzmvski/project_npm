import {
  type RevisionJobDto,
  type RevisionStatusDto,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { type QueryKey, useMutation, useQueryClient } from '@tanstack/react-query'

import { fetchChangeRevisionState } from '@/features/manage-revision/api'
import { randomUuid } from '@/shared/lib/browser'

type MutateParams = {
  shardId: string
  revisionId: number
  updatedStatus?: RevisionStatusDto
  job?: RevisionJobDto
}

interface UseRevisionStatusMutationOptions {
  queryKey?: QueryKey
  table?: string
}

export const useRevisionStatusMutation = ({
  queryKey,
  table,
}: UseRevisionStatusMutationOptions) => {
  const client = useQueryClient()
  return useMutation({
    mutationFn: ({ shardId, revisionId, updatedStatus, job }: MutateParams) => {
      const uuid = randomUuid()
      return fetchChangeRevisionState(shardId, revisionId, uuid, updatedStatus, job, table)
    },
    onSuccess: () => {
      return client.invalidateQueries({ queryKey })
    },
  })
}
