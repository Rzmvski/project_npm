export { AccessGuard } from './ui/AccessGuard'
export { hasAllAuthorities, hasAuthorityWithSubstring } from './lib'
