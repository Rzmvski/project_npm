import { render, screen } from '@testing-library/react'
import { describe, it, expect, vi } from 'vitest'

// Роутер создаётся при импорте модуля, а clearMocks обнуляет счётчики vi.fn
// перед каждым тестом, поэтому созданные роутеры считаем вручную.
const mocks = vi.hoisted(() => ({
  routerProviderMock: vi.fn(() => <div data-testid='tanstack-router-provider' />),
  createdRouters: 0,
}))

vi.mock('@tanstack/react-router', async (importOriginal) => {
  const actual = await importOriginal<typeof TanStackReactRouter>()
  return {
    ...actual,
    RouterProvider: mocks.routerProviderMock,
  }
})

vi.mock('@/app/routes/router', () => ({
  createAppRouter: () => {
    mocks.createdRouters += 1
    return 'mock-router'
  },
}))

import { RouterProvider } from '../RouterProvider'

import type * as TanStackReactRouter from '@tanstack/react-router'

describe('RouterProvider', () => {
  it('рендерит TanStack RouterProvider с единственным роутером приложения', () => {
    const { rerender } = render(<RouterProvider />)
    rerender(<RouterProvider />)

    // Роутер создан один раз при импорте и не пересоздаётся при рендерах.
    expect(mocks.createdRouters).toBe(1)
    expect(screen.getByTestId('tanstack-router-provider')).toBeInTheDocument()
    expect(mocks.routerProviderMock).toHaveBeenCalledWith(
      expect.objectContaining({ router: 'mock-router' }),
      undefined,
    )
  })
})
