import { RouterProvider as TanStackRouterProvider } from '@tanstack/react-router'
import React, { type FC } from 'react'

import { queryClient } from '@/app/config/queryClient'
import { createAppRouter } from '@/app/routes/router'

// Роутер должен иметь один экземпляр на всё время жизни приложения. Создание
// нового экземпляра во время рендера, особенно в React.StrictMode, размонтирует
// и монтирует дерево страниц повторно и приводит JSS-компоненты @v-uik к
// рассинхронизации SheetsManager.
const router = createAppRouter(queryClient)

export const RouterProvider: FC = () => {
  return <TanStackRouterProvider router={router} />
}
