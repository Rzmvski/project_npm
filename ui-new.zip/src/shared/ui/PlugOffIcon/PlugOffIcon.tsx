import { type LucideIcon, Plug, Slash } from 'lucide-react'
import { forwardRef } from 'react'

// LucideIcon — forwardRef-компонент: иконка должна пробрасывать ref, как и
// стандартные иконки lucide.
export const PlugOffIcon: LucideIcon = forwardRef((props, ref) => (
  <Plug ref={ref} {...props}>
    <Slash />
  </Plug>
))

PlugOffIcon.displayName = 'PlugOffIcon'
