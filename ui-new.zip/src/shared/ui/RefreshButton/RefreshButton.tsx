import { Button } from '@v-uik/base'
import classNames from 'classnames'
import { RefreshCwIcon } from 'lucide-react'
import { type ComponentProps, type FC, useState } from 'react'

import styles from './RefreshButton.module.scss'

type RefreshButtonProps = Omit<ComponentProps<typeof Button>, 'onClick' | 'prefixIcon'> & {
  /**
   * Перезапрос данных. Пока возвращённый промис не завершится, кнопка
   * неактивна, а иконка крутится. Бесконечные потоки (live-мониторинг) сюда
   * не передаются — их промис не завершается.
   */
  onRefresh: () => unknown
}

/** Кнопка «Обновить»: неактивна и крутит иконку, пока идёт запущенный ею запрос. */
export const RefreshButton: FC<RefreshButtonProps> = ({
  onRefresh,
  disabled,
  children,
  ...props
}) => {
  const [isRefreshing, setIsRefreshing] = useState(false)

  const handleClick = () => {
    setIsRefreshing(true)
    // async-обёртка вызывает onRefresh синхронно (запрос уходит сразу) и
    // превращает и результат, и исключение в промис. Ошибки перезапроса
    // показывают сами запросы; здесь важно лишь снять блокировку.
    void (async () => onRefresh())()
      .catch(() => undefined)
      .finally(() => setIsRefreshing(false))
  }

  return (
    <Button
      {...props}
      disabled={disabled || isRefreshing}
      aria-busy={isRefreshing}
      prefixIcon={
        <RefreshCwIcon
          aria-hidden
          className={classNames(styles.icon, { [styles.spinning]: isRefreshing })}
        />
      }
      onClick={handleClick}
    >
      {children}
    </Button>
  )
}
