import { generateId, modal, type ShowOptions } from '@v-uik/base'
import { type ReactNode } from 'react'

interface UseModalOptions {
  renderModal: () => ReactNode
  width?: string | number
  classes?: ShowOptions['classes']
}

export const useModal = () => {
  const modalId = generateId()

  const close = () => {
    modal.close(modalId)
  }

  const open = ({ renderModal, width, classes }: UseModalOptions) => {
    modal.show(modalId, {
      classes,
      content: renderModal(),
      width,
    } as ShowOptions)
  }

  return {
    open,
    close,
  }
}
