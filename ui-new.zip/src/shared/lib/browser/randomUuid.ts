const toHex = (byte: number) => byte.toString(16).padStart(2, '0')

/**
 * UUID v4. `crypto.randomUUID()` доступен только в защищённом контексте
 * (HTTPS/localhost); на обычном HTTP собираем UUID из `crypto.getRandomValues()`,
 * который есть везде.
 */
export const randomUuid = (): string => {
  if (typeof crypto.randomUUID === 'function') return crypto.randomUUID()

  const bytes = crypto.getRandomValues(new Uint8Array(16))
  bytes[6] = (bytes[6]! & 0x0f) | 0x40 // версия 4
  bytes[8] = (bytes[8]! & 0x3f) | 0x80 // вариант RFC 4122
  const hex = Array.from(bytes, toHex).join('')

  return [
    hex.slice(0, 8),
    hex.slice(8, 12),
    hex.slice(12, 16),
    hex.slice(16, 20),
    hex.slice(20),
  ].join('-')
}
