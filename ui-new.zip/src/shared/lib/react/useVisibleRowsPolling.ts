import {
  type QueryKey,
  type QueryObserverOptions,
  type QueryOptions,
  useQueries,
  useQueryClient,
} from '@tanstack/react-query'
import { isEqual } from 'lodash-es'
import { useEffect, useLayoutEffect, useMemo, useRef } from 'react'

import { createPollingQueryPolicy } from '@/shared/api'

interface UseVisibleRowsPollingOptions<TData> {
  rows: TData[]
  queryKey: QueryKey
  getRowId: (row: TData) => string
  fetchItem: (row: TData) => Promise<TData>
  stopPredicate: (row: TData) => boolean
}

export const useVisibleRowsPolling = <TData>({
  rows,
  queryKey,
  getRowId,
  fetchItem,
  stopPredicate,
}: UseVisibleRowsPollingOptions<TData>) => {
  const queryClient = useQueryClient()

  const pollingRows = useMemo(
    () => rows.filter((row) => !stopPredicate(row)),
    [rows, stopPredicate],
  )

  // Последние queryKey/getRowId для эффекта ниже: вызывающий может передать их
  // инлайн, а эффект должен срабатывать только на новые результаты запросов —
  // иначе setQueryData (всегда новый массив) зациклил бы рендеры.
  const latest = useRef({ queryKey, getRowId })
  useLayoutEffect(() => {
    latest.current = { queryKey, getRowId }
  })

  const queryResults = useQueries({
    queries: pollingRows.map((row) => ({
      queryKey: [queryKey, getRowId(row)],
      queryFn: () => fetchItem(row),
      ...createPollingQueryPolicy({
        stopPredicate,
      }),
      refetchOnMount: false,
      refetchOnWindowFocus: false,
    })) satisfies (QueryOptions<TData> | QueryObserverOptions<TData>)[],
  })

  useEffect(() => {
    const { queryKey, getRowId } = latest.current
    const updatedItems: TData[] = []

    queryResults.forEach((result) => {
      if (result.data) {
        updatedItems.push(result.data)
      }
    })

    if (!updatedItems.length) return

    const updatedMap = new Map(updatedItems.map((item) => [getRowId(item), item]))

    queryClient.setQueryData<TData[]>(queryKey, (old) => {
      return old?.map((item) => {
        const id = getRowId(item)
        const updatedItem = updatedMap.get(id)
        return updatedItem && !isEqual(updatedItem, item) ? updatedItem : item
      })
    })
  }, [queryResults, queryClient])
}
