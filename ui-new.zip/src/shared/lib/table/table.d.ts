import { type RowData } from '@tanstack/react-table'

// Дополняем TableMeta через @tanstack/react-table: @tanstack/table-core не
// объявлен в зависимостях и при строгой раскладке pnpm из src не резолвится.
// Параметры типа должны совпадать с исходным интерфейсом, иначе слияния нет.
declare module '@tanstack/react-table' {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars -- параметр нужен для слияния
  interface TableMeta<TData extends RowData> {
    loading?: boolean
    disabled?: boolean
    invalid?: boolean
  }
}
