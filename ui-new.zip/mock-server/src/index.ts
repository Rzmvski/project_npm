import type { Server } from 'node:http'
import type { AddressInfo } from 'node:net'

import { ErrorResponseDtoToJSON } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import express, {
  type ErrorRequestHandler,
  type Request,
  type RequestHandler,
  type Response,
} from 'express'

import { type ResolvedOperation, resolveOperation } from './contract'
import { createInitialState, enabledServices, type MockState } from './fixtures'
import { isFailure, type OperationRoute } from './operation'
import { operationRoutes } from './routes'

const DEFAULT_PORT = 3001
const DEFAULT_HOST = '127.0.0.1'
const LIVE_EMIT_INTERVAL_MS = 1000

/**
 * Стабильная, но различающаяся задержка для каждого endpoint.
 *
 * Явные значения делают основные запросы экрана кластеров предсказуемыми,
 * fallback покрывает остальные операции мока. Служебные endpoint (`/health`
 * и `/__mock/*`) намеренно остаются мгновенными.
 */
const ENDPOINT_DELAYS = new Map([
  ['GET /config/services', 160],
  ['GET /invoke/support-admin/cluster-management-service/service-mode', 220],
  ['GET /invoke/support-admin/cluster-management-service/nodes', 360],
  ['GET /invoke/support-admin/cluster-management-service/shard', 520],
  ['GET /invoke/support-admin/cluster-management-service/pools', 280],
  ['GET /invoke/support-admin/cluster-management-service/semaphores', 430],
  ['GET /invoke/support-admin/monitoring-management-service/monitorings/db', 610],
  ['GET /invoke/support-admin/monitoring-management-service/monitorings/ignite', 470],
  ['GET /invoke/support-admin/monitoring-management-service/monitorings/threshold', 190],
])

export const getEndpointDelay = (method: string, path: string) => {
  if (path === '/health' || path.startsWith('/__mock/')) return 0

  const operation = `${method} ${path}`
  const configured = ENDPOINT_DELAYS.get(operation)
  if (configured !== undefined) return configured

  const hash = [...operation].reduce(
    (value, character) => (value * 31 + character.charCodeAt(0)) >>> 0,
    0,
  )
  return 140 + (hash % 7) * 45
}

const sleep = (milliseconds: number) =>
  new Promise((resolve) => {
    setTimeout(resolve, milliseconds)
  })

const errorBody = (status: number, message: string, path: string) =>
  ErrorResponseDtoToJSON({ timestamp: new Date(), status, message, path })

/**
 * JSON-значение ответа. Для `uniqueItems` SDK объявляет Set, а FromJSON
 * собирает его из массива, поэтому по сети Set уходит массивом.
 */
const toWire = (value: unknown): unknown =>
  value === undefined
    ? undefined
    : JSON.parse(
        JSON.stringify(value, (_key, item: unknown) =>
          item instanceof Set ? [...item] : item,
        ),
      )

/** Spring пишет ответ SseEmitter именно с таким content-type. */
const SSE_CONTENT_TYPE = 'text/event-stream;charset=UTF-8'

/**
 * Совместим ли Accept с `text/event-stream`.
 *
 * Пустой Accept (fetch без явного заголовка) для Spring означает wildcard и
 * проходит. Явно несовместимый Accept, например `application/json`, даёт
 * HttpMediaTypeNotAcceptableException — 406 без тела.
 */
const acceptsSse = (request: Request) => {
  const accept = String(request.headers.accept ?? '').trim()
  if (accept === '') return true

  return accept.split(',').some((part) => {
    const type = part.split(';')[0].trim().toLowerCase()
    return type === '*/*' || type === 'text/*' || type === 'text/event-stream'
  })
}

/**
 * Разбивка тела на SSE-события так, как это делает Spring MVC: `Flux<T>` —
 * по событию на элемент, `Mono<T>` — одно событие, `Mono<Void>` — без событий.
 */
const toSseEvents = (body: unknown) =>
  body === undefined || body === null ? [] : Array.isArray(body) ? body : [body]

const openSse = (request: Request, response: Response, status: number) => {
  if (!acceptsSse(request)) {
    response.status(406).end()
    return false
  }
  // Потоковые операции без тела отвечают 200 с пустым SSE-потоком, а не 204.
  response.status(status === 204 ? 200 : status)
  response.setHeader('content-type', SSE_CONTENT_TYPE)
  // Заголовки кэширования, которые в admin-app проставляет Spring Security.
  response.setHeader('cache-control', 'no-cache, no-store, max-age=0, must-revalidate')
  response.setHeader('pragma', 'no-cache')
  response.setHeader('expires', '0')
  response.flushHeaders()
  return true
}

// После `data:` нет пробела — так пишет SseEmitter.SseEventBuilderImpl.
const writeSse = (response: Response, events: unknown[]) => {
  for (const event of events) response.write(`data:${JSON.stringify(event)}\n\n`)
}

/**
 * Конечный поток: после последнего события соединение закрывается. События
 * разнесены во времени: DevTools фиксирует события вкладки EventStream, только
 * пока соединение открыто, а мгновенный батч `write`+`end()` закрывается раньше.
 */
const sendSse = (request: Request, response: Response, status: number, body: unknown) => {
  if (!openSse(request, response, status)) return
  const events = toSseEvents(body)
  events.forEach((event, index) => {
    setTimeout(() => writeSse(response, [event]), index * 10)
  })
  setTimeout(() => response.end(), events.length * 10 + 20)
}

/** Поток-Sink: после начального снимка продолжает присылать изменения. */
const sendLiveSse = (
  request: Request,
  response: Response,
  body: unknown,
  next: () => unknown[],
) => {
  if (!openSse(request, response, 200)) return
  writeSse(response, toSseEvents(body))
  const interval = setInterval(() => writeSse(response, next()), LIVE_EMIT_INTERVAL_MS)
  const cleanup = () => clearInterval(interval)
  request.once('aborted', cleanup)
  response.once('close', cleanup)
}

/** Параметры операции SDK из HTTP-запроса: path, query и header — строки, тело — модель SDK. */
const inputOf = (operation: ResolvedOperation, request: Request) => {
  const input: Record<string, unknown> = {}
  for (const key of operation.pathKeys) input[key] = request.params[key]

  const url = new URL(request.originalUrl, 'http://mock')
  for (const [name, key] of operation.query) {
    const values = url.searchParams.getAll(name)
    if (values.length) input[key] = values.join(',')
  }
  for (const [name, key] of operation.headers) {
    const value = request.get(name)
    if (value !== undefined) input[key] = value
  }
  if (operation.body) input[operation.body.key] = operation.body.codec.fromJSON(request.body)
  return input
}

interface OperationHandlerOptions {
  getState: () => MockState
  responseDelay: (method: string, path: string) => number
}

const operationHandler = (
  route: OperationRoute,
  operation: ResolvedOperation,
  { getState, responseDelay }: OperationHandlerOptions,
): RequestHandler => {
  const encode = (body: unknown) => toWire(operation.responseCodec.toJSON(body))

  return async (request, response) => {
    const delay = Math.max(0, Number(responseDelay(operation.method, operation.template)) || 0)
    if (delay > 0) await sleep(delay)

    const state = getState()
    const outcome = await route.handle({ state, input: inputOf(operation, request), request })

    if (isFailure(outcome)) {
      const body = errorBody(outcome.status, outcome.failure, request.path)
      // Ошибки SSE-операций в актуальном контракте тоже text/event-stream.
      if (operation.sse) sendSse(request, response, outcome.status, body)
      else response.status(outcome.status).json(body)
      return
    }

    const status = outcome.status ?? (operation.response === 'void' ? 204 : 200)
    const { live } = route
    if (operation.sse && live) {
      sendLiveSse(request, response, encode(outcome.body), () =>
        toSseEvents(encode(live(state))),
      )
    } else if (operation.sse) {
      sendSse(request, response, status, encode(outcome.body))
    } else if (operation.response === 'void' || outcome.body === undefined) {
      response.sendStatus(status)
    } else if (operation.response === 'text') {
      response.status(status).type('text/plain').send(String(outcome.body))
    } else {
      response.status(status).json(encode(outcome.body))
    }
  }
}

/** Операции SDK, разобранные один раз: разбор вызывает SDK и не зависит от состояния. */
let resolvedOperations: Promise<[OperationRoute, ResolvedOperation][]> | undefined

export const resolveOperationRoutes = () =>
  (resolvedOperations ??= Promise.all(
    operationRoutes.map(
      async (route) =>
        [route, await resolveOperation(route.api, route.name as never)] as [
          OperationRoute,
          ResolvedOperation,
        ],
    ),
  ))

export interface MockServerOptions {
  port?: number
  host?: string
  quiet?: boolean
  responseDelay?: (method: string, path: string) => number
}

export interface MockServer {
  app: express.Express
  server: Server
  url: string
  close: () => Promise<void>
}

export const createMockServer = async ({
  port = DEFAULT_PORT,
  host = DEFAULT_HOST,
  quiet = false,
  responseDelay = getEndpointDelay,
}: MockServerOptions = {}): Promise<MockServer> => {
  let state = createInitialState()
  const reset = () => {
    state = createInitialState()
    return state
  }

  const app = express()
  app.disable('x-powered-by')
  app.disable('etag')
  app.use(express.json({ limit: '2mb' }))
  app.use((request, response, next) => {
    response.setHeader('cache-control', 'no-store')
    response.setHeader('access-control-allow-origin', '*')
    response.setHeader(
      'access-control-allow-headers',
      'accept, content-type, authorization, x-region, uuid',
    )
    response.setHeader('access-control-allow-methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS')
    if (request.method === 'OPTIONS') {
      response.sendStatus(204)
      return
    }

    const startedAt = performance.now()
    response.once('finish', () => {
      if (quiet) return
      const duration = Math.round(performance.now() - startedAt)
      process.stdout.write(
        `[mock] ${request.method} ${request.originalUrl} -> ${response.statusCode} (${duration}ms)\n`,
      )
    })
    next()
  })

  // Служебные endpoint мока и операции, которых нет в SDK.
  const serviceRouter = express.Router()
  serviceRouter.get('/health', (_request, response) => {
    response.json({
      status: 'ok',
      service: 'tcpf-support-admin-mock',
      processes: Object.keys(state.processes).length,
    })
  })
  serviceRouter.get('/__mock/state', (_request, response) => {
    response.json(state)
  })
  serviceRouter.post('/__mock/reset', (_request, response) => {
    response.json(reset())
  })
  serviceRouter.get('/config/services', async (_request, response) => {
    await sleep(responseDelay('GET', '/config/services'))
    response.json(enabledServices)
  })
  serviceRouter.post('/invoke/support-admin/user-service/logout', (_request, response) => {
    response.sendStatus(204)
  })

  const apiRouter = express.Router()
  for (const [route, operation] of await resolveOperationRoutes()) {
    const method = operation.method.toLowerCase() as 'get' | 'post' | 'put' | 'patch' | 'delete'
    apiRouter[method](
      operation.path,
      operationHandler(route, operation, { getState: () => state, responseDelay }),
    )
  }

  for (const prefix of ['/', '/platform', '/tkp']) app.use(prefix, serviceRouter, apiRouter)
  app.use((request, response) => {
    response
      .status(404)
      .json(errorBody(404, `No mock for ${request.method} ${request.path}`, request.path))
  })
  const handleError: ErrorRequestHandler = (error, request, response, _next) => {
    void _next
    // Тело, которое не читается моделью SDK, Spring отклоняет как 400.
    const status = Number((error as { status?: number }).status) || 400
    const message = error instanceof Error ? error.message : 'Mock request failed'
    response.status(status).json(errorBody(status, message, request.path))
  }
  app.use(handleError)

  return new Promise((resolve, reject) => {
    const server = app.listen(port, host)
    server.once('error', reject)
    server.once('listening', () => {
      const { port: actualPort } = server.address() as AddressInfo
      resolve({
        app,
        server,
        url: `http://${host}:${actualPort}`,
        close: () =>
          new Promise((done, fail) => {
            server.close((error) => (error ? fail(error) : done()))
          }),
      })
    })
  })
}
