import { randomUUID } from 'node:crypto'

import {
  ApplicationStatusDto,
  ApplicationTypeDto,
  ClusterManagementServiceApi,
  ClusterStateDto,
  ConnectionPoolManagementServiceApi,
  EnvironmentInfoServiceApi,
  EnvironmentTypeDto,
  FeatureTogglingServiceApi,
  GeoBalancingManagementServiceApi,
  IndexActionsDto,
  localDate,
  MetadataManagementServiceApi,
  MonitoringManagementServiceApi,
  MonitoringStateDto,
  PoolStateDto,
  RegionManagementServiceApi,
  ReplicationStateDto,
  ReviseReplicationServiceApi,
  RevisionJobDto,
  RevisionJobStatusDto,
  RevisionStatusDto,
  ScriptServiceApi,
  type ShardDto,
  ShardInfoServiceApi,
  UserServiceApi,
  ZoneIndexServiceApi,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'
import {
  ClientTransferServiceApi,
  DictionaryServiceApi,
  type DictionaryItemDto,
  OperationDayServiceApi,
  ProcessManagementServiceApi,
} from '@sber-pprb-tkp/tcpf-support-admin-api'

import { beans, createTransferProcessState, type MockState, permissions } from './fixtures'
import { done, fail, ok, operation } from './operation'
import {
  findProcess,
  nextDbMonitorings,
  updateIndexTransitions,
  updateTimedProcess,
} from './simulation'

const REPLICATION_COMPLETION_DELAY_MS = 2500
const REPLICA_LAG_THRESHOLD = 30
const BUCKET_COUNT = 32768

/** Значение enum SDK из строки запроса; неизвестное значение Spring отклоняет с 400. */
const enumValue = <E extends Record<string, string>>(
  values: E,
  value: string | undefined,
): E[keyof E] | undefined => Object.values(values).find((item) => item === value) as E[keyof E]

// X-Region: регион, в котором routing применяет изменение шарды. Шард вне
// региона — ошибка, как в tcpf-routing-app-os; без заголовка — без проверки.
const outOfRegion = (shard: ShardDto, region: string | undefined) =>
  Boolean(region) && !shard.region?.some((item) => item.region === region)

const regionMismatch = (shardId: number) =>
  fail(400, `Shard ${shardId} is not served by the requested region`)

const startedProcess = (state: MockState, processName: string) => ({
  processName,
  idOfStartedProcess: state.nextProcessId++,
})

const DICTIONARIES: Record<string, DictionaryItemDto[]> = {
  PROCESS_TYPE: [
    { id: '1', label: 'Закрытие операционного дня' },
    { id: '2', label: 'Пересчёт клиентских данных' },
  ],
  PROCESS_MONITORING: [
    { id: 'RUNNING', label: 'Выполняется' },
    { id: 'COMPLETED', label: 'Завершён' },
    { id: 'FAILED', label: 'Ошибка' },
  ],
}

const revisionOf = (state: MockState, shardId: string, revisionId: string) =>
  state.revisions.find((item) => String(item.id) === revisionId && item.shardId === shardId)

const userRoutes = [
  operation(UserServiceApi, 'getRoles', () => ok(new Set(['ADMIN', 'TKP_SUPPORT']))),
  operation(UserServiceApi, 'getPermissions', () => ok(new Set(permissions))),
  operation(EnvironmentInfoServiceApi, 'getEnvironmentInfo', () => ok(EnvironmentTypeDto.Dev)),
  operation(DictionaryServiceApi, 'dictionary', ({ input }) => {
    const { code } = input.dictionaryRequestDto
    return ok(
      DICTIONARIES[code] ?? [
        { id: `${code}_1`, label: `${code}: значение 1` },
        { id: `${code}_2`, label: `${code}: значение 2` },
      ],
    )
  }),
]

const processRoutes = [
  operation(ProcessManagementServiceApi, 'processList', () =>
    ok([
      { id: '1', label: 'Закрытие операционного дня' },
      { id: '2', label: 'Пересчёт данных' },
    ]),
  ),
  operation(ProcessManagementServiceApi, 'activeProcessResult', ({ state, input }) => {
    if (input.sessionId) return ok(findProcess(state, Number(input.sessionId)))

    const processGroupId = Number(input.processGroupId)
    const matching = Object.values(state.processes).filter(
      (process) => !processGroupId || process.processGroupId === processGroupId,
    )
    matching.forEach((process) => updateTimedProcess(state, process.sessionId))

    const active = matching.find((process) => !process.done)
    const latest = matching.toSorted((left, right) => right.sessionId - left.sessionId)[0]
    return ok(active ?? latest ?? { sessionId: processGroupId || 0, done: true })
  }),
  operation(ProcessManagementServiceApi, 'startProcess', ({ state, input }) => {
    const started = startedProcess(state, 'process-group')
    const process = structuredClone(findProcess(state, 7001))
    process.sessionId = started.idOfStartedProcess
    process.done = false
    process.processGroupId = Number(input.processGroupId)
    process.data!.groupOfProcesses.dateOD = input.operationDay
    process.data!.groupOfProcesses.statusGroup = 'RUNNING'
    state.processes[process.sessionId] = process
    return ok(started, 201)
  }),
  operation(ProcessManagementServiceApi, 'processResult', ({ state, input }) =>
    ok(findProcess(state, Number(input.sessionId))),
  ),
  operation(ProcessManagementServiceApi, 'stopProcess', ({ state, input }) => {
    const sessionId = Number(input.sessionId)
    const process = findProcess(state, sessionId)
    process.done = true
    if (process.data) process.data.groupOfProcesses.statusGroup = 'STOPPED'
    state.processes[sessionId] = process
    return ok({ processName: 'stopped-process', idOfStartedProcess: sessionId })
  }),
  operation(ProcessManagementServiceApi, 'processHistory', ({ state }) =>
    ok(state.processHistory),
  ),
]

const operationDayRoutes = [
  operation(OperationDayServiceApi, 'closeOd', ({ state }) => {
    const started = startedProcess(state, 'close-operation-day')
    const process = structuredClone(findProcess(state, 7001))
    process.sessionId = started.idOfStartedProcess
    state.processes[process.sessionId] = process
    return ok(started)
  }),
  operation(OperationDayServiceApi, 'odResult', ({ state, input }) =>
    ok(
      findProcess(state, input.resultOfClosingOdRequestDto.process.idOfStartedProcess ?? 7001),
    ),
  ),
  operation(OperationDayServiceApi, 'operationDays', ({ state }) => ok(state.operationDays)),
  operation(OperationDayServiceApi, 'currentOd', ({ state }) =>
    ok(state.operationDays.currentOperationDay!),
  ),
  operation(OperationDayServiceApi, 'odHistory', ({ state }) => ok(state.processHistory)),
  operation(OperationDayServiceApi, 'odHistoryDetails', ({ state, input }) =>
    ok(
      findProcess(state, input.historyDetailedRequestDto.sessionId).data ?? {
        groupOfProcesses: {},
      },
    ),
  ),
  operation(OperationDayServiceApi, 'failedContractsWithSteps', () =>
    ok([
      {
        id: 'contract-104',
        number: 'ДК-000104',
        idOfClient: 'client-42',
        errorMessage: 'Не найден обязательный шаг расчёта',
      },
    ]),
  ),
]

const clientTransferRoutes = [
  operation(ClientTransferServiceApi, 'transferStatus', ({ state }) =>
    ok(state.transferStatus),
  ),
  operation(ClientTransferServiceApi, 'transfer', ({ state, input }) => {
    const { shardIds, deleteUpToDate } = input.transferRequestDto
    const started = startedProcess(state, 'client-transfer')
    const transfer = createTransferProcessState({
      sessionId: started.idOfStartedProcess,
      shardIds: shardIds.length ? shardIds : [1],
    })
    transfer.process.data!.groupOfProcesses.dateOD =
      deleteUpToDate ?? state.operationDays.currentOperationDay
    state.processes[started.idOfStartedProcess] = transfer.process
    state.processTimelines[started.idOfStartedProcess] = transfer.timeline
    return ok(started)
  }),
  operation(ClientTransferServiceApi, 'createTask', ({ state, input }) => {
    const started = startedProcess(state, 'create-transfer-task')
    const sourceShardIds = input.createTaskRequestDto.sourceShardIds?.length
      ? input.createTaskRequestDto.sourceShardIds
      : [1]
    const isLast = (index: number) => index === sourceShardIds.length - 1
    state.processes[started.idOfStartedProcess] = {
      sessionId: started.idOfStartedProcess,
      done: true,
      data: {
        lastUpdate: new Date(),
        groupOfProcesses: {
          statusGroup: 'COMPLETED',
          fields: sourceShardIds.map((shardId, index) => ({
            name: 'Формирование задания',
            code: `CREATE_TRANSFER_TASK_${shardId}`,
            status: isLast(index) ? 'COMPLETED' : 'RUNNING',
            nodeCode: String(shardId),
            recordsWillBeProcessed: String(850 + index * 400),
            startTime: new Date('2026-08-12T09:10:00.000Z'),
            endTime: isLast(index) ? new Date('2026-08-12T09:12:00.000Z') : undefined,
          })),
        },
      },
    }
    return ok(started, 201)
  }),
  operation(ClientTransferServiceApi, 'transferResult', ({ state, input }) =>
    ok(findProcess(state, Number(input.processId))),
  ),
  operation(ClientTransferServiceApi, 'clientTransferHistory', ({ state }) =>
    ok(state.processHistory),
  ),
  operation(ClientTransferServiceApi, 'clear', ({ state }) =>
    ok(startedProcess(state, 'clear-transfer-tasks')),
  ),
  operation(ClientTransferServiceApi, 'clearStatus', ({ state }) => ok(state.transferStatus)),
]

/** Новые границы диапазонов шарды из bucketBoundary (UI отправляет один shardId). */
const applyBucketBoundaries = (shard: ShardDto, boundaries: number[]) => {
  const ranges = shard.bucketRanges.toSorted(
    (left, right) => left.startInclusive - right.startInclusive,
  )
  const nodeKeys = [...new Set(ranges.map(({ nodeKey }) => nodeKey))]

  // N нод => N - 1 границ между соседними нодами.
  if (boundaries.length !== nodeKeys.length - 1) {
    return `Expected ${nodeKeys.length - 1} bucket boundaries for shard ${shard.id}`
  }
  const invalid = boundaries.some(
    (boundary, index) =>
      !Number.isInteger(boundary) ||
      boundary < 0 ||
      boundary > BUCKET_COUNT ||
      (index > 0 && boundary < boundaries[index - 1]),
  )
  if (invalid) return `bucketBoundary must be ordered and between 0 and ${BUCKET_COUNT}`

  const edges = [0, ...boundaries, BUCKET_COUNT]
  shard.bucketRanges = nodeKeys.map((nodeKey, index) => ({
    ...ranges.find((range) => range.nodeKey === nodeKey)!,
    startInclusive: edges[index],
    endExclusive: edges[index + 1],
  }))
  return undefined
}

const clusterRoutes = [
  operation(ClusterManagementServiceApi, 'getNodes', ({ state }) => ok(state.nodes)),
  operation(ClusterManagementServiceApi, 'getShards', ({ state }) => ok(state.shards)),
  operation(ClusterManagementServiceApi, 'semaphoreInfo', ({ state }) => ok(state.semaphores)),
  operation(ConnectionPoolManagementServiceApi, 'getPools', ({ state }) => ok(state.pools)),
  operation(ClusterManagementServiceApi, 'changeClusterState', ({ state, input }) => {
    const semaphore = state.semaphores.find((item) => item.clusterKey === input.clusterKey)
    const status = input.changeClusterStateRequestDto?.status
    if (semaphore && status) semaphore.status = status
    return done()
  }),
  operation(ConnectionPoolManagementServiceApi, 'changePoolState', ({ state, input }) => {
    const pool = state.pools.find((item) => item.key === input.nodeKey)
    const poolState = enumValue(PoolStateDto, input.poolState)
    if (!poolState) return fail(400, `Unknown pool state ${input.poolState}`)
    if (pool) pool.status = poolState
    return done()
  }),
  operation(MetadataManagementServiceApi, 'refreshMetadataOnNode', () =>
    ok({ schemaVersion: '34.1.14-MOCK', dictionaryVersion: '3.0.1-MOCK' }),
  ),
  operation(ClusterManagementServiceApi, 'updateNodesOfShardById', ({ state, input }) => {
    const shardIds = input.ids.split(',').map(Number)
    const shards = state.shards.filter((shard) => shardIds.includes(shard.id))
    const foreign = shards.find((shard) => outOfRegion(shard, input.xRegion))
    if (foreign) return regionMismatch(foreign.id)

    const bucketBoundary = input.shardUpdateDto.bucketBoundary ?? []
    for (const [index, shard] of shards.entries()) {
      // Вариант с несколькими shardId сохраняет старую семантику контракта —
      // по одной границе на шарду.
      const boundaries =
        shards.length === 1
          ? bucketBoundary
          : [bucketBoundary.length === 1 ? bucketBoundary[0] : bucketBoundary[index]]
      const error = applyBucketBoundaries(shard, boundaries)
      if (error) return fail(400, error)
    }
    return ok(state.shards)
  }),
  operation(ClusterManagementServiceApi, 'updateSemaphoresOfShardById', ({ state, input }) => {
    const shard = state.shards.find((item) => item.id === Number(input.id))
    if (shard && outOfRegion(shard, input.xRegion)) return regionMismatch(shard.id)
    const changed = input.bucketRangeUpdateDto.changedBucketRanges ?? []
    if (shard && changed.length) shard.bucketRanges = changed
    return ok(state.shards)
  }),
  operation(ClusterManagementServiceApi, 'getServiceMode', ({ state }) =>
    ok({ status: state.serviceMode, startedAt: new Date('2026-08-12T07:00:00.000Z') }),
  ),
  operation(ClusterManagementServiceApi, 'updateServiceMode', ({ state, input }) => {
    state.serviceMode = input.updateServiceModeRequestDto.status
    return ok({ code: 0, description: `Сервисный режим: ${state.serviceMode}` })
  }),
  operation(ClusterManagementServiceApi, 'getForcedReplication', ({ state, input }) =>
    ok(
      state.replications[Number(input.shardId)] ?? {
        status: ReplicationStateDto.Required,
        startedAt: new Date(),
      },
    ),
  ),
  operation(ClusterManagementServiceApi, 'startReplication', ({ state, input }) => {
    const shardId = Number(input.shardId)
    const startedAt = new Date()
    state.replications[shardId] = { status: ReplicationStateDto.InProgress, startedAt }

    // Операция в реальном сервисе выполняется асинхронно. Держим мок в
    // промежуточном состоянии, чтобы UI успел показать прогресс, а затем
    // переводим только тот запуск, для которого ещё не пришла отмена или
    // новый повторный запуск.
    setTimeout(() => {
      const replication = state.replications[shardId]
      if (
        replication?.status !== ReplicationStateDto.InProgress ||
        replication.startedAt !== startedAt
      ) {
        return
      }
      state.replications[shardId] = {
        ...replication,
        status: ReplicationStateDto.Done,
        finishedAt: new Date(),
      }
    }, REPLICATION_COMPLETION_DELAY_MS)

    return ok({ code: 0, description: 'Репликация запущена' })
  }),
  operation(ClusterManagementServiceApi, 'undoReplication', ({ state, input }) => {
    state.replications[Number(input.shardId)] = {
      status: ReplicationStateDto.Required,
      startedAt: new Date(),
    }
    return ok({ code: 0, description: 'Репликация отменена' })
  }),
]

const regionRoutes = [
  operation(RegionManagementServiceApi, 'getRegionGroups', ({ state }) => ok(state.regions)),
  operation(RegionManagementServiceApi, 'updateRegionGroups', ({ state, input }) => {
    // Перевод диапазонов: заменяем группы новыми (регион изменился у части диапазонов).
    state.regions = structuredClone(input.regionGroupDtoDto)
    return ok(state.regions)
  }),
  operation(RegionManagementServiceApi, 'updateRegionAvailability', ({ state, input }) => {
    // Доступность региона обновляется отдельно от групп диапазонов: заменять
    // state.regions телом RegionDto[] нельзя, иначе теряются границы групп.
    const availability = new Map(
      input.regionDtoDto.map((region) => [region.region, region.regionAvailability]),
    )
    state.regions = state.regions.map((group) => ({
      ...group,
      regionAvailability: availability.get(group.region) ?? group.regionAvailability ?? true,
    }))

    // Отражаем новую доступность региона на шардах — отключённый регион
    // становится для UI только для просмотра.
    for (const shard of state.shards) {
      for (const region of shard.region ?? []) {
        region.regionAvailability = availability.get(region.region) ?? true
      }
    }
    return ok(input.regionDtoDto)
  }),
]

const monitoringRoutes = [
  operation(MonitoringManagementServiceApi, 'getIgniteMonitorings', ({ input }) => {
    const type = (input.type ?? 'ALL').toLowerCase()
    return ok([
      { id: `${type}-cluster-1`, state: MonitoringStateDto.Up },
      { id: `${type}-cluster-2`, state: MonitoringStateDto.OnlyRead },
    ])
  }),
  // Значения лага «живые»: каждый новый запрос продолжает ряд с того места,
  // где остановился предыдущий, а открытый поток получает обновления.
  operation(
    MonitoringManagementServiceApi,
    'getDbMonitorings',
    ({ state }) => ok(nextDbMonitorings(state)),
    { live: nextDbMonitorings },
  ),
  operation(MonitoringManagementServiceApi, 'getMonitoringThreshold', () =>
    ok({ lag: REPLICA_LAG_THRESHOLD }),
  ),
  operation(ShardInfoServiceApi, 'getShardInfo', ({ input }) => {
    // Контракт, для которого шард сознательно не найден — для проверки
    // состояния ошибки на странице "Шард контракта" (номер договора NOTFOUND).
    if (input.key === 'NOTFOUND') return fail(404, 'Shard not found')
    const hash = [...input.key].reduce((sum, char) => sum + char.charCodeAt(0), 0)
    return ok({ shardId: (hash % 3) + 1, nodeKey: 'P1' })
  }),
]

const indexRoutes = [
  operation(ZoneIndexServiceApi, 'clusterInfo', ({ state }) => {
    updateIndexTransitions(state.clusters)
    return ok(state.clusters)
  }),
  operation(ZoneIndexServiceApi, 'indexesExecute', ({ state, input }) => {
    const { rqUid, rqTm, actionRequest } = input.startActionWithIndexesRqDto
    const respond = (code: number, description: string) =>
      ok({ rqUid, rqTm, code, description })
    const cluster = state.clusters.find((item) => item.clusterId === actionRequest.clusterId)
    if (!cluster) return respond(1, 'Кластер не найден')

    switch (actionRequest.action) {
      case IndexActionsDto.CreateIndex:
        cluster.state = ClusterStateDto.Creating
        cluster.availableActions = IndexActionsDto.CancelLoading
        cluster.updateRequired = true
        cluster.transitionStartedAt = Date.now()
        break
      case IndexActionsDto.Deactivate:
      case IndexActionsDto.CancelLoading:
        cluster.state = ClusterStateDto.Inactive
        cluster.availableActions = IndexActionsDto.CreateIndex
        cluster.updateRequired = false
        delete cluster.transitionStartedAt
        break
      default:
        return respond(2, `Действие ${actionRequest.action} недоступно`)
    }
    return respond(0, `Действие ${actionRequest.action} принято`)
  }),
]

const DAY_MS = 24 * 60 * 60 * 1000

const revisionRoutes = [
  operation(ReviseReplicationServiceApi, 'getRevisionShardIds', ({ state }) =>
    ok(state.shards.map(({ id }) => String(id))),
  ),
  operation(ReviseReplicationServiceApi, 'getLastRevisions', ({ state }) =>
    ok(state.revisions),
  ),
  operation(ReviseReplicationServiceApi, 'revise', ({ state, input }) => {
    const now = new Date()
    const created = input.shardIds.split(',').map((shardId) => ({
      ...structuredClone(state.revisions[0]),
      id: state.nextRevisionId++,
      shardId,
      part: Number(input.part ?? 100),
      status: RevisionStatusDto.Working,
      jobStatus: RevisionJobStatusDto.Running,
      created: now,
      updated: now,
    }))
    state.revisions.unshift(...created)
    return ok(created, 201)
  }),
  operation(ReviseReplicationServiceApi, 'reviseHistory', ({ state, input }) => {
    const ids = input.shardIds.split(',')
    const fromMs = input.from ? new Date(input.from).getTime() : Number.NaN
    // "to" — граница дня (дата без времени), поэтому включаем весь день.
    const toMs = input.to ? new Date(input.to).getTime() + DAY_MS - 1 : Number.NaN
    const time = (date: Date | undefined) => date?.getTime() ?? 0

    const filtered = state.revisionHistory
      .filter((revision) => ids.includes(revision.shardId))
      .filter((revision) => !input.status || revision.status === input.status)
      .filter((revision) => !input.revisionId || String(revision.id) === input.revisionId)
      .filter((revision) => Number.isNaN(fromMs) || time(revision.updated) >= fromMs)
      .filter((revision) => Number.isNaN(toMs) || time(revision.updated) <= toMs)
      .toSorted((left, right) => time(right.updated) - time(left.updated))

    // Страницы нумеруются с 1; defaults SDK: page 1, size 20.
    const pageNumber = Math.max(1, Number(input.pageNumber ?? 1))
    const pageSize = Math.max(1, Number(input.pageSize ?? 20))
    const start = (pageNumber - 1) * pageSize
    return ok(filtered.slice(start, start + pageSize))
  }),
  operation(ReviseReplicationServiceApi, 'getRevisionById', ({ state, input }) => {
    const revision = revisionOf(state, input.shardId, input.revisionId)
    return revision ? ok(revision) : fail(404, 'Revision not found')
  }),
  operation(ReviseReplicationServiceApi, 'changeRevisionStatus', ({ state, input }) => {
    const revision = revisionOf(state, input.shardId, input.revisionId)
    if (!revision) return fail(404, 'Revision not found')
    revision.status = input.status ?? revision.status
    revision.job = enumValue(RevisionJobDto, input.job) ?? revision.job
    revision.updated = new Date()
    return ok(revision)
  }),
  operation(ReviseReplicationServiceApi, 'reviseDetails', ({ state, input }) => {
    const revision =
      state.revisions.find((item) => String(item.id) === input.revisionId) ?? state.revisions[0]
    return ok([
      { ...revision, table: 'client_contract', id: 1 },
      { ...revision, table: 'account_balance', id: 2, rowsDiff: 0 },
    ])
  }),
  operation(ReviseReplicationServiceApi, 'reviseReport', ({ input }) =>
    ok([
      {
        id: 1,
        revisionTaskId: Number(input.revisionId),
        pkUpdTime: new Date('2026-08-12T08:30:00.000Z'),
        table: 'client_contract',
        pk: 'contract-104',
        status: 'DIFF',
        statusTime: new Date(),
      },
    ]),
  ),
]

const scriptRoutes = [
  operation(ScriptServiceApi, 'loadScriptApplications', ({ state }) =>
    ok(state.scriptApplications),
  ),
  operation(ScriptServiceApi, 'saveScriptApplication', ({ state, input }) => {
    state.scriptApplications.unshift({
      ...input.createScriptApplicationRequestDto,
      id: Date.now(),
      type: ApplicationTypeDto.Script,
      rqUid: randomUUID(),
      status: ApplicationStatusDto.Pending,
      created: new Date(),
      createdBy: 'mock.admin',
    })
    return done(201)
  }),
  operation(ScriptServiceApi, 'scriptResult', ({ state, input }) =>
    ok(
      state.scriptApplications.find((item) => item.reasonId === input.reasonId) ??
        state.scriptApplications[0],
    ),
  ),
  operation(ScriptServiceApi, 'resolveScriptApplication', ({ state, input }) => {
    const application = state.scriptApplications.find(
      (item) => item.reasonId === input.reasonId,
    )
    if (!application) return fail(404, 'Script application not found')
    Object.assign(application, input.resolveScriptApplicationRequestDto, {
      resolvedAt: new Date(),
      resolvedBy: 'mock.admin',
    })
    return ok(application)
  }),
  operation(ScriptServiceApi, 'getScript', ({ state, input }) =>
    ok(
      state.scriptApplications.find((item) => item.reasonId === input.reasonId)?.scriptBody ??
        '// Текст скрипта недоступен',
    ),
  ),
  operation(ScriptServiceApi, 'getScriptLogs', ({ input }) =>
    ok(`[INFO] ${input.reasonId}: скрипт принят\n[INFO] Выполнение завершено`),
  ),
  operation(ScriptServiceApi, 'getTemplatesMetadata', ({ state }) => ok(state.templates)),
  operation(ScriptServiceApi, 'getTemplateByHash', ({ state, input }) =>
    ok(state.templateBodies[Number(input.hash)] ?? '// Шаблон не найден'),
  ),
  operation(ScriptServiceApi, 'loadBeans', () => ok(beans)),
]

const featureRoutes = [
  operation(FeatureTogglingServiceApi, 'getPropertyTypes', () =>
    ok(['STRING', 'INTEGER', 'BOOLEAN', 'DECIMAL']),
  ),
  operation(FeatureTogglingServiceApi, 'getFeatures', ({ state }) => ok(state.features)),
  operation(FeatureTogglingServiceApi, 'editHotConfigFeatures', ({ state, input }) => {
    state.features = input.logicalFeatureDto
    return done(204)
  }),
  operation(FeatureTogglingServiceApi, 'featureApplications', ({ state }) =>
    ok(state.featureApplications),
  ),
  operation(FeatureTogglingServiceApi, 'createFeatures', ({ state, input }) => {
    const created = input.createFeaturesRequestInnerDto.map(
      ({ requestId, action, feature }) => ({
        id: Date.now(),
        type: ApplicationTypeDto.Feature,
        uid: randomUUID(),
        reasonId: requestId,
        featureName: feature.name,
        target: feature.target,
        status: ApplicationStatusDto.Pending,
        action,
        after: feature.config,
        created: new Date(),
        createdBy: 'mock.admin',
      }),
    )
    state.featureApplications.unshift(...created)
    return done(201)
  }),
  operation(FeatureTogglingServiceApi, 'loadFeatureDump', ({ state, input }) => {
    const dump = input.loadFeatureDumpRequestDto.dump ?? []
    const known = new Set(state.features.map(({ name }) => name))
    const updated = dump.filter(({ name }) => known.has(name)).length
    state.features = [
      ...state.features.filter(({ name }) => !dump.some((feature) => feature.name === name)),
      ...dump,
    ]
    return ok({ created: dump.length - updated, updated, skipped: 0 }, 201)
  }),
  operation(FeatureTogglingServiceApi, 'resolveApplication', ({ state, input }) => {
    const application = state.featureApplications.find((item) => item.uid === input.uid)
    if (!application) return fail(404, 'Feature application not found')
    application.status = input.resolveScriptApplicationRequestDto.status
    return ok(application)
  }),
  operation(FeatureTogglingServiceApi, 'featureStatistics', ({ state }) =>
    ok(
      state.features.map((feature, index) => ({
        name: feature.name,
        lastCallDate: localDate('2026-08-12'),
        callAmount: 1200 - index * 275,
      })),
    ),
  ),
]

const geoBalancingRoutes = [
  operation(GeoBalancingManagementServiceApi, 'getGeoBalancingServices', () =>
    ok([
      { name: 'tcpf-client-app', dataCenters: new Set(['MSK', 'SPB']) },
      { name: 'tcpf-contract-app', dataCenters: new Set(['MSK']) },
    ]),
  ),
  operation(GeoBalancingManagementServiceApi, 'getDataCenters', () =>
    ok(['MSK', 'SPB', 'EKB']),
  ),
  operation(GeoBalancingManagementServiceApi, 'getTrafficRestrictions', ({ state }) =>
    ok(state.trafficRestrictions),
  ),
  operation(
    GeoBalancingManagementServiceApi,
    'createTrafficRestriction',
    ({ state, input }) => {
      const restriction = {
        ...input.trafficRestrictionDtoDto,
        id: String(state.nextRestrictionId++),
        created: new Date(),
        createdBy: 'mock.admin',
      }
      state.trafficRestrictions.push(restriction)
      // В контракте у createTrafficRestriction объявлен только 200.
      return ok(restriction)
    },
  ),
  operation(
    GeoBalancingManagementServiceApi,
    'getTrafficRestrictionById',
    ({ state, input }) => {
      const restriction = state.trafficRestrictions.find((item) => item.id === input.id)
      return restriction ? ok(restriction) : fail(404, 'Restriction not found')
    },
  ),
  operation(
    GeoBalancingManagementServiceApi,
    'updateTrafficRestriction',
    ({ state, input }) => {
      const index = state.trafficRestrictions.findIndex((item) => item.id === input.id)
      if (index < 0) return fail(404, 'Restriction not found')
      state.trafficRestrictions[index] = {
        ...state.trafficRestrictions[index],
        ...input.trafficRestrictionDtoDto,
        id: input.id,
        updated: new Date(),
        updatedBy: 'mock.admin',
      }
      return ok(state.trafficRestrictions[index])
    },
  ),
  operation(
    GeoBalancingManagementServiceApi,
    'removeTrafficRestrictionById',
    ({ state, input }) => {
      state.trafficRestrictions = state.trafficRestrictions.filter(
        (item) => item.id !== input.id,
      )
      return done()
    },
  ),
]

export const operationRoutes = [
  ...userRoutes,
  ...processRoutes,
  ...operationDayRoutes,
  ...clientTransferRoutes,
  ...clusterRoutes,
  ...regionRoutes,
  ...monitoringRoutes,
  ...indexRoutes,
  ...revisionRoutes,
  ...scriptRoutes,
  ...featureRoutes,
  ...geoBalancingRoutes,
]
