import type { Request } from 'express'

import type { ApiClass, OperationInput, OperationName, OperationResult } from './contract'
import type { MockState } from './fixtures'

export interface Context<Input> {
  readonly state: MockState
  /** Параметры операции SDK по их именам в SDK (path, query, header, тело). */
  readonly input: Input
  readonly request: Request
}

/** Успешный ответ: модель, которую вернул бы метод SDK. */
export type Reply<T> = [T] extends [void]
  ? { readonly status?: number; readonly body?: undefined }
  : { readonly status?: number; readonly body: T }

/** Ошибка бэкенда: тело ErrorResponseDto. */
export interface Failure {
  readonly status: number
  readonly failure: string
}

export type Outcome<T> = Reply<T> | Failure

export const ok = <T>(body: T, status = 200) => ({ status, body })
export const done = (status?: number) => ({ status })
export const fail = (status: number, failure: string): Failure => ({ status, failure })

export const isFailure = (outcome: Outcome<unknown>): outcome is Failure => 'failure' in outcome

type Handler<A, N extends OperationName<A>> = (
  context: Context<OperationInput<A, N>>,
) => Outcome<OperationResult<A, N>> | Promise<Outcome<OperationResult<A, N>>>

export interface OperationRoute {
  readonly api: ApiClass<object> & { readonly name: string }
  readonly name: string
  readonly handle: (context: Context<Record<string, unknown>>) => Promise<Outcome<unknown>>
  /**
   * Поток, который после первого снимка продолжает присылать изменения, пока
   * клиент не отключится (Sink на бэкенде вместо конечного Flux).
   */
  readonly live?: (state: MockState) => unknown
}

/**
 * Обработчик операции SDK. Метод, путь, параметры, тело и формат ответа
 * берутся из SDK (см. contract.ts), типы входа и ответа — из сигнатуры метода.
 */
export const operation = <A extends object, N extends OperationName<A>>(
  api: ApiClass<A> & { readonly name: string },
  name: N,
  handler: Handler<A, N>,
  options: { live?: (state: MockState) => OperationResult<A, N> } = {},
): OperationRoute => ({
  api,
  name,
  handle: async (context) =>
    handler(context as unknown as Context<OperationInput<A, N>>) as Outcome<unknown>,
  live: options.live,
})
