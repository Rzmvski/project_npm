import { once } from 'node:events'

import { createMockServer } from './index'

const instance = await createMockServer({
  port: Number(process.env.MOCK_SERVER_PORT ?? 3001),
  host: process.env.MOCK_SERVER_HOST ?? '127.0.0.1',
})
process.stdout.write(`TCPF mock server: ${instance.url}\n`)
process.stdout.write(`Health check: ${instance.url}/health\n`)

await Promise.race([once(process, 'SIGINT'), once(process, 'SIGTERM')])
await instance.close()
