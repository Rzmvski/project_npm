// @vitest-environment node
import {
  ClusterManagementServiceApi,
  ClusterManagementServiceApiSse,
  Configuration,
  MonitoringManagementServiceApiSse,
  ResponseError,
  ScriptServiceApi,
  ServiceModeStateDto,
  UserServiceApi,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'
import {
  ClientTransferServiceApi,
  Configuration as SupportConfiguration,
  localDate,
  OperationDayServiceApi,
} from '@sber-pprb-tkp/tcpf-support-admin-api'
import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest'

import { apiClasses, operationNames, resolveOperation } from '../contract'
import { createMockServer, type MockServer } from '../index'
import { operationRoutes } from '../routes'

const collect = async <T>(stream: AsyncGenerator<T>, limit = Infinity) => {
  const items: T[] = []
  for await (const item of stream) {
    items.push(item)
    if (items.length >= limit) break
  }
  return items
}

describe('контракт мока', () => {
  it('реализует каждую операцию SDK ровно один раз', () => {
    const sdkOperations = apiClasses().flatMap((api) =>
      operationNames(api).map((name) => `${api.name}.${name}`),
    )
    const mocked = operationRoutes.map(({ api, name }) => `${api.name}.${name}`)

    expect(mocked.toSorted()).toEqual(sdkOperations.toSorted())
  })

  it('берёт метод, путь, заголовки, тело и SSE из SDK', async () => {
    const operation = await resolveOperation(
      ClusterManagementServiceApi,
      'updateNodesOfShardById',
    )

    expect(operation).toMatchObject({
      method: 'PUT',
      path: '/invoke/support-admin/cluster-management-service/shard/:ids/nodes',
      sse: true,
      response: 'json',
      pathKeys: ['ids'],
      body: { key: 'shardUpdateDto' },
    })
    expect([...operation.headers]).toEqual([['x-region', 'xRegion']])
  })
})

describe('mock-сервер через SDK', () => {
  let mock: MockServer
  let platform: Configuration
  let support: SupportConfiguration

  beforeAll(async () => {
    mock = await createMockServer({ port: 0, quiet: true, responseDelay: () => 0 })
    platform = new Configuration({ basePath: mock.url })
    support = new SupportConfiguration({ basePath: mock.url })
  })

  beforeEach(async () => {
    await fetch(`${mock.url}/__mock/reset`, { method: 'POST' })
  })

  afterAll(async () => {
    await mock.close()
  })

  it('отдаёт модели, которые читает SDK', async () => {
    const serviceMode = await new ClusterManagementServiceApi(platform).getServiceMode()
    const roles = await new UserServiceApi(platform).getRoles()
    const script = await new ScriptServiceApi(platform).getScript('CHG-2026-1042')
    const currentOd = await new OperationDayServiceApi(support).currentOd()

    expect(serviceMode.status).toBe(ServiceModeStateDto.Disabled)
    expect(serviceMode.startedAt).toBeInstanceOf(Date)
    expect(Array.from(roles)).toEqual(['ADMIN', 'TKP_SUPPORT'])
    expect(script).toBe("return 'fixture result'")
    expect(currentOd).toBe('2026-08-12')
  })

  it('отдаёт SSE-операции потоком по элементу на событие', async () => {
    const shards = await collect(new ClusterManagementServiceApiSse(platform).getShardsStream())

    expect(shards).toHaveLength(20)
    expect(shards[0].bucketRanges[0]).toMatchObject({ nodeKey: 'P1', sameDC: true })
  })

  it('продолжает поток мониторинга БД после первого снимка', async () => {
    const controller = new AbortController()
    const stream = new MonitoringManagementServiceApiSse(platform).getDbMonitoringsStream({
      signal: controller.signal,
    })
    const monitorings = await collect(stream, 60)
    controller.abort()

    expect(monitorings.length).toBe(60)
  })

  it('меняет границу шарды только в её регионе', async () => {
    const api = new ClusterManagementServiceApiSse(platform)

    await expect(
      collect(api.updateNodesOfShardByIdStream([1], { bucketBoundary: [100] }, 'east')),
    ).rejects.toBeInstanceOf(ResponseError)

    const shards = await collect(
      api.updateNodesOfShardByIdStream([1], { bucketBoundary: [100] }, 'central'),
    )
    expect(
      shards.find(({ id }) => id === 1)?.bucketRanges.map((range) => range.endExclusive),
    ).toEqual([100, 32768])
  })

  it('принимает тело, собранное SDK', async () => {
    const started = await new ClientTransferServiceApi(support).transfer({
      shardIds: [1, 2],
      deleteUpToDate: localDate('2026-08-10'),
    })

    expect(started).toMatchObject({ processName: 'client-transfer' })
  })

  it.each([
    [
      'невалидный LocalDate',
      'POST',
      'client-transfer-service/transfer',
      { shardIds: [1], deleteUpToDate: '2026-13-40' },
    ],
    ['нет обязательного поля', 'PUT', 'cluster-management-service/service-mode', {}],
  ])(
    'отвечает 400, если тело не читается моделью SDK: %s',
    async (_case, method, path, body) => {
      const response = await fetch(`${mock.url}/invoke/support-admin/${path}`, {
        method,
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(body),
      })

      expect(response.status).toBe(400)
    },
  )
})
