/**
 * Поведение мока во времени: процессы с прогрессом, переходы кластеров
 * индексов и «живой» лаг репликации в мониторинге БД.
 */
import {
  ClusterStateDto,
  IndexActionsDto,
  type MonitoringDto,
  MonitoringStateDto,
  PoolStateDto,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { type MockCluster, type MockProcess, type MockState, processFields } from './fixtures'

export const updateTimedProcess = (state: MockState, id: number, now = Date.now()) => {
  const process = state.processes[id]
  const timeline = state.processTimelines[id]
  const group = process?.data?.groupOfProcesses
  if (!process || !timeline || !group || process.done) return process

  const elapsedMs = Math.max(0, now - timeline.startedAtMs)
  const progress = Math.min(1, elapsedMs / timeline.durationMs)
  const lastUpdate = new Date(now)

  process.done = progress >= 1
  process.data!.lastUpdate = lastUpdate
  group.statusGroup = process.done ? 'COMPLETED' : 'RUNNING'
  group.numbersMinutesAtWork = String(Math.max(1, Math.ceil(elapsedMs / 60_000)))

  for (const field of group.fields ?? []) {
    const totalRecords = Number(field.totalRecords ?? field.recordsWillBeProcessed ?? 0)
    const recordsProcessed = Math.min(totalRecords, Math.floor(totalRecords * progress))
    const processedWithError =
      recordsProcessed > 0 && Number(field.stepInGroup) % 11 === 0 ? 1 : 0

    field.status = process.done ? 'COMPLETED' : 'RUNNING'
    field.recordsProcessed = String(recordsProcessed)
    field.processedWithError = String(processedWithError)
    field.processedCorrectly = String(recordsProcessed - processedWithError)
    field.loading = progress.toFixed(2)
    field.numberMinutesAtWork = group.numbersMinutesAtWork
    field.lastUpdate = lastUpdate
    if (process.done) field.endTime = lastUpdate
  }

  if (process.done) delete state.processTimelines[id]

  return process
}

export const findProcess = (state: MockState, id: number): MockProcess =>
  updateTimedProcess(state, id) ?? {
    sessionId: id,
    done: true,
    data: {
      lastUpdate: new Date(),
      groupOfProcesses: {
        statusGroup: 'COMPLETED',
        numbersMinutesAtWork: '3',
        timeStart: new Date('2026-08-12T09:00:00.000Z'),
        dateOD: state.operationDays.currentOperationDay,
        fields: structuredClone(processFields),
      },
    },
  }

export const updateIndexTransitions = (clusters: MockCluster[]) => {
  const now = Date.now()
  for (const cluster of clusters) {
    if (!cluster.transitionStartedAt) continue
    const elapsed = now - cluster.transitionStartedAt
    if (elapsed < 2000) {
      cluster.state = ClusterStateDto.Creating
    } else if (elapsed < 6000) {
      cluster.state = ClusterStateDto.OnLoading
    } else {
      cluster.state = ClusterStateDto.Active
      cluster.availableActions = IndexActionsDto.Deactivate
      cluster.updateRequired = false
      delete cluster.transitionStartedAt
    }
  }
}

const dbMonitorings = (state: MockState): MonitoringDto[] =>
  state.nodes.map(({ key, monitoringState }) => {
    // Начиная с platform-api 2.1 статус пула коннектов — отдельный ресурс
    // (getPools()), поэтому для UP/DOWN по умолчанию смотрим на него, а не
    // на саму ноду.
    const connectionState = state.pools.find((pool) => pool.key === key)?.status
    const monitorState =
      monitoringState ??
      (connectionState === PoolStateDto.Active
        ? MonitoringStateDto.Up
        : MonitoringStateDto.Down)
    return {
      id: key,
      state: monitorState,
      // Пока мониторинг DOWN, лаг репликации недоступен.
      replicaLag:
        monitorState === MonitoringStateDto.Down ? undefined : key.startsWith('P') ? 0 : 42,
    }
  })

// Лаг большую часть времени "дышит" в безопасном диапазоне ниже порога
// и лишь изредка кратковременно выходит за него, после чего быстро
// восстанавливается обратно к норме.
const LAG = {
  normalMin: 0,
  normalMax: 18,
  minStep: 1,
  maxStep: 4,
  spikeMin: 35,
  spikeMax: 90,
  spikeChance: 0.05,
  spikeRecoveryMinStep: 8,
  spikeRecoveryMaxStep: 25,
}

export type LagOptions = Partial<typeof LAG> & { random?: () => number }

const randomInteger = (min: number, max: number, random: () => number) =>
  Math.floor(random() * (max - min + 1)) + min

const reserveUniqueLag = (
  value: number,
  occupied: Set<number>,
  direction: number,
  min: number,
  max: number,
) => {
  if (!occupied.has(value)) return value

  for (let offset = 1; offset <= max - min; offset += 1) {
    for (const candidate of [value + offset * direction, value - offset * direction]) {
      if (candidate >= min && candidate <= max && !occupied.has(candidate)) return candidate
    }
  }

  return value
}

export const createDbMonitoringEmitter = (
  state: MockState,
  { random = Math.random, ...overrides }: LagOptions = {},
) => {
  const lag = { ...LAG, ...overrides }
  const occupiedInitialValues = new Set<number>()
  const lagStates = state.nodes.map(() => {
    const value = reserveUniqueLag(
      randomInteger(lag.normalMin, lag.normalMax, random),
      occupiedInitialValues,
      1,
      lag.normalMin,
      lag.normalMax,
    )
    occupiedInitialValues.add(value)
    // Большую часть времени узел находится в "нормальном" режиме и
    // плавно дрейфует в безопасном диапазоне. spiking=true — короткий
    // эпизод превышения порога, из которого лаг быстро восстанавливается.
    return { value, spiking: false }
  })

  return (): MonitoringDto[] => {
    const occupiedNormal = new Set<number>()
    const occupiedSpike = new Set<number>()
    const reserve = (value: number, spike: boolean, direction = 1) => {
      const occupied = spike ? occupiedSpike : occupiedNormal
      const reserved = spike
        ? reserveUniqueLag(value, occupied, direction, lag.spikeMin, lag.spikeMax)
        : reserveUniqueLag(value, occupied, direction, lag.normalMin, lag.normalMax)
      occupied.add(reserved)
      return reserved
    }

    // Состояние узла читаем заново на каждом тике, а не один раз при
    // открытии SSE-соединения — иначе переключение UP/DOWN во время
    // подключения не отражалось бы в потоке.
    return dbMonitorings(state).map((monitoring, index) => {
      const lagState = lagStates[index]

      // Мониторинг недоступен: лаг не публикуется и не обновляется, чтобы при
      // восстановлении узел продолжил со своего последнего значения.
      if (monitoring.state === MonitoringStateDto.Down) return monitoring

      if (lagState.spiking) {
        // В режиме всплеска лаг быстро снижается обратно к норме.
        const decayed =
          lagState.value -
          randomInteger(lag.spikeRecoveryMinStep, lag.spikeRecoveryMaxStep, random)
        lagState.spiking = decayed > lag.normalMax
        lagState.value = lagState.spiking
          ? reserve(decayed, true, -1)
          : reserve(randomInteger(lag.normalMin, lag.normalMax, random), false)
      } else if (random() < lag.spikeChance) {
        // Редкий кратковременный выход лага за пределы нормы.
        lagState.spiking = true
        lagState.value = reserve(randomInteger(lag.spikeMin, lag.spikeMax, random), true)
      } else {
        // Обычный дрейф внутри безопасного диапазона.
        const direction = random() < 0.5 ? -1 : 1
        const wandered = Math.min(
          lag.normalMax,
          Math.max(
            lag.normalMin,
            lagState.value + randomInteger(lag.minStep, lag.maxStep, random) * direction,
          ),
        )
        lagState.value = reserve(wandered, false, direction)
      }

      return { ...monitoring, replicaLag: lagState.value }
    })
  }
}

/**
 * Эмиттер лага живёт рядом с состоянием, а не внутри него: класть функцию в
 * state нельзя, его клонируют структурно.
 */
const dbMonitoringEmitters = new WeakMap<MockState, () => MonitoringDto[]>()

export const nextDbMonitorings = (state: MockState) => {
  let emitter = dbMonitoringEmitters.get(state)
  if (!emitter) {
    emitter = createDbMonitoringEmitter(state)
    dbMonitoringEmitters.set(state, emitter)
  }
  return emitter()
}
