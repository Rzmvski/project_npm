## ADDED Requirements

### Requirement: Permanent readable badge

The UI SHALL display the environment type label on all common-layout pages without requiring business permissions or allowing dismissal.

#### Scenario: Integration label

- **WHEN** metadata contains integration
- **THEN** the header displays «Среда интеграционного тестирования» across route navigation

### Requirement: Loading and unknown states

The UI SHALL show «Определение среды…» initially and «Среда не определена» for unknown type, malformed response or failed retrieval without breaking other controls.

#### Scenario: Older app

- **WHEN** the endpoint returns 404 or 405
- **THEN** the UI shows the unknown state without retrying that response

### Requirement: Request lifecycle

The UI SHALL use the published SDK, refresh on application load and refocus, use a 10 second timeout per attempt and at most one retry for network errors or 5xx. It SHALL preserve authentication behavior and avoid repeated global notifications.

#### Scenario: Refresh failure

- **WHEN** previously loaded metadata fails to refresh
- **THEN** the badge changes to unknown instead of retaining a confirmed old label

### Requirement: Target isolation

The UI SHALL isolate metadata by actual API target and ignore late responses for previous targets.

#### Scenario: Contour target changes

- **WHEN** a pending request belongs to a previously selected target
- **THEN** its response does not overwrite the current badge

### Requirement: Accessible presentation

The UI SHALL render plain text with contrast at least 4.5:1 and provide full text without hover at supported viewport sizes.

#### Scenario: Long label on narrow viewport

- **WHEN** the full integration environment label is displayed
- **THEN** the label remains readable and header navigation and logout remain usable
