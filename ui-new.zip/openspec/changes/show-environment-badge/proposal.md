# Бэдж среды в общей шапке

## Why

Локальная часть сквозной функции обозначения среды: пользователь должен понимать, на каком стенде выполняет операции.

## What Changes

Показывать сведения о среде из опубликованного SDK в общей шапке. Добавить загрузку, неизвестное состояние, доступное оформление, mock и проверки. Использовать API change add-environment-info-contract.

## Capabilities

### New Capabilities

- `environment-badge`: Бэдж среды в общей шапке.

### Modified Capabilities

Не определены. При наличии базовых specs в целевом репозитории сверить capabilities до реализации.

## Impact

Изменения ограничены проектом ui; общий контракт и зависимости согласуются через support-admin-specs.

## Upstream

Store `support-admin-specs`, change `add-environment-badge`: прочитать proposal.md, design.md и specs/environment-identification/spec.md из активного change. references не заменяет чтение активного change.
