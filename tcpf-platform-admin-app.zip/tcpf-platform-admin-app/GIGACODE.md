# TCPF Platform Admin App

## Role

Spring Boot backend for platform administration capabilities.

Implements contracts from tcpf-platform-admin-api.

Do not place TCPF-support-specific behavior here unless the
OpenSpec design explicitly assigns ownership to the platform domain.

## Stack

- Java 17
- Spring Boot
- Hibernate
- MapStruct
- Lombok
- Micrometer

## Validation

Fast:
- targeted tests for changed modules/classes

Full:
- full Maven verify lifecycle
