package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.routing.api.v1_0.client.model.Node;
import sbp.tcpf.routing.api.v1_0.client.model.Region;
import sbp.tcpf.routing.api.v1_0.client.model.Shard;
import sbp.tcpf.support_admin.model.RegionDto;

import org.mapstruct.Mapper;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING)
public interface ShardMapper {

    sbp.tcpf.support_admin.model.Node map(Node node);

    sbp.tcpf.support_admin.model.Shard map(Shard node);

    RegionDto map(Region region);

//    String SLASH_DELIMITER = "/";

//    @Mapping(target = "type", constant = "POSTGRESQL")
//    @Mapping(target = "name", source = "nodes", qualifiedByName = "getShardName")
//    Shard convert(Integer id, List<Node> nodes);

//    @Named("getShardName")
//    default String getName(List<Node> nodes) {
//        return nodes.stream()
//                .map(Node::getKey)
//                .collect(Collectors.joining(SLASH_DELIMITER));
//    }
}
