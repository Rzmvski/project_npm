package sbp.tcpf.support_admin.configs.feign;

import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.util.ClassUtils;
import org.springframework.web.bind.annotation.PathVariable;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Arrays;
import java.util.Collection;

import reactivefeign.spring.config.ReactiveFeignClient;

public class ReactiveFeignCollectionArgumentPostProcessor implements BeanPostProcessor {

    @Override
    public Object postProcessAfterInitialization(Object bean, @NotNull String beanName) {
        Class<?>[] interfaces = ClassUtils.getAllInterfacesForClass(bean.getClass());

        if (Arrays.stream(interfaces)
                  .noneMatch(clazz -> AnnotatedElementUtils.hasAnnotation(
                          clazz, ReactiveFeignClient.class
                  ))) {
            return bean;
        }

        return Proxy.newProxyInstance(
                bean.getClass().getClassLoader(),
                interfaces,
                new Handler(bean)
        );
    }

    private record Handler(Object target) implements InvocationHandler {

        @Override
        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            try {
                return method.invoke(target, normalize(method, args));
            } catch (InvocationTargetException e) {
                throw e.getCause();
            }
        }

        private static Object[] normalize(Method method, Object[] args) {
            if (args == null) {
                return null;
            }

            Object[] result = null;
            var parameters = method.getParameters();

            for (int i = 0; i < args.length; i++) {
                if (!(args[i] instanceof Collection<?> collection)
                        || !parameters[i].isAnnotationPresent(PathVariable.class)) {
                    continue;
                }

                if (result == null) {
                    result = args.clone();
                }

                result[i] = new CommaSeparatedList<>(collection);
            }

            return result != null ? result : args;
        }
    }
}
