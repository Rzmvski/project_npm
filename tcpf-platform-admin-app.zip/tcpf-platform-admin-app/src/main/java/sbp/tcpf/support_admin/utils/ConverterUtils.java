package sbp.tcpf.support_admin.utils;

import org.mapstruct.Named;
import lombok.experimental.UtilityClass;

import java.nio.charset.StandardCharsets;
import java.util.Optional;

@UtilityClass
public class ConverterUtils {

    public static byte[] toBytes(String data) {
        return data.getBytes(StandardCharsets.UTF_8);
    }

    public static String toString(byte[] data) {
        return Optional.ofNullable(data)
                       .map(bytes -> new String(bytes, StandardCharsets.UTF_8))
                       .orElse(null);
    }

    @Named("emptyToNull")
    public static String emptyToNull(String value) {
        return Optional.ofNullable(value)
                       .filter(string -> !string.isBlank())
                       .orElse(null);
    }
}
