package sbp.tcpf.support_admin.configs

import com.fasterxml.jackson.databind.DeserializationFeature
import com.fasterxml.jackson.databind.ObjectMapper
import org.springframework.context.annotation.Configuration
import javax.annotation.PostConstruct

@Configuration
class JacksonCustomizer(
    private val objectMapper: ObjectMapper
) {
    @PostConstruct
    fun customize() {
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
    }
}
