package sbp.tcpf.support_admin.services

import org.springframework.stereotype.Service
import reactor.core.publisher.Flux
import sbp.tcpf.os.commons.config.ModuleProperties
import sbp.tcpf.routing.api.v1_0.client.model.Region
import sbp.tcpf.support.commons.auth.services.UserService
import sbp.tcpf.support_admin.clients.feign.routing.RoutingManagementApiClient
import sbp.tcpf.support_admin.configs.properties.RoutingAppOsProperties
import sbp.tcpf.support_admin.mappers.SemaphoreMapper
import sbp.tcpf.support_admin.mappers.ShardMapper
import sbp.tcpf.support_admin.mappers.UpdateShardMapper
import sbp.tcpf.support_admin.model.BucketRangeUpdate
import sbp.tcpf.support_admin.model.Node
import sbp.tcpf.support_admin.model.Shard
import sbp.tcpf.support_admin.model.ShardUpdate
import sbp.tcpf.support_admin.utils.toMono
import java.time.OffsetDateTime
import java.util.*

@Service
class NodeManagementService(
    private val updateShardMapper: UpdateShardMapper,
    private val semaphoreMapper: SemaphoreMapper,
    private val shardMapper: ShardMapper,
    private val routingManagementApiClient: RoutingManagementApiClient,
    private val userService: UserService,
    private val moduleProperties: ModuleProperties,
    private val routingAppOsProperties: RoutingAppOsProperties,
) {

    fun getShards(): Flux<Shard> {
        return routingManagementApiClient.getShards(null)
            .map { shard -> normalizeRegion(shard); shardMapper.map(shard) }
    }

    // region — регион обслуживания (X-Region), в котором routing применяет изменение.
    fun changeLoadRatio(shardIds: List<Int>, request: ShardUpdate, region: String?): Flux<Shard> {
        val updateRequest = updateShardMapper.convert(request)
        return routingManagementApiClient.updateNodesOfShardById(
                shardIds,
                updateRequest.toMono(),
                moduleProperties.moduleId,
                userService.getUserLogin(),
                UUID.randomUUID().toString(),
                OffsetDateTime.now(),
                region
        ).map { shard -> normalizeRegion(shard); shardMapper.map(shard) }
    }

    fun changeSemaphores(shardId: Int, update: BucketRangeUpdate, region: String?): Flux<Shard> {
        val updateRange = semaphoreMapper.convert(update)

        return routingManagementApiClient.updateSemaphoresOfShardById(
                shardId,
                updateRange.toMono(),
                moduleProperties.moduleId,
                userService.getUserLogin(),
                UUID.randomUUID().toString(),
                OffsetDateTime.now(),
                region
        ).map { shard -> normalizeRegion(shard); shardMapper.map(shard) }
    }

    fun getNodes(): Flux<Node> {
        return routingManagementApiClient.getNodes(null)
            .map { node -> shardMapper.map(node) }
    }

    // Шарды без назначенного региона считаются принадлежащими дефолтному региону.
    // Downstream может не прислать поле вовсе (null) — это тоже «не назначен».
    // Доступность дефолтного региона здесь неизвестна (она хранится в группах
    // регионов), поэтому передаётся `true`; UI берёт фактическую доступность из
    // GET /region/groups и использует это значение только как запасное.
    private fun normalizeRegion(shard: sbp.tcpf.routing.api.v1_0.client.model.Shard) {
        if (shard.region.isNullOrEmpty()) {
            shard.region(listOf(Region().region(routingAppOsProperties.defaultRegion()).regionAvailability(true)))
        }
    }
}
