package sbp.tcpf.support_admin.validators

import jakarta.validation.ConstraintValidator
import jakarta.validation.ConstraintValidatorContext
import sbp.tcpf.support_admin.validators.annotations.TwoPersonConstraint
import java.lang.reflect.Field

class TwoPersonValidator : ConstraintValidator<TwoPersonConstraint, Any> {

    private lateinit var creatorFieldName: String
    private lateinit var resolverFieldName: String

    override fun initialize(constraintAnnotation: TwoPersonConstraint) {
        creatorFieldName = constraintAnnotation.creatorFieldName
        resolverFieldName = constraintAnnotation.resolverFieldName
    }

    override fun isValid(value: Any, context: ConstraintValidatorContext): Boolean {
        val fields = getAllFields(value::class.java)

        val creatorField = fields.findFieldByName(creatorFieldName)
        val resolverField = fields.findFieldByName(resolverFieldName)

        if (creatorField == null || resolverField == null) {
            context.addViolation(MISSING_FIELDS_MESSAGE)
            return false
        }

        val creator = creatorField[value]
        val resolver = resolverField[value]

        if (creator == resolver) {
            context.addViolation(SAME_VALUES_MESSAGE)
            return false
        }

        return true
    }

    private fun ConstraintValidatorContext.addViolation(message: String) {
        this.disableDefaultConstraintViolation()
        this.buildConstraintViolationWithTemplate(message).addConstraintViolation()
    }

    private fun getAllFields(valueClass: Class<*>): List<Field> {
        return generateSequence(valueClass) { it.superclass }
            .flatMap { it.declaredFields.asSequence() }
            .toList()
    }

    private fun List<Field>.findFieldByName(name: String): Field? {
        return this.find { it.name == name }?.apply { isAccessible = true }
    }

    companion object {
        const val MISSING_FIELDS_MESSAGE = "Creator or resolver fields not found"
        const val SAME_VALUES_MESSAGE = "Creator and resolver must not be the same"
    }
}
