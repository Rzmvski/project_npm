package sbp.tcpf.support_admin.configs;

import sbp.tcpf.ff4j.client.config.CuratorFacade;
import sbp.tcpf.ff4j.client.config.FF4jClientConfig;
import sbp.tcpf.ff4j.client.facade.FF4jClient;
import sbp.tcpf.ff4j.config.FF4jClientProperties;
import sbp.tcpf.os.commons.config.ModuleProperties;

import org.apache.curator.framework.CuratorFramework;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class Ff4jConfig {

    //todo: if you ff4j admin, why you need this?
    @Bean
    @Primary
    public FF4jClient ff4jClient(@CuratorFacade.FeatureTogglingCuratorBean CuratorFramework curatorFramework,
                                 FF4jClientProperties ff4jClientProperties,
                                 FF4jClientConfig clientConfig) {
        return new FF4jClient(curatorFramework,
                              ff4jClientProperties,
                              clientConfig.moduleName());
    }

    @Bean
    public FF4jClientConfig ff4jClientConfig(ModuleProperties moduleProperties) {
        return new FF4jClientConfig(moduleProperties.getModuleId());
    }
}
