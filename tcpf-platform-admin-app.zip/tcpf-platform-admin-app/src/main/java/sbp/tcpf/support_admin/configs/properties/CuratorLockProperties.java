package sbp.tcpf.support_admin.configs.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

import java.time.Duration;

@ConfigurationProperties("curator-lock-service")
public record CuratorLockProperties(
        @DefaultValue("10s") Duration timeout
) {
}
