package sbp.tcpf.support_admin.services.request.resolvers

import sbp.tcpf.support_admin.model.ApplicationStatus

interface RequestResolver<T> {

    val status: ApplicationStatus

    fun resolve(application: T): T
}
