package sbp.tcpf.support_admin.services.request.cache

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import org.apache.curator.framework.recipes.cache.ChildData
import org.apache.curator.framework.recipes.cache.CuratorCacheListener
import org.apache.curator.framework.recipes.queue.DistributedDelayQueue
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import sbp.tcpf.support_admin.configs.properties.ResolveRequestServiceProperties
import sbp.tcpf.support_admin.entities.AbstractRequest
import sbp.tcpf.support_admin.model.ApplicationType
import sbp.tcpf.support_admin.utils.createdAt
import sbp.tcpf.support_admin.utils.put

@Component
class ArchiveCacheListener(
    private val objectMapper: ObjectMapper,
    private val distributedQueue: DistributedDelayQueue<String>,
    private val resolveRequestServiceProperties: ResolveRequestServiceProperties,
) : CuratorCacheListener {

    override fun event(
        type: CuratorCacheListener.Type,
        oldData: ChildData?,
        newData: ChildData?,
    ) {
        when (type) {
            CuratorCacheListener.Type.NODE_CREATED -> {
                if (newData == null || newData.data.isEmpty()) return
                onCreates(newData)
            }

            else -> Unit
        }
    }

    private fun onCreates(createdNode: ChildData) {
        val content = objectMapper.readValue<AbstractRequest>(createdNode.data)
        if (content.type !== ApplicationType.SCRIPT) return
        val createdTime = createdNode.stat.createdAt()
        val expirationTime = createdTime.plus(resolveRequestServiceProperties.archiveTtl)
        val path = createdNode.path
        distributedQueue.put(path, expirationTime)
        log.debug("node for path {} was added in expiration queue and will be archived at {}", path, expirationTime)
    }

    companion object {
        private val log: Logger = LoggerFactory.getLogger(ArchiveCacheListener::class.java)
    }
}
