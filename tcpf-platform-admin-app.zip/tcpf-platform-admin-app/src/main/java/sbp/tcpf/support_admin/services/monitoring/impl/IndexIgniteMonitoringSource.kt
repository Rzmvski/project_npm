package sbp.tcpf.support_admin.services.monitoring.impl

import org.springframework.stereotype.Component
import reactor.core.publisher.Flux
import sbp.tcpf.support_admin.clients.feign.zone_index.ZoneIndexMonitoringManagementApi
import sbp.tcpf.support_admin.mappers.MonitoringMapper
import sbp.tcpf.support_admin.model.IgniteType
import sbp.tcpf.support_admin.model.Monitoring
import sbp.tcpf.support_admin.services.monitoring.IgniteMonitoringSource
import sbp.tcpf.support_admin.utils.getResponseOrThrowWithMessage

@Component
class IndexIgniteMonitoringSource(
    private val zoneIndexMonitoringManagementApi: ZoneIndexMonitoringManagementApi,
    private val monitoringMapper: MonitoringMapper,
) : IgniteMonitoringSource {

    override val type: IgniteType = IgniteType.INDEX

    override fun load(): Flux<Monitoring> {
        return zoneIndexMonitoringManagementApi.igniteMonitorings
            .getResponseOrThrowWithMessage("Can not load index monitoring")
            .let { Flux.fromIterable(it) }
            .map { monitoringMapper.convert(it) }
    }
}
