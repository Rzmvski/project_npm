package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.support_admin.model.RegionDto;
import sbp.tcpf.support_admin.model.RegionGroupDto;
import sbp.tcpf.routing.api.v1_0.client.model.Region;
import sbp.tcpf.routing.api.v1_0.client.model.RegionGroup;

import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface RegionManagementServiceMapper {

    RegionDto convert(Region region);

    Region convert(RegionDto region);

    RegionGroupDto convert(RegionGroup regionGroup);

    RegionGroup convert(RegionGroupDto regionGroup);
}