package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.support_admin.model.GeoBalancingService;

import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface GeoBalancingServiceMapper {

    GeoBalancingService convert(sbp.tcpf.routing.api.v1_0.client.model.GeoBalancingService service);
}
