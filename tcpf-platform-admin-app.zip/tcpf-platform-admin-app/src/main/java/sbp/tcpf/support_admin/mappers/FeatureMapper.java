package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.ff4j.utils.FeatureBuilder;
import sbp.tcpf.support_admin.dto.FeatureLocation;
import sbp.tcpf.support_admin.dto.FeatureSnapshot;
import sbp.tcpf.support_admin.model.LogicalFeature;

import org.ff4j.core.Feature;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.Optional;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(
        componentModel = SPRING,
        uses = {
                FeatureActivationMapper.class,
                FeatureConfigurationMapper.class,
                CustomPropertyMapper.class,
        }
)
public interface FeatureMapper {

    @Mapping(target = "permissions", ignore = true)
    @Mapping(target = "group", ignore = true)
    @Mapping(target = "isHotConfig", source = "hot", dependsOn = "customProperties")
    @Mapping(target = "uid", source = "name")
    @Mapping(target = "strategy", source = "configuration.flippingStrategy")
    @Mapping(target = "enable", source = "configuration.enable")
    @Mapping(target = "description", source = "configuration.description")
    @Mapping(target = "customProperties", source = "configuration.customProperties")
    FeatureBuilder convert(FeatureSnapshot snapshot);

    default Feature map(FeatureSnapshot snapshot) {
        FeatureBuilder builder = convert(snapshot);
        return buildFeature(builder);
    }

    @Mapping(target = "configuration", source = "feature.config")
    FeatureSnapshot map(LogicalFeature feature, FeatureLocation location);

    default Feature buildFeature(FeatureBuilder builder) {
        return Optional.ofNullable(builder)
                       .map(FeatureBuilder::build)
                       .orElse(null);
    }

    default FeatureBuilder createBuilder() {
        return FeatureBuilder.builder();
    }
}
