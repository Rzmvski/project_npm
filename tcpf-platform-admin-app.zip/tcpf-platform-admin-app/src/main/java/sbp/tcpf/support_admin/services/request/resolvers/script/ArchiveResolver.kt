package sbp.tcpf.support_admin.services.request.resolvers

import org.springframework.stereotype.Component
import sbp.tcpf.support_admin.dto.ScriptApplicationDto
import sbp.tcpf.support_admin.model.ApplicationStatus
import sbp.tcpf.support_admin.services.request.store.CompositeScriptDataStore

@Component
class ArchiveResolver(
    private val store: CompositeScriptDataStore,
) : RequestResolver<ScriptApplicationDto> {

    override val status: ApplicationStatus = ApplicationStatus.ARCHIVED

    override fun resolve(
        application: ScriptApplicationDto,
    ): ScriptApplicationDto {
        return store.changeStatus(
                application.location,
                ApplicationStatus.ARCHIVED
        )
    }
}
