package sbp.tcpf.support_admin.clients.feign.script_engine;

import sbp.tcpf.script.engine.api.TemplateServiceApi;
import sbp.tcpf.support_admin.clients.feign.script_engine.config.ScriptEngineFeignConfig;

import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(
        name = "TemplateServiceApi",
        url = "${tcpf-platform-admin-app.script-service.uri}",
        configuration = ScriptEngineFeignConfig.class
)
public interface ScriptTemplateApi extends TemplateServiceApi {
}
