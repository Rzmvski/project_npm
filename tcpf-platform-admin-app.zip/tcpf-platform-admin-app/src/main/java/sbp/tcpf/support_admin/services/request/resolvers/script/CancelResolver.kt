package sbp.tcpf.support_admin.services.request.resolvers

import org.springframework.stereotype.Component
import sbp.tcpf.script.engine.async.model.StopCommand
import sbp.tcpf.support_admin.clients.kafka.ScriptEngineCommandPublisher
import sbp.tcpf.support_admin.dto.ScriptApplicationDto
import sbp.tcpf.support_admin.entities.ScriptRequest
import sbp.tcpf.support_admin.mappers.ScriptZkEntityMapper
import sbp.tcpf.support_admin.model.ApplicationStatus
import sbp.tcpf.support_admin.services.request.cache.RequestCuratorCacheManager

@Component
class CancelResolver(
    private val engineCommandPublisher: ScriptEngineCommandPublisher,
    private val requestCuratorCacheManager: RequestCuratorCacheManager,
    private val scriptZkEntityMapper: ScriptZkEntityMapper,
) : RequestResolver<ScriptApplicationDto> {

    override val status: ApplicationStatus = ApplicationStatus.CANCELED

    override fun resolve(application: ScriptApplicationDto): ScriptApplicationDto {
        val (scriptId, shardId) = application.location
        val command = StopCommand(scriptId)
        engineCommandPublisher.sendCommand(command)

        return requestCuratorCacheManager
            .getByUid(scriptId, ScriptRequest::class.java)
            .let { scriptZkEntityMapper.toDto(it) }
    }
}
