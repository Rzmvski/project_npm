package sbp.tcpf.support_admin.controllers;

import sbp.tcpf.support.commons.auth.services.UserService;
import sbp.tcpf.support_admin.api.UserServiceApi;

import org.springframework.web.bind.annotation.RestController;
import lombok.RequiredArgsConstructor;

import java.util.Set;

import static sbp.tcpf.base.metrics.TcpfMetrics.SERVICE;
import static sbp.tcpf.base.metrics.TcpfMetrics.SERVICE_CALL;

import io.micrometer.core.annotation.Timed;

@RestController
@RequiredArgsConstructor
public class UserServiceController implements UserServiceApi {

    private final UserService userService;

    @Override
    @Timed(value = SERVICE_CALL, extraTags = { SERVICE, "UserService" })
    public Set<String> getPermissions() {
        return userService.getPermissions();
    }

    @Override
    @Timed(value = SERVICE_CALL, extraTags = { SERVICE, "UserService" })
    public Set<String> getRoles() {
        return userService.getRoles();
    }

}
