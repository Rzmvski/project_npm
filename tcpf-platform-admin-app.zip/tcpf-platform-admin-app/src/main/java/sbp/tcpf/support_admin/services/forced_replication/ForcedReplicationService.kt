package sbp.tcpf.support_admin.services.forced_replication

import sbp.tcpf.support_admin.model.OperationResponseDto
import sbp.tcpf.support_admin.model.ReplicationStatusDto
import sbp.tcpf.support_admin.model.ServiceModeState
import sbp.tcpf.support_admin.model.ServiceModeStatusDto

interface ForcedReplicationService {

    fun getReplicationStatus(shardId: Int): ReplicationStatusDto

    fun getServiceModeStatus(): ServiceModeStatusDto

    fun startReplication(shardId: Int): OperationResponseDto

    fun undoReplication(shardId: Int): OperationResponseDto

    fun changeServiceMode(serviceModeState: ServiceModeState): OperationResponseDto
}
