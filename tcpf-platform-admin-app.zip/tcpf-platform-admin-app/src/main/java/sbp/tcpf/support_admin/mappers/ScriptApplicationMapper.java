package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.support_admin.dto.ScriptApplicationDto;
import sbp.tcpf.support_admin.model.ScriptApplication;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface ScriptApplicationMapper {

    @Mapping(target = "reasonId", source = "location.scriptId")
    @Mapping(target = "shardId", source = "location.shardId")
    @Mapping(target = "rqUid", ignore = true)
    ScriptApplication map(ScriptApplicationDto scriptApplicationDto);

}
