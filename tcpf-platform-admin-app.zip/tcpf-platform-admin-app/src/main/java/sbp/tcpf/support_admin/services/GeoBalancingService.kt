package sbp.tcpf.support_admin.services

import com.fasterxml.jackson.core.type.TypeReference
import com.fasterxml.jackson.databind.ObjectMapper
import org.springframework.stereotype.Service
import reactor.core.publisher.Flux
import reactor.core.publisher.Mono
import sbp.tcpf.os.commons.config.ModuleProperties
import sbp.tcpf.support.commons.auth.services.UserService
import sbp.tcpf.support_admin.clients.feign.routing.GeoBalancingManagementApiClient
import sbp.tcpf.support_admin.mappers.GeoBalancingServiceMapper
import sbp.tcpf.support_admin.mappers.TrafficRestrictionMapper
import sbp.tcpf.support_admin.model.TrafficRestrictionDto
import java.time.OffsetDateTime
import java.util.*
import sbp.tcpf.support_admin.model.GeoBalancingService as GeoBalancingServiceDto

@Service
class GeoBalancingService(
    private val geoBalancingManagementClient: GeoBalancingManagementApiClient,
    private val geoBalancingServiceMapper: GeoBalancingServiceMapper,
    private val trafficRestrictionMapper: TrafficRestrictionMapper,
    private val userService: UserService,
    private val moduleProperties: ModuleProperties,
    private val objectMapper: ObjectMapper,
) {
    fun createRestriction(trafficRestriction: TrafficRestrictionDto): Mono<TrafficRestrictionDto> {
        val uuid = UUID.randomUUID().toString()
        val userLogin = userService.getUserLogin()
        val dto = trafficRestrictionMapper.map(trafficRestriction)

        return geoBalancingManagementClient.createTrafficRestriction(
                dto.toMono(),
                moduleProperties.moduleId,
                userLogin,
                uuid,
                OffsetDateTime.now()
        )
            .map { restriction -> trafficRestrictionMapper.map(restriction) }
    }

    /**
     * `routing-api` объявляет data-centers как `Flux<String>`, но WebClient декодирует
     * `Flux<String>` через `StringDecoder`, а не через Jackson: JSON-массив приходит одной
     * строкой `["dc1","dc2"]` и наружу уходит одним SSE-событием вместо трёх.
     * Правка в `routing-api` недоступна, поэтому разбираем массив сами.
     *
     * Элементы, пришедшие уже распакованными, отдаём как есть — метод остаётся корректным
     * независимо от того, какой декодер сработал на стороне клиента.
     */
    fun getDataCenters(): Flux<String> {
        return geoBalancingManagementClient.dataCenters
            .flatMapIterable { chunk -> chunk.asDataCenters() }
    }

    private fun String.asDataCenters(): List<String> {
        val body = this.trim()

        if (!body.startsWith("[")) {
            return listOf(this)
        }

        return runCatching {
            objectMapper.readValue(body, object : TypeReference<List<String>>() {})
        }.getOrElse { listOf(this) }
    }

    fun getServices(): Flux<GeoBalancingServiceDto> {
        return geoBalancingManagementClient.geoBalancingServices
            .map { service -> geoBalancingServiceMapper.convert(service) }
    }

    fun getRestrictionById(id: String): Mono<TrafficRestrictionDto> {
        return geoBalancingManagementClient.getTrafficRestrictionById(id)
            .map { restriction -> trafficRestrictionMapper.map(restriction) }
    }

    fun getRestrictions(): Flux<TrafficRestrictionDto> {
        return geoBalancingManagementClient.trafficRestrictions
            .map { restriction -> trafficRestrictionMapper.map(restriction) }
    }

    fun removeRestriction(id: String): Mono<Void> {
        val uuid = UUID.randomUUID().toString()
        val userLogin = userService.getUserLogin()

        return geoBalancingManagementClient.removeTrafficRestrictionById(
                id,
                moduleProperties.moduleId,
                userLogin,
                uuid,
                OffsetDateTime.now()
        ).then()
    }

    fun updateRestriction(id: String, trafficRestriction: TrafficRestrictionDto): Mono<TrafficRestrictionDto> {
        val dto = trafficRestrictionMapper.map(trafficRestriction)
        val userLogin = userService.getUserLogin()
        val uuid = UUID.randomUUID().toString()

        return geoBalancingManagementClient.updateTrafficRestriction(
                id,
                dto.toMono(),
                moduleProperties.moduleId,
                userLogin,
                uuid,
                OffsetDateTime.now()
        )
            .map { restriction -> trafficRestrictionMapper.map(restriction) }
    }

    private fun <T> T.toMono(): Mono<T> {
        return Mono.justOrEmpty(this)
    }
}
