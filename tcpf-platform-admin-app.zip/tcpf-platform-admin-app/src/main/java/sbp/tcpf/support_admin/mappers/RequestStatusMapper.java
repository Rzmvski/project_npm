package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.support_admin.model.ApplicationStatus;
import sbp.tcpf.support_admin.services.request.RequestStatus;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;
import org.mapstruct.ValueMapping;

import java.util.Optional;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface RequestStatusMapper {

    @ValueMapping(target = MappingConstants.THROW_EXCEPTION, source = MappingConstants.ANY_REMAINING)
    RequestStatus map(ApplicationStatus status);

    @InheritInverseConfiguration
    ApplicationStatus map(RequestStatus statusId);

    default RequestStatus map(Long id) {
        return Optional.ofNullable(RequestStatus.findById(id)).orElseThrow();
    }

    default Long getId(RequestStatus status) {
        return status.getId();
    }
}
