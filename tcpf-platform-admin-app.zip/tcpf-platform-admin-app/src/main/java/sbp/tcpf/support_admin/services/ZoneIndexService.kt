package sbp.tcpf.support_admin.services

import org.springframework.stereotype.Service
import sbp.tcpf.os.commons.utils.ProtoDateUtils
import sbp.tcpf.routing.index.manage.dto.Action
import sbp.tcpf.routing.index.manage.dto.RoutingIndexManageRq
import sbp.tcpf.support_admin.clients.grpc.ZoneIndexGrpcRequestExecutor
import sbp.tcpf.support_admin.mappers.ActionResponseMapper
import sbp.tcpf.support_admin.mappers.ClusterInfoMapper
import sbp.tcpf.support_admin.model.ClusterInfo
import sbp.tcpf.support_admin.model.IndexActionResponse
import sbp.tcpf.support_admin.model.StartActionWithIndexesRq
import java.time.LocalDateTime

@Service
class ZoneIndexService(
    private val zoneIndexGrpcRequestExecutor: ZoneIndexGrpcRequestExecutor,
    private val clusterInfoMapper: ClusterInfoMapper,
    private val actionResponseMapper: ActionResponseMapper
) {

    /**
     * Метод для получения информации о состоянии кластеров
     * @return Список кластеров
     */
    fun getClusterInfo(): List<ClusterInfo> {
        return zoneIndexGrpcRequestExecutor.clusterInfo.clusterDetailsList.map(clusterInfoMapper::convert)
    }

    /**
     * Метод, выполняющий действие над кластером
     * @param request запрос, содержащий ID кластера и действие с кластером
     * @return {@link IndexActionResponse} ответ с результатом изменения состояния кластера
     */
    fun manageIndexes(request: StartActionWithIndexesRq): IndexActionResponse {
        return zoneIndexGrpcRequestExecutor.doActionForCluster(
            buildRoutingIndexManageRq(request.rqUid, request.rqTm, request.actionRequest.clusterId,
                Action.valueOf(request.actionRequest.action.name))
        ).let {
            actionResponseMapper.buildResponse(it)
        }
    }

    private fun buildRoutingIndexManageRq(rqUid: String,
                                          rqTm: LocalDateTime,
                                          clusterId: String,
                                          action: Action): RoutingIndexManageRq {
        return RoutingIndexManageRq.newBuilder()
            .setRqUid(rqUid)
            .setRqTm(ProtoDateUtils.toProtoTimestamp(rqTm))
            .setClusterId(clusterId)
            .setAction(action)
            .build()
    }
}