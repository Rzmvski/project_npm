package sbp.tcpf.support_admin.services.request.resolvers.feature

import org.springframework.stereotype.Component
import sbp.tcpf.support.commons.auth.services.UserService
import sbp.tcpf.support_admin.dto.FeatureDelta
import sbp.tcpf.support_admin.entities.FeatureRequest
import sbp.tcpf.support_admin.facades.Ff4jFacade
import sbp.tcpf.support_admin.mappers.FeatureSnapshotMapper
import sbp.tcpf.support_admin.model.ApplicationStatus
import sbp.tcpf.support_admin.services.request.resolvers.RequestResolver

@Component
class ApproveFeatureResolver(
    private val facade: Ff4jFacade,
    private val userService: UserService,
    private val mapper: FeatureSnapshotMapper,
) : RequestResolver<FeatureRequest> {

    override val status: ApplicationStatus = ApplicationStatus.APPROVED

    override fun resolve(request: FeatureRequest): FeatureRequest {
        var resolvedStatus = ApplicationStatus.APPROVED

        request.target.locations()
            .map { location ->
                runCatching {
                    val config = request.delta.after ?: request.delta.before
                    val snapshot = mapper.map(request, location, config)

                    when (request.delta.type()) {
                        FeatureDelta.ChangeType.CREATE -> facade.create(snapshot)
                        FeatureDelta.ChangeType.UPDATE -> facade.update(snapshot)
                        FeatureDelta.ChangeType.DELETE -> facade.delete(snapshot)
                    }
                }
                    .onFailure {
                        resolvedStatus = ApplicationStatus.ERROR
                        return@map
                    }
            }

        return request.resolve(
                userService.getUserLogin(),
                resolvedStatus.value
        )
    }
}
