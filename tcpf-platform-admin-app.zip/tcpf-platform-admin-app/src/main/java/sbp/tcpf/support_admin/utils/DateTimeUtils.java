package sbp.tcpf.support_admin.utils;

import com.google.protobuf.Timestamp;
import lombok.experimental.UtilityClass;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.Optional;

@UtilityClass
public class DateTimeUtils {

    public static final ZoneId TIMEZONE = ZoneId.of("Europe/Moscow");

    public static LocalDateTime asLocalDateTime(Timestamp source) {
        return Optional.ofNullable(source)
                .map(timestamp -> Instant.ofEpochSecond(timestamp.getSeconds(), timestamp.getNanos())
                      .atZone(TIMEZONE)
                      .toLocalDateTime())
                .orElse(null);
    }

    public static LocalDateTime asLocalDateTime(OffsetDateTime source) {
        return Optional.ofNullable(source)
                .map(offsetDateTime -> offsetDateTime.atZoneSameInstant(TIMEZONE).toLocalDateTime())
                .orElse(null);
    }

    public static OffsetDateTime asOffsetDateTime(LocalDateTime source) {
        return Optional.ofNullable(source)
                       .map(localDateTime -> localDateTime.atZone(TIMEZONE).toOffsetDateTime())
                       .orElse(null);
    }
}
