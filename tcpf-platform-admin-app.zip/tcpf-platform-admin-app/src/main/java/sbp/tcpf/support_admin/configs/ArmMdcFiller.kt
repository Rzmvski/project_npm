package sbp.tcpf.support_admin.configs

import com.fasterxml.jackson.databind.JsonNode
import jakarta.servlet.http.HttpServletRequest
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import sbp.tcpt.log.body.JsonSerializer
import sbp.tcpt.log.mdc.HttpMdcFiller
import sbp.tcpt.log.mdc.MdcKey
import sbp.tcpt.log.stream.BufferedRequestWrapper

@Component
class ArmMdcFiller: HttpMdcFiller() {

    override fun parse(message: Any) {
        super.parse(message)
        if (message is HttpServletRequest) {
            try {
                val wrapper = message as BufferedRequestWrapper
                val requestBody = wrapper.requestBody.trim()
                if (requestBody.isNotEmpty()) {
                    val payload = JsonSerializer.fromJson(requestBody, JsonNode::class.java)
                    JIRA_KEY.put(getPropertyOrNull(payload))
                }
            } catch (ex: Exception) {
                log.info("failed to fill in MDC context", ex)
            }
        }
    }

    override fun clear() {
        super.clear()
        JIRA_KEY.remove()
    }

    private fun getPropertyOrNull(payload: JsonNode): String? {
        return payload[JIRA_ID]?.asText()
    }

    companion object {
        const val JIRA_ID = "jiraId"
        val log: Logger = LoggerFactory.getLogger(ArmMdcFiller::class.java)
        val JIRA_KEY = MdcKey(JIRA_ID)
    }
}
