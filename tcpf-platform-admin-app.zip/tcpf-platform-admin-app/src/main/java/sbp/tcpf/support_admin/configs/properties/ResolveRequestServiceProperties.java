package sbp.tcpf.support_admin.configs.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

import java.time.Duration;
import java.util.List;

import jakarta.validation.constraints.NotNull;

@ConfigurationProperties("tcpf-platform-admin-app.resolve-request-service")
public record ResolveRequestServiceProperties(
        @NotNull Integer generalRequestShard,
        @DefaultValue("true") Boolean dbPersist,
        @DefaultValue("7d") Duration requestTtl,
        @DefaultValue("requestStatus") List<String> encryptedFields,
        @DefaultValue("48h") Duration archiveTtl
) {
}
