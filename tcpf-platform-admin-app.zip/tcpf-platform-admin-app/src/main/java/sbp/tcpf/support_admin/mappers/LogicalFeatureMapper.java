package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.support_admin.dto.LogicalFeatureDto;
import sbp.tcpf.support_admin.model.LogicalFeature;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING,
        uses = {
                FeatureTargetMapper.class,
                FeatureConfigurationMapper.class,
                CustomPropertyMapper.class,
                FeatureActivationMapper.class,
        }
)
public interface LogicalFeatureMapper {

    @InheritInverseConfiguration
    LogicalFeatureDto map(LogicalFeature logicalFeature);

    @Mapping(target = "target", source = "key.target")
    @Mapping(target = "name", source = "key.name")
    @Mapping(target = "config", source = "configuration")
    LogicalFeature map(LogicalFeatureDto logicalFeature);

}
