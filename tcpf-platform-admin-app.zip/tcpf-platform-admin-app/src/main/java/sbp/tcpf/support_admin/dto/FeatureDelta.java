package sbp.tcpf.support_admin.dto;

import sbp.tcpf.support_admin.model.FeatureConfiguration;

import org.jetbrains.annotations.Nullable;

import java.io.Serializable;

public record FeatureDelta(
        @Nullable FeatureConfiguration before,
        @Nullable FeatureConfiguration after
) implements Serializable {
    public enum ChangeType {
        CREATE,
        DELETE,
        UPDATE
    }

    public FeatureDelta.ChangeType type() {
        if (before == null) {
            return FeatureDelta.ChangeType.CREATE;
        }
        if (after == null) {
            return FeatureDelta.ChangeType.DELETE;
        }

        return FeatureDelta.ChangeType.UPDATE;
    }
}
