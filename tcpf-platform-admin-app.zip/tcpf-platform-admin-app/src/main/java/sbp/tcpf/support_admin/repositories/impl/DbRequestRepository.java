package sbp.tcpf.support_admin.repositories.impl;

import sbp.tcpf.support_admin.entities.RequestEntity;
import sbp.tcpf.support_admin.repositories.RequestRepository;
import sbp.tcpf.support_admin.services.request.RequestType;

import org.jetbrains.annotations.NotNull;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface DbRequestRepository
        extends JpaRepository<RequestEntity, Long>, RequestRepository<RequestEntity, String, RequestType> {

    @Query("""
            SELECT r FROM RequestEntity r
            WHERE r.rqUid = :key
                AND r.requestTypeId = :#{#type.id}
                AND r.bucketHash = 1
            """)
    RequestEntity findByKeyAndType(@Param("key") String key, @Param("type") RequestType type);

    @NotNull
    @Query("""
            SELECT r FROM RequestEntity r
            WHERE r.contractId = 1
                AND r.bucketHash = 1
                AND r.requestTypeId = :#{#type.id}
            """)
    List<RequestEntity> loadByType(@Param("type") RequestType type);

    @NotNull
    @Query("""
            SELECT r FROM RequestEntity r
            WHERE r.rqUid in :keys
                AND r.bucketHash = 1
                AND r.requestTypeId = :#{#type.id}
            """)
    List<RequestEntity> loadByKeysAndType(@NotNull @Param("keys") Iterable<? extends String> keys,
                                          @Param("type") RequestType type);

}
