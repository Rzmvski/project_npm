package sbp.tcpf.support_admin.configs.converters

import org.springframework.core.convert.converter.Converter
import org.springframework.stereotype.Component
import java.util.Optional

@Component
class OptionalToStringConverter : Converter<Optional<*>, String?> {

    override fun convert(source: Optional<*>): String? = source.map(Any::toString).orElse(null)
}
