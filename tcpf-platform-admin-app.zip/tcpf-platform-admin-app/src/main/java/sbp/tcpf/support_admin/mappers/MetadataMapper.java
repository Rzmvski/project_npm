package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.routing.api.v1_0.client.model.SchemaMetadata;
import sbp.tcpf.support_admin.model.Metadata;

import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface MetadataMapper {

    Metadata map(SchemaMetadata schemaMetadata);
}
