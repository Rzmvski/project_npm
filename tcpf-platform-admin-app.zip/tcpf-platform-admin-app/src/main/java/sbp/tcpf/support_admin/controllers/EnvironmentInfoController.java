package sbp.tcpf.support_admin.controllers;

import sbp.tcpf.support_admin.api.EnvironmentInfoServiceApi;
import sbp.tcpf.support_admin.configs.properties.EnvironmentProperties;
import sbp.tcpf.support_admin.model.EnvironmentType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RestController;
import lombok.RequiredArgsConstructor;

import static sbp.tcpf.base.metrics.TcpfMetrics.SERVICE;
import static sbp.tcpf.base.metrics.TcpfMetrics.SERVICE_CALL;

import io.micrometer.core.annotation.Timed;

@RestController
@RequiredArgsConstructor
public class EnvironmentInfoController implements EnvironmentInfoServiceApi {

    private static final Logger log = LoggerFactory.getLogger(EnvironmentInfoController.class);

    private final EnvironmentProperties environmentProperties;

    @jakarta.annotation.PostConstruct
    void logEnvironmentTypeAtStartup() {
        log.info("Configured deployment.environment.type resolved to: {}", environmentProperties.type());
    }

    @Override
    @Timed(value = SERVICE_CALL, extraTags = { SERVICE, "EnvironmentInfo" })
    public EnvironmentType getEnvironmentInfo() {
        return environmentProperties.type();
    }
}