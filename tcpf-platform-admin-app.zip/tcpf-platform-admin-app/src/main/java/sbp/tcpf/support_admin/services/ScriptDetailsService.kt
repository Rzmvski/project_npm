package sbp.tcpf.support_admin.services

import org.springframework.stereotype.Service
import sbp.tcpf.support_admin.services.request.store.CompositeScriptDataStore

@Service
class ScriptDetailsService(
    private val store: CompositeScriptDataStore,
) {

    fun getLogs(reasonId: String): String? {
        return store.loadLogs(reasonId)
    }

    fun getScriptBody(reasonId: String): String? {
        return store.loadScriptBody(reasonId)
    }
}
