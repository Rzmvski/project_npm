package sbp.tcpf.support_admin.configs.properties;

import sbp.tcpf.support_admin.model.EnvironmentType;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

@ConfigurationProperties("deployment.environment")
public record EnvironmentProperties(
        @DefaultValue("unknown") EnvironmentType type
) {
}