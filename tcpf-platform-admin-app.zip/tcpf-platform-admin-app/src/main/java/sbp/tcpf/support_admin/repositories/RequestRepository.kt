package sbp.tcpf.support_admin.repositories

import jakarta.validation.Valid

interface RequestRepository<R, K, T> {

    fun findByKeyAndType(key: K, type: T): R?

    fun save(@Valid entity: R): R

    fun loadByType(type: T): List<R> {
        throw NotImplementedError()
    }

    fun loadByKeysAndType(keys: Iterable<K>, type: T): List<R> {
        throw NotImplementedError()
    }
}
