package sbp.tcpf.support_admin.validators

import org.springframework.stereotype.Component
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import sbp.tcpf.support_admin.configs.properties.ScriptServiceProperties
import sbp.tcpf.support_admin.model.CreateScriptApplicationRequest

@Component
class ScriptValidator(
    private val properties: ScriptServiceProperties,
) : Validator {

    override fun supports(clazz: Class<*>): Boolean {
        return CreateScriptApplicationRequest::class.java.isAssignableFrom(clazz)
    }

    override fun validate(target: Any, errors: Errors) {
        val script = (target as CreateScriptApplicationRequest).scriptBody
        if (script.toByteArray().size > properties.maxScriptSize.toBytes()) {
            errors.reject(
                "scriptBody.tooLong",
                "Script is too large. Maximum size allowed is ${properties.maxScriptSize}"
            )
        }
    }
}
