package sbp.tcpf.support_admin.configs.feign;

import java.util.ArrayList;
import java.util.Collection;
import java.util.stream.Collectors;

final class CommaSeparatedList<T> extends ArrayList<T> {

    CommaSeparatedList(Collection<? extends T> items) {
        super(items);
    }

    @Override
    public String toString() {
        return stream()
                .map(String::valueOf)
                .collect(Collectors.joining(","));
    }
}
