package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.replica.monitor.api.mass.model.JobStatus;

import org.mapstruct.Mapper;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING)
public interface RevisionStatusMapper {

    JobStatus convert(String status);
}
