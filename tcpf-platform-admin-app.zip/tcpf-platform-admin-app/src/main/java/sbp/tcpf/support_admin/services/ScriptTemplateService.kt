package sbp.tcpf.support_admin.services

import org.springframework.stereotype.Service
import sbp.tcpf.support_admin.clients.feign.script_engine.ScriptTemplateApi
import sbp.tcpf.support_admin.mappers.TemplateMetadataMapper
import sbp.tcpf.support_admin.model.TemplateMetadata

@Service
class ScriptTemplateService(
    private val templateApi: ScriptTemplateApi,
    private val templateMetadataMapper: TemplateMetadataMapper,
) {

    fun loadMetadatas(): List<TemplateMetadata> {
        return templateApi.loadTemplateMetas()
            .map { metadata -> templateMetadataMapper.map(metadata) }
    }

    fun loadTemplateById(id: Int): String {
        return templateApi.loadScriptTemplate(id)
    }
}