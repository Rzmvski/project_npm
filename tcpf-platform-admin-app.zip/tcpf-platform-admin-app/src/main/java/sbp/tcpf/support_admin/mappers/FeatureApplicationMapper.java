package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.support_admin.dto.FeatureDelta;
import sbp.tcpf.support_admin.entities.FeatureRequest;
import sbp.tcpf.support_admin.model.FeatureApplication;
import sbp.tcpf.support_admin.model.FeatureApplicationAction;
import sbp.tcpf.support_admin.model.FeatureConfiguration;

import org.jetbrains.annotations.Nullable;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;

@Mapper(
        componentModel = MappingConstants.ComponentModel.SPRING,
        uses = {
                FeatureTargetMapper.class,
                CustomPropertyMapper.class,
        }
)
public interface FeatureApplicationMapper {

    @Mapping(target = "action", source = "request.delta")
    @Mapping(target = "uid", source = "request.rqUid")
    @Mapping(target = "target", source = "request.target")
    @Mapping(target = "created", source = "request.createdAt")
    @Mapping(target = "status", source = "request.requestStatus")
    @Mapping(target = "reasonId", source = "request.uid")
    FeatureApplication map(FeatureRequest request,
                           @Nullable FeatureConfiguration before,
                           @Nullable FeatureConfiguration after);

    default FeatureDelta.ChangeType map(FeatureDelta value) {
        return value.type();
    }

    FeatureApplicationAction map(FeatureDelta.ChangeType type);
}
