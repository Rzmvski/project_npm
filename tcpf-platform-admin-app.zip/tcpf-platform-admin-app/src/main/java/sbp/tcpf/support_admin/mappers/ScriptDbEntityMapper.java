package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.support_admin.dto.ScriptApplicationDto;
import sbp.tcpf.support_admin.entities.RequestEntity;
import sbp.tcpf.support_admin.services.request.RequestType;
import sbp.tcpf.support_admin.utils.ConverterUtils;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.ReportingPolicy;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Mapper(
        componentModel = MappingConstants.ComponentModel.SPRING,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        unmappedTargetPolicy = ReportingPolicy.IGNORE,
        uses = {
                RequestStatusMapper.class,
                ConverterUtils.class
        },
        imports = {
                LocalDateTime.class,
                LocalDate.class
        }
)
public interface ScriptDbEntityMapper extends RequestMapper<ScriptApplicationDto, RequestEntity> {

    long ARM_ID = 9L;
    long VSP_ID = 4L;
    long CONTRACT_ID = 1L;
    int BUCKET_HASH = 1;
    long TYPE_ID = RequestType.SCRIPT_REQUEST.getId();

    void update(ScriptApplicationDto source, @MappingTarget ScriptApplicationDto target);

    @Mapping(target = "rqUid", source = "location.scriptId")
    @Mapping(target = "statusId", source = "status")
    @Mapping(target = "executorLogin", source = "executedBy")
    @Mapping(target = "rqData", source = "scriptBody")
//    @Mapping(target = "rsData", source = "logs")
    @Mapping(target = "creatorLogin", source = "createdBy")
    @Mapping(target = "approverLogin", source = "resolvedBy")
//    @Mapping(target = "requestTypeId", source = "type", qualifiedByName = "requestTypeId")
    @Mapping(target = "requestTypeId", expression = "java(TYPE_ID)")
    @Mapping(target = "created", defaultExpression = "java(LocalDateTime.now())")
    @Mapping(target = "operDate", expression = "java(LocalDate.EPOCH)")
    @Mapping(target = "extSystemId", expression = "java(ARM_ID)")
    @Mapping(target = "channelId", expression = "java(VSP_ID)")
    @Mapping(target = "bucketHash", expression = "java(BUCKET_HASH)")
    @Mapping(target = "contractId", expression = "java(CONTRACT_ID)")
    RequestEntity toEntity(ScriptApplicationDto application);

    @InheritInverseConfiguration
//    @Mapping(target = "type", source = "requestTypeId", qualifiedByName = "applicationType")
//    @Mapping(target = "rqUid", ignore = true)
    ScriptApplicationDto toDto(RequestEntity entity);

}
