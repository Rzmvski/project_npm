package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.routing.api.v1_0.client.model.PoolStatus;
import sbp.tcpf.support_admin.model.Pool;
import sbp.tcpf.support_admin.model.PoolState;
import sbp.tcpf.support_admin.utils.DateTimeUtils;

import org.mapstruct.Mapper;
import org.mapstruct.ValueMapping;

import static org.mapstruct.MappingConstants.ANY_REMAINING;
import static org.mapstruct.MappingConstants.ComponentModel;
import static org.mapstruct.MappingConstants.THROW_EXCEPTION;

@Mapper(componentModel = ComponentModel.SPRING, uses = DateTimeUtils.class)
public interface PoolStateMapper {

    Pool map(sbp.tcpf.routing.api.v1_0.client.model.Pool state);

    PoolState map(PoolStatus state);

    @ValueMapping(target = THROW_EXCEPTION, source = ANY_REMAINING)
    PoolStatus map(PoolState state);
}
