package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.routing.api.v1_0.client.model.ShardUpdate;

import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface UpdateShardMapper {

    ShardUpdate convert(sbp.tcpf.support_admin.model.ShardUpdate request);

}
