package sbp.tcpf.support_admin.clients.grpc;

import sbp.tcpf.os.commons.grpc.MessageSender;
import sbp.tcpf.routing.index.info.api.RoutingIndexInfoServiceGrpc;
import sbp.tcpf.routing.index.info.dto.RoutingIndexInfoRs;
import sbp.tcpf.routing.index.manage.api.RoutingIndexManageServiceGrpc;
import sbp.tcpf.routing.index.manage.dto.RoutingIndexManageRq;
import sbp.tcpf.routing.index.manage.dto.RoutingIndexManageRs;
import sbp.tcpf.support_admin.configs.properties.ZoneIndexAppProperties;

import com.google.protobuf.Empty;
import org.springframework.stereotype.Component;
import lombok.RequiredArgsConstructor;

import java.util.UUID;

@Component
@RequiredArgsConstructor
public class ZoneIndexGrpcRequestExecutor {

    private final MessageSender<RoutingIndexInfoServiceGrpc.RoutingIndexInfoServiceBlockingStub, RoutingIndexInfoRs> getRoutingIndexInfoMsgSender;
    private final MessageSender<RoutingIndexManageServiceGrpc.RoutingIndexManageServiceBlockingStub, RoutingIndexManageRs> getRoutingIndexManageMsgSender;
    private final ZoneIndexAppProperties zoneIndexProperties;

    /**
     * Синхронный Вызов рпс процедуры info
     *
     * @return {@link RoutingIndexInfoRs} ответ из модуля tcpf-zone-index-app
     */
    public RoutingIndexInfoRs getClusterInfo() throws Exception {
        final var uri = zoneIndexProperties.grpcUri();
        final String rqUid = generateRqUid();
        return getRoutingIndexInfoMsgSender.sendMessage(
                stub -> stub.info(Empty.getDefaultInstance()),
                MessageSender.Context.of(
                        uri.getHost(),
                        uri.getPort() == -1 ? null : Integer.toString(uri.getPort()),
                        rqUid
                )
        );
    }

    /**
     * Синхронный Вызов рпс процедуры process
     *
     * @return {@link RoutingIndexManageRs} ответ из модуля tcpf-zone-index-app
     */
    public RoutingIndexManageRs doActionForCluster(RoutingIndexManageRq rq) throws Exception {
        final var uri = zoneIndexProperties.grpcUri();
        final String rqUid = generateRqUid();
        return getRoutingIndexManageMsgSender.sendMessage(
                stub -> stub.process(rq),
                MessageSender.Context.of(
                        uri.getHost(),
                        uri.getPort() == -1 ? null : Integer.toString(uri.getPort()),
                        rqUid
                )
        );
    }

    private static String generateRqUid() {
        return UUID.randomUUID().toString().replace("-", "");
    }
}
