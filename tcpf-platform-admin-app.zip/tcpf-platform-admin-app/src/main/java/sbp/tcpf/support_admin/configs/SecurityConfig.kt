package sbp.tcpf.support_admin.configs

import org.springframework.boot.actuate.autoconfigure.security.servlet.EndpointRequest
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.security.config.annotation.web.builders.HttpSecurity
import org.springframework.security.config.http.SessionCreationPolicy
import org.springframework.security.web.SecurityFilterChain
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter
import org.springframework.security.web.authentication.logout.CookieClearingLogoutHandler
import org.springframework.security.web.authentication.logout.HttpStatusReturningLogoutSuccessHandler
import sbp.tcpf.security.authentication.filters.BearerAuthenticationFilter
import sbp.tcpf.security.authentication.filters.MockAuthenticationFilter
import sbp.tcpf.security.properties.AuthProperties

@Configuration
class SecurityConfig {

    @Bean
    fun securityFilterChain(
        httpSecurity: HttpSecurity,
        authProperties: AuthProperties,
        bearerAuthenticationFilter: BearerAuthenticationFilter?,
        mockAuthenticationFilter: MockAuthenticationFilter?,
    ): SecurityFilterChain {
        val whiteList = authProperties.authenticationWhiteList.whiteList

        val authFilter = bearerAuthenticationFilter
            ?: mockAuthenticationFilter
            ?: throw IllegalStateException("No auth filter provided!")

        return httpSecurity
            .csrf { it.disable() }
            .authorizeHttpRequests { auth ->
                auth
                    .requestMatchers(EndpointRequest.toAnyEndpoint()).permitAll()
                    .requestMatchers(*whiteList.toTypedArray()).permitAll()
                    .anyRequest().authenticated()
            }
            .addFilterAfter(authFilter, UsernamePasswordAuthenticationFilter::class.java)
            .sessionManagement { configurer ->
                configurer
                    .sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)
            }
            .logout { configurer ->
                configurer
                    .logoutUrl("/invoke/support-admin/user-service/logout")
                    .addLogoutHandler(CookieClearingLogoutHandler(
                            "JSESSIONID", "PLATFORM_SESSION"
                    ))
                    .logoutSuccessHandler(HttpStatusReturningLogoutSuccessHandler())
            }
            .build()
    }
}
