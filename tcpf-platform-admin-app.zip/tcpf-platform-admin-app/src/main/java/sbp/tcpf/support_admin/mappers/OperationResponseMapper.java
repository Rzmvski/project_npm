package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.forced.replication.model.OperationResponse;
import sbp.tcpf.support_admin.model.OperationResponseDto;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface OperationResponseMapper {

    OperationResponseDto map(OperationResponse operationResponse);

    @InheritInverseConfiguration
    OperationResponse map(OperationResponseDto operationResponse);

}
