package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.replica.monitor.api.mass.model.Revision;
import sbp.tcpf.support_admin.model.RevisionInfo;
import sbp.tcpf.support_admin.utils.DateTimeUtils;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING, uses = DateTimeUtils.class)
public interface RevisionMapper {

    @Mapping(target = "created", source = "createdTime")
    @Mapping(target = "updated", source = "statusTime")
    RevisionInfo convert(Revision source);
}
