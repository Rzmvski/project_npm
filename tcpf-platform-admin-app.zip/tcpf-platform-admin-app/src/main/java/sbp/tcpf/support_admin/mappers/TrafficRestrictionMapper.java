package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.routing.api.v1_0.client.model.TrafficRestriction;
import sbp.tcpf.support_admin.model.TrafficRestrictionDto;
import sbp.tcpf.support_admin.utils.ConverterUtils;
import sbp.tcpf.support_admin.utils.DateTimeUtils;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING,
        uses = {
                DateTimeUtils.class,
                ConverterUtils.class
        })
public interface TrafficRestrictionMapper {

    @Mapping(target = "comment", qualifiedByName = "emptyToNull")
    @Mapping(target = "updateComment", qualifiedByName = "emptyToNull")
    TrafficRestrictionDto map(TrafficRestriction restriction);

    @InheritInverseConfiguration
    TrafficRestriction map(TrafficRestrictionDto dto);
}
