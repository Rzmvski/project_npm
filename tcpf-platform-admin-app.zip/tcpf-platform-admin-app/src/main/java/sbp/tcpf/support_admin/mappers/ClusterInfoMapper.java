package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.routing.index.info.dto.Action;
import sbp.tcpf.routing.index.info.dto.ClusterDetails;
import sbp.tcpf.routing.index.info.dto.State;
import sbp.tcpf.support_admin.model.ClusterInfo;
import sbp.tcpf.support_admin.model.IndexActions;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.List;

@Mapper(componentModel = "spring")
public interface ClusterInfoMapper {

    @Mapping(target = "updateRequired", source = "state", qualifiedByName = "updateFlag")
    @Mapping(target = "indexesCount", source = "entriesCount")
    @Mapping(target = "availableActions", source = "availableActionsList", qualifiedByName = "action")
    ClusterInfo convert(ClusterDetails clusterDetails);

    @Named("action")
    default IndexActions getAction(List<Action> actionList) {
        return !actionList.isEmpty() ? IndexActions.fromValue(actionList.get(0).name()) : IndexActions.UNRECOGNIZED;
    }

    @Named("updateFlag")
    default boolean getFlag(State state) {
        return switch (state) {
            case CREATING, ON_LOADING -> true;
            default -> false;
        };
    }
}
