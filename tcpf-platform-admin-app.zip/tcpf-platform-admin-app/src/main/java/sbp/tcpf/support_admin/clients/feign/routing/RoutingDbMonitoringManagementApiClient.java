package sbp.tcpf.support_admin.clients.feign.routing;

import sbp.tcpf.routing.api.v1_0.client.api.MonitoringEmitterManagementApi;
import sbp.tcpf.support_admin.clients.feign.routing.config.RoutingFeignConfig;

import reactivefeign.spring.config.ReactiveFeignClient;

@ReactiveFeignClient(
        name = "RoutingDbMonitoringManagement",
        url = "${tcpf-platform-admin-app.tcpf-routing-app-os.uri}",
        configuration = RoutingFeignConfig.class
)
public interface RoutingDbMonitoringManagementApiClient extends MonitoringEmitterManagementApi {
}
