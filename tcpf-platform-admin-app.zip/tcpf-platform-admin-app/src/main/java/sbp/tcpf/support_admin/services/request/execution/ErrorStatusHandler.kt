package sbp.tcpf.support_admin.services.request.execution

import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import sbp.tcpf.support_admin.model.ApplicationStatus
import sbp.tcpf.support_admin.services.request.store.CompositeScriptDataStore

@Component
class ErrorStatusHandler(
    private val dataStore: CompositeScriptDataStore,
) {

    fun checkAndMarkAsError(executionId: String, errorMessage: String? = ERROR_MESSAGE) {
        val application = dataStore.findByKey(executionId) ?: return
        if (application.status != ApplicationStatus.WORKS) return

        val (_, shardId) = application.location

        dataStore.changeStatus(application.location, ApplicationStatus.ERROR)
        if (errorMessage != null && shardId != null) {
            dataStore.saveLogs(application.location, errorMessage)
        }
        log.warn("Execution context for $executionId was marked as ERROR")
    }

    companion object {
        private val log: Logger = LoggerFactory.getLogger(ErrorStatusHandler::class.java)
        private const val ERROR_MESSAGE =
            "Execution context was unexpectedly lost. The process might have been terminated prematurely or encountered a system failure.\n"
    }
}
