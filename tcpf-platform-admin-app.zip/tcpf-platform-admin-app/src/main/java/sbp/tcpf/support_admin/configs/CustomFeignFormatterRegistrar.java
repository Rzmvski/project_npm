package sbp.tcpf.support_admin.configs;

import org.springframework.cloud.openfeign.FeignFormatterRegistrar;
import org.springframework.core.convert.converter.Converter;
import org.springframework.format.FormatterRegistry;
import org.springframework.stereotype.Component;
import lombok.RequiredArgsConstructor;

import java.util.Optional;

@Component
@RequiredArgsConstructor
public class CustomFeignFormatterRegistrar implements FeignFormatterRegistrar {

    private final Converter<Optional<?>, String> optionalStringConverter;

    @Override
    public void registerFormatters(FormatterRegistry registry) {
        registry.addConverter(optionalStringConverter);
    }
}
