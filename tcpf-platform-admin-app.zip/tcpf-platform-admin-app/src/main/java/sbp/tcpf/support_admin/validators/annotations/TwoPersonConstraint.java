package sbp.tcpf.support_admin.validators.annotations;

import sbp.tcpf.support_admin.validators.TwoPersonValidator;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static sbp.tcpf.support_admin.validators.TwoPersonValidator.SAME_VALUES_MESSAGE;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

@Target({ElementType.TYPE, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = TwoPersonValidator.class)
public @interface TwoPersonConstraint {

    String creatorFieldName() default "createdBy";
    String resolverFieldName() default "resolvedBy";
    String message() default SAME_VALUES_MESSAGE;
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
