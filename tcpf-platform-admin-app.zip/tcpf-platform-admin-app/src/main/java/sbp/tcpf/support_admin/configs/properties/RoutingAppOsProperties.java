package sbp.tcpf.support_admin.configs.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.net.URI;
import java.time.Duration;

import jakarta.validation.constraints.NotNull;

@ConfigurationProperties("tcpf-platform-admin-app.tcpf-routing-app-os")
public record RoutingAppOsProperties(
        @NotNull URI uri,
        @NotNull Duration monitoringThreshold,
        @NotNull String defaultRegion
) {
}
