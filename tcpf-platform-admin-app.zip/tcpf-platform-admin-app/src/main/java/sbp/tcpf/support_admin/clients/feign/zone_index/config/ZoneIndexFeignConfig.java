package sbp.tcpf.support_admin.clients.feign.zone_index.config;

import sbp.tcpf.routing.index.api.v1_0.client.model.Error;
import sbp.tcpf.support_admin.configs.decoders.ExternalServiceErrorDecoder;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.context.annotation.Bean;

import feign.codec.ErrorDecoder;

public class ZoneIndexFeignConfig {

    @Bean
    public ErrorDecoder zoneIndexErrorDecoder(ObjectMapper objectMapper) {
        return ExternalServiceErrorDecoder.of(objectMapper, Error.class, Error::getMessage);
    }
}
