package sbp.tcpf.support_admin.wrappers

import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import org.springframework.transaction.TransactionDefinition
import sbp.tcpf.routing.api.v1_0.client.model.MonitoringState
import sbp.tcpf.routing.client.core.uow.UnitOfWorkOperations
import sbp.tcpf.routing.client.jdbc.transaction.TxDefinition
import sbp.tcpf.support_admin.clients.feign.routing.RoutingMonitoringManagementApiClient
import java.util.concurrent.Callable

@Component
class SafeUnitOfWorkOperations(
    private val monitoringManagementApiClient: RoutingMonitoringManagementApiClient,
    private val delegate: UnitOfWorkOperations,
) : UnitOfWorkOperations by delegate {

    fun <T> tryCallOnNode(
        operation: String,
        nodeName: String,
        txDef: TransactionDefinition = TxDefinition.READ_ONLY.definition,
        work: Callable<T>,
    ): T? =
        runCatching {
            val monitoring = monitoringManagementApiClient.getDbMonitorings()
                .filter { it.id == nodeName }
                .singleOrEmpty()
                .block()
            if (monitoring?.state == MonitoringState.DOWN) {
                throw IllegalStateException("node $nodeName is down")
            }
            delegate.callOnNodeDefault(operation, nodeName, txDef, work)
        }.onFailure {
            log.warn("can not execute $operation on node $nodeName, cause ${it.message}")
        }.getOrNull()

    companion object {
        val log: Logger = LoggerFactory.getLogger(SafeUnitOfWorkOperations::class.java)
    }
}
