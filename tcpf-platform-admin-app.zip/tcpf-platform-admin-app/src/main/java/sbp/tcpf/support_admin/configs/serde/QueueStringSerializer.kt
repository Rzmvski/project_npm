package sbp.tcpf.support_admin.configs.serde

import org.apache.curator.framework.recipes.queue.QueueSerializer
import org.springframework.stereotype.Component

@Component
class QueueStringSerializer : QueueSerializer<String> {

    override fun serialize(item: String): ByteArray {
        return item.toByteArray()
    }

    override fun deserialize(bytes: ByteArray): String {
        return String(bytes)
    }
}
