package sbp.tcpf.support_admin.configs;

import sbp.tcpf.support.commons.audit.concurrency.UserInfoTaskDecorator;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

@Configuration
public class ConcurrencyConfig {
    @Bean
    public Executor armExecutor(UserInfoTaskDecorator userInfoTaskDecorator) {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setTaskDecorator(userInfoTaskDecorator);
        executor.initialize();
        return executor;
    }
}
