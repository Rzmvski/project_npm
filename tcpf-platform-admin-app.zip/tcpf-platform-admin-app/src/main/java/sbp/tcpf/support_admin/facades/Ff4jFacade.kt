package sbp.tcpf.support_admin.facades

import org.springframework.stereotype.Component
import sbp.tcpf.ff4j.admin.domain.TcpfFeature
import sbp.tcpf.ff4j.admin.facade.FF4jAdmin
import sbp.tcpf.support_admin.dto.FeatureLocation
import sbp.tcpf.support_admin.dto.FeatureSnapshot
import sbp.tcpf.support_admin.dto.LogicalFeatureDto
import sbp.tcpf.support_admin.mappers.FeatureMapper
import sbp.tcpf.support_admin.mappers.FeatureSnapshotMapper
import sbp.tcpf.support_admin.services.LogicalFeatureAggregator

@Component
class Ff4jFacade(
    private val ff4jAdmin: FF4jAdmin,
    private val featureMapper: FeatureMapper,
    private val snapshotMapper: FeatureSnapshotMapper,
    private val featureAggregator: LogicalFeatureAggregator,
) {

    fun create(snapshot: FeatureSnapshot) {
        val feature = featureMapper.map(snapshot)
        applyPath(
                snapshot.location,
                feature,
                ff4jAdmin::createOnModule,
                ff4jAdmin::createOnModule,
                ff4jAdmin::create,
                ff4jAdmin::create,
        )
    }

    fun update(snapshot: FeatureSnapshot) {
        val feature = featureMapper.map(snapshot)
        applyPath(
                snapshot.location,
                feature,
                ff4jAdmin::updateOnModule,
                ff4jAdmin::updateOnModule,
                ff4jAdmin::update,
                ff4jAdmin::update
        )

    }

    fun delete(snapshot: FeatureSnapshot) {
        applyPath(
                snapshot.location,
                snapshot.name,
                ff4jAdmin::deleteOnModule,
                ff4jAdmin::deleteOnModule,
                ff4jAdmin::delete,
                ff4jAdmin::delete
        )
    }

    fun getSnapshots(): List<FeatureSnapshot> {
        return ff4jAdmin.allFeaturesAsTcpfFeatures
            .map { tcpfFeature -> snapshotMapper.map(tcpfFeature) }
    }

    fun getLogicalFeatures(): List<LogicalFeatureDto> {
        val snapshots = getSnapshots()

        return featureAggregator.aggregate(snapshots)
    }

    fun getPhysicalFeatures(): List<TcpfFeature> {
        return ff4jAdmin.allFeaturesAsTcpfFeatures
    }

    private inline fun <T, R> applyPath(
        location: FeatureLocation,
        value: T,
        moduleTriFunction: (T, String, String) -> R,
        moduleBiFunction: (T, String) -> R,
        nodeBiFunction: (T, String) -> R,
        uniFunction: (T) -> R,
    ) {
        when {
            location.hasNode() && location.hasModule() -> moduleTriFunction(value, location.module, location.node)
            location.hasModule() -> moduleBiFunction(value, location.module)
            location.hasNode() -> nodeBiFunction(value, location.node)
            else -> uniFunction(value)
        }
    }
}
