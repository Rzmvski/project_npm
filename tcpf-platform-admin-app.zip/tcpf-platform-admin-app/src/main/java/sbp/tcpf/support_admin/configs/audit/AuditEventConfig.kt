package sbp.tcpf.support_admin.configs.audit

import com.fasterxml.jackson.databind.ObjectMapper
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import sbp.tcpf.audit.api.EventParamMapper
import sbp.tcpf.support.commons.auth.services.UserService
import sbp.tcpf.support_admin.enums.OuterErrorCodes
import sbp.tcpf.support_admin.model.*
import java.time.LocalDate

@Configuration
class AuditEventConfig {

    @Bean
    fun eventParamMapper(
        userService: UserService,
        objectMapper: ObjectMapper,
    ): EventParamMapper {
        return EventParamMapper()
// --------------- common section ---------------
            .mapping("date") { LocalDate.now().toString() }
            .mapping("additionalParams", Any::class.java) { it.safeToString() }
            .mapping("event.success") { "true" }
            .mapping("event.success", Throwable::class.java) { "false" }
            .mapping("errorCode") { OuterErrorCodes.SUCCESS.code.toString() }
            .mapping("errorCode", Throwable::class.java) { OuterErrorCodes.TECHNICAL_ERROR.code.toString() }
            .mapping("errorMessage", Throwable::class.java) { it.message ?: it.javaClass.simpleName }

// --------------- user service section ---------------
            .mapping("roles") { userService.getRoles().safeToString() }
            .mapping("userLogin") { userService.getUserLogin().safeToString() }

// --------------- cluster management section ---------------
            .mapping("semaphoreId", String::class.java) { it.safeToString() }
            .mapping("bucketBoundary", ShardUpdate::class.java) { it.bucketBoundary.safeToString() }
            .mapping("process", ArrayList::class.java) { it.safeToString() }
            .mapping("process", ChangeClusterStateRequest::class.java) { "change cluster state" }
            .mapping("shardId", Integer::class.java) { it.safeToString() }
            .mapping("shardId", ArrayList::class.java) { it.safeToString() }

// --------------- shard service section ---------------
            .mapping("NodeKey", ShardInfo::class.java) { it.nodeKey.safeToString() }
            .mapping("shardId", ShardInfo::class.java) { it.shardId.safeToString() }

// --------------- request service section ---------------
            .mapping("reasonId", FeatureApplication::class.java) { it.reasonId.safeToString() }
            .mapping("reasonId", ScriptApplication::class.java) { it.reasonId.safeToString() }
            .mapping("status", FeatureApplication::class.java) { it.status.safeToString() }
            .mapping("status", ScriptApplication::class.java) { it.status.safeToString() }
            .mapping("createdByLogin", FeatureApplication::class.java) { it.createdBy.safeToString() }
            .mapping("createdByLogin", ScriptApplication::class.java) { it.createdBy.safeToString() }
            .mapping("resolvedByLogin", FeatureApplication::class.java) { it.resolvedBy.safeToString() }

// --------------- feature request service part ---------------
            .mapping("isHotConfig", FeatureApplication::class.java) { it.isHotConfig().safeToString() }
            .mapping("oldValue", FeatureApplication::class.java) { it.before.serialize(objectMapper) }
            .mapping("newValue", FeatureApplication::class.java) { it.after.serialize(objectMapper) }
            .mapping("action", FeatureApplication::class.java) { it.action.safeToString() }

// --------------- script request service part ---------------
            .mapping("runByLogin", ScriptApplication::class.java) { it.resolvedBy.safeToString() }
            .mapping("rqUid", ScriptApplication::class.java) { it.rqUid.safeToString() }
            .mapping("script", CreateScriptApplicationRequest::class.java) { it.scriptBody.safeToString() }
    }

    private fun FeatureApplication.isHotConfig() {
        listOfNotNull(this.before, this.after)
            .flatMap { feature -> feature.customProperties }
            .any { property -> property.name == "type" && property.value == "hotConfig" }
    }

    private fun Any?.safeToString(): String = this?.toString() ?: DEFAULT_VALUE

    private fun Any?.serialize(mapper: ObjectMapper): String {
        return this?.let { mapper.writeValueAsString(this) } ?: DEFAULT_VALUE
    }

    companion object {
        const val DEFAULT_VALUE = "none"
    }
}
