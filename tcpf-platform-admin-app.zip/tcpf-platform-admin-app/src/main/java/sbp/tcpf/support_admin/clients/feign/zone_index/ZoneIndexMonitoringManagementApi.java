package sbp.tcpf.support_admin.clients.feign.zone_index;

import sbp.tcpf.routing.index.api.v1_0.client.api.MonitoringManagementApiClient;
import sbp.tcpf.support_admin.clients.feign.zone_index.config.ZoneIndexFeignConfig;

import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(
        name = "ZoneIndexMonitoringManagementApi",
        url = "${tcpf-platform-admin-app.tcpf-zone-index-app.rest-uri}",
        configuration = ZoneIndexFeignConfig.class
)
public interface ZoneIndexMonitoringManagementApi extends MonitoringManagementApiClient {
}
