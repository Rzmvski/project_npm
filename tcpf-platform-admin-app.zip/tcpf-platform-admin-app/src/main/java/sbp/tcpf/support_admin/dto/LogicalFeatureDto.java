package sbp.tcpf.support_admin.dto;

import sbp.tcpf.support_admin.model.FeatureConfiguration;

import java.time.LocalDateTime;

public record LogicalFeatureDto(
        FeatureIdentity key,
        FeatureConfiguration configuration,
        LocalDateTime created,
        LocalDateTime updated,
        Boolean hot
) {
}
