package sbp.tcpf.support_admin.dto;

public record FeatureIdentity(
        String name,
        FeatureTargetDto target
) {
}
