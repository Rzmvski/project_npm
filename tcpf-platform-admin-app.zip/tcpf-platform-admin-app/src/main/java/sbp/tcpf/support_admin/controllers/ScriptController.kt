package sbp.tcpf.support_admin.controllers

import io.micrometer.core.annotation.Timed
import org.springframework.security.access.annotation.Secured
import org.springframework.web.bind.annotation.RestController
import sbp.tcpf.audit.api.AuditEvent
import sbp.tcpf.base.metrics.TcpfMetrics
import sbp.tcpf.support_admin.api.ScriptServiceApi
import sbp.tcpf.support_admin.model.*
import sbp.tcpf.support_admin.services.ScriptDetailsService
import sbp.tcpf.support_admin.services.ScriptTemplateService
import sbp.tcpf.support_admin.services.ShellBeansService
import sbp.tcpf.support_admin.services.request.RequestService

@RestController
class ScriptController(
    private val requestService: RequestService<String, CreateScriptApplicationRequest, ScriptApplication>,
    private val scriptDetailsService: ScriptDetailsService,
    private val templateService: ScriptTemplateService,
    private val shellBeansService: ShellBeansService,
) : ScriptServiceApi {

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "ScriptService"])
    override fun getTemplatesMetadata(): List<TemplateMetadata> {
        return templateService.loadMetadatas()
    }

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "ScriptService"])
    override fun loadBeans(): List<BeanInfo> {
        return shellBeansService.loadBeans()
    }

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "ScriptService"])
    override fun getTemplateByHash(hash: Int): String {
        return templateService.loadTemplateById(hash)
    }

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "ScriptService"])
    @Secured("scriptService_getResult")
    override fun loadScriptApplications(): List<ScriptApplication> {
        return requestService.load()
    }

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "ScriptService"])
    override fun getScript(reasonId: String): String? {
        return scriptDetailsService.getScriptBody(reasonId)
    }

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "ScriptService"])
    override fun getScriptLogs(reasonId: String): String? {
        return scriptDetailsService.getLogs(reasonId)
    }

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "ScriptService"])
    @Secured("scriptService_resolveScriptRequest")
    override fun resolveScriptApplication(
        reasonId: String,
        resolveScriptApplicationRequest: ResolveScriptApplicationRequest,
    ): ScriptApplication {
        return requestService.resolve(reasonId, resolveScriptApplicationRequest.status)
    }

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "ScriptService"])
    @Secured("scriptService_createScriptRequest")
    override fun saveScriptApplication(createScriptApplicationRequest: CreateScriptApplicationRequest) {
        requestService.save(createScriptApplicationRequest)
    }

    @AuditEvent(onSuccess = "SCRIPT_REQUEST_RESULT", onError = "SCRIPT_REQUEST_RESULT_ERROR")
    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "ScriptService"])
    @Secured("scriptService_getResult")
    override fun scriptResult(reasonId: String): ScriptApplication {
        return requestService.find(reasonId)
    }
}
