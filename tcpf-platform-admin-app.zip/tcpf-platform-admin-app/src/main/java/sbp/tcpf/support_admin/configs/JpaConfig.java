package sbp.tcpf.support_admin.configs;

import sbp.tcpf.routing.client.hibernate.autoconfigure.LocalSessionFactoryBeanCustomizer;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories("sbp.tcpf.support_admin.repositories")
@Configuration
public class JpaConfig {

    @Bean
    public LocalSessionFactoryBeanCustomizer localSessionFactoryCommonsBeanCustomizer() {
        return localSessionFactoryBean -> localSessionFactoryBean.setPackagesToScan(
                "sbp.tcpf.support_admin.entities"
        );
    }

}
