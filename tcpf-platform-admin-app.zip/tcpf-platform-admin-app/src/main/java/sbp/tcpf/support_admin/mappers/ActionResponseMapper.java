package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.routing.index.manage.dto.RoutingIndexManageRs;
import sbp.tcpf.support_admin.model.IndexActionResponse;
import sbp.tcpf.support_admin.utils.DateTimeUtils;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring", uses = DateTimeUtils.class)
public interface ActionResponseMapper {
    @Mapping(target = "description", source = "status.description")
    @Mapping(target = "code", source = "status.code")
    IndexActionResponse buildResponse(RoutingIndexManageRs response);
}
