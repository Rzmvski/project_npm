package sbp.tcpf.support_admin.services.request.execution

import org.springframework.cache.annotation.Cacheable
import org.springframework.stereotype.Component
import sbp.tcpf.support_admin.entities.ScriptRequest
import sbp.tcpf.support_admin.services.request.cache.RequestCuratorCacheManager

@Component
class ExecutionLocationResolver(
    private val requestCache: RequestCuratorCacheManager,
) {

    @Cacheable("executionLocation")
    fun resolve(executionId: String): Int? {
        return requestCache
            .readAll(ScriptRequest::class.java)
            .find { it.uid == executionId }
            ?.dbRef
            ?.shardId
    }
}
