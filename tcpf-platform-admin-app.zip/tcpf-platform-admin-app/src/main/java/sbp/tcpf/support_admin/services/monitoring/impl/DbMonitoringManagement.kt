package sbp.tcpf.support_admin.services.monitoring.impl

import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.stereotype.Service
import reactor.core.publisher.Flux
import sbp.tcpf.support_admin.clients.feign.routing.RoutingDbMonitoringManagementApiClient
import sbp.tcpf.support_admin.configs.properties.RoutingAppOsProperties
import sbp.tcpf.support_admin.mappers.MonitoringMapper
import sbp.tcpf.support_admin.model.Monitoring
import sbp.tcpf.support_admin.services.monitoring.MonitoringManagement

@Service
@Qualifier("DB")
class DbMonitoringManagement(
    private val monitoringManagementApiClient: RoutingDbMonitoringManagementApiClient,
    private val monitoringMapper: MonitoringMapper,
    private val properties: RoutingAppOsProperties,
) : MonitoringManagement {

    companion object {
        private val log: Logger = LoggerFactory.getLogger(DbMonitoringManagement::class.java)
    }

    override fun getMonitoringInfo(): Flux<Monitoring> {
        return Flux
            .defer { monitoringManagementApiClient.dbMonitoringsSSE }
            .map { monitoringMapper.convert(it) }
            .doOnSubscribe { log.debug("DB monitoring downstream subscribed") }
            .doOnCancel { log.debug("DB monitoring downstream cancelled") }
            .doFinally { log.debug("DB monitoring downstream finished: {}", it) }
    }
}
