package sbp.tcpf.support_admin.services.request.store.modifiers

import org.springframework.stereotype.Component
import sbp.tcpf.support_admin.configs.properties.ResolveRequestServiceProperties
import sbp.tcpf.support_admin.dto.DbRef
import sbp.tcpf.support_admin.entities.ScriptRequest

@Component
class ShardIdModifier(
    private val properties: ResolveRequestServiceProperties,
) : Modifier<ScriptRequest> {

    override fun modify(
        data: ScriptRequest,
    ): ScriptRequest {
        if (properties.dbPersist) {
            data.dbRef = DbRef(properties.generalRequestShard)
        }

        return data
    }
}
