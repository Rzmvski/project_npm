package sbp.tcpf.support_admin.utils

import org.springframework.core.ParameterizedTypeReference
import org.springframework.core.ResolvableType
import org.springframework.http.ResponseEntity
import org.springframework.http.codec.ServerSentEvent
import org.springframework.web.reactive.function.client.WebClient
import reactor.core.publisher.Flux
import sbp.tcpf.support_admin.exceptions.ExternalServiceException

fun <T> ResponseEntity<T>.getResponseOrThrowWithMessage(errorMessage: String): T {
    val response = this.body
    if (this.statusCode.isError || response == null) throw ExternalServiceException(errorMessage)
    return response
}

inline fun <reified T> WebClient.ResponseSpec.bodyToSseDataFlux(): Flux<T> {
    val typeRef = ParameterizedTypeReference.forType<ServerSentEvent<T>>(
            ResolvableType.forClassWithGenerics(ServerSentEvent::class.java, T::class.java).type
    )
    return this
        .bodyToFlux(typeRef)
        .mapNotNull { event -> event.data() }
}
