package sbp.tcpf.support_admin.services.request

import org.apache.curator.framework.CuratorFramework
import org.apache.curator.framework.recipes.queue.QueueConsumer
import org.apache.curator.framework.state.ConnectionState
import org.apache.curator.utils.ZKPaths
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import sbp.tcpf.support_admin.exceptions.ResourceNotFoundException
import sbp.tcpf.support_admin.model.ApplicationStatus
import sbp.tcpf.support_admin.model.CreateScriptApplicationRequest
import sbp.tcpf.support_admin.model.ScriptApplication

@Service
class ArchiveService(
    private val requestService: RequestService<String, CreateScriptApplicationRequest, ScriptApplication>,
) : QueueConsumer<String> {

    override fun consumeMessage(message: String) {
        val key = ZKPaths.getNodeFromPath(message)
        try {
            requestService.resolve(key, ApplicationStatus.ARCHIVED)
            log.info("archived application with key $key")
        } catch (e: ResourceNotFoundException) {
            log.warn("can not archive application with key $key:", e)
        }
    }

    override fun stateChanged(client: CuratorFramework, newState: ConnectionState) {
        log.debug("curator change state to {}", newState)
    }

    companion object {
        private val log: Logger = LoggerFactory.getLogger(ArchiveService::class.java)
    }
}
