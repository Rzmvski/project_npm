package sbp.tcpf.support_admin.services.request.resolvers

import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import sbp.tcpf.support.commons.auth.services.UserService
import sbp.tcpf.support_admin.dto.ScriptApplicationDto
import sbp.tcpf.support_admin.entities.FeatureRequest
import sbp.tcpf.support_admin.model.ApplicationStatus
import sbp.tcpf.support_admin.services.request.resolvers.script.CommonStatusResolver
import sbp.tcpf.support_admin.services.request.store.CompositeScriptDataStore

@Configuration
class ResolverConfig {

    @Bean
    fun approveScriptResolver(userService: UserService, store: CompositeScriptDataStore): RequestResolver<ScriptApplicationDto> {
        return CommonStatusResolver(ApplicationStatus.APPROVED, userService, store)
    }

    @Bean
    fun declineScriptResolver(userService: UserService, store: CompositeScriptDataStore): RequestResolver<ScriptApplicationDto> {
        return CommonStatusResolver(ApplicationStatus.DECLINE, userService, store)
    }

    @Bean
    fun featureResolverRegistry(resolvers: List<RequestResolver<FeatureRequest>>): ResolverRegistry<FeatureRequest> {
        return ResolverRegistry(resolvers)
    }

    @Bean
    fun scriptResolverRegistry(resolvers: List<RequestResolver<ScriptApplicationDto>>): ResolverRegistry<ScriptApplicationDto> {
        return ResolverRegistry(resolvers)
    }
}
