package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.support_admin.model.CustomProperty;

import org.ff4j.property.Property;
import org.ff4j.property.util.PropertyFactory;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ObjectFactory;
import org.mapstruct.ReportingPolicy;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING,
        unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public interface CustomPropertyMapper {

    @Mapping(target = "value", source = "property", qualifiedByName = "getValue")
    CustomProperty convert(Property<?> property);

    @ObjectFactory
    default Property<?> convert(CustomProperty property) {
        return PropertyFactory.createProperty(property.getName(), property.getType(), property.getValue());
    }

    @Named("getValue")
    default String getValue(Property<?> property) {
        return property.asString();
    }

    default List<CustomProperty> convert(Map<String, Property<?>> properties) {
        return Optional.ofNullable(properties)
                .map(Map::values)
                .stream()
                .flatMap(Collection::stream)
                .map(this::convert)
                .toList();
    }

    default Map<String, Property<?>> convert(List<CustomProperty> properties) {
        return Optional.ofNullable(properties)
                .stream()
                .flatMap(Collection::stream)
                .map(this::convert)
                .collect(Collectors.toMap(Property::getName, Function.identity()));
    }
}
