package sbp.tcpf.support_admin.configs

import jakarta.annotation.PostConstruct
import jakarta.annotation.PreDestroy
import org.apache.curator.framework.recipes.cache.CuratorCache
import org.apache.curator.framework.recipes.cache.CuratorCacheListener
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.context.annotation.Configuration

@Configuration
class RequestCuratorCacheListenerRegistrar(
    private val listeners: List<CuratorCacheListener>,
    @Qualifier("requestCache")
    private val cache: CuratorCache
) {

    @PostConstruct
    fun add() {
        listeners.forEach { listener -> cache.listenable().addListener(listener) }
        cache.start()
    }

    @PreDestroy
    fun remove() {
        listeners.forEach { listener -> cache.listenable().removeListener(listener) }
        cache.close()
    }
}
