package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.routing.client.domain.RoutingIndex;
import sbp.tcpf.support_admin.model.RoutingType;

import org.mapstruct.Mapper;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING)
public interface RoutingTypeMapper {
    RoutingIndex map(RoutingType type);
}
