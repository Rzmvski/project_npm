package sbp.tcpf.support_admin.controllers;

import sbp.tcpf.audit.api.AuditEvent;
import sbp.tcpf.support_admin.api.ReviseReplicationServiceApi;
import sbp.tcpf.support_admin.model.RevisionDetails;
import sbp.tcpf.support_admin.model.RevisionInfo;
import sbp.tcpf.support_admin.model.RevisionJob;
import sbp.tcpf.support_admin.model.RevisionReport;
import sbp.tcpf.support_admin.model.RevisionStatus;
import sbp.tcpf.support_admin.services.ReviseReplicationService;

import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.RestController;
import lombok.RequiredArgsConstructor;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import static sbp.tcpf.base.metrics.TcpfMetrics.SERVICE;
import static sbp.tcpf.base.metrics.TcpfMetrics.SERVICE_CALL;

import io.micrometer.core.annotation.Timed;

@RestController
@RequiredArgsConstructor
public class ReviseReplicationController implements ReviseReplicationServiceApi {

    private final ReviseReplicationService reviseReplicationService;

    @Override
    @Timed(value = SERVICE_CALL, extraTags = {SERVICE, "ReviseReplicationService"})
    @AuditEvent(onSuccess = "RUN_REVISION", onError = "RUN_REVISION_ERROR")
    @Secured("revisionService_runRevision")
    public List<RevisionInfo> revise(UUID uuid, List<String> shardIds, Integer part) {
        return reviseReplicationService.revise(shardIds, uuid, part);
    }

    @Override
    @Timed(value = SERVICE_CALL, extraTags = {SERVICE, "ReviseReplicationService"})
    @Secured("revisionService_runRevision")
    public RevisionInfo changeRevisionStatus(Long revisionId, UUID uuid, String shardId, RevisionStatus status, RevisionJob job, String table) {
        return reviseReplicationService.changeStatus(shardId, revisionId, uuid, status, job, table);
    }

    @Override
    @Timed(value = SERVICE_CALL, extraTags = {SERVICE, "ReviseReplicationService"})
    @Secured("revisionService_runRevision")
    public List<RevisionDetails> reviseDetails(String reviseShardId, Long revisionId, Integer pageNumber, Integer pageSize, String tableName) {
        return reviseReplicationService.loadDetails(reviseShardId, revisionId, tableName, pageNumber, pageSize);
    }

    @Override
    @Timed(value = SERVICE_CALL, extraTags = {SERVICE, "ReviseReplicationService"})
    @Secured("revisionService_getRevisionHistory")
    public List<RevisionInfo> reviseHistory(
            List<String> reviseShardIds,
            String status,
            Long revisionId,
            LocalDate started,
            LocalDate completed,
            Integer pageNumber,
            Integer pageSize
    ) {
        return reviseReplicationService.loadHistory(reviseShardIds, status, revisionId, started, completed, pageNumber, pageSize);
    }

    @Override
    @Timed(value = SERVICE_CALL, extraTags = {SERVICE, "ReviseReplicationService"})
    @Secured("revisionService_runRevision")
    public List<RevisionReport> reviseReport(
            String reviseShardId,
            Long revisionId,
            Integer pageNumber,
            String table
    ) {
        return reviseReplicationService.loadReport(reviseShardId, revisionId, table, pageNumber);
    }

    @Override
    @Timed(value = SERVICE_CALL, extraTags = {SERVICE, "ReviseReplicationService"})
    @Secured("revisionService_runRevision")
    public List<RevisionInfo> getLastRevisions() {
        return reviseReplicationService.getLastRevisions();
    }

    @Override
    @Timed(value = SERVICE_CALL, extraTags = {SERVICE, "ReviseReplicationService"})
    @Secured("revisionService_runRevision")
    public RevisionInfo getRevisionById(Long revisionId, UUID uuid, String shardId) {
        return reviseReplicationService.getRevisionById(revisionId, shardId);
    }

    @Override
    @Timed(value = SERVICE_CALL, extraTags = {SERVICE, "ReviseReplicationService"})
    @Secured("revisionService_runRevision")
    public List<String> getRevisionShardIds() {
        return reviseReplicationService.getReviseShardIds();
    }
}
