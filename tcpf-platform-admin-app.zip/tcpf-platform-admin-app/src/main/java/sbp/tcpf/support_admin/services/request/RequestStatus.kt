package sbp.tcpf.support_admin.services.request

enum class RequestStatus(val id: Long) {
    CREATED(36L),
    WORKS(37L),
    SUCCESS(38L),
    ERROR(39L),
    WARN(40L),
    CANCELED(41L),
    PENDING(155L),
    APPROVED(156L),
    DECLINE(136L),
    ARCHIVED(203L);

    companion object {
        @JvmStatic
        fun findById(id: Long): RequestStatus? {
            return RequestStatus.values().find { it.id == id }
        }
    }
}
