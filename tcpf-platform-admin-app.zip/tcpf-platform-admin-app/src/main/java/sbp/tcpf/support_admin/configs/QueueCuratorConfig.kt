package sbp.tcpf.support_admin.configs

import org.apache.curator.framework.CuratorFramework
import org.apache.curator.framework.recipes.queue.DistributedDelayQueue
import org.apache.curator.framework.recipes.queue.QueueBuilder
import org.apache.curator.framework.recipes.queue.QueueConsumer
import org.apache.curator.framework.recipes.queue.QueueSerializer
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import sbp.tcpf.support_admin.configs.CuratorConfig.ModuleCuratorBean

@Configuration
class QueueCuratorConfig {

    @Bean
    fun archiveDistributedQueue(
        @ModuleCuratorBean curator: CuratorFramework,
        consumer: QueueConsumer<String>,
        serializer: QueueSerializer<String>,
    ): DistributedDelayQueue<String> {
        return QueueBuilder
            .builder(curator, consumer, serializer, "/queues/archive")
            .lockPath("/locks")
            .buildDelayQueue()
            .also { it.start() }
    }
}
