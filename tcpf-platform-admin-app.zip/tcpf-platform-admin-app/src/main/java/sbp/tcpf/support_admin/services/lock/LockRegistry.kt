package sbp.tcpf.support_admin.services.lock

import org.springframework.stereotype.Component
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.locks.ReentrantReadWriteLock

@Component
class LockRegistry {
    private val locks = ConcurrentHashMap<String, ReentrantReadWriteLock>()

    fun get(path: String): ReentrantReadWriteLock {
        return locks.computeIfAbsent(path) { ReentrantReadWriteLock() }
    }

    fun remove(path: String) {
        locks.remove(path)
    }
}