package sbp.tcpf.support_admin.entities;

import sbp.tcpf.support_admin.dto.FeatureDelta;
import sbp.tcpf.support_admin.dto.FeatureTargetDto;

import org.apache.curator.utils.ZKPaths;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

import static sbp.tcpf.ff4j.utils.Constants.APPS_FEATURE;
import static sbp.tcpf.ff4j.utils.Constants.GLOBAL_FEATURE;

import jakarta.validation.constraints.NotNull;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@SuperBuilder(toBuilder = true)
public class FeatureRequest extends AbstractRequest {
    private UUID rqUid;
    private String featureName;
    @NotNull
    private FeatureTargetDto target;
    @NotNull
    private FeatureDelta delta;
    private Boolean hot;

    public FeatureRequest resolve(String resolverLogin, String resolvedStatus) {
        return this.toBuilder()
                   .resolvedAt(LocalDateTime.now())
                   .resolvedBy(resolverLogin)
                   .requestStatus(resolvedStatus)
                   .build();
    }

    @Override
    public String getPath() {
        return Optional.ofNullable(target.module())
                       .map(module -> ZKPaths.makePath(APPS_FEATURE, module, this.getUid(), this.getRqUid().toString()))
                       .orElse(ZKPaths.makePath(GLOBAL_FEATURE, this.getUid(), this.getRqUid().toString()));
    }
}
