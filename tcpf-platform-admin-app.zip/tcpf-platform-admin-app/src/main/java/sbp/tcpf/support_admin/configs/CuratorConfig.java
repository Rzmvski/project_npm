package sbp.tcpf.support_admin.configs;

import sbp.tcpf.coordination.config.CuratorFacade.AppCuratorBean;
import sbp.tcpf.coordination.discovery.ApplicationInstanceInfo;
import sbp.tcpf.support_admin.configs.properties.CuratorLockProperties;
import sbp.tcpf.support_admin.configs.properties.ScriptServiceProperties;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.recipes.cache.CuratorCache;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.String.join;
import static org.apache.curator.utils.ZKPaths.PATH_SEPARATOR;

@Configuration
@EnableConfigurationProperties(CuratorLockProperties.class)
public class CuratorConfig {

    private static final String REQUEST_ROOT = "requests";

    @Retention(RetentionPolicy.RUNTIME)
    @Target({ElementType.CONSTRUCTOR, ElementType.FIELD, ElementType.PARAMETER, ElementType.METHOD})
    @Bean("requestCuratorFramework")
    @Qualifier("requestCuratorFramework")
    public @interface RequestCuratorBean {
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target({ElementType.CONSTRUCTOR, ElementType.FIELD, ElementType.PARAMETER, ElementType.METHOD})
    @Bean("moduleCuratorFramework")
    @Qualifier("moduleCuratorFramework")
    public @interface ModuleCuratorBean {
    }

    @ModuleCuratorBean
    public CuratorFramework moduleCuratorFramework(
            @AppCuratorBean CuratorFramework curatorFramework,
            ApplicationInstanceInfo instanceInfo
    ) {
        return curatorFramework.usingNamespace(
                join(PATH_SEPARATOR, curatorFramework.getNamespace(), instanceInfo.getModuleId())
        );
    }

    @RequestCuratorBean
    public CuratorFramework requestCuratorFramework(@ModuleCuratorBean CuratorFramework curatorFramework) {
        return curatorFramework.usingNamespace(
                join(PATH_SEPARATOR, curatorFramework.getNamespace(), REQUEST_ROOT)
        );
    }

    @Bean
    public CuratorCache requestCache(@RequestCuratorBean CuratorFramework curatorFramework) {
        return CuratorCache.build(
                curatorFramework,
                PATH_SEPARATOR
        );
    }

    @Bean
    public CuratorCache executionCache(
            @AppCuratorBean CuratorFramework curatorFramework,
            ScriptServiceProperties properties
    ) {
        return CuratorCache.build(
                curatorFramework,
                properties.zookeeper().path()
        );
    }
}
