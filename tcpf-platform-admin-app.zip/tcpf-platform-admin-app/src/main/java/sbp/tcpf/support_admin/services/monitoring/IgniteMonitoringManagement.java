package sbp.tcpf.support_admin.services.monitoring;

import sbp.tcpf.support_admin.model.IgniteType;
import sbp.tcpf.support_admin.model.Monitoring;

import org.jetbrains.annotations.NotNull;

import reactor.core.publisher.Flux;

public interface IgniteMonitoringManagement extends MonitoringManagement {

    @Override
    default Flux<Monitoring> getMonitoringInfo() {
        return getMonitoringByType(IgniteType.ALL);
    }

    Flux<Monitoring> getMonitoringByType(@NotNull IgniteType igniteType);
}
