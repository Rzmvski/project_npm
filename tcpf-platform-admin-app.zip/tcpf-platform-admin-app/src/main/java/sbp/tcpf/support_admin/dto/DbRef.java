package sbp.tcpf.support_admin.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

import java.io.Serializable;

@Value
@Builder
@Jacksonized
@AllArgsConstructor
public class DbRef implements Serializable {
    int shardId;
}
