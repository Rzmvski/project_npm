package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.forced.replication.model.ServiceModeStatus;
import sbp.tcpf.support_admin.model.ServiceModeStatusDto;
import sbp.tcpf.support_admin.utils.DateTimeUtils;

import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

@Mapper(
        componentModel = MappingConstants.ComponentModel.SPRING,
        uses = {
                DateTimeUtils.class,
                ServiceModeStateMapper.class
        }
)
public interface ServiceModeStatusMapper {

    ServiceModeStatusDto map(ServiceModeStatus status);
}
