package sbp.tcpf.support_admin.controllers

import io.micrometer.core.annotation.Timed
import org.springframework.http.codec.ServerSentEvent
import org.springframework.web.bind.annotation.RestController
import reactor.core.publisher.Flux
import sbp.tcpf.base.metrics.TcpfMetrics
import sbp.tcpf.support_admin.api.RegionManagementServiceApi
import sbp.tcpf.support_admin.model.RegionDto
import sbp.tcpf.support_admin.model.RegionGroupDto
import sbp.tcpf.support_admin.services.RegionManagementService
import sbp.tcpf.support_admin.utils.toSse

@RestController
class RegionManagementController(
    private val regionManagementService: RegionManagementService,
) : RegionManagementServiceApi {

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "RegionManagementService"])
    override fun getRegionGroups(): Flux<ServerSentEvent<RegionGroupDto>> {
        return regionManagementService.getRegionGroups().toSse()
    }

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "RegionManagementService"])
    override fun updateRegionGroups(regionGroupDto: List<RegionGroupDto>): Flux<ServerSentEvent<RegionGroupDto>> {
        return regionManagementService.updateRegionGroups(regionGroupDto).toSse()
    }

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "RegionManagementService"])
    override fun updateRegionAvailability(regionDto: List<RegionDto>): Flux<ServerSentEvent<RegionDto>> {
        return regionManagementService.updateRegionAvailability(regionDto).toSse()
    }
}