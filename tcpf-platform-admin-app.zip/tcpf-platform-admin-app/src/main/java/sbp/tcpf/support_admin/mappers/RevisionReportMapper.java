package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.replica.monitor.api.mass.model.RevisionRow;
import sbp.tcpf.support_admin.model.RevisionReport;
import sbp.tcpf.support_admin.utils.DateTimeUtils;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING, uses = DateTimeUtils.class)
public interface RevisionReportMapper {

    @Mapping(target = "table", source = "tableName")
    RevisionReport convert(RevisionRow row);
}
