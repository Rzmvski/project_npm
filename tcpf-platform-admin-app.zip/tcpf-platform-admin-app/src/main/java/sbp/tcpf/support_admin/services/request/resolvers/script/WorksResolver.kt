package sbp.tcpf.support_admin.services.request.resolvers.script

import org.springframework.stereotype.Component
import sbp.tcpf.support.commons.auth.services.UserService
import sbp.tcpf.support_admin.clients.kafka.ScriptEngineCommandPublisher
import sbp.tcpf.support_admin.dto.ScriptApplicationDto
import sbp.tcpf.support_admin.mappers.ScriptExecutionRequestMapper
import sbp.tcpf.support_admin.model.ApplicationStatus
import sbp.tcpf.support_admin.services.request.resolvers.RequestResolver
import sbp.tcpf.support_admin.services.request.store.CompositeScriptDataStore

@Component
class WorksResolver(
    private val userService: UserService,
    private val engineCommandPublisher: ScriptEngineCommandPublisher,
    private val scriptExecutionRequestMapper: ScriptExecutionRequestMapper,
    private val store: CompositeScriptDataStore,
) : RequestResolver<ScriptApplicationDto> {

    override val status: ApplicationStatus = ApplicationStatus.WORKS

    override fun resolve(application: ScriptApplicationDto): ScriptApplicationDto {
        val userLogin = userService.getUserLogin() ?: throw IllegalStateException()
        val resolved = application.withExecutedBy(userLogin)
        val command = scriptExecutionRequestMapper.map(resolved)

        engineCommandPublisher.sendCommand(command)

        return store.execute(
                application.location,
                userLogin
        )
    }
}
