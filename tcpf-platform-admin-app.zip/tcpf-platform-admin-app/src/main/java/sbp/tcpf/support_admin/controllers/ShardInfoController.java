package sbp.tcpf.support_admin.controllers;

import sbp.tcpf.audit.api.AuditEvent;
import sbp.tcpf.support_admin.api.ShardInfoServiceApi;
import sbp.tcpf.support_admin.model.RoutingType;
import sbp.tcpf.support_admin.model.ShardInfo;
import sbp.tcpf.support_admin.services.RoutingObjectService;

import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.RestController;
import lombok.RequiredArgsConstructor;

import static sbp.tcpf.base.metrics.TcpfMetrics.SERVICE;
import static sbp.tcpf.base.metrics.TcpfMetrics.SERVICE_CALL;

import io.micrometer.core.annotation.Timed;

/**
 * REST-контроллер для получения информации о шардах по идентификаторам клиента
 */
@RestController
@RequiredArgsConstructor
public class ShardInfoController implements ShardInfoServiceApi {

    private final RoutingObjectService routingObjectService;

    @Override
    @Timed(value = SERVICE_CALL, extraTags = { SERVICE, "ShardInfoService" })
    @AuditEvent(onSuccess = "SHARD_INFO", onError = "SHARD_INFO_ERROR")
    @Secured("shardInfoService_getInfo")
    public ShardInfo getShardInfo(RoutingType type, String key) {
        return routingObjectService.getShardInfo(type, key);
    }
}
