package sbp.tcpf.support_admin.services

import org.springframework.stereotype.Service
import sbp.tcpf.support_admin.dto.FeatureDelta
import sbp.tcpf.support_admin.entities.FeatureRequest
import sbp.tcpf.support_admin.facades.Ff4jFacade
import sbp.tcpf.support_admin.mappers.LogicalFeatureMapper
import sbp.tcpf.support_admin.model.FeatureApplication
import sbp.tcpf.support_admin.model.LoadFeatureDump201Response
import sbp.tcpf.support_admin.model.LogicalFeature
import sbp.tcpf.support_admin.services.request.FeatureRequestFactory
import sbp.tcpf.support_admin.services.request.RequestService
import java.util.*

@Service
class ImportFeatureService(
    private val ff4jFacade: Ff4jFacade,
    private val logicalFeatureMapper: LogicalFeatureMapper,
    private val featureRequestFactory: FeatureRequestFactory,
    private val requestService: RequestService<UUID, FeatureRequest, FeatureApplication>,
) {

    fun import(permissionId: String, dump: List<LogicalFeature>): LoadFeatureDump201Response {
        val existingByKey = ff4jFacade.getLogicalFeatures()
            .associateBy { it.key }

        val requests = dump
            .map { dto -> logicalFeatureMapper.map(dto) }
            .mapNotNull { desired ->
                val existing = existingByKey[desired.key]
                featureRequestFactory
                    .create(permissionId, desired, existing)
                    .orElse(null)
            }
            .filter { !it.hasDeltaType(FeatureDelta.ChangeType.DELETE) }

        requests.forEach { requestService.save(it) }

        val (created, updated) = requests
            .fold(0 to 0) { (created, updated), request ->
                when {
                    request.hasDeltaType(FeatureDelta.ChangeType.CREATE) -> created + 1 to updated
                    request.hasDeltaType(FeatureDelta.ChangeType.UPDATE) -> created to updated + 1
                    else -> created to updated
                }
            }


        return LoadFeatureDump201Response(
                created,
                updated,
                dump.size - (created + updated)
        )
    }

    private fun FeatureRequest.hasDeltaType(type: FeatureDelta.ChangeType): Boolean =
        this.delta.type() == type
}
