package sbp.tcpf.support_admin.configs

import org.springframework.boot.autoconfigure.condition.ConditionalOnBooleanProperty
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import sbp.tcpf.support.commons.auth.services.UserService
import sbp.tcpf.support_admin.configs.properties.ResolveRequestServiceProperties
import sbp.tcpf.support_admin.configs.properties.ScriptServiceProperties
import sbp.tcpf.support_admin.dto.ScriptApplicationDto
import sbp.tcpf.support_admin.entities.RequestEntity
import sbp.tcpf.support_admin.entities.ScriptRequest
import sbp.tcpf.support_admin.mappers.RequestMapper
import sbp.tcpf.support_admin.mappers.RequestStatusMapper
import sbp.tcpf.support_admin.model.ScriptApplication
import sbp.tcpf.support_admin.repositories.RequestRepository
import sbp.tcpf.support_admin.repositories.impl.DbRequestRepository
import sbp.tcpf.support_admin.services.ShardService
import sbp.tcpf.support_admin.services.lock.CuratorLockManager
import sbp.tcpf.support_admin.services.request.cache.RequestCuratorCacheManager
import sbp.tcpf.support_admin.services.request.dto.ScriptKey
import sbp.tcpf.support_admin.services.request.store.DatabaseRequestStore
import sbp.tcpf.support_admin.services.request.store.RequestDataStore
import sbp.tcpf.support_admin.services.request.store.ZookeeperRequestDataStore
import sbp.tcpf.support_admin.services.request.store.modifiers.Modifier
import sbp.tcpf.support_admin.wrappers.SafeUnitOfWorkOperations

@Configuration
@EnableConfigurationProperties(ResolveRequestServiceProperties::class)
class RequestServiceConfig {

    @Bean
    @ConditionalOnBooleanProperty(
            prefix = "tcpf-platform-admin-app.resolve-request-service",
            name = ["db-persist"],
            matchIfMissing = true
    )
    fun scriptApplicationDatabaseDataStore(
        mapper: RequestMapper<ScriptApplicationDto, RequestEntity>,
        properties: ResolveRequestServiceProperties,
        scriptModifiers: List<Modifier<ScriptApplication>>,
        uow: SafeUnitOfWorkOperations,
        shardService: ShardService,
        scriptRequestRepository: DbRequestRepository,
        statusMapper: RequestStatusMapper,
        userService: UserService,
        scriptProperties: ScriptServiceProperties,
    ): RequestDataStore<ScriptApplicationDto, String, ScriptKey, RequestEntity> {
        return DatabaseRequestStore(
                mapper = mapper,
                uow = uow,
                shardService = shardService,
                repository = scriptRequestRepository,
                properties = properties,
                statusMapper = statusMapper,
        )
    }

    @Bean
    fun scriptApplicationZookeeperDataStore(
        lockManager: CuratorLockManager,
        requestRepository: RequestRepository<ScriptRequest, String, Class<ScriptRequest>>,
        curatorCache: RequestCuratorCacheManager,
        scriptZkEntityMapper: RequestMapper<ScriptApplicationDto, ScriptRequest>,
        requestModifiers: List<Modifier<ScriptRequest>>,
        userService: UserService,
    ): RequestDataStore<ScriptApplicationDto, String, ScriptKey, ScriptRequest> {
        return ZookeeperRequestDataStore(
                lockManager = lockManager,
                repository = requestRepository,
                curatorCache = curatorCache,
                requestClass = ScriptRequest::class.java,
                mapper = scriptZkEntityMapper,
                modifiers = requestModifiers,
                uidFunction = { key -> key.scriptId },
                contentFunction = { request -> request.content?.let { String(it) } }
        )
    }
}
