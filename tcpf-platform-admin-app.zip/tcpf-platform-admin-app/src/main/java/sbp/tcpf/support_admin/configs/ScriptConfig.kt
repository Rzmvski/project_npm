package sbp.tcpf.support_admin.configs

import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.context.annotation.Configuration
import sbp.tcpf.support_admin.configs.properties.ScriptServiceProperties

@Configuration
@EnableConfigurationProperties(ScriptServiceProperties::class)
class ScriptConfig
