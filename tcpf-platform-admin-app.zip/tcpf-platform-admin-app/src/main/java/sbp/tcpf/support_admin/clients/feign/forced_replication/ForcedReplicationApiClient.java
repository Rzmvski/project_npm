package sbp.tcpf.support_admin.clients.feign.forced_replication;

import sbp.tcpf.forced.replication.api.ForcedReplicationApi;
import sbp.tcpf.support_admin.clients.feign.forced_replication.config.ForcedReplicationFeignConfig;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cloud.openfeign.FeignClient;

@ConditionalOnProperty(
        prefix = "tcpf-platform-admin-app.tcpf-forced-replication-app",
        name = "uri"
)
@FeignClient(
        name = "ForcedReplication",
        url = "${tcpf-platform-admin-app.tcpf-forced-replication-app.uri}",
        primary = false,
        configuration = ForcedReplicationFeignConfig.class
)
public interface ForcedReplicationApiClient extends ForcedReplicationApi {
}
