package sbp.tcpf.support_admin.exceptions;

import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

import feign.FeignException;
import feign.Request;

public class ExternalServiceException extends FeignException {

    public ExternalServiceException(String message) {
        super(INTERNAL_SERVER_ERROR.value(), message);
    }

    public ExternalServiceException(int status, String message, Request request) {
        super(status, message, request);
    }
}
