package sbp.tcpf.support_admin.services

import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import reactor.core.publisher.Flux
import sbp.tcpf.os.commons.config.ModuleProperties
import sbp.tcpf.support.commons.auth.services.UserService
import sbp.tcpf.support_admin.clients.feign.routing.RegionManagementApiClient
import sbp.tcpf.support_admin.mappers.RegionManagementServiceMapper
import sbp.tcpf.support_admin.model.RegionDto
import sbp.tcpf.support_admin.model.RegionGroupDto
import java.time.OffsetDateTime
import java.util.*

@Service
class RegionManagementService(
    private val regionManagementClient: RegionManagementApiClient,
    private val regionManagementServiceMapper: RegionManagementServiceMapper,
    private val userService: UserService,
    private val moduleProperties: ModuleProperties,
) {
    fun getRegionGroups(): Flux<RegionGroupDto> {
        log.debug("get region groups")
        return regionManagementClient.getRegionGroups()
            .doOnNext { regionGroup -> log.trace("region group received: {}", regionGroup) }
            .doOnError { error -> log.debug("get region groups failed", error) }
            .map { regionGroup -> regionManagementServiceMapper.convert(regionGroup) }
    }

    fun updateRegionGroups(regionGroups: List<RegionGroupDto>): Flux<RegionGroupDto> {
        val uuid = UUID.randomUUID().toString()
        val userLogin = userService.getUserLogin()
        val body = Flux.fromIterable(regionGroups)
            .map { regionGroup -> regionManagementServiceMapper.convert(regionGroup) }
        log.debug("update region groups: requestId={}, groups={}", uuid, regionGroups.size)
        log.trace("update region groups: requestId={}, body={}", uuid, regionGroups)

        return regionManagementClient.updateRegionGroups(
            body,
            moduleProperties.moduleId,
            userLogin,
            uuid,
            OffsetDateTime.now()
        )
            .doOnNext { regionGroup -> log.trace("region group updated: requestId={}, group={}", uuid, regionGroup) }
            .doOnError { error -> log.debug("update region groups failed: requestId={}", uuid, error) }
            .map { regionGroup -> regionManagementServiceMapper.convert(regionGroup) }
    }

    fun updateRegionAvailability(regions: List<RegionDto>): Flux<RegionDto> {
        val uuid = UUID.randomUUID().toString()
        val userLogin = userService.getUserLogin()
        val body = Flux.fromIterable(regions).map { region -> regionManagementServiceMapper.convert(region) }
        log.debug("update region availability: requestId={}, regions={}", uuid, regions)

        return regionManagementClient.updateRegionAvailability(
                body,
                moduleProperties.moduleId,
                userLogin,
                uuid,
                OffsetDateTime.now()
        )
            .doOnNext { region -> log.trace("region updated: requestId={}, region={}", uuid, region) }
            .doOnError { error -> log.debug("update region availability failed: requestId={}", uuid, error) }
            .map { region -> regionManagementServiceMapper.convert(region) }
    }

    companion object {
        val log: Logger = LoggerFactory.getLogger(RegionManagementService::class.java)
    }
}