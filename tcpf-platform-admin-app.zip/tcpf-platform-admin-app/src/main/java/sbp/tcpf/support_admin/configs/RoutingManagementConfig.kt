package sbp.tcpf.support_admin.configs

import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.cloud.openfeign.EnableFeignClients
import org.springframework.context.annotation.Configuration
import sbp.tcpf.support_admin.configs.properties.RoutingAppOsProperties

@Configuration
@EnableConfigurationProperties(RoutingAppOsProperties::class)
class RoutingManagementConfig
