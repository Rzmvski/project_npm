package sbp.tcpf.support_admin.controllers

import io.micrometer.core.annotation.Timed
import org.springframework.context.annotation.Scope
import org.springframework.context.annotation.ScopedProxyMode.TARGET_CLASS
import org.springframework.security.access.annotation.Secured
import org.springframework.web.bind.annotation.RestController
import sbp.tcpf.base.metrics.TcpfMetrics
import sbp.tcpf.support_admin.api.FeatureTogglingServiceApi
import sbp.tcpf.support_admin.model.*
import sbp.tcpf.support_admin.services.FeatureTogglingService
import sbp.tcpf.support_admin.services.ImportFeatureService
import sbp.tcpf.support_admin.services.PropertyTypesSupplierService
import java.util.*

@Scope(proxyMode = TARGET_CLASS)
@RestController
class FeatureTogglingController(
    private val featureTogglingService: FeatureTogglingService,
    private val propertyTypesSupplierService: PropertyTypesSupplierService,
    private val importFeatureService: ImportFeatureService,
) : FeatureTogglingServiceApi {

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "FeatureTogglingService"])
    override fun getPropertyTypes(): List<String> {
        return propertyTypesSupplierService.getTypes()
    }

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "FeatureTogglingService"])
    @Secured("featureTogglingService_manageFeature")
    override fun loadFeatureDump(loadFeatureDumpRequest: LoadFeatureDumpRequest): LoadFeatureDump201Response {
        return importFeatureService.import(loadFeatureDumpRequest.requestId, loadFeatureDumpRequest.dump)
    }

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "FeatureTogglingService"])
    @Secured("featureTogglingService_manageFeature")
    override fun resolveApplication(
        uid: UUID,
        resolveScriptApplicationRequest: ResolveScriptApplicationRequest,
    ): FeatureApplication {
        return featureTogglingService.resolveFeatureRequest(uid, resolveScriptApplicationRequest.status)
    }

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "FeatureTogglingService"])
    @Secured("featureTogglingService_getInfo")
    override fun featureApplications(): List<FeatureApplication> {
        return featureTogglingService.loadFeatureRequests()
    }

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "FeatureTogglingService"])
    @Secured("featureTogglingService_getInfo")
    override fun getFeatures(): List<LogicalFeature> {
        return featureTogglingService.getFeatures()
    }

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "FeatureTogglingService"])
    @Secured("featureTogglingService_manageFeature")
    override fun createFeatures(createFeaturesRequest: List<CreateFeaturesRequestInner>) {
        featureTogglingService.createApplications(createFeaturesRequest)
    }

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "FeatureTogglingService"])
    @Secured("featureTogglingService_manageFeature")
    override fun editHotConfigFeatures(logicalFeature: List<LogicalFeature>) {
        featureTogglingService.updateFeatures(logicalFeature)
    }

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "FeatureTogglingService"])
    @Secured("featureTogglingService_getInfo")
    override fun featureStatistics(): List<FeatureStatistics> {
        return featureTogglingService.getStatistics()
    }
}
