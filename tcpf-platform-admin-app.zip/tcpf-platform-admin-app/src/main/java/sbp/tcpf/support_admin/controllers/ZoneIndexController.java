package sbp.tcpf.support_admin.controllers;

import sbp.tcpf.audit.api.AuditEvent;
import sbp.tcpf.support_admin.api.ZoneIndexServiceApi;
import sbp.tcpf.support_admin.model.ClusterInfo;
import sbp.tcpf.support_admin.model.IndexActionResponse;
import sbp.tcpf.support_admin.model.StartActionWithIndexesRq;
import sbp.tcpf.support_admin.services.ZoneIndexService;

import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import lombok.RequiredArgsConstructor;

import java.util.List;

import static sbp.tcpf.base.metrics.TcpfMetrics.SERVICE;
import static sbp.tcpf.base.metrics.TcpfMetrics.SERVICE_CALL;

import io.micrometer.core.annotation.Timed;

/**
 * REST-контроллер для взаимодействия с ZoneIndex-сервисом
 */
@RestController
@RequiredArgsConstructor
public class ZoneIndexController implements ZoneIndexServiceApi {

    private final ZoneIndexService zoneIndexService;

    /**
     * Метод для получения информации о состоянии кластеров
     * @return Список кластеров
     */
    @Override
    @Timed(value = SERVICE_CALL, extraTags = { SERVICE, "ZoneIndexService" })
    @AuditEvent(onSuccess = "VIEW_CLUSTER_INFO", onError = "VIEW_CLUSTER_INFO_ERROR")
    @Secured("zoneIndexService_getClusterInfo")
    public List<ClusterInfo> clusterInfo() {
        return zoneIndexService.getClusterInfo();
    }

    /**
     * Метод для изменения состояния кластера
     * @param request запрос, содержащий {@link StartActionWithIndexesRq} с ID кластера и действие с ним
     * @return результат изменения состояния кластера
     */
    @Override
    @Timed(value = SERVICE_CALL, extraTags = { SERVICE, "ZoneIndexService" })
    @AuditEvent(onSuccess = "MANAGE_INDEXES", onError = "MANAGE_INDEXES_ERROR")
    @Secured("zoneIndexService_startActionWithIndexes")
    public IndexActionResponse indexesExecute(@RequestBody StartActionWithIndexesRq request) {
        return zoneIndexService.manageIndexes(request);
    }

}
