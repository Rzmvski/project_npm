package sbp.tcpf.support_admin.clients.feign.script_engine;

import sbp.tcpf.script.engine.api.BeanIntrospectionServiceApi;
import sbp.tcpf.support_admin.clients.feign.script_engine.config.ScriptEngineFeignConfig;

import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(
        name = "ShellBeansServiceApi",
        url = "${tcpf-platform-admin-app.script-service.uri}",
        configuration = ScriptEngineFeignConfig.class
)
public interface ShellBeansApi extends BeanIntrospectionServiceApi {
}
