package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.routing.api.v1_0.client.model.ClusterStatus;
import sbp.tcpf.support_admin.model.ClusterState;

import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;
import org.mapstruct.ValueMapping;

@Mapper(componentModel = "spring")
public interface ClusterStateMapper {
    @ValueMapping(source = MappingConstants.ANY_REMAINING, target = MappingConstants.THROW_EXCEPTION)
    ClusterStatus convert(ClusterState state);
}
