package sbp.tcpf.support_admin.services.forced_replication

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty
import org.springframework.context.annotation.Primary
import org.springframework.stereotype.Service
import sbp.tcpf.forced.replication.model.OperationRequest
import sbp.tcpf.forced.replication.model.ServiceModeRequest
import sbp.tcpf.support_admin.clients.feign.forced_replication.ForcedReplicationApiClient
import sbp.tcpf.support_admin.clients.feign.forced_replication.ServiceModeApiClient
import sbp.tcpf.support_admin.mappers.OperationResponseMapper
import sbp.tcpf.support_admin.mappers.ReplicationStatusMapper
import sbp.tcpf.support_admin.mappers.ServiceModeStateMapper
import sbp.tcpf.support_admin.mappers.ServiceModeStatusMapper
import sbp.tcpf.support_admin.model.OperationResponseDto
import sbp.tcpf.support_admin.model.ReplicationStatusDto
import sbp.tcpf.support_admin.model.ServiceModeState
import sbp.tcpf.support_admin.model.ServiceModeStatusDto
import java.time.OffsetDateTime
import java.util.*

@Service
@Primary
@ConditionalOnProperty(
        prefix = "tcpf-platform-admin-app.tcpf-forced-replication-app",
        name = ["uri"],
)
class DefaultForcedReplicationService(
    private val replicationApiClient: ForcedReplicationApiClient,
    private val serviceModeApiClient: ServiceModeApiClient,
    private val operationMapper: OperationResponseMapper,
    private val serviceModeStatusMapper: ServiceModeStatusMapper,
    private val replicationStatusMapper: ReplicationStatusMapper,
    private val serviceModeStateMapper: ServiceModeStateMapper,
) : ForcedReplicationService {

    override fun getReplicationStatus(shardId: Int): ReplicationStatusDto {
        return replicationApiClient.getForcedReplication(shardId)
            .let { status -> replicationStatusMapper.map(status) }
    }

    override fun getServiceModeStatus(): ServiceModeStatusDto {
        return serviceModeApiClient.serviceMode
            .let { status -> serviceModeStatusMapper.map(status) }
    }

    override fun startReplication(shardId: Int): OperationResponseDto {
        val request = OperationRequest(
                UUID.randomUUID(),
                OffsetDateTime.now()
        )

        return replicationApiClient.startReplication(shardId, request)
            .let { response -> operationMapper.map(response) }
    }

    override fun undoReplication(shardId: Int): OperationResponseDto {
        return replicationApiClient.undoReplication(shardId)
            .let { response -> operationMapper.map(response) }
    }

    override fun changeServiceMode(serviceModeState: ServiceModeState): OperationResponseDto {
        val state = serviceModeStateMapper.map(serviceModeState)
        val request = ServiceModeRequest(
                UUID.randomUUID(),
                OffsetDateTime.now(),
                state,
        )

        return serviceModeApiClient.updateServiceMode(request)
            .let { response -> operationMapper.map(response) }
    }
}
