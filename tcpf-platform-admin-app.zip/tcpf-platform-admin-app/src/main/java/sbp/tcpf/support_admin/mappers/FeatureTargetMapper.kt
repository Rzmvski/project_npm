package sbp.tcpf.support_admin.mappers

import org.springframework.stereotype.Component
import sbp.tcpf.support_admin.dto.FeatureLocation
import sbp.tcpf.support_admin.dto.FeatureTargetDto
import sbp.tcpf.support_admin.model.DirectFeatureTarget
import sbp.tcpf.support_admin.model.FeatureTarget
import sbp.tcpf.support_admin.model.NodeFeatureTarget
import sbp.tcpf.support_admin.model.ShardFeatureTarget

@Component
class FeatureTargetMapper {

    fun toDomain(source: FeatureTarget): FeatureTargetDto {
        return when (source) {
            is DirectFeatureTarget -> FeatureTargetDto(
                    FeatureTargetDto.Type.DIRECT, source.module, null
            )

            is NodeFeatureTarget -> FeatureTargetDto(
                    FeatureTargetDto.Type.NODE, source.module, listOf(source.nodeKey)
            )

            is ShardFeatureTarget -> FeatureTargetDto(
                    FeatureTargetDto.Type.SHARD, source.module, source.nodeKeys
            )

            else ->
                throw IllegalArgumentException(
                        "Unsupported feature target: ${source.javaClass.name}"
                )
        }
    }

    fun toApi(source: FeatureTargetDto): FeatureTarget {
        return when (source.type) {
            FeatureTargetDto.Type.DIRECT -> DirectFeatureTarget().module(source.module)

            FeatureTargetDto.Type.NODE -> NodeFeatureTarget.builder()
                .nodeKey(source.nodeKeys.single())
                .module(source.module)
                .build()

            FeatureTargetDto.Type.SHARD -> ShardFeatureTarget.builder()
                .nodeKeys(source.nodeKeys)
                .module(source.module)
                .build()
        }
    }

    fun toLocation(source: FeatureTarget): List<FeatureLocation> {
        return when (source) {
            is DirectFeatureTarget -> listOf(FeatureLocation(source.module, null))

            is NodeFeatureTarget -> listOf(
                    FeatureLocation(source.module, source.nodeKey)
            )

            is ShardFeatureTarget -> source.nodeKeys.map { node ->
                FeatureLocation(
                        source.module, node
                )
            }

            else ->
                throw IllegalArgumentException(
                        "Unsupported feature target: ${source.javaClass.name}"
                )
        }
    }

}
