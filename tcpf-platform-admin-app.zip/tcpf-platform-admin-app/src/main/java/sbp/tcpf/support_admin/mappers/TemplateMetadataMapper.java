package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.script.engine.model.MetaInfo;
import sbp.tcpf.support_admin.model.TemplateMetadata;

import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface TemplateMetadataMapper {

    TemplateMetadata map(MetaInfo metadata);
}
