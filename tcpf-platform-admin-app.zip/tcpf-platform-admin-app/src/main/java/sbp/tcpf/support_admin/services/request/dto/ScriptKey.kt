package sbp.tcpf.support_admin.services.request.dto

data class ScriptKey(
    val scriptId: String,
    val shardId: Int? = null,
)
