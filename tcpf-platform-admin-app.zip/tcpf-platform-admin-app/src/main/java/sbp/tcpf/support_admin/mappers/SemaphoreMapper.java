package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.routing.api.v1_0.client.model.BucketRange;
import sbp.tcpf.routing.api.v1_0.client.model.Cluster;
import sbp.tcpf.support_admin.model.BucketRangeUpdate;
import sbp.tcpf.support_admin.model.Semaphore;
import sbp.tcpf.support_admin.utils.DateTimeUtils;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING, uses = {
        ClusterStateMapper.class,
        DateTimeUtils.class,
})
public interface SemaphoreMapper {

    sbp.tcpf.routing.api.v1_0.client.model.BucketRangeUpdate convert(BucketRangeUpdate bucketRange);

    @InheritInverseConfiguration
    BucketRange convert(Semaphore semaphore);

    @Mapping(target = "recordsAmount", source = "entriesCount")
    @Mapping(target = "clusterKey", source = "key")
    Semaphore convert(Cluster cluster);
}
