package sbp.tcpf.support_admin.services.monitoring

import reactor.core.publisher.Flux
import sbp.tcpf.support_admin.model.IgniteType
import sbp.tcpf.support_admin.model.Monitoring

interface IgniteMonitoringSource {
    val type: IgniteType

    fun load(): Flux<Monitoring>
}
