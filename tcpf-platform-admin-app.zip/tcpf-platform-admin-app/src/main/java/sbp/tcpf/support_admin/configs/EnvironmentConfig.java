package sbp.tcpf.support_admin.configs;

import sbp.tcpf.support_admin.configs.properties.EnvironmentProperties;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties(EnvironmentProperties.class)
public class EnvironmentConfig {
}