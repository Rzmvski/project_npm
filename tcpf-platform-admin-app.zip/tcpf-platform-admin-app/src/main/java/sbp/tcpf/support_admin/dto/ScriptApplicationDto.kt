package sbp.tcpf.support_admin.dto

import sbp.tcpf.support_admin.model.ApplicationStatus
import sbp.tcpf.support_admin.model.Restrictions
import sbp.tcpf.support_admin.services.request.dto.ScriptKey
import java.time.LocalDateTime

data class ScriptApplicationDto(
    var location: ScriptKey,
    var jiraId: String? = null,
    var scriptBody: String? = null,
    var restrictions: Restrictions? = null,
    var created: LocalDateTime? = null,
    var createdBy: String? = null,
    var executedBy: String? = null,
    var resolvedBy: String? = null,
    var resolvedAt: LocalDateTime? = null,
    val status: ApplicationStatus? = ApplicationStatus.PENDING,
) {
    fun withExecutedBy(executedBy: String): ScriptApplicationDto {
        return this.copy(executedBy = executedBy)
    }
}
