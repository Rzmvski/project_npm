package sbp.tcpf.support_admin.dto;

import org.jetbrains.annotations.Nullable;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

public record FeatureTargetDto(
        Type type,
        @Nullable String module,
        List<String> nodeKeys
) implements Serializable {

    public enum Type {
        DIRECT,
        NODE,
        SHARD
    }

    public List<FeatureLocation> locations() {
        if (Objects.equals(type, Type.DIRECT)) {
            return List.of(new FeatureLocation(module, null));
        }

        return nodeKeys.stream()
                       .map(node -> new FeatureLocation(module, node))
                       .toList();
    }
}
