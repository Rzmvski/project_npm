package sbp.tcpf.support_admin.validators;

import sbp.tcpf.support_admin.exceptions.ValidationException;
import sbp.tcpf.support_admin.model.CreateScriptApplicationRequest;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindException;
import lombok.RequiredArgsConstructor;

@Aspect
@Component
@RequiredArgsConstructor
public class ScriptValidationAspect {

    private final ScriptValidator validator;

    @Pointcut("execution(* sbp.tcpf.support_admin.controllers.*.*(..))")
    public void controllerMethods() {
    }

    @Before("controllerMethods() && args(application)")
    public void validate(CreateScriptApplicationRequest application) {
        var bindingResult = new BindException(application, "application");
        validator.validate(application, bindingResult);
        if (bindingResult.hasErrors()) {
            throw new ValidationException(String.format("Validation failed: %s", bindingResult.getAllErrors()));
        }
    }
}
