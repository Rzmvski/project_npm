package sbp.tcpf.support_admin.services.lock

import org.springframework.stereotype.Component
import sbp.tcpf.support_admin.configs.properties.CuratorLockProperties
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException
import java.util.concurrent.locks.Lock

@Component
class CuratorLockManager(
    private val lockRegistry: LockRegistry,
    private val properties: CuratorLockProperties,
) {

    fun <T> withLock(path: String, type: LockType, action: () -> T): T {
        val lock = lockRegistry.getLockByType(type, path)

        if (!lock.tryLock(properties.timeout.toMillis(), TimeUnit.MILLISECONDS)) {
            throw TimeoutException("Could not acquire $type lock at $path within ${properties.timeout}")
        }

        return try {
            action()
        } finally {
            lock.unlock()
        }
    }

    private fun LockRegistry.getLockByType(type: LockType, path: String): Lock =
        when (type) {
            LockType.READ -> this.get(path).readLock()
            LockType.WRITE -> this.get(path).writeLock()
        }
}