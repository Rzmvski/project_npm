package sbp.tcpf.support_admin.services.request;

import sbp.tcpf.support.commons.auth.services.UserService;
import sbp.tcpf.support_admin.dto.FeatureDelta;
import sbp.tcpf.support_admin.dto.LogicalFeatureDto;
import sbp.tcpf.support_admin.entities.FeatureRequest;
import sbp.tcpf.support_admin.model.ApplicationStatus;
import sbp.tcpf.support_admin.model.FeatureConfiguration;

import org.jetbrains.annotations.Nullable;
import org.springframework.stereotype.Service;
import lombok.RequiredArgsConstructor;

import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class FeatureRequestFactory {

    private final UserService userService;

    public Optional<FeatureRequest> create(
            String requestId,
            LogicalFeatureDto desired,
            @Nullable LogicalFeatureDto existing
    ) {
        var before = configurationOf(existing);
        var after = configurationOf(desired);

        if (Objects.equals(before, after)) {
            return Optional.empty();
        }

        var delta = new FeatureDelta(before, after);

        return Optional.of(FeatureRequest.builder()
                                         .rqUid(UUID.randomUUID())
                                         .uid(requestId)
                                         .featureName(desired.key().name())
                                         .target(desired.key().target())
                                         .delta(delta)
                                         .requestStatus(ApplicationStatus.PENDING.getValue())
                                         .createdAt(LocalDateTime.now())
                                         .createdBy(userService.getUserLogin())
                                         .hot(desired.hot())
                                         .build());

    }

    private FeatureConfiguration configurationOf(@Nullable LogicalFeatureDto snapshot) {
        return snapshot == null ? null : snapshot.configuration();
    }
}
