package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.forced.replication.model.ServiceModeState;

import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;
import org.mapstruct.ValueMapping;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface ServiceModeStateMapper {

    @ValueMapping(target = MappingConstants.THROW_EXCEPTION, source = MappingConstants.ANY_REMAINING)
    ServiceModeState map(sbp.tcpf.support_admin.model.ServiceModeState state);

}
