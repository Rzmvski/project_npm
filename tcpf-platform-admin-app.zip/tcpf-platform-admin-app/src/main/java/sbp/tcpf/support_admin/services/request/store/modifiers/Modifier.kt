package sbp.tcpf.support_admin.services.request.store.modifiers

fun interface Modifier<D> {

    fun modify(data: D): D
}
