package sbp.tcpf.support_admin.configs.audit;

import org.aspectj.lang.JoinPoint
import org.aspectj.lang.ProceedingJoinPoint
import org.aspectj.lang.annotation.Around
import org.aspectj.lang.annotation.Aspect
import org.slf4j.LoggerFactory
import org.slf4j.MDC
import org.springframework.context.ApplicationEventPublisher
import org.springframework.security.core.Authentication
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.stereotype.Component
import reactor.core.publisher.Flux
import reactor.core.publisher.Mono
import sbp.tcpf.audit.api.EventParamMapper
import sbp.tcpf.audit.core.providers.ArgumentProvider
import sbp.tcpf.audit.core.services.EventParamsFactory
import sbp.tcpf.audit.core.services.EventService

/**
 * Публикует события аудита для методов, возвращающих Mono/Flux.
 *
 * Построение события повторяет поведение стандартного AnnotationAuditEventPublisher.
 * Отличается только момент публикации:
 *
 * - для обычного результата — после возврата из метода;
 * - для Mono/Flux — после терминального сигнала publisher'а.
 *
 * SecurityContext и MDC захватываются на потоке вызова и временно
 * восстанавливаются на потоке Reactor только на время формирования события аудита.
 */
@Aspect
@Component
class ReactiveAnnotationAuditEventPublisher(
    private val eventService: EventService,
    private val eventParamsFactory: EventParamsFactory,
    private val mapper: EventParamMapper,
    private val applicationEventPublisher: ApplicationEventPublisher,
    private val argumentProvider: ArgumentProvider,
) {

    @Around("@annotation(audit)")
    fun handle(
        joinPoint: ProceedingJoinPoint,
        audit: ReactiveAuditEvent,
    ): Any? {
        val callerContext = CallerContext.capture()

        val result = try {
            joinPoint.proceed()
        } catch (error: Throwable) {
            publishSafely(
                    eventName = audit.onError,
                    joinPoint = joinPoint,
                    response = error,
                    callerContext = callerContext,
            )
            throw error
        }

        return when (result) {
            is Mono<*> -> auditMono(
                    source = result,
                    audit = audit,
                    joinPoint = joinPoint,
                    callerContext = callerContext,
            )

            is Flux<*> -> auditFlux(
                    source = result,
                    audit = audit,
                    joinPoint = joinPoint,
                    callerContext = callerContext,
            )

            else -> result.also {
                publishSafely(
                        eventName = audit.onSuccess,
                        joinPoint = joinPoint,
                        response = it,
                        callerContext = callerContext,
                )
            }
        }
    }

    private fun auditMono(
        source: Mono<*>,
        audit: ReactiveAuditEvent,
        joinPoint: JoinPoint,
        callerContext: CallerContext,
    ): Mono<*> =
        source
            .doOnSuccess { response ->
                publishSafely(
                        eventName = audit.onSuccess,
                        joinPoint = joinPoint,
                        response = response,
                        callerContext = callerContext,
                )
            }
            .doOnError { error ->
                publishSafely(
                        eventName = audit.onError,
                        joinPoint = joinPoint,
                        response = error,
                        callerContext = callerContext,
                )
            }

    private fun auditFlux(
        source: Flux<*>,
        audit: ReactiveAuditEvent,
        joinPoint: JoinPoint,
        callerContext: CallerContext,
    ): Flux<*> =
        if (audit.collectResponse) {
            auditCollectingFlux(
                    source = source,
                    audit = audit,
                    joinPoint = joinPoint,
                    callerContext = callerContext,
            )
        } else {
            source
                .doOnComplete {
                    publishSafely(
                            eventName = audit.onSuccess,
                            joinPoint = joinPoint,
                            response = null,
                            callerContext = callerContext,
                    )
                }
                .doOnError { error ->
                    publishSafely(
                            eventName = audit.onError,
                            joinPoint = joinPoint,
                            response = error,
                            callerContext = callerContext,
                    )
                }
        }

    @Suppress("UNCHECKED_CAST")
    private fun auditCollectingFlux(
        source: Flux<*>,
        audit: ReactiveAuditEvent,
        joinPoint: JoinPoint,
        callerContext: CallerContext,
    ): Flux<*> {
        val flux = source as Flux<Any?>

        /*
         * Коллекция должна быть создана на каждую подписку.
         *
         * Publisher может быть подписан несколько раз, поэтому создание списка
         * непосредственно в handle() привело бы к совместному состоянию между subscriptions.
         */
        return Flux.defer {
            val response = mutableListOf<Any?>()

            flux
                .doOnNext(response::add)
                .doOnComplete {
                    publishSafely(
                            eventName = audit.onSuccess,
                            joinPoint = joinPoint,
                            response = response,
                            callerContext = callerContext,
                    )
                }
                .doOnError { error ->
                    publishSafely(
                            eventName = audit.onError,
                            joinPoint = joinPoint,
                            response = error,
                            callerContext = callerContext,
                    )
                }
        }
    }

    private fun publishSafely(
        eventName: String,
        joinPoint: JoinPoint,
        response: Any?,
        callerContext: CallerContext,
    ) {
        callerContext.runWithContext {
            runCatching {
                publish(
                        eventName = eventName,
                        joinPoint = joinPoint,
                        response = response,
                )
            }.onFailure { error ->
                /*
                 * Ошибка аудита не должна превращать уже завершившийся
                 * reactive stream в ошибочный.
                 */
                log.error(
                        "Не удалось опубликовать событие аудита '{}'",
                        eventName,
                        error,
                )
            }
        }
    }

    private fun publish(
        eventName: String,
        joinPoint: JoinPoint,
        response: Any?,
    ) {
        val requestClasses = getRequestClasses(eventName)
        val request = argumentProvider.findRequestArgs(
                joinPoint.args,
                requestClasses,
        )

        val eventInfo = eventService.getEventInfoByName(eventName)

        val params = eventParamsFactory.fillParams(
                eventInfo,
                request,
                response,
                mapper,
        )

        val event = eventService.createEvent(
                eventName,
                params,
        )

        applicationEventPublisher.publishEvent(event)
    }

    private fun getRequestClasses(eventName: String): List<Class<*>> =
        eventService.getParamsByEventName(eventName)
            .flatMap(mapper::getKeysByParam)
            .mapNotNull { it.request }
            .distinct()
            .map { Class.forName(it) }

    /**
     * Снимок ThreadLocal-контекста исходного вызова.
     *
     * Храним Authentication, а не сам SecurityContext:
     * SecurityContext — mutable-объект и его не стоит разделять между потоками.
     */
    private class CallerContext(
        private val authentication: Authentication?,
        private val mdc: Map<String, String>?,
    ) {

        fun runWithContext(action: () -> Unit) {
            val previousAuthentication =
                SecurityContextHolder.getContext().authentication

            val previousMdc = MDC.getCopyOfContextMap()

            try {
                setAuthentication(authentication)
                setMdc(mdc)

                action()
            } finally {
                setAuthentication(previousAuthentication)
                setMdc(previousMdc)
            }
        }

        companion object {

            fun capture() = CallerContext(
                    authentication = SecurityContextHolder.getContext().authentication,
                    mdc = MDC.getCopyOfContextMap(),
            )

            private fun setAuthentication(authentication: Authentication?) {
                if (authentication == null) {
                    SecurityContextHolder.clearContext()
                    return
                }

                val context = SecurityContextHolder.createEmptyContext()
                context.authentication = authentication
                SecurityContextHolder.setContext(context)
            }

            private fun setMdc(context: Map<String, String>?) {
                if (context == null) {
                    MDC.clear()
                } else {
                    MDC.setContextMap(context)
                }
            }
        }
    }

    companion object {
        private val log =
            LoggerFactory.getLogger(ReactiveAnnotationAuditEventPublisher::class.java)
    }
}
