package sbp.tcpf.support_admin.utils

import org.springframework.http.codec.ServerSentEvent
import reactor.core.publisher.Flux
import reactor.core.publisher.Mono
import java.time.Duration
import java.util.*

fun <T> T?.toOptional() = this.let { Optional.ofNullable(it) }

fun <T> T.toMono() = Mono.justOrEmpty(this)

fun <T : Any> Mono<T>.toSse() = this.map { it.toServerSentEvent() }

fun <T : Any> Flux<T>.toSse() = this
    .publish { source ->
        val events = source.map { it.toServerSentEvent() }
        val heartbeat = Flux
            .interval(Duration.ofSeconds(1))
            .takeUntilOther(events.ignoreElements())
            .map {
                ServerSentEvent.builder<T>()
                    .comment("keep-alive")
                    .build()
            }

        events.mergeWith(heartbeat)
    }

private fun <T : Any> T.toServerSentEvent(
    eventName: String? = null,
): ServerSentEvent<T> {
    return ServerSentEvent.builder<T>(this)
        .build()
}
