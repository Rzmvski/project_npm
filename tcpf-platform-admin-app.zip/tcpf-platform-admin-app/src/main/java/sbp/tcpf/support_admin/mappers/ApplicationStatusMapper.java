package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.script.engine.async.model.Status;
import sbp.tcpf.support_admin.model.ApplicationStatus;

import org.mapstruct.Mapper;
import org.mapstruct.ValueMapping;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING)
public interface ApplicationStatusMapper {

    @ValueMapping(target = "WORKS", source = "QUEUED")
    @ValueMapping(target = "ERROR", source = "FAILED")
    ApplicationStatus map(Status executionStatus);
}
