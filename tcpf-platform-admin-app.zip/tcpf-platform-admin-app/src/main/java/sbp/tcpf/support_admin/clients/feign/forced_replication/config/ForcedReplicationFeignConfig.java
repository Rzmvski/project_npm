package sbp.tcpf.support_admin.clients.feign.forced_replication.config;

import sbp.tcpf.forced.replication.model.OperationResponse;
import sbp.tcpf.support_admin.configs.decoders.ExternalServiceErrorDecoder;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.context.annotation.Bean;

import feign.codec.ErrorDecoder;

public class ForcedReplicationFeignConfig {

    @Bean
    public ErrorDecoder replicaErrorDecoder(ObjectMapper objectMapper) {
        return ExternalServiceErrorDecoder.of(objectMapper, OperationResponse.class, OperationResponse::getDescription);
    }
}
