package sbp.tcpf.support_admin.configs.decoders;

import sbp.tcpf.support_admin.exceptions.ExternalServiceException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;

import java.util.function.Function;

import static feign.FeignException.errorStatus;

import feign.FeignException;
import feign.Response;
import feign.codec.ErrorDecoder;

@RequiredArgsConstructor(staticName = "of")
public final class ExternalServiceErrorDecoder<T> implements ErrorDecoder {

    private final ObjectMapper objectMapper;
    private final Class<T> errorClass;
    private final Function<T, String> messageExtractor;

    @Override
    public Exception decode(String methodKey, Response response) {
        FeignException exception = errorStatus(methodKey, response);
        var content = exception.contentUTF8();
        try {
            T error = objectMapper.readValue(content, errorClass);
            String message = messageExtractor.apply(error);

            return new ExternalServiceException(
                    exception.status(),
                    message,
                    exception.request()
            );
        } catch (JsonProcessingException e) {
            return exception;
        }
    }
}
