package sbp.tcpf.support_admin.configs;

import sbp.tcpf.support_admin.configs.feign.ReactiveFeignCollectionArgumentPostProcessor;
import sbp.tcpf.support_admin.configs.feign.ReactiveFeignContract;

import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.cloud.openfeign.AnnotatedParameterProcessor;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.format.support.FormattingConversionService;

import java.util.List;

import feign.Contract;
import feign.slf4j.Slf4jLogger;
import reactivefeign.spring.config.EnableReactiveFeignClients;

@Configuration
@EnableReactiveFeignClients(basePackages = "sbp.tcpf.support_admin.clients")
@EnableFeignClients(basePackages = "sbp.tcpf.support_admin.clients")
public class FeignConfig {

    @Bean
    public Slf4jLogger slf4jLogger() {
        return new Slf4jLogger();
    }

    @Bean
    public Contract reactiveFeignContract(
            List<AnnotatedParameterProcessor> parameterProcessors,
            FormattingConversionService conversionService
    ) {
        return new ReactiveFeignContract(parameterProcessors, conversionService);
    }

    @Bean
    public static BeanPostProcessor reactiveFeignCollectionArgumentPostProcessor() {
        return new ReactiveFeignCollectionArgumentPostProcessor();
    }
}
