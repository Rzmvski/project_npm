package sbp.tcpf.support_admin.entities

import java.io.Serializable

data class PartitionKey(
        val id: Long? = null,
        val bucketHash: Int? = null,
) : Serializable
