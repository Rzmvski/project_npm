package sbp.tcpf.support_admin.clients.feign.replica_monitor;

import sbp.tcpf.replica.monitor.api.mass.MassSpringServer;
import sbp.tcpf.support_admin.clients.feign.replica_monitor.config.ReplicaMonitorFeignConfig;

import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(
        name = "ReplicaMonitor",
        url = "${tcpf-platform-admin-app.tcpf-replica-monitor-app.uri}",
        primary = false,
        configuration = ReplicaMonitorFeignConfig.class
)
public interface ReplicaMonitorApiClient extends MassSpringServer {
}
