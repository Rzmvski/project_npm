package sbp.tcpf.support_admin.services.request.store.aggregators

import org.springframework.stereotype.Component
import sbp.tcpf.support_admin.dto.ScriptApplicationDto
import sbp.tcpf.support_admin.mappers.ScriptDbEntityMapper

@Component
class ScriptDataAggregator(
    private val scriptDbEntityMapper: ScriptDbEntityMapper,
) : Aggregator<ScriptApplicationDto> {

    override fun aggregate(data: List<ScriptApplicationDto>): List<ScriptApplicationDto> {
        return data
            .groupBy { it.location.scriptId }
            .map { (_, group) ->
                group.reduce { acc, application ->
                    scriptDbEntityMapper.update(application, acc)
                    return@reduce acc
                }
            }
    }
}
