package sbp.tcpf.support_admin.configs;

import sbp.tcpf.coordination.discovery.ApplicationInstanceInfo;
import sbp.tcpf.os.commons.config.ModuleProperties;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.validation.beanvalidation.MethodValidationPostProcessor;
import org.springframework.web.client.RestTemplate;
import lombok.extern.slf4j.Slf4j;

/**
 * Настройка бинов для отработки запросов от "Транзакционного кошелька".
 */
@Slf4j
@Configuration
public class AppConfig {

    public AppConfig() {
        log.info("Start module");
    }

    @Bean
    public ApplicationInstanceInfo applicationInstanceInfo(ModuleProperties moduleProperties) {
        return new ApplicationInstanceInfo(moduleProperties.getModuleId());
    }

    @Bean
    public LocalValidatorFactoryBean validator() {
        return new LocalValidatorFactoryBean();
    }

    @Bean
    public MethodValidationPostProcessor methodValidationPostProcessor() {
        return new MethodValidationPostProcessor();
    }

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}
