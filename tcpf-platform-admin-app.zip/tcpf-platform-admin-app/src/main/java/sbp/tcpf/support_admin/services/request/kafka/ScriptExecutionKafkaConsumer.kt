package sbp.tcpf.support_admin.services.request.kafka

import io.micrometer.core.annotation.Timed
import org.apache.kafka.clients.consumer.ConsumerRecords
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.kafka.annotation.KafkaListener
import org.springframework.kafka.support.KafkaHeaders
import org.springframework.messaging.handler.annotation.Header
import org.springframework.messaging.handler.annotation.Payload
import org.springframework.stereotype.Component
import reactor.core.publisher.Flux
import reactor.core.publisher.Mono
import sbp.tcpf.script.engine.async.model.ExecutionEvent
import sbp.tcpf.script.engine.async.model.ExecutionLogEvent
import sbp.tcpf.support_admin.mappers.ApplicationStatusMapper
import sbp.tcpf.support_admin.services.request.dto.ScriptKey
import sbp.tcpf.support_admin.services.request.execution.ExecutionContextManager
import sbp.tcpf.support_admin.services.request.execution.ExecutionLocationResolver
import sbp.tcpf.support_admin.services.request.store.CompositeScriptDataStore

@Component
class ScriptExecutionKafkaConsumer(
    private val applicationStatusMapper: ApplicationStatusMapper,
    private val executionContextManager: ExecutionContextManager,
    private val locationResolver: ExecutionLocationResolver,
    private val dataStore: CompositeScriptDataStore,
) {

    @Timed("kafka.execution.status.event.listener")
    @KafkaListener(
            topics = ["\${tcpf-platform-admin-app.script-service.kafka-topics.statuses}"],
    )
    fun consumeStatus(
        @Header(KafkaHeaders.RECEIVED_KEY) executionId: String,
        @Payload statusEvent: ExecutionEvent,
    ): Mono<Void> {
        log.debug("Received status event for execution ID: {}, status: {}", executionId, statusEvent.status)
        val status = applicationStatusMapper.map(statusEvent.status)
        val shardId = locationResolver.resolve(executionId)
        val scriptKey = ScriptKey(executionId, shardId)

        return Mono.fromRunnable {
            dataStore.changeStatus(scriptKey, status)
        }
    }

    @Timed("kafka.execution.log.batch.listener")
    @KafkaListener(
            topics = ["\${tcpf-platform-admin-app.script-service.kafka-topics.logs}"],
            batch = "true"
    )
    fun consumeLogs(
        records: ConsumerRecords<String, ExecutionLogEvent>,
    ): Mono<Void> {
        log.debug("Received log batch with size: {}, from partitions: {}", records.count(), records.partitions())

        return Flux
            .fromIterable(records)
            .groupBy { it.key() }
            .flatMap { group ->
                group
                    .collectList()
                    .flatMap { events ->
                        val executionId = group.key()
                        val shardId = locationResolver.resolve(executionId)
                        val aggregatedLog = buildString {
                            events.forEach { append(it.value().message) }
                        }
                        val scriptKey = ScriptKey(executionId, shardId)

                        log.debug("Received log event for execution ID: {}, log message: {}", executionId, aggregatedLog)

                        Mono.fromRunnable<Unit> {
                            dataStore.saveLogs(scriptKey, aggregatedLog)
                        }
                    }
            }
            .then()
    }

    companion object {
        private val log: Logger = LoggerFactory.getLogger(ScriptExecutionKafkaConsumer::class.java)
    }
}
