package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.ff4j.admin.domain.TcpfFeature;
import sbp.tcpf.support_admin.model.FeatureStatistics;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface FeatureStatisticsMapper {

    @Mapping(target = "lastCallDate", source = "lastUsageDate")
    @Mapping(target = "callAmount", source = "hitCount")
    FeatureStatistics convert(TcpfFeature feature);
}
