package sbp.tcpf.support_admin.dto;

import java.io.Serializable;

public record FeatureLocation(
        String module,
        String node
) implements Serializable {
    public boolean hasModule() {
        return module != null;
    }

    public boolean hasNode() {
        return node != null;
    }
}
