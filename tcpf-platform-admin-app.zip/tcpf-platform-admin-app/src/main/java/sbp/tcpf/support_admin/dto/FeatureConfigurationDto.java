package sbp.tcpf.support_admin.dto;

import org.ff4j.core.FlippingStrategy;
import org.ff4j.property.Property;

import java.util.Map;

public record FeatureConfigurationDto(
        boolean enable,
        String description,
        FlippingStrategy flippingStrategy,
        Map<String, Property<?>> customProperties
) {
}
