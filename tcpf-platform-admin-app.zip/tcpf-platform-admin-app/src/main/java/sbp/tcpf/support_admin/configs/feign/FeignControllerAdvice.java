package sbp.tcpf.support_admin.configs.feign;

import sbp.tcpf.support_admin.model.ErrorResponse;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;
import java.util.Optional;

import feign.FeignException;
import feign.Request;
import jakarta.servlet.http.HttpServletRequest;

@RestControllerAdvice
public class FeignControllerAdvice {

    @ExceptionHandler(FeignException.class)
    public ResponseEntity<ErrorResponse> handleFeignException(FeignException exception, HttpServletRequest request) {
        var path = Optional.ofNullable(exception.request())
                           .map(Request::url)
                           .orElseGet(request::getPathInfo);

        return ResponseEntity
                .status(exception.status())
                .body(ErrorResponse.builder()
                                   .status(exception.status())
                                   .message(exception.getMessage())
                                   .path(path)
                                   .timestamp(LocalDateTime.now())
                                   .build()
                );
    }
}
