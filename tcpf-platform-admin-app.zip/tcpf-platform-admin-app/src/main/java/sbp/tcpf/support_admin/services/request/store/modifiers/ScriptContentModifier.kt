package sbp.tcpf.support_admin.services.request.store.modifiers

import org.springframework.stereotype.Component
import sbp.tcpf.support_admin.configs.properties.ResolveRequestServiceProperties
import sbp.tcpf.support_admin.entities.ScriptRequest

@Component
class ScriptContentModifier(
    private val properties: ResolveRequestServiceProperties,
) : Modifier<ScriptRequest> {

    override fun modify(data: ScriptRequest): ScriptRequest {
        if (properties.dbPersist) {
            data.content = null
        }
        return data
    }
}
