package sbp.tcpf.support_admin.services.monitoring.impl

import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.stereotype.Service
import reactor.core.publisher.Flux
import sbp.tcpf.support_admin.model.IgniteType
import sbp.tcpf.support_admin.model.Monitoring
import sbp.tcpf.support_admin.services.monitoring.IgniteMonitoringManagement
import sbp.tcpf.support_admin.services.monitoring.IgniteMonitoringSource

@Service
@Qualifier("IGNITE")
class IgniteMonitoringManagementImpl(
    private val igniteMonitoringSources: List<IgniteMonitoringSource>,
) : IgniteMonitoringManagement {

    private val sourcesByType = igniteMonitoringSources.associateBy { it.type }

    override fun getMonitoringByType(igniteType: IgniteType): Flux<Monitoring> {
        return when (igniteType) {
            IgniteType.ALL -> loadAllMonitoring()
            else -> loadMonitoringByType(igniteType)
        }
    }

    private fun loadAllMonitoring(): Flux<Monitoring> {
        return Flux
            .fromIterable(sourcesByType.values)
            .flatMap { source -> source.load() }
    }

    private fun loadMonitoringByType(igniteType: IgniteType): Flux<Monitoring> {
        val source = sourcesByType[igniteType]
            ?: throw IllegalArgumentException("No monitoring source found for $igniteType")
        return source.load()
    }
}
