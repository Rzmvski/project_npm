package sbp.tcpf.support_admin.services.request

import org.apache.commons.lang3.SerializationUtils
import org.springframework.stereotype.Service
import sbp.tcpf.support_admin.configs.properties.ResolveRequestServiceProperties
import sbp.tcpf.support_admin.entities.AbstractRequest
import java.lang.reflect.Field
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.spec.SecretKeySpec

@Service
class RequestCryptoService<T: AbstractRequest>(
    private val properties: ResolveRequestServiceProperties,
) {

    private val encoder = Base64.getEncoder()
    private val decoder = Base64.getDecoder()

    fun encrypt(request: T): T {
        return transform(
            request,
            Cipher.ENCRYPT_MODE,
            { encoder.encode(it.toByteArray(StandardCharsets.UTF_8)) },
            encoder::encodeToString
        )
    }

    fun decrypt(request: T): T {
        return transform(
            request,
            Cipher.DECRYPT_MODE,
            decoder::decode
        ) { String(decoder.decode(it), StandardCharsets.UTF_8) }
    }

    private fun transform(
        request: T,
        mode: Int,
        preProcessor: (String) -> ByteArray,
        postProcessor: (ByteArray) -> String,
    ): T {
        val requestClone = SerializationUtils.clone(request)
        for (fieldName in properties.encryptedFields) {
            val field = findField(request::class.java, fieldName)
            val fieldValue = field[request]
            if (fieldValue != null) {
                val transformedValue = processCipher(fieldValue, request.path, mode, preProcessor)
                field[requestClone] = postProcessor(transformedValue)
            }
        }
        return requestClone
    }

    private fun findField(clazz: Class<*>, fieldName: String): Field {
        return generateSequence(clazz) { it.superclass }
            .flatMap { it.declaredFields.asSequence() }
            .find { it.name == fieldName }
            ?.apply { isAccessible = true }
            ?: throw NoSuchFieldException()
    }

    private fun processCipher(value: Any, path: String, mode: Int, preProcessor: (String) -> ByteArray): ByteArray {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(mode, generateKey(path))
        return cipher.doFinal(preProcessor(value.toString()))
    }

    private fun generateKey(path: String): SecretKey {
        val key = MessageDigest.getInstance(HASH_ALGORITHM)
            .digest(path.toByteArray(StandardCharsets.UTF_8))
        return SecretKeySpec(key, ALGORITHM)
    }

    companion object {
        private const val ALGORITHM = "AES"
        private const val TRANSFORMATION = "AES/ECB/PKCS5Padding"
        private const val HASH_ALGORITHM = "SHA256"
    }
}
