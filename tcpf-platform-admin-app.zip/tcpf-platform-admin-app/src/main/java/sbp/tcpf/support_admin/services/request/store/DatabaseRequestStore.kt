package sbp.tcpf.support_admin.services.request.store

import jakarta.persistence.EntityManager
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.util.unit.DataSize
import sbp.tcpf.routing.client.jdbc.transaction.TxDefinition
import sbp.tcpf.support_admin.configs.properties.ResolveRequestServiceProperties
import sbp.tcpf.support_admin.dto.ScriptApplicationDto
import sbp.tcpf.support_admin.entities.RequestEntity
import sbp.tcpf.support_admin.mappers.RequestMapper
import sbp.tcpf.support_admin.mappers.RequestStatusMapper
import sbp.tcpf.support_admin.model.ApplicationStatus
import sbp.tcpf.support_admin.repositories.impl.DbRequestRepository
import sbp.tcpf.support_admin.services.ShardService
import sbp.tcpf.support_admin.services.request.RequestType
import sbp.tcpf.support_admin.services.request.dto.ScriptKey
import sbp.tcpf.support_admin.wrappers.SafeUnitOfWorkOperations
import java.util.concurrent.Callable

class DatabaseRequestStore(
    private val mapper: RequestMapper<ScriptApplicationDto, RequestEntity>,
    private val properties: ResolveRequestServiceProperties,
    private val uow: SafeUnitOfWorkOperations,
    private val shardService: ShardService,
    private val repository: DbRequestRepository,
    private val statusMapper: RequestStatusMapper,
) : RequestDataStore<ScriptApplicationDto, String, ScriptKey, RequestEntity> {

    companion object {
        val log: Logger = LoggerFactory.getLogger(DatabaseRequestStore::class.java)
        val type: RequestType = RequestType.SCRIPT_REQUEST
    }

    override val storeType: StoreType = StoreType.SECONDARY

    override fun findByKey(key: String): ScriptApplicationDto? {
        return uow
            .safeCallOnActiveNodes("searching request by id") { repository.findByKeyAndType(key, type) }
            .firstOrNull()
            ?.let { mapper.toDto(it) }
    }

    override fun loadByKeys(keys: Iterable<String>): List<ScriptApplicationDto> {
        return uow
            .safeCallOnActiveNodes("loading requests by ids") { repository.loadByKeysAndType(keys, type) }
            .flatten()
            .map { mapper.toDto(it) }
    }

    override fun loadAll(): List<ScriptApplicationDto> {
        return uow
            .safeCallOnActiveNodes("loading requests") { repository.loadByType(type) }
            .flatten()
            .map { mapper.toDto(it) }
    }

    override fun save(application: ScriptApplicationDto): ScriptApplicationDto {
        val entity = mapper.toEntity(application)
        val requestShardId = properties.generalRequestShard

        return uow
            .callOnActiveNode("save request", requestShardId) { _, nodeKey ->
                log.debug("saved request {} on node {}", entity, nodeKey)
                return@callOnActiveNode repository.save(entity)
            }
            .let { application }
    }

    override fun resolve(
        location: ScriptKey,
        status: ApplicationStatus,
        resolver: String,
    ): ScriptApplicationDto {
        return update(location) {
            val requestStatus = statusMapper.map(status)

            statusId = requestStatus.id
            approverLogin = resolver

            return@update UpdateResult.Updated
        }
    }

    override fun changeStatus(location: ScriptKey, status: ApplicationStatus): ScriptApplicationDto {
        return update(location) {
            val requestStatus = statusMapper.map(status)

            statusId = requestStatus.id

            return@update UpdateResult.Updated
        }
    }

    override fun execute(location: ScriptKey, executor: String): ScriptApplicationDto {
        return update(location) {
            val requestStatus = statusMapper.map(ApplicationStatus.WORKS)

            statusId = requestStatus.id
            executorLogin = executor

            return@update UpdateResult.Updated
        }
    }

    private fun String.byteSize() = this.toByteArray().size

    override fun appendLog(location: ScriptKey, maxLogSize: DataSize, logMessage: String) {
        update(location) {
            val currentLogs = rsData.orEmpty()

            val logSize = logMessage.byteSize()
            val currentLogsSize = currentLogs.byteSize()

            if (logSize + currentLogsSize > maxLogSize.toBytes()) {
                log.warn(
                        "skipped append log for script with id {}: logs exceeded {} KB",
                        location.scriptId,
                        maxLogSize.toKilobytes()
                )

                return@update UpdateResult.Skipped
            }

            val appendedLogs = currentLogs.plus(logMessage)

            rsData = appendedLogs

            return@update UpdateResult.Updated
        }
    }

    override fun getLogs(key: String): String? {
        return uow
            .safeCallOnActiveNodes("searching request by id") {
                val request = repository.findByKeyAndType(key, type)

                return@safeCallOnActiveNodes request?.rsData
            }
            .firstOrNull()
    }

    override fun getScriptData(key: String): String? {
        return uow
            .safeCallOnActiveNodes("searching request by id") {
                val request = repository.findByKeyAndType(key, type)

                return@safeCallOnActiveNodes request?.rqData
            }
            .firstOrNull()
    }

    private fun update(location: ScriptKey, updateBlock: RequestEntity.() -> UpdateResult): ScriptApplicationDto {
        val (key, shardId) = location

        requireNotNull(shardId) {
            "Shard ID must not be null for request: $key"
        }

        return uow
            .callOnActiveNode("update request", shardId) { _, nodeKey ->
                val entity = repository.findByKeyAndType(key, RequestType.SCRIPT_REQUEST)
                    ?: throw IllegalStateException("Oops, request by key $key not found")

                when (entity.updateBlock()) {
                    UpdateResult.Updated -> {
                        repository.save(entity)
                        log.debug("updated request {} on node {}", entity, nodeKey)
                    }

                    UpdateResult.Skipped -> {
                        log.debug("skipped update request {} on node {}", entity, nodeKey)
                    }
                }

                return@callOnActiveNode entity
            }
            .let { entity -> mapper.toDto(entity) }
    }

    private fun <T> SafeUnitOfWorkOperations.callOnActiveNode(operationName: String, shardId: Int, operation: (EntityManager, String) -> T): T {
        return shardService.getActiveNodeByShardId(shardId).key
            .let { nodeKey ->
                this.callOnNodeDefault(operationName, nodeKey, TxDefinition.DEFAULT.definition) { em ->
                    operation(em, nodeKey)
                }
            }
    }

    private fun <T> SafeUnitOfWorkOperations.safeCallOnActiveNodes(operationName: String, operation: Callable<T>): List<T> {
        return shardService.getActiveNodes()
            .collectList()
            .block()
            .orEmpty()
            .map { node -> node.key }
            .mapNotNull { nodeKey ->
                this.tryCallOnNode(operationName, nodeKey) { operation.call() }
            }
    }
}
