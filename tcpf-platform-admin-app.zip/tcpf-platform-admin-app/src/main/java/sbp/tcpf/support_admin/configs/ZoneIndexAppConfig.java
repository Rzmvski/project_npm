package sbp.tcpf.support_admin.configs;

import sbp.tcpf.os.commons.config.ModuleProperties;
import sbp.tcpf.os.commons.grpc.MessageSender;
import sbp.tcpf.os.commons.grpc.MessageSenderBlockingImpl;
import sbp.tcpf.os.commons.grpc.StubCreator;
import sbp.tcpf.os.commons.grpc.StubFactory;
import sbp.tcpf.routing.index.info.api.RoutingIndexInfoServiceGrpc;
import sbp.tcpf.routing.index.info.dto.RoutingIndexInfoRs;
import sbp.tcpf.routing.index.manage.api.RoutingIndexManageServiceGrpc;
import sbp.tcpf.routing.index.manage.dto.RoutingIndexManageRs;
import sbp.tcpf.support_admin.configs.properties.ZoneIndexAppProperties;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import net.devh.boot.grpc.client.channelfactory.GrpcChannelFactory;

/**
 * Конфигурационный класс, настраивающий бины для GRPC соединение с ZoneIndex App
 */
@Configuration
@EnableConfigurationProperties(ZoneIndexAppProperties.class)
public class ZoneIndexAppConfig {
    @Bean
    public StubCreator<RoutingIndexManageServiceGrpc.RoutingIndexManageServiceBlockingStub> routingIndexManageServiceBlockingStubStubCreator() {
        return RoutingIndexManageServiceGrpc::newBlockingStub;
    }

    @Bean
    public StubCreator<RoutingIndexInfoServiceGrpc.RoutingIndexInfoServiceBlockingStub> routingIndexInfoServiceBlockingStubStubCreator() {
        return RoutingIndexInfoServiceGrpc::newBlockingStub;
    }

    @Bean
    public StubFactory<RoutingIndexManageServiceGrpc.RoutingIndexManageServiceBlockingStub> routingIndexManageServiceBlockingStubStubFactory(
            ModuleProperties moduleProperties,
            StubCreator<RoutingIndexManageServiceGrpc.RoutingIndexManageServiceBlockingStub> routingIndexManageServiceBlockingStubCreator,
            GrpcChannelFactory grpcChannelFactory
    ) {
        return new StubFactory<>(grpcChannelFactory, routingIndexManageServiceBlockingStubCreator, null, moduleProperties.getClient().getMaxOpenChannels());
    }

    @Bean
    public StubFactory<RoutingIndexInfoServiceGrpc.RoutingIndexInfoServiceBlockingStub> routingIndexInfoServiceBlockingStubStubFactory(
            ModuleProperties moduleProperties,
            StubCreator<RoutingIndexInfoServiceGrpc.RoutingIndexInfoServiceBlockingStub> routingIndexInfoServiceBlockingStubStubCreator,
            GrpcChannelFactory grpcChannelFactory
    ) {
        return new StubFactory<>(grpcChannelFactory, routingIndexInfoServiceBlockingStubStubCreator, null, moduleProperties.getClient().getMaxOpenChannels());
    }

    @Bean
    public MessageSender<RoutingIndexInfoServiceGrpc.RoutingIndexInfoServiceBlockingStub, RoutingIndexInfoRs> routingIndexInfoMsgSender(
            StubFactory<RoutingIndexInfoServiceGrpc.RoutingIndexInfoServiceBlockingStub> routingIndexManageServiceBlockingStubFactory
    ) {
        return new MessageSenderBlockingImpl<>(routingIndexManageServiceBlockingStubFactory);
    }

    @Bean
    public MessageSender<RoutingIndexManageServiceGrpc.RoutingIndexManageServiceBlockingStub, RoutingIndexManageRs> routingIndexManageMsgSender(
            StubFactory<RoutingIndexManageServiceGrpc.RoutingIndexManageServiceBlockingStub> routingIndexManageServiceBlockingStubFactory
    ) {
        return new MessageSenderBlockingImpl<>(routingIndexManageServiceBlockingStubFactory);
    }
}
