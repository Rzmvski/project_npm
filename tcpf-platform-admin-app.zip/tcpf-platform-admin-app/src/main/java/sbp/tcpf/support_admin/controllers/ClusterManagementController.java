package sbp.tcpf.support_admin.controllers;

import sbp.tcpf.support_admin.api.ClusterManagementServiceApi;
import sbp.tcpf.support_admin.api.ConnectionPoolManagementServiceApi;
import sbp.tcpf.support_admin.api.MetadataManagementServiceApi;
import sbp.tcpf.support_admin.configs.audit.ReactiveAuditEvent;
import sbp.tcpf.support_admin.model.BucketRangeUpdate;
import sbp.tcpf.support_admin.model.ChangeClusterStateRequest;
import sbp.tcpf.support_admin.model.Metadata;
import sbp.tcpf.support_admin.model.Node;
import sbp.tcpf.support_admin.model.OperationResponseDto;
import sbp.tcpf.support_admin.model.Pool;
import sbp.tcpf.support_admin.model.PoolState;
import sbp.tcpf.support_admin.model.ReplicationStatusDto;
import sbp.tcpf.support_admin.model.Semaphore;
import sbp.tcpf.support_admin.model.ServiceModeStatusDto;
import sbp.tcpf.support_admin.model.Shard;
import sbp.tcpf.support_admin.model.ShardUpdate;
import sbp.tcpf.support_admin.model.UpdateServiceModeRequest;
import sbp.tcpf.support_admin.services.MetadataManagementService;
import sbp.tcpf.support_admin.services.NodeManagementService;
import sbp.tcpf.support_admin.services.PoolManagerService;
import sbp.tcpf.support_admin.services.SemaphoreManagementService;
import sbp.tcpf.support_admin.services.forced_replication.ForcedReplicationService;

import org.springframework.http.codec.ServerSentEvent;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.RestController;
import lombok.RequiredArgsConstructor;

import java.util.List;

import static sbp.tcpf.base.metrics.TcpfMetrics.SERVICE;
import static sbp.tcpf.base.metrics.TcpfMetrics.SERVICE_CALL;
import static sbp.tcpf.support_admin.utils.ConverterExtensionsKt.toSse;

import io.micrometer.core.annotation.Timed;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequiredArgsConstructor
public class ClusterManagementController implements
        ClusterManagementServiceApi,
        ConnectionPoolManagementServiceApi,
        MetadataManagementServiceApi {

    private final NodeManagementService nodeManagementService;
    private final SemaphoreManagementService semaphoreManagementService;
    private final PoolManagerService poolManagerService;
    private final MetadataManagementService metadataManagementService;
    private final ForcedReplicationService forcedReplicationService;

    @Override
    @Timed(value = SERVICE_CALL, extraTags = {SERVICE, "ClusterManagementService"})
    @ReactiveAuditEvent(onSuccess = "VIEW_SEMAPHORES_INFO", onError = "VIEW_SEMAPHORES_INFO_ERROR")
    @Secured("clusterManagementService_getSemaphore")
    public Flux<ServerSentEvent<Semaphore>> semaphoreInfo() {
        return toSse(semaphoreManagementService.getSemaphores());
    }

    @Override
    @Timed(value = SERVICE_CALL, extraTags = {SERVICE, "ClusterManagementService"})
    @ReactiveAuditEvent(onSuccess = "MANAGE_SEMAPHORE", onError = "MANAGE_SEMAPHORE_ERROR")
    @Secured("clusterManagementService_manageSemaphore")
    public Mono<Void> changeClusterState(String clusterKey, ChangeClusterStateRequest request) {
        return semaphoreManagementService.changeState(clusterKey, request);
    }

    @Override
    @Timed(value = SERVICE_CALL, extraTags = {SERVICE, "ClusterManagementService"})
    @Secured({"standInService_activatePool", "clusterManagementService_changePoolState"})
    public Mono<Void> changePoolState(String nodeKey, PoolState poolState) {
        return poolManagerService.changePoolState(nodeKey, poolState);
    }

    @Override
    @Timed(value = SERVICE_CALL, extraTags = {SERVICE, "ClusterManagementService"})
    public Flux<ServerSentEvent<Pool>> getPools() {
        return toSse(poolManagerService.getPoolActivityStates());
    }

    @Override
    @Timed(value = SERVICE_CALL, extraTags = {SERVICE, "ClusterManagementService"})
    @Secured({"standInService_activatePool", "clusterManagementService_changePoolState"})
    public Mono<ServerSentEvent<Metadata>> refreshMetadataOnNode(String nodeKey) {
        return toSse(metadataManagementService.refresh(nodeKey));
    }

    @Override
    @Timed(value = SERVICE_CALL, extraTags = {SERVICE, "ClusterManagementService"})
    @Secured("clusterManagementService_getShard")
    public ReplicationStatusDto getForcedReplication(Integer shardId) {
        return forcedReplicationService.getReplicationStatus(shardId);
    }

    @Override
    @Timed(value = SERVICE_CALL, extraTags = {SERVICE, "ClusterManagementService"})
    @Secured("clusterManagementService_getShard")
    public ServiceModeStatusDto getServiceMode() {
        return forcedReplicationService.getServiceModeStatus();
    }

    @Override
    @Timed(value = SERVICE_CALL, extraTags = {SERVICE, "ClusterManagementService"})
    @Secured("clusterManagementService_changeRanges")
    public OperationResponseDto startReplication(Integer shardId) {
        return forcedReplicationService.startReplication(shardId);
    }

    @Override
    @Timed(value = SERVICE_CALL, extraTags = {SERVICE, "ClusterManagementService"})
    @Secured("clusterManagementService_changeRanges")
    public OperationResponseDto undoReplication(Integer shardId) {
        return forcedReplicationService.undoReplication(shardId);
    }

    @Override
    @Timed(value = SERVICE_CALL, extraTags = {SERVICE, "ClusterManagementService"})
    @Secured("clusterManagementService_changeRanges")
    public OperationResponseDto updateServiceMode(UpdateServiceModeRequest request) {
        return forcedReplicationService.changeServiceMode(request.getStatus());
    }

    @Override
    @Timed(value = SERVICE_CALL, extraTags = {SERVICE, "ClusterManagementService"})
    @Secured("clusterManagementService_getShard")
    @ReactiveAuditEvent(onSuccess = "VIEW_SHARDS_INFO", onError = "VIEW_SHARDS_INFO_ERROR")
    public Flux<ServerSentEvent<Node>> getNodes() {
        return toSse(nodeManagementService.getNodes());
    }

    @Override
    public Flux<ServerSentEvent<Shard>> getShards() {
        return toSse(nodeManagementService.getShards());
    }

    @Override
    @Timed(value = SERVICE_CALL, extraTags = {SERVICE, "ClusterManagementService"})
    @ReactiveAuditEvent(onSuccess = "MANAGE_RANGES", onError = "MANAGE_RANGES_ERROR")
    @Secured("clusterManagementService_changeRanges")
    public Flux<ServerSentEvent<Shard>> updateNodesOfShardById(
            List<Integer> ids,
            ShardUpdate shardUpdate,
            String xRegion
    ) {
        return toSse(nodeManagementService.changeLoadRatio(ids, shardUpdate, xRegion));
    }

    @Override
    @Timed(value = SERVICE_CALL, extraTags = {SERVICE, "ClusterManagementService"})
    @Secured("clusterManagementService_changeRanges")
    public Flux<ServerSentEvent<Shard>> updateSemaphoresOfShardById(
            Integer id,
            BucketRangeUpdate bucketRangeUpdate,
            String xRegion
    ) {
        return toSse(nodeManagementService.changeSemaphores(id, bucketRangeUpdate, xRegion));
    }
}
