package sbp.tcpf.support_admin.entities;

import sbp.tcpf.support_admin.model.ApplicationType;
import sbp.tcpf.support_admin.validators.annotations.TwoPersonConstraint;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import org.apache.curator.utils.ZKPaths;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.io.Serializable;
import java.time.LocalDateTime;

import static sbp.tcpf.ff4j.utils.Constants.GLOBAL_FEATURE;

@Data
@TwoPersonConstraint
@SuperBuilder(toBuilder = true)
@NoArgsConstructor
@JsonIgnoreProperties(
        value = "type",
        allowSetters = true
)
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "type", visible = true)
@JsonSubTypes({
        @JsonSubTypes.Type(value = FeatureRequest.class, name = "feature"),
        @JsonSubTypes.Type(value = ScriptRequest.class, name = "script")
})
public abstract class AbstractRequest implements Serializable {
    private ApplicationType type;
    private String uid;
    private String requestStatus;
    private String createdBy;
    private LocalDateTime createdAt;
    private String resolvedBy;
    private LocalDateTime resolvedAt;
    private String requestTtl;

    @JsonIgnore
    public String getPath() {
        return ZKPaths.makePath(GLOBAL_FEATURE, this.getUid());
    }
}
