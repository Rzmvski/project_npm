package sbp.tcpf.support_admin.services

import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import reactor.core.publisher.Flux
import reactor.core.publisher.Mono
import sbp.tcpf.os.commons.config.ModuleProperties
import sbp.tcpf.routing.api.v1_0.client.model.ClusterMode
import sbp.tcpf.routing.api.v1_0.client.model.ClusterStatus
import sbp.tcpf.routing.api.v1_0.client.model.ClusterUpdate
import sbp.tcpf.support.commons.auth.services.UserService
import sbp.tcpf.support_admin.clients.feign.routing.SemaphoreClusterManagementApiClient
import sbp.tcpf.support_admin.mappers.ClusterStateMapper
import sbp.tcpf.support_admin.mappers.SemaphoreMapper
import sbp.tcpf.support_admin.model.ChangeClusterStateRequest
import sbp.tcpf.support_admin.model.Semaphore
import sbp.tcpf.support_admin.utils.toMono
import java.time.OffsetDateTime
import java.util.*

@Service
class SemaphoreManagementService(
    private val semaphoreMapper: SemaphoreMapper,
    private val clusterStateMapper: ClusterStateMapper,
    private val semaphoreManagementApiClient: SemaphoreClusterManagementApiClient,
    private val userService: UserService,
    private val moduleProperties: ModuleProperties,
) {

    fun getSemaphores(): Flux<Semaphore> {
        return semaphoreManagementApiClient.getClusters()
            .map { cluster -> semaphoreMapper.convert(cluster) }
    }

    fun changeState(clusterKey: String, request: ChangeClusterStateRequest): Mono<Void> {
        val status = clusterStateMapper.convert(request.status)
        return semaphoreManagementApiClient.updateClustersByKey(
                listOf(clusterKey),
                ClusterUpdate(status).toMono(),
                moduleProperties.moduleId,
                userService.getUserLogin(),
                UUID.randomUUID().toString(),
                OffsetDateTime.now(),
                request.restoreRanges.takeIf { status == ClusterStatus.ACTIVE },
                request.createModel.takeIf { status == ClusterStatus.ACTIVE },
        )
            .flatMap { result ->
                log.info("semaphore $clusterKey's state was changed to $status")

                if (status == ClusterStatus.INACTIVE && request.switchRanges == true) {
                    return@flatMap semaphoreManagementApiClient.newClusterModeByKey(
                            listOf(clusterKey),
                            ClusterMode(ClusterMode.ModeEnum.SWITCH).toMono(),
                            moduleProperties.moduleId,
                            userService.getUserLogin(),
                            UUID.randomUUID().toString(),
                            OffsetDateTime.now(),
                    ).doOnComplete {
                        log.info("ranges for semaphore $clusterKey was successfully switched")
                    }
                }

                return@flatMap Mono.empty()
            }
            .then()
    }

    companion object {
        val log: Logger = LoggerFactory.getLogger(SemaphoreManagementService::class.java)
    }
}
