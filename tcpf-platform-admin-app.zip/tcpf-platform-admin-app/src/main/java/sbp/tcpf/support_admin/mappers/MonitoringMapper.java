package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.support_admin.model.Monitoring;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING)
public interface MonitoringMapper {

    Monitoring convert(sbp.tcpf.routing.api.v1_0.client.model.Monitoring monitoring);

    @Mapping(target = "replicaLag", ignore = true)
    Monitoring convert(sbp.tcpf.routing.index.api.v1_0.client.model.Monitoring monitoring);
}
