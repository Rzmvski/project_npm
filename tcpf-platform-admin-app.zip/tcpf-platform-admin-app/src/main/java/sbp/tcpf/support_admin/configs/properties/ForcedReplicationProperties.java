package sbp.tcpf.support_admin.configs.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.lang.Nullable;

import java.net.URI;

@ConfigurationProperties("tcpf-platform-admin-app.tcpf-forced-replication-app")
public record ForcedReplicationProperties(
        @Nullable URI uri
) {
}
