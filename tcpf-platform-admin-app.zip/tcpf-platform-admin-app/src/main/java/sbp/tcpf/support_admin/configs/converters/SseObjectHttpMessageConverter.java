package sbp.tcpf.support_admin.configs.converters;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.jetbrains.annotations.NotNull;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.MediaType;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.http.converter.AbstractHttpMessageConverter;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Пишет одиночный объект в {@code text/event-stream} как одно SSE-событие.
 * <p>
 * Эндпоинты, возвращающие {@code Mono<T>} (или обычный объект) с {@code produces=text/event-stream},
 * Spring MVC отдаёт через {@code DeferredResult}, а не через {@code SseEmitter} — SSE-фрейминг
 * в этом случае никто не делает, и штатные конвертеры отказываются писать POJO в
 * {@code text/event-stream}, отдавая 500 {@code HttpMessageNotWritableException}. Этот конвертер
 * закрывает пробел: формат на проводе остаётся SSE, то есть UI и сгенерированные
 * {@code *ApiSse}-клиенты работают одинаково и для потоков, и для одиночных объектов.
 * <p>
 * Ответы-массивы ({@code Flux<T>}) идут через {@code SseEmitter} и этого конвертера не касаются —
 * см. {@link #canWrite(Class, MediaType)}.
 */
@Component
public class SseObjectHttpMessageConverter extends AbstractHttpMessageConverter<Object> {

    private static final byte[] DATA_PREFIX = "data:".getBytes(StandardCharsets.UTF_8);
    private static final byte[] EVENT_SUFFIX = "\n\n".getBytes(StandardCharsets.UTF_8);

    private final ObjectMapper objectMapper;

    public SseObjectHttpMessageConverter(ObjectMapper objectMapper) {
        super(StandardCharsets.UTF_8, MediaType.TEXT_EVENT_STREAM);
        this.objectMapper = objectMapper;
    }

    @Override
    protected boolean supports(@NotNull Class<?> clazz) {
        return ServerSentEvent.class.isAssignableFrom(clazz);
    }

    /**
     * Только явно запрошенный {@code text/event-stream}.
     * <p>
     * При {@code mediaType == null} конвертер выбирать нельзя: с таким аргументом конвертеры
     * перебирает {@code SseEmitter}, когда пишет данные очередного события. Если разрешить
     * себя здесь, префикс {@code data:} допишется второй раз поверх фрейминга эмиттера.
     */
    @Override
    public boolean canWrite(@NotNull Class<?> clazz, MediaType mediaType) {
        return mediaType != null && MediaType.TEXT_EVENT_STREAM.isCompatibleWith(mediaType);
    }

    @Override
    public boolean canRead(@NotNull Class<?> clazz, MediaType mediaType) {
        return false;
    }

    @NotNull
    @Override
    protected Object readInternal(@NotNull Class<?> clazz, HttpInputMessage inputMessage) {
        throw new UnsupportedOperationException("SSE — односторонний протокол, чтение не поддерживается");
    }

    @Override
    protected void writeInternal(@NotNull Object object, HttpOutputMessage outputMessage) throws IOException {
        Object data = object instanceof ServerSentEvent<?> event
                ? event.data()
                : object;
        OutputStream body = outputMessage.getBody();
        body.write(DATA_PREFIX);

        if (data != null) {
            body.write(objectMapper.writeValueAsBytes(data));
        }

        body.write(EVENT_SUFFIX);
        body.flush();
    }
}
