package sbp.tcpf.support_admin.services

import org.springframework.stereotype.Service
import reactor.core.publisher.Mono
import sbp.tcpf.os.commons.config.ModuleProperties
import sbp.tcpf.support.commons.auth.services.UserService
import sbp.tcpf.support_admin.clients.feign.routing.MetadataManagementApiClient
import sbp.tcpf.support_admin.mappers.MetadataMapper
import sbp.tcpf.support_admin.model.Metadata
import java.time.OffsetDateTime
import java.util.*

@Service
class MetadataManagementService(
    private val metadataMapper: MetadataMapper,
    private val userService: UserService,
    private val metadataManagementApiClient: MetadataManagementApiClient,
    private val moduleProperties: ModuleProperties,
) {
    fun refresh(nodeKey: String): Mono<Metadata> {
        return metadataManagementApiClient.updateMetadataByKey(
                listOf(nodeKey),
                moduleProperties.moduleId,
                userService.getUserLogin(),
                UUID.randomUUID().toString(),
                OffsetDateTime.now(),
        )
            .map { metadataMapper.map(it) }
            .single()
    }
}
