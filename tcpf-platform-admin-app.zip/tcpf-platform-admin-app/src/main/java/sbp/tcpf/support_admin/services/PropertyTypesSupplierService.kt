package sbp.tcpf.support_admin.services

import org.ff4j.property.Property
import org.ff4j.property.PropertyInstant
import org.reflections.Reflections
import org.springframework.stereotype.Service
import java.lang.reflect.Modifier

@Service
class PropertyTypesSupplierService {

    private val reflections = Reflections(Property::class.java.packageName)

    fun getTypes(): List<String> {
        return reflections.getSubTypesOf(Property::class.java)
            .filter { !Modifier.isAbstract(it.modifiers) }
            .filter { it != PropertyInstant::class.java }
            .map { it.name }
    }
}
