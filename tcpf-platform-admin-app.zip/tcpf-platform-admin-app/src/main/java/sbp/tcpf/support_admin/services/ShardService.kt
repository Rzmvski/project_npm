package sbp.tcpf.support_admin.services

import org.springframework.stereotype.Service
import reactor.core.publisher.Flux
import sbp.tcpf.routing.api.v1_0.client.model.Node
import sbp.tcpf.routing.api.v1_0.client.model.NodeStatus
import sbp.tcpf.support_admin.clients.feign.routing.RoutingManagementApiClient
import sbp.tcpf.support_admin.exceptions.ExternalServiceException

@Service
class ShardService(
    private val routingManagementApiClient: RoutingManagementApiClient,
) {

    fun getNodes(): Flux<Node> {
        return routingManagementApiClient.getNodes(null)
    }

    fun getActiveNodes(): Flux<Node> {
        return routingManagementApiClient
            .getMostSaturatedNodes(null)
            .filter { node -> node.status == NodeStatus.WORKING }
    }

    fun getActiveNodeByShardId(shardId: Int): Node {
        return routingManagementApiClient.getMostSaturatedNodeInShard(shardId)
            .single()
            .block()
            ?: throw ExternalServiceException("no active nodes found on shard $shardId")
    }
}
