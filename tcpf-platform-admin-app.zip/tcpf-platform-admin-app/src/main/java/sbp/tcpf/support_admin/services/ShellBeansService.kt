package sbp.tcpf.support_admin.services

import org.springframework.stereotype.Service
import sbp.tcpf.support_admin.clients.feign.script_engine.ShellBeansApi
import sbp.tcpf.support_admin.mappers.ShellBeanMapper
import sbp.tcpf.support_admin.model.BeanInfo

@Service
class ShellBeansService(
    private val shellBeansApi: ShellBeansApi,
    private val shellBeanMapper: ShellBeanMapper,
) {

    fun loadBeans(): List<BeanInfo> {
        return shellBeansApi.loadBeans()
            .map { shellBeanMapper.convert(it) }
    }
}
