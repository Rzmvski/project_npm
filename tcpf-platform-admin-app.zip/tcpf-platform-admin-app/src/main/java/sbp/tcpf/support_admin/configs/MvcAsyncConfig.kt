package sbp.tcpf.support_admin.configs

import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.context.annotation.Configuration
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor
import org.springframework.web.servlet.config.annotation.AsyncSupportConfigurer
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer

@Configuration
class MvcAsyncConfig(
    @Qualifier("mvcAsyncExecutor")
    private val threadPoolTaskExecutor: ThreadPoolTaskExecutor,
) : WebMvcConfigurer {

    override fun configureAsyncSupport(configurer: AsyncSupportConfigurer) {
        configurer.setTaskExecutor(threadPoolTaskExecutor)
    }
}
