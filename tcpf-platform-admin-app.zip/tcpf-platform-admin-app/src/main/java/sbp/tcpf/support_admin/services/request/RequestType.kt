package sbp.tcpf.support_admin.services.request

enum class RequestType(val id: Long) {
    FEATURE_REQUEST(42L),
    SCRIPT_REQUEST(43L);

    companion object {
        @JvmStatic
        fun getById(id: Long): RequestType? {
            return RequestType.values().find { type -> type.id == id }
        }
    }
}
