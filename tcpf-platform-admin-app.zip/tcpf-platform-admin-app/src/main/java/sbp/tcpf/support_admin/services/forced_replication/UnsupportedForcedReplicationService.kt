package sbp.tcpf.support_admin.services.forced_replication

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean
import org.springframework.stereotype.Service
import sbp.tcpf.support_admin.model.OperationResponseDto
import sbp.tcpf.support_admin.model.ReplicationStatusDto
import sbp.tcpf.support_admin.model.ServiceModeState
import sbp.tcpf.support_admin.model.ServiceModeStatusDto

@Service
@ConditionalOnMissingBean(DefaultForcedReplicationService::class)
class UnsupportedForcedReplicationService : ForcedReplicationService {

    override fun getReplicationStatus(shardId: Int): ReplicationStatusDto {
        throw UnsupportedOperationException()
    }

    override fun getServiceModeStatus(): ServiceModeStatusDto {
        return ServiceModeStatusDto().apply {
            status = ServiceModeState.UNSUPPORTED
        }
    }

    override fun startReplication(shardId: Int): OperationResponseDto {
        throw UnsupportedOperationException()
    }

    override fun undoReplication(shardId: Int): OperationResponseDto {
        throw UnsupportedOperationException()
    }

    override fun changeServiceMode(serviceModeState: ServiceModeState): OperationResponseDto {
        throw UnsupportedOperationException()
    }
}
