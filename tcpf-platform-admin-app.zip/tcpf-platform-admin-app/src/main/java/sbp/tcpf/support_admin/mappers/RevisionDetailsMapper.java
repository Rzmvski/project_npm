package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.replica.monitor.api.mass.model.RevisionTable;
import sbp.tcpf.support_admin.model.RevisionDetails;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface RevisionDetailsMapper {

    @Mapping(target = "id", source = "revisionId")
    @Mapping(target = "table", source = "table.tableName")
    RevisionDetails convert(RevisionTable table);
}
