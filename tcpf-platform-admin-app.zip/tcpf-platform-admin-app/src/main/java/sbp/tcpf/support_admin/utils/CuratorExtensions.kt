package sbp.tcpf.support_admin.utils

import org.apache.curator.framework.recipes.queue.DistributedDelayQueue
import org.apache.zookeeper.data.Stat
import sbp.tcpf.support_admin.utils.DateTimeUtils.TIMEZONE
import java.time.Instant
import java.time.LocalDateTime

fun Stat.createdAt(): LocalDateTime {
    return LocalDateTime.ofInstant(
            Instant.ofEpochMilli(this.ctime),
            TIMEZONE
    )
}

fun <T> DistributedDelayQueue<T>.put(item: T, delay: LocalDateTime) {
    this.put(item, delay.toEpochMillis())
}

private fun LocalDateTime.toEpochMillis(): Long {
    return this.atZone(TIMEZONE)
        .toInstant()
        .toEpochMilli()
}
