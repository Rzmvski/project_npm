package sbp.tcpf.support_admin.clients.feign.script_engine.config;

import sbp.tcpf.script.engine.model.ErrorResponse;
import sbp.tcpf.support_admin.configs.decoders.ExternalServiceErrorDecoder;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.context.annotation.Bean;

import feign.codec.ErrorDecoder;

public class ScriptEngineFeignConfig {

    @Bean
    public ErrorDecoder scriptEngineErrorDecoder(ObjectMapper objectMapper) {
        return ExternalServiceErrorDecoder.of(objectMapper, ErrorResponse.class, ErrorResponse::getMessage);
    }
}
