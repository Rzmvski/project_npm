package sbp.tcpf.support_admin.configs

import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.cache.annotation.EnableCaching
import org.springframework.context.annotation.Configuration
import sbp.tcpf.support_admin.configs.properties.CoffeeCacheProperties

@Configuration
@EnableCaching
@EnableConfigurationProperties(CoffeeCacheProperties::class)
class CacheConfig
