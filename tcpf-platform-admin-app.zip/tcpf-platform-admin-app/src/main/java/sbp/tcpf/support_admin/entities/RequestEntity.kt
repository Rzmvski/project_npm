package sbp.tcpf.support_admin.entities

import jakarta.persistence.Column
import jakarta.persistence.Entity
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import jakarta.persistence.IdClass
import jakarta.persistence.PrePersist
import jakarta.persistence.PreUpdate
import jakarta.persistence.SequenceGenerator
import jakarta.persistence.Table
import jakarta.persistence.Version
import sbp.tcpf.support_admin.mappers.ScriptDbEntityMapper.*
import sbp.tcpf.support_admin.validators.annotations.TwoPersonConstraint
import java.time.LocalDate
import java.time.LocalDateTime

@Entity
@Table(name = "REQUEST")
@IdClass(PartitionKey::class)
@TwoPersonConstraint(
        creatorFieldName = "creatorLogin",
        resolverFieldName = "approverLogin"
)
data class RequestEntity(
    @Id
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "request_sequence_generator",
    )
    @SequenceGenerator(
            name = "request_sequence_generator",
            sequenceName = "request_seq",
            allocationSize = 1,
    )
    var id: Long? = null,

    @Id
    @Column(name = "BUCKET_HASH", nullable = false)
    var bucketHash: Int = BUCKET_HASH,

    @Column(name = "RQ_UID", nullable = false)
    var rqUid: String,

    @Column(name = "CREATOR_LOGIN")
    var creatorLogin: String? = null,

    @Column(name = "EXECUTOR_LOGIN")
    var executorLogin: String? = null,

    @Column(name = "APPROVER_LOGIN")
    var approverLogin: String? = null,

    @Column(name = "STATUS_ID", nullable = false)
    var statusId: Long,

    @Column(name = "RQ_DATA")
    var rqData: String? = null,

    @Column(name = "RS_DATA")
    var rsData: String? = null,

    @Column(name = "OPER_DATE", nullable = false)
    var operDate: LocalDate = LocalDate.EPOCH,

    @Column(name = "REQUEST_TYPE_ID", nullable = false)
    var requestTypeId: Long,

    @Column(name = "CREATED", nullable = false)
    var created: LocalDateTime = LocalDateTime.now(),

    @Column(name = "EXT_SYSTEM_ID")
    var extSystemId: Long? = ARM_ID,

    @Column(name = "CHANNEL_ID")
    var channelId: Long? = VSP_ID,

    @Column(name = "CONTRACT_ID")
    var contractId: Long? = CONTRACT_ID,

    @Column(name = "ROW_VERSION")
    @Version
    var rowVersion: Long? = null,

    @Column(name = "ROW_UPD_TIMESTAMP")
    var rowUpdTimestamp: LocalDateTime? = null,

    @Column(name = "ROW_INS_TIMESTAMP")
    var rowInsTimestamp: LocalDateTime? = null,
) {

    @PreUpdate
    fun onUpdate() {
        this.rowUpdTimestamp = LocalDateTime.now()
    }

    @PrePersist
    fun onPersist() {
        this.rowInsTimestamp = LocalDateTime.now()
        this.rowUpdTimestamp = this.rowInsTimestamp
        this.rowVersion = 1L
    }
}
