package sbp.tcpf.support_admin.configs.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.Map;

@ConfigurationProperties(prefix = "coffee-boots.cache")
public record CoffeeCacheProperties(
        Map<String, String> spec
) {
}
