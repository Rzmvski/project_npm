package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.forced.replication.model.ReplicationStatus;
import sbp.tcpf.support_admin.model.ReplicationStatusDto;
import sbp.tcpf.support_admin.utils.DateTimeUtils;

import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

@Mapper(
        componentModel = MappingConstants.ComponentModel.SPRING,
        uses = DateTimeUtils.class
)
public interface ReplicationStatusMapper {

    ReplicationStatusDto map(ReplicationStatus status);
}
