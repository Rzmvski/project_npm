package sbp.tcpf.support_admin.services.request.resolvers.feature

import org.springframework.stereotype.Component
import sbp.tcpf.support.commons.auth.services.UserService
import sbp.tcpf.support_admin.entities.FeatureRequest
import sbp.tcpf.support_admin.facades.Ff4jFacade
import sbp.tcpf.support_admin.model.ApplicationStatus
import sbp.tcpf.support_admin.services.request.resolvers.RequestResolver

@Component
class DeclineFeatureResolver(
    private val ff4jFacade: Ff4jFacade,
    private val userService: UserService,
) : RequestResolver<FeatureRequest> {

    override val status: ApplicationStatus = ApplicationStatus.DECLINE

    override fun resolve(
        request: FeatureRequest,
    ): FeatureRequest {
        val resolverLogin = userService.getUserLogin() ?: throw IllegalStateException()

        return request.resolve(
                userService.getUserLogin(),
                status.value
        )
    }
}
