package sbp.tcpf.support_admin.configs.feign;

import org.springframework.cloud.openfeign.AnnotatedParameterProcessor;
import org.springframework.cloud.openfeign.support.SpringMvcContract;
import org.springframework.core.convert.ConversionService;
import org.springframework.web.bind.annotation.PathVariable;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.Collection;
import java.util.List;

import feign.MethodMetadata;

public class ReactiveFeignContract extends SpringMvcContract {

    public ReactiveFeignContract(
            List<AnnotatedParameterProcessor> parameterProcessors,
            ConversionService conversionService
    ) {
        super(parameterProcessors, conversionService);
    }

    @Override
    public MethodMetadata parseAndValidateMetadata(Class<?> targetType, Method method) {
        MethodMetadata metadata = super.parseAndValidateMetadata(targetType, method);

        Parameter[] parameters = method.getParameters();

        for (int i = 0; i < parameters.length; i++) {
            Parameter parameter = parameters[i];

            if (parameter.isAnnotationPresent(PathVariable.class)
                    && Collection.class.isAssignableFrom(parameter.getType())) {

                metadata.indexToExpander().remove(i);
            }
        }

        return metadata;
    }
}
