package sbp.tcpf.support_admin.controllers

import io.micrometer.core.annotation.Timed
import org.springframework.http.codec.ServerSentEvent
import org.springframework.security.access.annotation.Secured
import org.springframework.web.bind.annotation.RestController
import reactor.core.publisher.Flux
import reactor.core.publisher.Mono
import sbp.tcpf.base.metrics.TcpfMetrics
import sbp.tcpf.support_admin.api.GeoBalancingManagementServiceApi
import sbp.tcpf.support_admin.model.TrafficRestrictionDto
import sbp.tcpf.support_admin.services.GeoBalancingService
import sbp.tcpf.support_admin.utils.toSse
import sbp.tcpf.support_admin.model.GeoBalancingService as GeoBalancingServiceDto

@RestController
class GeoBalancingController(
    private val geoBalancingService: GeoBalancingService,
) : GeoBalancingManagementServiceApi {

//    TODO: change it after role model update
    @Secured("userService_getPermissions")
    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "GeoBalancingService"])
    override fun createTrafficRestriction(trafficRestriction: TrafficRestrictionDto): Mono<ServerSentEvent<TrafficRestrictionDto>> {
    return geoBalancingService.createRestriction(trafficRestriction).toSse()
    }

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "GeoBalancingService"])
    override fun getDataCenters(): Flux<ServerSentEvent<String>> {
        return geoBalancingService.getDataCenters().toSse()
    }

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "GeoBalancingService"])
    override fun getGeoBalancingServices(): Flux<ServerSentEvent<GeoBalancingServiceDto>> {
        return geoBalancingService.getServices().toSse()
    }

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "GeoBalancingService"])
    override fun getTrafficRestrictionById(id: String): Mono<ServerSentEvent<TrafficRestrictionDto>> {
        return geoBalancingService.getRestrictionById(id).toSse()
    }

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "GeoBalancingService"])
    override fun getTrafficRestrictions(): Flux<ServerSentEvent<TrafficRestrictionDto>> {
        return geoBalancingService.getRestrictions().toSse()
    }

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "GeoBalancingService"])
    override fun removeTrafficRestrictionById(id: String): Mono<Void> {
        return geoBalancingService.removeRestriction(id)
    }

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "GeoBalancingService"])
    override fun updateTrafficRestriction(
        id: String,
        trafficRestriction: TrafficRestrictionDto,
    ): Mono<ServerSentEvent<TrafficRestrictionDto>> {
        return geoBalancingService.updateRestriction(id, trafficRestriction).toSse()
    }
}
