package sbp.tcpf.support_admin.services

import org.springframework.stereotype.Service
import sbp.tcpf.support.commons.auth.services.UserService
import sbp.tcpf.support_admin.entities.FeatureRequest
import sbp.tcpf.support_admin.facades.Ff4jFacade
import sbp.tcpf.support_admin.mappers.FeatureMapper
import sbp.tcpf.support_admin.mappers.FeatureStatisticsMapper
import sbp.tcpf.support_admin.mappers.FeatureTargetMapper
import sbp.tcpf.support_admin.mappers.LogicalFeatureMapper
import sbp.tcpf.support_admin.model.*
import sbp.tcpf.support_admin.services.request.FeatureRequestFactory
import sbp.tcpf.support_admin.services.request.RequestService
import java.util.*

@Service
class FeatureTogglingService(
    private val featureMapper: FeatureMapper,
    private val featureStatisticsMapper: FeatureStatisticsMapper,
    private val ff4jFacade: Ff4jFacade,
    private val userService: UserService,
    private val requestService: RequestService<UUID, FeatureRequest, FeatureApplication>,
    private val featureRequestFactory: FeatureRequestFactory,
    private val logicalFeatureMapper: LogicalFeatureMapper,
    private val featureTargetMapper: FeatureTargetMapper,
) {

    fun loadFeatureRequests(): List<FeatureApplication> {
        return requestService.load()
    }

    fun resolveFeatureRequest(uid: UUID, status: ApplicationStatus): FeatureApplication {
        return requestService.resolve(uid, status)
    }

    fun getFeatures(): List<LogicalFeature> {
        return ff4jFacade.getLogicalFeatures()
            .map { logicalFeatureMapper.map(it) }
    }

    fun updateFeatures(features: List<LogicalFeature>) {
        features
            .flatMap { logicalFeature ->
                featureTargetMapper.toLocation(logicalFeature.target)
                    .map { location -> featureMapper.map(logicalFeature, location) }
            }
            .forEach {
                ff4jFacade.update(it)
            }
    }

    fun createApplications(manageDtos: List<CreateFeaturesRequestInner>) {
        val existingByKey = ff4jFacade.getLogicalFeatures()
            .associateBy { it.key }

        manageDtos.forEach { dto ->
            val desired = logicalFeatureMapper.map(dto.feature)
            val existing = existingByKey[desired.key]

            if (dto.action == FeatureApplicationAction.DELETE) {
                require(desired.configuration == null)
            } else {
                requireNotNull(desired.configuration)
            }

            featureRequestFactory
                .create(dto.requestId, desired, existing)
                .ifPresent { requestService.save(it) }
        }
    }


    fun getStatistics(): List<FeatureStatistics> {
        return ff4jFacade.getPhysicalFeatures()
            .map { featureStatisticsMapper.convert(it) }
    }
}
