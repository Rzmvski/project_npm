package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.support_admin.dto.FeatureConfigurationDto;
import sbp.tcpf.support_admin.model.FeatureConfiguration;

import org.ff4j.core.Feature;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;

@Mapper(
        componentModel = MappingConstants.ComponentModel.SPRING,
        uses = {
                FeatureActivationMapper.class,
                CustomPropertyMapper.class,
        }
)
public interface FeatureConfigurationMapper {

    FeatureConfigurationDto map(Feature tcpfFeature);

    @Mapping(target = "flippingStrategy", source = "activation")
    @Mapping(target = "enable", source = "activation")
    FeatureConfigurationDto map(FeatureConfiguration configuration);

    @Mapping(target = "activation", source = "configurationDto")
    FeatureConfiguration map(FeatureConfigurationDto configurationDto);

}
