package sbp.tcpf.support_admin.services.request.store

import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.util.unit.DataSize
import sbp.tcpf.support_admin.entities.AbstractRequest
import sbp.tcpf.support_admin.entities.ScriptRequest
import sbp.tcpf.support_admin.mappers.RequestMapper
import sbp.tcpf.support_admin.model.ApplicationStatus
import sbp.tcpf.support_admin.repositories.RequestRepository
import sbp.tcpf.support_admin.services.lock.CuratorLockManager
import sbp.tcpf.support_admin.services.lock.LockType
import sbp.tcpf.support_admin.services.request.cache.RequestCuratorCacheManager
import sbp.tcpf.support_admin.services.request.store.modifiers.Modifier
import sbp.tcpf.support_admin.utils.applyAll
import java.time.LocalDateTime
import java.util.function.Function

class ZookeeperRequestDataStore<D, R : AbstractRequest, L>(
    private val lockManager: CuratorLockManager,
    private val repository: RequestRepository<R, String, Class<R>>,
    private val curatorCache: RequestCuratorCacheManager,
    private val requestClass: Class<R>,
    private val mapper: RequestMapper<D, R>,
    private val modifiers: List<Modifier<R>> = emptyList(),
    private val uidFunction: Function<L, String>,
    private val contentFunction: Function<R, String?>,
) : RequestDataStore<D, String, L, R> {

    override val storeType: StoreType = StoreType.PRIMARY

    override fun findByKey(key: String): D? {
        return curatorCache.getByUid(key, requestClass)
            .let { mapper.toDto(it) }
    }

    override fun loadByKeys(keys: Iterable<String>): List<D> {
        throw NotImplementedError()
    }

    override fun loadAll(): List<D> {
        return curatorCache.readAll(requestClass)
            .map { mapper.toDto(it) }
    }

    override fun save(application: D): D {
        val request = mapper.toEntity(application)
        val processed = modifiers.applyAll(request)
        val path = processed.path
        return lockManager.withLock(path, LockType.WRITE) {
            repository.save(processed)
            return@withLock mapper.toDto(request)
        }
    }

    override fun resolve(location: L, status: ApplicationStatus, resolver: String): D {
        return update(location) {
            requestStatus = status.value
            resolvedBy = resolver
            resolvedAt = LocalDateTime.now()
        }
    }

    override fun changeStatus(location: L, status: ApplicationStatus): D {
        return update(location) {
            requestStatus = status.value
        }
    }

    override fun execute(location: L, executor: String): D {
        return update(location) {
            if (this !is ScriptRequest) throw UnsupportedOperationException()

            requestStatus = ApplicationStatus.WORKS.value
            executedBy = executor
            resolvedAt = LocalDateTime.now()
        }
    }

    override fun appendLog(location: L, maxLogSize: DataSize, logMessage: String) {
        log.debug("skipping log appending in zookeeper store for {}", location)
    }

    override fun getLogs(key: String): String? {
        log.debug("zookeeper store does not hold logs, {}", key)
        return null
    }

    override fun getScriptData(key: String): String? {
        val request = curatorCache.getByUid(key, requestClass)
        return contentFunction.apply(request)
    }

    private fun update(location: L, updateBlock: R.() -> Unit): D {
        val uid = uidFunction.apply(location)
        val cachedRequest = curatorCache.getByUid(uid, requestClass)
        val path = cachedRequest.path

        return lockManager.withLock(path, LockType.WRITE) {
            val request = repository.findByKeyAndType(path, requestClass)
                ?: throw IllegalStateException("nothing to update")

            request.apply(updateBlock)

            repository.save(request)

            return@withLock mapper.toDto(request)
        }
    }

    companion object {
        private val log: Logger = LoggerFactory.getLogger(ZookeeperRequestDataStore::class.java)
    }
}
