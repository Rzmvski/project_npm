package sbp.tcpf.support_admin.utils

import sbp.tcpf.support_admin.services.request.store.modifiers.Modifier

fun <D> List<Modifier<D>>.applyAll(data: D): D = fold(data) { acc, modifier ->
    modifier.modify(acc)
}
