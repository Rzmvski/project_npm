package sbp.tcpf.support_admin.services.request.store.aggregators

fun interface Aggregator<D> {

    fun aggregate(data: List<D>): List<D>
}
