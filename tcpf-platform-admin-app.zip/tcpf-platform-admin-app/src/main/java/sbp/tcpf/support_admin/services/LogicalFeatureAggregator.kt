package sbp.tcpf.support_admin.services

import jakarta.annotation.PostConstruct
import org.springframework.stereotype.Component
import sbp.tcpf.routing.api.v1_0.client.model.Node
import sbp.tcpf.support_admin.dto.FeatureIdentity
import sbp.tcpf.support_admin.dto.FeatureSnapshot
import sbp.tcpf.support_admin.dto.FeatureTargetDto
import sbp.tcpf.support_admin.dto.LogicalFeatureDto
import sbp.tcpf.support_admin.mappers.FeatureConfigurationMapper

@Component
class LogicalFeatureAggregator(
    private val shardService: ShardService,
    private val configurationMapper: FeatureConfigurationMapper,
) {

    private lateinit var shardByNode: Map<String, List<String>>

    private data class LogicalKey(
        val name: String,
        val module: String?,
        val shard: List<String>?,
        val node: String?,
    )

    @PostConstruct
    protected fun init() {
        shardByNode = shardService.getNodes()
            .collectList()
            .block()
            .orEmpty()
            .groupBy { it.shardId }
            .values
            .associateByNodes()
    }

    fun aggregate(features: List<FeatureSnapshot>): List<LogicalFeatureDto> {
        return features
            .groupBy { feature ->
                val shardNodes = feature.location.node?.let { shardByNode.get(it) }
                LogicalKey(
                        name = feature.name,
                        module = feature.location.module,
                        shard = feature.location.node?.let(shardByNode::get),
                        node = feature.location.node.takeIf { it !in shardByNode }
                )
            }
            .map { (key, grouped) ->
                toLogicalFeature(key, grouped)
            }
    }


    private fun toLogicalFeature(
        key: LogicalKey,
        features: List<FeatureSnapshot>,
    ): LogicalFeatureDto {
        val firstFeature = features.first()
        val configs = features
            .map { it.configuration }
            .map { configurationMapper.map(it) }
        val firstConfiguration = configs.first()

        require(configs.all { it == firstConfiguration }) {
            "Physical feature $key have different configurations"
        }

        val actualNodes = features
            .mapNotNull { it.location.node }
            .toSet()

        val target = when {
            key.shard != null && actualNodes == key.shard.toSet() -> FeatureTargetDto(
                    FeatureTargetDto.Type.SHARD,
                    key.module,
                    key.shard
            )

            actualNodes.size == 1 -> FeatureTargetDto(
                    FeatureTargetDto.Type.NODE,
                    key.module,
                    actualNodes.toList()
            )

            else -> FeatureTargetDto(
                    FeatureTargetDto.Type.DIRECT,
                    key.module,
                    null
            )
        }

        return LogicalFeatureDto(
                FeatureIdentity(key.name, target),
                configurationMapper.map(firstFeature.configuration),
                firstFeature.created,
                firstFeature.updated,
                firstFeature.hot,
        )
    }


    companion object {
        private fun Collection<List<Node>>.associateByNodes(): Map<String, List<String>> {
            return buildMap {
                for (shardNodes in this@associateByNodes) {
                    val nodeKeys = shardNodes.map { node -> node.key }

                    for (nodeKey in nodeKeys) {
                        put(nodeKey, nodeKeys)
                    }
                }
            }
        }
    }
}
