package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.support_admin.model.BeanInfo;

import org.mapstruct.Mapper;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING)
public interface ShellBeanMapper {

    BeanInfo convert(sbp.tcpf.script.engine.model.BeanInfo beanInfo);
}
