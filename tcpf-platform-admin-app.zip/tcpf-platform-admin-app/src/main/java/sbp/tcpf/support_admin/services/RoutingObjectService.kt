package sbp.tcpf.support_admin.services

import org.springframework.stereotype.Service
import sbp.tcpf.routing.client.RoutingInfoProvider
import sbp.tcpf.support_admin.mappers.RoutingTypeMapper
import sbp.tcpf.support_admin.model.RoutingType
import sbp.tcpf.support_admin.model.ShardInfo

@Service
class RoutingObjectService(
    private val routingInfoProvider: RoutingInfoProvider,
    private val routingTypeMapper: RoutingTypeMapper,
) {
    fun getShardInfo(type: RoutingType, key: String): ShardInfo? {
        return runCatching {
            val nodeContext = routingInfoProvider.getNodeContext(routingTypeMapper.map(type), key)
            return ShardInfo(nodeContext.shardId, nodeContext.nodeKey)
        }.getOrNull()
    }
}
