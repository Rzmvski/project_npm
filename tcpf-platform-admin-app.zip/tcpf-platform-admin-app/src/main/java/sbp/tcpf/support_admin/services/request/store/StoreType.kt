package sbp.tcpf.support_admin.services.request.store

enum class StoreType {
    PRIMARY,
    SECONDARY;

    fun isPrimary(): Boolean {
        return this == PRIMARY
    }
}
