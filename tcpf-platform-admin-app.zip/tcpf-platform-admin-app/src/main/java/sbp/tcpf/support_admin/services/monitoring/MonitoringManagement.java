package sbp.tcpf.support_admin.services.monitoring;

import sbp.tcpf.support_admin.model.Monitoring;

import reactor.core.publisher.Flux;

public interface MonitoringManagement {

    Flux<Monitoring> getMonitoringInfo();
}
