package sbp.tcpf.support_admin.configs.properties;

import org.jetbrains.annotations.NotNull;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.net.URI;

@ConfigurationProperties("tcpf-platform-admin-app.tcpf-zone-index-app")
public record ZoneIndexAppProperties(@NotNull URI grpcUri, @NotNull URI restUri) {
}
