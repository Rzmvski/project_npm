package sbp.tcpf.support_admin.configs.properties;

import org.jetbrains.annotations.Nullable;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;
import org.springframework.boot.context.properties.bind.DefaultValue;
import org.springframework.lang.NonNull;
import org.springframework.util.unit.DataSize;

import java.net.URI;
import java.time.Duration;

@ConfigurationProperties("tcpf-platform-admin-app.script-service")
public record ScriptServiceProperties(
        @DefaultValue("1MB") DataSize maxLogSize,
        @DefaultValue("1536KB") DataSize maxScriptSize,
        @NonNull String executionsPath,
        @Nullable URI uri,
        @DefaultValue("1m") Duration awaitTimeout,
        @DefaultValue("1m") Duration finalizeDelay,
        @NestedConfigurationProperty ZookeeperProperties zookeeper,
        @NestedConfigurationProperty KafkaTopicsProperties kafkaTopics
) {

    public record ZookeeperProperties(
            @NonNull String path
    ) {
    }

    public record KafkaTopicsProperties(
            @NonNull String logs,
            @NonNull String statuses,
            @NonNull String commands
    ) {
    }
}
