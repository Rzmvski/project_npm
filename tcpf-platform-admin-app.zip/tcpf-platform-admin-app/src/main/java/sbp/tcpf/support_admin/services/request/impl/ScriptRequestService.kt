package sbp.tcpf.support_admin.services.request.impl

import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import sbp.tcpf.audit.api.AuditEvent
import sbp.tcpf.support.commons.auth.services.UserService
import sbp.tcpf.support_admin.dto.ScriptApplicationDto
import sbp.tcpf.support_admin.exceptions.ResourceNotFoundException
import sbp.tcpf.support_admin.mappers.ScriptApplicationMapper
import sbp.tcpf.support_admin.model.ApplicationStatus
import sbp.tcpf.support_admin.model.CreateScriptApplicationRequest
import sbp.tcpf.support_admin.model.ScriptApplication
import sbp.tcpf.support_admin.services.request.RequestService
import sbp.tcpf.support_admin.services.request.dto.ScriptKey
import sbp.tcpf.support_admin.services.request.resolvers.ResolverRegistry
import sbp.tcpf.support_admin.services.request.store.CompositeScriptDataStore
import java.time.LocalDateTime

@Service
class ScriptRequestService(
    private val userService: UserService,
    private val resolverRegistry: ResolverRegistry<ScriptApplicationDto>,
    private val store: CompositeScriptDataStore,
    private val mapper: ScriptApplicationMapper,
) : RequestService<String, CreateScriptApplicationRequest, ScriptApplication> {

    override fun load(): List<ScriptApplication> {
        return store.loadAll()
            .map { applicationDto -> applicationDto.toApi() }
    }

    @AuditEvent(onSuccess = "CREATE_SCRIPT_REQUEST", onError = "CREATE_SCRIPT_REQUEST_ERROR")
    override fun save(request: CreateScriptApplicationRequest): ScriptApplication {
        val dto = ScriptApplicationDto(
                location = ScriptKey(scriptId = request.reasonId),
                jiraId = request.jiraId,
                scriptBody = request.scriptBody,
                restrictions = request.restrictions,
                status = ApplicationStatus.PENDING,
                createdBy = userService.getUserLogin(),
                created = LocalDateTime.now(),
        )

        return store.save(dto).toApi()
    }

    override fun resolve(key: String, status: ApplicationStatus): ScriptApplication {
        val request = store.findByKey(key)
            ?: throw ResourceNotFoundException("request with uid $key not found")
        if (request.status == status) {
            log.info("request with key $key already has status $status, no resolution needed")
            return request.toApi()
        }
        val resolver = resolverRegistry.get(status)

        return resolver.resolve(request).toApi()
    }

    override fun find(key: String): ScriptApplication {
        return store.findByKey(key)
            ?.toApi()
            ?: throw ResourceNotFoundException("request with uid $key not found")
    }

    private fun ScriptApplicationDto.toApi() = mapper.map(this)

    companion object {
        private val log: Logger = LoggerFactory.getLogger(ScriptRequestService::class.java)
    }
}
