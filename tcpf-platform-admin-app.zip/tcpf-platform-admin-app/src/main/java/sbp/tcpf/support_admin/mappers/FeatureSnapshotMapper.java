package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.ff4j.admin.domain.TcpfFeature;
import sbp.tcpf.support_admin.dto.FeatureLocation;
import sbp.tcpf.support_admin.dto.FeatureSnapshot;
import sbp.tcpf.support_admin.entities.FeatureRequest;
import sbp.tcpf.support_admin.model.FeatureConfiguration;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.Named;

import static sbp.tcpf.ff4j.utils.Constants.GLOBAL_FEATURE;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING,
        uses = FeatureConfigurationMapper.class)
public interface FeatureSnapshotMapper {

    @Mapping(target = "created", ignore = true)
    @Mapping(target = "updated", ignore = true)
    @Mapping(target = "name", source = "request.featureName")
    @Mapping(target = "hot", source = "request.hot")
    @Mapping(target = "configuration", source = "configuration")
    FeatureSnapshot map(FeatureRequest request,
                        FeatureLocation location,
                        FeatureConfiguration configuration);

    @Mapping(target = "hot", source = "hotConfig")
    @Mapping(target = "updated", source = "updateDate")
    @Mapping(target = "created", source = "createDate")
    @Mapping(target = "location.module", source = "app", qualifiedByName = "getModule")
    @Mapping(target = "location.node", source = "node")
    @Mapping(target = "configuration", source = "feature")
    FeatureSnapshot map(TcpfFeature tcpfFeature);

    @Named("getModule")
    default String getModule(String source) {
        if (GLOBAL_FEATURE.equals(source)) {
            return null;
        }

        return source;
    }
}
