package sbp.tcpf.support_admin.services.monitoring.impl

import org.springframework.stereotype.Component
import reactor.core.publisher.Flux
import sbp.tcpf.support_admin.clients.feign.routing.RoutingMonitoringManagementApiClient
import sbp.tcpf.support_admin.mappers.MonitoringMapper
import sbp.tcpf.support_admin.model.IgniteType
import sbp.tcpf.support_admin.model.Monitoring
import sbp.tcpf.support_admin.services.monitoring.IgniteMonitoringSource

@Component
class SemaphoreIgniteMonitoringSource(
    private val routingMonitoringManagementApiClient: RoutingMonitoringManagementApiClient,
    private val monitoringMapper: MonitoringMapper,
) : IgniteMonitoringSource {

    override val type: IgniteType = IgniteType.SEMAPHORE

    override fun load(): Flux<Monitoring> {
        return routingMonitoringManagementApiClient.igniteMonitorings
            .map { monitoringMapper.convert(it) }
    }
}
