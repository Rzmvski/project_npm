package sbp.tcpf.support_admin.mappers

import org.ff4j.core.FlippingStrategy
import org.springframework.stereotype.Component
import sbp.tcpf.ff4j.strategy.ODReleaseDateFlipStrategy
import sbp.tcpf.support_admin.dto.FeatureConfigurationDto
import sbp.tcpf.support_admin.model.FeatureActivation
import sbp.tcpf.support_admin.model.ManualFeatureActivation
import sbp.tcpf.support_admin.model.OdReleaseFeatureActivation

@Component
class FeatureActivationMapper {

    fun mapEnable(source: FeatureActivation): Boolean {
        return when (source) {
            is ManualFeatureActivation -> source.enabled

            else -> false
        }
    }

    fun mapStrategy(source: FeatureActivation): FlippingStrategy? {
        return when (source) {
            is OdReleaseFeatureActivation -> ODReleaseDateFlipStrategy(source.releaseDate)

            else -> null
        }
    }

    fun toApi(source: FeatureConfigurationDto): FeatureActivation {
        val strategy = source.flippingStrategy
        return when (strategy) {
            is ODReleaseDateFlipStrategy -> OdReleaseFeatureActivation().releaseDate(strategy.releaseDate)

            else -> ManualFeatureActivation().enabled(source.enable)
        }
    }
}
