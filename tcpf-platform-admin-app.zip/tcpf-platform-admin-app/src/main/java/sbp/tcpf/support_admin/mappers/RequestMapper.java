package sbp.tcpf.support_admin.mappers;

public interface RequestMapper<D, E> {

    E toEntity(D dto);

    D toDto(E request);
}
