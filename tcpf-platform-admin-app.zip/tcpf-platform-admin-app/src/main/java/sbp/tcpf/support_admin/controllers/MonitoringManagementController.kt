package sbp.tcpf.support_admin.controllers

import io.micrometer.core.annotation.Timed
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.http.codec.ServerSentEvent
import org.springframework.web.bind.annotation.RestController
import reactor.core.publisher.Flux
import sbp.tcpf.base.metrics.TcpfMetrics
import sbp.tcpf.support_admin.api.MonitoringManagementServiceApi
import sbp.tcpf.support_admin.configs.properties.RoutingAppOsProperties
import sbp.tcpf.support_admin.model.IgniteType
import sbp.tcpf.support_admin.model.Monitoring
import sbp.tcpf.support_admin.model.ReplicationThreshold
import sbp.tcpf.support_admin.services.monitoring.IgniteMonitoringManagement
import sbp.tcpf.support_admin.services.monitoring.MonitoringManagement
import sbp.tcpf.support_admin.utils.toSse

@RestController
class MonitoringManagementController(
    @Qualifier("DB") private val dbMonitoringManagement: MonitoringManagement,
    @Qualifier("IGNITE") private val igniteMonitoringManagement: IgniteMonitoringManagement,
    private val properties: RoutingAppOsProperties,
) : MonitoringManagementServiceApi {

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "MonitoringManagementService"])
    override fun getDbMonitorings(): Flux<ServerSentEvent<Monitoring>> {
        return dbMonitoringManagement.monitoringInfo.toSse()
    }

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "MonitoringManagementService"])
    override fun getIgniteMonitorings(type: IgniteType?): Flux<ServerSentEvent<Monitoring>> {
        return igniteMonitoringManagement.getMonitoringByType(type ?: IgniteType.ALL).toSse()
    }

    @Timed(value = TcpfMetrics.SERVICE_CALL, extraTags = [TcpfMetrics.SERVICE, "MonitoringManagementService"])
    override fun getMonitoringThreshold(): ReplicationThreshold? {
        return ReplicationThreshold(properties.monitoringThreshold.toMillis().toInt())
    }
}
