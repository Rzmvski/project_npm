package sbp.tcpf.support_admin.services.request.resolvers

import sbp.tcpf.support_admin.model.ApplicationStatus

class ResolverRegistry<T>(
    resolvers: List<RequestResolver<T>>,
) {

    private val resolversByStatus = resolvers.associateBy { it.status }

    fun get(status: ApplicationStatus): RequestResolver<T> {
        return resolversByStatus[status] ?: throw UnsupportedOperationException("update to status $status not supported")
    }
}
