package sbp.tcpf.support_admin.services.request.store

import org.springframework.util.unit.DataSize
import sbp.tcpf.support_admin.model.ApplicationStatus

interface RequestDataStore<D, K, L, E> {

    val storeType: StoreType

    fun findByKey(key: K): D?

    fun loadByKeys(keys: Iterable<K>): List<D>

    fun loadAll(): List<D>

    fun save(application: D): D

    fun resolve(location: L, status: ApplicationStatus, resolver: String): D

    fun changeStatus(location: L, status: ApplicationStatus): D

    fun execute(location: L, executor: String): D

    fun appendLog(location: L, maxLogSize: DataSize, logMessage: String)

    fun getLogs(key: K): String?

    fun getScriptData(key: K): String?
}
