package sbp.tcpf.support_admin.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Коды ошибок для внешних систем и их описание
 * <a href="https://confluence.delta.sbrf.ru/pages/viewpage.action?pageId=2375273999">...</a>
 */
@AllArgsConstructor
@Getter
public enum OuterErrorCodes {
    SUCCESS(0, "Успех"),
    INPUT_PARAM_VALIDATION_ERROR(-1, "Некорректные значения параметров в запросе"),
    TECHNICAL_ERROR(-2, "Произошла техническая ошибка на внешнем транспорте"),
    DUPLICATE_RQ_UID_REQUEST_ERROR(-3, "Запрос с таким RqUID уже был ранее зарегистрирован. Обратитесь к Администратору системы"),
    BUSINESS_LOGIC_ERROR(-4, "При выполнении процедуры произошла ошибка. Обратитесь к Администратору."),
    DUPLICATE_REQUEST_ERROR(-5, "Получен дублированный запрос. Основной запрос находится в обработке или обработан."),
    REQUEST_ALREADY_DONE(-6, "Запрос уже выполнен успешно."),
    REQUEST_IN_WORK(-7, "Запрос в работе."),
    OPERATION_REFUSED(-8, "Отказ в выполнении операции"),
    COMPLIANCE_ERROR(1, "Отказ Комплаенс"),
    NO_INFORMATION_FOUND(2, "По запрошенным критериям информация не найдена."),
    SERVICE_UNAVAILABLE(10, "Сервис недоступен"),
    CONTRACT_STATUS_INVALID(12, "Недопустимый статус договора."),
    PROCESS_ALREADY_STOPPED(16, "Процесс уже остановлен"),
    CLIENT_ACTIVE_CONTRACT_EXISTS(49, "Для данного клиента найден действующий кредитный договор"),
    CONTRACT_IN_OVD(109, "По договору имеется просроченная задолженность."),
    NEW_CREDIT_LIMIT_NOT_MATCH_REASON_REQUEST(121, "Новый кредитный лимит не соответствует причине изменений в запросе."),
    NEW_CREDIT_LIMIT_LESS_MIN_PRODUCT(122, "Новый кредитный лимит меньше минимального значения, установленного по продукту."),
    NEW_CREDIT_LIMIT_LESS_USED(123, "Новый кредитный лимит меньше использованного кредитного лимита."),
    NEW_CREDIT_LIMIT_MORE_MAX_PRODUCT(124, "Новый кредитный лимит превышает максимальное значение, установленное по продукту."),
    INVALID_INPUT_VALIDATION(-100, "REST service input data validation failed"),
    INVALID_OUTPUT_VALIDATION(-110, "REST service output data validation failed"),
    MMT_ERROR(-150, "Ошибки ММТ");

    private final int code;
    private final String description;

    public static String getDescriptionByCode(int code) {
        for (OuterErrorCodes errorCode : values()) {
            if (errorCode.code == code) {
                return errorCode.description;
            }
        }
        return OuterErrorCodes.BUSINESS_LOGIC_ERROR.description;
    }

    public static OuterErrorCodes getByCode(int code) {
        for (OuterErrorCodes errorCode : values()) {
            if (errorCode.code == code) {
                return errorCode;
            }
        }
        return OuterErrorCodes.BUSINESS_LOGIC_ERROR;
    }
}
