package sbp.tcpf.support_admin.services.request.resolvers.script

import sbp.tcpf.support.commons.auth.services.UserService
import sbp.tcpf.support_admin.dto.ScriptApplicationDto
import sbp.tcpf.support_admin.model.ApplicationStatus
import sbp.tcpf.support_admin.services.request.resolvers.RequestResolver
import sbp.tcpf.support_admin.services.request.store.CompositeScriptDataStore

class CommonStatusResolver(
    override val status: ApplicationStatus,
    private val userService: UserService,
    private val store: CompositeScriptDataStore,
) : RequestResolver<ScriptApplicationDto> {

    override fun resolve(application: ScriptApplicationDto): ScriptApplicationDto {
        val resolverLogin = userService.getUserLogin() ?: throw IllegalStateException()

        return store.resolveStatus(
                application.location,
                status,
                resolverLogin
        )
    }
}
