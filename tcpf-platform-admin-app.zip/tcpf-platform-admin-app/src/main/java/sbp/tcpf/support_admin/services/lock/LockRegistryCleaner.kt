package sbp.tcpf.support_admin.services.lock

import org.apache.curator.framework.recipes.cache.ChildData
import org.apache.curator.framework.recipes.cache.CuratorCacheListener
import org.springframework.stereotype.Component

@Component
class LockRegistryCleaner(
    private val lockRegistry: LockRegistry,
) : CuratorCacheListener {

    override fun event(
        type: CuratorCacheListener.Type,
        oldData: ChildData?,
        data: ChildData?,
    ) {
        if (type == CuratorCacheListener.Type.NODE_DELETED && oldData != null) {
            lockRegistry.remove(oldData.path)
        }
    }
}