package sbp.tcpf.support_admin.services.request.impl

import org.springframework.stereotype.Service
import sbp.tcpf.audit.api.AuditEvent
import sbp.tcpf.support_admin.entities.FeatureRequest
import sbp.tcpf.support_admin.mappers.FeatureApplicationMapper
import sbp.tcpf.support_admin.mappers.LogicalFeatureMapper
import sbp.tcpf.support_admin.model.ApplicationStatus
import sbp.tcpf.support_admin.model.FeatureApplication
import sbp.tcpf.support_admin.repositories.RequestRepository
import sbp.tcpf.support_admin.services.LogicalFeatureAggregator
import sbp.tcpf.support_admin.services.request.RequestService
import sbp.tcpf.support_admin.services.request.cache.RequestCuratorCacheManager
import sbp.tcpf.support_admin.services.request.resolvers.ResolverRegistry
import java.util.*

@Service
class FeatureTogglingRequestService(
    private val resolverRegistry: ResolverRegistry<FeatureRequest>,
    private val curatorCache: RequestCuratorCacheManager,
    private val repository: RequestRepository<FeatureRequest, String, Class<FeatureRequest>>,
    private val aggregator: LogicalFeatureAggregator,
    private val logicalFeatureMapper: LogicalFeatureMapper,
    private val featureApplicationMapper: FeatureApplicationMapper,
) : RequestService<UUID, FeatureRequest, FeatureApplication> {

    override fun load(): List<FeatureApplication> {
        return curatorCache.readAll(FeatureRequest::class.java)
            .map { it.toApi() }
    }

    @AuditEvent(onSuccess = "CREATE_FEATURE_REQUEST", onError = "CREATE_FEATURE_REQUEST_ERROR")
    override fun save(request: FeatureRequest): FeatureApplication {
        return repository.save(request).toApi()
    }

    @AuditEvent(onSuccess = "FEATURE_REQUEST_RESULT", onError = "FEATURE_REQUEST_RESULT_ERROR")
    override fun resolve(key: UUID, status: ApplicationStatus): FeatureApplication {
        val request = curatorCache
            .readAll(FeatureRequest::class.java)
            .single { request -> request.rqUid == key }
        val resolver = resolverRegistry.get(status)

        val resolvedRequest = resolver.resolve(request)

        return repository.save(resolvedRequest).toApi()
    }

    private fun FeatureRequest.toApi() = featureApplicationMapper.map(this, this.delta.before, this.delta.after)

    override fun find(key: String): FeatureApplication {
        throw UnsupportedOperationException()
    }
}
