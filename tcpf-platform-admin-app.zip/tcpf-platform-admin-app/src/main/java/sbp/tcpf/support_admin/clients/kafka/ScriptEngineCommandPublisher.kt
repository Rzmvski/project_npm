package sbp.tcpf.support_admin.clients.kafka

import org.springframework.kafka.core.KafkaTemplate
import org.springframework.stereotype.Component
import sbp.tcpf.script.engine.async.model.Command
import sbp.tcpf.support_admin.configs.properties.ScriptServiceProperties
import sbp.tcpf.support_admin.services.request.execution.ExecutionContextManager

@Component
class ScriptEngineCommandPublisher(
    private val kafkaTemplate: KafkaTemplate<String, Command>,
    private val executionContextManager: ExecutionContextManager,
    private val scriptServiceProperties: ScriptServiceProperties,
) {

    fun sendCommand(command: Command) {
        val executionId = command.executionId
        kafkaTemplate.send(
                scriptServiceProperties.kafkaTopics.commands,
                executionId,
                command
        )
        executionContextManager
            .awaitExecution(executionId)
            .subscribe()
    }
}
