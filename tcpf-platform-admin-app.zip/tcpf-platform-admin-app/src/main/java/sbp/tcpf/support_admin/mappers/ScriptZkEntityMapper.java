package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.support_admin.dto.DbRef;
import sbp.tcpf.support_admin.dto.ScriptApplicationDto;
import sbp.tcpf.support_admin.entities.ScriptRequest;
import sbp.tcpf.support_admin.utils.ConverterUtils;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.ReportingPolicy;

import java.time.LocalDateTime;
import java.util.Optional;

@Mapper(
        componentModel = MappingConstants.ComponentModel.SPRING,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        unmappedTargetPolicy = ReportingPolicy.IGNORE,
        uses = ConverterUtils.class,
        imports = LocalDateTime.class
)
public interface ScriptZkEntityMapper extends RequestMapper<ScriptApplicationDto, ScriptRequest> {

    @Mapping(target = "executionUid", ignore = true)
    @Mapping(target = "uid", source = "location.scriptId")
    @Mapping(target = "content", source = "scriptBody")
//    @Mapping(target = "cancelled", source = "isCancelled")
    @Mapping(target = "dbRef", source = "location.shardId")
    @Mapping(target = "requestStatus", source = "status")
    @Mapping(target = "createdAt", source = "created", defaultExpression = "java(LocalDateTime.now())")
    ScriptRequest toEntity(ScriptApplicationDto application);

    @InheritInverseConfiguration
    ScriptApplicationDto toDto(ScriptRequest request);

    default DbRef buildRef(Integer shardId) {
        return Optional.ofNullable(shardId)
                       .map(DbRef::new)
                       .orElse(null);
    }

    default Integer getShardId(DbRef dbRef) {
        return Optional.ofNullable(dbRef)
                       .map(DbRef::getShardId)
                       .orElse(null);
    }
}
