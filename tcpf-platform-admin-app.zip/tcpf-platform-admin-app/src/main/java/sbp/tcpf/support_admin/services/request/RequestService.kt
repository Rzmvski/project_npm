package sbp.tcpf.support_admin.services.request

import sbp.tcpf.support_admin.model.ApplicationStatus

interface RequestService<K, R, T> {

    fun load(): List<T>

    fun save(request: R): T

    fun resolve(key: K, status: ApplicationStatus): T

    fun find(key: String): T
}
