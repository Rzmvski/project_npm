package sbp.tcpf.support_admin.dto;

import java.time.LocalDateTime;

public record FeatureSnapshot(
        String name,
        FeatureLocation location,
        FeatureConfigurationDto configuration,
        LocalDateTime created,
        LocalDateTime updated,
        Boolean hot
) {
}
