package sbp.tcpf.support_admin.repositories.impl

import com.fasterxml.jackson.databind.ObjectMapper
import org.apache.commons.lang3.time.DurationFormatUtils.formatDurationWords
import org.apache.curator.framework.CuratorFramework
import org.apache.zookeeper.CreateMode
import org.springframework.stereotype.Repository
import org.springframework.validation.annotation.Validated
import sbp.tcpf.routing.client.hikari.zk.exists
import sbp.tcpf.support_admin.configs.CuratorConfig.RequestCuratorBean
import sbp.tcpf.support_admin.configs.properties.ResolveRequestServiceProperties
import sbp.tcpf.support_admin.entities.AbstractRequest
import sbp.tcpf.support_admin.repositories.RequestRepository
import sbp.tcpf.support_admin.services.request.RequestCryptoService

@Validated
@Repository
class ZkRequestRepository<R : AbstractRequest>(
    @RequestCuratorBean
    private val curatorFramework: CuratorFramework,
    private val properties: ResolveRequestServiceProperties,
    private val objectMapper: ObjectMapper,
    private val cryptoService: RequestCryptoService<R>,
) : RequestRepository<R, String, Class<R>> {

    override fun findByKeyAndType(key: String, type: Class<R>): R {
        val data = curatorFramework.data.forPath(key)
        return objectMapper.readValue(data, type)
            .let { cryptoService.decrypt(it) }
    }

    override fun save(entity: R): R {
        val requestTtl = properties.requestTtl
        val path = entity.path
        val data = entity
            .apply {
                this.requestTtl = formatDurationWords(
                        requestTtl.toMillis(),
                        true,
                        true
                )
            }
            .let { cryptoService.encrypt(it) }
            .let { objectMapper.writeValueAsBytes(it) }

        curatorFramework.upsert(path, data)

        return entity
    }

    private fun CuratorFramework.upsert(path: String, data: ByteArray) {
        if (!this.exists(path)) {
            this.create()
                .withTtl(properties.requestTtl.toMillis())
                .creatingParentContainersIfNeeded()
                .withMode(CreateMode.PERSISTENT_WITH_TTL)
                .forPath(path, data)
        } else {
            this.setData().forPath(path, data)
        }
    }
}
