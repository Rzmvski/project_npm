package sbp.tcpf.support_admin.services.lock

enum class LockType {
    READ, WRITE
}