package sbp.tcpf.support_admin.services.request.store

sealed interface UpdateResult {
    data object Updated : UpdateResult

    data object Skipped : UpdateResult
}
