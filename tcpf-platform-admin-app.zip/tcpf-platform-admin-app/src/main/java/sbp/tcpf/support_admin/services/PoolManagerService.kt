package sbp.tcpf.support_admin.services

import org.springframework.stereotype.Service
import reactor.core.publisher.Flux
import reactor.core.publisher.Mono
import sbp.tcpf.os.commons.config.ModuleProperties
import sbp.tcpf.routing.api.v1_0.client.model.PoolUpdate
import sbp.tcpf.support.commons.auth.services.UserService
import sbp.tcpf.support_admin.clients.feign.routing.ConnectionPoolManagementApiClient
import sbp.tcpf.support_admin.mappers.PoolStateMapper
import sbp.tcpf.support_admin.model.Pool
import sbp.tcpf.support_admin.model.PoolState
import sbp.tcpf.support_admin.utils.toMono
import java.time.OffsetDateTime
import java.util.*

/**
 * Класс для взаимодействия с пулами через tcpf-routing-app-os по REST протоколу
 */
@Service
class PoolManagerService(
    private val poolStateMapper: PoolStateMapper,
    private val connectionPoolManagementApiClient: ConnectionPoolManagementApiClient,
    private val moduleProperties: ModuleProperties,
    private val userService: UserService,
) {

    fun getPoolActivityStates(): Flux<Pool> {
        return connectionPoolManagementApiClient.getPools()
            .map { poolStateMapper.map(it) }
    }

    fun changePoolState(nodeKey: String, state: PoolState): Mono<Void> {
        val status = poolStateMapper.map(state)
        return connectionPoolManagementApiClient.updatePoolsByKey(
                listOf(nodeKey),
                PoolUpdate(status).toMono(),
                moduleProperties.moduleId,
                userService.getUserLogin(),
                UUID.randomUUID().toString(),
                OffsetDateTime.now(),
                null,
        ).then()
    }

    private fun List<Pool>.getPoolState() = this.first().status.value
}
