package sbp.tcpf.support_admin.services

import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import sbp.tcpf.replica.monitor.api.mass.model.JobStatus
import sbp.tcpf.replica.monitor.api.mass.model.Revision
import sbp.tcpf.support_admin.clients.feign.replica_monitor.ReplicaMonitorApiClient
import sbp.tcpf.support_admin.configs.properties.ReplicaMonitorAppProperties
import sbp.tcpf.support_admin.exceptions.ExternalServiceException
import sbp.tcpf.support_admin.mappers.RevisionDetailsMapper
import sbp.tcpf.support_admin.mappers.RevisionMapper
import sbp.tcpf.support_admin.mappers.RevisionReportMapper
import sbp.tcpf.support_admin.mappers.RevisionStatusMapper
import sbp.tcpf.support_admin.model.*
import sbp.tcpf.support_admin.utils.getResponseOrThrowWithMessage
import java.time.LocalDate
import java.util.*

@Service
class ReviseReplicationService(
    private val replicaMonitorClient: ReplicaMonitorApiClient,
    private val revisionMapper: RevisionMapper,
    private val revisionDetailsMapper: RevisionDetailsMapper,
    private val revisionReportMapper: RevisionReportMapper,
    private val revisionStatusMapper: RevisionStatusMapper,
    private val revisionProperties: ReplicaMonitorAppProperties,
) {

    fun getReviseShardIds(): List<String> {
        return replicaMonitorClient.shards
            .getResponseOrThrowWithMessage(ERROR_MESSAGE)
            .map { it.id }
    }

    fun getLastRevisions(): List<RevisionInfo> {
        return replicaMonitorClient.getRevisionsAggregated(
            true, null, null, null,  null, null,DEFAULT_PAGE_SIZE
        )
            .getResponseOrThrowWithMessage(ERROR_MESSAGE)
            .map { revisionMapper.convert(it) }
    }

    fun getRevisionById(revisionId: Long, shardId: String): RevisionInfo {
        return replicaMonitorClient.getRevision(shardId, revisionId)
            .getResponseOrThrowWithMessage(ERROR_MESSAGE)
            .let { revisionMapper.convert(it) }
    }

    fun revise(shardIds: List<String>, uuid: UUID, part: Int): List<RevisionInfo> {
        val revision = Revision().apply { part(part) }
        return shardIds.failSafeCall { shardId ->
            replicaMonitorClient.postRevisions(uuid.toString(), shardId, revision, null, null)
                .getResponseOrThrowWithMessage(ERROR_MESSAGE)
                .let { revisionMapper.convert(it) }
        }
    }

    fun changeStatus(
        reviseShardId: String,
        revisionId: Long,
        uuid: UUID,
        targetStatus: RevisionStatus?,
        revisionJob: RevisionJob?,
        table: String?,
    ): RevisionInfo {
        val revision = Revision().apply {
            status = targetStatus?.value
            job = revisionJob?.value

            table?.let { addTablesItem(it) }
        }
        return replicaMonitorClient.postRevision(uuid.toString(), reviseShardId, revisionId, revision, null)
            .getResponseOrThrowWithMessage(ERROR_MESSAGE)
            .let { revisionMapper.convert(it) }
    }

    fun loadDetails(
        reviseShardId: String,
        revisionId: Long,
        tableName: String?,
        pageNumber: Int?,
        pageSize: Int?,
    ): List<RevisionDetails> {
        return replicaMonitorClient.getRevisionTables(reviseShardId, revisionId, tableName, null, null,pageNumber, pageSize)
            .getResponseOrThrowWithMessage(ERROR_MESSAGE)
            .map { revisionDetailsMapper.convert(it) }
    }

    fun loadHistory(
        reviseShardIds: List<String>,
        status: String?,
        revisionId: Long?,
        from: LocalDate?,
        to: LocalDate?,
        pageNumber: Int?,
        pageSize: Int?,
    ): List<RevisionInfo> {
        val jobStatus = revisionStatusMapper.convert(status)
        return fetchRevisions(reviseShardIds, jobStatus, revisionId, pageNumber, pageSize, from, to)
            .map { revisionMapper.convert(it) }
    }

    private fun fetchRevisions(
        reviseShardIds: List<String>,
        jobStatus: JobStatus?,
        revisionId: Long?,
        pageNumber: Int?,
        pageSize: Int?,
        from: LocalDate?,
        to: LocalDate?,
    ): List<Revision> {
        return when {
            revisionId != null -> {
                listOf(
                        replicaMonitorClient.getRevision(reviseShardIds.first(), revisionId)
                            .getResponseOrThrowWithMessage(ERROR_MESSAGE)
                )
            }
            reviseShardIds.size == 1 -> {
                replicaMonitorClient.getRevisions(reviseShardIds.first(), null, jobStatus, from, to, pageNumber, pageSize)
                    .getResponseOrThrowWithMessage(ERROR_MESSAGE)
            }
            else -> {
                replicaMonitorClient.getRevisionsAggregated(false, null, jobStatus,from, to, pageNumber, pageSize)
                    .getResponseOrThrowWithMessage(ERROR_MESSAGE)
            }
        }
    }

    fun loadReport(
        reviseShardId: String,
        revisionId: Long,
        table: String?,
        pageNumber: Int,
    ): List<RevisionReport> {
        return replicaMonitorClient.getRevisionRows(
            reviseShardId, revisionId, table, null, pageNumber, revisionProperties.reportPageSize
        )
            .getResponseOrThrowWithMessage(ERROR_MESSAGE)
            .map { revisionReportMapper.convert(it) }
    }

    private fun <T> List<String>.failSafeCall(action: (String) -> T?): List<T> {
        val (results, errors) = this.map { shardId ->
            runCatching { action(shardId) }
                .onFailure { log.error("failed revision on shard $shardId: ${it.message}", it) }
        }.partition { it.isSuccess }
        if (errors.isNotEmpty()) throw ExternalServiceException("failed to revise on some shards")
        return results.mapNotNull { it.getOrNull() }
    }

    companion object {
        const val DEFAULT_PAGE_SIZE = 1
        const val ERROR_MESSAGE = "Failed to retrieve revision data"
        val log: Logger = LoggerFactory.getLogger(ReviseReplicationService::class.java)
    }
}
