package sbp.tcpf.support_admin.mappers;

import sbp.tcpf.script.engine.async.model.Restrictions;
import sbp.tcpf.script.engine.async.model.StartCommand;
import sbp.tcpf.support_admin.dto.ScriptApplicationDto;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;
import java.util.Optional;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING)
public interface ScriptExecutionRequestMapper {

    @Mapping(target = "script", source = "scriptBody")
    @Mapping(target = "executionId", source = "location.scriptId")
    @Mapping(target = "restrictions", source = "restrictions.allowedNodes")
    StartCommand map(ScriptApplicationDto application);

    default Restrictions buildRestrictions(List<String> allowedNodes) {
        return Optional.ofNullable(allowedNodes)
                .filter(nodes -> !nodes.isEmpty())
                .map((nodes) -> {
                    var restrictions = new Restrictions();
                    restrictions.allowedNodes(nodes);

                    return restrictions;
                })
                .orElse(null);
    }
}
