package sbp.tcpf.support_admin.services.request.store

import org.springframework.stereotype.Component
import sbp.tcpf.support_admin.configs.properties.ScriptServiceProperties
import sbp.tcpf.support_admin.dto.ScriptApplicationDto
import sbp.tcpf.support_admin.model.ApplicationStatus
import sbp.tcpf.support_admin.services.request.dto.ScriptKey
import sbp.tcpf.support_admin.services.request.store.aggregators.Aggregator

@Component
class CompositeScriptDataStore(
    private val stores: List<RequestDataStore<ScriptApplicationDto, String, ScriptKey, *>>,
    private val aggregator: Aggregator<ScriptApplicationDto>,
    private val properties: ScriptServiceProperties,
) {

    fun findByKey(key: String): ScriptApplicationDto? {
        return query { store -> store.findByKey(key) }
            .let { aggregator.aggregate(it) }
            .firstOrNull()
    }

    fun loadAll(): List<ScriptApplicationDto> {
        val (primaryStore, secondaryStores) = stores.partition { it.storeType.isPrimary() }

        val primaryData = primaryStore.single().loadAll()
        val keys = primaryData
            .map { application -> application.location.scriptId }

        val secondaryData = secondaryStores.flatMap { it.loadByKeys(keys) }

        return aggregator.aggregate(secondaryData + primaryData)
    }

    fun save(application: ScriptApplicationDto): ScriptApplicationDto {
        return stores
            .fold(application) { acc, source ->
                source.save(acc)
            }
    }

    fun resolveStatus(key: ScriptKey, status: ApplicationStatus, resolver: String): ScriptApplicationDto {
        return executeOnAllAndAggregate { store ->
            store.resolve(key, status, resolver)
        }
    }

    fun changeStatus(key: ScriptKey, status: ApplicationStatus): ScriptApplicationDto {
        return executeOnAllAndAggregate { store ->
            store.changeStatus(key, status)
        }
    }

    fun execute(key: ScriptKey, executor: String): ScriptApplicationDto {
        return executeOnAllAndAggregate { store ->
            store.execute(key, executor)
        }
    }

    fun saveLogs(key: ScriptKey, logMessage: String) {
        stores.forEach { store ->
            store.appendLog(key, properties.maxLogSize, logMessage)
        }
    }

    fun loadLogs(key: String): String? {
        return query { store -> store.getLogs(key) }
            .firstOrNull()
    }

    fun loadScriptBody(key: String): String? {
        return query { store -> store.getScriptData(key) }
            .firstOrNull()
    }

    private fun <T> query(queryFn: (RequestDataStore<ScriptApplicationDto, String, ScriptKey, *>) -> T?): List<T> {
        return stores.mapNotNull(queryFn)
    }

    private fun executeOnAllAndAggregate(
        operation: (RequestDataStore<ScriptApplicationDto, String, ScriptKey, *>) -> ScriptApplicationDto,
    ): ScriptApplicationDto {
        return stores
            .map(operation)
            .let { aggregator.aggregate(it) }
            .first()
    }
}
