package sbp.tcpf.support_admin.entities;

import sbp.tcpf.support_admin.dto.DbRef;
import sbp.tcpf.support_admin.model.Restrictions;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.UUID;
import javax.annotation.Nullable;

@Data
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public final class ScriptRequest extends AbstractRequest {

    private UUID rqUid;
    @Nullable
    private String executionUid;
    @Nullable
    private DbRef dbRef;
    private boolean cancelled;
    private String jiraId;
    private String executedBy;
    @Nullable
    private byte[] content;
    private Restrictions restrictions;
}
