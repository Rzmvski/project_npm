package sbp.tcpf.support_admin.configs.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

import java.net.URI;
import javax.validation.constraints.NotNull;

@ConfigurationProperties("tcpf-platform-admin-app.tcpf-replica-monitor-app")
public record ReplicaMonitorAppProperties(
        @NotNull URI uri,
        @DefaultValue("5000") Integer reportPageSize
) {
}
