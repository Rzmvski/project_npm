import sbp.tcpf.routing.client.jdbc.transaction.TxDefinition

log.info("waiting 3s")
Thread.sleep(3000)
log.info("searching contract")
def work = { defaultGeneralContractRepository.findContractIdByContractNumber("100500") }
def result = uow.callOnNodeDefault("test", "ALPHA", TxDefinition.READ_ONLY.getDefinition(), work)

log.info("result: contract id is ${result.get()}")
log.debug("script ended")
