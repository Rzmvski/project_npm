package sbp.tcpf.support_admin.controllers;

import sbp.tcpf.forced.replication.model.OperationResponse;
import sbp.tcpf.forced.replication.model.ReplicationStatus;
import sbp.tcpf.forced.replication.model.ServiceModeStatus;
import sbp.tcpf.routing.api.v1_0.client.model.BucketRange;
import sbp.tcpf.routing.api.v1_0.client.model.Cluster;
import sbp.tcpf.routing.api.v1_0.client.model.ClusterStatus;
import sbp.tcpf.routing.api.v1_0.client.model.NodeStatus;
import sbp.tcpf.routing.api.v1_0.client.model.PoolStatus;
import sbp.tcpf.routing.api.v1_0.client.model.SchemaMetadata;
import sbp.tcpf.support_admin.clients.feign.routing.ConnectionPoolManagementApiClient;
import sbp.tcpf.support_admin.clients.feign.routing.RoutingManagementApiClient;
import sbp.tcpf.support_admin.clients.feign.routing.SemaphoreClusterManagementApiClient;
import sbp.tcpf.support_admin.config.AuditTestConfig;
import sbp.tcpf.support_admin.config.CommonTestConfig;
import sbp.tcpf.support_admin.config.FeignClientsTestConfig;
import sbp.tcpf.support_admin.config.NoOpEventListener;
import sbp.tcpf.support_admin.config.SecurityTestConfig;
import sbp.tcpf.support_admin.configs.properties.ForcedReplicationProperties;
import sbp.tcpf.support_admin.configs.properties.RoutingAppOsProperties;
import sbp.tcpf.support_admin.mappers.ClusterStateMapperImpl;
import sbp.tcpf.support_admin.mappers.MetadataMapperImpl;
import sbp.tcpf.support_admin.mappers.OperationResponseMapperImpl;
import sbp.tcpf.support_admin.mappers.PoolStateMapperImpl;
import sbp.tcpf.support_admin.mappers.ReplicationStatusMapperImpl;
import sbp.tcpf.support_admin.mappers.SemaphoreMapperImpl;
import sbp.tcpf.support_admin.mappers.ServiceModeStateMapperImpl;
import sbp.tcpf.support_admin.mappers.ServiceModeStatusMapperImpl;
import sbp.tcpf.support_admin.mappers.ShardMapperImpl;
import sbp.tcpf.support_admin.mappers.UpdateShardMapperImpl;
import sbp.tcpf.support_admin.model.BucketRangeUpdate;
import sbp.tcpf.support_admin.model.ChangeClusterStateRequest;
import sbp.tcpf.support_admin.model.ClusterState;
import sbp.tcpf.support_admin.model.Metadata;
import sbp.tcpf.support_admin.model.Node;
import sbp.tcpf.support_admin.model.Pool;
import sbp.tcpf.support_admin.model.PoolState;
import sbp.tcpf.support_admin.model.ReplicationState;
import sbp.tcpf.support_admin.model.ReplicationStatusDto;
import sbp.tcpf.support_admin.model.Semaphore;
import sbp.tcpf.support_admin.model.ServiceModeState;
import sbp.tcpf.support_admin.model.ServiceModeStatusDto;
import sbp.tcpf.support_admin.model.Shard;
import sbp.tcpf.support_admin.model.ShardUpdate;
import sbp.tcpf.support_admin.model.UpdateServiceModeRequest;
import sbp.tcpf.support_admin.services.MetadataManagementService;
import sbp.tcpf.support_admin.services.NodeManagementService;
import sbp.tcpf.support_admin.services.PoolManagerService;
import sbp.tcpf.support_admin.services.SemaphoreManagementService;
import sbp.tcpf.support_admin.services.forced_replication.DefaultForcedReplicationService;
import sbp.tcpf.support_admin.services.forced_replication.UnsupportedForcedReplicationService;
import sbp.tcpf.support_admin.utils.AsyncMvc;
import sbp.tcpf.support_admin.utils.AuditAssertions;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.maciejwalkowiak.wiremock.spring.ConfigureWireMock;
import com.maciejwalkowiak.wiremock.spring.EnableWireMock;
import com.maciejwalkowiak.wiremock.spring.InjectWireMock;
import com.sbt.audit.core.model.v2.event.Event;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.test.context.support.WithUserDetails;
import org.springframework.test.context.bean.override.mockito.MockitoSpyBean;
import org.springframework.test.web.servlet.MockMvc;

import java.time.OffsetDateTime;
import java.util.List;

import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.okJson;
import static com.github.tomakehurst.wiremock.client.WireMock.serverError;
import static com.github.tomakehurst.wiremock.client.WireMock.serviceUnavailable;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathTemplate;
import static org.apache.commons.lang3.tuple.Pair.of;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.then;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.atMostOnce;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static sbp.tcpf.support_admin.config.SecurityTestConfig.FIRST_ADMIN;
import static sbp.tcpf.support_admin.utils.AuditAssertions.thenEventSatisfies;
import static sbp.tcpf.support_admin.utils.TestConstants.ALPHA;
import static sbp.tcpf.support_admin.utils.TestConstants.GAMMA;
import static sbp.tcpf.support_admin.utils.TestConstants.P5;
import static sbp.tcpf.support_admin.utils.TestConstants.P6;
import static sbp.tcpf.support_admin.utils.TestConstants.S5;
import static sbp.tcpf.support_admin.utils.TestConstants.S6;
import static sbp.tcpf.support_admin.utils.TestConstants.SEM_1;
import static sbp.tcpf.support_admin.utils.TestConstants.SEM_2;

import feign.FeignException;

@WithUserDetails(FIRST_ADMIN)
@EnableWireMock({
        @ConfigureWireMock(name = "routing", property = "tcpf-platform-admin-app.tcpf-routing-app-os.uri"),
        @ConfigureWireMock(name = "forced-replication", property = "tcpf-platform-admin-app.tcpf-forced-replication-app.uri"),
})
@EnableConfigurationProperties({
        RoutingAppOsProperties.class,
        ForcedReplicationProperties.class,
})
@AutoConfigureMockMvc(addFilters = false)
@WebMvcTest(ClusterManagementController.class)
@Import({
        NodeManagementService.class,
        SemaphoreMapperImpl.class,
        PoolManagerService.class,
        PoolStateMapperImpl.class,
        UpdateShardMapperImpl.class,
        SemaphoreManagementService.class,
        ClusterStateMapperImpl.class,
        FeignClientsTestConfig.class,
        AuditTestConfig.class,
        SecurityTestConfig.class,
        MetadataManagementService.class,
        MetadataMapperImpl.class,
        CommonTestConfig.class,
        ShardMapperImpl.class,
        DefaultForcedReplicationService.class,
        UnsupportedForcedReplicationService.class,
        OperationResponseMapperImpl.class,
        ServiceModeStateMapperImpl.class,
        ServiceModeStatusMapperImpl.class,
        ReplicationStatusMapperImpl.class,
})
class ClusterManagementControllerTest {

    private static final String URL = "/invoke/support-admin/cluster-management-service";
    private static final int SHARD_ID = 1;
    private static final String REGION = "moscow";
    private static final String NODE_KEY = "node_A";
    private static final String CLUSTER_KEY_A = "cluster_A";
    private static final String CLUSTER_KEY_B = "cluster_B";

    @InjectWireMock("routing")
    WireMockServer routingWiremock;
    @InjectWireMock("forced-replication")
    WireMockServer replicationWiremock;
    @MockitoSpyBean
    SemaphoreClusterManagementApiClient semaphoreClusterManagementApiClient;
    @MockitoSpyBean
    ConnectionPoolManagementApiClient connectionPoolManagementApiClient;
    @MockitoSpyBean
    RoutingManagementApiClient routingManagementApiClient;
    @MockitoSpyBean
    NoOpEventListener listener;
    @Captor
    ArgumentCaptor<Event> eventArgumentCaptor;
    @Autowired
    MockMvc mockMvc;
    @Autowired
    ObjectMapper objectMapper;

    private record UpdateClusterStateDto(String clusterKey, ChangeClusterStateRequest params) {
    }

    @Test
    void shouldReturnSemaphores() throws Exception {
        routingWiremock.stubFor(WireMock.get("/api/v1/semaphore-cluster-management/clusters").willReturn(okJson(
                objectMapper.writeValueAsString(getClusters())
        )));

        MockHttpServletResponse response = AsyncMvc.perform(mockMvc, get(URL + "/semaphores"))
                                                   .andDo(print())
                                                   .andExpect(status().isOk())
                                                   .andReturn().getResponse();

        List<Semaphore> result = AsyncMvc.readList(objectMapper, response, Semaphore.class);

        then(listener).should(atLeastOnce()).listen(eventArgumentCaptor.capture());
        Event event = eventArgumentCaptor.getValue();
        thenEventSatisfies(event, AuditAssertions.EventExpectations.of()
                                                                   .eventName("VIEW_SEMAPHORES_INFO")
                                                                   .paramsAsserts(List.of(
                                                                           of("userLogin", value -> assertThat(value).isEqualTo(FIRST_ADMIN))
                                                                   )));

        assertThat(result)
                .hasSize(2)
                .allSatisfy(semaphore -> assertThat(semaphore.getClusterKey()).isNotNull())
                .extracting(Semaphore::getClusterKey)
                .containsExactlyInAnyOrder(SEM_1, SEM_2);
    }

    @Test
    void shouldThrowWhenRoutingAppNotAvailableWhileRequestsSemaphores() throws Exception {
        routingWiremock.stubFor(WireMock.get("/api/v1/semaphore-cluster-management/clusters").willReturn(WireMock.serverError()));

        AsyncMvc.perform(mockMvc, get(URL + "/semaphores"))
                .andDo(print())
                .andExpect(status().isInternalServerError())
                .andExpect(result -> assertThat(result.getResolvedException())
                        .isInstanceOf(FeignException.class));

        then(listener).should(atLeastOnce()).listen(eventArgumentCaptor.capture());
        Event event = eventArgumentCaptor.getValue();
        thenEventSatisfies(event, AuditAssertions.EventExpectations.of()
                                                                   .eventName("VIEW_SEMAPHORES_INFO_ERROR")
                                                                   .paramsAsserts(List.of(
                                                                           of("userLogin", value -> assertThat(value).isEqualTo(FIRST_ADMIN)),
                                                                           of("errorMessage", value -> assertThat(value).isNotBlank())
                                                                   )));
    }

    private static List<UpdateClusterStateDto> getActivateClusterStateRequests() {
        return List.of(
                new UpdateClusterStateDto(CLUSTER_KEY_A, ChangeClusterStateRequest.builder()
                                                                                  .status(ClusterState.ACTIVE)
                                                                                  .build()),
                new UpdateClusterStateDto(CLUSTER_KEY_A, ChangeClusterStateRequest.builder()
                                                                                  .status(ClusterState.ACTIVE)
                                                                                  .createModel(true)
                                                                                  .build()),
                new UpdateClusterStateDto(CLUSTER_KEY_A, ChangeClusterStateRequest.builder()
                                                                                  .status(ClusterState.ACTIVE)
                                                                                  .restoreRanges(true)
                                                                                  .build()),
                new UpdateClusterStateDto(CLUSTER_KEY_A, ChangeClusterStateRequest.builder()
                                                                                  .status(ClusterState.ACTIVE)
                                                                                  .createModel(true)
                                                                                  .restoreRanges(true)
                                                                                  .build())
        );
    }

    private static List<UpdateClusterStateDto> getDeactivateClusterStateRequests() {
        return List.of(
                new UpdateClusterStateDto(CLUSTER_KEY_A, ChangeClusterStateRequest.builder()
                                                                                  .status(ClusterState.INACTIVE)
                                                                                  .build()),
                new UpdateClusterStateDto(CLUSTER_KEY_A, ChangeClusterStateRequest.builder()
                                                                                  .status(ClusterState.INACTIVE)
                                                                                  .switchRanges(true)
                                                                                  .build()),
                new UpdateClusterStateDto(CLUSTER_KEY_B, ChangeClusterStateRequest.builder()
                                                                                  .status(ClusterState.INACTIVE)
                                                                                  .switchRanges(true)
                                                                                  .createModel(true)
                                                                                  .build()),
                new UpdateClusterStateDto(CLUSTER_KEY_A, ChangeClusterStateRequest.builder()
                                                                                  .status(ClusterState.INACTIVE)
                                                                                  .switchRanges(true)
                                                                                  .createModel(true)
                                                                                  .restoreRanges(true)
                                                                                  .build()),
                new UpdateClusterStateDto(CLUSTER_KEY_A, ChangeClusterStateRequest.builder()
                                                                                  .status(ClusterState.INACTIVE)
                                                                                  .switchRanges(false)
                                                                                  .createModel(true)
                                                                                  .restoreRanges(true)
                                                                                  .build())
        );
    }

    @ParameterizedTest
    @MethodSource("getActivateClusterStateRequests")
    void shouldActivateSemaphore(UpdateClusterStateDto request) throws Exception {
        var clusterKey = request.clusterKey;
        var restoreRangesFlag = request.params.getRestoreRanges();
        var createModelFlag = request.params.getCreateModel();

        routingWiremock.stubFor(WireMock.put(urlPathTemplate("/api/v1/semaphore-cluster-management/clusters/{keys}"))
                                        .withPathParam("keys", equalTo(clusterKey))
                                        .willReturn(WireMock.okJson(objectMapper.writeValueAsString(
                                                List.of(new Cluster(clusterKey, ClusterStatus.ACTIVE, 100L, OffsetDateTime.now(), "dc1"))
                                        ))));

        AsyncMvc.perform(mockMvc, patch(URL + "/semaphores/{clusterKey}/status", clusterKey)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request.params)))
                .andDo(print())
                .andExpect(status().isOk());

        // тело запроса теперь передаётся как Mono<ClusterUpdate>, поэтому сверяем его не по значению,
        // а через WireMock-стаб выше
        then(semaphoreClusterManagementApiClient).should(atMostOnce()).updateClustersByKey(
                eq(List.of(clusterKey)),
                any(),
                any(), any(), any(), any(),
                eq(restoreRangesFlag),
                eq(createModelFlag)
        );
        then(semaphoreClusterManagementApiClient).should(never()).newClusterModeByKey(any(), any(), any(), any(), any(), any());

        then(listener).should(atLeastOnce()).listen(eventArgumentCaptor.capture());
        Event event = eventArgumentCaptor.getValue();
        thenEventSatisfies(event, AuditAssertions.EventExpectations.of()
                                                                   .eventName("MANAGE_SEMAPHORE")
                                                                   .paramsAsserts(List.of(
                                                                           of("userLogin", value -> assertThat(value).isEqualTo(FIRST_ADMIN)),
                                                                           of("semaphoreId", value -> assertThat(value).isEqualTo(clusterKey)),
                                                                           of("process", value -> assertThat(value).isEqualTo("change cluster state"))
                                                                   )));
    }

    @ParameterizedTest
    @MethodSource("getDeactivateClusterStateRequests")
    void shouldDeactivateSemaphore(UpdateClusterStateDto request) throws Exception {
        var clusterKey = request.clusterKey;
        var switchRangesFlag = request.params.getSwitchRanges();

        routingWiremock.stubFor(WireMock.put(urlPathTemplate("/api/v1/semaphore-cluster-management/clusters/{keys}"))
                                        .withPathParam("keys", equalTo(clusterKey))
                                        .willReturn(WireMock.okJson(objectMapper.writeValueAsString(
                                                List.of(new Cluster(clusterKey, ClusterStatus.CREATING, 100L, OffsetDateTime.now(), "dc1"))
                                        ))));

        routingWiremock.stubFor(WireMock.post(urlPathTemplate("/api/v1/semaphore-cluster-management/clusters/{keys}"))
                                        .withPathParam("keys", equalTo(clusterKey))
                                        .willReturn(WireMock.okJson(objectMapper.writeValueAsString(
                                                List.of(new Cluster(clusterKey, ClusterStatus.CREATING, 100L, OffsetDateTime.now(), "dc1"))
                                        ))));

        AsyncMvc.perform(mockMvc, patch(URL + "/semaphores/{clusterKey}/status", clusterKey)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request.params)))
                .andDo(print())
                .andExpect(status().isOk());

        then(semaphoreClusterManagementApiClient).should().updateClustersByKey(
                eq(List.of(clusterKey)),
                any(),
                any(), any(), any(), any(),
                eq(null),
                eq(null));

        if (Boolean.TRUE.equals(switchRangesFlag)) {
            verify(semaphoreClusterManagementApiClient).newClusterModeByKey(eq(List.of(clusterKey)), any(), any(), any(), any(), any());
        } else {
            verify(semaphoreClusterManagementApiClient, never()).newClusterModeByKey(eq(List.of(clusterKey)), any(), any(), any(), any(), any());
        }

        then(listener).should(atLeastOnce()).listen(eventArgumentCaptor.capture());
        Event event = eventArgumentCaptor.getValue();
        thenEventSatisfies(event, AuditAssertions.EventExpectations.of()
                                                                   .eventName("MANAGE_SEMAPHORE")
                                                                   .paramsAsserts(List.of(
                                                                           of("userLogin", value -> assertThat(value).isEqualTo(FIRST_ADMIN)),
                                                                           of("semaphoreId", value -> assertThat(value).isEqualTo(clusterKey)),
                                                                           of("process", value -> assertThat(value).isEqualTo("change cluster state"))
                                                                   )));
    }

    @ParameterizedTest
    @MethodSource({"getDeactivateClusterStateRequests", "getActivateClusterStateRequests"})
    void shouldThrowWhenUnsuccessfullyChangedSemaphoreState(UpdateClusterStateDto request) throws Exception {
        var switchRangesFlag = request.params.getSwitchRanges();
        var clusterKey = request.clusterKey;

        routingWiremock.stubFor(WireMock.put(urlPathTemplate("/api/v1/semaphore-cluster-management/clusters/{keys}"))
                                        .withPathParam("keys", equalTo(clusterKey))
                                        .willReturn(serverError()));

        routingWiremock.stubFor(WireMock.post(urlPathTemplate("/api/v1/semaphore-cluster-management/clusters/{keys}"))
                                        .withPathParam("keys", equalTo(clusterKey))
                                        .willReturn(serverError()));

        AsyncMvc.perform(mockMvc, patch(URL + "/semaphores/{clusterKey}/status", clusterKey)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request.params)))
                .andDo(print())
                .andExpect(status().isInternalServerError())
                .andExpect(result -> assertThat(result.getResolvedException()).isInstanceOf(FeignException.class));

        if (!Boolean.TRUE.equals(switchRangesFlag)) {
            verify(semaphoreClusterManagementApiClient, never()).newClusterModeByKey(any(), any(), any(), any(), any(), any());
        }

        then(listener).should(atLeastOnce()).listen(eventArgumentCaptor.capture());
        Event event = eventArgumentCaptor.getValue();
        thenEventSatisfies(event, AuditAssertions.EventExpectations.of()
                                                                   .eventName("MANAGE_SEMAPHORE_ERROR")
                                                                   .paramsAsserts(List.of(
                                                                           of("userLogin", value -> assertThat(value).isEqualTo(FIRST_ADMIN)),
                                                                           of("semaphoreId", value -> assertThat(value).isEqualTo(clusterKey)),
                                                                           of("process", value -> assertThat(value).isEqualTo("change cluster state")),
                                                                           of("errorMessage", value -> assertThat(value).isNotBlank())
                                                                   )));
    }

    @Test
    void shouldReturnShards() throws Exception {
        routingWiremock.stubFor(WireMock.get("/api/v1/routing-management/shard")
                                        .willReturn(okJson(objectMapper.writeValueAsString(getRanges()))));

        MockHttpServletResponse response = AsyncMvc.perform(mockMvc, get(URL + "/shard"))
                                                   .andDo(print())
                                                   .andExpect(status().isOk())
                                                   .andReturn().getResponse();

        List<Shard> shards = AsyncMvc.readList(objectMapper, response, Shard.class);

        assertThat(shards)
                .hasSize(3)
                .allSatisfy(shard -> {
                    assertThat(shard.getId()).isNotNull();
                    assertThat(shard.getBucketRanges()).isNotEmpty();
                    // узлы без назначенного региона нормализуются к дефолтному региону (default-region: moscow)
                    assertThat(shard.getRegion())
                            .singleElement()
                            .satisfies(region -> assertThat(region.getRegion()).isEqualTo("moscow"));
                })
                .extracting(Shard::getId)
                .containsExactlyInAnyOrder(1005, 1006, 1);
    }

    @Test
    void shouldReturnPools() throws Exception {
        routingWiremock.stubFor(WireMock.get("/api/v1/connection-pool-management/pools")
                                        .willReturn(okJson(objectMapper.writeValueAsString(getPoolStates()))));

        MockHttpServletResponse response = AsyncMvc.perform(mockMvc, get(URL + "/pools"))
                                                   .andDo(print())
                                                   .andExpect(status().isOk())
                                                   .andReturn().getResponse();

        List<Pool> pools = AsyncMvc.readList(objectMapper, response, Pool.class);

        assertThat(pools)
                .hasSize(6)
                .allSatisfy(pool -> assertThat(pool.getKey()).isNotBlank())
                .extracting(Pool::getStatus)
                .containsOnly(PoolState.ACTIVE, PoolState.SUSPENDED);
    }

    @Test
    void shouldReturnNodeInfo() throws Exception {
        routingWiremock.stubFor(WireMock.get("/api/v1/routing-management/nodes")
                                        .willReturn(okJson(objectMapper.writeValueAsString(getNodes()))));

        MockHttpServletResponse response = AsyncMvc.perform(mockMvc, get(URL + "/nodes"))
                                                   .andDo(print())
                                                   .andExpect(status().isOk())
                                                   .andReturn().getResponse();

        List<Node> nodes = AsyncMvc.readList(objectMapper, response, Node.class);

        assertThat(nodes)
                .hasSize(6)
                .allSatisfy(node -> assertThat(node.getKey()).isNotBlank());

        then(listener).should(atLeastOnce()).listen(eventArgumentCaptor.capture());
        Event event = eventArgumentCaptor.getValue();
        thenEventSatisfies(event, AuditAssertions.EventExpectations.of()
                                                                   .eventName("VIEW_SHARDS_INFO")
                                                                   .paramsAsserts(List.of(
                                                                           of("userLogin", value -> assertThat(value).isEqualTo(FIRST_ADMIN))
                                                                   )));
    }

    @Test
    void shouldThrowWhenRoutingAppNotAvailable() throws Exception {
        routingWiremock.stubFor(WireMock.get("/api/v1/routing-management/nodes")
                                        .willReturn(serviceUnavailable()));

        AsyncMvc.perform(mockMvc, get(URL + "/nodes"))
                .andDo(print())
                .andExpect(status().is5xxServerError())
                .andExpect(result -> assertThat(result.getResolvedException())
                        .isInstanceOf(FeignException.class));

        then(listener).should(atLeastOnce()).listen(eventArgumentCaptor.capture());
        Event event = eventArgumentCaptor.getValue();
        thenEventSatisfies(event, AuditAssertions.EventExpectations.of()
                                                                   .eventName("VIEW_SHARDS_INFO_ERROR")
                                                                   .paramsAsserts(List.of(
                                                                           of("userLogin", value -> assertThat(value).isEqualTo(FIRST_ADMIN)),
                                                                           of("errorMessage", value -> assertThat(value).isNotBlank())
                                                                   )));
    }

    @Test
    void shouldManageShardState() throws Exception {
        var request = getShardUpdate();

        routingWiremock.stubFor(WireMock.put(urlPathTemplate("/api/v1/routing-management/shard/{ids}/nodes"))
                                        .withPathParam("ids", equalTo(String.valueOf(SHARD_ID)))
                                        .withHeader("X-Region", equalTo(REGION))
                                        .willReturn(WireMock.okJson(objectMapper.writeValueAsString(getRanges()))));

        MockHttpServletResponse response = AsyncMvc.perform(mockMvc, put(URL + "/shard/{ids}/nodes", SHARD_ID)
                                                           .header("X-Region", REGION)
                                                           .content(objectMapper.writeValueAsString(request))
                                                           .contentType(MediaType.APPLICATION_JSON))
                                                   .andDo(print())
                                                   .andExpect(status().isOk())
                                                   .andReturn().getResponse();

        assertThat(AsyncMvc.readList(objectMapper, response, Shard.class)).isNotEmpty();

        then(routingManagementApiClient).should().updateNodesOfShardById(
                eq(List.of(SHARD_ID)), any(), any(), any(), any(), any(), eq(REGION)
        );

        then(listener).should(atLeastOnce()).listen(eventArgumentCaptor.capture());
        Event event = eventArgumentCaptor.getValue();
        thenEventSatisfies(event, AuditAssertions.EventExpectations.of()
                                                                   .eventName("MANAGE_RANGES")
                                                                   .paramsAsserts(List.of(
                                                                           of("userLogin", value -> assertThat(value).isEqualTo(FIRST_ADMIN)),
                                                                           of("shardId", value -> assertThat(value).isNotBlank()),
                                                                           of("bucketBoundary", value -> assertThat(value).isNotBlank())
                                                                   )));
    }

    @Test
    void shouldUpdateShardSemaphores() throws Exception {
        var request = getBucketRangeUpdate();

        routingWiremock.stubFor(WireMock.put(urlPathTemplate("/api/v1/routing-management/shard/{id}/semaphores"))
                                        .withPathParam("id", equalTo(String.valueOf(SHARD_ID)))
                                        .withHeader("X-Region", equalTo(REGION))
                                        .willReturn(WireMock.okJson(objectMapper.writeValueAsString(getRanges()))));

        MockHttpServletResponse response = AsyncMvc.perform(mockMvc, put(URL + "/shard/{id}/semaphores", SHARD_ID)
                                                           .header("X-Region", REGION)
                                                           .content(objectMapper.writeValueAsString(request))
                                                           .contentType(MediaType.APPLICATION_JSON))
                                                   .andDo(print())
                                                   .andExpect(status().isOk())
                                                   .andReturn().getResponse();

        assertThat(AsyncMvc.readList(objectMapper, response, Shard.class)).isNotEmpty();

        then(routingManagementApiClient).should().updateSemaphoresOfShardById(
                eq(SHARD_ID), any(), any(), any(), any(), any(), eq(REGION)
        );
    }

    @Test
    void shouldThrowWhenUnsuccessfulManageRanges() throws Exception {
        routingWiremock.stubFor(WireMock.put(urlPathTemplate("/api/v1/routing-management/shard/{ids}/nodes"))
                                        .withPathParam("ids", equalTo(String.valueOf(SHARD_ID)))
                                        .willReturn(WireMock.serverError())
        );

        var request = getShardUpdate();

        AsyncMvc.perform(mockMvc, put(URL + "/shard/{ids}/nodes", SHARD_ID)
                        .content(objectMapper.writeValueAsString(request))
                        .contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isInternalServerError())
                .andExpect(result -> assertThat(result.getResolvedException())
                        .isInstanceOf(FeignException.class));

        then(listener).should(atLeastOnce()).listen(eventArgumentCaptor.capture());
        Event event = eventArgumentCaptor.getValue();
        thenEventSatisfies(event, AuditAssertions.EventExpectations.of()
                                                                   .eventName("MANAGE_RANGES_ERROR")
                                                                   .paramsAsserts(List.of(
                                                                           of("userLogin", value -> assertThat(value).isEqualTo(FIRST_ADMIN)),
                                                                           of("shardId", value -> assertThat(value).isNotBlank()),
                                                                           of("bucketBoundary", value -> assertThat(value).isNotBlank()),
                                                                           of("errorMessage", value -> assertThat(value).isNotBlank())
                                                                   )));
    }

    @Test
    void shouldThrowWhenUnsuccessfulManageSemaphores() throws Exception {
        routingWiremock.stubFor(WireMock.put(urlPathTemplate("/api/v1/routing-management/shard/{id}/semaphores"))
                                        .withPathParam("id", equalTo(String.valueOf(SHARD_ID)))
                                        .willReturn(WireMock.serverError())
        );

        var request = getBucketRangeUpdate();

        AsyncMvc.perform(mockMvc, put(URL + "/shard/{id}/semaphores", SHARD_ID)
                        .content(objectMapper.writeValueAsString(request))
                        .contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isInternalServerError())
                .andExpect(result -> assertThat(result.getResolvedException())
                        .isInstanceOf(FeignException.class));
    }

    @ParameterizedTest
    @EnumSource(value = PoolState.class, names = {"ACTIVE", "SUSPENDED"})
    void shouldManagePoolStates(PoolState state) throws Exception {
        routingWiremock.stubFor(WireMock.put(urlPathTemplate("/api/v1/connection-pool-management/pools/{keys}"))
                                        .withPathParam("keys", equalTo(NODE_KEY))
                                        .willReturn(WireMock.okJson(objectMapper.writeValueAsString(getPoolStates()))));

        AsyncMvc.perform(mockMvc, put(URL + "/nodes/{nodeKey}/pools", NODE_KEY)
                        .queryParam("poolState", state.getValue())
                        .contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk());

        then(connectionPoolManagementApiClient).should(atMostOnce()).updatePoolsByKey(eq(List.of(NODE_KEY)), any(), any(), any(), any(), any(), any());
    }

    @ParameterizedTest
    @EnumSource(value = PoolState.class, names = {"ACTIVE", "SUSPENDED"})
    void shouldThrowWhenManagePoolStates(PoolState state) throws Exception {
        routingWiremock.stubFor(WireMock.put(urlPathTemplate("/api/v1/connection-pool-management/pools/{keys}"))
                                        .withPathParam("keys", equalTo(NODE_KEY))
                                        .willReturn(WireMock.serverError()));

        AsyncMvc.perform(mockMvc, put(URL + "/nodes/{nodeKey}/pools", NODE_KEY)
                        .queryParam("poolState", state.getValue())
                        .contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isInternalServerError())
                .andExpect(result -> assertThat(result.getResolvedException())
                        .isInstanceOf(FeignException.class));
    }

    @Test
    void shouldRefreshMetadata() throws Exception {
        routingWiremock.stubFor(WireMock.put(urlPathTemplate("/api/v1/metadata-management/metadatas/{keys}"))
                                        .withPathParam("keys", equalTo(NODE_KEY))
                                        .willReturn(okJson(objectMapper.writeValueAsString(getMetadata())))
        );

        MockHttpServletResponse response = AsyncMvc.perform(mockMvc, put(URL + "/nodes/{nodeKey}/metadatas", NODE_KEY))
                                                   .andDo(print())
                                                   .andExpect(status().is2xxSuccessful())
                                                   .andReturn().getResponse();

        Metadata metadata = AsyncMvc.readSingle(objectMapper, response, Metadata.class);

        assertThat(metadata).isNotNull();
    }

    @Test
    void shouldReturnServiceModeStatus() throws Exception {
        replicationWiremock.stubFor(WireMock.get(urlPathTemplate("/api/v1/service-mode"))
                                            .willReturn(okJson(objectMapper.writeValueAsString(
                                                    getServiceMode(
                                                            sbp.tcpf.forced.replication.model.ServiceModeState.DISABLED)
                                            )))
        );

        var response = AsyncMvc.perform(mockMvc, get(URL + "/service-mode"))
                               .andDo(print())
                               .andExpect(status().is2xxSuccessful())
                               .andReturn().getResponse();

        var status = objectMapper.readValue(response.getContentAsString(), ServiceModeStatusDto.class);

        assertThat(status.getStatus()).isEqualTo(ServiceModeState.DISABLED);
    }

    @ParameterizedTest
    @EnumSource(value = ServiceModeState.class, names = {
            "ENABLED",
            "DISABLED"
    })
    void shouldChangeServiceModeStatus(ServiceModeState state) throws Exception {
        replicationWiremock.stubFor(WireMock.put(urlPathTemplate("/api/v1/service-mode"))
                                            .willReturn(okJson(objectMapper.writeValueAsString(getOperationResponse())))
        );

        AsyncMvc.perform(mockMvc, put(URL + "/service-mode")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(UpdateServiceModeRequest.builder()
                                                                                         .status(state)
                                                                                         .build())
                        ))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    @Test
    void shouldReturnReplicationStatus() throws Exception {
        replicationWiremock.stubFor(WireMock.get(urlPathTemplate("/api/v1/shards/{shardId}/replication"))
                                            .withPathParam("shardId", equalTo(String.valueOf(SHARD_ID)))
                                            .willReturn(okJson(objectMapper.writeValueAsString(
                                                    getReplicationStatus(
                                                            sbp.tcpf.forced.replication.model.ReplicationState.REQUIRED
                                                    )
                                            )))
        );

        var response = AsyncMvc.perform(mockMvc, get(URL + "/shards/{shardId}/replication", SHARD_ID))
                               .andDo(print())
                               .andExpect(status().is2xxSuccessful())
                               .andReturn().getResponse();

        var status = objectMapper.readValue(response.getContentAsString(), ReplicationStatusDto.class);

        assertThat(status.getStatus()).isEqualTo(ReplicationState.REQUIRED);
    }

    @Test
    void shouldStartReplication() throws Exception {
        replicationWiremock.stubFor(WireMock.post(urlPathTemplate("/api/v1/shards/{shardId}/replication"))
                                            .withPathParam("shardId", equalTo(String.valueOf(SHARD_ID)))
                                            .willReturn(okJson(objectMapper.writeValueAsString(getOperationResponse())))
        );

        AsyncMvc.perform(mockMvc, post(URL + "/shards/{shardId}/replication", SHARD_ID))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    @Test
    void shouldUndoReplication() throws Exception {
        replicationWiremock.stubFor(WireMock.delete(urlPathTemplate("/api/v1/shards/{shardId}/replication"))
                                            .withPathParam("shardId", equalTo(String.valueOf(SHARD_ID)))
                                            .willReturn(okJson(objectMapper.writeValueAsString(getOperationResponse())))
        );

        AsyncMvc.perform(mockMvc, delete(URL + "/shards/{shardId}/replication", SHARD_ID))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    private ServiceModeStatus getServiceMode(sbp.tcpf.forced.replication.model.ServiceModeState state) {
        return ServiceModeStatus.builder()
                                .startedAt(OffsetDateTime.now())
                                .status(state)
                                .build();
    }

    private OperationResponse getOperationResponse() {
        return OperationResponse.builder()
                                .code(0)
                                .description("SUCCESS")
                                .build();
    }

    private ReplicationStatus getReplicationStatus(sbp.tcpf.forced.replication.model.ReplicationState replicationState) {
        return ReplicationStatus.builder()
                                .startedAt(OffsetDateTime.now())
                                .status(replicationState)
                                .build();
    }

    private List<SchemaMetadata> getMetadata() {
        return List.of(new SchemaMetadata("1.0.0", "2.0.0"));
    }

    private ShardUpdate getShardUpdate() {
        return ShardUpdate.builder()
                          .bucketBoundary(List.of(16_000))
                          .build();
    }

    private BucketRangeUpdate getBucketRangeUpdate() {
        return BucketRangeUpdate.builder()
                                .changedBucketRanges(List.of(
                                        sbp.tcpf.support_admin.model.BucketRange.builder()
                                                                                .nodeKey(ALPHA)
                                                                                .semaphoreClusterKey(SEM_1)
                                                                                .startInclusive(0)
                                                                                .endExclusive(5_000)
                                                                                .build(),
                                        sbp.tcpf.support_admin.model.BucketRange.builder()
                                                                                .nodeKey(GAMMA)
                                                                                .semaphoreClusterKey(SEM_2)
                                                                                .startInclusive(5_000)
                                                                                .endExclusive(32_768)
                                                                                .build()
                                ))
                                .build();
    }

    private List<sbp.tcpf.routing.api.v1_0.client.model.Shard> getRanges() {
        return List.of(
                sbp.tcpf.routing.api.v1_0.client.model.Shard.builder()
                                                            .id(1005)
                                                            .bucketRanges(
                                                                    List.of(
                                                                            BucketRange.builder()
                                                                                       .nodeKey(P5)
                                                                                       .semaphoreClusterKey(SEM_1)
                                                                                       .startInclusive(0)
                                                                                       .endExclusive(30_000)
                                                                                       .build(),
                                                                            BucketRange.builder()
                                                                                       .nodeKey(S5)
                                                                                       .semaphoreClusterKey(SEM_2)
                                                                                       .startInclusive(30_000)
                                                                                       .endExclusive(32_768)
                                                                                       .frozenSemaphoreCluster(true)
                                                                                       .build()
                                                                    )
                                                            )
                                                            .build(),
                sbp.tcpf.routing.api.v1_0.client.model.Shard.builder()
                                                            .id(1006)
                                                            .bucketRanges(
                                                                    List.of(
                                                                            BucketRange.builder()
                                                                                       .nodeKey(P6)
                                                                                       .semaphoreClusterKey(SEM_1)
                                                                                       .startInclusive(0)
                                                                                       .endExclusive(32_768)
                                                                                       .build()
                                                                    )
                                                            )
                                                            .build(),
                sbp.tcpf.routing.api.v1_0.client.model.Shard.builder()
                                                            .id(1)
                                                            .bucketRanges(
                                                                    List.of(
                                                                            BucketRange.builder()
                                                                                       .nodeKey(ALPHA)
                                                                                       .semaphoreClusterKey(SEM_1)
                                                                                       .startInclusive(0)
                                                                                       .endExclusive(32_768)
                                                                                       .build()
                                                                    )
                                                            )
                                                            .build()
        );
    }

    private List<sbp.tcpf.routing.api.v1_0.client.model.Node> getNodes() {
        return List.of(
                sbp.tcpf.routing.api.v1_0.client.model.Node.builder()
                                                           .key(P5)
                                                           .status(NodeStatus.WORKING)
                                                           .shardId(1005)
                                                           .id(1)
                                                           .build(),
                sbp.tcpf.routing.api.v1_0.client.model.Node.builder()
                                                           .key(S5)
                                                           .status(NodeStatus.WORKING)
                                                           .shardId(1005)
                                                           .id(2)
                                                           .build(),
                sbp.tcpf.routing.api.v1_0.client.model.Node.builder()
                                                           .key(P6)
                                                           .status(NodeStatus.WORKING)
                                                           .shardId(1006)
                                                           .id(3)
                                                           .build(),
                sbp.tcpf.routing.api.v1_0.client.model.Node.builder()
                                                           .key(S6)
                                                           .status(NodeStatus.SLEEPING)
                                                           .shardId(1006)
                                                           .id(4)
                                                           .build(),
                sbp.tcpf.routing.api.v1_0.client.model.Node.builder()
                                                           .key(ALPHA)
                                                           .status(NodeStatus.WORKING)
                                                           .shardId(1)
                                                           .id(5)
                                                           .build(),
                sbp.tcpf.routing.api.v1_0.client.model.Node.builder()
                                                           .key(GAMMA)
                                                           .status(NodeStatus.SLEEPING)
                                                           .shardId(1)
                                                           .id(6)
                                                           .build()
        );
    }

    private List<sbp.tcpf.routing.api.v1_0.client.model.Pool> getPoolStates() {
        return List.of(
                sbp.tcpf.routing.api.v1_0.client.model.Pool.builder()
                                                           .key(P5)
                                                           .status(PoolStatus.ACTIVE)
                                                           .build(),
                sbp.tcpf.routing.api.v1_0.client.model.Pool.builder()
                                                           .key(S5)
                                                           .status(PoolStatus.ACTIVE)
                                                           .build(),
                sbp.tcpf.routing.api.v1_0.client.model.Pool.builder()
                                                           .key(P6)
                                                           .status(PoolStatus.ACTIVE)
                                                           .build(),
                sbp.tcpf.routing.api.v1_0.client.model.Pool.builder()
                                                           .key(S6)
                                                           .status(PoolStatus.SUSPENDED)
                                                           .build(),
                sbp.tcpf.routing.api.v1_0.client.model.Pool.builder()
                                                           .key(ALPHA)
                                                           .status(PoolStatus.ACTIVE)
                                                           .build(),
                sbp.tcpf.routing.api.v1_0.client.model.Pool.builder()
                                                           .key(GAMMA)
                                                           .status(PoolStatus.SUSPENDED)
                                                           .build()
        );
    }

    private List<Cluster> getClusters() {
        return List.of(
                Cluster.builder()
                       .key(SEM_1)
                       .status(ClusterStatus.ACTIVE)
                       .entriesCount(1000L)
                       .build(),
                Cluster.builder()
                       .key(SEM_2)
                       .status(ClusterStatus.ACTIVE)
                       .entriesCount(20L)
                       .build()
        );
    }
}
