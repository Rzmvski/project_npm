package sbp.tcpf.support_admin.validators;

import sbp.tcpf.routing.client.core.uow.UnitOfWorkOperations;
import sbp.tcpf.support_admin.config.CommonTestConfig;
import sbp.tcpf.support_admin.configs.properties.ScriptServiceProperties;
import sbp.tcpf.support_admin.controllers.ScriptController;
import sbp.tcpf.support_admin.exceptions.ValidationException;
import sbp.tcpf.support_admin.model.CreateScriptApplicationRequest;
import sbp.tcpf.support_admin.model.Restrictions;
import sbp.tcpf.support_admin.model.ScriptApplication;
import sbp.tcpf.support_admin.services.ScriptDetailsService;
import sbp.tcpf.support_admin.services.ScriptTemplateService;
import sbp.tcpf.support_admin.services.ShellBeansService;
import sbp.tcpf.support_admin.services.request.RequestService;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.aop.AopAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.bean.override.mockito.MockitoSpyBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.validation.Errors;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Collections;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.then;
import static org.mockito.Mockito.only;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import jakarta.persistence.EntityManager;

@EnableConfigurationProperties(ScriptServiceProperties.class)
@TestPropertySource(
        properties = {
                "tcpf-platform-admin-app.script-service.max-script-size=100B",
        }
)
@AutoConfigureMockMvc(addFilters = false)
@WebMvcTest(ScriptController.class)
@ImportAutoConfiguration(AopAutoConfiguration.class)
@Import({
        CommonTestConfig.class,
        ScriptValidator.class,
        ScriptValidationAspect.class,
})
class ScriptValidatorTest {

    @MockitoBean
    ScriptDetailsService scriptDetailsService;
    @MockitoBean
    ShellBeansService shellBeansService;
    @MockitoBean
    ScriptTemplateService templateService;
    @MockitoBean
    RequestService<String, CreateScriptApplicationRequest, ScriptApplication> requestService;
    @MockitoBean
    UnitOfWorkOperations uow;
    @MockitoBean
    EntityManager em;
    @Captor
    ArgumentCaptor<Errors> errorCaptor;
    @MockitoSpyBean
    ScriptValidationAspect validationAspect;
    @MockitoSpyBean
    ScriptValidator validator;
    @Autowired
    MockMvc mockMvc;
    @Autowired
    ObjectMapper objectMapper;

    private static final String URL = "/invoke/support-admin/script-service/applications";
    private static final String SCRIPT_PATH = "src/test/resources/test_script.groovy";

    private CreateScriptApplicationRequest buildRequest(String scriptBody) {
        return CreateScriptApplicationRequest.builder()
                .jiraId("test")
                .reasonId("reasonId")
                .scriptBody(scriptBody)
                .restrictions(new Restrictions(false, Collections.emptyList()))
                .build();
    }

    @Test
    void shouldSuccessfulValidateScript() throws Exception {
        var request = buildRequest("log.info('tiny correct script')");

        mockMvc.perform(post(URL)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request))
        ).andExpect(status().isOk());

        then(validator).should(only()).validate(eq(request), errorCaptor.capture());

        assertThat(errorCaptor.getValue().getAllErrors()).isEmpty();
    }

    @Test
    void shouldValidateScriptSizeAndThrow() throws Exception {
        var script = Files.readString(Paths.get(SCRIPT_PATH));
        var request = buildRequest(script);

        mockMvc.perform(post(URL)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request))
        ).andExpect(status().isBadRequest());

        then(validator).should(only()).validate(eq(request), errorCaptor.capture());

        assertThatThrownBy(() -> validationAspect.validate(request)).isInstanceOf(ValidationException.class);
        assertThat(errorCaptor.getValue().getAllErrors())
                .isNotEmpty()
                .extracting(DefaultMessageSourceResolvable::getCode)
                .contains("scriptBody.tooLong");
    }
}
