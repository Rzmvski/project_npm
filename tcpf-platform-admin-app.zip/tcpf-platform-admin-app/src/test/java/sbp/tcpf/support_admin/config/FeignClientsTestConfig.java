package sbp.tcpf.support_admin.config;

import sbp.tcpf.support_admin.configs.AsyncConfig;
import sbp.tcpf.support_admin.configs.FeignConfig;
import sbp.tcpf.support_admin.configs.converters.OptionalToStringConverter;
import sbp.tcpf.support_admin.configs.converters.SseObjectHttpMessageConverter;
import sbp.tcpf.support_admin.configs.feign.FeignControllerAdvice;

import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.cloud.loadbalancer.config.LoadBalancerAutoConfiguration;
import org.springframework.cloud.openfeign.FeignAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.web.reactive.function.client.WebClient;

import reactivefeign.spring.config.ReactiveFeignAutoConfiguration;

@TestConfiguration
@ImportAutoConfiguration({
        FeignAutoConfiguration.class,
        ReactiveFeignAutoConfiguration.class,
        LoadBalancerAutoConfiguration.class,
})
@Import({
        FeignConfig.class,
        AsyncConfig.class,
        FeignControllerAdvice.class,
        SseObjectHttpMessageConverter.class,
        OptionalToStringConverter.class,
})
public class FeignClientsTestConfig {

    @Bean
    @ConditionalOnMissingBean
    public WebClient.Builder webClientBuilder() {
        return WebClient.builder();
    }
}
