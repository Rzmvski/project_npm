package sbp.tcpf.support_admin;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@Disabled
@AutoConfigureObservability
@SpringBootTest
class PlatformAdminApplicationTest {

    @Autowired
    PlatformAdminApplication platformAdminApplication;

    @Test
    void contextLoads() {
        assertNotNull(platformAdminApplication);
    }
}
