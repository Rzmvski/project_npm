package sbp.tcpf.support_admin.controllers;

import sbp.tcpf.routing.index.info.dto.Action;
import sbp.tcpf.routing.index.info.dto.ClusterDetails;
import sbp.tcpf.routing.index.info.dto.RoutingIndexInfoRs;
import sbp.tcpf.routing.index.info.dto.State;
import sbp.tcpf.routing.index.info.dto.StatusType;
import sbp.tcpf.routing.index.manage.dto.RoutingIndexManageRs;
import sbp.tcpf.support_admin.clients.grpc.ZoneIndexGrpcRequestExecutor;
import sbp.tcpf.support_admin.config.AuditTestConfig;
import sbp.tcpf.support_admin.config.CommonTestConfig;
import sbp.tcpf.support_admin.config.NoOpEventListener;
import sbp.tcpf.support_admin.config.SecurityTestConfig;
import sbp.tcpf.support_admin.mappers.ActionResponseMapperImpl;
import sbp.tcpf.support_admin.mappers.ClusterInfoMapperImpl;
import sbp.tcpf.support_admin.model.ActionRequest;
import sbp.tcpf.support_admin.model.AuditInfo;
import sbp.tcpf.support_admin.model.ClusterInfo;
import sbp.tcpf.support_admin.model.IndexActionResponse;
import sbp.tcpf.support_admin.model.IndexActions;
import sbp.tcpf.support_admin.model.StartActionWithIndexesRq;
import sbp.tcpf.support_admin.services.ZoneIndexService;
import sbp.tcpf.support_admin.utils.AuditAssertions;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbt.audit.core.model.v2.event.Event;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithUserDetails;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.bean.override.mockito.MockitoSpyBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import static org.apache.commons.lang3.tuple.Pair.of;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.BDDMockito.then;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static sbp.tcpf.support_admin.config.SecurityTestConfig.FIRST_ADMIN;
import static sbp.tcpf.support_admin.utils.AuditAssertions.thenEventSatisfies;

@WithUserDetails(FIRST_ADMIN)
@AutoConfigureMockMvc(addFilters = false)
@WebMvcTest(ZoneIndexController.class)
@Import({
        CommonTestConfig.class,
        ZoneIndexService.class,
        ClusterInfoMapperImpl.class,
        ActionResponseMapperImpl.class,
        AuditTestConfig.class,
        SecurityTestConfig.class,
})
class ZoneIndexControllerTest {

    private static final String URL = "/invoke/support-admin/zone-index-service/clusters";

    @MockitoBean
    ZoneIndexGrpcRequestExecutor zoneIndexGrpcRequestExecutor;
    @MockitoSpyBean
    NoOpEventListener listener;
    @Captor
    ArgumentCaptor<Event> eventArgumentCaptor;
    @Autowired
    ObjectMapper objectMapper;
    @Autowired
    MockMvc mockMvc;

    @Test
    void getClusterInfoTest() throws Exception {

        when(zoneIndexGrpcRequestExecutor.getClusterInfo()).thenReturn(getRoutingIndexInfoRs());

        MvcResult mvcResult = mockMvc.perform(get(URL)
                        .contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andReturn();

        List<ClusterInfo> clusterInfos = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), new TypeReference<>() {});

        then(listener).should().listen(eventArgumentCaptor.capture());
        Event event = eventArgumentCaptor.getValue();
        thenEventSatisfies(event, AuditAssertions.EventExpectations.of()
                                                                   .eventName("VIEW_CLUSTER_INFO")
                                                                   .paramsAsserts(List.of(
                                                                           of("userLogin", value -> assertThat(value).isEqualTo(FIRST_ADMIN)),
                                                                           of("additionalParams", value -> assertThat(value).isNull())
                                                                   )));

        assertNotNull(clusterInfos);
        assertEquals(3, clusterInfos.size());
        assertEquals(Boolean.TRUE, clusterInfos.get(0).getUpdateRequired());
        assertEquals(Boolean.FALSE, clusterInfos.get(1).getUpdateRequired());
        assertEquals(Boolean.TRUE, clusterInfos.get(2).getUpdateRequired());
    }

    private RoutingIndexInfoRs getRoutingIndexInfoRs() {
        return RoutingIndexInfoRs.newBuilder()
                .addClusterDetails(ClusterDetails.newBuilder()
                        .setClusterId("1")
                        .setState(State.ON_LOADING)
                        .addAvailableActions(Action.CANCEL_LOADING)
                        .setEntriesCount(100L)
                        .build())
                .addClusterDetails(ClusterDetails.newBuilder()
                        .setClusterId("2")
                        .setState(State.ACTIVE)
                        .addAvailableActions(Action.DEACTIVATE)
                        .setEntriesCount(100L)
                        .build())
                .addClusterDetails(ClusterDetails.newBuilder()
                        .setClusterId("3")
                        .setState(State.CREATING)
                        .addAvailableActions(Action.CANCEL_LOADING)
                        .setEntriesCount(100L)
                        .build())
                .setStatus(StatusType.newBuilder()
                        .setCode(0)
                        .setDescription("SUCCESS")
                        .build())
                .build();
    }

    @Test
    void startActionWithIndexesTest() throws Exception {

        when(zoneIndexGrpcRequestExecutor.doActionForCluster(any())).thenReturn(getRoutingIndexManageRs());

        StartActionWithIndexesRq request = StartActionWithIndexesRq.builder()
                .rqUid(UUID.randomUUID().toString().replace("-", ""))
                .rqTm(LocalDateTime.now())
                .actionRequest(ActionRequest.builder()
                        .clusterId("1")
                        .action(IndexActions.CREATE_INDEX)
                        .build())
                .auditInfo(AuditInfo.builder().build())
                .build();

        MvcResult mvcResult = mockMvc.perform(post(URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andDo(print())
                .andExpect(status().isOk())
                .andReturn();

        IndexActionResponse response = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), IndexActionResponse.class);

        then(listener).should().listen(eventArgumentCaptor.capture());
        Event event = eventArgumentCaptor.getValue();
        thenEventSatisfies(event, AuditAssertions.EventExpectations.of()
                                                                   .eventName("MANAGE_INDEXES")
                                                                   .paramsAsserts(List.of(
                                                                           of("userLogin", value -> assertThat(value).isEqualTo(FIRST_ADMIN)),
                                                                           of("additionalParams", value -> assertThat(value).isNull())
                                                                   )));

        assertNotNull(response);
    }

    private RoutingIndexManageRs getRoutingIndexManageRs() {
        return RoutingIndexManageRs.newBuilder()
                .setStatus(sbp.tcpf.routing.index.manage.dto.StatusType.newBuilder()
                        .setCode(0)
                        .setDescription("SUCCESS")
                        .build())
                .build();
    }
}
