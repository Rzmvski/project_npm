package sbp.tcpf.support_admin.controllers;

import sbp.tcpf.os.commons.config.ModuleProperties;
import sbp.tcpf.routing.api.v1_0.client.model.Error;
import sbp.tcpf.routing.api.v1_0.client.model.TrafficRestriction;
import sbp.tcpf.support_admin.config.CommonTestConfig;
import sbp.tcpf.support_admin.config.FeignClientsTestConfig;
import sbp.tcpf.support_admin.config.SecurityTestConfig;
import sbp.tcpf.support_admin.configs.properties.RoutingAppOsProperties;
import sbp.tcpf.support_admin.mappers.GeoBalancingServiceMapperImpl;
import sbp.tcpf.support_admin.mappers.TrafficRestrictionMapperImpl;
import sbp.tcpf.support_admin.model.TrafficRestrictionDto;
import sbp.tcpf.support_admin.services.GeoBalancingService;
import sbp.tcpf.support_admin.utils.AsyncMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.maciejwalkowiak.wiremock.spring.ConfigureWireMock;
import com.maciejwalkowiak.wiremock.spring.EnableWireMock;
import com.maciejwalkowiak.wiremock.spring.InjectWireMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.test.context.support.WithUserDetails;
import org.springframework.test.web.servlet.MockMvc;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Set;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.deleteRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.equalToJson;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.putRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static sbp.tcpf.support_admin.config.SecurityTestConfig.FIRST_ADMIN;

import feign.FeignException;

@WithUserDetails(FIRST_ADMIN)
@EnableWireMock({
        @ConfigureWireMock(name = "routing", property = "tcpf-platform-admin-app.tcpf-routing-app-os.uri")
})
@EnableConfigurationProperties(RoutingAppOsProperties.class)
@AutoConfigureMockMvc(addFilters = false)
@WebMvcTest(GeoBalancingController.class)
@Import({
        GeoBalancingService.class,
        TrafficRestrictionMapperImpl.class,
        GeoBalancingServiceMapperImpl.class,
        FeignClientsTestConfig.class,
        SecurityTestConfig.class,
        CommonTestConfig.class
})
class GeoBalancingControllerTest {

    private static final String URL = "/invoke/support-admin/geo-balancing";

    @InjectWireMock("routing")
    WireMockServer wiremock;
    @Autowired
    MockMvc mockMvc;
    @Autowired
    ObjectMapper objectMapper;
    @Autowired
    ModuleProperties moduleProperties;

    @BeforeEach
    void setUp() {
        wiremock.resetAll();
    }

    private TrafficRestrictionDto createRestrictionDto(String id) {
        return TrafficRestrictionDto.builder()
                                    .id(id)
                                    .name("name")
                                    .dataCenters(List.of("dataCenter1"))
                                    .services(List.of("service1"))
                                    .build();
    }

    private TrafficRestriction createTrafficRestriction(String id) {
        return new TrafficRestriction()
                .id(id)
                .dataCenters(List.of("dataCenter1"))
                .services(List.of("service1"));
    }

    @Test
    void shouldCreateTrafficRestriction() throws Exception {
        String restrictionId = "test-id-1";
        TrafficRestrictionDto requestDto = createRestrictionDto(restrictionId);
        TrafficRestriction routingResponse = createTrafficRestriction(restrictionId);

        wiremock.stubFor(WireMock.post(urlEqualTo("/api/v1/geo-balancing/traffic-restrictions"))
                                 .withHeader("X-System-Id", equalTo(moduleProperties.getModuleId()))
                                 .withHeader("X-User-Login", equalTo(FIRST_ADMIN))
                                 .withRequestBody(equalToJson(objectMapper.writeValueAsString(requestDto)))
                                 .willReturn(aResponse()
                                                     .withStatus(200)
                                                     .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                                     .withBody(objectMapper.writeValueAsString(routingResponse))));

        MockHttpServletResponse response = AsyncMvc.perform(mockMvc, post(URL + "/traffic-restrictions")
                                                           .contentType(MediaType.APPLICATION_JSON)
                                                           .content(objectMapper.writeValueAsString(requestDto)))
                                                   .andDo(print())
                                                   .andExpect(status().is2xxSuccessful())
                                                   .andReturn().getResponse();

        TrafficRestrictionDto result = AsyncMvc.readSingle(objectMapper, response, TrafficRestrictionDto.class);
        assertThat(result).isNotNull();
        assertThat(result.getId()).isEqualTo(restrictionId);

        wiremock.verify(1, postRequestedFor(urlEqualTo("/api/v1/geo-balancing/traffic-restrictions")));
    }

    @Test
    void shouldThrowOnCreateTrafficRestriction() throws Exception {
        String restrictionId = "test-id-1";
        TrafficRestrictionDto requestDto = createRestrictionDto(restrictionId);

        wiremock.stubFor(WireMock.post(urlEqualTo("/api/v1/geo-balancing/traffic-restrictions"))
                                 .willReturn(WireMock.serverError()));

        AsyncMvc.perform(mockMvc, post(URL + "/traffic-restrictions")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(requestDto)))
                .andDo(print())
                .andExpect(status().isInternalServerError())
                .andExpect(result -> assertThat(result.getResolvedException())
                        .isInstanceOf(FeignException.class)
                );
    }

    @Test
    void shouldReturnDataCenters() throws Exception {
        List<String> dataCenters = List.of("dc1", "dc2", "dc3");

        wiremock.stubFor(WireMock.get(urlEqualTo("/api/v1/geo-balancing/data-centers"))
                                 .willReturn(aResponse()
                                                     .withStatus(200)
                                                     .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                                     .withBody(objectMapper.writeValueAsString(dataCenters))));

        MockHttpServletResponse response = AsyncMvc.perform(mockMvc, get(URL + "/data-centers"))
                                                   .andDo(print())
                                                   .andExpect(status().isOk())
                                                   .andReturn().getResponse();

        List<String> result = AsyncMvc.readList(objectMapper, response, String.class);
        assertThat(result).isEqualTo(dataCenters);

        wiremock.verify(1, getRequestedFor(urlEqualTo("/api/v1/geo-balancing/data-centers")));
    }

    @Test
    void shouldThrowOnRequestDataCenters() throws Exception {
        wiremock.stubFor(WireMock.get(urlEqualTo("/api/v1/geo-balancing/data-centers"))
                                 .willReturn(WireMock.serverError()));

        AsyncMvc.perform(mockMvc, get(URL + "/data-centers"))
                .andDo(print())
                .andExpect(status().isInternalServerError())
                .andExpect(result -> assertThat(result.getResolvedException())
                        .isInstanceOf(FeignException.class)
                );
    }

    @Test
    void shouldReturnGeoBalancingServices() throws Exception {
        var services = createServices();

        wiremock.stubFor(WireMock.get(urlEqualTo("/api/v1/geo-balancing/services"))
                                 .willReturn(aResponse()
                                                     .withStatus(200)
                                                     .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                                     .withBody(objectMapper.writeValueAsString(services))));

        MockHttpServletResponse response = AsyncMvc.perform(mockMvc, get(URL + "/services"))
                                                   .andDo(print())
                                                   .andExpect(status().isOk())
                                                   .andReturn().getResponse();

        List<sbp.tcpf.support_admin.model.GeoBalancingService> result =
                AsyncMvc.readList(objectMapper, response, sbp.tcpf.support_admin.model.GeoBalancingService.class);
        assertThat(result).allSatisfy(service -> {
            assertThat(service.getName()).isNotBlank();
            assertThat(service.getDataCenters()).isNotEmpty();
        });

        wiremock.verify(1, getRequestedFor(urlEqualTo("/api/v1/geo-balancing/services")));
    }

    private List<sbp.tcpf.routing.api.v1_0.client.model.GeoBalancingService> createServices() {
        return List.of(
                sbp.tcpf.routing.api.v1_0.client.model.GeoBalancingService.builder()
                                                                          .name("service1")
                                                                          .dataCenters(Set.of("dc1"))
                                                                          .build(),
                sbp.tcpf.routing.api.v1_0.client.model.GeoBalancingService.builder()
                                                                          .name("service2")
                                                                          .dataCenters(Set.of("dc2"))
                                                                          .build()
        );
    }

    @Test
    void shouldThrowOnRequestGeoBalancingServices() throws Exception {
        wiremock.stubFor(WireMock.get(urlEqualTo("/api/v1/geo-balancing/services"))
                                 .willReturn(WireMock.serverError()));

        AsyncMvc.perform(mockMvc, get(URL + "/services"))
                .andDo(print())
                .andExpect(status().isInternalServerError())
                .andExpect(result -> assertThat(result.getResolvedException())
                        .isInstanceOf(FeignException.class)
                );
    }

    @Test
    void shouldReturnEmptyListWhenGeoBalancingServicesResponseIs404() throws Exception {
        var notFoundMessage = "not found message";
        wiremock.stubFor(WireMock.get(urlEqualTo("/api/v1/geo-balancing/services"))
                                 .willReturn(WireMock.notFound()
                                                     .withBody(objectMapper.writeValueAsString(
                                                             Error.builder()
                                                                  .error("Not found")
                                                                  .message(notFoundMessage)
                                                                  .status(404)
                                                                  .timestamp(OffsetDateTime.now())
                                                                  .build()
                                                     ))));

        AsyncMvc.perform(mockMvc, get(URL + "/services"))
                .andDo(print())
                .andExpect(status().isNotFound())
                .andExpect(result -> assertThat(result.getResolvedException())
                        .isInstanceOf(FeignException.class)
                        .hasMessage(notFoundMessage)
                );
    }

    @Test
    void shouldGetTrafficRestrictionById() throws Exception {
        String restrictionId = "test-id-2";
        TrafficRestriction routingResponse = createTrafficRestriction(restrictionId);

        wiremock.stubFor(WireMock.get(urlEqualTo("/api/v1/geo-balancing/traffic-restrictions/" + restrictionId))
                                 .willReturn(aResponse()
                                                     .withStatus(200)
                                                     .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                                     .withBody(objectMapper.writeValueAsString(routingResponse))));

        MockHttpServletResponse response = AsyncMvc.perform(mockMvc, get(URL + "/traffic-restrictions/{id}", restrictionId))
                                                   .andDo(print())
                                                   .andExpect(status().isOk())
                                                   .andReturn().getResponse();

        TrafficRestrictionDto result = AsyncMvc.readSingle(objectMapper, response, TrafficRestrictionDto.class);
        assertThat(result).isNotNull();
        assertThat(result.getId()).isEqualTo(restrictionId);

        wiremock.verify(1, getRequestedFor(urlEqualTo("/api/v1/geo-balancing/traffic-restrictions/" + restrictionId)));
    }

    @Test
    void shouldThrowOnGetTrafficRestrictionById() throws Exception {
        String restrictionId = "test-id-1";

        wiremock.stubFor(WireMock.get(urlEqualTo("/api/v1/geo-balancing/traffic-restrictions/" + restrictionId))
                                 .willReturn(WireMock.serverError()));

        AsyncMvc.perform(mockMvc, get(URL + "/traffic-restrictions/{id}", restrictionId))
                .andDo(print())
                .andExpect(status().isInternalServerError())
                .andExpect(result -> assertThat(result.getResolvedException())
                        .isInstanceOf(FeignException.class)
                );
    }

    @Test
    void shouldGetAllTrafficRestrictions() throws Exception {
        List<TrafficRestriction> routingRestrictions = List.of(
                createTrafficRestriction("id1"),
                createTrafficRestriction("id2")
        );

        wiremock.stubFor(WireMock.get(urlEqualTo("/api/v1/geo-balancing/traffic-restrictions"))
                                 .willReturn(aResponse()
                                                     .withStatus(200)
                                                     .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                                     .withBody(objectMapper.writeValueAsString(routingRestrictions))));

        MockHttpServletResponse response = AsyncMvc.perform(mockMvc, get(URL + "/traffic-restrictions"))
                                                   .andDo(print())
                                                   .andExpect(status().isOk())
                                                   .andReturn().getResponse();

        List<TrafficRestrictionDto> result = AsyncMvc.readList(objectMapper, response, TrafficRestrictionDto.class);
        assertThat(result).hasSize(2);
        assertThat(result.get(0).getId()).isEqualTo("id1");
        assertThat(result.get(1).getId()).isEqualTo("id2");

        wiremock.verify(1, getRequestedFor(urlEqualTo("/api/v1/geo-balancing/traffic-restrictions")));
    }

    @Test
    void shouldThrowOnRequestAllTrafficRestrictions() throws Exception {
        wiremock.stubFor(WireMock.get(urlEqualTo("/api/v1/geo-balancing/traffic-restrictions"))
                                 .willReturn(WireMock.serverError()));

        AsyncMvc.perform(mockMvc, get(URL + "/traffic-restrictions"))
                .andDo(print())
                .andExpect(status().isInternalServerError())
                .andExpect(result -> assertThat(result.getResolvedException())
                        .isInstanceOf(FeignException.class)
                );
    }

    @Test
    void shouldRemoveTrafficRestrictionById() throws Exception {
        String restrictionId = "test-id-3";

        wiremock.stubFor(WireMock.delete(urlEqualTo("/api/v1/geo-balancing/traffic-restrictions/" + restrictionId))
                                 .willReturn(aResponse()
                                                     .withStatus(200)
                                                     .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                                     .withBody("{\"status\":\"OK\"}")));

        AsyncMvc.perform(mockMvc, delete(URL + "/traffic-restrictions/{id}", restrictionId))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());

        wiremock.verify(1, deleteRequestedFor(urlEqualTo("/api/v1/geo-balancing/traffic-restrictions/" + restrictionId)));
    }

    @Test
    void shouldThrowOnRemoveTrafficRestrictionById() throws Exception {
        String restrictionId = "test-id-1";

        wiremock.stubFor(WireMock.delete(urlEqualTo("/api/v1/geo-balancing/traffic-restrictions/" + restrictionId))
                                 .willReturn(WireMock.serverError()));

        AsyncMvc.perform(mockMvc, delete(URL + "/traffic-restrictions/{id}", restrictionId))
                .andDo(print())
                .andExpect(status().isInternalServerError())
                .andExpect(result -> assertThat(result.getResolvedException())
                        .isInstanceOf(FeignException.class)
                );
    }

    @Test
    void shouldUpdateTrafficRestriction() throws Exception {
        String restrictionId = "test-id-4";
        TrafficRestrictionDto updateDto = createRestrictionDto(restrictionId);
        TrafficRestriction routingResponse = createTrafficRestriction(restrictionId);

        wiremock.stubFor(WireMock.put(urlEqualTo("/api/v1/geo-balancing/traffic-restrictions/" + restrictionId))
                                 .withRequestBody(equalToJson(objectMapper.writeValueAsString(updateDto)))
                                 .willReturn(aResponse()
                                                     .withStatus(200)
                                                     .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                                     .withBody(objectMapper.writeValueAsString(routingResponse))));

        MockHttpServletResponse response = AsyncMvc.perform(mockMvc, put(URL + "/traffic-restrictions/{id}", restrictionId)
                                                           .contentType(MediaType.APPLICATION_JSON)
                                                           .content(objectMapper.writeValueAsString(updateDto)))
                                                   .andDo(print())
                                                   .andExpect(status().is2xxSuccessful())
                                                   .andReturn().getResponse();

        TrafficRestrictionDto result = AsyncMvc.readSingle(objectMapper, response, TrafficRestrictionDto.class);
        assertThat(result).isNotNull();

        wiremock.verify(1, putRequestedFor(urlEqualTo("/api/v1/geo-balancing/traffic-restrictions/" + restrictionId)));
    }

    @Test
    void shouldThrowOnUpdateTrafficRestriction() throws Exception {
        String restrictionId = "test-id-4";
        TrafficRestrictionDto updateDto = createRestrictionDto(restrictionId);

        wiremock.stubFor(WireMock.put(urlEqualTo("/api/v1/geo-balancing/traffic-restrictions/" + restrictionId))
                                 .willReturn(WireMock.serverError()));

        AsyncMvc.perform(mockMvc, put(URL + "/traffic-restrictions/{id}", restrictionId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updateDto)))
                .andDo(print())
                .andExpect(status().isInternalServerError())
                .andExpect(result -> assertThat(result.getResolvedException())
                        .isInstanceOf(FeignException.class)
                );
    }
}
