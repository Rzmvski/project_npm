package sbp.tcpf.support_admin.utils

import org.apache.commons.lang3.tuple.Pair
import org.reactivestreams.Publisher
import reactor.test.StepVerifier
import java.util.function.Consumer

fun <T> Publisher<T>.test() = StepVerifier.create(this)

fun <T> Publisher<T>.testWithVirtualTime() = StepVerifier.withVirtualTime { this }

fun AuditAssertions.EventExpectations.paramAssert(
    name: String,
    block: (String) -> Unit,
): AuditAssertions.EventExpectations {
    val currentAsserts = this.paramsAsserts ?: mutableListOf()
    val newAsserts = currentAsserts.toMutableList()
    newAsserts.add(Pair.of(name, Consumer { block(it) }))
    return this.paramsAsserts(newAsserts)
}
