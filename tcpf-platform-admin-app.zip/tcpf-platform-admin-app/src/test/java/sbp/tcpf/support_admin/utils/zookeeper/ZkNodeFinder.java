package sbp.tcpf.support_admin.utils.zookeeper;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.utils.ZKPaths;
import org.jetbrains.annotations.Nullable;
import lombok.experimental.UtilityClass;

import java.util.List;
import java.util.Objects;

@UtilityClass
public class ZkNodeFinder {

    public static final String ROOT = "/";

    public static String findNodeByData(CuratorFramework client, byte[] data) throws Exception {
        return findNodeByData(client, data, ROOT);
    }

    @Nullable
    private static String findNodeByData(CuratorFramework client, byte[] data, String currentPath) throws Exception {
        List<String> children = client.getChildren().forPath(currentPath);

        for (String child : children) {
            String childPath = ZKPaths.makePath(currentPath, child);
            byte[] childData = client.getData().forPath(childPath);
            if (Objects.deepEquals(childData, data)) {
                return childPath;
            }

            return findNodeByData(client, data, childPath);
        }

        return null;
    }
}
