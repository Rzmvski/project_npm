package sbp.tcpf.support_admin.utils.zookeeper;

import sbp.tcpf.support_admin.entities.AbstractRequest;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.curator.framework.CuratorFramework;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;

@RequiredArgsConstructor
public class MockZookeeperManager {

    private final CuratorFramework curatorFramework;
    private final ObjectMapper objectMapper;

    public byte[] getDataByPath(String path) throws Exception {
        return curatorFramework.getData().forPath(path);
    }

    @SneakyThrows
    public <T extends AbstractRequest> void createNode(T data) {
        curatorFramework.create().creatingParentContainersIfNeeded().forPath(
                data.getPath(),
                objectMapper.writeValueAsBytes(data)
        );
    }

    @SneakyThrows
    public <T> void createNode(T data, String path) {
        curatorFramework.create().creatingParentContainersIfNeeded().forPath(
                path,
                data != null ? objectMapper.writeValueAsBytes(data) : null
        );
    }

    public <T extends AbstractRequest> void updateNode(T data) throws Exception {
        curatorFramework.setData().forPath(
                data.getPath(),
                objectMapper.writeValueAsBytes(data)
        );
    }

    public void deleteNode(String path) throws Exception {
        curatorFramework.delete().forPath(path);
    }
}
