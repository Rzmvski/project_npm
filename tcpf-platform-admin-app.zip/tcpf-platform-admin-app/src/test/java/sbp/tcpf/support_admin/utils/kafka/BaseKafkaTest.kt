package sbp.tcpf.support_admin.utils.kafka

import com.fasterxml.jackson.databind.ObjectMapper
import org.junit.jupiter.api.BeforeAll
import org.junit.jupiter.api.TestInstance
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean
import org.springframework.boot.autoconfigure.kafka.KafkaAutoConfiguration
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.context.TestConfiguration
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Import
import org.springframework.kafka.test.EmbeddedKafkaBroker
import org.springframework.kafka.test.context.EmbeddedKafka
import org.springframework.test.annotation.DirtiesContext
import org.springframework.test.context.ContextConfiguration
import sbp.tcpf.support_admin.configs.properties.ScriptServiceProperties

@SpringBootTest
@DirtiesContext
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@ContextConfiguration(
        classes = [
            TestKafkaConsumerFactory::class,
        ]
)
@EmbeddedKafka(
        brokerProperties = [
            "listeners=PLAINTEXT://\${spring.kafka.bootstrap-servers}",
        ],
//        partitions = 1
)
@Import(
    KafkaAutoConfiguration::class,
)
abstract class BaseKafkaTest {

    @Autowired
    lateinit var properties: ScriptServiceProperties

    @Autowired
    lateinit var testConsumerFactory: TestKafkaConsumerFactory

    val logTopic get() = properties.kafkaTopics.logs

    val statusTopic get() = properties.kafkaTopics.statuses

    val commandTopic get() = properties.kafkaTopics.commands

    @TestConfiguration
    class TestConfig {

        @Bean
        @ConditionalOnMissingBean
        fun objectMapper(): ObjectMapper {
            return ObjectMapper()
        }
    }

    @Autowired
    lateinit var broker: EmbeddedKafkaBroker

    @BeforeAll
    fun init() {
        broker.addTopicsWithResults(
                logTopic,
                statusTopic,
                commandTopic,
        )
    }
}
