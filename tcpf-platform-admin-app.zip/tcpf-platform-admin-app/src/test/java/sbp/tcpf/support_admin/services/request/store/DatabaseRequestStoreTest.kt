package sbp.tcpf.support_admin.services.request.store

import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.mockito.ArgumentCaptor
import org.mockito.Captor
import org.mockito.kotlin.*
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.context.TestConfiguration
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Import
import org.springframework.test.context.bean.override.mockito.MockitoBean
import org.springframework.util.unit.DataSize
import reactor.core.publisher.Flux
import sbp.tcpf.routing.api.v1_0.client.model.Node
import sbp.tcpf.routing.api.v1_0.client.model.NodeStatus
import sbp.tcpf.support.commons.auth.services.UserService
import sbp.tcpf.support_admin.config.UOWTestConfig
import sbp.tcpf.support_admin.configs.properties.ResolveRequestServiceProperties
import sbp.tcpf.support_admin.configs.properties.ScriptServiceProperties
import sbp.tcpf.support_admin.dto.ScriptApplicationDto
import sbp.tcpf.support_admin.entities.RequestEntity
import sbp.tcpf.support_admin.mappers.RequestMapper
import sbp.tcpf.support_admin.mappers.RequestStatusMapper
import sbp.tcpf.support_admin.mappers.RequestStatusMapperImpl
import sbp.tcpf.support_admin.mappers.ScriptDbEntityMapperImpl
import sbp.tcpf.support_admin.model.ScriptApplication
import sbp.tcpf.support_admin.repositories.impl.DbRequestRepository
import sbp.tcpf.support_admin.services.ShardService
import sbp.tcpf.support_admin.services.request.RequestStatus
import sbp.tcpf.support_admin.services.request.RequestType
import sbp.tcpf.support_admin.services.request.dto.ScriptKey
import sbp.tcpf.support_admin.services.request.store.modifiers.Modifier
import sbp.tcpf.support_admin.wrappers.SafeUnitOfWorkOperations
import java.time.LocalDateTime
import kotlin.random.Random

@EnableConfigurationProperties(
        ResolveRequestServiceProperties::class,
        ScriptServiceProperties::class
)
@SpringBootTest(
        classes = [
            ScriptDbEntityMapperImpl::class,
            RequestStatusMapperImpl::class,
        ]
)
@Import(
        UOWTestConfig::class,
        DatabaseRequestStoreTest.TestConfig::class,
)
class DatabaseRequestStoreTest {

    @MockitoBean
    lateinit var shardService: ShardService

    @MockitoBean
    lateinit var repository: DbRequestRepository

    @MockitoBean
    lateinit var userService: UserService

    @Captor
    lateinit var entityCaptor: ArgumentCaptor<RequestEntity>

    @Autowired
    lateinit var dbRequestStore: DatabaseRequestStore

    @BeforeEach
    fun setUp() {
        given { shardService.getActiveNodeByShardId(any()) }
            .willAnswer { invocation ->
                val shardId = invocation.getArgument<Int>(0)

                return@willAnswer Node(shardId, "nodeName", shardId, NodeStatus.WORKING, "dcKey", emptyList())
            }

        // ShardService.getActiveNodes() после рефакторинга возвращает Flux —
        // без стаба DatabaseRequestStore.safeCallOnActiveNodes упадёт на null
        given { shardService.getActiveNodes() }
            .willReturn(Flux.just(Node(1005, "nodeName", 1005, NodeStatus.WORKING, "dcKey", emptyList())))
    }

    @TestConfiguration
    class TestConfig {
        @Bean
        fun databaseRequestStore(
            mapper: RequestMapper<ScriptApplicationDto, RequestEntity>,
            properties: ResolveRequestServiceProperties,
            scriptModifiers: List<Modifier<ScriptApplication>>,
            uow: SafeUnitOfWorkOperations,
            shardService: ShardService,
            scriptRequestRepository: DbRequestRepository,
            statusMapper: RequestStatusMapper,
            userService: UserService,
            scriptProperties: ScriptServiceProperties,
        ): DatabaseRequestStore {
            return DatabaseRequestStore(
                    mapper = mapper,
                    uow = uow,
                    shardService = shardService,
                    repository = scriptRequestRepository,
                    properties = properties,
                    statusMapper = statusMapper,
            )
        }
    }

    @Test
    fun `should append logs to request`() {
        val smallLogMessage = "small log"
        val reasonId = "reasonId"
        val shardId = 1005
        val scriptRequestLocation = ScriptKey(reasonId, shardId)
        val maxLogSize = DataSize.ofKilobytes(15)
        val entity = createRequestEntity(reasonId)

        given { repository.findByKeyAndType(reasonId, RequestType.SCRIPT_REQUEST) }.willReturn(entity)

        dbRequestStore.appendLog(scriptRequestLocation, maxLogSize, smallLogMessage)

        then(repository).should().save(capture(entityCaptor))

        assertThat(entityCaptor)
            .extracting { captor -> captor.value }
            .extracting { entity -> entity.rsData }
            .isEqualTo(smallLogMessage)
    }

    @Test
    fun `should skip appending logs when log is too large`() {
        val smallLogMessage = "small log"
        val largeLogMessage = String(Random.Default.nextBytes(DataSize.ofKilobytes(150).toBytes().toInt()))
        val reasonId = "reasonId"
        val shardId = 1005
        val scriptRequestLocation = ScriptKey(reasonId, shardId)
        val maxLogSize = DataSize.ofKilobytes(15)

        given { repository.findByKeyAndType(reasonId, RequestType.SCRIPT_REQUEST) }
            .willReturn(createRequestEntity(reasonId, rsData = smallLogMessage))


        dbRequestStore.appendLog(scriptRequestLocation, maxLogSize, largeLogMessage)

        then(repository).should(never()).save(any<RequestEntity>())
    }

    private fun createRequestEntity(
        rqUid: String,
        creator: String = "admin",
        rqData: String? = null,
        rsData: String? = null,
    ): RequestEntity {
        return RequestEntity(
                id = 1L,
                rqUid = rqUid,
                creatorLogin = creator,
                statusId = RequestStatus.CREATED.id,
                rqData = rqData,
                rsData = rsData,
                requestTypeId = RequestType.SCRIPT_REQUEST.id,
                created = LocalDateTime.now(),
        )
    }
}
