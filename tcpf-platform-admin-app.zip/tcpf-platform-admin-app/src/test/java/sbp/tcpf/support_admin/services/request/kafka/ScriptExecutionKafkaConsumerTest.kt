package sbp.tcpf.support_admin.services.request.kafka

import org.assertj.core.api.Assertions.assertThat
import org.awaitility.Awaitility.await
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.mockito.ArgumentCaptor
import org.mockito.Captor
import org.mockito.kotlin.*
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.context.annotation.Import
import org.springframework.kafka.core.KafkaTemplate
import org.springframework.test.context.TestPropertySource
import org.springframework.test.context.bean.override.mockito.MockitoBean
import sbp.tcpf.script.engine.async.model.ExecutionEvent
import sbp.tcpf.script.engine.async.model.ExecutionLogEvent
import sbp.tcpf.script.engine.async.model.Status
import sbp.tcpf.support_admin.configs.KafkaConfig
import sbp.tcpf.support_admin.configs.ScriptConfig
import sbp.tcpf.support_admin.mappers.ApplicationStatusMapperImpl
import sbp.tcpf.support_admin.model.ApplicationStatus
import sbp.tcpf.support_admin.services.request.dto.ScriptKey
import sbp.tcpf.support_admin.services.request.execution.ExecutionContextManager
import sbp.tcpf.support_admin.services.request.execution.ExecutionLocationResolver
import sbp.tcpf.support_admin.services.request.store.CompositeScriptDataStore
import sbp.tcpf.support_admin.utils.kafka.BaseKafkaTest
import java.time.LocalDateTime

@TestPropertySource(properties = [
    "spring.kafka.consumer.fetch-max-wait=500ms"
])
@SpringBootTest(
        classes = [
            ScriptExecutionKafkaConsumer::class,
            ApplicationStatusMapperImpl::class,
        ]
)
@Import(
        KafkaConfig::class,
        ScriptConfig::class
)
class ScriptExecutionKafkaConsumerTest : BaseKafkaTest() {

    companion object {
        const val SHARD_ID = 1005
    }

    @Captor
    lateinit var logCaptor: ArgumentCaptor<String>

    @Captor
    lateinit var statusCaptor: ArgumentCaptor<ApplicationStatus>

    @Captor
    lateinit var keyCaptor: ArgumentCaptor<ScriptKey>

    @MockitoBean
    lateinit var executionContextManager: ExecutionContextManager

    @MockitoBean
    lateinit var store: CompositeScriptDataStore

    @MockitoBean
    lateinit var locationResolver: ExecutionLocationResolver

    @Autowired
    lateinit var kafkaTemplate: KafkaTemplate<String, Any>

    @BeforeEach
    fun setUp() {
        given { locationResolver.resolve(any()) }.willReturn(SHARD_ID)
    }

    @Test
    fun `should append logs and send it to updater`() {
        val logs = listOf("log1", "log2", "log3")
        val reasonId = "reasonId"

        logs.forEach { log ->
            kafkaTemplate.send(logTopic, reasonId, ExecutionLogEvent(log, LocalDateTime.now()))
        }

        await().untilAsserted {
            then(store).should().saveLogs(
                    capture(keyCaptor),
                    capture(logCaptor)
            )
        }

        assertThat(keyCaptor.value).satisfies({
            assertThat(it.scriptId).isEqualTo(reasonId)
            assertThat(it.shardId).isEqualTo(SHARD_ID)
        })
        assertThat(logCaptor.value).contains(logs)
    }

    @Test
    fun `should handle statuses and send it to updater`() {
        val reasonId = "reasonId"
        val executionStatuses = listOf(
                Status.QUEUED,
                Status.WORKS,
                Status.SUCCESS,
        )
        val applicationStatuses = listOf(
                ApplicationStatus.WORKS,
                ApplicationStatus.SUCCESS,
        )

        executionStatuses.forEach { status ->
            kafkaTemplate.send(statusTopic, reasonId, ExecutionEvent(status, LocalDateTime.now()))
        }

        await().untilAsserted {
            then(store).should(times(executionStatuses.size)).changeStatus(
                    capture(keyCaptor),
                    capture(statusCaptor)
            )
        }

        assertThat(keyCaptor.value).satisfies({
            assertThat(it.scriptId).isEqualTo(reasonId)
            assertThat(it.shardId).isEqualTo(SHARD_ID)
        })
        assertThat(statusCaptor.allValues.toSet()).containsExactlyElementsOf(applicationStatuses)
    }
}
