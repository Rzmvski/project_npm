package sbp.tcpf.support_admin.services.request.impl

import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.junit.jupiter.params.ParameterizedTest
import org.junit.jupiter.params.provider.EnumSource
import org.mockito.ArgumentCaptor
import org.mockito.Captor
import org.mockito.kotlin.*
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.context.annotation.Import
import org.springframework.security.test.context.support.WithUserDetails
import org.springframework.test.context.bean.override.mockito.MockitoBean
import org.springframework.test.context.bean.override.mockito.MockitoSpyBean
import sbp.tcpf.script.engine.async.model.Command
import sbp.tcpf.script.engine.async.model.StartCommand
import sbp.tcpf.script.engine.async.model.StopCommand
import sbp.tcpf.support_admin.clients.kafka.ScriptEngineCommandPublisher
import sbp.tcpf.support_admin.config.SecurityTestConfig
import sbp.tcpf.support_admin.config.SecurityTestConfig.FIRST_ADMIN
import sbp.tcpf.support_admin.config.SecurityTestConfig.SECOND_ADMIN
import sbp.tcpf.support_admin.dto.DbRef
import sbp.tcpf.support_admin.dto.ScriptApplicationDto
import sbp.tcpf.support_admin.entities.ScriptRequest
import sbp.tcpf.support_admin.mappers.ScriptApplicationMapperImpl
import sbp.tcpf.support_admin.mappers.ScriptExecutionRequestMapperImpl
import sbp.tcpf.support_admin.mappers.ScriptZkEntityMapperImpl
import sbp.tcpf.support_admin.model.ApplicationStatus
import sbp.tcpf.support_admin.model.CreateScriptApplicationRequest
import sbp.tcpf.support_admin.model.Restrictions
import sbp.tcpf.support_admin.model.ScriptApplication
import sbp.tcpf.support_admin.services.request.RequestService
import sbp.tcpf.support_admin.services.request.cache.RequestCuratorCacheManager
import sbp.tcpf.support_admin.services.request.dto.ScriptKey
import sbp.tcpf.support_admin.services.request.resolvers.ArchiveResolver
import sbp.tcpf.support_admin.services.request.resolvers.CancelResolver
import sbp.tcpf.support_admin.services.request.resolvers.ResolverConfig
import sbp.tcpf.support_admin.services.request.resolvers.script.WorksResolver
import sbp.tcpf.support_admin.services.request.store.CompositeScriptDataStore
import java.time.LocalDateTime

@WithUserDetails(FIRST_ADMIN)
@SpringBootTest(
        classes = [
            ScriptRequestService::class,
            WorksResolver::class,
            ArchiveResolver::class,
            CancelResolver::class,
            ScriptApplicationMapperImpl::class,
            ScriptZkEntityMapperImpl::class,
            ScriptExecutionRequestMapperImpl::class,
        ]
)
@Import(
        ResolverConfig::class,
        SecurityTestConfig::class,
)
class ScriptRequestServiceTest {

    @MockitoSpyBean
    lateinit var archiveResolver: ArchiveResolver

    @MockitoBean
    lateinit var publisher: ScriptEngineCommandPublisher

    @MockitoBean
    lateinit var store: CompositeScriptDataStore

    @MockitoBean
    lateinit var curatorCache: RequestCuratorCacheManager

    @Captor
    lateinit var commandCaptor: ArgumentCaptor<Command>

    @Autowired
    lateinit var requestService: RequestService<String, CreateScriptApplicationRequest, ScriptApplication>

    @Test
    fun `should resolve to works application`() {
        val reasonId = "reasonId"
        val jiraId = "jiraId"
        val script = "hello world"
        val shardId = 1005
        val currentRestrictions = Restrictions(true, listOf("nodeKey"))
        val location = ScriptKey(reasonId, shardId)
        val application = ScriptApplicationDto(
                location = location,
                status = ApplicationStatus.APPROVED,
                jiraId = jiraId,
                createdBy = SECOND_ADMIN,
                restrictions = currentRestrictions,
                scriptBody = script
        )

        given { store.findByKey(reasonId) }.willReturn(application)
        given { store.execute(any(), any()) }.willReturn(application)

        requestService.resolve(reasonId, ApplicationStatus.WORKS)

        verify(publisher).sendCommand(capture(commandCaptor))

        verify(store).execute(location, FIRST_ADMIN)

        assertThat(commandCaptor.value)
            .isInstanceOfSatisfying(StartCommand::class.java, {
                assertThat(it.executionId).isEqualTo(reasonId)
                assertThat(it.script).isEqualTo(script)
                assertThat(it.jiraId).isEqualTo(jiraId)
                assertThat(it.createdBy).isEqualTo(SECOND_ADMIN)
                assertThat(it.executedBy).isEqualTo(FIRST_ADMIN)
                assertThat(it.restrictions)
                    .extracting { it.allowedNodes }
                    .isEqualTo(currentRestrictions.allowedNodes)
            })
    }

    @ParameterizedTest
    @EnumSource(names = ["APPROVED", "DECLINE"])
    fun `should resolve application`(status: ApplicationStatus) {
        val reasonId = "reasonId"
        val shardId = 1
        val location = ScriptKey(reasonId, shardId)
        val application = ScriptApplicationDto(
                location = location,
                status = ApplicationStatus.PENDING,
                jiraId = "jiraId"
        )

        given { store.findByKey(reasonId) }.willReturn(application)
        given { store.resolveStatus(location, status, FIRST_ADMIN) }.willReturn(application)

        requestService.resolve(reasonId, status)

        verify(store).resolveStatus(location, status, FIRST_ADMIN)
    }

    @Test
    fun `should cancel application`() {
        val reasonId = "reasonId"
        val shardId = 1
        val location = ScriptKey(reasonId, shardId)
        val application = ScriptApplicationDto(
                location = location,
                status = ApplicationStatus.CREATED,
                jiraId = "jiraId"
        )
        val zkEntity = ScriptRequest().apply {
            dbRef = DbRef(shardId)
            jiraId = "jiraId"
            uid = reasonId
            requestStatus = ApplicationStatus.SUCCESS.value
            createdBy = FIRST_ADMIN
            createdAt = LocalDateTime.now()
            resolvedBy = SECOND_ADMIN
            resolvedAt = LocalDateTime.now()
        }

        given { store.findByKey(reasonId) }.willReturn(application)
        given { curatorCache.getByUid(reasonId, ScriptRequest::class.java) }.willReturn(zkEntity)
        given { store.changeStatus(any(), any()) }.willReturn(application)

        requestService.resolve(reasonId, ApplicationStatus.CANCELED)

        verify(publisher).sendCommand(capture(commandCaptor))

        assertThat(commandCaptor.value)
            .isInstanceOf(StopCommand::class.java)
            .satisfies({
                assertThat(it.executionId).isEqualTo(reasonId)
            })
    }

    @Test
    fun `should archive application`() {
        val reasonId = "reasonId"
        val shardId = 1
        val location = ScriptKey(reasonId, shardId)
        val application = ScriptApplicationDto(
                location = location,
                status = ApplicationStatus.CREATED,
                jiraId = "jiraId"
        )

        given { store.findByKey(reasonId) }.willReturn(application)
        given { store.changeStatus(any(), any()) }.willReturn(application)

        requestService.resolve(reasonId, ApplicationStatus.ARCHIVED)

        verify(store).changeStatus(location, ApplicationStatus.ARCHIVED)
    }

    @Test
    fun `should skip resolving when current status is equal to resolve status`() {
        val reasonId = "reasonId"
        val status = ApplicationStatus.ARCHIVED
        val location = ScriptKey(reasonId)
        val application = ScriptApplicationDto(
                location = location,
                status = status,
                jiraId = "jiraId"
        )

        given { store.findByKey(reasonId) }.willReturn(application)

        requestService.resolve(reasonId, status)

        then(store).should(never()).changeStatus(any(), any())
    }
}
