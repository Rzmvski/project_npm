package sbp.tcpf.support_admin.utils

import org.assertj.core.api.AbstractAssert
import org.assertj.core.api.Assertions.assertThat

fun <ELEMENT> assertThatIterable(actual: Iterable<ELEMENT>) = CustomIterableAssert(actual)

class CustomIterableAssert<ELEMENT>(val actual: Iterable<ELEMENT>) :
    AbstractAssert<CustomIterableAssert<ELEMENT>, Iterable<ELEMENT>>(actual, CustomIterableAssert::class.java) {

    fun containsOnlyOneOf(vararg expected: ELEMENT): CustomIterableAssert<ELEMENT> {
        val matches = expected.count { it in actual }

        assertThat(matches)
            .withFailMessage(
                    "Expected to contain only one of ${expected.toList()}, but found $matches matches in $actual"
            )
            .isEqualTo(1)

        return this
    }
}
