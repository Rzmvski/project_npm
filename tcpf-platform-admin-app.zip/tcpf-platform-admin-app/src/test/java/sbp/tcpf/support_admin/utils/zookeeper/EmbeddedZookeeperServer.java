package sbp.tcpf.support_admin.utils.zookeeper;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.RetryOneTime;
import org.apache.curator.test.TestingServer;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import lombok.Getter;

@Getter
public class EmbeddedZookeeperServer implements InitializingBean, DisposableBean {

    private TestingServer testingServer;
    private CuratorFramework curatorFramework;

    @Override
    public void afterPropertiesSet() throws Exception {
        testingServer = new TestingServer();
        curatorFramework = CuratorFrameworkFactory.builder()
                                                  .namespace("namespace")
                                                  .retryPolicy(new RetryOneTime(1000))
                                                  .connectString(testingServer.getConnectString())
                                                  .build();

        System.setProperty("zookeeper.extendedTypesEnabled", "true");
        System.setProperty("zookeeper.emulate353TTLNodes", "true");

        curatorFramework.start();
    }

    @Override
    public void destroy() throws Exception {
        testingServer.close();
        curatorFramework.close();
    }
}
