package sbp.tcpf.support_admin.services.lock

import org.awaitility.Awaitility.await
import org.junit.jupiter.api.Test
import org.mockito.kotlin.verify
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.context.annotation.Import
import org.springframework.test.context.bean.override.mockito.MockitoSpyBean
import sbp.tcpf.support_admin.config.CuratorTestConfig
import sbp.tcpf.support_admin.configs.properties.CuratorLockProperties
import sbp.tcpf.support_admin.utils.zookeeper.MockZookeeperManager

@EnableConfigurationProperties(CuratorLockProperties::class)
@SpringBootTest(
        classes = [
            LockRegistry::class,
            LockRegistryCleaner::class,
            CuratorLockManager::class,
        ]
)
@Import(CuratorTestConfig::class)
class LockRegistryCleanerTest {

    data class TestData(
        val uid: String,
        val value: String,
    )

    @MockitoSpyBean
    lateinit var lockRegistry: LockRegistry

    @Autowired
    lateinit var curatorLockManager: CuratorLockManager

    @Autowired
    lateinit var mockZookeeperManager: MockZookeeperManager

    private val testPath = "/test/lock/path"
    private val testNodeData = TestData("test-id", "test-value")

    @Test
    fun `should clear lock registry`() {
        mockZookeeperManager.createNode(testNodeData, testPath)

        val work = "success"
        curatorLockManager.withLock(testPath, LockType.READ) {
            return@withLock work
        }

        mockZookeeperManager.deleteNode(testPath)

        await().untilAsserted {
            verify(lockRegistry).remove(testPath)
        }
    }

}
