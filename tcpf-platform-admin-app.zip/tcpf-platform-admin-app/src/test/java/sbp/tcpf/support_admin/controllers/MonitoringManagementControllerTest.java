package sbp.tcpf.support_admin.controllers;

import sbp.tcpf.routing.api.v1_0.client.model.Monitoring;
import sbp.tcpf.routing.api.v1_0.client.model.MonitoringState;
import sbp.tcpf.support_admin.config.CommonTestConfig;
import sbp.tcpf.support_admin.config.FeignClientsTestConfig;
import sbp.tcpf.support_admin.config.SecurityTestConfig;
import sbp.tcpf.support_admin.configs.properties.RoutingAppOsProperties;
import sbp.tcpf.support_admin.mappers.MonitoringMapperImpl;
import sbp.tcpf.support_admin.services.monitoring.impl.DbMonitoringManagement;
import sbp.tcpf.support_admin.services.monitoring.impl.IgniteMonitoringManagementImpl;
import sbp.tcpf.support_admin.services.monitoring.impl.SemaphoreIgniteMonitoringSource;
import sbp.tcpf.support_admin.utils.AsyncMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.maciejwalkowiak.wiremock.spring.ConfigureWireMock;
import com.maciejwalkowiak.wiremock.spring.EnableWireMock;
import com.maciejwalkowiak.wiremock.spring.InjectWireMock;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static com.github.tomakehurst.wiremock.client.WireMock.okJson;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static sbp.tcpf.support_admin.utils.TestConstants.ALPHA;
import static sbp.tcpf.support_admin.utils.TestConstants.GAMMA;
import static sbp.tcpf.support_admin.utils.TestConstants.P5;
import static sbp.tcpf.support_admin.utils.TestConstants.P6;
import static sbp.tcpf.support_admin.utils.TestConstants.S5;
import static sbp.tcpf.support_admin.utils.TestConstants.S6;
import static sbp.tcpf.support_admin.utils.TestConstants.SEM_1;
import static sbp.tcpf.support_admin.utils.TestConstants.SEM_2;

@EnableConfigurationProperties(RoutingAppOsProperties.class)
@TestPropertySource(
        properties = "tcpf-platform-admin-app.tcpf-routing-app-os.monitoring-threshold=30s"
)
@EnableWireMock({
        @ConfigureWireMock(name = "routing", property = "tcpf-platform-admin-app.tcpf-routing-app-os.uri")
})
@AutoConfigureMockMvc(addFilters = false)
@WebMvcTest(MonitoringManagementController.class)
@Import({
        DbMonitoringManagement.class,
        IgniteMonitoringManagementImpl.class,
        MonitoringMapperImpl.class,
        FeignClientsTestConfig.class,
        SemaphoreIgniteMonitoringSource.class,
        SecurityTestConfig.class,
        CommonTestConfig.class
})
class MonitoringManagementControllerTest {

    private static final String BASE_URL = "/invoke/support-admin/monitoring-management-service/monitorings";

    @InjectWireMock("routing")
    WireMockServer wiremock;
    @Autowired
    MockMvc mockMvc;
    @Autowired
    ObjectMapper objectMapper;

    @ParameterizedTest
    @ValueSource(strings = {"/ignite", "/db"})
    void shouldReturnMonitoringInfo(String endpoint) throws Exception {
        wiremock.stubFor(WireMock.get("/api/v1/routing-management/monitorings/ignite").willReturn(okJson(
                objectMapper.writeValueAsString(getIgniteMonitoring())
        )));

        wiremock.stubFor(WireMock.get("/api/v1/routing-management/monitorings/sse/db").willReturn(okJson(
                objectMapper.writeValueAsString(getDbMonitoring())
        )));

        MockHttpServletResponse response = AsyncMvc.perform(mockMvc, get(BASE_URL + endpoint))
                                                   .andDo(print())
                                                   .andExpect(status().isOk())
                                                   .andReturn().getResponse();

        List<sbp.tcpf.support_admin.model.Monitoring> monitorings =
                AsyncMvc.readList(objectMapper, response, sbp.tcpf.support_admin.model.Monitoring.class);

        assertThat(monitorings)
                .isNotEmpty()
                .allSatisfy(monitoring -> {
                    assertThat(monitoring.getId()).isNotBlank();
                    assertThat(monitoring.getState()).isNotNull();
                });
    }

    public static List<Monitoring> getIgniteMonitoring() {
        return List.of(
                new Monitoring(SEM_1, MonitoringState.UP, null, null),
                new Monitoring(SEM_2, MonitoringState.DOWN, null, null)
        );
    }

    public static List<Monitoring> getDbMonitoring() {
        return List.of(
                new Monitoring(P5, MonitoringState.UP, 100L, null),
                new Monitoring(S5, MonitoringState.DOWN, 100L, null),
                new Monitoring(P6, MonitoringState.UP, 100L, null),
                new Monitoring(S6, MonitoringState.DOWN, 100L, null),
                new Monitoring(ALPHA, MonitoringState.UP, 100L, null),
                new Monitoring(GAMMA, MonitoringState.DOWN, 100L, null)
        );
    }
}
