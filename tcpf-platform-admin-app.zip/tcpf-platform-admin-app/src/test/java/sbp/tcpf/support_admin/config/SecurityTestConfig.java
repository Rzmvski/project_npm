package sbp.tcpf.support_admin.config;

import sbp.tcpf.security.authentication.entity.UfsUser;
import sbp.tcpf.security.authorization.resolvers.PermissionResolver;
import sbp.tcpf.security.authorization.resolvers.RoleResolver;
import sbp.tcpf.support.commons.auth.services.UserService;

import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetailsService;

import java.util.List;
import java.util.UUID;

@TestConfiguration
@Import({
        UserService.class,
        RoleResolver.class,
        PermissionResolver.class,
})
public class SecurityTestConfig {

    public static final String FIRST_ADMIN = "admin1";
    public static final String SECOND_ADMIN = "admin2";
    public static final GrantedAuthority ADMIN_ROLE = new SimpleGrantedAuthority("ROLE_ADMIN");
    public static final GrantedAuthority SIMPLE_PERMISSION = new SimpleGrantedAuthority("simple_permission");

    @Bean
    @Primary
    public UserDetailsService userDetailsService() {
        return new InMemoryUfsUserDetailsService(createAdmin(FIRST_ADMIN), createAdmin(SECOND_ADMIN));
    }

    private UfsUser createAdmin(String login) {
        return UfsUser.builder()
                      .login(login)
                      .name("admin")
                      .lastName("adminov")
                      .middleName("adminovich")
                      .email("admin@sberbank.ru")
                      .UUID(UUID.randomUUID().toString())
                      .authorities(List.of(
                              ADMIN_ROLE,
                              SIMPLE_PERMISSION
                      ))
                      .build();
    }
}
