package sbp.tcpf.support_admin.validators;

import sbp.tcpf.support_admin.validators.annotations.TwoPersonConstraint;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.validation.beanvalidation.SpringConstraintValidatorFactory;
import org.springframework.web.context.WebApplicationContext;
import lombok.experimental.SuperBuilder;

import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static sbp.tcpf.support_admin.validators.TwoPersonValidator.MISSING_FIELDS_MESSAGE;
import static sbp.tcpf.support_admin.validators.TwoPersonValidator.SAME_VALUES_MESSAGE;

import jakarta.validation.ConstraintViolation;

@SpringBootTest(classes = {
        TwoPersonValidator.class,
})
@Import(TwoPersonValidatorTest.TestConfig.class)
class TwoPersonValidatorTest {

    @Autowired
    LocalValidatorFactoryBean localValidatorFactoryBean;

    @TestConfiguration
    static class TestConfig {
        @Bean
        public LocalValidatorFactoryBean localValidatorFactoryBean(
                WebApplicationContext context,
                SpringConstraintValidatorFactory constraintValidatorFactory
        ) {
            LocalValidatorFactoryBean localValidatorFactoryBean = new LocalValidatorFactoryBean();
            localValidatorFactoryBean.setApplicationContext(context);
            localValidatorFactoryBean.setConstraintValidatorFactory(constraintValidatorFactory);
            return localValidatorFactoryBean;
        }

        @Bean
        public SpringConstraintValidatorFactory springConstraintValidatorFactory(WebApplicationContext context) {
            return new SpringConstraintValidatorFactory(context.getAutowireCapableBeanFactory());
        }
    }

    @SuperBuilder
    @TwoPersonConstraint(
            creatorFieldName = "creator",
            resolverFieldName = "resolver"
    )
    abstract static class ParentTestObject {
        String creator;
    }

    @SuperBuilder
    static class ValidClass extends ParentTestObject {
        String firstField;
        String secondField;
        String resolver;
    }

    @SuperBuilder
    static class InvalidClass extends ParentTestObject {
        String firstField;
    }

    @Test
    void shouldBeValid() {
        var validObject1 = ValidClass.builder()
                .creator("creator")
                .build();
        var validObject2 = ValidClass.builder()
                .creator("creator")
                .resolver("resolver")
                .build();
        Set<ConstraintViolation<ValidClass>> violations1 = localValidatorFactoryBean.validate(validObject1);
        Set<ConstraintViolation<ValidClass>> violations2 = localValidatorFactoryBean.validate(validObject2);

        assertThat(violations1).isEmpty();
        assertThat(violations2).isEmpty();
    }

    @Test
    void shouldBeInvalidByMissingRequiredAnnotation() {
        var invalidObject = InvalidClass.builder()
                .creator("creator")
                .build();

        var violations = localValidatorFactoryBean.validate(invalidObject);

        assertThat(violations).isNotEmpty();
        assertThat(violations)
                .extracting(ConstraintViolation::getMessage)
                .contains(MISSING_FIELDS_MESSAGE);
    }

    @Test
    void shouldBeInvalidByTwoPersonPrinciple() {
        var invalidObject = ValidClass.builder()
                .creator("creator")
                .resolver("creator")
                .build();

        Set<ConstraintViolation<ValidClass>> violations = localValidatorFactoryBean.validate(invalidObject);

        assertThat(violations).isNotEmpty();
        assertThat(violations)
                .extracting(ConstraintViolation::getMessage)
                .contains(SAME_VALUES_MESSAGE);
    }
}
