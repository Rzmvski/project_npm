package sbp.tcpf.support_admin.utils;

import org.mockito.Answers;
import org.mockito.stubbing.Answer;
import lombok.experimental.UtilityClass;

import static org.mockito.Mockito.mock;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * Мок, который по умолчанию отдаёт пустой {@code Flux}/{@code Mono} вместо {@code null}.
 * <p>
 * Зачем это нужно:
 * <ul>
 *     <li>Mockito не знает про Reactor и для методов, возвращающих {@code Flux}/{@code Mono},
 *     по умолчанию отдаёт {@code null} (для {@code List} он отдавал пустой список — до
 *     рефакторинга код это спасало);</li>
 *     <li>Spring Boot ({@code ResetMocksTestExecutionListener}) сбрасывает стабы у всех
 *     мок-бинов контекста после каждого теста, поэтому {@code given(...)} внутри
 *     {@code @Bean}-фабрики живёт только до первого теста.</li>
 * </ul>
 * Default answer задаётся при создании мока и переживает {@code Mockito.reset()},
 * так что пустой поток возвращается всегда.
 */
@UtilityClass
public class ReactiveMocks {

    /**
     * Пустой поток для реактивных типов, штатное поведение Mockito — для остальных.
     */
    public static final Answer<Object> EMPTY_PUBLISHERS = invocation -> {
        Class<?> returnType = invocation.getMethod().getReturnType();

        if (Flux.class.isAssignableFrom(returnType)) {
            return Flux.empty();
        }

        if (Mono.class.isAssignableFrom(returnType)) {
            return Mono.empty();
        }

        return Answers.RETURNS_DEFAULTS.answer(invocation);
    };

    public static <T> T reactiveMock(Class<T> type) {
        return mock(type, EMPTY_PUBLISHERS);
    }
}
