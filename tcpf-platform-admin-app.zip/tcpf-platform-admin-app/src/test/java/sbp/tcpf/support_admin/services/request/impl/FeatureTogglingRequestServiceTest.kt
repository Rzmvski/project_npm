package sbp.tcpf.support_admin.services.request.impl

import org.junit.jupiter.api.Test
import org.junit.jupiter.params.ParameterizedTest
import org.junit.jupiter.params.provider.MethodSource
import org.mockito.kotlin.*
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.context.TestConfiguration
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Import
import org.springframework.security.test.context.support.WithUserDetails
import org.springframework.test.context.bean.override.mockito.MockitoBean
import reactor.core.publisher.Flux
import sbp.tcpf.routing.api.v1_0.client.model.Node
import sbp.tcpf.support_admin.config.SecurityTestConfig
import sbp.tcpf.support_admin.config.SecurityTestConfig.FIRST_ADMIN
import sbp.tcpf.support_admin.dto.FeatureDelta
import sbp.tcpf.support_admin.dto.FeatureTargetDto
import sbp.tcpf.support_admin.entities.FeatureRequest
import sbp.tcpf.support_admin.facades.Ff4jFacade
import sbp.tcpf.support_admin.mappers.*
import sbp.tcpf.support_admin.model.ApplicationStatus
import sbp.tcpf.support_admin.model.FeatureConfiguration
import sbp.tcpf.support_admin.model.ManualFeatureActivation
import sbp.tcpf.support_admin.repositories.RequestRepository
import sbp.tcpf.support_admin.services.LogicalFeatureAggregator
import sbp.tcpf.support_admin.services.ShardService
import sbp.tcpf.support_admin.services.request.cache.RequestCuratorCacheManager
import sbp.tcpf.support_admin.services.request.resolvers.ResolverConfig
import sbp.tcpf.support_admin.services.request.resolvers.feature.ApproveFeatureResolver
import sbp.tcpf.support_admin.services.request.resolvers.feature.DeclineFeatureResolver
import sbp.tcpf.support_admin.services.request.store.CompositeScriptDataStore
import sbp.tcpf.support_admin.utils.ReactiveMocks.reactiveMock
import java.time.LocalDateTime
import java.util.*

@WithUserDetails(FIRST_ADMIN)
@SpringBootTest(
        classes = [
            FeatureTogglingRequestService::class,
            ApproveFeatureResolver::class,
            DeclineFeatureResolver::class,
            LogicalFeatureAggregator::class,
            LogicalFeatureMapperImpl::class,
            FeatureApplicationMapperImpl::class,
            FeatureTargetMapper::class,
            FeatureActivationMapper::class,
            FeatureSnapshotMapperImpl::class,
            FeatureConfigurationMapperImpl::class,
            CustomPropertyMapperImpl::class,
        ]
)
@Import(
        ResolverConfig::class,
        SecurityTestConfig::class,
        FeatureTogglingRequestServiceTest.Config::class
)
class FeatureTogglingRequestServiceTest {

    @MockitoBean
    lateinit var compositeScriptDataStore: CompositeScriptDataStore

    @MockitoBean
    lateinit var repository: RequestRepository<FeatureRequest, String, Class<FeatureRequest>>

    @MockitoBean
    lateinit var ff4jFacade: Ff4jFacade

    @MockitoBean
    lateinit var cacheManager: RequestCuratorCacheManager

    @Autowired
    lateinit var requestService: FeatureTogglingRequestService

    private val featureUid = "featureUid"

    @TestConfiguration
    class Config {
        @Bean
        fun shardService(): ShardService {
            val shardService = reactiveMock(ShardService::class.java)
            given(shardService.getNodes()).willReturn(
                    Flux.just(
                            Node.builder()
                                .shardId(1005)
                                .key("P5")
                                .build(),
                            Node.builder()
                                .shardId(1005)
                                .key("S5")
                                .build()
                    )
            )

            return shardService
        }
    }

    @Test
    fun `should decline application`() {
        val uuid = UUID.randomUUID()

        val request = FeatureRequest()
            .apply {
                uid = "reasonId"
                rqUid = uuid
                target = FeatureTargetDto(FeatureTargetDto.Type.DIRECT, "module", null)
                delta = FeatureDelta(
                        FeatureConfiguration.builder()
                            .activation(ManualFeatureActivation.builder().build())
                            .build(),
                        null
                )
                requestStatus = ApplicationStatus.PENDING.value
                createdAt = LocalDateTime.now()
                createdBy = FIRST_ADMIN
            }

        given { cacheManager.readAll(FeatureRequest::class.java) }.willReturn(listOf(request))
        given { repository.save(any()) }.willAnswer { invocation -> invocation.getArgument(0) }

        requestService.resolve(uuid, ApplicationStatus.DECLINE)

        verify(repository, only()).save(any())
        verifyNoInteractions(ff4jFacade)
    }

    companion object {
        @JvmStatic
        fun deltas(): List<FeatureDelta> {
            return listOf(
                    FeatureDelta(
                            null,
                            FeatureConfiguration.builder()
                                .activation(
                                        ManualFeatureActivation.builder()
                                            .enabled(false)
                                            .build()
                                )
                                .build(),
                    ),
                    FeatureDelta(
                            FeatureConfiguration.builder()
                                .activation(
                                        ManualFeatureActivation.builder()
                                            .enabled(false)
                                            .build()
                                )
                                .build(),
                            FeatureConfiguration.builder()
                                .activation(
                                        ManualFeatureActivation.builder()
                                            .enabled(true)
                                            .build()
                                )
                                .build(),
                    ),
                    FeatureDelta(
                            FeatureConfiguration.builder()
                                .activation(
                                        ManualFeatureActivation.builder()
                                            .enabled(false)
                                            .build()
                                )
                                .build(),
                            null
                    )
            )
        }
    }

    @ParameterizedTest
    @MethodSource("deltas")
    fun `should approve application`(changes: FeatureDelta) {
        val uuid = UUID.randomUUID()

        val request = FeatureRequest()
            .apply {
                uid = "reasonId"
                rqUid = uuid
                target = FeatureTargetDto(FeatureTargetDto.Type.DIRECT, "module", null)
                delta = changes
                requestStatus = ApplicationStatus.PENDING.value
                createdAt = LocalDateTime.now()
                createdBy = FIRST_ADMIN
            }

        given { cacheManager.readAll(FeatureRequest::class.java) }.willReturn(listOf(request))
        given { repository.save(any()) }.willAnswer { invocation -> invocation.getArgument(0) }

        requestService.resolve(uuid, ApplicationStatus.APPROVED)

        verify(repository, only()).save(any())

        when (changes.type()) {
            FeatureDelta.ChangeType.CREATE -> verify(ff4jFacade).create(any())
            FeatureDelta.ChangeType.UPDATE -> verify(ff4jFacade).update(any())
            FeatureDelta.ChangeType.DELETE -> verify(ff4jFacade).delete(any())
        }
    }
}
