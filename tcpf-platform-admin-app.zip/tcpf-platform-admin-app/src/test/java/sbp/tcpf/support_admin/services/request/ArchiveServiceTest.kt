package sbp.tcpf.support_admin.services.request

import org.apache.curator.utils.ZKPaths
import org.awaitility.Awaitility.await
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertDoesNotThrow
import org.junit.jupiter.params.ParameterizedTest
import org.junit.jupiter.params.provider.MethodSource
import org.junit.jupiter.params.provider.NullSource
import org.mockito.kotlin.any
import org.mockito.kotlin.given
import org.mockito.kotlin.then
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.context.annotation.Import
import org.springframework.test.context.TestPropertySource
import org.springframework.test.context.bean.override.mockito.MockitoBean
import sbp.tcpf.support_admin.config.CuratorTestConfig
import sbp.tcpf.support_admin.configs.QueueCuratorConfig
import sbp.tcpf.support_admin.configs.properties.ResolveRequestServiceProperties
import sbp.tcpf.support_admin.configs.properties.ScriptServiceProperties
import sbp.tcpf.support_admin.configs.serde.QueueStringSerializer
import sbp.tcpf.support_admin.entities.AbstractRequest
import sbp.tcpf.support_admin.entities.ScriptRequest
import sbp.tcpf.support_admin.exceptions.ResourceNotFoundException
import sbp.tcpf.support_admin.model.ApplicationStatus
import sbp.tcpf.support_admin.model.CreateScriptApplicationRequest
import sbp.tcpf.support_admin.model.ScriptApplication
import sbp.tcpf.support_admin.services.request.ArchiveServiceTest.Companion.ARCHIVE_TTL
import sbp.tcpf.support_admin.services.request.cache.ArchiveCacheListener
import sbp.tcpf.support_admin.utils.zookeeper.MockZookeeperManager
import java.util.*
import java.util.stream.Stream

@TestPropertySource(
        properties = [
            "tcpf-platform-admin-app.resolve-request-service.archive-ttl=${ARCHIVE_TTL}"
        ]
)
@EnableConfigurationProperties(
        ScriptServiceProperties::class,
        ResolveRequestServiceProperties::class
)
@SpringBootTest(
        classes = [
            ArchiveService::class,
            ArchiveCacheListener::class,
            QueueStringSerializer::class,
        ]
)
@Import(
        CuratorTestConfig::class,
        QueueCuratorConfig::class,
)
class ArchiveServiceTest {

    companion object {
        const val ARCHIVE_TTL = "1s"

        @JvmStatic
        fun invalidValues(): Stream<AbstractRequest> {
            return Stream.of(
//                    FeatureRequest().apply {
//                        uid = "reasonId"
//                        requestStatus = ApplicationStatus.CREATED.value
//                        action = FeatureApplicationAction.CREATE
//                    },
            )
        }
    }

    @Autowired
    lateinit var mockZookeeperManager: MockZookeeperManager

    @MockitoBean
    lateinit var requestService: RequestService<String, CreateScriptApplicationRequest, ScriptApplication>

    @Autowired
    lateinit var archiveService: ArchiveService

    @Test
    fun `should archive script application`() {
        val reasonId = "reasonId"
        val application = ScriptRequest().apply {
            rqUid = UUID.randomUUID()
            executionUid = "executionId"
            uid = reasonId
            requestStatus = ApplicationStatus.CREATED.value
        }

        mockZookeeperManager.createNode(application)

        await().untilAsserted {
            then(requestService).should().resolve(reasonId, ApplicationStatus.ARCHIVED)
        }
    }

    @Test
    fun `should skip archive when request is gone`() {
        val reasonId = "reasonId"
        given { requestService.resolve(reasonId, ApplicationStatus.ARCHIVED) }
            .willThrow(ResourceNotFoundException::class.java)

        val application = ScriptRequest().apply {
            rqUid = UUID.randomUUID()
            executionUid = "executionId"
            uid = reasonId
            requestStatus = ApplicationStatus.CREATED.value
        }

        assertDoesNotThrow { archiveService.consumeMessage(application.path) }

        then(requestService).should().resolve(any(), any())
    }

    @ParameterizedTest
    @MethodSource("invalidValues")
    @NullSource
    fun `should ignore nodes with invalid values`(invalidNodeValue: Any?) {
        mockZookeeperManager.createNode(
                invalidNodeValue,
                ZKPaths.makePath(ZKPaths.PATH_SEPARATOR, UUID.randomUUID().toString())
        )

        await().untilAsserted {
            then(requestService).shouldHaveNoInteractions()
        }
    }
}
