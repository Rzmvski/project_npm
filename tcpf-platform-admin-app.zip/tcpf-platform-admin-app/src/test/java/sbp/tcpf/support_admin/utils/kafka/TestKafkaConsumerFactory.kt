package sbp.tcpf.support_admin.utils.kafka

import jakarta.annotation.PreDestroy
import org.apache.kafka.clients.consumer.Consumer
import org.springframework.kafka.core.DefaultKafkaConsumerFactory
import org.springframework.kafka.test.EmbeddedKafkaBroker
import org.springframework.stereotype.Component

@Component
class TestKafkaConsumerFactory(
    private val embeddedKafka: EmbeddedKafkaBroker,
    private val factory: DefaultKafkaConsumerFactory<*, *>,
) {

    private val consumers = mutableMapOf<String, Consumer<*, *>>()

    fun createConsumer(topic: String): Consumer<*, *> {
        return consumers.getOrPut(topic) {
            val consumer = factory.createConsumer()
            embeddedKafka.consumeFromAnEmbeddedTopic(consumer, topic)
            consumers[topic] = consumer

            return consumer
        }
    }

    @PreDestroy
    fun clear() {
        consumers.forEach { (_, value) -> value.close() }
    }
}
