package sbp.tcpf.support_admin.utils

import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.Mock
import org.mockito.junit.jupiter.MockitoExtension
import org.mockito.kotlin.any
import org.mockito.kotlin.given
import org.springframework.core.ParameterizedTypeReference
import org.springframework.http.codec.ServerSentEvent
import org.springframework.web.reactive.function.client.WebClient
import reactor.core.publisher.Flux

@ExtendWith(MockitoExtension::class)
class MvcExtensionsTest {

    @Mock
    lateinit var response: WebClient.ResponseSpec

    @Test
    fun `should unwrap server sent event to data`() {
        val strings = listOf("one", "two", "three")
        val sse = Flux
            .fromIterable(strings)
            .map { ServerSentEvent.builder(it).build() }

        given { response.bodyToFlux(any<ParameterizedTypeReference<*>>()) }
            .willReturn(sse)

        response
            .bodyToSseDataFlux<String>()
            .test()
            .recordWith { mutableListOf() }
            .thenConsumeWhile { true }
            .consumeRecordedWith { store ->
                assertThat(store).containsAll(strings)
            }
            .verifyComplete()
    }

    @Test
    fun `should return empty stream if data doesn't present`() {
        val strings = listOf("one", "two", "three")
        val sse = Flux
            .fromIterable(strings)
            .map { ServerSentEvent.builder<String>().event("heartbeat").comment(it).build() }

        given { response.bodyToFlux(any<ParameterizedTypeReference<*>>()) }
            .willReturn(sse)

        response
            .bodyToSseDataFlux<String>()
            .test()
            .recordWith { mutableListOf() }
            .thenConsumeWhile { true }
            .consumeRecordedWith { store ->
                assertThat(store).isEmpty()
            }
            .verifyComplete()
    }
}
