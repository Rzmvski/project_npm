package sbp.tcpf.support_admin.wrappers

import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.mockito.kotlin.given
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.bean.override.mockito.MockitoBean
import reactor.core.publisher.Flux
import sbp.tcpf.routing.api.v1_0.client.model.Monitoring
import sbp.tcpf.routing.api.v1_0.client.model.MonitoringState
import sbp.tcpf.support_admin.clients.feign.routing.RoutingMonitoringManagementApiClient
import sbp.tcpf.support_admin.config.UOWTestConfig

@SpringBootTest(classes = [
    SafeUnitOfWorkOperations::class,
    UOWTestConfig::class
])
class SafeUnitOfWorkOperationsTest {

    companion object {
        private const val OPERATION = "some operation"
        private const val NODE = "node"
    }

    @MockitoBean
    lateinit var monitoringManagementApiClient: RoutingMonitoringManagementApiClient

    @Autowired
    lateinit var safeUnitOfWorkOperations: SafeUnitOfWorkOperations

    @BeforeEach
    fun setUp() {
        // SafeUnitOfWorkOperations делает .filter { it.id == nodeName }.single(),
        // поэтому мониторинг по ноде должен быть ровно один
        givenMonitoring(MonitoringState.UP)
    }

    @Test
    fun `should return result`() {
        val response = "response"
        val result = safeUnitOfWorkOperations.tryCallOnNode(OPERATION, NODE) { response }

        assertThat(result).isEqualTo(response)
    }

    @Test
    fun `should return null when work throws exception`() {
        val result = safeUnitOfWorkOperations.tryCallOnNode<String?>(OPERATION, NODE) {
            throw RuntimeException("oops, something went wrong")
        }

        assertThat(result).isNull()
    }

    @Test
    fun `should return null when node is down`() {
        givenMonitoring(MonitoringState.DOWN)

        val result = safeUnitOfWorkOperations.tryCallOnNode(OPERATION, NODE) { "response" }

        assertThat(result).isNull()
    }

    private fun givenMonitoring(state: MonitoringState) {
        given(monitoringManagementApiClient.getDbMonitorings())
            .willReturn(Flux.just(Monitoring(NODE, state, null, null)))
    }
}
