package sbp.tcpf.support_admin.services.request

import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.context.annotation.Import
import org.springframework.test.context.TestPropertySource
import sbp.tcpf.support_admin.config.CommonTestConfig
import sbp.tcpf.support_admin.configs.properties.ResolveRequestServiceProperties
import sbp.tcpf.support_admin.entities.ScriptRequest
import java.util.*

@TestPropertySource(
        properties = [
            "tcpf-platform-admin-app.resolve-request-service.encrypted-fields=jiraId,executedBy",
        ]
)
@EnableConfigurationProperties(ResolveRequestServiceProperties::class)
@SpringBootTest(
        classes = [
            RequestCryptoService::class,
        ]
)
@Import(CommonTestConfig::class)
class RequestCryptoServiceTest {

    @Autowired
    lateinit var cryptoService: RequestCryptoService<ScriptRequest>

    @Test
    fun `should encrypt and decrypt fields`() {
        val original = ScriptRequest.builder()
            .uid("test-uid")
            .jiraId("SECRET-123")
            .executedBy("secret-executor")
            .build()

        val encrypted = cryptoService.encrypt(original)

        assertThat(encrypted.jiraId).isNotEqualTo(original.jiraId)
        assertThat(encrypted.executedBy).isNotEqualTo(original.executedBy)

        val decrypted = cryptoService.decrypt(encrypted)

        assertThat(decrypted.jiraId).isEqualTo(original.jiraId)
        assertThat(decrypted.executedBy).isEqualTo(original.executedBy)
    }

    @Test
    fun `should not modify non-encrypted fields`() {
        val uid = UUID.randomUUID()
        val original = ScriptRequest.builder()
            .uid("test-uid")
            .rqUid(uid)
            .jiraId("SCRT-456")
            .build()

        val encrypted = cryptoService.encrypt(original)

        assertThat(encrypted.rqUid).isEqualTo(uid)
        assertThat(encrypted.uid).isEqualTo(original.uid)
    }

    @Test
    fun `should handle null encrypted fields`() {
        val original = ScriptRequest.builder()
            .uid("test-uid")
            .build()

        val result = cryptoService.encrypt(original)

        assertThat(result.jiraId).isNull()
    }
}
