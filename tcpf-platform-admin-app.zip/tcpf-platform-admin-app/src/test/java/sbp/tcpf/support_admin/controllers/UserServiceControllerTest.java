package sbp.tcpf.support_admin.controllers;

import sbp.tcpf.support.commons.audit.listeners.AuthorizationFailureEventListener;
import sbp.tcpf.support.commons.audit.listeners.AuthorizedEventListener;
import sbp.tcpf.support.commons.audit.publishers.DefaultAuthEventPublisher;
import sbp.tcpf.support_admin.config.AuditTestConfig;
import sbp.tcpf.support_admin.config.CommonTestConfig;
import sbp.tcpf.support_admin.config.SecurityTestConfig;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.security.test.context.support.WithUserDetails;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static sbp.tcpf.support_admin.config.SecurityTestConfig.FIRST_ADMIN;
import static sbp.tcpf.support_admin.config.SecurityTestConfig.SIMPLE_PERMISSION;

@WithUserDetails(FIRST_ADMIN)
@AutoConfigureMockMvc(addFilters = false)
@WebMvcTest(UserServiceController.class)
@Import({
        CommonTestConfig.class,
        AuditTestConfig.class,
        SecurityTestConfig.class,
        AuthorizedEventListener.class,
        AuthorizationFailureEventListener.class,
        DefaultAuthEventPublisher.class,
})
class UserServiceControllerTest {

    private static final String URL = "/invoke/support-admin/user-service";

    @Autowired
    ObjectMapper objectMapper;
    @Autowired
    MockMvc mockMvc;

    @Test
    void shouldReturnPermissions() throws Exception {
        var response = mockMvc.perform(get(URL + "/permissions"))
                              .andExpect(status().isOk())
                              .andDo(print())
                              .andReturn().getResponse();

        Set<String> permissions = objectMapper.readValue(response.getContentAsString(), new TypeReference<>() {
        });

        assertThat(permissions)
                .isNotEmpty()
                .containsOnly(SIMPLE_PERMISSION.getAuthority());
    }

    @Test
    void shouldReturnUserRoles() throws Exception {
        var response = mockMvc.perform(get(URL + "/roles"))
                              .andExpect(status().isOk())
                              .andDo(print())
                              .andReturn().getResponse();

        Set<String> roles = objectMapper.readValue(response.getContentAsString(), new TypeReference<>() {
        });

        assertThat(roles)
                .isNotEmpty()
                .containsOnly("ADMIN");
    }
}
