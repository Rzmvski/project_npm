package sbp.tcpf.support_admin.config;

import sbp.tcpf.audit.core.AuditAutoConfiguration;
import sbp.tcpf.audit.core.properties.AuditProperties;
import sbp.tcpf.audit.core.publishers.AnnotationAuditEventPublisher;
import sbp.tcpf.audit.core.services.EventParamsFactory;
import sbp.tcpf.audit.core.services.EventService;
import sbp.tcpf.support.commons.audit.concurrency.UserInfoTaskDecorator;
import sbp.tcpf.support.commons.audit.provider.ArmUserProvider;
import sbp.tcpf.support_admin.configs.audit.AuditEventConfig;
import sbp.tcpf.support_admin.configs.audit.ReactiveAnnotationAuditEventPublisher;

import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.aop.AopAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;

@EnableAspectJAutoProxy
@Import({
        AnnotationAuditEventPublisher.class,
        ReactiveAnnotationAuditEventPublisher.class,
        AuditEventConfig.class,
        EventService.class,
        EventParamsFactory.class,
        UserInfoTaskDecorator.class,
        ArmUserProvider.class
})
@ImportAutoConfiguration(classes = {
        AopAutoConfiguration.class,
        AuditAutoConfiguration.class,
})
@EnableConfigurationProperties(AuditProperties.class)
@TestPropertySource(properties = {
        "audit.metamodelPath=classpath:model.json"
})
@TestConfiguration
public class AuditTestConfig {

    @Bean
    public NoOpEventListener noOpEventListener() {
        return new NoOpEventListener();
    }
}
