package sbp.tcpf.support_admin.controllers;

import sbp.tcpf.support_admin.config.CommonTestConfig;
import sbp.tcpf.support_admin.configs.properties.EnvironmentProperties;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@EnableConfigurationProperties(EnvironmentProperties.class)
@TestPropertySource(properties = "deployment.environment.type=ift")
@AutoConfigureMockMvc(addFilters = false)
@Import(CommonTestConfig.class)
@WebMvcTest(EnvironmentInfoController.class)
class EnvironmentInfoControllerTest {

    @Autowired
    MockMvc mockMvc;

    private static final String URL = "/config/environment";

    @Test
    void shouldReturnConfiguredTypeAsStringEnum() throws Exception {
        String body = mockMvc.perform(get(URL))
                             .andExpect(status().isOk())
                             .andReturn().getResponse().getContentAsString();

        // Ответ — JSON-строка (enum), а не объект { "type": "ift" }.
        assertThat(body).isEqualTo("\"ift\"");
    }
}