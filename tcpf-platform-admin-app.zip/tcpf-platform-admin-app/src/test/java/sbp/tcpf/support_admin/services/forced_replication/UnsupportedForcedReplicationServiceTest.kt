package sbp.tcpf.support_admin.services.forced_replication

import org.assertj.core.api.Assertions.assertThat
import org.assertj.core.api.Assertions.assertThatThrownBy
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import sbp.tcpf.support_admin.model.ServiceModeState

@SpringBootTest(
        classes = [
            UnsupportedForcedReplicationService::class,
            DefaultForcedReplicationService::class,
        ]
)
class UnsupportedForcedReplicationServiceTest {

    companion object {
        private const val SHARD_ID = 1005
    }

    @Autowired
    lateinit var forcedReplicationService: ForcedReplicationService

    @Test
    fun `should return unsupported status when service mode status called`() {
        val result = forcedReplicationService.getServiceModeStatus()

        assertThat(result).isNotNull
        assertThat(result.status).isEqualTo(ServiceModeState.UNSUPPORTED)
    }

    @Test
    fun `should throw unsupported exception when replication status called`() {
        assertThatThrownBy { forcedReplicationService.getReplicationStatus(SHARD_ID) }
            .isInstanceOf(UnsupportedOperationException::class.java)
    }

    @Test
    fun `should throw unsupported exception when start replication called`() {
        assertThatThrownBy { forcedReplicationService.startReplication(SHARD_ID) }
            .isInstanceOf(UnsupportedOperationException::class.java)
    }

    @Test
    fun `should throw unsupported exception when undo replication called`() {
        assertThatThrownBy { forcedReplicationService.undoReplication(SHARD_ID) }
            .isInstanceOf(UnsupportedOperationException::class.java)
    }

    @Test
    fun `should throw unsupported exception when change service mode called`() {
        assertThatThrownBy {
            forcedReplicationService.changeServiceMode(ServiceModeState.ENABLED)
        }.isInstanceOf(UnsupportedOperationException::class.java)
    }
}
