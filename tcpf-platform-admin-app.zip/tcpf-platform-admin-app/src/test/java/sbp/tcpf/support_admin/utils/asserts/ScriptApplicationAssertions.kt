package sbp.tcpf.support_admin.utils.asserts

import org.assertj.core.api.AbstractAssert
import org.assertj.core.api.Assertions.assertThat
import sbp.tcpf.support_admin.dto.ScriptApplicationDto
import sbp.tcpf.support_admin.model.ApplicationStatus
import sbp.tcpf.support_admin.model.Restrictions

fun assertScriptApplication(actual: ScriptApplicationDto?): ScriptApplicationAssertions = ScriptApplicationAssertions(actual)

class ScriptApplicationAssertions(private val actual: ScriptApplicationDto?) :
    AbstractAssert<ScriptApplicationAssertions, ScriptApplicationDto>(actual, ScriptApplicationAssertions::class.java) {

    fun hasLocation(scriptId: String, shardId: Int? = null) = apply {
        assertThat(actual?.location).satisfies({ location ->
            assertThat(location?.scriptId).isEqualTo(scriptId)
            assertThat(location?.shardId).isEqualTo(shardId)
        })
    }

    fun hasCreator(login: String?) = apply {
        assertThat(actual?.createdBy).isEqualTo(login)
        assertThat(actual?.created).isNotNull
    }

    fun hasResolver(login: String?) = apply {
        assertThat(actual?.resolvedBy).isEqualTo(login)
        assertThat(actual?.resolvedAt).isNotNull
    }

    fun hasStatus(status: ApplicationStatus) = apply {
        assertThat(actual?.status).isEqualTo(status)
    }

    fun hasRestrictions(expected: Restrictions?) = apply {
        assertThat(actual?.restrictions).isEqualTo(expected)
    }

}
