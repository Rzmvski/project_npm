package sbp.tcpf.support_admin.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.jetbrains.annotations.NotNull;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.ResultHandler;
import org.springframework.test.web.servlet.ResultMatcher;
import lombok.experimental.UtilityClass;

import java.util.ArrayList;
import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.asyncDispatch;

/**
 * Хелпер для контроллеров, которые после перехода на reactive-feign возвращают {@code Flux}/{@code Mono}.
 * <p>
 * Spring MVC отдаёт такие ответы асинхронно (DeferredResult для {@code Mono} и для {@code Flux}
 * с {@code produces=application/json}, SseEmitter для {@code produces=text/event-stream}),
 * поэтому и тело ответа, и разрешённое исключение доступны только после async-диспатча.
 * <p>
 * Вся «асинхронная» механика собрана здесь, чтобы при необходимости её правки менялся один файл,
 * а не каждый тест по отдельности.
 */
@UtilityClass
public class AsyncMvc {

    private static final String SSE_DATA_PREFIX = "data:";

    /**
     * Выполняет запрос и, если обработка ушла в async, дожидается её завершения.
     */
    public static ResultActions perform(MockMvc mockMvc, RequestBuilder requestBuilder) throws Exception {
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();

        if (!result.getRequest().isAsyncStarted()) {
            return new CompletedResultActions(result);
        }

        return mockMvc.perform(asyncDispatch(result));
    }

    /**
     * Читает коллекцию из тела ответа независимо от того, отдан он как JSON-массив
     * или как поток server-sent events.
     */
    public static <T> List<T> readList(
            ObjectMapper objectMapper,
            MockHttpServletResponse response,
            Class<T> type
    ) throws Exception {
        String body = response.getContentAsString();

        if (body == null || body.isBlank()) {
            return List.of();
        }

        if (isSse(body)) {
            return readSse(objectMapper, body, type);
        }

        return objectMapper.readValue(
                body,
                objectMapper.getTypeFactory().constructCollectionType(List.class, type)
        );
    }

    /**
     * Читает единичный объект из тела ответа: JSON-объект либо одно событие SSE.
     */
    public static <T> T readSingle(
            ObjectMapper objectMapper,
            MockHttpServletResponse response,
            Class<T> type
    ) throws Exception {
        String body = response.getContentAsString();

        if (body == null || body.isBlank()) {
            return null;
        }

        if (isSse(body)) {
            List<T> events = readSse(objectMapper, body, type);
            return events.isEmpty() ? null : events.get(0);
        }

        return objectMapper.readValue(body, type);
    }

    private static boolean isSse(String body) {
        return body.stripLeading().startsWith(SSE_DATA_PREFIX);
    }

    private static <T> List<T> readSse(ObjectMapper objectMapper, String body, Class<T> type) throws Exception {
        List<T> events = new ArrayList<>();

        for (String line : body.split("\\R")) {
            String trimmed = line.trim();

            if (!trimmed.startsWith(SSE_DATA_PREFIX)) {
                continue;
            }

            String payload = trimmed.substring(SSE_DATA_PREFIX.length()).trim();

            if (payload.isEmpty()) {
                continue;
            }

            // строковые элементы уходят в поток «как есть», без JSON-кавычек
            if (type == String.class && !payload.startsWith("\"")) {
                events.add(type.cast(payload));
            } else {
                events.add(objectMapper.readValue(payload, type));
            }
        }

        return events;
    }

    private record CompletedResultActions(MvcResult result) implements ResultActions {

        @NotNull
        @Override
        public ResultActions andExpect(ResultMatcher matcher) throws Exception {
            matcher.match(result);
            return this;
        }

        @NotNull
        @Override
        public ResultActions andDo(ResultHandler handler) throws Exception {
            handler.handle(result);
            return this;
        }

        @NotNull
        @Override
        public MvcResult andReturn() {
            return result;
        }
    }
}
