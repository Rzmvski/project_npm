package sbp.tcpf.support_admin.controllers;

import sbp.tcpf.routing.client.RoutingInfoProvider;
import sbp.tcpf.routing.client.domain.NodeContext;
import sbp.tcpf.routing.client.domain.NodeStatusDto;
import sbp.tcpf.routing.client.domain.RoutingIndex;
import sbp.tcpf.routing.client.domain.exception.IndexNotFoundException;
import sbp.tcpf.support_admin.config.AuditTestConfig;
import sbp.tcpf.support_admin.config.CommonTestConfig;
import sbp.tcpf.support_admin.config.NoOpEventListener;
import sbp.tcpf.support_admin.config.SecurityTestConfig;
import sbp.tcpf.support_admin.enums.OuterErrorCodes;
import sbp.tcpf.support_admin.mappers.RoutingTypeMapperImpl;
import sbp.tcpf.support_admin.model.RoutingType;
import sbp.tcpf.support_admin.model.ShardInfo;
import sbp.tcpf.support_admin.services.RoutingObjectService;
import sbp.tcpf.support_admin.utils.AuditAssertions;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbt.audit.core.model.v2.event.Event;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.security.test.context.support.WithUserDetails;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.bean.override.mockito.MockitoSpyBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.util.List;

import static org.apache.commons.lang3.tuple.Pair.of;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static sbp.tcpf.support_admin.config.SecurityTestConfig.FIRST_ADMIN;
import static sbp.tcpf.support_admin.utils.AuditAssertions.thenEventSatisfies;

@WithUserDetails(FIRST_ADMIN)
@AutoConfigureMockMvc(addFilters = false)
@WebMvcTest(ShardInfoController.class)
@Import({
        CommonTestConfig.class,
        RoutingObjectService.class,
        RoutingTypeMapperImpl.class,
        AuditTestConfig.class,
        SecurityTestConfig.class,
})
class ShardInfoControllerTest {

    private static final String URL = "/invoke/support-admin/shard-info-service/routing-objects/shard";
    private static final String CONTRACT_NUMBER = "ТКП123456789";
    private static final Integer SHARD_ID = 1;
    private static final String NODE_KEY = "nodeKey";

    @MockitoBean
    RoutingInfoProvider routingInfoProvider;
    @MockitoSpyBean
    NoOpEventListener listener;
    @Captor
    ArgumentCaptor<Event> eventArgumentCaptor;
    @Autowired
    ObjectMapper objectMapper;
    @Autowired
    MockMvc mockMvc;

    @Test
    void getShardInfo() throws Exception {
        given(routingInfoProvider.getNodeContext(any(RoutingIndex.class), any())).willReturn(getNodeContext());

        MvcResult result = mockMvc.perform(get(URL)
                        .queryParam("type", RoutingType.CONTRACT_NUMBER.name())
                        .queryParam("key", CONTRACT_NUMBER))
                .andExpect(status().isOk())
                .andDo(print())
                .andReturn();

        ShardInfo response = objectMapper.readValue(result.getResponse().getContentAsString(), ShardInfo.class);

        then(listener).should().listen(eventArgumentCaptor.capture());
        Event event = eventArgumentCaptor.getValue();
        thenEventSatisfies(event, AuditAssertions.EventExpectations.of()
                                                                   .eventName("SHARD_INFO")
                                                                   .paramsAsserts(List.of(
                                                                           of("shardId", value -> assertThat(value).isEqualTo(SHARD_ID.toString())),
                                                                           of("NodeKey", value -> assertThat(value).isEqualTo(NODE_KEY)),
                                                                           of("errorCode", value -> assertThat(value).isEqualTo(String.valueOf(
                                                                                   OuterErrorCodes.SUCCESS.getCode()
                                                                           )))
                                                                   )));

        then(routingInfoProvider).should().getNodeContext(RoutingIndex.CONTRACT_NUMBER, CONTRACT_NUMBER);
        assertThat(response).isNotNull();
    }

    private NodeContext getNodeContext() {
        return NodeContext.of(
                null,
                "semaphoreKey",
                NODE_KEY,
                "version",
                NodeStatusDto.UNKNOWN,
                SHARD_ID,
                "dcKey",
                0
        );
    }

    @Test
    void shouldReturnInfoWhenIndexNotFound() throws Exception {
        when(routingInfoProvider.getNodeContext(any(RoutingIndex.class), any()))
                .thenThrow(new IndexNotFoundException(RoutingIndex.CONTRACT_NUMBER.name(), CONTRACT_NUMBER));

        mockMvc.perform(get(URL)
                        .queryParam("type", RoutingType.CONTRACT_NUMBER.name())
                        .queryParam("key", CONTRACT_NUMBER))
                .andExpect(status().isOk())
                .andExpect(result -> assertThat(result.getResponse().getContentAsString()).isEmpty())
                .andDo(print());

        then(listener).should().listen(eventArgumentCaptor.capture());
        Event event = eventArgumentCaptor.getValue();
        thenEventSatisfies(event, AuditAssertions.EventExpectations.of()
                                                                   .eventName("SHARD_INFO")
                                                                   .paramsAsserts(List.of(
                                                                           of("shardId", value -> assertThat(value).isNull()),
                                                                           of("NodeKey", value -> assertThat(value).isNull()),
                                                                           of("errorCode", value -> assertThat(value).isEqualTo(String.valueOf(
                                                                                   OuterErrorCodes.SUCCESS.getCode()
                                                                           )))
                                                                   )));
    }
}
