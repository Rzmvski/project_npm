package sbp.tcpf.support_admin.services

import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.mockito.kotlin.any
import org.mockito.kotlin.given
import org.mockito.kotlin.then
import org.mockito.kotlin.times
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.bean.override.mockito.MockitoBean
import sbp.tcpf.ff4j.admin.domain.TcpfFeature
import sbp.tcpf.support.commons.auth.services.UserService
import sbp.tcpf.support_admin.configs.properties.ResolveRequestServiceProperties
import sbp.tcpf.support_admin.dto.FeatureIdentity
import sbp.tcpf.support_admin.dto.FeatureTargetDto
import sbp.tcpf.support_admin.dto.LogicalFeatureDto
import sbp.tcpf.support_admin.entities.FeatureRequest
import sbp.tcpf.support_admin.facades.Ff4jFacade
import sbp.tcpf.support_admin.mappers.*
import sbp.tcpf.support_admin.model.*
import sbp.tcpf.support_admin.services.request.FeatureRequestFactory
import sbp.tcpf.support_admin.services.request.RequestService
import java.time.LocalDateTime
import java.util.*

@EnableConfigurationProperties(ResolveRequestServiceProperties::class)
@SpringBootTest(
        classes = [
            FeatureTogglingService::class,
            Ff4jFacade::class,
            FeatureRequestFactory::class,
            LogicalFeatureMapperImpl::class,
            FeatureTargetMapper::class,
            FeatureMapperImpl::class,
            FeatureConfigurationMapperImpl::class,
            FeatureActivationMapper::class,
            CustomPropertyMapperImpl::class,
            FeatureStatisticsMapperImpl::class,
        ]
)
class FeatureTogglingServiceTest {

    @MockitoBean
    lateinit var ff4jFacade: Ff4jFacade

    @MockitoBean
    lateinit var requestService: RequestService<UUID, FeatureRequest, FeatureApplication>

    @MockitoBean
    lateinit var userService: UserService

    @Autowired
    lateinit var featureTogglingService: FeatureTogglingService

    @Test
    fun `should load features`() {
        given { ff4jFacade.getLogicalFeatures() }.willReturn(
                listOf(
                        LogicalFeatureDto(
                                FeatureIdentity(
                                        "feature1",
                                        FeatureTargetDto(FeatureTargetDto.Type.DIRECT, "module1", listOf())
                                ),
                                FeatureConfiguration(
                                        ManualFeatureActivation().enabled(false),
                                        "description",
                                        listOf()
                                ),
                                LocalDateTime.now(),
                                null,
                                false
                        )
                )
        )

        val features = featureTogglingService.getFeatures()

        assertThat(features).isNotEmpty
    }

    @Test
    fun `should return empty when no features`() {
        given { ff4jFacade.getLogicalFeatures() }.willReturn(emptyList())

        val features = featureTogglingService.getFeatures()

        assertThat(features).isEmpty()
    }

    @Test
    fun `should update features`() {
        featureTogglingService.updateFeatures(
                listOf(
                        LogicalFeature(
                                "feature",
                                ShardFeatureTarget.builder()
                                    .module("module")
                                    .nodeKeys(listOf("nodeA", "nodeB"))
                                    .build(),
                                false,
                                FeatureConfiguration(
                                        ManualFeatureActivation().enabled(false),
                                        "description",
                                        listOf()
                                ),
                                LocalDateTime.now(),
                                null,
                        )
                )
        )

        then(ff4jFacade).should(times(2)).update(any())
    }

    @Test
    fun `should load statistics`() {
        given { ff4jFacade.getPhysicalFeatures() }.willReturn(
                listOf(
                        TcpfFeature.builder()
                            .name("feature")
                            .node("node")
                            .hitCount(100)
                            .isHotConfig(false)
                            .createDate(LocalDateTime.now())
                            .build()
                )
        )

        val stats = featureTogglingService.getStatistics()

        assertThat(stats).isNotEmpty
    }

    @Test
    fun `should create request`() {
        val existing = listOf(
                LogicalFeatureDto(
                        FeatureIdentity(
                                "feature",
                                FeatureTargetDto(
                                        FeatureTargetDto.Type.SHARD, "module", listOf("nodeA", "nodeB")
                                )
                        ),
                        FeatureConfiguration(
                                ManualFeatureActivation().enabled(false),
                                "description",
                                listOf()
                        ),
                        LocalDateTime.now(),
                        null,
                        false
                )
        )

        given { ff4jFacade.getLogicalFeatures() }.willReturn(existing)

        featureTogglingService.createApplications(
                listOf(
                        CreateFeaturesRequestInner.builder()
                            .requestId("requestId")
                            .action(FeatureApplicationAction.UPDATE)
                            .feature(
                                    LogicalFeature(
                                            "feature",
                                            ShardFeatureTarget.builder()
                                                .module("module")
                                                .nodeKeys(listOf("nodeA", "nodeB"))
                                                .build(),
                                            false,
                                            FeatureConfiguration(
                                                    ManualFeatureActivation().enabled(true),
                                                    "description",
                                                    listOf()
                                            ),
                                            LocalDateTime.now(),
                                            null,
                                    )
                            )
                            .build()
                )
        )

        then(requestService).should().save(any())
    }
}
