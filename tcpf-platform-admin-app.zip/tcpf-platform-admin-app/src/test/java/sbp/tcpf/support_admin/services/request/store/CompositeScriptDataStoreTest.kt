package sbp.tcpf.support_admin.services.request.store

import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.mockito.ArgumentCaptor
import org.mockito.BDDMockito.willReturn
import org.mockito.Captor
import org.mockito.kotlin.*
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest
import org.springframework.context.annotation.Import
import org.springframework.security.test.context.support.WithUserDetails
import org.springframework.test.context.bean.override.mockito.MockitoBean
import org.springframework.test.context.bean.override.mockito.MockitoSpyBean
import reactor.core.publisher.Flux
import sbp.tcpf.routing.api.v1_0.client.model.Node
import sbp.tcpf.routing.api.v1_0.client.model.NodeStatus
import sbp.tcpf.support_admin.config.CuratorTestConfig
import sbp.tcpf.support_admin.config.SecurityTestConfig
import sbp.tcpf.support_admin.config.SecurityTestConfig.FIRST_ADMIN
import sbp.tcpf.support_admin.config.SecurityTestConfig.SECOND_ADMIN
import sbp.tcpf.support_admin.config.UOWTestConfig
import sbp.tcpf.support_admin.configs.RequestServiceConfig
import sbp.tcpf.support_admin.configs.properties.CuratorLockProperties
import sbp.tcpf.support_admin.configs.properties.ResolveRequestServiceProperties
import sbp.tcpf.support_admin.configs.properties.ScriptServiceProperties
import sbp.tcpf.support_admin.dto.DbRef
import sbp.tcpf.support_admin.dto.ScriptApplicationDto
import sbp.tcpf.support_admin.entities.AbstractRequest
import sbp.tcpf.support_admin.entities.RequestEntity
import sbp.tcpf.support_admin.entities.ScriptRequest
import sbp.tcpf.support_admin.mappers.RequestStatusMapperImpl
import sbp.tcpf.support_admin.mappers.ScriptDbEntityMapper.BUCKET_HASH
import sbp.tcpf.support_admin.mappers.ScriptDbEntityMapperImpl
import sbp.tcpf.support_admin.mappers.ScriptZkEntityMapperImpl
import sbp.tcpf.support_admin.mappers.ShardMapperImpl
import sbp.tcpf.support_admin.model.ApplicationStatus
import sbp.tcpf.support_admin.model.Restrictions
import sbp.tcpf.support_admin.repositories.RequestRepository
import sbp.tcpf.support_admin.repositories.impl.DbRequestRepository
import sbp.tcpf.support_admin.repositories.impl.ZkRequestRepository
import sbp.tcpf.support_admin.services.ShardService
import sbp.tcpf.support_admin.services.lock.CuratorLockManager
import sbp.tcpf.support_admin.services.lock.LockRegistry
import sbp.tcpf.support_admin.services.request.RequestCryptoService
import sbp.tcpf.support_admin.services.request.RequestStatus
import sbp.tcpf.support_admin.services.request.RequestType
import sbp.tcpf.support_admin.services.request.cache.RequestCuratorCacheManager
import sbp.tcpf.support_admin.services.request.dto.ScriptKey
import sbp.tcpf.support_admin.services.request.store.aggregators.ScriptDataAggregator
import sbp.tcpf.support_admin.services.request.store.modifiers.ScriptContentModifier
import sbp.tcpf.support_admin.services.request.store.modifiers.ShardIdModifier
import sbp.tcpf.support_admin.utils.asserts.assertDbRequestEntity
import sbp.tcpf.support_admin.utils.asserts.assertScriptApplication
import sbp.tcpf.support_admin.utils.asserts.assertZkRequestEntity
import java.time.LocalDate
import java.time.LocalDateTime

@WithUserDetails(FIRST_ADMIN)
@DataJpaTest
@EnableConfigurationProperties(
        ScriptServiceProperties::class,
        ResolveRequestServiceProperties::class,
        CuratorLockProperties::class,
)
@Import(
        CompositeScriptDataStore::class,
        RequestServiceConfig::class,
        ScriptDataAggregator::class,
        ScriptDbEntityMapperImpl::class,
        ScriptContentModifier::class,
        ShardIdModifier::class,
        ShardMapperImpl::class,
        RequestStatusMapperImpl::class,
        CuratorLockManager::class,
        LockRegistry::class,
        ZkRequestRepository::class,
        RequestCryptoService::class,
        RequestCuratorCacheManager::class,
        ScriptZkEntityMapperImpl::class,
        UOWTestConfig::class,
        SecurityTestConfig::class,
        CuratorTestConfig::class,
)
class CompositeScriptDataStoreTest {

    @MockitoSpyBean
    lateinit var dbStore: RequestDataStore<ScriptApplicationDto, String, ScriptKey, RequestEntity>

    @MockitoSpyBean
    lateinit var zkStore: RequestDataStore<ScriptApplicationDto, String, ScriptKey, ScriptRequest>

    @MockitoSpyBean
    lateinit var dbRepository: DbRequestRepository

    @MockitoSpyBean
    lateinit var zkRepository: RequestRepository<AbstractRequest, String, Class<AbstractRequest>>

    @MockitoSpyBean
    lateinit var curatorCache: RequestCuratorCacheManager

    @MockitoBean
    lateinit var shardService: ShardService

//    @MockitoBean
//    lateinit var featureMapper: RequestMapper<FeatureRequestDto, FeatureRequest>

    @Captor
    lateinit var dbRequestEntityCaptor: ArgumentCaptor<RequestEntity>

    @Captor
    lateinit var zkRequestEntityCaptor: ArgumentCaptor<ScriptRequest>

    @Autowired
    lateinit var compositeStore: CompositeScriptDataStore

    private val reasonId = "reason-123"
    private val anotherReasonId = "reason-345"
    private val shardId = 1005
    private val dto = ScriptApplicationDto(
            createdBy = "creator",
            location = ScriptKey(reasonId),
            jiraId = "JIRA-1",
            scriptBody = "hello world",
            status = ApplicationStatus.PENDING,
    )

    @BeforeEach
    fun setUp() {
        val activeNode = Node(
                shardId,
                "nodeKey",
                shardId,
                NodeStatus.WORKING,
                "dcKey",
                emptyList()
        )
        given { shardService.getActiveNodeByShardId(shardId) }.willReturn(activeNode)
        given { shardService.getActiveNodes() }.willReturn(Flux.just(activeNode))
    }

    @Test
    fun `should aggregate results from all stores for an application`() {
        val currentRestrictions = Restrictions(true, listOf("nodeKey"))
        val script = "hello world"
        val jira = "jiraId"
        val dbEntity = RequestEntity(
                1,
                BUCKET_HASH,
                reasonId,
                FIRST_ADMIN,
                null,
                SECOND_ADMIN,
                RequestStatus.SUCCESS.id,
                script,
                "logs",
                LocalDate.EPOCH,
                RequestType.SCRIPT_REQUEST.id,
        )
        val zkEntity = ScriptRequest().apply {
            dbRef = DbRef(shardId)
            jiraId = jira
            uid = reasonId
            requestStatus = ApplicationStatus.SUCCESS.value
            createdBy = FIRST_ADMIN
            createdAt = LocalDateTime.now()
            resolvedBy = SECOND_ADMIN
            resolvedAt = LocalDateTime.now()
            restrictions = currentRestrictions
        }

        willReturn(dbEntity).given(dbRepository).findByKeyAndType(
                reasonId, RequestType.SCRIPT_REQUEST
        )
        willReturn(zkEntity).given(curatorCache).getByUid(
                reasonId, ScriptRequest::class.java
        )

        val result = compositeStore.findByKey(reasonId)

        assertScriptApplication(result)
            .hasLocation(scriptId = reasonId, shardId = shardId)
            .hasStatus(ApplicationStatus.SUCCESS)
            .hasCreator(FIRST_ADMIN)
            .hasResolver(SECOND_ADMIN)
            .satisfies({
                assertThat(it?.jiraId).isEqualTo(jira)
                assertThat(it?.restrictions).isEqualTo(currentRestrictions)
                assertThat(it?.scriptBody).isEqualTo(script)
            })
    }

    @Test
    fun `should load all applications from all stores`() {
        val currentRestrictions = Restrictions(true, listOf("nodeKey"))
        val script = "hello world"
        val jira = "jiraId"
        val dbEntity1 = RequestEntity(
                1,
                BUCKET_HASH,
                reasonId,
                FIRST_ADMIN,
                null,
                SECOND_ADMIN,
                RequestStatus.SUCCESS.id,
                script,
                "logs",
                LocalDate.EPOCH,
                RequestType.SCRIPT_REQUEST.id,
        )
        val zkEntity1 = ScriptRequest().apply {
            dbRef = DbRef(shardId)
            jiraId = jira
            uid = reasonId
            requestStatus = ApplicationStatus.SUCCESS.value
            createdBy = FIRST_ADMIN
            createdAt = LocalDateTime.now()
            resolvedBy = SECOND_ADMIN
            resolvedAt = LocalDateTime.now()
            restrictions = currentRestrictions
        }
        val dbEntity2 = RequestEntity(
                2,
                BUCKET_HASH,
                anotherReasonId,
                FIRST_ADMIN,
                null,
                SECOND_ADMIN,
                RequestStatus.SUCCESS.id,
                script,
                "logs",
                LocalDate.EPOCH,
                RequestType.SCRIPT_REQUEST.id,
        )
        val zkEntity2 = ScriptRequest().apply {
            dbRef = DbRef(shardId)
            jiraId = jira
            uid = anotherReasonId
            requestStatus = ApplicationStatus.SUCCESS.value
            createdBy = FIRST_ADMIN
            createdAt = LocalDateTime.now()
            resolvedBy = SECOND_ADMIN
            resolvedAt = LocalDateTime.now()
            restrictions = currentRestrictions
        }

        willReturn(listOf(dbEntity1, dbEntity2)).given(dbRepository).loadByKeysAndType(
                listOf(reasonId, anotherReasonId), RequestType.SCRIPT_REQUEST
        )
        willReturn(listOf(zkEntity1, zkEntity2)).given(curatorCache).readAll(ScriptRequest::class.java)

        val result = compositeStore.loadAll()

        assertThat(result)
            .hasSize(2)
            .allSatisfy { application ->
                assertScriptApplication(application)
                    .hasStatus(ApplicationStatus.SUCCESS)
                    .hasCreator(FIRST_ADMIN)
                    .hasResolver(SECOND_ADMIN)
                    .satisfies({
                        assertThat(it.location.scriptId).isIn(reasonId, anotherReasonId)
                        assertThat(it.location.shardId).isEqualTo(shardId)
                        assertThat(it.jiraId).isEqualTo(jira)
                        assertThat(it.restrictions).isEqualTo(currentRestrictions)
                        assertThat(it.scriptBody).isEqualTo(script)
                    })
            }
    }

    @Test
    fun `should return null when no store has data`() {
        willReturn(null).given(dbRepository).loadByKeysAndType(listOf(reasonId), RequestType.SCRIPT_REQUEST)
        willReturn(null).given(zkStore).findByKey(reasonId)

        val result = compositeStore.findByKey(reasonId)

        assertThat(result).isNull()
    }

    @Test
    fun `should save to all stores`() {
        val savedApplication = compositeStore.save(dto)

        assertScriptApplication(savedApplication)
            .hasLocation(scriptId = reasonId, shardId = shardId)
            .hasCreator(dto.createdBy)
            .hasStatus(ApplicationStatus.PENDING)
            .satisfies({
                assertThat(it.jiraId).isEqualTo(dto.jiraId)
            })

        verify(dbRepository).save(capture(dbRequestEntityCaptor))
        verify(zkRepository).save(capture(zkRequestEntityCaptor))

        assertDbRequestEntity(dbRequestEntityCaptor.value)
            .hasBasicFields(rqUid = reasonId)
            .hasStatus(RequestStatus.PENDING)
            .hasData(rqData = dto.scriptBody)
            .hasCreator(dto.createdBy)

        assertZkRequestEntity(zkRequestEntityCaptor.value)
            .hasBasicFields(uid = reasonId)
            .hasStatus(ApplicationStatus.PENDING)
            .hasCreator(dto.createdBy)
            .hasRestrictions(dto.restrictions)
            .hasShardId(shardId)
    }

    @Test
    fun `should update status in all stores and aggregate result`() {
        val currentRestrictions = Restrictions(true, listOf("nodeKey"))
        val script = "hello world"
        val jira = "jiraId"
        val dbEntity = RequestEntity(
                id = 1,
                rqUid = reasonId,
                creatorLogin = FIRST_ADMIN,
                statusId = RequestStatus.PENDING.id,
                rqData = script,
                requestTypeId = RequestType.SCRIPT_REQUEST.id,
                rowInsTimestamp = LocalDateTime.now()
        )
        val zkEntity = ScriptRequest().apply {
            dbRef = DbRef(shardId)
            jiraId = jira
            uid = reasonId
            requestStatus = ApplicationStatus.PENDING.value
            createdBy = FIRST_ADMIN
            createdAt = LocalDateTime.now()
            restrictions = currentRestrictions
        }

        willReturn(dbEntity).given(dbRepository).findByKeyAndType(
                reasonId, RequestType.SCRIPT_REQUEST
        )
        willReturn(zkEntity).given(curatorCache).getByUid(
                reasonId, ScriptRequest::class.java
        )
        willReturn(zkEntity).given(zkRepository).findByKeyAndType(
                any(), any()
        )

        val result = compositeStore.changeStatus(
                ScriptKey(reasonId, shardId),
                ApplicationStatus.APPROVED
        )

        assertScriptApplication(result)
            .hasLocation(scriptId = reasonId, shardId = shardId)
            .hasStatus(ApplicationStatus.APPROVED)
            .hasCreator(FIRST_ADMIN)
            .hasRestrictions(currentRestrictions)


        verify(dbRepository).save(capture(dbRequestEntityCaptor))
        verify(zkRepository).save(capture(zkRequestEntityCaptor))

        assertDbRequestEntity(dbRequestEntityCaptor.value)
            .hasBasicFields(rqUid = reasonId)
            .hasStatus(RequestStatus.APPROVED)
            .hasData(rqData = script)
            .hasCreator(FIRST_ADMIN)

        assertZkRequestEntity(zkRequestEntityCaptor.value)
            .hasBasicFields(uid = reasonId)
            .hasStatus(ApplicationStatus.APPROVED)
            .hasCreator(FIRST_ADMIN)
            .hasRestrictions(currentRestrictions)
            .hasShardId(shardId)

    }

    @Test
    fun `should execute application in all stores`() {
        val executorLogin = "executor"
        val currentRestrictions = Restrictions(true, listOf("nodeKey"))
        val script = "hello world"
        val jira = "jiraId"
        val dbEntity = RequestEntity(
                id = 1,
                rqUid = reasonId,
                creatorLogin = FIRST_ADMIN,
                approverLogin = SECOND_ADMIN,
                statusId = RequestStatus.APPROVED.id,
                rqData = script,
                requestTypeId = RequestType.SCRIPT_REQUEST.id,
                rowInsTimestamp = LocalDateTime.now()
        )
        val zkEntity = ScriptRequest().apply {
            dbRef = DbRef(shardId)
            jiraId = jira
            uid = reasonId
            requestStatus = ApplicationStatus.APPROVED.value
            createdBy = FIRST_ADMIN
            createdAt = LocalDateTime.now()
            resolvedBy = SECOND_ADMIN
            resolvedAt = LocalDateTime.now()
            restrictions = currentRestrictions
        }

        willReturn(dbEntity).given(dbRepository).findByKeyAndType(
                reasonId, RequestType.SCRIPT_REQUEST
        )
        willReturn(zkEntity).given(curatorCache).getByUid(
                reasonId, ScriptRequest::class.java
        )
        willReturn(zkEntity).given(zkRepository).findByKeyAndType(
                any(), any()
        )

        val result = compositeStore.execute(
                ScriptKey(reasonId, shardId),
                executorLogin
        )

        assertScriptApplication(result)
            .hasLocation(scriptId = reasonId, shardId = shardId)
            .hasStatus(ApplicationStatus.WORKS)
            .hasCreator(FIRST_ADMIN)
            .hasResolver(SECOND_ADMIN)
            .hasRestrictions(currentRestrictions)
            .satisfies({
                assertThat(it.executedBy).isEqualTo(executorLogin)
            })


        verify(dbRepository).save(capture(dbRequestEntityCaptor))
        verify(zkRepository).save(capture(zkRequestEntityCaptor))

        assertDbRequestEntity(dbRequestEntityCaptor.value)
            .hasBasicFields(rqUid = reasonId)
            .hasStatus(RequestStatus.WORKS)
            .hasData(rqData = script)
            .hasCreator(FIRST_ADMIN)
            .hasResolver(SECOND_ADMIN)
            .satisfies({
                assertThat(it?.executorLogin).isEqualTo(executorLogin)
            })

        assertZkRequestEntity(zkRequestEntityCaptor.value)
            .hasBasicFields(uid = reasonId)
            .hasStatus(ApplicationStatus.WORKS)
            .hasCreator(FIRST_ADMIN)
            .hasResolver(SECOND_ADMIN)
            .hasRestrictions(currentRestrictions)
            .hasShardId(shardId)
            .satisfies({
                assertThat(it?.executedBy).isEqualTo(executorLogin)
            })
    }

    @Test
    fun `should resolve application in all stores`() {
        val currentRestrictions = Restrictions(true, listOf("nodeKey"))
        val script = "hello world"
        val jira = "jiraId"
        val dbEntity = RequestEntity(
                id = 1,
                rqUid = reasonId,
                creatorLogin = FIRST_ADMIN,
                statusId = RequestStatus.PENDING.id,
                rqData = script,
                requestTypeId = RequestType.SCRIPT_REQUEST.id,
                rowInsTimestamp = LocalDateTime.now()
        )
        val zkEntity = ScriptRequest().apply {
            dbRef = DbRef(shardId)
            jiraId = jira
            uid = reasonId
            requestStatus = ApplicationStatus.PENDING.value
            createdBy = FIRST_ADMIN
            createdAt = LocalDateTime.now()
            restrictions = currentRestrictions
        }

        willReturn(dbEntity).given(dbRepository).findByKeyAndType(
                reasonId, RequestType.SCRIPT_REQUEST
        )
        willReturn(zkEntity).given(curatorCache).getByUid(
                reasonId, ScriptRequest::class.java
        )
        willReturn(zkEntity).given(zkRepository).findByKeyAndType(
                any(), any()
        )

        val result = compositeStore.resolveStatus(
                ScriptKey(reasonId, shardId),
                ApplicationStatus.DECLINE,
                SECOND_ADMIN
        )

        assertScriptApplication(result)
            .hasLocation(scriptId = reasonId, shardId = shardId)
            .hasStatus(ApplicationStatus.DECLINE)
            .hasCreator(FIRST_ADMIN)
            .hasResolver(SECOND_ADMIN)
            .hasRestrictions(currentRestrictions)


        verify(dbRepository).save(capture(dbRequestEntityCaptor))
        verify(zkRepository).save(capture(zkRequestEntityCaptor))

        assertDbRequestEntity(dbRequestEntityCaptor.value)
            .hasBasicFields(rqUid = reasonId)
            .hasStatus(RequestStatus.DECLINE)
            .hasData(rqData = script)
            .hasCreator(FIRST_ADMIN)
            .hasResolver(SECOND_ADMIN)

        assertZkRequestEntity(zkRequestEntityCaptor.value)
            .hasBasicFields(uid = reasonId)
            .hasStatus(ApplicationStatus.DECLINE)
            .hasCreator(FIRST_ADMIN)
            .hasResolver(SECOND_ADMIN)
            .hasRestrictions(currentRestrictions)
            .hasShardId(shardId)

    }

    @Test
    fun `should save logs in db store only`() {
        val logMessage = "test log"
        val currentRestrictions = Restrictions(true, listOf("nodeKey"))
        val script = "hello world"
        val jira = "jiraId"
        val dbEntity = RequestEntity(
                id = 1,
                rqUid = reasonId,
                creatorLogin = FIRST_ADMIN,
                approverLogin = SECOND_ADMIN,
                statusId = RequestStatus.WORKS.id,
                rqData = script,
                requestTypeId = RequestType.SCRIPT_REQUEST.id,
                rowInsTimestamp = LocalDateTime.now()
        )
        val zkEntity = ScriptRequest().apply {
            dbRef = DbRef(shardId)
            jiraId = jira
            uid = reasonId
            requestStatus = ApplicationStatus.WORKS.value
            createdBy = FIRST_ADMIN
            createdAt = LocalDateTime.now()
            resolvedBy = SECOND_ADMIN
            resolvedAt = LocalDateTime.now()
            restrictions = currentRestrictions
        }

        willReturn(dbEntity).given(dbRepository).findByKeyAndType(
                reasonId, RequestType.SCRIPT_REQUEST
        )

        compositeStore.saveLogs(ScriptKey(reasonId, shardId), logMessage)

        verify(dbRepository).save(capture(dbRequestEntityCaptor))
        verify(zkRepository, never()).save(any())

        assertDbRequestEntity(dbRequestEntityCaptor.value)
            .hasBasicFields(rqUid = reasonId)
            .hasStatus(RequestStatus.WORKS)
            .hasData(rqData = script, rsData = logMessage)
            .hasCreator(FIRST_ADMIN)
            .hasResolver(SECOND_ADMIN)
    }

    @Test
    fun `should return logs`() {
        val logMessage = "test log"
        val script = "hello world"
        val jira = "jiraId"
        val dbEntity = RequestEntity(
                id = 1,
                rqUid = reasonId,
                creatorLogin = FIRST_ADMIN,
                approverLogin = SECOND_ADMIN,
                statusId = RequestStatus.WORKS.id,
                rqData = script,
                rsData = logMessage,
                requestTypeId = RequestType.SCRIPT_REQUEST.id,
                rowInsTimestamp = LocalDateTime.now()
        )
        val zkEntity = ScriptRequest().apply {
            dbRef = DbRef(shardId)
            jiraId = jira
            uid = reasonId
            requestStatus = ApplicationStatus.WORKS.value
            createdBy = FIRST_ADMIN
            createdAt = LocalDateTime.now()
            resolvedBy = SECOND_ADMIN
            resolvedAt = LocalDateTime.now()
        }

        willReturn(dbEntity).given(dbRepository).findByKeyAndType(
                reasonId, RequestType.SCRIPT_REQUEST
        )
        willReturn(zkEntity).given(curatorCache).getByUid(
                reasonId, ScriptRequest::class.java
        )
        willReturn(zkEntity).given(zkRepository).findByKeyAndType(
                any(), any()
        )

        val result = compositeStore.loadLogs(reasonId)

        assertThat(result).isEqualTo(logMessage)
    }

    @Test
    fun `should return script body`() {
        val logMessage = "test log"
        val script = "hello world"
        val jira = "jiraId"
        val dbEntity = RequestEntity(
                id = 1,
                rqUid = reasonId,
                creatorLogin = FIRST_ADMIN,
                approverLogin = SECOND_ADMIN,
                statusId = RequestStatus.WORKS.id,
                rqData = script,
                rsData = logMessage,
                requestTypeId = RequestType.SCRIPT_REQUEST.id,
                rowInsTimestamp = LocalDateTime.now()
        )
        val zkEntity = ScriptRequest().apply {
            dbRef = DbRef(shardId)
            jiraId = jira
            uid = reasonId
            requestStatus = ApplicationStatus.WORKS.value
            createdBy = FIRST_ADMIN
            createdAt = LocalDateTime.now()
            resolvedBy = SECOND_ADMIN
            resolvedAt = LocalDateTime.now()
        }

        willReturn(dbEntity).given(dbRepository).findByKeyAndType(
                reasonId, RequestType.SCRIPT_REQUEST
        )
        willReturn(zkEntity).given(curatorCache).getByUid(
                reasonId, ScriptRequest::class.java
        )
        willReturn(zkEntity).given(zkRepository).findByKeyAndType(
                any(), any()
        )

        val result = compositeStore.loadScriptBody(reasonId)

        assertThat(result).isEqualTo(script)
    }

}
