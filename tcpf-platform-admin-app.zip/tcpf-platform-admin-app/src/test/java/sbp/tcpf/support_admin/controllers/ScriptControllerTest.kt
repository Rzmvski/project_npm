package sbp.tcpf.support_admin.controllers

import com.fasterxml.jackson.core.type.TypeReference
import com.fasterxml.jackson.databind.ObjectMapper
import com.github.tomakehurst.wiremock.WireMockServer
import com.github.tomakehurst.wiremock.client.WireMock
import com.github.tomakehurst.wiremock.client.WireMock.equalTo
import com.maciejwalkowiak.wiremock.spring.ConfigureWireMock
import com.maciejwalkowiak.wiremock.spring.EnableWireMock
import com.maciejwalkowiak.wiremock.spring.InjectWireMock
import com.sbt.audit.core.model.v2.event.Event
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.mockito.ArgumentCaptor
import org.mockito.BDDMockito.given
import org.mockito.BDDMockito.then
import org.mockito.Captor
import org.mockito.kotlin.any
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest
import org.springframework.context.annotation.Import
import org.springframework.http.MediaType
import org.springframework.security.test.context.support.WithUserDetails
import org.springframework.test.context.bean.override.mockito.MockitoBean
import org.springframework.test.context.bean.override.mockito.MockitoSpyBean
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*
import org.springframework.test.web.servlet.result.MockMvcResultHandlers.print
import org.springframework.test.web.servlet.result.MockMvcResultMatchers.status
import sbp.tcpf.script.engine.model.BeanInfo
import sbp.tcpf.script.engine.model.MetaInfo
import sbp.tcpf.script.engine.model.Method
import sbp.tcpf.support_admin.config.AuditTestConfig
import sbp.tcpf.support_admin.config.FeignClientsTestConfig
import sbp.tcpf.support_admin.config.NoOpEventListener
import sbp.tcpf.support_admin.config.SecurityTestConfig
import sbp.tcpf.support_admin.config.SecurityTestConfig.FIRST_ADMIN
import sbp.tcpf.support_admin.configs.properties.ScriptServiceProperties
import sbp.tcpf.support_admin.dto.ScriptApplicationDto
import sbp.tcpf.support_admin.mappers.ScriptApplicationMapperImpl
import sbp.tcpf.support_admin.mappers.ShellBeanMapperImpl
import sbp.tcpf.support_admin.mappers.TemplateMetadataMapperImpl
import sbp.tcpf.support_admin.model.*
import sbp.tcpf.support_admin.services.ScriptDetailsService
import sbp.tcpf.support_admin.services.ScriptTemplateService
import sbp.tcpf.support_admin.services.ShellBeansService
import sbp.tcpf.support_admin.services.request.dto.ScriptKey
import sbp.tcpf.support_admin.services.request.impl.ScriptRequestService
import sbp.tcpf.support_admin.services.request.resolvers.RequestResolver
import sbp.tcpf.support_admin.services.request.resolvers.ResolverRegistry
import sbp.tcpf.support_admin.services.request.store.CompositeScriptDataStore
import sbp.tcpf.support_admin.utils.AuditAssertions
import sbp.tcpf.support_admin.utils.AuditAssertions.thenEventSatisfies
import sbp.tcpf.support_admin.utils.paramAssert
import java.time.LocalDateTime
import java.util.*

@WithUserDetails(FIRST_ADMIN)
@EnableWireMock(
        ConfigureWireMock(name = "script_engine", property = "tcpf-platform-admin-app.script-service.uri")
)
@EnableConfigurationProperties(ScriptServiceProperties::class)
@AutoConfigureMockMvc(addFilters = false)
@WebMvcTest(ScriptController::class)
@Import(
        ScriptTemplateService::class,
        ScriptRequestService::class,
        TemplateMetadataMapperImpl::class,
        AuditTestConfig::class,
        FeignClientsTestConfig::class,
        SecurityTestConfig::class,
        ShellBeansService::class,
        ShellBeanMapperImpl::class,
        ScriptDetailsService::class,
        ScriptApplicationMapperImpl::class
)
class ScriptControllerTest {

    companion object {
        private const val BASE_URL = "/invoke/support-admin/script-service"
        private const val TEMPLATE_HASH = 100500
        private const val REASON_ID = "reasonId"
    }

    @InjectWireMock("script_engine")
    lateinit var wiremock: WireMockServer

    @MockitoBean
    lateinit var resolverRegistry: ResolverRegistry<ScriptApplicationDto>

    @MockitoBean
    lateinit var resolver: RequestResolver<ScriptApplicationDto>

    @MockitoBean
    lateinit var dataStore: CompositeScriptDataStore

    @MockitoSpyBean
    lateinit var listener: NoOpEventListener

    @Captor
    lateinit var eventArgumentCaptor: ArgumentCaptor<Event>

    @Autowired
    lateinit var mockMvc: MockMvc

    @Autowired
    lateinit var objectMapper: ObjectMapper

    @Test
    fun shouldReturnAvailableBeans() {
        wiremock.stubFor(
                WireMock.get("/api/v1/beans")
                    .willReturn(WireMock.okJson(objectMapper.writeValueAsString(getBeans())))
        )

        mockMvc.perform(get("$BASE_URL/beans"))
            .andExpect(status().isOk())
            .andDo(print())
    }

    @Test
    fun shouldReturnTemplates() {
        wiremock.stubFor(
                WireMock.get("/api/v1/templates/metas")
                    .willReturn(WireMock.okJson(objectMapper.writeValueAsString(getMetaInfos())))
        )

        val response = mockMvc.perform(get("$BASE_URL/templates/metadata"))
            .andExpect(status().isOk())
            .andDo(print())
            .andReturn().response

        val templateMetadatas: List<TemplateMetadata> = objectMapper.readValue(
                response.contentAsString,
                object : TypeReference<List<TemplateMetadata>>() {}
        )

        assertThat(templateMetadatas).isNotEmpty()
    }

    @Test
    fun shouldReturnTemplateByHash() {
        val script = "script"
        wiremock.stubFor(
                WireMock.get(WireMock.urlPathTemplate("/api/v1/templates/{hash}/script"))
                    .withPathParam("hash", equalTo(TEMPLATE_HASH.toString()))
                    .willReturn(WireMock.ok(script))
        )

        val response = mockMvc.perform(get("$BASE_URL/templates/{hash}", TEMPLATE_HASH))
            .andExpect(status().isOk())
            .andDo(print())
            .andReturn().response

        assertThat(response.contentAsString).isEqualTo(script)
    }

    @Test
    fun shouldReturnApplications() {
        given(dataStore.loadAll()).willReturn(getApplications())

        val response = mockMvc.perform(get("$BASE_URL/applications"))
            .andExpect(status().isOk())
            .andDo(print())
            .andReturn().response

        val applications = objectMapper.readValue(
                response.contentAsString,
                object : TypeReference<List<ScriptApplication>>() {}
        )

        assertThat(applications).isNotEmpty()
    }

    @Test
    fun `should return logs`() {
        val logs = "logs"
        given(dataStore.loadLogs(REASON_ID)).willReturn(logs)

        val response = mockMvc.perform(get("$BASE_URL/applications/{reasonId}/logs", REASON_ID))
            .andExpect(status().isOk())
            .andDo(print())
            .andReturn().response

        assertThat(response.contentAsString)
            .isNotEmpty()
            .isEqualTo(logs)
    }

    @Test
    fun `should return script body`() {
        val script = "script"
        given(dataStore.loadScriptBody(REASON_ID)).willReturn(script)

        val response = mockMvc.perform(get("$BASE_URL/applications/{reasonId}/script", REASON_ID))
            .andExpect(status().isOk())
            .andDo(print())
            .andReturn().response

        assertThat(response.contentAsString)
            .isNotEmpty()
            .isEqualTo(script)
    }

    @Test
    fun `should resolve application`() {
        val resolvedStatus = ApplicationStatus.APPROVED
        given(dataStore.findByKey(REASON_ID)).willReturn(getApplication())
        given(resolverRegistry.get(resolvedStatus)).willReturn(resolver)
        given(resolver.resolve(any())).willReturn(getApplication())

        val response = mockMvc.perform(
                put("$BASE_URL/applications/{reasonId}/status", REASON_ID)
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(
                            objectMapper.writeValueAsString(
                                    ResolveScriptApplicationRequest(resolvedStatus)
                            )
                    )
        )
            .andExpect(status().isOk())
            .andDo(print())
            .andReturn().response

        val resolvedApplication = objectMapper.readValue(response.contentAsString, ScriptApplication::class.java)

        assertThat(resolvedApplication).isNotNull()
            .satisfies({ application ->
                assertThat(application.status).isEqualTo(resolvedStatus)
                assertThat(application.createdBy).isEqualTo(FIRST_ADMIN)
                assertThat(application.reasonId).isEqualTo(REASON_ID)
            })
    }

    @Test
    fun `should save application`() {
        given(dataStore.save(any())).willReturn(getApplication())
        val createRequest = CreateScriptApplicationRequest(
                REASON_ID,
                "jiraId",
                "script",
                Restrictions(false, Collections.emptyList()),
                LocalDateTime.now(),
                FIRST_ADMIN
        )

        mockMvc.perform(
                post("$BASE_URL/applications")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(createRequest))
        )
            .andExpect(status().isOk())
            .andDo(print())
    }

    @Test
    fun `should return application metadata`() {
        val application = getApplication()
        given(dataStore.findByKey(REASON_ID)).willReturn(application)

        mockMvc.perform(get("$BASE_URL/applications/{reasonId}", REASON_ID))
            .andExpect(status().isOk())
            .andDo(print())

        then(listener).should().listen(eventArgumentCaptor.capture())
        val event = eventArgumentCaptor.value
        thenEventSatisfies(
                event,
                AuditAssertions.EventExpectations.of()
                    .eventName("SCRIPT_REQUEST_RESULT")
                    .paramAssert("createdByLogin") { value: String -> assertThat(value).isEqualTo(application.createdBy) }
                    .paramAssert("runByLogin") { value: String -> assertThat(value).isNotBlank() }
                    .paramAssert("status") { value -> assertThat(value).isEqualTo(application.status.toString()) }
                    .paramAssert("reasonId") { value -> assertThat(value).isEqualTo(application.location.scriptId) }
        )
    }

    private fun getBeans(): List<BeanInfo> {
        return listOf(
                BeanInfo.builder()
                    .name("beanName")
                    .className("className")
                    .packageName("package")
                    .methods(
                            listOf(
                                    Method.builder()
                                        .name("methodName")
                                        .returnType("returnType")
                                        .parameters(emptyList())
                                        .build()
                            )
                    )
                    .build()
        )
    }

    private fun getMetaInfos(): List<MetaInfo> {
        return listOf(
                MetaInfo.builder()
                    .title("title")
                    .path("group1/subgroup")
                    .author(FIRST_ADMIN)
                    .description("description")
                    .hashcode(TEMPLATE_HASH)
                    .build()
        )
    }

    private fun getApplications(): List<ScriptApplicationDto> {
        return listOf(getApplication())
    }

    private fun getApplication(): ScriptApplicationDto {
        return ScriptApplicationDto(
                status = ApplicationStatus.APPROVED,
                location = ScriptKey(REASON_ID),
                jiraId = "jiraId",
                createdBy = FIRST_ADMIN,
                created = LocalDateTime.now(),
        )
    }
}
