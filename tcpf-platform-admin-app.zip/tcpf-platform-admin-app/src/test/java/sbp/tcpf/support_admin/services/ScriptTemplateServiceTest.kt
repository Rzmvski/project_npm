package sbp.tcpf.support_admin.services

import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.mockito.kotlin.given
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.bean.override.mockito.MockitoBean
import sbp.tcpf.script.engine.model.MetaInfo
import sbp.tcpf.support_admin.clients.feign.script_engine.ScriptTemplateApi
import sbp.tcpf.support_admin.mappers.TemplateMetadataMapperImpl

@SpringBootTest(
        classes = [
            ScriptTemplateService::class,
            TemplateMetadataMapperImpl::class,
        ]
)
class ScriptTemplateServiceTest {

    @MockitoBean
    lateinit var scriptTemplateApi: ScriptTemplateApi

    @Autowired
    lateinit var scriptTemplateService: ScriptTemplateService

    @Test
    fun `should return metadatas`() {
        given { scriptTemplateApi.loadTemplateMetas() }
            .willReturn(listOf(
                    MetaInfo(1, "path", "title", "groovy", null, null, null)
            ))

        val metadatas = scriptTemplateService.loadMetadatas()

        assertThat(metadatas).isNotEmpty
    }

    @Test
    fun `should return template by hash`() {
        val hash = 1
        val template = "script"
        given { scriptTemplateApi.loadScriptTemplate(hash) }
            .willReturn(template)

        val result = scriptTemplateService.loadTemplateById(hash)

        assertThat(result).isEqualTo(template)
    }
}
