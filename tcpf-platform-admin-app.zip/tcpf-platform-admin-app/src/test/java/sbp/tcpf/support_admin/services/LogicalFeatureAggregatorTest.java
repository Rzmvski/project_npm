package sbp.tcpf.support_admin.services;

import sbp.tcpf.routing.api.v1_0.client.model.Node;
import sbp.tcpf.support_admin.dto.FeatureConfigurationDto;
import sbp.tcpf.support_admin.dto.FeatureLocation;
import sbp.tcpf.support_admin.dto.FeatureSnapshot;
import sbp.tcpf.support_admin.dto.FeatureTargetDto;
import sbp.tcpf.support_admin.mappers.CustomPropertyMapperImpl;
import sbp.tcpf.support_admin.mappers.FeatureActivationMapper;
import sbp.tcpf.support_admin.mappers.FeatureConfigurationMapperImpl;
import sbp.tcpf.support_admin.model.ManualFeatureActivation;

import org.ff4j.property.PropertyString;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.BDDMockito.given;
import static sbp.tcpf.support_admin.utils.ReactiveMocks.reactiveMock;

import reactor.core.publisher.Flux;

@SpringBootTest(classes = {
        LogicalFeatureAggregator.class,
        FeatureConfigurationMapperImpl.class,
        FeatureActivationMapper.class,
        CustomPropertyMapperImpl.class,
        LogicalFeatureAggregatorTest.TestConfig.class,
})
public class LogicalFeatureAggregatorTest {

    @Autowired
    ShardService shardService;

    @Autowired
    LogicalFeatureAggregator featureAggregator;

    /**
     * ShardService нельзя объявить через {@code @MockitoBean}: {@code LogicalFeatureAggregator.init()}
     * помечен {@code @PostConstruct} и выполняется при поднятии контекста, то есть раньше,
     * чем {@code @BeforeEach} успевает выставить стаб. Мок с default answer отдаёт пустой Flux
     * и на старте, и после сброса стабов между тестами.
     */
    @TestConfiguration
    static class TestConfig {

        @Bean
        ShardService shardService() {
            return reactiveMock(ShardService.class);
        }
    }

    @BeforeEach
    void setUp() {
        given(shardService.getNodes()).willReturn(Flux.just(
                Node.builder()
                    .shardId(1005)
                    .key("P5")
                    .build(),
                Node.builder()
                    .shardId(1006)
                    .key("P6")
                    .build(),
                Node.builder()
                    .shardId(1006)
                    .key("S6")
                    .build(),
                Node.builder()
                    .shardId(1005)
                    .key("S5")
                    .build()
        ));

        featureAggregator.init();
    }

    @Test
    void shouldAggregateShardFeature() {
        var featureName = "featureName";
        var module = "module";
        var leftConfiguration = new FeatureConfigurationDto(
                false,
                "description",
                null,
                Map.of(
                        "type", new PropertyString("type", "value")
                )
        );

        var rightConfiguration = new FeatureConfigurationDto(
                false,
                "description",
                null,
                Map.of(
                        "type", new PropertyString("type", "value")
                )
        );

        var snapshots = List.of(
                new FeatureSnapshot(
                        featureName,
                        new FeatureLocation(module, "P5"),
                        leftConfiguration,
                        LocalDateTime.now(),
                        null,
                        false
                ),
                new FeatureSnapshot(
                        featureName,
                        new FeatureLocation(module, "S5"),
                        rightConfiguration,
                        LocalDateTime.now(),
                        null,
                        false
                )
        );

        var result = featureAggregator.aggregate(snapshots);

        assertThat(result)
                .isNotEmpty()
                .hasSize(1)
                .satisfiesOnlyOnce(logicalFeatureDto -> {
                    assertThat(logicalFeatureDto.key().name()).isEqualTo(featureName);
                    assertThat(logicalFeatureDto.key().target()).satisfies(targetDto -> {
                        assertThat(targetDto.type()).isEqualTo(FeatureTargetDto.Type.SHARD);
                        assertThat(targetDto.module()).isEqualTo(module);
                        assertThat(targetDto.nodeKeys()).containsExactlyInAnyOrder("P5", "S5");
                        assertThat(targetDto.locations()).hasSize(snapshots.size());
                    });
                });
    }

    @Test
    void shouldAggregateNodeFeature() {
        var featureName = "featureName";
        var module = "module";
        var configuration = new FeatureConfigurationDto(
                false,
                "description",
                null,
                Collections.emptyMap()
        );

        var snapshots = List.of(
                new FeatureSnapshot(
                        featureName,
                        new FeatureLocation(module, "P5"),
                        configuration,
                        LocalDateTime.now(),
                        null,
                        false
                ),
                new FeatureSnapshot(
                        featureName,
                        new FeatureLocation(module, "P6"),
                        configuration,
                        LocalDateTime.now(),
                        null,
                        false
                )
        );

        var result = featureAggregator.aggregate(snapshots);

        assertThat(result)
                .isNotEmpty()
                .hasSize(snapshots.size())
                .allSatisfy(logicalFeatureDto -> {
                    assertThat(logicalFeatureDto.key().name()).isEqualTo(featureName);
                    assertThat(logicalFeatureDto.configuration()).satisfies(config -> {
                        assertThat(config.getActivation()).isInstanceOfSatisfying(ManualFeatureActivation.class, (activation) ->
                                assertThat(activation.getEnabled()).isEqualTo(configuration.enable()));
                        assertThat(config.getDescription()).isEqualTo(configuration.description());
                        assertThat(config.getCustomProperties().size()).isEqualTo(configuration.customProperties().size());
                    });
                    assertThat(logicalFeatureDto.key().target()).satisfies(targetDto -> {
                        assertThat(targetDto.type()).isEqualTo(FeatureTargetDto.Type.NODE);
                        assertThat(targetDto.module()).isEqualTo(module);
                        assertThat(targetDto.nodeKeys())
                                .hasSize(1)
                                .containsAnyOf("P5", "P6");
                        assertThat(targetDto.locations()).hasSize(1);
                    });
                });
    }

    @Test
    void shouldAggregateDirectFeature() {
        var featureName = "featureName";
        var configuration = new FeatureConfigurationDto(
                false,
                "description",
                null,
                Collections.emptyMap()
        );

        var snapshots = List.of(
                new FeatureSnapshot(
                        featureName,
                        new FeatureLocation(null, null),
                        configuration,
                        LocalDateTime.now(),
                        null,
                        false
                ),
                new FeatureSnapshot(
                        featureName,
                        new FeatureLocation("module", null),
                        configuration,
                        LocalDateTime.now(),
                        null,
                        false
                )
        );

        var result = featureAggregator.aggregate(snapshots);

        assertThat(result)
                .isNotEmpty()
                .hasSize(snapshots.size())
                .allSatisfy(logicalFeatureDto -> {
                    assertThat(logicalFeatureDto.key().name()).isEqualTo(featureName);
                    assertThat(logicalFeatureDto.configuration())
                            .satisfies(config -> {
                                assertThat(config.getActivation()).isInstanceOfSatisfying(ManualFeatureActivation.class, (activation) ->
                                        assertThat(activation.getEnabled()).isEqualTo(configuration.enable()));
                                assertThat(config.getDescription()).isEqualTo(configuration.description());
                                assertThat(config.getCustomProperties().size()).isEqualTo(configuration.customProperties().size());
                            });
                    assertThat(logicalFeatureDto.key().target()).satisfies(targetDto -> {
                        assertThat(targetDto.type()).isEqualTo(FeatureTargetDto.Type.DIRECT);
                        assertThat(targetDto.nodeKeys()).isNull();
                        assertThat(targetDto.locations()).hasSize(1);
                    });
                });
    }

    @Test
    void shouldThrowIfConfigsDifferentInOneLogicFeatureGroup() {
        var featureName = "featureName";
        var location = new FeatureLocation(null, null);

        var snapshots = List.of(
                new FeatureSnapshot(
                        featureName,
                        location,
                        new FeatureConfigurationDto(
                                false,
                                "description",
                                null,
                                Map.of(
                                        "type", new PropertyString("type", "another value")
                                )
                        ),
                        LocalDateTime.now(),
                        null,
                        false
                ),
                new FeatureSnapshot(
                        featureName,
                        location,
                        new FeatureConfigurationDto(
                                true,
                                "another description",
                                null,
                                Map.of(
                                        "type", new PropertyString("type", "value")
                                )
                        ),
                        LocalDateTime.now(),
                        null,
                        false
                )
        );

        assertThatThrownBy(() -> featureAggregator.aggregate(snapshots))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageMatching("Physical feature .* have different configurations");
    }
}
