package sbp.tcpf.support_admin.services.request;

import sbp.tcpf.support_admin.config.SecurityTestConfig;
import sbp.tcpf.support_admin.configs.properties.ResolveRequestServiceProperties;
import sbp.tcpf.support_admin.dto.FeatureDelta;
import sbp.tcpf.support_admin.dto.FeatureIdentity;
import sbp.tcpf.support_admin.dto.FeatureTargetDto;
import sbp.tcpf.support_admin.dto.LogicalFeatureDto;
import sbp.tcpf.support_admin.mappers.CustomPropertyMapperImpl;
import sbp.tcpf.support_admin.mappers.FeatureActivationMapper;
import sbp.tcpf.support_admin.mappers.FeatureConfigurationMapperImpl;
import sbp.tcpf.support_admin.model.FeatureConfiguration;
import sbp.tcpf.support_admin.model.ManualFeatureActivation;
import sbp.tcpf.support_admin.model.OdReleaseFeatureActivation;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static sbp.tcpf.ff4j.utils.Constants.APPS_FEATURE;
import static sbp.tcpf.ff4j.utils.Constants.GLOBAL_FEATURE;

@EnableConfigurationProperties(ResolveRequestServiceProperties.class)
@SpringBootTest(classes = {
        FeatureRequestFactory.class,
        FeatureConfigurationMapperImpl.class,
        FeatureActivationMapper.class,
        CustomPropertyMapperImpl.class,
})
@Import(SecurityTestConfig.class)
class FeatureRequestFactoryTest {

    @Autowired
    FeatureRequestFactory featureRequestFactory;

    @Test
    void shouldCreateDeleteRequest() {
        String requestId = "requestId";
        String node = "node";
        String featureName = "featureName";
        var releaseDate = LocalDate.now();
        var configuration = new FeatureConfiguration(
                OdReleaseFeatureActivation.builder().releaseDate(releaseDate).build(), "description", Collections.emptyList()
        );
        var feature = new LogicalFeatureDto(
                new FeatureIdentity(
                        featureName,
                        new FeatureTargetDto(
                                FeatureTargetDto.Type.NODE,
                                null,
                                List.of(node)
                        )
                ),
                null,
                LocalDateTime.now(),
                null,
                false
        );
        var existing = new LogicalFeatureDto(
                new FeatureIdentity(
                        featureName,
                        new FeatureTargetDto(
                                FeatureTargetDto.Type.NODE,
                                null,
                                List.of(node)
                        )
                ),
                configuration,
                LocalDateTime.now(),
                null,
                false
        );

        var result = featureRequestFactory.create(requestId, feature, existing);

        assertThat(result)
                .isPresent()
                .hasValueSatisfying(request -> {
                    assertThat(request.getRqUid()).isNotNull();
                    assertThat(request.getPath())
                            .isNotNull()
                            .contains(GLOBAL_FEATURE);
                    assertThat(request.getFeatureName()).isEqualTo(featureName);
                    assertThat(request.getTarget())
                            .satisfies(target ->
                                               assertThat(target.locations())
                                                       .hasSize(1)
                                                       .allSatisfy(location -> {
                                                           assertThat(location.hasModule()).isFalse();
                                                           assertThat(location.hasNode()).isTrue();
                                                           assertThat(location.node()).isEqualTo(node);
                                                       })
                            );
                    assertThat(request.getDelta())
                            .satisfies(delta -> {
                                assertThat(delta.type()).isEqualTo(FeatureDelta.ChangeType.DELETE);
                                assertThat(delta.before())
                                        .isNotNull()
                                        .satisfies(config -> {
                                            assertThat(config.getDescription()).isEqualTo(configuration.getDescription());
                                            assertThat(config.getActivation())
                                                    .isInstanceOfSatisfying(OdReleaseFeatureActivation.class, (manualActivation) ->
                                                            assertThat(manualActivation.getReleaseDate()).isEqualTo(releaseDate));
                                            assertThat(config.getCustomProperties()).hasSize(configuration.getCustomProperties().size());
                                        });
                                assertThat(delta.after()).isNull();
                            });
                });
    }

    @Test
    void shouldCreateUpdateRequest() {
        String requestId = "requestId";
        String node = "node";
        String featureName = "featureName";
        var afterConfiguration = new FeatureConfiguration(
                ManualFeatureActivation.builder().enabled(true).build(), "description", Collections.emptyList()
        );
        var beforeConfiguration = new FeatureConfiguration(
                ManualFeatureActivation.builder().enabled(false).build(), "updated description", Collections.emptyList()
        );
        var feature = new LogicalFeatureDto(
                new FeatureIdentity(
                        featureName,
                        new FeatureTargetDto(
                                FeatureTargetDto.Type.NODE,
                                null,
                                List.of(node)
                        )
                ),
                afterConfiguration,
                LocalDateTime.now(),
                null,
                false
        );
        var existing =
                new LogicalFeatureDto(
                        new FeatureIdentity(
                                featureName,
                                new FeatureTargetDto(FeatureTargetDto.Type.NODE,
                                                     null,
                                                     List.of(node))
                        ),
                        beforeConfiguration,
                        LocalDateTime.now(),
                        null,
                        false
                );

        var result = featureRequestFactory.create(requestId, feature, existing);

        assertThat(result)
                .isPresent()
                .hasValueSatisfying(request -> {
                    assertThat(request.getRqUid()).isNotNull();
                    assertThat(request.getPath())
                            .isNotNull()
                            .contains(GLOBAL_FEATURE);
                    assertThat(request.getFeatureName()).isEqualTo(featureName);
                    assertThat(request.getTarget())
                            .satisfies(target ->
                                               assertThat(target.locations())
                                                       .hasSize(1)
                                                       .allSatisfy(location -> {
                                                           assertThat(location.hasModule()).isFalse();
                                                           assertThat(location.hasNode()).isTrue();
                                                           assertThat(location.node()).isEqualTo(node);
                                                       })
                            );
                    assertThat(request.getDelta())
                            .satisfies(delta -> {
                                assertThat(delta.type()).isEqualTo(FeatureDelta.ChangeType.UPDATE);
                                assertThat(delta.before())
                                        .isNotNull()
                                        .satisfies(config -> {
                                            assertThat(config.getDescription()).isEqualTo(beforeConfiguration.getDescription());
                                            assertThat(config.getActivation())
                                                    .isInstanceOfSatisfying(ManualFeatureActivation.class, (manualActivation) ->
                                                            assertThat(manualActivation).isEqualTo(beforeConfiguration.getActivation()));
                                            assertThat(config.getCustomProperties()).hasSize(beforeConfiguration.getCustomProperties().size());
                                        });
                                assertThat(delta.after())
                                        .isNotNull()
                                        .satisfies(config -> {
                                            assertThat(config.getDescription()).isEqualTo(afterConfiguration.getDescription());
                                            assertThat(config.getActivation())
                                                    .isInstanceOfSatisfying(ManualFeatureActivation.class, (manualActivation) ->
                                                            assertThat(manualActivation).isEqualTo(afterConfiguration.getActivation()));
                                            assertThat(config.getCustomProperties()).hasSize(afterConfiguration.getCustomProperties().size());
                                        });
                            });
                });
    }

    @Test
    void shouldCreateRequestForNodeFeature() {
        String requestId = "requestId";
        String module = "module";
        String featureName = "featureName";
        String node = "P5";
        var configuration = new FeatureConfiguration(
                ManualFeatureActivation.builder().enabled(true).build(), "description", Collections.emptyList()
        );
        var feature = new LogicalFeatureDto(
                new FeatureIdentity(
                        featureName,
                        new FeatureTargetDto(
                                FeatureTargetDto.Type.NODE,
                                module,
                                List.of(node)
                        )
                ),
                configuration,
                LocalDateTime.now(),
                null,
                false
        );

        var result = featureRequestFactory.create(requestId, feature, null);

        assertThat(result)
                .isPresent()
                .hasValueSatisfying(request -> {
                    assertThat(request.getRqUid()).isNotNull();
                    assertThat(request.getPath())
                            .isNotNull()
                            .contains(APPS_FEATURE, module);
                    assertThat(request.getFeatureName()).isEqualTo(featureName);
                    assertThat(request.getTarget())
                            .satisfies(target ->
                                               assertThat(target.locations())
                                                       .hasSize(1)
                                                       .allSatisfy(location -> {
                                                           assertThat(location.hasModule()).isTrue();
                                                           assertThat(location.module()).isEqualTo(module);
                                                           assertThat(location.hasNode()).isTrue();
                                                           assertThat(location.node()).contains(node);
                                                       })
                            );
                    assertThat(request.getDelta())
                            .satisfies(delta -> {
                                assertThat(delta.type()).isEqualTo(FeatureDelta.ChangeType.CREATE);
                                assertThat(delta.before()).isNull();
                                assertThat(delta.after())
                                        .isNotNull()
                                        .satisfies(config -> {
                                            assertThat(config.getDescription()).isEqualTo(configuration.getDescription());
                                            assertThat(config.getActivation())
                                                    .isInstanceOfSatisfying(ManualFeatureActivation.class, (manualActivation) ->
                                                            assertThat(manualActivation).isEqualTo(configuration.getActivation()));
                                            assertThat(config.getCustomProperties()).hasSize(configuration.getCustomProperties().size());
                                        });
                            });
                });
    }

    @Test
    void shouldCreateRequestForShardFeature() {
        String requestId = "requestId";
        String module = "module";
        String featureName = "featureName";
        List<String> nodes = List.of("P5", "S5");
        var configuration = new FeatureConfiguration(
                ManualFeatureActivation.builder().enabled(true).build(), "description", Collections.emptyList()
        );
        var feature = new LogicalFeatureDto(
                new FeatureIdentity(
                        featureName,
                        new FeatureTargetDto(
                                FeatureTargetDto.Type.SHARD,
                                module,
                                nodes
                        )
                ),
                configuration,
                LocalDateTime.now(),
                null,
                false
        );

        var result = featureRequestFactory.create(requestId, feature, null);

        assertThat(result)
                .isPresent()
                .hasValueSatisfying(request -> {
                    assertThat(request.getRqUid()).isNotNull();
                    assertThat(request.getPath())
                            .isNotNull()
                            .contains(APPS_FEATURE, module);
                    assertThat(request.getFeatureName()).isEqualTo(featureName);
                    assertThat(request.getTarget())
                            .satisfies(target ->
                                               assertThat(target.locations())
                                                       .hasSize(nodes.size())
                                                       .allSatisfy(location -> {
                                                           assertThat(location.hasModule()).isTrue();
                                                           assertThat(location.module()).isEqualTo(module);
                                                           assertThat(location.hasNode()).isTrue();
                                                           assertThat(nodes).contains(location.node());
                                                       })
                            );
                    assertThat(request.getDelta())
                            .satisfies(delta -> {
                                assertThat(delta.type()).isEqualTo(FeatureDelta.ChangeType.CREATE);
                                assertThat(delta.before()).isNull();
                                assertThat(delta.after())
                                        .isNotNull()
                                        .satisfies(config -> {
                                            assertThat(config.getDescription()).isEqualTo(configuration.getDescription());
                                            assertThat(config.getActivation())
                                                    .isInstanceOfSatisfying(ManualFeatureActivation.class, (manualActivation) ->
                                                            assertThat(manualActivation).isEqualTo(configuration.getActivation()));
                                            assertThat(config.getCustomProperties()).hasSize(configuration.getCustomProperties().size());
                                        });
                            });
                });
    }
}
