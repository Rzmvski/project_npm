package sbp.tcpf.support_admin.controllers;

import sbp.tcpf.replica.monitor.api.mass.model.Revision;
import sbp.tcpf.replica.monitor.api.mass.model.RevisionRow;
import sbp.tcpf.replica.monitor.api.mass.model.RevisionTable;
import sbp.tcpf.replica.monitor.api.mass.model.Shard;
import sbp.tcpf.replica.monitor.api.mass.model.Status;
import sbp.tcpf.support_admin.clients.feign.replica_monitor.ReplicaMonitorApiClient;
import sbp.tcpf.support_admin.config.AuditTestConfig;
import sbp.tcpf.support_admin.config.FeignClientsTestConfig;
import sbp.tcpf.support_admin.config.NoOpEventListener;
import sbp.tcpf.support_admin.config.SecurityTestConfig;
import sbp.tcpf.support_admin.configs.properties.ReplicaMonitorAppProperties;
import sbp.tcpf.support_admin.enums.OuterErrorCodes;
import sbp.tcpf.support_admin.exceptions.ExternalServiceException;
import sbp.tcpf.support_admin.mappers.RevisionDetailsMapperImpl;
import sbp.tcpf.support_admin.mappers.RevisionMapperImpl;
import sbp.tcpf.support_admin.mappers.RevisionReportMapperImpl;
import sbp.tcpf.support_admin.mappers.RevisionStatusMapperImpl;
import sbp.tcpf.support_admin.model.RevisionDetails;
import sbp.tcpf.support_admin.model.RevisionInfo;
import sbp.tcpf.support_admin.model.RevisionJob;
import sbp.tcpf.support_admin.model.RevisionJobStatus;
import sbp.tcpf.support_admin.model.RevisionReport;
import sbp.tcpf.support_admin.model.RevisionStatus;
import sbp.tcpf.support_admin.services.ReviseReplicationService;
import sbp.tcpf.support_admin.utils.AuditAssertions;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.maciejwalkowiak.wiremock.spring.ConfigureWireMock;
import com.maciejwalkowiak.wiremock.spring.EnableWireMock;
import com.maciejwalkowiak.wiremock.spring.InjectWireMock;
import com.sbt.audit.core.model.v2.event.Event;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.test.context.support.WithUserDetails;
import org.springframework.test.context.bean.override.mockito.MockitoSpyBean;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.okJson;
import static com.github.tomakehurst.wiremock.client.WireMock.serverError;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathTemplate;
import static org.apache.commons.lang3.tuple.Pair.of;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.then;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.never;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static sbp.tcpf.support_admin.config.SecurityTestConfig.FIRST_ADMIN;
import static sbp.tcpf.support_admin.utils.AuditAssertions.thenEventSatisfies;

@WithUserDetails(FIRST_ADMIN)
@EnableWireMock({
        @ConfigureWireMock(name = "replica", property = "tcpf-platform-admin-app.tcpf-replica-monitor-app.uri")
})
@EnableConfigurationProperties(ReplicaMonitorAppProperties.class)
@AutoConfigureMockMvc(addFilters = false)
@WebMvcTest(ReviseReplicationController.class)
@Import({
        ReviseReplicationService.class,
        RevisionMapperImpl.class,
        RevisionDetailsMapperImpl.class,
        RevisionReportMapperImpl.class,
        RevisionStatusMapperImpl.class,
        AuditTestConfig.class,
        FeignClientsTestConfig.class,
        SecurityTestConfig.class,
})
class ReviseReplicationControllerTest {

    private static final String URL = "/invoke/support-admin/revise-replication-service/";
    private static final String REVISION_SHARD_ID = "petryaninShard";
    private static final String ANOTHER_SHARD_ID = "petryaninShard2";
    private static final Integer REVISION_PART = 1;
    private static final Long REVISION_ID = 1L;
    private static final Integer PAGE_SIZE = 20;
    private static final Integer PAGE_NUMBER = 1;
    private static final Integer DEFAULT_REPORT_PAGE_SIZE = 5_000;
    private static final OffsetDateTime STARTED_TIME = OffsetDateTime.now().minusMinutes(30);
    private static final OffsetDateTime COMPLETED_TIME = OffsetDateTime.now();

    @InjectWireMock("replica")
    WireMockServer wiremock;
    @MockitoSpyBean
    ReplicaMonitorApiClient replicaMonitorClient;
    @MockitoSpyBean
    NoOpEventListener listener;
    @Captor
    ArgumentCaptor<Revision> revisionArgumentCaptor;
    @Captor
    ArgumentCaptor<Event> eventArgumentCaptor;
    @Autowired
    MockMvc mockMvc;
    @Autowired
    ObjectMapper objectMapper;

    @Test
    void shouldReturnRevisionShardIds() throws Exception {
        wiremock.stubFor(WireMock.get("/mass/v1/shards")
                                 .willReturn(WireMock.okJson(objectMapper.writeValueAsString(getRevisionShards()))));

        MockHttpServletResponse response = mockMvc.perform(get(URL + "/shards"))
                                                  .andDo(print())
                                                  .andExpect(status().isOk())
                                                  .andReturn().getResponse();

        List<String> shardIds = objectMapper.readValue(response.getContentAsString(), new TypeReference<>() {
        });

        assertThat(shardIds).isNotEmpty();
    }

    @Test
    void shouldReturnLastRevisions() throws Exception {
        wiremock.stubFor(WireMock.get(urlPathTemplate("/mass/v1/revisions"))
                                 .willReturn(WireMock.okJson(objectMapper.writeValueAsString(getRevises()))));

        MockHttpServletResponse response = mockMvc.perform(get(URL + "/shards/revisions"))
                                                  .andDo(print())
                                                  .andExpect(status().isOk())
                                                  .andReturn().getResponse();

        List<RevisionInfo> result = objectMapper.readValue(response.getContentAsString(), new TypeReference<>() {
        });

        assertThat(result).isNotEmpty();
    }

    @Test
    void shouldReturnRevisionById() throws Exception {
        wiremock.stubFor(WireMock.get(urlPathTemplate("/mass/v1/shards/{shardId}/revisions/{revisionId}"))
                                 .willReturn(WireMock.okJson(objectMapper.writeValueAsString(getRevision()))));

        var uuid = UUID.randomUUID();

        MockHttpServletResponse response = mockMvc.perform(get(URL + "/shards/{shardId}/revisions/{revisionId}", REVISION_SHARD_ID, REVISION_ID)
                                                                   .header("uuid", uuid))
                                                  .andDo(print())
                                                  .andExpect(status().isOk())
                                                  .andReturn().getResponse();

        RevisionInfo result = objectMapper.readValue(response.getContentAsString(), RevisionInfo.class);

        assertThat(result).isNotNull().satisfies(revision -> {
            assertThat(revision.getId()).isEqualTo(REVISION_ID);
            assertThat(revision.getShardId()).isEqualTo(REVISION_SHARD_ID);
        });
    }

    private List<Shard> getRevisionShards() {
        Shard shard1 = new Shard();
        shard1.setId("1005");
        Shard shard2 = new Shard();
        shard2.setId("1006");
        return List.of(shard1, shard2);
    }

    @Test
    void shouldReviseWithExceptions() throws Exception {
        wiremock.stubFor(WireMock.post(urlPathTemplate("/mass/v1/shards/{shardId}/revisions"))
                                 .withPathParam("shardId", equalTo(REVISION_SHARD_ID))
                                 .willReturn(serverError()));

        var uuid = UUID.randomUUID();
        var shardList = List.of(REVISION_SHARD_ID);

        mockMvc.perform(post(URL + "/shards/{shardIds}/revisions", String.join(",", shardList))
                                .header("uuid", uuid)
                                .queryParam("part", REVISION_PART.toString()))
               .andDo(print())
               .andExpect(status().isInternalServerError())
               .andExpect(result -> assertThat(result.getResolvedException())
                       .isInstanceOf(ExternalServiceException.class))
        ;

        then(listener).should().listen(eventArgumentCaptor.capture());
        Event event = eventArgumentCaptor.getValue();
        thenEventSatisfies(event, AuditAssertions.EventExpectations.of()
                                                                   .eventName("RUN_REVISION_ERROR")
                                                                   .paramsAsserts(List.of(
                                                                           of("userLogin", value -> assertThat(value).isEqualTo(FIRST_ADMIN)),
                                                                           of("date", value -> assertThat(value).isEqualTo(LocalDate.now().toString())),
                                                                           of("errorCode", value -> assertThat(value).isEqualTo(String.valueOf(
                                                                                   OuterErrorCodes.TECHNICAL_ERROR.getCode()
                                                                           )))
                                                                   )));
    }

    @Test
    void shouldRevise() throws Exception {
        var uuid = UUID.randomUUID();
        var shardList = List.of(REVISION_SHARD_ID, ANOTHER_SHARD_ID);

        wiremock.stubFor(WireMock.post(urlPathTemplate("/mass/v1/shards/{shardId}/revisions"))
                                 .willReturn(okJson(objectMapper.writeValueAsString(getRevise()))));

        MockHttpServletResponse response = mockMvc.perform(post(URL + "/shards/{shardIds}/revisions", String.join(",", shardList))
                                                                   .header("uuid", uuid)
                                                                   .queryParam("part", REVISION_PART.toString()))
                                                  .andDo(print())
                                                  .andExpect(status().isOk())
                                                  .andReturn().getResponse();

        List<RevisionInfo> result = objectMapper.readValue(response.getContentAsString(), new TypeReference<>() {
        });

        then(listener).should().listen(eventArgumentCaptor.capture());
        Event event = eventArgumentCaptor.getValue();
        thenEventSatisfies(event, AuditAssertions.EventExpectations.of()
                                                                   .eventName("RUN_REVISION")
                                                                   .paramsAsserts(List.of(
                                                                           of("userLogin", value -> assertThat(value).isEqualTo(FIRST_ADMIN)),
                                                                           of("date", value -> assertThat(value).isEqualTo(LocalDate.now().toString()))
                                                                   )));

        assertThat(result).isNotEmpty().allSatisfy(revision -> {
                                                       assertThat(revision.getId()).isEqualTo(REVISION_ID);
                                                       assertThat(revision.getStatus()).isEqualTo(RevisionStatus.NOT_MATCHED.getValue());
                                                       assertThat(revision.getShardId()).isEqualTo(REVISION_SHARD_ID);
                                                   }
        );
    }

    @ParameterizedTest
    @ValueSource(strings = {"ABORTED", "WORKING", "RECHECKING"})
    void shouldChangeRevisionStatus(String targetStatus) throws Exception {
        wiremock.stubFor(WireMock.post(urlPathTemplate("/mass/v1/shards/{shardId}/revisions/{revisionId}"))
                                 .withPathParam("shardId", equalTo(REVISION_SHARD_ID))
                                 .withPathParam("revisionId", equalTo(String.valueOf(REVISION_ID)))
                                 .willReturn(okJson(objectMapper.writeValueAsString(getRevise()))));

        var uuid = UUID.randomUUID();

        mockMvc.perform(patch(URL + "/shards/{shardId}/revisions/{revisionId}", REVISION_SHARD_ID, REVISION_ID)
                                .header("uuid", uuid)
                                .queryParam("status", targetStatus)
               )
               .andDo(print())
               .andExpect(status().isOk());

        then(replicaMonitorClient).should(atLeastOnce()).postRevision(
                eq(uuid.toString()), eq(REVISION_SHARD_ID), eq(REVISION_ID), revisionArgumentCaptor.capture(), any()
        );

        assertThat(revisionArgumentCaptor.getValue().getStatus()).isEqualTo(targetStatus);
    }

    @ParameterizedTest
    @EnumSource(RevisionJob.class)
    void shouldStartRevisionJob(RevisionJob job) throws Exception {
        var targetTable = "table_001";
        wiremock.stubFor(WireMock.post(urlPathTemplate("/mass/v1/shards/{shardId}/revisions/{revisionId}"))
                                 .withPathParam("shardId", equalTo(REVISION_SHARD_ID))
                                 .withPathParam("revisionId", equalTo(String.valueOf(REVISION_ID)))
                                 .willReturn(okJson(objectMapper.writeValueAsString(getRevise()))));

        var uuid = UUID.randomUUID();

        mockMvc.perform(patch(URL + "/shards/{shardId}/revisions/{revisionId}", REVISION_SHARD_ID, REVISION_ID)
                                .header("uuid", uuid)
                                .queryParam("job", job.getValue())
                                .queryParam("table", targetTable)
               )
               .andDo(print())
               .andExpect(status().isOk());

        then(replicaMonitorClient).should(atLeastOnce()).postRevision(
                eq(uuid.toString()), eq(REVISION_SHARD_ID), eq(REVISION_ID), revisionArgumentCaptor.capture(), any()
        );

        assertThat(revisionArgumentCaptor.getValue()).satisfies((revision) -> {
            assertThat(revision.getJob()).isEqualTo(job.getValue());
            assertThat(revision.getTables()).contains(targetTable);
        });
    }

    private Revision getRevise() {
        Revision revision = new Revision();
        revision.setId(REVISION_ID);
        revision.setCreatedTime(OffsetDateTime.now());
        revision.setStatus(Status.NOT_MATCHED.getValue());
        revision.setRowsTotal(100L);
        revision.setRowsDiff(2L);
        revision.setShardId(REVISION_SHARD_ID);
        return revision;
    }

    @Test
    void shouldReturnDetails() throws Exception {
        wiremock.stubFor(WireMock.get(urlPathTemplate("/mass/v1/shards/{shardId}/revisions/{revisionId}/tables"))
                                 .withPathParam("shardId", equalTo(REVISION_SHARD_ID))
                                 .withPathParam("revisionId", equalTo(String.valueOf(REVISION_ID)))
                                 .willReturn(okJson(objectMapper.writeValueAsString(getRevisionTables()))));

        MockHttpServletResponse response = mockMvc.perform(get(URL + "/shards/{shardId}/revisions/{revisionId}/details", REVISION_SHARD_ID, REVISION_ID)
                                                                   .queryParam("pageNumber", PAGE_NUMBER.toString())
                                                                   .queryParam("pageSize", PAGE_SIZE.toString()))
                                                  .andDo(print())
                                                  .andExpect(status().isOk())
                                                  .andReturn().getResponse();

        List<RevisionDetails> result = objectMapper.readValue(response.getContentAsString(), new TypeReference<>() {
        });

        assertThat(result).isNotEmpty().allSatisfy(revisionDetails -> {
            assertThat(revisionDetails.getId()).isNotNull();
            assertThat(revisionDetails.getTable()).isNotNull();
            assertThat(revisionDetails.getRowsTotal()).isNotNull();
            assertThat(revisionDetails.getRowsDiff()).isNotNull();
        });
    }

    private List<RevisionTable> getRevisionTables() {
        RevisionTable table = new RevisionTable();
        table.revisionId(1L);
        table.setTableName("table");
        table.setStatus(Status.NOT_MATCHED.getValue());
        table.setRowsDiff(1L);
        table.setRowsTotal(100L);
        return List.of(table);
    }

    @Test
    void shouldLoadHistoryByParamsFromShards() throws Exception {
        var anotherShard = "anotherPetryaninShard";
        var revisionShardIds = List.of(REVISION_SHARD_ID, anotherShard);

        wiremock.stubFor(WireMock.get(urlPathTemplate("/mass/v1/revisions"))
                                 .willReturn(okJson(objectMapper.writeValueAsString(getRevises()))));

        var startDate = LocalDate.now().minusDays(7);
        var endDate = LocalDate.now();

        MockHttpServletResponse response = mockMvc.perform(get(URL + "/shards/{shardId}/revisions/history", String.join(",", revisionShardIds))
                                                                   .queryParam("status", RevisionJobStatus.FAILED.getValue())
                                                                   .queryParam("from", startDate.toString())
                                                                   .queryParam("to", endDate.toString())
                                                                   .queryParam("pageNumber", PAGE_NUMBER.toString())
                                                                   .queryParam("pageSize", PAGE_SIZE.toString()))
                                                  .andDo(print())
                                                  .andExpect(status().isOk())
                                                  .andReturn().getResponse();

        then(replicaMonitorClient).should(never()).getRevision(any(), any());
        then(replicaMonitorClient).should(never()).getRevisions(any(), any(), any(), any(), any(), any(), any());

        List<RevisionInfo> result = objectMapper.readValue(response.getContentAsString(), new TypeReference<>() {
        });

        assertThat(result)
                .isNotEmpty()
                .extracting(RevisionInfo::getShardId)
                .allSatisfy(shardId -> assertThat(shardId).isEqualTo(REVISION_SHARD_ID));
    }

    @Test
    void shouldLoadHistoryByParamsFromOneShard() throws Exception {
        wiremock.stubFor(WireMock.get(urlPathTemplate("/mass/v1/shards/{shardId}/revisions"))
                                 .withPathParam("shardId", equalTo(REVISION_SHARD_ID))
                                 .willReturn(okJson(objectMapper.writeValueAsString(getRevises()))));

        var startDate = LocalDate.now().minusDays(7);
        var endDate = LocalDate.now();

        MockHttpServletResponse response = mockMvc.perform(get(URL + "/shards/{shardId}/revisions/history", REVISION_SHARD_ID)
                                                                   .queryParam("status", RevisionJobStatus.FAILED.getValue())
                                                                   .queryParam("from", startDate.toString())
                                                                   .queryParam("to", endDate.toString())
                                                                   .queryParam("pageNumber", PAGE_NUMBER.toString())
                                                                   .queryParam("pageSize", PAGE_SIZE.toString()))
                                                  .andDo(print())
                                                  .andExpect(status().isOk())
                                                  .andReturn().getResponse();

        then(replicaMonitorClient).should(never()).getRevision(any(), any());
        then(replicaMonitorClient).should(never()).getRevisionsAggregated(any(), any(), any(), any(), any(), any(), any());

        List<RevisionInfo> result = objectMapper.readValue(response.getContentAsString(), new TypeReference<>() {
        });

        assertThat(result)
                .isNotEmpty()
                .extracting(RevisionInfo::getShardId)
                .allSatisfy(shardId -> assertThat(shardId).isEqualTo(REVISION_SHARD_ID));
    }

    @Test
    void shouldLoadHistoryById() throws Exception {
        wiremock.stubFor(WireMock.get(urlPathTemplate("/mass/v1/shards/{shardId}/revisions/{revisionId}"))
                                 .withPathParam("shardId", equalTo(REVISION_SHARD_ID))
                                 .withPathParam("revisionId", equalTo(String.valueOf(REVISION_ID)))
                                 .willReturn(okJson(objectMapper.writeValueAsString(getRevision()))));

        MockHttpServletResponse response = mockMvc.perform(get(URL + "/shards/{shardId}/revisions/history", REVISION_SHARD_ID)
                                                                   .queryParam("revisionId", REVISION_ID.toString())
                                                                   .queryParam("pageNumber", PAGE_NUMBER.toString())
                                                                   .queryParam("pageSize", PAGE_SIZE.toString()))
                                                  .andDo(print())
                                                  .andExpect(status().isOk())
                                                  .andReturn().getResponse();

        then(replicaMonitorClient).should(never()).getRevisions(any(), any(), any(), any(), any(), any(), any());
        then(replicaMonitorClient).should(never()).getRevisionsAggregated(any(), any(), any(), any(), any(), any(), any());

        List<RevisionInfo> result = objectMapper.readValue(response.getContentAsString(), new TypeReference<>() {
        });

        assertThat(result)
                .isNotEmpty()
                .hasSize(1)
                .allSatisfy(revision -> {
                    assertThat(revision.getId()).isEqualTo(REVISION_ID);
                    assertThat(revision.getStatus()).isEqualTo(RevisionStatus.MATCHED.getValue());
                    assertThat(revision.getShardId()).isEqualTo(REVISION_SHARD_ID);
                });
    }

    private List<Revision> getRevises() {
        Revision revision = new Revision();
        revision.setId(REVISION_ID);
        revision.setCreatedTime(OffsetDateTime.now().minusMinutes(30));
        revision.setStatusTime(OffsetDateTime.now());
        revision.setStatus(Status.MATCHED.getValue());
        revision.setRowsTotal(100L);
        revision.setRowsDiff(0L);
        revision.setShardId(REVISION_SHARD_ID);

        Revision revision2 = new Revision();
        revision2.setId(2L);
        revision2.setCreatedTime(OffsetDateTime.now().minusMonths(1));
        revision2.setStatusTime(OffsetDateTime.now().minusDays(20));
        revision2.setStatus(Status.NOT_MATCHED.getValue());
        revision2.setRowsTotal(30L);
        revision2.setRowsDiff(10L);
        revision2.setShardId(REVISION_SHARD_ID);

        Revision revision3 = new Revision();
        revision3.setId(3L);
        revision3.setCreatedTime(OffsetDateTime.now().minusDays(5));
        revision3.setStatusTime(OffsetDateTime.now().minusDays(2));
        revision3.setStatus(Status.NOT_MATCHED.getValue());
        revision3.setRowsTotal(150L);
        revision3.setRowsDiff(20L);
        revision3.setShardId(REVISION_SHARD_ID);
        return List.of(revision, revision2, revision3);
    }

    private Revision getRevision() {
        Revision revision = new Revision();
        revision.setId(REVISION_ID);
        revision.setCreatedTime(STARTED_TIME);
        revision.setStatusTime(COMPLETED_TIME);
        revision.setStatus(Status.MATCHED.getValue());
        revision.setRowsTotal(100L);
        revision.setRowsDiff(0L);
        revision.setShardId(REVISION_SHARD_ID);
        return revision;
    }

    @Test
    void shouldLoadReport() throws Exception {
        wiremock.stubFor(WireMock.get(urlPathTemplate("/mass/v1/shards/{shardId}/revisions/{revisionId}/rows"))
                                 .withPathParam("shardId", equalTo(REVISION_SHARD_ID))
                                 .withPathParam("revisionId", equalTo(String.valueOf(REVISION_ID)))
                                 .willReturn(okJson(objectMapper.writeValueAsString(getReviseRows()))));

        MockHttpServletResponse response = mockMvc.perform(get(URL + "/shards/{shardIds}/revisions/{revisionId}/report", REVISION_SHARD_ID, REVISION_ID))
                                                  .andDo(print())
                                                  .andExpect(status().isOk())
                                                  .andReturn().getResponse();

        List<RevisionReport> result = objectMapper.readValue(response.getContentAsString(), new TypeReference<>() {
        });

        then(replicaMonitorClient).should().getRevisionRows(any(), any(), any(), any(), any(), eq(DEFAULT_REPORT_PAGE_SIZE));

        assertThat(result).isNotEmpty().allSatisfy(report -> {
            assertThat(report.getId()).isEqualTo(REVISION_ID);
            assertThat(report.getStatus()).isEqualTo(RevisionStatus.NOT_MATCHED.getValue());
            assertThat(report.getPk()).isNotNull();
            assertThat(report.getTable()).isNotNull();
            assertThat(report.getRevisionTaskId()).isEqualTo(REVISION_ID);
        });
    }

    private List<RevisionRow> getReviseRows() {
        RevisionRow row = new RevisionRow();
        row.setId(REVISION_ID);
        row.setCreatedTime(OffsetDateTime.now());
        row.setStatus(Status.NOT_MATCHED.getValue());
        row.pk("key");
        row.setTableName("table");
        row.revisionTaskId(REVISION_ID);
        return List.of(row);
    }
}
