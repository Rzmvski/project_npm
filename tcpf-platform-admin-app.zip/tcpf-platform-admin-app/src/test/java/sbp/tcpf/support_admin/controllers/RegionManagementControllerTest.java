package sbp.tcpf.support_admin.controllers;

import sbp.tcpf.routing.api.v1_0.client.model.Region;
import sbp.tcpf.routing.api.v1_0.client.model.RegionGroup;
import sbp.tcpf.support_admin.config.CommonTestConfig;
import sbp.tcpf.support_admin.config.FeignClientsTestConfig;
import sbp.tcpf.support_admin.config.SecurityTestConfig;
import sbp.tcpf.support_admin.configs.properties.RoutingAppOsProperties;
import sbp.tcpf.support_admin.mappers.RegionManagementServiceMapperImpl;
import sbp.tcpf.support_admin.services.RegionManagementService;
import sbp.tcpf.support_admin.utils.AsyncMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.maciejwalkowiak.wiremock.spring.ConfigureWireMock;
import com.maciejwalkowiak.wiremock.spring.EnableWireMock;
import com.maciejwalkowiak.wiremock.spring.InjectWireMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.test.context.support.WithUserDetails;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalToJson;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.putRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static sbp.tcpf.support_admin.config.SecurityTestConfig.FIRST_ADMIN;

import feign.FeignException;

@WithUserDetails(FIRST_ADMIN)
@EnableWireMock({
        @ConfigureWireMock(name = "routing", property = "tcpf-platform-admin-app.tcpf-routing-app-os.uri")
})
@EnableConfigurationProperties(RoutingAppOsProperties.class)
@AutoConfigureMockMvc(addFilters = false)
@WebMvcTest(RegionManagementController.class)
@Import({
        RegionManagementService.class,
        RegionManagementServiceMapperImpl.class,
        FeignClientsTestConfig.class,
        SecurityTestConfig.class,
        CommonTestConfig.class
})
class RegionManagementControllerTest {

    private static final String URL = "/invoke/support-admin/region";

    @InjectWireMock("routing")
    WireMockServer wiremock;
    @Autowired
    MockMvc mockMvc;
    @Autowired
    ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        wiremock.resetAll();
    }

    private List<RegionGroup> createRegionGroups() {
        return List.of(
                new RegionGroup().startInclusive(0).endExclusive(500).region("moscow").regionAvailability(true),
                new RegionGroup().startInclusive(500).endExclusive(1000).region("spb").regionAvailability(false)
        );
    }

    @Test
    void shouldReturnRegionGroups() throws Exception {
        List<RegionGroup> groups = createRegionGroups();

        wiremock.stubFor(WireMock.get(urlEqualTo("/api/v1/region/groups"))
                                 .willReturn(aResponse()
                                                     .withStatus(200)
                                                     .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                                     .withBody(objectMapper.writeValueAsString(groups))));

        MockHttpServletResponse response = AsyncMvc.perform(mockMvc, get(URL + "/groups"))
                                                   .andDo(print())
                                                   .andExpect(status().isOk())
                                                   .andReturn().getResponse();

        List<sbp.tcpf.support_admin.model.RegionGroupDto> result =
                AsyncMvc.readList(objectMapper, response, sbp.tcpf.support_admin.model.RegionGroupDto.class);
        assertThat(result).hasSize(2);
        assertThat(result.get(0).getStartInclusive()).isEqualTo(0);
        assertThat(result.get(0).getRegion()).isEqualTo("moscow");
        assertThat(result.get(0).getRegionAvailability()).isTrue();
        assertThat(result.get(1).getStartInclusive()).isEqualTo(500);
        assertThat(result.get(1).getRegion()).isEqualTo("spb");
        assertThat(result.get(1).getRegionAvailability()).isFalse();

        wiremock.verify(1, getRequestedFor(urlEqualTo("/api/v1/region/groups")));
    }

    @Test
    void shouldThrowOnRequestRegionGroups() throws Exception {
        wiremock.stubFor(WireMock.get(urlEqualTo("/api/v1/region/groups"))
                                 .willReturn(WireMock.serverError()));

        AsyncMvc.perform(mockMvc, get(URL + "/groups"))
                .andDo(print())
                .andExpect(status().isInternalServerError())
                .andExpect(result -> assertThat(result.getResolvedException())
                        .isInstanceOf(FeignException.class)
                );
    }

    @Test
    void shouldUpdateRegionGroups() throws Exception {
        // «Перевести диапазоны»: диапазон spb переназначен moscow.
        List<RegionGroup> groups = List.of(
                new RegionGroup().startInclusive(0).endExclusive(500).region("moscow").regionAvailability(true),
                new RegionGroup().startInclusive(500).endExclusive(1000).region("moscow").regionAvailability(true)
        );
        String body = objectMapper.writeValueAsString(groups);

        wiremock.stubFor(WireMock.put(urlEqualTo("/api/v1/region/groups"))
                                 .withRequestBody(equalToJson(body))
                                 .willReturn(aResponse()
                                                     .withStatus(200)
                                                     .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                                     .withBody(body)));

        MockHttpServletResponse response = AsyncMvc.perform(mockMvc, put(URL + "/groups")
                                                           .contentType(MediaType.APPLICATION_JSON)
                                                           .content(body))
                                                   .andDo(print())
                                                   .andExpect(status().isOk())
                                                   .andReturn().getResponse();

        List<sbp.tcpf.support_admin.model.RegionGroupDto> result =
                AsyncMvc.readList(objectMapper, response, sbp.tcpf.support_admin.model.RegionGroupDto.class);
        assertThat(result).hasSize(2)
                          .allSatisfy(group -> assertThat(group.getRegion()).isEqualTo("moscow"));

        wiremock.verify(1, putRequestedFor(urlEqualTo("/api/v1/region/groups")).withRequestBody(equalToJson(body)));
    }

    @Test
    void shouldThrowOnUpdateRegionGroups() throws Exception {
        wiremock.stubFor(WireMock.put(urlEqualTo("/api/v1/region/groups"))
                                 .willReturn(WireMock.serverError()));

        AsyncMvc.perform(mockMvc, put(URL + "/groups")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(createRegionGroups())))
                .andDo(print())
                .andExpect(status().isInternalServerError())
                .andExpect(result -> assertThat(result.getResolvedException())
                        .isInstanceOf(FeignException.class)
                );
    }

    @Test
    void shouldUpdateRegionAvailability() throws Exception {
        List<Region> regions = List.of(
                new Region().region("moscow").regionAvailability(true),
                new Region().region("spb").regionAvailability(false)
        );
        String body = objectMapper.writeValueAsString(regions);

        wiremock.stubFor(WireMock.put(urlEqualTo("/api/v1/region"))
                                 .withRequestBody(equalToJson(body))
                                 .willReturn(aResponse()
                                                     .withStatus(200)
                                                     .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                                     .withBody(body)));

        MockHttpServletResponse response = AsyncMvc.perform(mockMvc, put(URL)
                                                           .contentType(MediaType.APPLICATION_JSON)
                                                           .content(body))
                                                   .andDo(print())
                                                   .andExpect(status().isOk())
                                                   .andReturn().getResponse();

        List<sbp.tcpf.support_admin.model.RegionDto> result =
                AsyncMvc.readList(objectMapper, response, sbp.tcpf.support_admin.model.RegionDto.class);
        assertThat(result).hasSize(2);
        assertThat(result.get(1).getRegion()).isEqualTo("spb");
        assertThat(result.get(1).getRegionAvailability()).isFalse();

        wiremock.verify(1, putRequestedFor(urlEqualTo("/api/v1/region")).withRequestBody(equalToJson(body)));
    }

    @Test
    void shouldThrowOnUpdateRegionAvailability() throws Exception {
        wiremock.stubFor(WireMock.put(urlEqualTo("/api/v1/region"))
                                 .willReturn(WireMock.serverError()));

        AsyncMvc.perform(mockMvc, put(URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(
                                List.of(new Region().region("moscow").regionAvailability(false)))))
                .andDo(print())
                .andExpect(status().isInternalServerError())
                .andExpect(result -> assertThat(result.getResolvedException())
                        .isInstanceOf(FeignException.class)
                );
    }
}
