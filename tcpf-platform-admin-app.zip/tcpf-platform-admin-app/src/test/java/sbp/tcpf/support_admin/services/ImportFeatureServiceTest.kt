package sbp.tcpf.support_admin.services

import org.apache.curator.framework.CuratorFramework
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.mockito.kotlin.*
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.context.TestConfiguration
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Import
import org.springframework.test.context.bean.override.mockito.MockitoBean
import reactor.core.publisher.Flux
import sbp.tcpf.coordination.config.CuratorFacade.AppCuratorBean
import sbp.tcpf.coordination.utils.CuratorUtils
import sbp.tcpf.ff4j.admin.facade.FF4jAdmin
import sbp.tcpf.ff4j.client.config.CuratorFacade.FeatureTogglingCuratorBean
import sbp.tcpf.ff4j.config.FF4jClientProperties
import sbp.tcpf.routing.api.v1_0.client.model.Node
import sbp.tcpf.support_admin.config.CuratorTestConfig
import sbp.tcpf.support_admin.config.SecurityTestConfig
import sbp.tcpf.support_admin.configs.properties.ResolveRequestServiceProperties
import sbp.tcpf.support_admin.dto.FeatureConfigurationDto
import sbp.tcpf.support_admin.dto.FeatureLocation
import sbp.tcpf.support_admin.dto.FeatureSnapshot
import sbp.tcpf.support_admin.entities.FeatureRequest
import sbp.tcpf.support_admin.facades.Ff4jFacade
import sbp.tcpf.support_admin.mappers.*
import sbp.tcpf.support_admin.model.*
import sbp.tcpf.support_admin.services.request.FeatureRequestFactory
import sbp.tcpf.support_admin.services.request.RequestService
import sbp.tcpf.support_admin.utils.ReactiveMocks.reactiveMock
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.*

@EnableConfigurationProperties(ResolveRequestServiceProperties::class)
@SpringBootTest(
        classes = [
            ImportFeatureService::class,
            Ff4jFacade::class,
            FeatureTogglingService::class,
            LogicalFeatureAggregator::class,
            FeatureRequestFactory::class,
            FeatureMapperImpl::class,
            FeatureConfigurationMapperImpl::class,
            FeatureActivationMapper::class,
            CustomPropertyMapperImpl::class,
            FeatureSnapshotMapperImpl::class,
            LogicalFeatureMapperImpl::class,
            FeatureTargetMapper::class,
            FeatureStatisticsMapperImpl::class,
        ]
)
@Import(
        CuratorTestConfig::class,
        ImportFeatureServiceTest.Config::class,
        SecurityTestConfig::class,
)
class ImportFeatureServiceTest {

    @MockitoBean
    lateinit var requestService: RequestService<UUID, FeatureRequest, FeatureApplication>

    @Autowired
    lateinit var ff4jFacade: Ff4jFacade

    @Autowired
    lateinit var importFeatureService: ImportFeatureService

    @TestConfiguration
    class Config {
        @FeatureTogglingCuratorBean
        fun featureCurator(@AppCuratorBean curator: CuratorFramework): CuratorFramework {
            return CuratorUtils.facadeWithNamespace(curator, "feature")
        }

        @Bean
        fun ff4Admin(@FeatureTogglingCuratorBean curator: CuratorFramework): FF4jAdmin {
            val props = FF4jClientProperties()
            return FF4jAdmin(curator, props)
        }

        @Bean
        fun shardService(): ShardService {
            val shardService = reactiveMock(ShardService::class.java)
            given(shardService.getNodes()).willReturn(
                    Flux.just(
                            Node.builder()
                                .shardId(1005)
                                .key("P5")
                                .build(),
                            Node.builder()
                                .shardId(1005)
                                .key("S5")
                                .build()
                    )
            )

            return shardService
        }
    }

    @Test
    fun `should process dump and call request service`() {
        val skippedSnapshot = FeatureSnapshot(
                "name",
                FeatureLocation("moduleA", null),
                FeatureConfigurationDto(
                        true, "description", null, Collections.emptyMap()
                ),
                LocalDateTime.now(),
                null,
                false,
        )

        val shardFeatureSnapshots = listOf(
                FeatureSnapshot(
                        "SHARD_FEATURE",
                        FeatureLocation(null, "P5"),
                        FeatureConfigurationDto(
                                true, "description", null, Collections.emptyMap()
                        ),
                        LocalDateTime.now(),
                        null,
                        false,
                ),
                FeatureSnapshot(
                        "SHARD_FEATURE",
                        FeatureLocation(null, "S5"),
                        FeatureConfigurationDto(
                                true, "description", null, Collections.emptyMap()
                        ),
                        LocalDateTime.now(),
                        null,
                        false,
                )
        )

        val changedSnapshot = FeatureSnapshot(
                "RATE_LIMITER_CONFIG",
                FeatureLocation("tcpf-info-details-app", null),
                FeatureConfigurationDto(
                        true,
                        "фича для настройки hot swap rate limiter",
                        null,
                        Collections.emptyMap()
                ),
                LocalDateTime.now(),
                null,
                false,
        )

        ff4jFacade.create(skippedSnapshot)
        ff4jFacade.create(changedSnapshot)
        shardFeatureSnapshots.forEach { snapshot ->
            ff4jFacade.create(snapshot)
        }

        val dump = listOf<LogicalFeature>(
                LogicalFeature.builder()
                    .hot(false)
                    .name(skippedSnapshot.name)
                    .target(DirectFeatureTarget().module(skippedSnapshot.location.module))
                    .config(
                            FeatureConfiguration(
                                    ManualFeatureActivation().enabled(skippedSnapshot.configuration.enable),
                                    skippedSnapshot.configuration.description,
                                    Collections.emptyList()
                            )
                    )
                    .created(LocalDateTime.now())
                    .build(),
                LogicalFeature.builder()
                    .hot(false)
                    .name(changedSnapshot.name)
                    .target(DirectFeatureTarget().module(changedSnapshot.location.module))
                    .config(
                            FeatureConfiguration(
                                    ManualFeatureActivation().enabled(false),
                                    "changed description",
                                    Collections.emptyList()
                            )
                    )
                    .created(LocalDateTime.now())
                    .build(),
                LogicalFeature.builder()
                    .hot(false)
                    .name("NEW_FEATURE")
                    .target(NodeFeatureTarget().module("module").nodeKey("node"))
                    .config(
                            FeatureConfiguration(
                                    OdReleaseFeatureActivation().releaseDate(LocalDate.now()),
                                    "description",
                                    Collections.emptyList()
                            )
                    )
                    .created(LocalDateTime.now())
                    .build(),
                LogicalFeature.builder()
                    .hot(false)
                    .name("SHARD_FEATURE")
                    .target(ShardFeatureTarget().nodeKeys(listOf("P5", "S5")))
                    .config(
                            FeatureConfiguration(
                                    OdReleaseFeatureActivation().releaseDate(LocalDate.now()),
                                    "description",
                                    Collections.emptyList()
                            )
                    )
                    .created(LocalDateTime.now())
                    .build(),
        )

        val result = importFeatureService.import("test", dump)

        assertThat(result.created).isEqualTo(1)
        assertThat(result.updated).isEqualTo(2)
        assertThat(result.skipped).isEqualTo(1)

        verify(requestService, times(result.created + result.updated)).save(any())
    }

    @Test
    fun `should skip delete requests`() {
        val shardFeatureSnapshots = listOf(
                FeatureSnapshot(
                        "SHARD_FEATURE",
                        FeatureLocation("moduleA", "P5"),
                        FeatureConfigurationDto(true, "description", null, null),
                        LocalDateTime.now(),
                        null,
                        false
                ),
                FeatureSnapshot(
                        "SHARD_FEATURE",
                        FeatureLocation("moduleA", "S5"),
                        FeatureConfigurationDto(true, "description", null, null),
                        LocalDateTime.now(),
                        null,
                        false
                )
        )

        shardFeatureSnapshots.forEach { snapshot ->
            ff4jFacade.create(snapshot)
        }

        val dump = listOf<LogicalFeature>(
                LogicalFeature.builder()
                    .name("SHARD_FEATURE")
                    .target(ShardFeatureTarget().nodeKeys(listOf("P5", "S5")))
                    .created(LocalDateTime.now())
                    .hot(false)
                    .build(),
        )

        val result = importFeatureService.import("test", dump)

        assertThat(result.skipped).isEqualTo(1)

        verify(requestService, never()).save(any())
    }
}
