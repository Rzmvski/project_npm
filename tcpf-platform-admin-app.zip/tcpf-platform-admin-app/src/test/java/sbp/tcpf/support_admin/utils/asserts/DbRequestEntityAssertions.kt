package sbp.tcpf.support_admin.utils.asserts

import org.assertj.core.api.AbstractAssert
import org.assertj.core.api.Assertions.assertThat
import sbp.tcpf.support_admin.entities.RequestEntity
import sbp.tcpf.support_admin.mappers.ScriptDbEntityMapper.*
import sbp.tcpf.support_admin.services.request.RequestStatus
import java.time.LocalDate

fun assertDbRequestEntity(actual: RequestEntity?): DbRequestEntityAssertions = DbRequestEntityAssertions(actual)

class DbRequestEntityAssertions(private val actual: RequestEntity?) :
    AbstractAssert<DbRequestEntityAssertions, RequestEntity?>(actual, DbRequestEntityAssertions::class.java) {

    fun hasBasicFields(
        rqUid: String,
        bucketHash: Int = BUCKET_HASH,
        operDate: LocalDate = LocalDate.EPOCH,
        requestTypeId: Long = TYPE_ID,
        extSystemId: Long = ARM_ID,
        channelId: Long = VSP_ID,
        contractId: Long = CONTRACT_ID,
    ) = apply {
        assertThat(actual).satisfies({
            assertThat(it?.id).isNotNull
            assertThat(it?.bucketHash).isEqualTo(bucketHash)
            assertThat(it?.operDate).isEqualTo(operDate)
            assertThat(it?.requestTypeId).isEqualTo(requestTypeId)
            assertThat(it?.rqUid).isEqualTo(rqUid)
            assertThat(it?.extSystemId).isEqualTo(extSystemId)
            assertThat(it?.channelId).isEqualTo(channelId)
            assertThat(it?.contractId).isEqualTo(contractId)
        })
    }

    fun hasStatus(status: RequestStatus) = apply {
        assertThat(actual?.statusId).isEqualTo(status.id)
    }

    fun hasData(rqData: String?, rsData: String? = null) = apply {
        assertThat(actual?.rqData).isEqualTo(rqData)
        assertThat(actual?.rsData).isEqualTo(rsData)
    }

    fun hasCreator(login: String?) = apply {
        assertThat(actual?.creatorLogin).isEqualTo(login)
        assertThat(actual?.created).isNotNull
    }

    fun hasResolver(login: String?) = apply {
        assertThat(actual?.approverLogin).isEqualTo(login)
        assertThat(actual?.rowUpdTimestamp).isNotNull
    }
}
