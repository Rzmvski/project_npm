package sbp.tcpf.support_admin.config;

import sbp.tcpf.coordination.config.CuratorFacade.AppCuratorBean;
import sbp.tcpf.support_admin.configs.AppConfig;
import sbp.tcpf.support_admin.configs.RequestCuratorCacheListenerRegistrar;
import sbp.tcpf.support_admin.configs.CuratorConfig;
import sbp.tcpf.support_admin.configs.CuratorConfig.RequestCuratorBean;
import sbp.tcpf.support_admin.configs.properties.ScriptServiceProperties;
import sbp.tcpf.support_admin.utils.zookeeper.EmbeddedZookeeperServer;
import sbp.tcpf.support_admin.utils.zookeeper.MockZookeeperManager;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.apache.curator.framework.CuratorFramework;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;

@EnableConfigurationProperties(ScriptServiceProperties.class)
@TestConfiguration
@Import({
        CuratorConfig.class,
        CommonTestConfig.class,
        AppConfig.class,
        RequestCuratorCacheListenerRegistrar.class,
})
public class CuratorTestConfig {

    @Bean
    public ObjectMapper objectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        return objectMapper;
    }

    @Bean
    public EmbeddedZookeeperServer embeddedZookeeperServer() {
        return new EmbeddedZookeeperServer();
    }

    @AppCuratorBean
    public CuratorFramework realCurator(EmbeddedZookeeperServer server) {
        return server.getCuratorFramework();
    }

    @Bean
    public MockZookeeperManager mockZookeeperManager(@RequestCuratorBean CuratorFramework curatorFramework,
                                                     ObjectMapper objectMapper) {
        return new MockZookeeperManager(curatorFramework, objectMapper);
    }
}
