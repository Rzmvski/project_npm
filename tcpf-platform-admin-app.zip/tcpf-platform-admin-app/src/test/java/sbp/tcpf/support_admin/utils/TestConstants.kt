package sbp.tcpf.support_admin.utils

object TestConstants {
    const val ALPHA: String = "ALPHA"
    const val GAMMA: String = "GAMMA"
    const val P5: String = "P5"
    const val S5: String = "S5"
    const val P6: String = "P6"
    const val S6: String = "S6"
    const val SEM_1: String = "SEM_1"
    const val SEM_2: String = "SEM_2"
}
