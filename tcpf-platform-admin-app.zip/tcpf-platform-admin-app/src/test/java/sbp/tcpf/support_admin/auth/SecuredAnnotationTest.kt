package sbp.tcpf.support_admin.auth

import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.reflections.Reflections
import org.reflections.scanners.Scanners
import org.springframework.security.access.annotation.Secured
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestMethod
import org.springframework.web.bind.annotation.RestController
import java.lang.reflect.Method
import kotlin.reflect.full.declaredFunctions
import kotlin.reflect.jvm.javaMethod

class SecuredAnnotationTest {

    @Test
    fun `post methods must be secured`() {
        val reflections = Reflections("sbp.tcpf.support_admin", Scanners.TypesAnnotated, Scanners.MethodsAnnotated)

        val interfaceMethods = reflections.getMethodsAnnotatedWith(RequestMapping::class.java)
            .filter { it.isPostMethod() }
            .toSet()

        val controllerMethods = reflections.getTypesAnnotatedWith(RestController::class.java)
            .flatMap { it.kotlin.declaredFunctions.mapNotNull { func -> func.javaMethod } }
            .toSet()

        interfaceMethods
            .map { it.findImplementationMethods(controllerMethods) }
            .onEach { implementingMethods ->
                assertThat(implementingMethods)
                    .`as`("Method ${implementingMethods.firstOrNull()} must have only one implementation")
                    .hasSizeLessThan(2)
            }
            .flatten()
            .forEach { method ->
                assertThat(method.isAnnotationPresent(Secured::class.java))
                    .`as`("Method ${method.name} in controller class ${method.declaringClass.simpleName} must be annotating with @Secured")
                    .isTrue()
            }

    }

    private fun Method.isPostMethod(): Boolean {
        val requestMapping = getAnnotation(RequestMapping::class.java)
        return requestMapping?.method?.contains(RequestMethod.POST) == true
    }

    private fun Method.findImplementationMethods(controllerMethods: Set<Method>): List<Method> {
        return controllerMethods.filter { it.isImplementingMethod(this) }
    }

    private fun Method.isImplementingMethod(interfaceMethod: Method): Boolean {
        return name == interfaceMethod.name &&
                parameterTypes.matches(interfaceMethod.parameterTypes) &&
                returnType.matches(interfaceMethod.returnType)
    }

    private fun Array<Class<*>>.matches(other: Array<Class<*>>): Boolean {
        return size == other.size && indices.all { this[it].matches(other[it]) }
    }

    private fun Class<*>.matches(other: Class<*>): Boolean {
        return this.normalizeType() == other.normalizeType()
    }

    private fun Class<*>.normalizeType(): Class<*> {
        return this::class.java
    }
}
