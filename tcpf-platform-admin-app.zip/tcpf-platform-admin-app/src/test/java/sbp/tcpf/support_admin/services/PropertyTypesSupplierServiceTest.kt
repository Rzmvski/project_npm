package sbp.tcpf.support_admin.services

import org.assertj.core.api.Assertions.assertThat
import org.ff4j.property.Property
import org.ff4j.property.PropertyInstant
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest(classes = [
    PropertyTypesSupplierService::class
])
class PropertyTypesSupplierServiceTest {

    @Autowired
    lateinit var propertyTypesSupplierService: PropertyTypesSupplierService

    @Test
    fun `should return property types`() {
        val types = propertyTypesSupplierService.getTypes()

        assertThat(types).isNotEmpty
            .doesNotContain(PropertyInstant::class.java.name)
            .allMatch { it.startsWith(Property::class.java.name) }
    }
}
