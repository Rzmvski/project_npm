package sbp.tcpf.support_admin.utils.asserts

import org.assertj.core.api.AbstractAssert
import org.assertj.core.api.Assertions.assertThat
import sbp.tcpf.support_admin.entities.ScriptRequest
import sbp.tcpf.support_admin.model.ApplicationStatus
import sbp.tcpf.support_admin.model.Restrictions

fun assertZkRequestEntity(actual: ScriptRequest?): ZkRequestEntityAssertions = ZkRequestEntityAssertions(actual)

class ZkRequestEntityAssertions(private val actual: ScriptRequest?) :
    AbstractAssert<ZkRequestEntityAssertions, ScriptRequest>(actual, ZkRequestEntityAssertions::class.java) {

    fun hasBasicFields(
        uid: String,
        content: ByteArray? = null,
    ) = apply {
        assertThat(actual?.uid).isEqualTo(uid)
        assertThat(actual?.content).isEqualTo(content)
        assertThat(actual?.requestTtl).isNotNull
    }

    fun hasStatus(status: ApplicationStatus?) = apply {
        assertThat(actual?.requestStatus).isEqualTo(status?.value)
    }

    fun hasCreator(login: String?) = apply {
        assertThat(actual?.createdBy).isEqualTo(login)
        assertThat(actual?.createdAt).isNotNull
    }

    fun hasResolver(login: String?) = apply {
        assertThat(actual?.resolvedBy).isEqualTo(login)
        assertThat(actual?.resolvedAt).isNotNull
    }

    fun hasRestrictions(expected: Restrictions?) = apply {
        assertThat(actual?.restrictions).isEqualTo(expected)
    }

    fun hasShardId(expected: Int) = apply {
        assertThat(actual?.dbRef)
            .extracting { it?.shardId }
            .isEqualTo(expected)
    }
}
