package sbp.tcpf.support_admin.config;

import sbp.tcpf.routing.client.LockContractService;
import sbp.tcpf.routing.client.core.RoutingInfoProviderInternal;
import sbp.tcpf.routing.client.core.hibernate.RoutingContextNodeResolver;
import sbp.tcpf.routing.client.core.lock.EntityLockRepository;
import sbp.tcpf.routing.client.core.uow.UOW;
import sbp.tcpf.routing.client.core.uow.UOWFactory;
import sbp.tcpf.routing.client.core.uow.UOWRunner;
import sbp.tcpf.routing.client.core.uow.UnitOfWorkFacade;
import sbp.tcpf.routing.client.core.uow.UnitOfWorkOperations;
import sbp.tcpf.routing.client.core.uow.UnitOfWorkOperationsFactory;
import sbp.tcpf.routing.client.core.uow.exception.UOWException;
import sbp.tcpf.support_admin.clients.feign.routing.RoutingMonitoringManagementApiClient;
import sbp.tcpf.support_admin.wrappers.SafeUnitOfWorkOperations;

import org.hibernate.Session;
import org.mockito.ArgumentMatchers;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;

import java.util.concurrent.Callable;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static sbp.tcpf.support_admin.utils.ReactiveMocks.reactiveMock;

import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import jakarta.persistence.EntityManager;
import kotlin.jvm.functions.Function1;

@TestConfiguration
public class UOWTestConfig {

    @Bean
    @ConditionalOnMissingBean
    public RoutingMonitoringManagementApiClient routingMonitoringManagementApiClient() {
        // default answer, а не given(...): Spring сбрасывает стабы мок-бинов после каждого
        // теста, и стаб из @Bean-фабрики дожил бы только до первого. Без пустого Flux
        // SafeUnitOfWorkOperations падает с NPE вместо «мониторинга по ноде нет».
        return reactiveMock(RoutingMonitoringManagementApiClient.class);
    }

    @Bean
    @ConditionalOnMissingBean
    public SafeUnitOfWorkOperations uowWrapper(
            RoutingMonitoringManagementApiClient monitoringManagementApiClient,
            UnitOfWorkOperations uow
    ) {
        return new SafeUnitOfWorkOperations(monitoringManagementApiClient, uow);
    }

    @Bean
    public UOWFactory uowFactory() {
        var routingContextNodeResolver = mock(RoutingContextNodeResolver.class);
        var lockContractService = mock(LockContractService.class);
        var entityLockRepository = mock(EntityLockRepository.class);
        var ptm = mock(PlatformTransactionManager.class);
        var sharedEntityManager = mock(EntityManager.class);
        var meterRegistry = new SimpleMeterRegistry();
        var routingInfoProviderInternal = mock(RoutingInfoProviderInternal.class);
        var session = mock(Session.class);

        given(sharedEntityManager.unwrap(any())).willReturn(session);

        return new UOWFactory(routingContextNodeResolver,
                              null,
                              null,
                              lockContractService,
                              entityLockRepository,
                              ptm,
                              sharedEntityManager,
                              meterRegistry,
                              routingInfoProviderInternal
        );
    }

    @Bean
    public UOWRunner uowRunner() {
        var uowRunner = mock(UOWRunner.class);
        given(uowRunner.run(any()))
                .willAnswer(i -> i.getArgument(0, UOW.class).run());
        return uowRunner;
    }

    @Bean
    public UnitOfWorkOperationsFactory unitOfWorkOperationsFactory(UOWFactory uowFactory, UOWRunner uowRunner) {
        return new UnitOfWorkOperationsFactory(uowFactory, uowRunner);
    }

    @Bean
    public UnitOfWorkFacade uow() {
        var uow = mock(UnitOfWorkFacade.class);
        given(uow.callOnNodeDefault(
                any(),
                any(),
                any(TransactionDefinition.class),
                ArgumentMatchers.<Callable<Object>>any())
        ).willAnswer(i -> {
            try {
                return i.getArgument(3, Callable.class).call();
            } catch (Exception e) {
                throw new UOWException(e);
            }
        });

        given(uow.callOnNodeDefault(
                any(),
                any(),
                any(TransactionDefinition.class),
                ArgumentMatchers.<Function1<? super EntityManager, ?>>any())
        ).willAnswer(invocation -> {
            Function1<EntityManager, ?> work = invocation.getArgument(3);
            EntityManager entityManager = mock(EntityManager.class);
            try {
                return work.invoke(entityManager);
            } catch (Exception e) {
                throw new UOWException(e);
            }
        });

        return uow;
    }
}
