package sbp.tcpf.support_admin.config;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class InMemoryUfsUserDetailsService implements UserDetailsService {

    private final Map<String, UserDetails> storage = new HashMap<>();

    public InMemoryUfsUserDetailsService(UserDetails... users) {
        for (UserDetails user : users) {
            storage.put(user.getUsername().toLowerCase(Locale.ROOT), user);
        }
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        UserDetails user = storage.get(username.toLowerCase(Locale.ROOT));
        if (user == null) {
            throw new UsernameNotFoundException("user '" + username + "' not found");
        }
        return user;
    }
}
