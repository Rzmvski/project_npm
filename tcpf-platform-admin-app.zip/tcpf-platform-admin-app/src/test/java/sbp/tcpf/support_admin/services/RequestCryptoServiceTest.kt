package sbp.tcpf.support_admin.services

import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.boot.test.context.SpringBootTest
import sbp.tcpf.support_admin.configs.properties.ResolveRequestServiceProperties
import sbp.tcpf.support_admin.entities.AbstractRequest
import sbp.tcpf.support_admin.entities.ScriptRequest
import sbp.tcpf.support_admin.model.ApplicationStatus
import sbp.tcpf.support_admin.services.request.RequestCryptoService

@EnableConfigurationProperties(ResolveRequestServiceProperties::class)
@SpringBootTest(classes = [RequestCryptoService::class])
class RequestCryptoServiceTest {

    companion object {
        const val UID = "test"
        const val MODULE = "module"
    }

    @Autowired
    private lateinit var requestCryptoService: RequestCryptoService<AbstractRequest>

    @Test
    fun `should successfully encrypt data`() {
        val request = ScriptRequest.builder()
            .uid(UID)
            .requestStatus(ApplicationStatus.CREATED.value)
            .build()

        val encryptedRequest = requestCryptoService.encrypt(request)

        assertThat(encryptedRequest.requestStatus).isBase64
    }

    @Test
    fun `should encrypt data with different salt`() {
        val status = ApplicationStatus.CREATED.value

        val request = ScriptRequest.builder()
            .uid(UID)
            .requestStatus(status)
            .build()

        val anotherRequest = ScriptRequest.builder()
            .uid("another")
            .requestStatus(status)
            .build()

        val encryptedRequest = requestCryptoService.encrypt(request)
        val encryptedAnotherRequest = requestCryptoService.encrypt(anotherRequest)

        assertThat(encryptedRequest.requestStatus).isNotEqualTo(encryptedAnotherRequest.requestStatus)
    }

    @Test
    fun `should successfully decrypt data`() {
        val status = ApplicationStatus.CREATED.value
        val request = ScriptRequest.builder()
            .uid(UID)
            .requestStatus(status)
            .build()

        val encryptedRequest = requestCryptoService.encrypt(request)

        assertThat(encryptedRequest.requestStatus).isBase64

        val decryptedRequest = requestCryptoService.decrypt(encryptedRequest)

        assertThat(decryptedRequest.requestStatus).isEqualTo(status)
    }
}
