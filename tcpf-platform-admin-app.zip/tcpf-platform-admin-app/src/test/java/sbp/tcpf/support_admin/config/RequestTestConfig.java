package sbp.tcpf.support_admin.config;

import sbp.tcpf.support_admin.entities.RequestEntity;

import org.springframework.boot.test.context.TestConfiguration;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@TestConfiguration
public class RequestTestConfig {

    private final Map<Long, RequestEntity> mockTable = new ConcurrentHashMap<>();

//    @Bean
//    public DbRequestRepository generalRequestRepository() {
//        DbRequestRepository requestRepository = mock(DbRequestRepository.class);
//
//        doAnswer(i -> {
//            String rqUid = i.getArgument(0);
//            return mockTable.values().stream()
//                    .filter(entity -> rqUid.equals(entity.getRqUid()))
//                    .findFirst().orElse(null);
//        }).when(requestRepository).findByKeyAndType(any(), any());
//
//        doAnswer(i -> {
//            RequestEntity entity = i.getArgument(0);
//            mockTable.put(entity.getId(), entity);
//            return null;
//        }).when(requestRepository).save(any());
//
//        doAnswer(i -> mockTable.values()).when(requestRepository).loadByType(any());
//
//        return requestRepository;
//    }
}
