package sbp.tcpf.support_admin.config;

import sbp.tcpf.os.commons.config.ModuleProperties;
import sbp.tcpf.support_admin.configs.AsyncConfig;

import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;

@TestConfiguration
@Import(AsyncConfig.class)
public class CommonTestConfig {

    @Bean
    public ModuleProperties moduleProperties() {
        ModuleProperties properties = new ModuleProperties();
        properties.setModuleId("moduleId");
        return properties;
    }
}
