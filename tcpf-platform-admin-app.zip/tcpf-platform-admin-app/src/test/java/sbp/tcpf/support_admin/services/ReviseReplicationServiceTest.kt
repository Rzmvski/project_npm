package sbp.tcpf.support_admin.services

import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import org.mockito.kotlin.*
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.bean.override.mockito.MockitoBean
import sbp.tcpf.support_admin.clients.feign.replica_monitor.ReplicaMonitorApiClient
import sbp.tcpf.support_admin.configs.properties.ReplicaMonitorAppProperties
import sbp.tcpf.support_admin.exceptions.ExternalServiceException
import sbp.tcpf.support_admin.mappers.RevisionDetailsMapperImpl
import sbp.tcpf.support_admin.mappers.RevisionMapperImpl
import sbp.tcpf.support_admin.mappers.RevisionReportMapperImpl
import sbp.tcpf.support_admin.mappers.RevisionStatusMapperImpl
import java.util.*

@EnableConfigurationProperties(ReplicaMonitorAppProperties::class)
@SpringBootTest(
    classes = [
        ReviseReplicationService::class,
        RevisionMapperImpl::class,
        RevisionDetailsMapperImpl::class,
        RevisionReportMapperImpl::class,
        RevisionStatusMapperImpl::class,
    ]
)
class ReviseReplicationServiceTest {

    @MockitoBean
    lateinit var massSpringServer: ReplicaMonitorApiClient

    @Autowired
    lateinit var reviseReplicationService: ReviseReplicationService

    @Test
    fun `should ignore fails and process all revision requests`() {
        given { massSpringServer.postRevisions(any(), any(), any(), eq(null),eq(null)) }.willThrow(RuntimeException())

        val uuid = UUID.randomUUID()
        val part = 1
        val shardIds = listOf("shard1", "shard2")

        assertThrows<ExternalServiceException>("failed to revise on some shards") {
            reviseReplicationService.revise(shardIds, uuid, part)
        }

        then(massSpringServer).should(times(shardIds.size)).postRevisions(any(), any(), any(), eq(null),eq(null))
    }
}
