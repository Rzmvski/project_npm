package sbp.tcpf.support_admin.services.request.resolvers

import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.mockito.kotlin.given
import org.mockito.kotlin.then
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.context.annotation.Import
import org.springframework.kafka.test.utils.KafkaTestUtils
import org.springframework.security.test.context.support.WithUserDetails
import org.springframework.test.context.bean.override.mockito.MockitoBean
import reactor.core.publisher.Mono
import sbp.tcpf.script.engine.async.model.StartCommand
import sbp.tcpf.support_admin.clients.kafka.ScriptEngineCommandPublisher
import sbp.tcpf.support_admin.config.SecurityTestConfig
import sbp.tcpf.support_admin.config.SecurityTestConfig.FIRST_ADMIN
import sbp.tcpf.support_admin.configs.properties.ScriptServiceProperties
import sbp.tcpf.support_admin.dto.ScriptApplicationDto
import sbp.tcpf.support_admin.mappers.ScriptExecutionRequestMapperImpl
import sbp.tcpf.support_admin.model.ApplicationStatus
import sbp.tcpf.support_admin.model.Restrictions
import sbp.tcpf.support_admin.services.request.dto.ScriptKey
import sbp.tcpf.support_admin.services.request.execution.ExecutionContextManager
import sbp.tcpf.support_admin.services.request.resolvers.script.WorksResolver
import sbp.tcpf.support_admin.services.request.store.CompositeScriptDataStore
import sbp.tcpf.support_admin.utils.kafka.BaseKafkaTest
import java.util.*

@EnableConfigurationProperties(ScriptServiceProperties::class)
@WithUserDetails(FIRST_ADMIN)
@SpringBootTest(
        classes = [
            WorksResolver::class,
            ScriptExecutionRequestMapperImpl::class,
            ScriptEngineCommandPublisher::class,
        ]
)
@Import(
        SecurityTestConfig::class,
)
class WorksResolverTest : BaseKafkaTest() {

    @MockitoBean
    lateinit var executionContextManager: ExecutionContextManager

    @MockitoBean
    lateinit var updater: CompositeScriptDataStore

    @Autowired
    lateinit var worksResolver: WorksResolver

    @Test
    fun `should send run script command to kafka`() {
        val allowedNodes = listOf("Node A", "Node B")
        val uid = UUID.randomUUID()
        val reasonId = "reasonId"
        val application = ScriptApplicationDto(
                location = ScriptKey(reasonId),
                jiraId = "jiraId",
                status = ApplicationStatus.WORKS,
                restrictions = Restrictions(true, allowedNodes)
        )
        val consumer = testConsumerFactory.createConsumer(commandTopic)

        given { executionContextManager.awaitExecution(reasonId) }.willReturn(Mono.empty())

        worksResolver.resolve(application)

        val record = KafkaTestUtils.getSingleRecord(consumer, commandTopic)

        assertThat(record)
            .extracting { record -> record.value() }
            .isInstanceOfSatisfying(StartCommand::class.java, { command ->
                assertThat(command.executionId).isEqualTo(reasonId)
                assertThat(command.executedBy).isEqualTo(FIRST_ADMIN)
                assertThat(command.restrictions).isNotNull.satisfies({ restrictions ->
                    assertThat(restrictions?.allowedNodes).containsExactlyInAnyOrderElementsOf(allowedNodes)
                })
            })

        then(executionContextManager).should().awaitExecution(reasonId)
    }
}
