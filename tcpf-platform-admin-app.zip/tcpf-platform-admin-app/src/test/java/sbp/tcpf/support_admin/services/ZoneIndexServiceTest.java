package sbp.tcpf.support_admin.services;

import sbp.tcpf.routing.index.info.dto.RoutingIndexInfoRs;
import sbp.tcpf.routing.index.info.dto.State;
import sbp.tcpf.routing.index.manage.dto.RoutingIndexManageRs;
import sbp.tcpf.routing.index.manage.dto.StatusType;
import sbp.tcpf.support_admin.clients.grpc.ZoneIndexGrpcRequestExecutor;
import sbp.tcpf.support_admin.configs.properties.ZoneIndexAppProperties;
import sbp.tcpf.support_admin.mappers.ActionResponseMapperImpl;
import sbp.tcpf.support_admin.mappers.ClusterInfoMapperImpl;
import sbp.tcpf.support_admin.model.ActionRequest;
import sbp.tcpf.support_admin.model.ClusterInfo;
import sbp.tcpf.support_admin.model.ClusterState;
import sbp.tcpf.support_admin.model.IndexActionResponse;
import sbp.tcpf.support_admin.model.IndexActions;
import sbp.tcpf.support_admin.model.StartActionWithIndexesRq;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@SpringBootTest(classes = {
        ZoneIndexService.class,
        ClusterInfoMapperImpl.class,
        ActionResponseMapperImpl.class
})
class ZoneIndexServiceTest {
    private static final String CLUSTER_ID = "IDX_1";
    private static final int SUCCESS_CODE = 0;
    private static final String SUCCESS_MESSAGE = "Success";
    private static final long INDEXES_COUNT = 100L;

    @MockitoBean
    private ZoneIndexGrpcRequestExecutor zoneIndexGrpcRequestExecutor;
    @MockitoBean
    private ZoneIndexAppProperties zoneIndexAppProperties;
    @Autowired
    private ZoneIndexService zoneIndexService;

    private static RoutingIndexInfoRs getClusterInfo() {
        return RoutingIndexInfoRs
                .newBuilder()
                .addAllClusterDetails(
                        Collections.singletonList(sbp.tcpf.routing.index.info.dto.ClusterDetails.newBuilder()
                                .setClusterId(CLUSTER_ID)
                                .setEntriesCount(INDEXES_COUNT)
                                .setState(State.ACTIVE)
                                .addAllAvailableActions(
                                        Collections.singletonList(sbp.tcpf.routing.index.info.dto.Action.DEACTIVATE)
                                )
                                .build()
                        )
                )
                .build();
    }

    private static RoutingIndexManageRs getRoutingIndexManageRs() {
        return RoutingIndexManageRs.newBuilder()
                .setStatus(StatusType.newBuilder()
                        .setCode(SUCCESS_CODE)
                        .setDescription(SUCCESS_MESSAGE)
                        .build())
                .build();
    }

    @Test
    void getClusterInfoSuccessTest() throws Exception {
        when(zoneIndexGrpcRequestExecutor.getClusterInfo()).thenReturn(getClusterInfo());

        final List<ClusterInfo> response = zoneIndexService.getClusterInfo();

        assertNotNull(response);
        assertEquals(getClusterInfo().getClusterDetailsList().size(), response.size());
        assertEquals(getClusterInfo().getClusterDetails(0).getClusterId(), response.get(0).getClusterId());
        assertEquals(IndexActions.valueOf(getClusterInfo().getClusterDetails(0).getAvailableActions(0).name()), response.get(0).getAvailableActions());
        assertEquals(ClusterState.valueOf(getClusterInfo().getClusterDetails(0).getState().name()), response.get(0).getState());
        assertEquals(getClusterInfo().getClusterDetails(0).getEntriesCount(), response.get(0).getIndexesCount());

        verify(zoneIndexGrpcRequestExecutor, times(1)).getClusterInfo();
    }

    @Test
    void getResultOfActionWithIndexesSuccessTest() throws Exception {
        when(zoneIndexGrpcRequestExecutor.doActionForCluster(any())).thenReturn(getRoutingIndexManageRs());

        var request = StartActionWithIndexesRq.builder()
                .rqUid(UUID.randomUUID().toString())
                .rqTm(LocalDateTime.now())
                .actionRequest(ActionRequest.builder()
                        .clusterId(CLUSTER_ID)
                        .action(IndexActions.CREATE_INDEX)
                        .build())
                .build();

        IndexActionResponse response = zoneIndexService.manageIndexes(request);

        assertNotNull(response);
        assertEquals(SUCCESS_CODE, response.getCode());
        assertEquals(SUCCESS_MESSAGE, response.getDescription());
        verify(zoneIndexGrpcRequestExecutor, times(1)).doActionForCluster(any());
    }

}
