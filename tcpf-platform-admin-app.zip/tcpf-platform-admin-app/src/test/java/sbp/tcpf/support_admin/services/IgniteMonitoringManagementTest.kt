package sbp.tcpf.support_admin.services

import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.params.ParameterizedTest
import org.junit.jupiter.params.provider.EnumSource
import org.mockito.kotlin.given
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.http.ResponseEntity
import org.springframework.test.context.bean.override.mockito.MockitoBean
import reactor.core.publisher.Flux
import sbp.tcpf.support_admin.clients.feign.routing.RoutingMonitoringManagementApiClient
import sbp.tcpf.support_admin.clients.feign.zone_index.ZoneIndexMonitoringManagementApi
import sbp.tcpf.support_admin.mappers.MonitoringMapperImpl
import sbp.tcpf.support_admin.model.IgniteType
import sbp.tcpf.support_admin.services.monitoring.IgniteMonitoringManagement
import sbp.tcpf.support_admin.services.monitoring.impl.IgniteMonitoringManagementImpl
import sbp.tcpf.support_admin.services.monitoring.impl.IndexIgniteMonitoringSource
import sbp.tcpf.support_admin.services.monitoring.impl.SemaphoreIgniteMonitoringSource
import sbp.tcpf.support_admin.utils.assertThatIterable
import java.util.function.Function
import sbp.tcpf.routing.api.v1_0.client.model.Monitoring as RoutingMonitoring
import sbp.tcpf.routing.api.v1_0.client.model.MonitoringState as RoutingMonitoringState
import sbp.tcpf.routing.index.api.v1_0.client.model.Monitoring as ZoneMonitoring
import sbp.tcpf.routing.index.api.v1_0.client.model.MonitoringState as ZoneMonitoringState

@SpringBootTest(
        classes = [
            IgniteMonitoringManagementImpl::class,
            IndexIgniteMonitoringSource::class,
            SemaphoreIgniteMonitoringSource::class,
            MonitoringMapperImpl::class,
        ]
)
class IgniteMonitoringManagementTest {

    @MockitoBean
    lateinit var zoneIndexMonitoringManagementApi: ZoneIndexMonitoringManagementApi

    @MockitoBean
    lateinit var routingMonitoringManagementApiClient: RoutingMonitoringManagementApiClient

    @Autowired
    lateinit var igniteMonitoringManagement: IgniteMonitoringManagement

    companion object {
        const val IDX_ID = "IDX_1"
        const val SEM_ID = "SEM_1"
    }

    @BeforeEach
    fun setUp() {
        // zone-index клиент остался блокирующим
        given { zoneIndexMonitoringManagementApi.igniteMonitorings }.willReturn(
                ResponseEntity.ok(
                        listOf(ZoneMonitoring(IDX_ID, ZoneMonitoringState.UP))
                )
        )
        // routing-клиент переведён на reactive-feign и отдаёт Flux
        given { routingMonitoringManagementApiClient.getIgniteMonitorings() }.willReturn(
                Flux.just(RoutingMonitoring(SEM_ID, RoutingMonitoringState.UP, null, null))
        )
    }

    @Test
    fun `should return all monitoring`() {
        val result = igniteMonitoringManagement.monitoringInfo
            .collectList()
            .block()
            .orEmpty()

        assertThat(result).isNotEmpty
            .extracting(Function { it.id })
            .contains(IDX_ID, SEM_ID)
    }

    @ParameterizedTest
    @EnumSource(value = IgniteType::class, names = ["ALL"], mode = EnumSource.Mode.EXCLUDE)
    fun `should return monitoring by type`(type: IgniteType) {
        val result = igniteMonitoringManagement.getMonitoringByType(type)
            .collectList()
            .block()
            .orEmpty()

        assertThat(result).isNotEmpty

        val ids = result.map { it.id }

        assertThatIterable(ids).containsOnlyOneOf(IDX_ID, SEM_ID)
    }
}
