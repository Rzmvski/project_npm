package sbp.tcpf.support_admin.config;

import com.sbt.audit.core.model.v2.event.Event;
import org.springframework.context.event.EventListener;

public class NoOpEventListener {

    @EventListener
    public void listen(Event event) {
    }
}
