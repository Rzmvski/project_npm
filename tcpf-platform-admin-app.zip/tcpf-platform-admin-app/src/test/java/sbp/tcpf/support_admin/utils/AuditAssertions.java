package sbp.tcpf.support_admin.utils;

import com.sbt.audit.core.model.v2.event.Event;
import com.sbt.audit.core.model.v2.event.EventParam;
import org.apache.commons.lang3.tuple.Pair;
import org.assertj.core.api.Assertions;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import static org.assertj.core.api.BDDAssertions.then;

public class AuditAssertions extends Assertions {

    @Data(staticConstructor = "of")
    @Accessors(fluent = true)
    public static class EventExpectations {
        String eventName;
        List<Pair<String, Consumer<String>>> paramsAsserts;
    }

    public static void thenEventSatisfies(Event event, EventExpectations expectations) {
        then(event.getName()).isEqualTo(expectations.eventName());

        var params = event.getParams().stream()
                .filter(param -> param.getValue() != null)
                .collect(Collectors.toMap(EventParam::getName, EventParam::getValue));

        then(expectations.paramsAsserts()).allSatisfy(assertion -> {
            var paramValue = params.get(assertion.getLeft());
            assertion.getRight().accept(paramValue);
        });
    }
}
