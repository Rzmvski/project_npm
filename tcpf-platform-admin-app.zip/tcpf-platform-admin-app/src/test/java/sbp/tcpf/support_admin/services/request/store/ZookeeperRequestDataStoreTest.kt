package sbp.tcpf.support_admin.services.request.store

import com.fasterxml.jackson.databind.ObjectMapper
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.mockito.ArgumentCaptor
import org.mockito.Captor
import org.mockito.kotlin.capture
import org.mockito.kotlin.verify
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest
import org.springframework.context.annotation.Import
import org.springframework.security.test.context.support.WithUserDetails
import org.springframework.test.context.TestPropertySource
import org.springframework.test.context.bean.override.mockito.MockitoSpyBean
import sbp.tcpf.support_admin.config.CuratorTestConfig
import sbp.tcpf.support_admin.config.SecurityTestConfig
import sbp.tcpf.support_admin.config.SecurityTestConfig.FIRST_ADMIN
import sbp.tcpf.support_admin.config.UOWTestConfig
import sbp.tcpf.support_admin.configs.RequestServiceConfig
import sbp.tcpf.support_admin.configs.properties.CuratorLockProperties
import sbp.tcpf.support_admin.configs.properties.ResolveRequestServiceProperties
import sbp.tcpf.support_admin.configs.properties.ScriptServiceProperties
import sbp.tcpf.support_admin.dto.ScriptApplicationDto
import sbp.tcpf.support_admin.entities.AbstractRequest
import sbp.tcpf.support_admin.entities.ScriptRequest
import sbp.tcpf.support_admin.mappers.RequestStatusMapperImpl
import sbp.tcpf.support_admin.mappers.ScriptDbEntityMapperImpl
import sbp.tcpf.support_admin.mappers.ScriptZkEntityMapperImpl
import sbp.tcpf.support_admin.mappers.ShardMapperImpl
import sbp.tcpf.support_admin.model.ApplicationStatus
import sbp.tcpf.support_admin.repositories.RequestRepository
import sbp.tcpf.support_admin.repositories.impl.ZkRequestRepository
import sbp.tcpf.support_admin.services.lock.CuratorLockManager
import sbp.tcpf.support_admin.services.lock.LockRegistry
import sbp.tcpf.support_admin.services.request.RequestCryptoService
import sbp.tcpf.support_admin.services.request.cache.RequestCuratorCacheManager
import sbp.tcpf.support_admin.services.request.dto.ScriptKey
import sbp.tcpf.support_admin.services.request.store.aggregators.ScriptDataAggregator
import sbp.tcpf.support_admin.services.request.store.modifiers.ScriptContentModifier
import sbp.tcpf.support_admin.services.request.store.modifiers.ShardIdModifier
import sbp.tcpf.support_admin.utils.asserts.assertScriptApplication
import sbp.tcpf.support_admin.utils.asserts.assertZkRequestEntity

@TestPropertySource(
        properties = ["tcpf-platform-admin-app.resolve-request-service.db-persist=false"]
)
@WithUserDetails(FIRST_ADMIN)
@DataJpaTest
@EnableConfigurationProperties(
        ScriptServiceProperties::class,
        ResolveRequestServiceProperties::class,
        CuratorLockProperties::class,
)
@Import(
        RequestServiceConfig::class,
        ScriptDataAggregator::class,
        ScriptDbEntityMapperImpl::class,
        ScriptContentModifier::class,
        ShardIdModifier::class,
        ShardMapperImpl::class,
        RequestStatusMapperImpl::class,
        CuratorLockManager::class,
        LockRegistry::class,
        ZkRequestRepository::class,
        RequestCryptoService::class,
        RequestCuratorCacheManager::class,
        ScriptZkEntityMapperImpl::class,
        UOWTestConfig::class,
        SecurityTestConfig::class,
        CuratorTestConfig::class,
)
class ZookeeperRequestDataStoreTest {

    @MockitoSpyBean
    lateinit var zkRepository: RequestRepository<AbstractRequest, String, Class<AbstractRequest>>

    @Captor
    lateinit var zkRequestEntityCaptor: ArgumentCaptor<ScriptRequest>

    @Autowired
    lateinit var objectMapper: ObjectMapper

    @Autowired
    lateinit var zkStore: RequestDataStore<ScriptApplicationDto, String, ScriptKey, ScriptRequest>

    private val reasonId = "reason-123"
    private val scriptBody = "hello world"
    private val dto = ScriptApplicationDto(
            createdBy = "creator",
            location = ScriptKey(reasonId),
            jiraId = "JIRA-1",
            scriptBody = scriptBody,
            status = ApplicationStatus.PENDING,
    )

    @Test
    fun `should save in zookeeper store`() {
        val savedApplication = zkStore.save(dto)
        val scriptContent = scriptBody.toByteArray()

        assertScriptApplication(savedApplication)
            .hasLocation(scriptId = reasonId)
            .hasCreator(dto.createdBy)
            .hasStatus(ApplicationStatus.PENDING)
            .satisfies({
                assertThat(it.jiraId).isEqualTo(dto.jiraId)
                assertThat(it.scriptBody).isEqualTo(scriptBody)
            })

        verify(zkRepository).save(capture(zkRequestEntityCaptor))

        assertZkRequestEntity(zkRequestEntityCaptor.value)
            .hasBasicFields(uid = reasonId, content = scriptContent)
            .hasStatus(ApplicationStatus.PENDING)
            .hasCreator(dto.createdBy)
            .hasRestrictions(dto.restrictions)
            .satisfies({
                assertThat(it.dbRef).isNull()
            })
    }
}
