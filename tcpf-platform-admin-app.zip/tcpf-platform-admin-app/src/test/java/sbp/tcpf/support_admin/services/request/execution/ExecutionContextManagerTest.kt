package sbp.tcpf.support_admin.services.request.execution

import org.apache.curator.framework.CuratorFramework
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.context.annotation.Import
import org.springframework.test.context.TestPropertySource
import org.springframework.test.context.bean.override.mockito.MockitoBean
import sbp.tcpf.coordination.config.CuratorFacade.AppCuratorBean
import sbp.tcpf.support_admin.config.CuratorTestConfig
import sbp.tcpf.support_admin.configs.ScriptConfig
import sbp.tcpf.support_admin.configs.properties.ResolveRequestServiceProperties
import sbp.tcpf.support_admin.configs.properties.ScriptServiceProperties
import sbp.tcpf.support_admin.services.request.execution.ExecutionContextManagerTest.Companion.DELAY
import sbp.tcpf.support_admin.services.request.execution.ExecutionContextManagerTest.Companion.TIMEOUT
import sbp.tcpf.support_admin.services.request.store.CompositeScriptDataStore
import sbp.tcpf.support_admin.utils.test
import sbp.tcpf.support_admin.utils.testWithVirtualTime
import java.time.Duration
import java.util.*
import java.util.concurrent.TimeoutException

@TestPropertySource(properties = [
    "tcpf-platform-admin-app.script-service.await-timeout=$TIMEOUT",
    "tcpf-platform-admin-app.script-service.finalize-delay=$DELAY",
])
@EnableConfigurationProperties(
        ScriptServiceProperties::class,
        ResolveRequestServiceProperties::class,
)
@SpringBootTest(
        classes = [
            ExecutionContextManager::class,
            ErrorStatusHandler::class,
        ]
)
@Import(
        CuratorTestConfig::class,
        ScriptConfig::class,
)
class ExecutionContextManagerTest {

    companion object {
        const val TIMEOUT: Long = 1000
        const val DELAY: Long = 1000
    }

    @MockitoBean
    lateinit var dataStore: CompositeScriptDataStore

    @Autowired
    lateinit var registry: ExecutionContextManager

    @Autowired
    @AppCuratorBean
    lateinit var curator: CuratorFramework

    @Test
    fun `should create active execution in registry`() {
        val executionId = UUID.randomUUID().toString()

        registry
            .awaitExecution(executionId)
            .test()
            .then {
                curator
                    .create()
                    .creatingParentContainersIfNeeded()
                    .forPath("/tcpf-script-engine-app/executions/$executionId")
            }
            .expectComplete()
            .verifyThenAssertThat()
            .hasNotDroppedErrors()
    }

    @Test
    fun `should finalize execution when await timeout was expired`() {
        val uid = UUID.randomUUID().toString()
        val timeoutDuration = Duration.ofMillis(TIMEOUT)

        registry.awaitExecution(uid)
            .testWithVirtualTime()
            .thenAwait(timeoutDuration.plusSeconds(1))
            .verifyErrorSatisfies { throwable ->
                assertThat(throwable).isInstanceOf(TimeoutException::class.java)
            }
    }
}
