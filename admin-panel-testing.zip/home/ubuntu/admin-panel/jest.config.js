/** @type {import('ts-jest').JestConfigWithTsJest} */
module.exports = {
  preset: 'ts-jest',
  testEnvironment: 'jsdom',
  moduleFileExtensions: ['ts', 'tsx', 'js', 'jsx', 'json', 'node'],
  
  // Настройка для работы с абсолютными импортами (@/...)
  moduleNameMapper: {
    '^@/(.*)$': '<rootDir>/src/$1',
    // Настройка для CSS Modules
    '\\.(css|less|sass|scss)$': 'identity-obj-proxy',
  },
  
  // Файл для настройки тестовой среды (кастомные ассерты RTL)
  setupFilesAfterEnv: ['<rootDir>/setupTests.ts'],
  
  // Игнорировать директории
  testPathIgnorePatterns: ['/node_modules/', '/dist/'],
  
  // Настройка для ts-jest
  transform: {
    '^.+\\.(ts|tsx)$': [
      'ts-jest',
      {
        tsconfig: 'tsconfig.json',
      },
    ],
  },
};
