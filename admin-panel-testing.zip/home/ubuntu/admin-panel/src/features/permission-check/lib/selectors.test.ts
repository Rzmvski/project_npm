import { Permission, UserRole } from '@/shared/types';
import { SERVICE_REGISTRY } from '@/entities/service';
import { selectVisibleServices } from './selectors';

// Мок RootState
const mockState = {
  user: {
    data: {
      permissions: [
        Permission.PROCESS_GROUPS_VIEW,
        Permission.CONTACT_SEARCH_VIEW,
        Permission.IGNITE_INDEXES_VIEW,
      ],
    },
  },
  serviceConfig: {
    // Имитируем, что только 'process-groups' и 'contact-search' включены через JSON
    data: {
      'process-groups': true,
      'operational-day': false,
      'contact-search': true,
      'ignite-indexes': true,
      'nodes-semaphores': true,
      'groovy-scripts': true,
      'feature-toggling': true,
      'shard-migration': true,
    },
    status: 'succeeded',
    error: null,
  },
};

describe('Permission Check Selectors', () => {
  test('selectVisibleServices should filter by enabled flags and user permissions', () => {
    const visibleServices = selectVisibleServices(mockState as any);

    // Ожидаем, что останутся только те, которые:
    // 1. Включены в mockState.serviceConfig.data (process-groups, contact-search, ignite-indexes, nodes-semaphores, groovy-scripts, feature-toggling, shard-migration)
    // 2. Есть в mockState.user.data.permissions (process-groups, contact-search, ignite-indexes)
    // 3. Отсортированы по order

    const expectedIds = [
      'process-groups', // order 1, enabled: true, has permission
      'contact-search', // order 3, enabled: true, has permission
      'ignite-indexes', // order 4, enabled: true, has permission
    ];

    expect(visibleServices.map(s => s.id)).toEqual(expectedIds);
  });

  test('selectVisibleServices should return empty array if no permissions', () => {
    const noPermissionState = {
      ...mockState,
      user: {
        data: {
          permissions: [],
        },
      },
    };

    const visibleServices = selectVisibleServices(noPermissionState as any);
    expect(visibleServices).toEqual([]);
  });

  test('selectVisibleServices should return empty array if all services disabled by config', () => {
    const allDisabledState = {
      ...mockState,
      serviceConfig: {
        data: SERVICE_REGISTRY.reduce((acc, s) => ({ ...acc, [s.id]: false }), {}),
      },
    };

    const visibleServices = selectVisibleServices(allDisabledState as any);
    expect(visibleServices).toEqual([]);
  });
});
