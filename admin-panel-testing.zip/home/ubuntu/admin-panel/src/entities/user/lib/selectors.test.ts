import { UserRole, Permission } from '@/shared/types';
import {
  selectUser,
  selectIsAdmin,
  selectUserPermissions,
  selectIsAuthenticated,
} from './selectors';

// Мок RootState
const mockState = {
  user: {
    data: {
      id: '123',
      username: 'testuser',
      email: 'test@example.com',
      roles: [UserRole.USER, UserRole.ADMIN],
      permissions: [Permission.PROCESS_GROUPS_VIEW, Permission.CONTACT_SEARCH_VIEW],
      firstName: 'Test',
      lastName: 'User',
      token: 'token123',
    },
    status: 'succeeded',
    error: null,
    isAuthenticated: true,
  },
  // Другие слайсы
  serviceConfig: {},
};

describe('User Selectors', () => {
  test('selectUser should return user data', () => {
    expect(selectUser(mockState as any)).toEqual(mockState.user.data);
  });

  test('selectIsAuthenticated should return true', () => {
    expect(selectIsAuthenticated(mockState as any)).toBe(true);
  });

  test('selectUserPermissions should return user permissions', () => {
    expect(selectUserPermissions(mockState as any)).toEqual([
      Permission.PROCESS_GROUPS_VIEW,
      Permission.CONTACT_SEARCH_VIEW,
    ]);
  });

  test('selectIsAdmin should return true if user has ADMIN role', () => {
    expect(selectIsAdmin(mockState as any)).toBe(true);
  });

  test('selectIsAdmin should return false if user does not have ADMIN role', () => {
    const nonAdminState = {
      ...mockState,
      user: {
        ...mockState.user,
        data: {
          ...mockState.user.data,
          roles: [UserRole.USER],
        },
      },
    };
    expect(selectIsAdmin(nonAdminState as any)).toBe(false);
  });
});
