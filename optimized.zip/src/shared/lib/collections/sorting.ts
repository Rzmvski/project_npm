/**
 * Стандартная быстрая сортировка
 */
export const standardSorting = <T>(a: T, b: T): number => (a > b ? 1 : a < b ? -1 : 0)
