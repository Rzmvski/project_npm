#!/usr/bin/env node

import { execSync } from 'child_process'
import { readFileSync, existsSync } from 'fs'
import { homedir } from 'os'
import { join } from 'path'
import { question } from 'readline-sync'

const REGISTRY = 'https://nexus-ci.delta.sbrf.ru/repository/npm-all/'
const REGISTRY_KEY = '//nexus-ci.delta.sbrf.ru/repository/npm-all/:_auth'

console.log('🚀 Project setup\n')

// ── 1. pnpm / npm ───────────────────────────────────────────────────
try {
  execSync('pnpm --version', { stdio: 'pipe' })
} catch {
  console.log('📦 Installing pnpm via npm...\n')
  try {
    execSync(`npm install -g pnpm@latest --registry=${REGISTRY}`, { stdio: 'inherit' })
  } catch {
    console.error('❌ Failed to install pnpm via npm.')
    console.log('   Please run manually:\n')
    console.log(`     npm install -g pnpm@latest --registry=${REGISTRY}\n`)
    process.exit(1)
  }
}

// ── 2. Токен nexus-ci в ~/.npmrc ──────────────────────────────────────
const homeNpmrc = join(homedir(), '.npmrc')

function ensureToken() {
  // 1) Из env
  if (process.env.NPM_NEXUS_AUTH && process.env.NPM_NEXUS_AUTH.trim()) {
    return process.env.NPM_NEXUS_AUTH.trim()
  }
  // 2) Уже записан в ~/.npmrc
  if (existsSync(homeNpmrc)) {
    const existing = readFileSync(homeNpmrc, 'utf-8')
    if (existing.includes(REGISTRY_KEY)) {
      const m = existing.match(new RegExp(`^${REGISTRY_KEY}\\s*=\\s*["']?([^"'\n]+)`, 'm'))
      if (m && m[1]) return null // уже настроен — ничего не делаем
    }
  }
  // 3) Интерактивно (скрытый ввод пароля, кроссплатформенно)
  console.log('🔐 Nexus credentials required.')
  const u = question('Nexus username: ').trim()
  const p = question('Nexus password: ', { hideEchoBack: true }).trim()
  if (!u || !p) {
    console.error('\n❌ Username and password are required.')
    process.exit(1)
  }
  return Buffer.from(`${u}:${p}`).toString('base64')
}

const token = ensureToken()
if (token) {
  execSync(`npm config set '${REGISTRY_KEY}' '${token}' --location=user`, { stdio: 'inherit' })
  console.log(`✅ Nexus token written to ${homeNpmrc}\n`)
} else {
  console.log(`✅ Nexus token already configured in ${homeNpmrc}\n`)
}

// ── 3. Установка зависимостей ──────────────────────────────────────────
console.log('📦 Installing dependencies with pnpm...\n')
try {
  execSync('pnpm install --frozen-lockfile --ignore-scripts', { stdio: 'inherit' })
  console.log('\n✅ Setup complete! You can start the dev server with: pnpm run dev')
} catch (err) {
  console.error('\n❌ Failed to install dependencies:', err.message)
  process.exit(1)
}
