# Аудит TS/JS

Синтаксически проверено файлов: 1370.
Найдено: 304 any и 87 приведений к never в 149 файлах.
Это полный проход по перечисленным TS/JS-файлам на две запрещённые конструкции; он не заменяет ручную проверку поведения.

## Настройки
- tsconfig.app.json: strict и noImplicitAny не включены.
- eslint.config.mjs:163: no-explicit-any отключён для тестов.
- Приведения к never отдельно не запрещены правилами ESLint.

## Все подтверждённые вхождения

### src/entities/application/lib/__tests__/useApplications.test.ts

- Строка 4: any
- Строка 6: any

### src/entities/bean/lib/__tests__/useBeans.test.ts

- Строка 4: any
- Строка 6: any

### src/entities/connection-pool/lib/__tests__/usePools.test.ts

- Строка 6: any
- Строка 10: any

### src/entities/data-center/lib/__tests__/useDataCenters.test.ts

- Строка 5: any
- Строка 9: any

### src/entities/dictionary/lib/__tests__/useDictionaries.test.ts

- Строка 4: any
- Строка 6: any
- Строка 13: any

### src/entities/feature/lib/__tests__/useFeatureColumns.test.tsx

- Строка 35: never-cast

### src/entities/feature/lib/__tests__/useFeatures.test.ts

- Строка 12: any
- Строка 17: any

### src/entities/feature-application/api/__tests__/fetch.test.ts

- Строка 39: never-cast

### src/entities/feature-application/lib/__tests__/useFeatureApplicationColumns.test.tsx

- Строка 33: never-cast

### src/entities/feature-application/lib/__tests__/useFeatureResolve.test.tsx

- Строка 28: never-cast
- Строка 71: never-cast

### src/entities/index-cluster/lib/__tests__/useIndexClusters.test.ts

- Строка 7: any
- Строка 11: any

### src/entities/monitoring/lib/__tests__/useMonitoring.test.ts

- Строка 10: any
- Строка 14: any

### src/entities/node/lib/__tests__/useNodes.test.ts

- Строка 6: any
- Строка 11: any

### src/entities/operation-day/lib/__tests__/useOperationDay.test.ts

- Строка 4: any
- Строка 6: any

### src/entities/process/lib/__tests__/useActiveProcesses.test.ts

- Строка 6: any
- Строка 7: any
- Строка 8: any
- Строка 13: any
- Строка 17: any
- Строка 21: any
- Строка 34: any

### src/entities/process/lib/__tests__/useProcessColumns.test.ts

- Строка 18: never-cast

### src/entities/process-group/lib/__tests__/useProcessGroups.test.ts

- Строка 4: any
- Строка 6: any

### src/entities/process-history/lib/__tests__/useProcessHistoryColumns.test.ts

- Строка 18: never-cast

### src/entities/region/lib/__tests__/useRegionMutations.test.ts

- Строка 18: any

### src/entities/region/lib/__tests__/useRegions.test.ts

- Строка 13: any
- Строка 20: any
- Строка 30: any
- Строка 47: any
- Строка 64: any

### src/entities/revision/config/__tests__/statusConfig.test.tsx

- Строка 20: never-cast

### src/entities/revision/lib/__tests__/useRevisionColumns.test.tsx

- Строка 19: never-cast

### src/entities/revision/lib/__tests__/useRevisionDetails.test.ts

- Строка 6: any
- Строка 11: any
- Строка 13: any
- Строка 15: any

### src/entities/revision/lib/__tests__/useRevisionDetailsColumns.test.tsx

- Строка 19: never-cast

### src/entities/revision/lib/__tests__/useRevisions.test.ts

- Строка 6: any
- Строка 11: any
- Строка 13: any

### src/entities/revision-history/lib/__tests__/useRevisionHistoryFilter.test.ts

- Строка 11: any
- Строка 28: any

### src/entities/revision-history/ui/RevisionHistoryFilter/__tests__/RevisionHistoryFilter.test.tsx

- Строка 24: any
- Строка 35: any
- Строка 46: any
- Строка 56: any
- Строка 58: any

### src/entities/revision-report/lib/__tests__/useLoadRevisionReport.test.ts

- Строка 6: any
- Строка 8: any
- Строка 12: any
- Строка 15: any
- Строка 17: any
- Строка 18: any

### src/entities/revision-shard/lib/__tests__/useRevisionShards.test.ts

- Строка 4: any
- Строка 6: any

### src/entities/routing-shard/api/__tests__/fetchAvailableShards.test.ts

- Строка 5: never-cast
- Строка 14: never-cast
- Строка 23: never-cast

### src/entities/routing-shard/lib/__tests__/useAvailableShards.test.ts

- Строка 6: any
- Строка 10: any

### src/entities/routing-shard/ui/NodeSelector/__tests__/NodeSelector.test-model.tsx

- Строка 13: never-cast

### src/entities/routing-shard/ui/NodeSelector/__tests__/NodeSelector.test.tsx

- Строка 20: any
- Строка 35: any
- Строка 42: any
- Строка 49: any
- Строка 51: any

### src/entities/script-request/lib/__tests__/useScriptLogs.test.ts

- Строка 5: any
- Строка 7: any
- Строка 9: any
- Строка 11: any

### src/entities/script-request/lib/__tests__/useScriptRequests.test.ts

- Строка 4: any
- Строка 6: any

### src/entities/script-request/lib/__tests__/useUpdatableScriptRequests.test.ts

- Строка 8: any
- Строка 19: any

### src/entities/script-template/lib/__tests__/useTemplates.test.ts

- Строка 4: any
- Строка 6: any

### src/entities/script-template/ui/TemplateExplorer/__tests__/TemplateExplorer.test.tsx

- Строка 51: any
- Строка 52: any
- Строка 56: any
- Строка 64: any
- Строка 65: any
- Строка 72: any
- Строка 75: any
- Строка 79: any
- Строка 83: any

### src/entities/script-template/ui/TemplateInfo/__tests__/TemplateInfo.test-model.tsx

- Строка 6: any
- Строка 7: never-cast

### src/entities/script-template/ui/TreeItem/__tests__/TreeItem.test-model.tsx

- Строка 6: any
- Строка 19: never-cast

### src/entities/semaphore/lib/__tests__/useSemaphores.test.ts

- Строка 5: any
- Строка 9: any

### src/entities/traffic-restriction/lib/__tests__/useTrafficRestrictions.test.ts

- Строка 6: any
- Строка 10: any

### src/entities/traffic-restriction/ui/PartitionSelector/__tests__/PartitionSelector.test.tsx

- Строка 7: any

### src/entities/traffic-restriction/ui/RestrictionTooltip/__tests__/RestrictionTooltip.test.tsx

- Строка 8: any

### src/entities/traffic-restriction/ui/TrafficRestrictionViewer/__tests__/TrafficRestrictionViewer.test.tsx

- Строка 6: any
- Строка 11: any

### src/entities/transfer-history/lib/__tests__/useTransferHistoryColumns.test.ts

- Строка 22: never-cast

### src/features/beans-introspection/lib/__tests__/useBeanIntrospection.test.ts

- Строка 9: any
- Строка 16: any
- Строка 26: any
- Строка 65: never-cast
- Строка 81: never-cast
- Строка 95: never-cast
- Строка 111: never-cast
- Строка 118: never-cast

### src/features/beans-introspection/lib/useBeanIntrospection.ts

- Строка 55: any

### src/features/build-restriction-graph/lib/__tests__/useGraph.test.ts

- Строка 7: any
- Строка 22: never-cast

### src/features/build-restriction-graph/lib/__tests__/useGraphEdges.test.ts

- Строка 6: never-cast

### src/features/build-restriction-matrix/lib/__tests__/useMatrix.test.tsx

- Строка 18: any
- Строка 39: any
- Строка 42: any
- Строка 54: any

### src/features/change-range/api/__tests__/fetch.test.ts

- Строка 12: never-cast

### src/features/change-range/lib/__tests__/useChangeRangesMutation.test.ts

- Строка 6: any
- Строка 13: any
- Строка 17: any
- Строка 24: never-cast

### src/features/change-range/ui/RangeEditor/__tests__/RangeEditor.test-model.tsx

- Строка 17: never-cast
- Строка 19: never-cast
- Строка 29: never-cast

### src/features/change-range/ui/RangeEditor/__tests__/RangeEditor.test.tsx

- Строка 10: any
- Строка 14: any
- Строка 28: any
- Строка 31: any
- Строка 31: any
- Строка 34: any
- Строка 50: any
- Строка 60: any
- Строка 63: any
- Строка 66: any

### src/features/change-semaphore-state/api/__tests__/fetchChangeSemaphoreState.test.ts

- Строка 11: never-cast

### src/features/change-semaphore-state/lib/__tests__/useSemaphoreColumns.test.tsx

- Строка 15: never-cast

### src/features/change-semaphore-state/lib/__tests__/useSemaphoreDetails.test.ts

- Строка 7: any
- Строка 12: any
- Строка 18: any
- Строка 27: any

### src/features/change-semaphore-state/lib/__tests__/useSemaphoreStateMutation.test.ts

- Строка 6: any
- Строка 8: any
- Строка 12: any

### src/features/change-shard-boundary/lib/__tests__/calculateBoundary.test.ts

- Строка 7: never-cast
- Строка 13: never-cast
- Строка 19: never-cast

### src/features/change-shard-boundary/lib/__tests__/useChangeNodeBoundaryMutation.test.ts

- Строка 6: any
- Строка 14: any
- Строка 18: any

### src/features/change-shard-boundary/ui/LoadSlider/__tests__/LoadSlider.test.tsx

- Строка 6: any
- Строка 15: any

### src/features/clear-transfer-task/api/__tests__/fetch.test.ts

- Строка 9: never-cast

### src/features/clear-transfer-task/ui/__tests__/ClearTransferTaskForm.test.tsx

- Строка 21: any
- Строка 32: any
- Строка 43: any
- Строка 49: any
- Строка 63: any
- Строка 71: any
- Строка 75: any

### src/features/create-transfer-task/api/__tests__/fetch.test.ts

- Строка 10: never-cast
- Строка 29: never-cast

### src/features/create-transfer-task/lib/__tests__/useDisabledSteps.test.ts

- Строка 6: never-cast
- Строка 37: never-cast

### src/features/create-transfer-task/ui/Steps/__tests__/Steps.test.tsx

- Строка 22: any
- Строка 34: any
- Строка 48: any
- Строка 56: any
- Строка 67: any
- Строка 70: any
- Строка 72: any

### src/features/filter-feature-applications/ui/FeatureApplicationsFilters/__tests__/FeatureApplicationsFilters.test-model.tsx

- Строка 20: never-cast
- Строка 22: never-cast
- Строка 26: never-cast
- Строка 27: never-cast

### src/features/filter-feature-applications/ui/FeatureApplicationsFilters/__tests__/FeatureApplicationsFilters.test.tsx

- Строка 4: any
- Строка 7: any

### src/features/filter-features/ui/FeatureFilters/__tests__/FeatureFilters.test-model.tsx

- Строка 20: never-cast
- Строка 22: never-cast
- Строка 26: never-cast

### src/features/filter-features/ui/FeatureFilters/__tests__/FeatureFilters.test.tsx

- Строка 4: any
- Строка 7: any

### src/features/filter-restrictions/ui/RestrictionFilters/__tests__/RestrictionFilters.test-model.tsx

- Строка 20: never-cast

### src/features/filter-restrictions/ui/RestrictionFilters/__tests__/RestrictionFilters.test.tsx

- Строка 10: any

### src/features/find-shard-info/ui/__tests__/FindShardInfo.test.tsx

- Строка 9: any
- Строка 23: any

### src/features/import-feature/api/__tests__/fetch.test.ts

- Строка 8: never-cast

### src/features/import-feature/lib/__tests__/useImportFeature.test.tsx

- Строка 21: never-cast

### src/features/import-feature/lib/__tests__/useLoadDumpMutation.test.ts

- Строка 6: any
- Строка 13: any
- Строка 17: any
- Строка 26: never-cast

### src/features/import-feature/ui/FileError/__tests__/FileError.test.tsx

- Строка 24: never-cast

### src/features/import-feature/ui/ImportFeatureModal/__tests__/ImportFeatureModal.test.tsx

- Строка 22: any
- Строка 45: any
- Строка 84: any

### src/features/import-feature/ui/PreviewStep/__tests__/PreviewStep.test-model.tsx

- Строка 8: never-cast

### src/features/import-feature/ui/PreviewStep/__tests__/PreviewStep.test.tsx

- Строка 7: any
- Строка 16: any
- Строка 25: any
- Строка 30: any
- Строка 31: any

### src/features/manage-connection-pool/lib/__tests__/useChangePoolMutation.test.ts

- Строка 6: any
- Строка 13: any
- Строка 17: any
- Строка 25: never-cast

### src/features/manage-features/api/__tests__/fetch.test.ts

- Строка 10: never-cast

### src/features/manage-features/ui/CreateFeatureForm/__tests__/CreateFeatureForm.test.tsx

- Строка 14: any
- Строка 39: any

### src/features/manage-features/ui/DeleteFeatureForm/__tests__/DeleteFeatureForm.test-model.tsx

- Строка 16: never-cast

### src/features/manage-features/ui/DeleteFeatureForm/__tests__/DeleteFeatureForm.test.tsx

- Строка 6: any
- Строка 12: any
- Строка 15: any
- Строка 29: any
- Строка 34: any

### src/features/manage-features/ui/EditFeatureForm/__tests__/EditFeatureForm.test-model.tsx

- Строка 12: any
- Строка 18: never-cast

### src/features/manage-features/ui/EditFeatureForm/__tests__/EditFeatureForm.test.tsx

- Строка 8: any
- Строка 10: any
- Строка 20: any
- Строка 37: any
- Строка 50: any

### src/features/manage-features/ui/MainSection/__tests__/MainSection.test.tsx

- Строка 9: any
- Строка 20: any
- Строка 35: any
- Строка 38: any
- Строка 41: any
- Строка 43: any

### src/features/manage-features/ui/PermissionIdInput/__tests__/PermissionIdInput.test.tsx

- Строка 9: any
- Строка 22: any

### src/features/manage-indexes/lib/__tests__/useIndexActionNotifications.test.ts

- Строка 16: any
- Строка 25: never-cast

### src/features/manage-indexes/lib/__tests__/useManageIndexes.test.ts

- Строка 6: any
- Строка 17: any
- Строка 35: never-cast
- Строка 49: never-cast

### src/features/manage-indexes/ui/__tests__/IndexTable.test.tsx

- Строка 17: any
- Строка 18: any
- Строка 53: any
- Строка 67: any
- Строка 68: any
- Строка 100: any

### src/features/manage-revision/lib/__tests__/useRevisionActions.test.tsx

- Строка 58: never-cast
- Строка 61: never-cast

### src/features/manage-revision/lib/__tests__/useRunRevision.test.ts

- Строка 6: any
- Строка 12: any

### src/features/manage-script-requests/api/__tests__/fetchManageRequest.test.ts

- Строка 8: never-cast

### src/features/manage-script-requests/lib/__tests__/useArchivePartition.test.ts

- Строка 7: never-cast

### src/features/manage-script-requests/lib/__tests__/useChangeRequestStatus.test.ts

- Строка 7: any
- Строка 18: any
- Строка 31: never-cast

### src/features/manage-script-requests/lib/__tests__/useScriptModal.test.tsx

- Строка 13: any
- Строка 25: any
- Строка 29: never-cast

### src/features/manage-script-requests/lib/__tests__/useScriptRequestsColumns.test.tsx

- Строка 15: never-cast

### src/features/manage-script-requests/ui/ManageButtons/__tests__/ManageButtons.test-model.tsx

- Строка 8: never-cast

### src/features/manage-script-requests/ui/ManageButtons/__tests__/ManageButtons.test.tsx

- Строка 27: any
- Строка 33: any

### src/features/manage-script-requests/ui/ScriptViewer/__tests__/ScriptViewer.test-model.tsx

- Строка 10: never-cast

### src/features/manage-script-requests/ui/ScriptViewer/__tests__/ScriptViewer.test.tsx

- Строка 7: any

### src/features/manage-traffic-restriction/lib/__tests__/restrictionMutations.test.ts

- Строка 8: any
- Строка 16: any
- Строка 19: any
- Строка 20: any
- Строка 21: any
- Строка 29: never-cast
- Строка 30: never-cast

### src/features/manage-traffic-restriction/ui/TrafficRestrictionForm/__tests__/TrafficRestrictionForm.test.tsx

- Строка 29: any
- Строка 53: any
- Строка 64: any
- Строка 67: any
- Строка 70: any

### src/features/run-shard-replication/lib/__tests__/useShardReplicationMutation.test.ts

- Строка 9: any
- Строка 16: any
- Строка 19: any
- Строка 20: any

### src/features/start-process-group/api/__tests__/fetch.test.ts

- Строка 10: never-cast

### src/features/start-process-group/ui/ConfirmProcessGroup/__tests__/ConfirmProcessGroup.test.tsx

- Строка 12: any
- Строка 17: any

### src/features/start-process-group/ui/StartProcessGroupForm/__tests__/StartProcessGroupForm.test.tsx

- Строка 12: any
- Строка 19: any

### src/features/start-process-group/ui/StartProcessModal/__tests__/StartProcessModal.test.tsx

- Строка 21: any
- Строка 34: any

### src/features/sync-node-dictionaries/lib/__tests__/useNodeDictionariesMutation.test.ts

- Строка 6: any
- Строка 12: any
- Строка 16: any

### src/features/transfer-clients/api/__tests__/fetch.test.ts

- Строка 7: never-cast

### src/features/transfer-clients/ui/__tests__/TransferClientsForm.test.tsx

- Строка 20: any
- Строка 27: any
- Строка 37: any
- Строка 43: any
- Строка 59: any
- Строка 63: any

### src/pages/cluster-management/ui/NodeManagementTab/__tests__/NodeManagementTab.test.tsx

- Строка 29: any
- Строка 33: any

### src/pages/geo-balancing/ui/__tests__/GeoBalancingPage.test.tsx

- Строка 19: any
- Строка 25: any
- Строка 35: any
- Строка 50: any
- Строка 95: any
- Строка 102: any

### src/pages/node-balancing/ui/__tests__/NodeBalancingPage.test.tsx

- Строка 6: any

### src/shared/api/__tests__/apiProxy.test.ts

- Строка 81: any
- Строка 118: any
- Строка 119: any
- Строка 131: any
- Строка 132: any

### src/shared/api/__tests__/services.test.ts

- Строка 187: any
- Строка 214: any
- Строка 215: any
- Строка 222: any
- Строка 223: any

### src/shared/lib/__tests__/useConfirm.test.tsx

- Строка 69: any
- Строка 83: any

### src/shared/lib/__tests__/useSelectAll.test.tsx

- Строка 96: any

### src/shared/lib/__tests__/useTaskColumns.test.tsx

- Строка 32: any

### src/shared/lib/modal/__tests__/useConfirm.test.tsx

- Строка 14: any

### src/shared/lib/modal/__tests__/useInfoModal.test.tsx

- Строка 9: any

### src/shared/lib/modal/__tests__/useModal.test.ts

- Строка 18: never-cast

### src/shared/lib/table/plugins/__tests__/useEmptyState.test.tsx

- Строка 50: never-cast

### src/shared/lib/table/plugins/__tests__/useExpandedRow.test.tsx

- Строка 48: never-cast

### src/shared/lib/table/plugins/__tests__/usePinnedColumns.test.tsx

- Строка 109: never-cast
- Строка 118: never-cast
- Строка 133: never-cast
- Строка 141: never-cast

### src/shared/lib/table/plugins/__tests__/useSorting.test.tsx

- Строка 26: never-cast

### src/shared/lib/table/plugins/__tests__/useStyledRow.test.tsx

- Строка 50: never-cast

### src/shared/lib/table/runtime/__tests__/resolveContributions.test.ts

- Строка 20: never-cast
- Строка 34: never-cast
- Строка 35: never-cast

### src/shared/ui/ServiceTabs/ServiceTabs.tsx

- Строка 58: never-cast
- Строка 72: never-cast

### src/shared/ui/Table/columns/__tests__/ExpandColumn.test.tsx

- Строка 24: any
- Строка 26: any
- Строка 35: any
- Строка 37: any
- Строка 45: any
- Строка 47: any

### src/shared/ui/Tooltip/__tests__/Tooltip.test.tsx

- Строка 7: any

### src/widgets/clear-transfer-task-tab/ui/__tests__/ClearTransferTask.test.tsx

- Строка 20: any
- Строка 45: any

### src/widgets/create-transfer-task-tab/ui/__tests__/CreateTransferTask.test.tsx

- Строка 38: any
- Строка 83: any
- Строка 87: any

### src/widgets/manage-feature-applications-tab/ui/ManageFeatureApplicationsTab/__tests__/ManageFeatureApplicationsTab.test.tsx

- Строка 83: any

### src/widgets/manage-features-tab/ui/ManageFeaturesTab/__tests__/ManageFeaturesTab.test.tsx

- Строка 87: any

### src/widgets/manage-script-requests-tab/ui/__tests__/ManageScriptRequest.test.tsx

- Строка 53: any

### src/widgets/od-history-tab/ui/__tests__/OdHistory.test.tsx

- Строка 10: any
- Строка 29: any
- Строка 41: any
- Строка 47: any

### src/widgets/process-history-tab/ui/__tests__/ProcessHistory.test.tsx

- Строка 10: any
- Строка 32: any
- Строка 47: any
- Строка 53: any

### src/widgets/revision-history-tab/ui/RevisionHistoryTab/__tests__/RevisionHistoryTab.test.tsx

- Строка 19: any
- Строка 34: any
- Строка 44: any
- Строка 50: any
- Строка 65: any
- Строка 66: any
- Строка 86: any

### src/widgets/run-revision-tab/ui/__tests__/RunRevisionTab.test.tsx

- Строка 19: any
- Строка 45: any
- Строка 73: any
- Строка 85: any

### src/widgets/shard-item/ui/LoadTab/__tests__/LoadTab.test.tsx

- Строка 26: any

### src/widgets/shard-item/ui/NodeStatusGrid/__tests__/NodeStatusGrid.test.tsx

- Строка 31: never-cast

### src/widgets/shard-item/ui/RangesTab/__tests__/RangesTab.test.tsx

- Строка 43: any
- Строка 51: any

### src/widgets/start-process-tab/ui/__tests__/StartProcessTab.test.tsx

- Строка 6: any
- Строка 28: any
- Строка 60: any
- Строка 61: any
- Строка 62: any

### src/widgets/transfer-clients-tab/ui/__tests__/TransferClients.test.tsx

- Строка 20: any
- Строка 44: any

### src/widgets/transfer-history-tab/ui/__tests__/TransferHistory.test.tsx

- Строка 16: any
- Строка 32: any
- Строка 35: any
- Строка 53: any
