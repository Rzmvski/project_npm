import { useMemo } from 'react'
import { type FieldNamesMarkedBoolean, type FieldValues } from 'react-hook-form'

import { type StepDef, type StepId } from '@/features/create-transfer-task/config'

export const useDisabledSteps = <T extends FieldValues>(
  dirtyFields: Partial<Readonly<FieldNamesMarkedBoolean<T>>>,
  steps: StepDef<T>[],
) => {
  return useMemo(() => {
    const disabled: Record<string, boolean> = {}
    const stepsById = new Map<StepId, StepDef<T>>()
    for (const step of steps) {
      if (!stepsById.has(step.id)) stepsById.set(step.id, step)
    }

    for (const step of steps) {
      const { dependsOn, id } = step
      if (!dependsOn) {
        disabled[id] = false
        continue
      }

      const prevStep = stepsById.get(dependsOn)
      if (!prevStep) throw new Error(`step ${id} depends on unknown step`)

      // Шаг пройден, когда все его поля изменены пользователем.
      const isCompleted = prevStep.fields.every(
        (field) => !!dirtyFields[field as keyof typeof dirtyFields],
      )
      disabled[id] = !isCompleted
    }
    return disabled as Record<StepId, boolean>
  }, [dirtyFields, steps])
}
