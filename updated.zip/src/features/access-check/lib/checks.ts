import { type PermissionType } from '@/shared/model'

export const hasAuthority = (
  userPermissions: PermissionType[],
  requiredPermission: PermissionType,
): boolean => {
  return userPermissions.includes(requiredPermission)
}

/** Заменяет [].some(x.includes(y)) на Set.has(): O(n) вместо O(n*m). */
export const hasAnyAuthority = (
  userPermissions: PermissionType[],
  requiredPermissions: PermissionType[],
): boolean => {
  // userPermissions — «большой» список (20–100 элементов); requiredPermissions —
  // маленький (1–3). Создаём Set из userPermissions и проверяем .has() за O(1).
  const permSet = new Set(userPermissions)
  return requiredPermissions.some((permission) => permSet.has(permission))
}

/** Заменяет [].every(x.includes(y)) на Set.has(): O(n) вместо O(n*m). */
export const hasAllAuthorities = (
  userPermissions: PermissionType[],
  requiredPermissions: PermissionType[],
): boolean => {
  const permSet = new Set(userPermissions)
  return requiredPermissions.every((permission) => permSet.has(permission))
}

export const hasAuthorityWithSubstring = (userRoles: string[], substring: string): boolean => {
  return userRoles.some((role) => role.includes(substring))
}
