import { type ApplicationStatusDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { useScriptRequests } from '@/entities/script-request'
import { useChangeRequestStatus } from '@/features/manage-script-requests/lib/useChangeRequestStatus'

interface UseManageSelectedRequestsOptions {
  selectedRequestIds: string[]
  removeRowSelection: (id: string) => void
}

export const useManageSelectedRequests = ({
  selectedRequestIds,
  removeRowSelection,
}: UseManageSelectedRequestsOptions) => {
  const { mutate, ...rest } = useChangeRequestStatus()
  const { requests } = useScriptRequests()

  const batchMutate = (targetStatus: ApplicationStatusDto) => {
    const requestsById = new Map(requests.map((request) => [request.reasonId, request]))

    selectedRequestIds.forEach((id) => {
      const application = requestsById.get(id)
      if (!application) return

      mutate({ application, targetStatus })
      const { reasonId } = application
      removeRowSelection(reasonId)
    })
  }

  return {
    ...rest,
    mutate: batchMutate,
  }
}
