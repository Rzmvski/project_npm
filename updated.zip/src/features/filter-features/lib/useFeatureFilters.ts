import { useMemo, useState } from 'react'

import { type Feature, FeatureType, type FeatureView, FeatureStatus } from '@/entities/feature'
import { createObjectMatcher, useOptions, useSearch } from '@/shared/lib'

const typeDictionary: Record<FeatureType, string> = {
  [FeatureType.HotConfig]: 'hot config',
  [FeatureType.Regular]: 'обычный',
}

const matcher = createObjectMatcher<Feature>({
  deep: false,
  caseSensitive: false,
  fields: ['name'],
})

interface UseFeatureFiltersOptions {
  features: FeatureView[]
}

export const useFeatureFilters = ({ features }: UseFeatureFiltersOptions) => {
  const [selectedType, setSelectedType] = useState<Nullable<FeatureType>>(null)
  const [selectedStatus, setSelectedStatus] =
    useState<Nullable<FeatureStatus | 'flipStrat'>>(null)
  const [selectedModule, setSelectedModule] = useState<Nullable<string>>(null)

  const filteredFeatures = useMemo(
    () =>
      features.filter(({ hot, config: { activation }, target: { module } }) => {
        if (selectedType === FeatureType.HotConfig && hot !== true) return false
        if (selectedType === FeatureType.Regular && hot === true) return false
        if (selectedModule && module !== selectedModule) return false

        if (!selectedStatus) return true
        if (activation.type === 'MANUAL') {
          const status = activation.enabled ? FeatureStatus.Active : FeatureStatus.Inactive
          return selectedStatus === status
        }
        return activation.type === 'OD_RELEASE' && selectedStatus === 'flipStrat'
      }),
    [features, selectedModule, selectedStatus, selectedType],
  )

  const {
    result: searchedFeatures,
    searchQuery,
    setSearchQuery,
  } = useSearch({
    items: filteredFeatures,
    searchFn: (items, query) =>
      items.filter((application) => {
        return matcher(application, query)
      }),
  })

  const modules = useMemo(() => {
    return [
      ...new Set(
        features
          .map(({ target: { module } }: Feature) => module)
          .filter((module) => module !== undefined),
      ),
    ]
  }, [features])

  const moduleOptions = useOptions({
    values: [null, ...modules],
    getLabel: (value) => value ?? 'Все',
  })

  const typeOptions = useOptions({
    values: [null, ...Object.values(FeatureType)],
    getLabel: (value) => (value && typeDictionary[value]) ?? 'Все',
  })

  const statusOptions = useOptions({
    values: [null, ...Object.values(FeatureStatus), 'flipStrat'],
    getLabel: (value) => value ?? 'Все',
  })

  return {
    result: searchedFeatures,
    searchQuery,
    setSearchQuery,
    selectedStatus,
    setSelectedStatus,
    selectedType,
    setSelectedType,
    selectedModule,
    setSelectedModule,
    moduleOptions,
    typeOptions,
    statusOptions,
  }
}
