import {
  ApplicationStatusDto,
  FeatureApplicationActionDto,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { useMemo, useState } from 'react'

import { type FeatureApplication } from '@/entities/feature-application'
import { createObjectMatcher, useOptions, useSearch } from '@/shared/lib'

const matcher = createObjectMatcher<FeatureApplication>({
  deep: false,
  caseSensitive: false,
  fields: ['reasonId', 'featureName', 'createdBy', 'resolvedBy'],
})

interface UseFeatureApplicationsFiltersOptions {
  applications: FeatureApplication[]
}

export const useFeatureApplicationsFilters = ({
  applications,
}: UseFeatureApplicationsFiltersOptions) => {
  const [selectedAction, setSelectedAction] =
    useState<Nullable<FeatureApplicationActionDto>>(null)
  const [selectedStatus, setSelectedStatus] = useState<Nullable<ApplicationStatusDto>>(null)
  const [selectedModule, setSelectedModule] = useState<Nullable<string>>(null)

  const filteredApplications = useMemo(
    () =>
      applications.filter(({ action, status, target: { module } }) => {
        if (selectedAction && action !== selectedAction) return false
        if (selectedStatus && status !== selectedStatus) return false
        if (selectedModule && module !== selectedModule) return false
        return true
      }),
    [applications, selectedAction, selectedModule, selectedStatus],
  )

  const modules = useMemo(() => {
    return [
      ...new Set(
        applications
          .map(({ target }) => target.module)
          .filter((module) => module !== undefined),
      ),
    ]
  }, [applications])

  const {
    result: filteredFeatures,
    searchQuery,
    setSearchQuery,
  } = useSearch({
    items: filteredApplications,
    searchFn: (items, query) =>
      items.filter((application) => {
        return matcher(application, query)
      }),
  })

  const moduleOptions = useOptions({
    values: [null, ...modules],
    getLabel: (value) => value ?? 'Все',
  })

  const actionOptions = useOptions({
    values: [null, ...Object.values(FeatureApplicationActionDto)],
    getLabel: (value) => value ?? 'Все',
  })

  const statusOptions = useOptions({
    values: [
      null,
      ApplicationStatusDto.Approved,
      ApplicationStatusDto.Decline,
      ApplicationStatusDto.Pending,
    ],
    getLabel: (value) => value ?? 'Все',
  })

  return {
    result: filteredFeatures,
    searchQuery,
    setSearchQuery,
    selectedStatus,
    setSelectedStatus,
    selectedAction,
    setSelectedAction,
    selectedModule,
    setSelectedModule,
    moduleOptions,
    statusOptions,
    actionOptions,
  }
}
