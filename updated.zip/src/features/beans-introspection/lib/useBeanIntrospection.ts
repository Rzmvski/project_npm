import { type Ace } from 'ace-builds'
import { useCallback, useEffect } from 'react'

import { useBeans } from '@/entities/bean'

export const useBeanIntrospection = (editor: Nullable<Ace.Editor>) => {
  const useBeansResult = useBeans()
  const { data } = useBeansResult

  // Выносим методы за пределы useEffect: они зависят только от data,
  // что предотвращает их пересоздание при каждом рендере.
  const beanCompletions = useCallback(
    (prefix: string): Ace.Completion[] => {
      if (!data) return []
      return data
        .filter(({ name }) => name.startsWith(prefix))
        .map(({ name }) => ({
          caption: name,
          value: name,
          meta: 'bean',
          score: 1000,
        }))
    },
    [data],
  )

  const methodCompletions = useCallback(
    (beanName: string, prefix: string): Ace.Completion[] => {
      const bean = data?.find(({ name }) => name === beanName)
      if (!bean) return []
      const { methods } = bean
      return methods
        .filter(({ name }) => name.startsWith(prefix))
        .map(({ name, parameters }) => ({
          caption: `${name}(${parameters.join(', ')})`,
          value: `${name}(`,
          meta: 'method',
          score: 900,
        }))
    },
    [data],
  )

  const extractBeanName = useCallback((line: string, dotIndex: number): string | undefined => {
    const beanName = line.slice(0, dotIndex).trim().split(/\s+/).pop()
    return beanName
  }, [])

  useEffect(() => {
    if (!editor) return

    // Именованный колбэк для корректной отписки: editor.commands.off()
    // требует ту же функцию-обработчик, что была передана в .on()
    const afterExecListener = ({
      command,
      args,
      editor,
    }: {
      command: { name?: string }
      args: unknown
      editor: Ace.Editor
    }) => {
      if (command.name === 'insertstring' && typeof args === 'string' && args.includes('.')) {
        editor.execCommand('startAutocomplete')
      }
    }

    editor.commands.on('afterExec', afterExecListener)

    const completer: Ace.Completer = {
      getCompletions(
        _editor: Ace.Editor,
        session: Ace.EditSession,
        position: Ace.Point,
        prefix: string,
        callback: Ace.CompleterCallback,
      ) {
        const line = session.getLine(position.row)
        const beforeCursor = line.slice(0, position.column)
        const dotIndex = beforeCursor.lastIndexOf('.')

        if (dotIndex === -1) {
          callback(null, beanCompletions(prefix))
          return
        }

        const beanName = extractBeanName(beforeCursor, dotIndex)
        if (!beanName) {
          callback(null, [])
          return
        }
        const methodPrefix = beforeCursor.slice(dotIndex + 1)
        callback(null, methodCompletions(beanName, methodPrefix))
      },
    }

    editor.completers.push(completer)

    // cleanup: отписка от commands и удаление completer'а при unmount
    return () => {
      editor.commands.off('afterExec', afterExecListener)
      editor.completers = editor.completers.filter((c) => c !== completer)
    }
  }, [data, editor, beanCompletions, methodCompletions, extractBeanName])

  return useBeansResult
}
