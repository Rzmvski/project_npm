import { uniqBy } from 'lodash-es'
import { useMemo } from 'react'

import { getRangeId, type Range, type RangeId } from '@/entities/range'
import { type Semaphore } from '@/entities/semaphore'
import { type ActiveWarning, evaluateWarning } from '@/entities/warning'
import { crossDistributionWarning, type WarningsMap } from '@/features/change-range/model'

/**
 * Объединяет .flatMap().filter() в один проход .reduce(): каждое range вычисляет
 * warning и сразу push в accumulator (если не null), без второго .filter().
 */
const buildWarnings = (ranges: Range[], semaphores: Semaphore[]): ActiveWarning<RangeId>[] =>
  ranges.reduce<ActiveWarning<RangeId>[]>((acc, range) => {
    const { clusterKey, dcKey } = range
    const semaphore = semaphores.find((semaphore) => semaphore.clusterKey === clusterKey)
    const warning = evaluateWarning(crossDistributionWarning, {
      rangeId: getRangeId(range),
      nodeDc: dcKey,
      semaphoreDc: semaphore?.dcKey,
    })
    if (warning !== null) acc.push(warning)
    return acc
  }, [])

export const useRangeWarnings = (ranges: Range[], semaphores: Semaphore[]) => {
  return useMemo(() => {
    const warnings = buildWarnings(ranges, semaphores)

    const warningsMap = warnings.reduce<WarningsMap>((acc, warning) => {
      const { id } = warning
      acc[id] ??= []
      acc[id].push(warning)

      return acc
    }, {})

    return {
      warnings: uniqBy(warnings, ({ type }) => type),
      warningsMap,
    }
  }, [ranges, semaphores])
}
