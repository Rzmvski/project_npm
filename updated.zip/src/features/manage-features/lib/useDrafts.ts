import { FeatureApplicationActionDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { notification } from '@v-uik/base'
import { useCallback, useState } from 'react'

import {
  type Feature,
  type FeatureDraft,
  featuresQueryKey,
  getFeatureKey,
} from '@/entities/feature'
import {
  fetchCreateFeatureRequests,
  featureApplicationQueryKey,
} from '@/entities/feature-application'
import { fetchUpdateHotConfigs } from '@/features/manage-features/api'

interface SubmissionResult {
  successfulDrafts: FeatureDraft[]
  hotConfigsSaved: boolean
  requestsSaved: boolean
}

class DraftSubmissionError extends Error {
  constructor(
    message: string,
    readonly result: SubmissionResult,
  ) {
    super(message)
  }
}

export const useDrafts = () => {
  const [drafts, setDrafts] = useState<FeatureDraft[]>([])
  const queryClient = useQueryClient()

  const addToDrafts = useCallback(
    (feature: Feature, changeType: FeatureApplicationActionDto, permissionId?: string) => {
      setDrafts((prev) => {
        const uid = getFeatureKey(feature)
        const filtered = prev.filter((f) => f.uid !== uid)
        return [
          ...filtered,
          {
            uid,
            feature: { ...feature, uid },
            type: changeType,
            permissionId,
          },
        ]
      })
    },
    [],
  )

  const removeFromDrafts = useCallback((feature: Feature) => {
    setDrafts((prev) => prev.filter((f) => f.uid !== feature.uid))
  }, [])

  const clearDrafts = useCallback(() => setDrafts([]), [])

  const submitMutation = useMutation({
    mutationFn: async () => {
      const submittedDrafts = [...drafts]
      const processedDrafts: Parameters<typeof fetchCreateFeatureRequests>[0] = []
      const hotDrafts: FeatureDraft[] = []
      const requestDrafts: FeatureDraft[] = []

      submittedDrafts.forEach((draft) => {
        const { type, feature, permissionId } = draft
        if (type === FeatureApplicationActionDto.Update && feature.hot) {
          hotDrafts.push(draft)
        } else {
          if (!permissionId) {
            throw Error('Для отправки заявки укажите идентификатор разрешения')
          }
          const { name, target } = feature
          requestDrafts.push(draft)
          processedDrafts.push({
            feature: type === FeatureApplicationActionDto.Delete ? { name, target } : feature,
            requestId: permissionId,
            action: type,
          })
        }
      })

      const [hotResult, requestsResult] = await Promise.allSettled([
        hotDrafts.length
          ? fetchUpdateHotConfigs(hotDrafts.map(({ feature }) => feature))
          : Promise.resolve(),
        processedDrafts.length
          ? fetchCreateFeatureRequests(processedDrafts)
          : Promise.resolve(),
      ])
      const hotConfigsSaved = hotDrafts.length > 0 && hotResult.status === 'fulfilled'
      const requestsSaved = requestDrafts.length > 0 && requestsResult.status === 'fulfilled'
      const result: SubmissionResult = {
        successfulDrafts: [
          ...(hotConfigsSaved ? hotDrafts : []),
          ...(requestsSaved ? requestDrafts : []),
        ],
        hotConfigsSaved,
        requestsSaved,
      }
      const failedGroups = [
        ...(hotResult.status === 'rejected' ? ['горячие конфигурации'] : []),
        ...(requestsResult.status === 'rejected' ? ['заявки на изменение'] : []),
      ]
      if (failedGroups.length) {
        throw new DraftSubmissionError(
          `Не удалось отправить: ${failedGroups.join(', ')}. Неотправленные черновики сохранены — повторите отправку.`,
          result,
        )
      }
      return result
    },
    onSettled: async (data, error) => {
      const result = error instanceof DraftSubmissionError ? error.result : data
      if (!result) {
        if (error) notification.error(error.message)
        return
      }

      const successfulDrafts = new Set(result.successfulDrafts)
      setDrafts((current) => current.filter((draft) => !successfulDrafts.has(draft)))
      await Promise.all([
        ...(result.hotConfigsSaved
          ? [queryClient.invalidateQueries({ queryKey: featuresQueryKey })]
          : []),
        ...(result.requestsSaved
          ? [queryClient.invalidateQueries({ queryKey: featureApplicationQueryKey })]
          : []),
      ])
      if (error) {
        notification.error(error.message)
      } else {
        notification.success('Изменения успешно отправлены на сервер', {
          direction: 'vertical',
        })
      }
    },
  })

  return {
    drafts,
    addToDrafts,
    removeFromDrafts,
    clearDrafts,
    submit: submitMutation.mutate,
    isSending: submitMutation.isPending,
  }
}
