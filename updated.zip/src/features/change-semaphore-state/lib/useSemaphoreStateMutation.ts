import { type ClusterStateDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { type QueryClient, useMutation, useQueryClient } from '@tanstack/react-query'
import { notification } from '@v-uik/base'

import { fetchChangeSemaphoreState } from '@/features/change-semaphore-state/api'
import { type ActionFormValues } from '@/features/change-semaphore-state/model'

interface StateMutationOptions {
  targetState: ClusterStateDto
  additionalOptions?: ActionFormValues
}

/**
 * Мутация изменения статуса семафора с инвалидацией кэша после успешного
 * выполнения: без неё UI не обновляет список семафоров и показывает устаревший
 * статус до следующего ручного refetch.
 */
export const useSemaphoreStateMutation = (clusterKey: string) => {
  const client = useQueryClient()
  return useMutation({
    mutationFn: ({ targetState, additionalOptions }: StateMutationOptions) =>
      fetchChangeSemaphoreState(clusterKey, targetState, additionalOptions),
    onSuccess: () => {
      notification.success(`Изменение статуса семафора ${clusterKey} выполнено успешно`)
      return client.invalidateQueries({ queryKey: ['semaphores'] })
    },
  })
}
