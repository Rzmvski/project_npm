import { type Ace, Range } from 'ace-builds'
import classNames from 'classnames'
import { type MutableRefObject, useCallback, useEffect, useState } from 'react'

import { type Placeholder, usePlaceholders } from '@/entities/script-placeholder'

const BRACKET_AMOUNT = 4

interface UseHighlightEditorParams {
  editorRef: MutableRefObject<Nullable<Ace.Editor>>
  scriptValue: string
}

/**
 * Вынесена за пределы useHighlightEditor как чистая модульная функция.
 * getRange вызывается в каждом рендере внутри updateMarkers: пересоздание
 * Range при каждом вызове React-хука без необходимости — лишние allocation'ы.
 */
export const getPlaceholderRange = ({
  position,
  name,
}: Pick<Placeholder, 'name' | 'position'>): Range => {
  const { row, column } = position
  return new Range(row, column, row, column + name.length + BRACKET_AMOUNT)
}

export const useHighlightEditor = ({ editorRef, scriptValue }: UseHighlightEditorParams) => {
  const [editor, setEditor] = useState<Ace.Editor | null>(null)
  const {
    placeholders,
    activePlaceholderIndex,
    setFirstActivePlaceholder,
    setActivePlaceholderIndex,
    clearActivePlaceholder,
  } = usePlaceholders({ value: scriptValue })

  const navigateToPlaceholder = useCallback(() => {
    if (
      !editorRef.current ||
      activePlaceholderIndex === null ||
      activePlaceholderIndex < 0 ||
      activePlaceholderIndex >= placeholders.length
    )
      return
    const editor = editorRef.current

    const { position, name } = placeholders[activePlaceholderIndex]
    const { row, column } = position

    editor.gotoLine(row + 1, column, true)
    editor.focus()

    const range = getPlaceholderRange({ position, name })
    editor.selection.setRange(range)
  }, [activePlaceholderIndex, placeholders, editorRef])

  const updateMarkers = useCallback(() => {
    if (!editorRef.current) return

    const session = editorRef.current.session
    const markers = session.getMarkers()

    Object.keys(markers).forEach((marker) => {
      const markerId = Number(marker)
      if (markers[markerId].clazz?.includes('placeholder-marker')) {
        session.removeMarker(markerId)
      }
    })

    placeholders.forEach((placeholder, index) => {
      if (!placeholder?.position) return

      const range = getPlaceholderRange(placeholder)
      const className = classNames('placeholder-marker', {
        'active-placeholder': index === activePlaceholderIndex,
      })

      session.addMarker(range, className, 'text', false)
    })
  }, [placeholders, activePlaceholderIndex, editorRef])

  const onLoad = useCallback(
    (editor: Ace.Editor) => {
      editorRef.current = editor

      setEditor(editor)
    },
    [editorRef],
  )

  useEffect(() => {
    if (!editor) return
    const session = editor.session
    session.on('change', updateMarkers)
    return () => {
      session.off('change', updateMarkers)
    }
  }, [editor, updateMarkers])

  useEffect(() => {
    if (!editor) return
    editorRef.current = editor
    return () => {
      if (editorRef.current === editor) editorRef.current = null
    }
  }, [editor, editorRef])

  useEffect(() => {
    navigateToPlaceholder()
  }, [editor, navigateToPlaceholder])

  useEffect(() => {
    updateMarkers()
  }, [editor, updateMarkers])

  return {
    onLoad,
    placeholders,
    setFirstActivePlaceholder,
    clearActivePlaceholder,
    setActivePlaceholderIndex,
  }
}
