import { useReactFlow } from '@xyflow/react'
import { type DependencyList, useEffect } from 'react'

export const useGraphFitView = (deps: DependencyList) => {
  const { fitView } = useReactFlow()

  useEffect(() => {
    const frame = requestAnimationFrame(() => {
      return fitView({ padding: { top: 0.3 }, duration: 1000 })
    })

    return () => cancelAnimationFrame(frame)
    // This hook forwards the dependency list supplied by its caller. Its
    // length is fixed at every call site, but ESLint cannot infer it here.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fitView, ...deps])
}
