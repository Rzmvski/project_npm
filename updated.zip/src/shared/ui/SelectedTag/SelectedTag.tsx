import { Button } from '@v-uik/base'
import classNames from 'classnames'
import { X } from 'lucide-react'
import React, { type FC, type ReactNode } from 'react'

import styles from './SelectedTag.module.scss'

interface SelectedTagProps {
  label: string
  icon: ReactNode
  onRemove: () => void
  disabled?: boolean
  warning?: boolean
}

export const SelectedTag: FC<SelectedTagProps> = ({
  label,
  icon,
  onRemove,
  disabled,
  warning,
}) => (
  <span
    className={classNames(styles.selectedTag, {
      [styles.disabled]: disabled,
      [styles.warning]: warning,
    })}
  >
    {icon}
    {label}
    <Button
      kind={'ghost'}
      size={'sm'}
      color={'secondary'}
      aria-label={`Удалить ${label}`}
      title={`Удалить ${label}`}
      className={styles.removeButton}
      onClick={onRemove}
      disabled={disabled}
    >
      <X />
    </Button>
  </span>
)
