export { pluralize } from './plural'
