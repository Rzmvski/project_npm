const rules = new Intl.PluralRules('ru-RU')
const FORM_INDEX: Partial<Record<Intl.LDMLPluralRule, number>> = { one: 0, few: 1 }

/** Форма слова для числа: `pluralize(2, ['шард', 'шарда', 'шардов'])` → «шарда». */
export const pluralize = (count: number, forms: [string, string, string]) =>
  forms[FORM_INDEX[rules.select(count)] ?? 2]
