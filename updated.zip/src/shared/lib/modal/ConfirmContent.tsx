import { Checkbox, LabelControl, ModalBody, ModalFooter, ModalHeader } from '@v-uik/base'
import { type ReactNode, useState } from 'react'

import { Button } from '@/shared/ui/Button'

interface ConfirmContentProps {
  title: string
  text: string
  additionalContent?: ReactNode
  confirmationLabel?: string
  confirmText?: string
  onResolve: (result: boolean) => void
}

export const ConfirmContent = ({
  title,
  text,
  additionalContent,
  confirmationLabel,
  confirmText = 'Подтвердить',
  onResolve,
}: ConfirmContentProps) => {
  const [confirmedLabel, setConfirmedLabel] = useState<string | null>(null)
  const confirmed = !confirmationLabel || confirmedLabel === confirmationLabel

  return (
    <>
      <ModalHeader>{title}</ModalHeader>
      <ModalBody>
        <p>{text}</p>
        {additionalContent}
        {confirmationLabel && (
          <LabelControl
            size={'sm'}
            control={<Checkbox />}
            label={confirmationLabel}
            checked={confirmed}
            onChange={(event) =>
              setConfirmedLabel(event.target.checked ? confirmationLabel : null)
            }
          />
        )}
      </ModalBody>
      <ModalFooter>
        <Button
          kind={'outlined'}
          color={'secondary'}
          disabled={!confirmed}
          onClick={() => onResolve(true)}
        >
          {confirmText}
        </Button>
        <Button color={'primary'} onClick={() => onResolve(false)}>
          {'Отмена'}
        </Button>
      </ModalFooter>
    </>
  )
}
