export { ROUTES, TITLE_DICTIONARY, TAB_ROUTE_PATTERNS } from './routes'
export type { RoutePath, TabRoutePath } from './routes'
export { platformRequestConfiguration, tkpRequestConfiguration } from './http'
