# TCPF Support Admin UI

Административный React-интерфейс для TCPF support/platform API. Перед изменением кода прочитай только относящиеся к задаче документы из @docs/README.md;
фактический код, `package.json` и публичные exports библиотек `@sber-pprb-tkp/tcpf-*-admin-api` имеют приоритет над текстом документации.

Этот файл — основной проектный контекст для GigaCode. Следуй правилам проекта и используй подходящие подключённые skills.

## Архитектура

- Соблюдай направление FSD: `app → pages → widgets → features → entities → shared`.
- Между slices используй публичные `index.ts`; не добавляй deep import во внутренности чужого slice.
- TanStack Query владеет server state, React Hook Form + Zod — формами, React state — локальным UI-состоянием.
- UI не вызывает сгенерированный SDK напрямую: API-доступ располагается в `api`-сегменте соответствующего slice.
- Не возвращай Redux и `src/shared/deprecated`.

Подробности: @docs/architecture.md, @docs/sdk-contract.md и @docs/forms.md.

## UI

- Сначала переиспользуй VUIK и `shared/ui`; стили размещай в SCSS Modules.
- Используй tokens/variables из `src/shared/styles`, не добавляй произвольные цвета и размеры без необходимости.
- Сохраняй semantic HTML, доступные имена действий и состояния loading/empty/error/pending.
- Адаптивную верстку проверяй в запущенном приложении рядом с sidebar, с длинными русскими строками и реальными состояниями mock API.

Подробности: @docs/design-system.md и @docs/table-plugins.md.

## SDK и mock

- Источник истины frontend-контракта — публичные exports подключённых библиотек `@sber-pprb-tkp/tcpf-support-admin-api` и
  `@sber-pprb-tkp/tcpf-platform-admin-api`; версия фиксируется в `package.json` и lockfile.
- Текущие `file:`-ссылки на `/Users/rzmvski/Downloads/@sber-pprb-tkp` временны. Не закрепляй этот путь в архитектуре или production-коде: после публикации
  библиотеки подключаются обычной semver-версией из registry.
- В production-коде импортируй только из корня `@sber-pprb-tkp/*`; не делай deep import из `dist` или `src`.
- При временном локальном подключении контракт можно проверить по `package.json` и `dist/index.d.ts` библиотеки в `Downloads`; после перехода на registry
  проверяй установленную зафиксированную версию.
- При обновлении библиотеки синхронно обновляй использование SDK, Express mock и тесты.
- Не редактируй код внутри `node_modules` и исходники подключённых библиотек без явного запроса.
- Не придумывай отсутствующий endpoint или DTO по mock/старой документации. Если нужного public export нет, зафиксируй blocker для изменения библиотеки.
- Не обновляй приватные `@sber-pprb-tkp/*` без доступного внутреннего источника и явного запроса.
- Для SSE используй сгенерированные `*ApiSse` и `useSseQuery`, не собирай URL вручную.

Подробности: @docs/sdk-contract.md и @docs/mock-server.md.

## Рабочие правила

Общие правила находятся в `.gigacode/rules` и подключаются здесь:

@.gigacode/rules/working-principles.md
@.gigacode/rules/safety.md
@.gigacode/rules/verification.md

Проверки по типу изменения описаны в @docs/validation.md.

## Цикл агентов

Для нетривиальной реализации используй `orchestrator` и цикл `plan → implement → review + validate → fix`:

0. `planner` составляет план, если задача затрагивает больше двух файлов или требования неоднозначны.
1. Один профильный исполнитель владеет изменением и его исправлениями.
2. `reviewer` и `build-validator` независимо проверяют результат; `fsd-architect` подключается при новых slices, переносах и изменении imports.
3. Координатор объединяет только обязательные замечания и возвращает их тому же исполнителю.
4. Цикл повторяется максимум три раза и завершается при `PASS` всех обязательных проверок либо при явном blocker.

Не запускай параллельных исполнителей на пересекающихся файлах. Read-only проверки можно выполнять параллельно. Подробный протокол находится в skill
`.gigacode/skills/agent-workflow`.

## Команды

```bash
pnpm run dev
pnpm test
pnpm run lint
pnpm run typecheck
pnpm run lint:architecture
pnpm run build
pnpm run validate
```

Проектные GigaCode skills находятся в `.gigacode/skills`, специализированные субагенты — в `.gigacode/agents`, правила — в `.gigacode/rules`.
Встроенные в GigaCode `Explore`, `general-purpose`, `review`, `simplify`, `init` и `skill-creator` не дублируются.
