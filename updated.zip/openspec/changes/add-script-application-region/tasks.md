# Tasks: add-script-application-region

## 1. Контракт platform API

- [x] 1.1 Добавить optional `regions?: string[]` в `CreateScriptApplicationRequestDto` и `ScriptApplicationDto` в локальной библиотеке `../@sber-pprb-tkp/tcpf-platform-admin-api/src/models/`. Обновить `FromJSON`, `ToJSON`, декларации в `dist` и ESM/CJS сборки пересборкой пакета. _Verification:_ SDK build проходит; focused round-trip тест проверяет отсутствующее и заданное поле.
- [ ] 1.2 Подтвердить/реализовать backend контракт `saveScriptApplication`: принять `regions` и применить его к исполнению. Это отдельная внешняя зависимость; не помечать задачу выполненной без подтверждения backend владельца. _Verification:_ интеграционный контрактный тест или подтверждённый backend API тест.

## 2. Форма запуска скрипта

- [x] 2.1 Добавить поле `regions` (минимум один элемент) в Zod-схему и defaults формы; список регионов обязателен для новой заявки, но не меняет optionality SDK DTO. _Verification:_ form submission блокируется без региона; focused form tests проходят.
- [x] 2.2 Подключить список из `entities/region` в `RestrictionSection`; показывать только `regionAvailability === true`, без автоподстановки. Блокировать submit при загрузке, пустом списке или ошибке. _Verification:_ отображение проверено в браузере; mock component tests проходят.
- [x] 2.3 Фильтровать `NodeSelector` через `NodeDto.shardId` → `ShardDto.id` → `ShardDto.region`; `NodeDto.key` используется как название ноды. Если смена регионов исключает выбранные ноды, запросить подтверждение; отмена сохраняет оба исходных выбора, подтверждение удаляет регион и только несовместимые ноды. _Verification:_ focused form tests проверяют фильтр, отмену и подтверждение.
- [x] 2.4 Добавить `regions` в payload `saveScriptApplication`, сохранив существующие предупреждения и ограничения по узлам. _Verification:_ focused form test проверяет request body с массивом регионов.

## 3. Просмотр заявки

- [x] 3.1 В `ScriptViewer` добавить компактное отображение `selected.regions` рядом с текущим списком ограничений по нодам; legacy-заявки без `regions` показывают «Все регионы (старая заявка)». _Verification:_ focused RTL tests для новых заявок с несколькими регионами и legacy DTO.

## 4. Mock и контрактные тесты

- [x] 4.1 Mock route сохраняет поля заявки через spread; выбор регионов и нод сверяется по связям ShardDto/NodeDto. _Verification:_ focused submit test подтверждает payload.
- [x] 4.2 Добавить SDK сериализацию в контрактные тесты приложения. _Verification:_ focused round-trip test проверяет `regions` в обоих направлениях.

## 5. Валидация

- [ ] 5.1 Выполнить `pnpm run typecheck`. _Verification:_ текущий запуск остаётся красным из-за существующих ошибок в несвязанных модулях (`beans-introspection`, `clear-transfer-task`, `create-transfer-task`); ошибок в затронутых файлах не показано.
- [x] 5.2 Выполнить focused Vitest, focused ESLint, Stylelint, Prettier и frontend production build. _Verification:_ focused tests 14/14; ESLint/Stylelint/Prettier/build завершились с кодом 0 (build сообщает существующее предупреждение о chunk >500 kB).
- [ ] 5.3 Проверить браузерный сценарий выбора регионов и фильтрации нод на широкой и компактной ширине, включая payload/network и console. _Verification:_ доступен только компактный screenshot/AX check; ширина desktop и network/console inspection не выполнены.
- [ ] 5.4 Выполнить независимый reviewer и build-validator согласно `openspec/config.yaml`; named GigaCode agents в runtime недоступны.
