# Proposal: fix-custom-parameter-validation

## Why

В модалках создания и редактирования фичи (TPTCP-4158) значения «Дополнительных параметров» не проверяются по выбранному типу: для типа `Int` форма принимает произвольную строку (на скриншоте тикета — `dplasdlI`), для Boolean/даты — аналогично. Схема `customParameterSchema` проверяет только непустоту полей. Некорректное значение проходит клиентскую валидацию и уходит в заявку; о проблеме администратор узнаёт уже от сервера либо получает нерабочее свойство фичи.

## What Changes

- В формы создания и редактирования фичи добавляется проверка значения кастомного параметра по выбранному типу:
  - числовые целые типы (`Byte`, `Short`, `Int`, `Long`, `BigInteger`) — целое число, для ограниченных типов дополнительно диапазон Java-типа;
  - дробные (`Double`, `Float`, `BigDecimal`) — десятичное число;
  - `Boolean` — `true`/`false` (регистр не важен);
  - `Date`, `Calendar`, `LocalDateTime` — ISO-формат даты/даты-со-временем;
  - `LogLevel` — один из уровней логирования FF4J;
  - `Class` — qualified-имя класса Java;
  - `String` и неизвестные типы — требование непустоты (текущее поведение).
- Ошибка выводится в существующем механизме формы: красная рамка поля и `helperText` с сообщением, submit блокируется наравне с остальными ошибками схемы.
- Type-aware проверка добавляется отдельным слоем схемы: базовый `customParameterSchema` (непустота) остаётся без изменений и продолжает использоваться разбором дампов при импорте фич.
- UI-компонент `CustomParameters` и mock-сервер не меняются: список типов уже приходит с бэкенда (`GET /properties/types`), отображение ошибок уже реализовано через `Controller`.

## Capabilities

### New Capabilities

- `feature-custom-parameters`: правила валидации значений кастомных параметров фичи в формах создания и редактирования (соответствие значения выбранному типу, сообщения об ошибках, поведение при неизвестном типе).

### Modified Capabilities

_(нет — существующие capabilities `feature-application-preview` и `node-metadata-sync` не затрагиваются)_

## Impact

- `src/entities/feature/model/feature.ts` — новый публичный export type-aware схемы/правил валидации значений по типу (домен кастомных параметров живёт в entities/feature).
- `src/features/manage-features/model/schema.ts` — подключение проверенного массива параметров в `commonFeatureSchema` (покрывает `createFeatureSchema` и `editFeatureSchema`).
- Тесты: `src/entities/feature/model/__tests__/feature.test.ts`, `src/features/manage-features/model/__tests__/schema.test.ts`, возможно сценарные тесты `CustomParameters`.
- Совместимость: контракты SDK и mock-сервер не меняются; импорт дампов (`src/features/import-feature/model/dumpSchema.ts`) сохраняет текущую пермиссивную валидацию.
