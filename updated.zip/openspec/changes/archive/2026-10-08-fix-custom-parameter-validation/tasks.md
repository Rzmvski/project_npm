# Tasks: fix-custom-parameter-validation

## 1. Формовая схема значений в entities/feature

- [x] 1.1 В `src/entities/feature/model/feature.ts` добавить `typedCustomParameterSchema` (проверка значения по суффиксу типа согласно карте правил design.md D2/D3, ошибки на path `value`) и экспорт `featureFormConfigurationSchema`; базовый `customParameterSchema` не менять. Проверка: focused-тест новой схемы в `src/entities/feature/model/__tests__/feature.test.ts` проходит
- [x] 1.2 Unit-тесты карты правил: целые (`Byte` вне диапазона отклоняется, границы принимаются, `Long` на границах ±2^63−1 через BigInt), дробные, `Boolean` регистронезависимо, `Date` реальная календарная дата (`2026-02-30` отклоняется), `LocalDateTime`/`Calendar` ISO-формат, `LogLevel` список уровней, `Class` qualified-имя, неизвестный тип — только непустота. Проверка: `npm test -- entities/feature/model` зелёный

## 2. Подключение к схемам форм

- [x] 2.1 В `src/features/manage-features/model/schema.ts` переопределить `config.customProperties` на формовую схему в `commonFeatureSchema` и обеих ветках `editFeatureSchema`; убедиться, что `CreateFormSchema`/`EditFormSchema`/`defaultValues` типизированы без ошибок. Проверка: `npm run typecheck`
- [x] 2.2 Тесты `schema.test.ts`: создание фичи с параметром типа Int и строковым значением отклоняется с path `config.customProperties.N.value`; корректное значение проходит; редактирование аналогично. Проверка: `npm test -- manage-features/model` зелёный
- [x] 2.3 Регресс-проверка импорта дампов: импорт должен остаться пермиссивным — тест, что `featureDumpSchema` разбирает параметр со значением, не соответствующим типу (например `Int` + `dplasdlI`), и прогоны существующих тестов модуля импорта не показывают регрессий. Проверка: `npm test -- import-feature` зелёный; при изменении списка fixtures/тестов импорта — без ослабления его валидации

## 3. Поведение формы CustomParameters

- [x] 3.1 Тест формы (по образцу существующих `*.test-model.tsx`): при несоответствии значения типу поле помечается ошибкой с сообщением, submit блокируется; после ввода корректного значения ошибка снимается. Проверка: `npm test -- CustomParameters` зелёный

## 4. Верификация и ревью

- [x] 4.1 Прогон пропорциональных проверок: `npm run typecheck`, focused ESLint изменённых файлов, `npm run lint:architecture`. Проверка: команды выполнены фактически, результат зафиксирован
- [ ] 4.2 Визуальная проверка на запущенном dev + mock (`npm run start:api`, `npm run dev`): создание и редактирование фичи, ошибка у поля значения для Int, снятие после исправления, узкая область рядом с sidebar и сообщение об ошибке не ломают раскладку. Проверка: сценарий пройден в браузере, mock smoke (`/health`, `/properties/types`)
- [ ] 4.3 Проверка пользовательского сценария импорта фичи на стенде: импорт дампа с «грязными» значениями параметров по-прежнему разбирается и показывает diff без ошибок валидации. Проверка: сценарий пройден в браузере против mock
- [x] 4.4 Независимые проверки по agent-workflow: reviewer по diff, build-validator по проверкам; обязательные замечания исправляются тем же исполнителем. Проверка: PASS обязательных проверок или явно зафиксированный blocker. Итог: reviewer VERDICT pass (NIT-фиксы применены: дедупликация override в schema.ts, границы Int/Short в тестах, явный выбор типа в validation-тесте; перепрогон 46/46 + ESLint чисто), build-validator VERDICT pass (vitest 165/168 — падения только baseline useFeatureResolve, typecheck 119 = baseline HEAD без упоминаний диффа, lint:architecture 3 = baseline HEAD, focused ESLint чисто)
