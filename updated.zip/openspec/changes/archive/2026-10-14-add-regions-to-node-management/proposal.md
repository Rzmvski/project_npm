# add-regions-to-node-management

## Why

Администратор должен управлять узлами и семафорами в разрезе региона: видеть, какой регион обслуживает нагрузку, фильтровать узлы по региону и включать/отключать обслуживание региона. Контракт публикует `tcpf-platform-admin-api`, backend-passthrough — `tcpf-platform-admin-app`; данный репозиторий отвечает за вкладку «Узлы» страницы «Управление узлами и семафорами».

Change межмодульный: доработка одна, затрагивает три репозитория. Идентификатор change `add-regions-to-node-management` единый во всех модулях; доля каждого модуля живёт в его собственном openspec.

## Related changes

| Репозиторий                                              | Локальный путь к change                            | Доля                                                                                              | Статус               |
| -------------------------------------------------------- | -------------------------------------------------- | ------------------------------------------------------------------------------------------------- | -------------------- |
| `platform-apps/tcpf-support-admin-ui` (этот репозиторий) | `openspec/changes/add-regions-to-node-management/` | вкладка «Узлы»: выбор региона, фильтрация, toggle доступности, «Перевести диапазоны», mock-server | **активный** (здесь) |
| `platform-apps/tcpf-platform-admin-app`                  | `openspec/changes/add-regions-to-node-management/` | passthrough backend, нормализация дефолтного региона, адаптация routing-api 2.0.3                 | активен (реализован) |
| `platform-api/tcpf-platform-admin-api`                   | `openspec/changes/add-regions-to-node-management/` | контракт тега RegionManagement, схемы RegionDto/RegionGroupDto, SDK                               | перенос запланирован |

Сквозные решения и полная task-карта централизации исторически хранятся в store `tcpf-context` (репо `tools/tcpf-context`; store выводится из эксплуатации после переноса долей в модули):

```bash
openspec show add-regions-to-node-management --store tcpf-context
```

## What Changes

- FSD-слайс `src/entities/region`: модель (`Region`, `deriveRegions`), `streamRegions` (SDK `getRegionGroups` через `useSseQuery`, queryKey `['regions']`), мутации доступности и перевода диапазонов, компоненты `RegionSelector`, `RegionToggleDialog`, `RegionTransferDialog`, `SummaryItem`.
- Шапка регионов на вкладке «Узлы» (`NodeManagementTab`): ряд выбора (пилюли-регионы с точкой доступности + поиск + refresh), ряд сводки (имя, статус, ДЦ, «Сервисный режим», действия), строка-уведомление; фильтрация карточек шардов по `shard.region`; отключённый регион — только просмотр.
- Диалоги-подтверждения с блокирующими причинами (несохранённые изменения шардов, последний обслуживающий регион); «Перевести диапазоны» с выбором переводимых диапазонов (`CheckboxGroup`) и целевого региона (`ComboBox`).
- `mock-server`: endpoints `GET/PUT /region/groups`, `PUT /region`, проверка заголовка `X-Region` (400 для шарда вне региона), асинхронное выравнивание шарды.
- Сквозное: передача `xRegion` в переводе нагрузки/семофоров, общая кнопка `shared/ui/RefreshButton`, сохранение несохранённых изменений при обновлении данных.

## Capabilities

### New Capabilities

- region-management (доля UI): выбор региона и фильтрация, toggle обслуживания с подтверждением, перевод диапазонов между регионами, совместимость со старым API без регионов.

### Modified Capabilities

- (нет)

## Impact

- **UI:** `src/entities/region/**`, `src/pages/cluster-management/ui/NodeManagementTab/**`, `src/shared/ui/RefreshButton`, `mock-server/**`.
- **Смежные модули (их openspec):** `tcpf-platform-admin-api` (контракт), `tcpf-platform-admin-app` (passthrough, реализован).
- **Downstream:** `tcpf-routing-app-os` — без изменений.
