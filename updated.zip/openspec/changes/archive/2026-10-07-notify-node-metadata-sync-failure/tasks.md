# Tasks: уведомление об ошибке синхронизации метаданных ноды

## 1. Обработка ошибки в мутации

- [x] 1.1 В `useNodeDictionariesMutation` добавить `onError`, показывающий `notification.error` с ключом ноды и `direction: 'vertical'` (образец — `useChangeNodeBoundaryMutation`). Проверка: focused vitest по хуку.
- [x] 1.2 Оставить обработчик в мутации, а не в `shared/config/http.ts`: SSE-ветка middleware должна оставаться молчаливой для переподключаемых подписок. Проверка: middleware не изменён (`git diff` по `shared/config/http.ts` пуст).

## 2. Тесты

- [x] 2.1 Кейс хука: `onError` вызывает `notification.error` с текстом, содержащим ключ ноды, и `{ direction: 'vertical' }`; уведомление об успехе не вызывается. Запуск: `npx vitest run src/features/sync-node-dictionaries`.
- [x] 2.2 Кейс компонента `SyncButton`: клик по кнопке синхронизации при отклонённом запросе показывает уведомление об ошибке и не показывает уведомление об успехе. До фикса кейс падал — уведомление не вызывалось вовсе. Запуск: тот же focused-прогон.
- [x] 2.3 Существующие кейсы успеха (хук и кнопка) сохранены без изменений ожиданий. Запуск: тот же focused-прогон.

## 3. Визуальная верификация

- [x] 3.1 Воспроизвести ошибку в запущенном приложении на mock-стенде (`npm run dev`: mock API :3001 + Vite :5173): временно `PUT .../nodes/{nodeKey}/metadatas` возвращал 500, ошибка кодировалась SSE-потоком. Проверка: вместо молчаливого возврата кнопки появляется тост «При синхронизации метаданных на ноде P2 возникла ошибка»; скриншот приложен к отчёту TPTCP-4145. Примечание: снимок получен вручную, так как Playwright MCP в сессии не поднялся.
- [x] 3.2 Временная правка mock-сервера для репродукции откачена — `mock-server/index.js` приведён к закоммиченному состоянию и не входит в изменение. Проверка: `git status` не показывает `mock-server/index.js`.

## 4. Валидация и коммит

- [x] 4.1 Пропорциональные проверки: `npx vitest run src/features/sync-node-dictionaries` — 3 файла / 5 тестов пройдены; focused ESLint (`--max-warnings=0`) и `prettier --check` — без замечаний.
- [x] 4.2 `npm run typecheck` — 119 ошибок `error TS` в baseline (`node_modules/react-ace`, `manage-features`, `manage-revision`, `shared/ui`, `widgets/manage-feature-applications-tab`); в `src/features/sync-node-dictionaries` ошибок нет, новых не добавлено. Baseline зафиксирован отдельно и не скрывался отключением проверок.
- [ ] 4.3 Закоммитить изменение (код + тесты + openspec-артефакты) Conventional Commit `fix(ui): TPTCP-4145 ...`. Проверка: `git status` чистый по затронутым файлам, commit-msg hook прошёл. Выполняется после подтверждения запуска git-операции.
