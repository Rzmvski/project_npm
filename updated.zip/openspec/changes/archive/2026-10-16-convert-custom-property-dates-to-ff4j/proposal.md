## Why

Бэкенд (tcpf-platform-admin-app) парсит кастомные параметры FF4J-фич через PropertyFactory, у которого в FF4J 1.9 свои форматы (не ISO-8601): `PropertyDate` → `"yyyy-MM-dd HH:mm:ss"`, `PropertyLocalDateTime` → `"yyyy-MM-dd HH:mm:ss.nnn"`, `PropertyCalendar` → `"yyyy-MM-dd HH:mm"`. UI-валидатор принимает ISO-формы (`2024-02-12`, `2024-02-12T12:00:00`, `2024-02-12T12:00:00.000Z`), и эти ISO-значения уходят в API без преобразования: `customProperties` проходят сквозь `mapFeatureDates.ts` нетронутыми, из-за чего PropertyFactory не может их распарсить и создание/обновление фичи с такими параметрами падает. Это «Вариант Б», скорректированный в ходе реализации: ISO-валидация датовых типов удалена из формы (формат значения контролируют пикер и пара конвертеров), а конвертация в формат FF4J выполняется на этапе формирования payload. Дополнительно, для типов даты/времени текстовый ввод заменяется компонентами выбора (VUIK `DatePicker`/`DateTimePicker`), которые пишут ISO-значение в `value` — это удобнее для администратора и исключает ручной ввод формата.

## What Changes

- **Ввод даты/времени компонентом**: для кастомного параметра с типом `Date` в форме используется VUIK `DatePicker`, для `LocalDateTime`/`Calendar` — VUIK `DateTimePicker`. Компонент записывает значение в `customProperties[].value` как ISO-строку (`YYYY-MM-DD` для даты, `YYYY-MM-DDT HH:mm:ss` для даты-со-временем). Модель значения остаётся строкой; остальные типы продолжают использовать текстовый `Input`.
- **Конвертация ISO → FF4J на payload**: добавляется функция конвертации значения кастомного параметра из ISO-8601 в формат парсинга FF4J для типов `PropertyDate`, `PropertyLocalDateTime`, `PropertyCalendar`:
  - `"2024-02-12"` → `"2024-02-12 00:00:00"`;
  - `"2024-02-12T12:00:00"` → `"2024-02-12 12:00:00.000"`;
  - `"2024-02-12T12:00:00.000Z"` → `"2024-02-12 12:00:00.000"`;
  - `"2024-02-12T12:00:00.123+03:00"` → `"2024-02-12 12:00:00.123"`.
- Конвертация применяется только к `customProperties` на этапе формирования payload (`mapDatesToApi`), не к `activation.releaseDate`. Сохраняется локальное время (Z/оффсет не меняет часы).
- Типы, отличные от дат/времени, и неизвестные/нераспознанные типы передаются без изменений.
- **Обратная нормализация**: при разборе ответа API значение кастомного параметра даты/времени нормализуется из формата хранения FF4J (дата и время через пробел) в ISO-канон пикера — иначе сохранённая фича возвращается значением, которое пикер не разбирает. Нормализация строгая: ровно один известный входной формат на тип; значения вне его передаются без изменений.
- **Валидация**: датовые ISO-правила (`date`, `localdatetime`, `calendar`) удалены из `typedCustomParameterSchema`; для датовых типов действует только базовая проверка непустоты, а смена типа параметра сбрасывает `value`.
- **Mock**: список типов параметров (`getPropertyTypes`) расширяется типами даты/времени, чтобы сценарий с пикерами проверялся end-to-end.

## Capabilities

### New Capabilities

_(нет)_

### Modified Capabilities

- `feature-custom-parameters`: добавляются требования: (1) значение кастомного параметра типа даты/времени конвертируется из ISO-8601 в формат парсинга FF4J при формировании API-payload фичи (только `customProperties`, не `activation.releaseDate`); (2) ввод значения даты/времени выполняется компонентами выбора `DatePicker`/`DateTimePicker`, которые сохраняют ISO-строку в `value`; (3) значение из ответа API нормализуется обратно из формата хранения FF4J в ISO-канон пикера (строгий входной формат на тип); (4) датовые ISO-правила удалены из формовой валидации — непустое значение любого формата проходит.

## Impact

- **UI** (`src/features/manage-features/ui/CustomParameters/`): для типа `Date`/`LocalDateTime`/`Calendar` вместо текстового `Input` рендер `DatePicker`/`DateTimePicker`, связанный с полем `config.customProperties.<index>.value` через `Controller`; сериализация выбранного `Date` в ISO-строку.
- **API-слой** (`src/entities/feature/api/mapFeatureDates.ts`): в `mapConfigurationToApi` применяется конвертер ISO → FF4J к `customProperties`, в `mapFeatureConfigurationDatesFromApi` — обратная нормализация.
- **Новый конвертер** в API-сегменте `entities/feature` (например `src/entities/feature/api/convertCustomPropertyValue.ts`) и зеркальный обратный конвертер `src/entities/feature/api/restoreCustomPropertyValue.ts`.
- **Модель** (`src/entities/feature/model/feature.ts`): экспорт `resolvePropertyTypeSuffix`/`DatePropertySuffix` для всех потребителей суффикса; удаление датовых ISO-правил из `typedValueRules`.
- **Mock** (`mock-server/src/routes.ts`): `getPropertyTypes` отдаёт также типы даты/времени.
- Тесты: `src/entities/feature/api/__tests__/` (конвертация и `mapFeatureDatesToApi`), `src/entities/feature/model/__tests__/` и UI-тесты `CustomParameters` (пикер, ISO-значение).
