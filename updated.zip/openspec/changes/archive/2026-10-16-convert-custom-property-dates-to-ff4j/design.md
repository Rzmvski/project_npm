## Context

См. `proposal.md` — Why. Две связанные части одного изменения: (1) ввод даты/времени кастомного параметра компонентами выбора вместо текстового поля, (2) конвертация ISO-строки значения в формат парсинга FF4J при формировании API-payload.

Ключевые факты текущего кода:

- `customProperties` описываются в `src/entities/feature/model/feature.ts`: базовый `customParameterSchema` (`value: z.string().nonempty`) и формовый `typedCustomParameterSchema` с ISO-правилами для суффиксов `date`, `localdatetime`, `calendar`. Модель значения — **строка**.
- Payload форм создаётся из `data` форм (`CreateFeatureForm`/`EditFeatureForm` передают распарсенный RHF-`data` в `onAction`), и `mapFeatureDatesToApi` (`src/entities/feature/api/mapFeatureDates.ts`) маппит `config`. В `mapConfigurationToApi` `customProperties` проходят сквозь `...configuration` нетронутыми — это точка конвертации.
- Виджет `CustomParameters` (`src/features/manage-features/ui/CustomParameters/CustomParameters.tsx`) рендерит строку параметра: имя / тип (`ComboBox`) / значение (`Input`) / удалить. Значение связано через `Controller` с полем `config.customProperties.<index>.value`.
- VUIK `@v-uik/base@1.23.0` ре-экспортирует `@v-uik/date-picker`, в котором есть `DatePicker`, `DateTimePicker`, `TimePicker`. Приложение уже настраивает `DateLibAdapterProvider` с `DateFnsAdapter` (`src/app/providers/DateAdapter.tsx`), поэтому пикеры работают с нативным `Date`, а `date-fns` доступен для сериализации. Уже есть обёртка `src/shared/ui/DatePicker` (маска `ДД.ММ.ГГГГ`, value — `Date`).
- Mock `getPropertyTypes` (`mock-server/src/routes.ts`) отдаёт только `['STRING','INTEGER','BOOLEAN','DECIMAL']`.

## Goals / Non-Goals

**Goals:**

- Значение даты/времени вводится `DatePicker`/`DateTimePicker`, но в `value` пишется ISO-**строка** — модель значения и zod-валидация не меняются.
- При формировании payload `customProperties` конвертируются ISO → FF4J по типу (только даты/время; `releaseDate` не трогаем).
- Значение из ответа API нормализуется обратно в ISO-канон пикера (D7) — round-trip сохранённых фич.
- Датовые ISO-правила удалены из формовой валидации (D8): непустое значение датового типа любого формата проходит форму.
- Mock расширен типами даты/времени для сквозной проверки сценария.

**Non-Goals:**

- Смена модели значения на объект `Date` (по решению — не меняем).
- Конвертация `activation.releaseDate` (уже делает `toLocalDate`).
- Изменение импорта дампов (остаётся пермиссивным через базовую схему).

## Decisions

### D1. Конвертер ISO → FF4J как чистый модуль в API-слое `entities/feature`

Новый экспорт в `src/entities/feature/api/` (например `convertCustomPropertyValue.ts`): функция `convertCustomPropertyValue(type: string, value: string): string`, применяемая в `mapConfigurationToApi` к каждому элементу `customProperties`. Тип распознаётся по суффиксу после префикса `org.ff4j.property.` / `property` (та же логика, что у `resolveValueRule` в feature.ts). Возвращает значение без изменений для не-датовых и неизвестных типов. Альтернатива (`.transform()` прямо в формовой схеме) отвергнута: затирала бы контролируемый `Input` при вводе (см. ниже) и уводила конвертацию от «этапа формирования payload».

### D2. Форматы и граничные случаи конвертации

| Суффикс         | Вход (ISO)                                                                                                                                                                     | Выход (FF4J)              |
| --------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------- |
| `Date`          | `2024-02-12`                                                                                                                                                                   | `2024-02-12 00:00:00`     |
| `LocalDateTime` | `2024-02-12T12:00:00` → `2024-02-12 12:00:00.000`; `...T12:00:00.123Z` → `... 12:00:00.123`; `...T12:00:00.5` → `... 12:00:00.500`; `...T12:00:00.123456` → `... 12:00:00.123` | `yyyy-MM-dd HH:mm:ss.nnn` |
| `Calendar`      | `2024-02-12T12:00:00`                                                                                                                                                          | `2024-02-12 12:00`        |

Дробные секунды: ровно 3 — как есть; меньше — дополнить нулями; больше — усечь. `Z`/оффсет отбрасываются без смены локального времени (вход разбирается как локальное). Неизвестный тип → без изменений.

### D3. Пикеры в `CustomParameters` пишут ISO-строку, модель не меняется

В `CustomParameters` для распознанного типа даты/времени вместо `Input` рендерится пикер из `@v-uik/base`: `Date` → `DatePicker`, `LocalDateTime`/`Calendar` → `DateTimePicker`. Пикеры наследуют текущий размер ряда: `size={'sm'}` (тот же, что у существующих `Input`/`ComboBox` в блоке), и рендерятся **без `canClear` (крестик очистки не отображается)**. У `DateTimePicker` время настраивается через `timePickerProps: StaticBaseTimePickerProps<TDate>` (`minutesStep`, `secondsStep`, `millisecondsStep`, `is12HoursFormat`); выбранное значение приходит нативным `Date` (`DateFnsAdapter`). Placeholder пикера повторяет паттерн поля «Дата активации» (show шаблон формата): `Date` → `ДД.ММ.ГГГГ`, `Calendar` → `ДД.ММ.ГГГГ ЧЧ:ММ` (без секунд), `LocalDateTime` → `ДД.ММ.ГГГГ ЧЧ:ММ:СС` (секунды есть, дробные не показываются). Связка через существующий `Controller` на поле `value`:

- `value` (ISO-строка) → распарсить в `Date` (пустая/невалидная строка → `null`, для редактируемости и сброса);
- `onChange(date)` → `field.onChange(format(...))` по типу через `date-fns` (локальное время): `Date` → `yyyy-MM-dd`; `Calendar` → `yyyy-MM-dd'T'HH:mm` (без секунд); `LocalDateTime` → `yyyy-MM-dd'T'HH:mm:ss` (целые секунды, без дробных).

Исходящая строка `value` всегда в ISO; конкретный формат FF4J (`LocalDateTime` → `HH:mm:ss.nnn` ровно 3 цифры дробных; `Calendar` → `HH:mm` без секунд) решает конвертер на payload независимо от того, показывает ли пикер секунды. Модель значения остаётся строковой; не-датовые типы по-прежнему используют `Input`. Роутинг по типу — тот же `resolveValueRule`-подход (переиспользовать/экспортировать функцию распознавания).

Вписывание пикера в слот строки: официальное растягивание — `inputProps.fullWidth`, который VUIK отражает классом `fullWidth` на корне пикера (`width: 100%`, `align-items: stretch`). Без него безымянные обёртки `Labelled`/`Control` держат intrinsic-ширину плейсхолдера — у каждого типа своя, из-за чего value-поля разных типов получают разную ширину, а плейсхолдер `ДД.ММ.ГГГГ ЧЧ:ММ:СС` не влезает. Top-level `classes.inputRoot` вместо него не работает: применяется только при отсутствии `timePickerProps` (`[classesMap.inputRoot]: !timePickerProps` в DatePicker). `inputProps.classes.root` дополнительно перебивает JSS `.inputRoot { width: 176px }`, которым закреплён `DatePicker`. Календарная иконка обязана оставаться внутри слота (не вылезать за него и не наезжать на кнопку удаления) на обычной и узкой ширине.

При смене типа параметра старое `value` сбрасывается (`setValue` пустой строки): значение одного датового типа не переиспользуется другим, повторный выбор того же значения ничего не меняет.

Переопределение иконок — единообразно с уже используемым в проекте `shared/ui/DatePicker` (`src/shared/ui/DatePicker/DatePicker.tsx`): стандартная иконка календаря заменяется через `inputProps.suffix = <CalendarDaysIcon className={suffixIcon} />` (lucide-react, ширина `$spacing-4` из `_variables.scss`), а error-иконка отключается через `inputProps.showErrorIcon = false` (ошибка показывается рамкой и `helperText`, как у остальных полей блока с `showErrorIcon={false}`). Применяется и к `DatePicker`, и к `DateTimePicker` (оба несут `inputProps`).

### D4. Не добавлять `shared/ui`-обёртку ради одного сценария

Прямое использование `DatePicker`/`DateTimePicker` из `@v-uik/base` в фиче `manage-features` достаточно: примитивы уже адаптированы `DateLibAdapterProvider`. Существующая `shared/ui/DatePicker` переиспользуется там, где нужна обвязка маски; для `DateTimePicker` обёртки нет и не создаём лишнюю, пока только одна точка использования.

### D5. Mock расширяется датами, чтобы сценарий проверялся end-to-end

`getPropertyTypes` в `mock-server/src/routes.ts` отдаёт дополнительно типы даты/времени (например `'DATE'`, `'LOCALDATETIME'`, `'CALENDAR'` краткие имена для ComboBox-фильтра UI), чтобы в dev можно было выбрать дату и прогнать конвертацию на payload. Суффиксы кратких имён совпадают с картой правил (case-insensitive).

### D6. Реализация — проектный цикл агентов

Изменение затрагивает и UI (пикеры), и API-слой (конвертер), и mock. Реализует ui-react-specialist (+ api-integration-specialist для конвертера и mock), независимые проверки — reviewer и build-validator (skill `project-testing`), координация — orchestrator по `openspec/config.yaml` и `agent-workflow`.

### D7. Обратная нормализация FF4J → ISO при разборе ответа API

Конвертер D1 односторонний, и на этом change изначально останавливался, из-за чего round-trip ломался: FF4J хранит и отдаёт обратно дата/время через пробел (`PropertyDate` → `2026-10-26 00:00:00`, `PropertyLocalDateTime` → `2026-10-16 04:10:04.000`, `PropertyCalendar` → `2026-10-05 06:00`), а `toPickerValue` в `CustomParameters` разбирает `value` паттернами `yyyy-MM-dd` / `yyyy-MM-dd'T'HH:mm[:ss]`. Сохранённая фича поэтому возвращалась значением, которое не парсят ни пикер, ни ISO-валидация, — в формах просмотра, редактирования и удаления поле выглядело пустым.

Аддитивный чистый конвертер `restoreCustomPropertyValue(type, value)` в `src/entities/feature/api/` — зеркало D1 по той же карте суффиксов (`resolvePropertyTypeSuffix`) и своей карте `propertyFormats: Record<DatePropertySuffix, PropertyDateFormat>` с парой `input`/`output` на тип; применяется к `customProperties` в `mapFeatureConfigurationDatesFromApi` (то же место, где `activation.releaseDate` идёт через `fromLocalDate`). Вход строго фиксирован — **ровно один известный формат хранения FF4J на тип**, тот самый, который производит бэкенд (PropertyFactory) и наш собственный `convertCustomPropertyValue` при сохранении; разбор — `parse`/`format` date-fns. Значение, не совпадающее с паттерном типа, возвращается без изменений:

| Суффикс         | Вход (ответ API)          | Выход (`value` UI)    |
| --------------- | ------------------------- | --------------------- |
| `Date`          | `2026-10-26 00:00:00`     | `2026-10-26`          |
| `LocalDateTime` | `2026-10-16 04:10:04.000` | `2026-10-16T04:10:04` |
| `Calendar`      | `2026-10-05 06:00`        | `2026-10-05T06:00`    |

Уже каноническое ISO-значение пикера формат хранения не совпадает и потому проходит без изменений — restore идемпотентен, а round-trip гарантируется тем, что выход `convertCustomPropertyValue` по каждому типу совпадает со входом `restoreCustomPropertyValue`. Перебор допустимых входных форматов (необязательные секунды, ISO на входе, ручной regex-разбор) отвергнут сознательно: набор форматов известен из контракта PropertyFactory, а ветвления по вариантам — источник регрессий. Альтернатива (мягче принимать пробельный формат прямо в `toPickerValue`/формовой валидации) также отвергнута: формат ответа перестал бы быть границей одного API-слоя, а датовая валидация формы к этому моменту удалена (D8).

### D8. Датовые ISO-правила удалены из формовой валидации

Решение принято в ходе реализации (изначальный Non-Goal «валидация остаётся как есть» отменён): из `typedValueRules` в `src/entities/feature/model/feature.ts` удалены записи `date`/`localdatetime`/`calendar` вместе со ставшими мёртвыми хелперами ISO-паттернов. Правило валидации датовых типов теперь одно — непустое значение любого формата проходит форму (базовая проверка `customParameterSchema`). Соответствие формату контролируется цепочкой «пикер + маска → `convertCustomPropertyValue` на payload → `restoreCustomPropertyValue` на ответе»: текстовый `Input` для датовых типов заменён пикером, а неразбираемое значение `toPickerValue` вернёт `null`, т.е. поле просто пустое, без блокирующей ошибки формата. Экспортируемые из модели `DatePropertySuffix` и `resolvePropertyTypeSuffix` — единая точка распознавания суффикса для карты правил, обоих конвертеров и роутинга пикеров.

## Risks / Trade-offs

- [Пикер `onChange` даёт `Date`, а `value` — строка; при пере-рендере несоответствие формата] → связка парсинг/`format` в `Controller` единообразна; пустые значения → `null`, невалидные строки → `null` без поломки.
- [Распознавание типа дублируется между фичей и entities] → переиспользуем единый `resolveTypeRule` (экспорт из `entities/feature/model`), чтобы не расходиться в наборе типов.
- [Разные форматы реального FF4J (например зоны `Calendar`)] → правила собраны в одном конвертере-карте; при расхождении на стенде правка одной точки. Неизвестные типы не блокируются.
- [Пикер-слот узкий в строке] → колонки строки приоритизированы в пользу значения (`CustomParameters.module.scss`), `inputProps.fullWidth` убирает зависимость ширины пикера от плейсхолдера; проверка на обычной и узкой (sidebar) ширинах входит в verification (react-ui-change).
- [Меньше/больше 3 цифр дробных — конвенция] → покрыта юнит-тестами конвертера и зафиксирована в spec.
- [Ответ API с отклоняющимся форматом (без дробных у `LocalDateTime`, с секундами у `Calendar`) restore не нормализует — пикер не разберёт такое значение] → осознанный компромисс: формат хранения фиксирован PropertyFactory и собственным конвертером D1; расхождение на стенде правится в одной точке карты `propertyFormats`.

## Migration Plan

Изменение клиентское и аддитивное + правка mock только для dev-проверки (не влияет на прод-контракт). Деплой обычным релизом UI; откат — revert. Данные и контракты не мигрируют.

## Open Questions

Нет. Решения по форматам, модели значения и месту конвертации зафиксированы выше и в spec.
