# Proposal: update-syngx-base-image

## Why

TPTCP-4156 «[tcpf-support-adimin-ui] Vulns Множественные уязвимости Platform V SberLinux OS Server (07.2026)»: продовый deploy-этап Dockerfile собирается на базовом образе `sngx/sbel9:syngx-4.2.3-9373-repacked-358`, основанном на устаревшей сборке SberLinux OS Server, поэтому контейнер приложения содержит известные уязвимости ОС. Актуальные пересборки SynGX публикуются на портале M-App (https://mapp.sberbank.ru/sberinfra/page/17874): для линии 4.2.x актуальная сборка от 07.08.2026 — `syngx-4.2.4-9536-repacked-361` (sbel9), собрана на SBEL 9.8.1 и содержит исправления безопасности.

## What Changes

- В `Dockerfile` меняется только строка `FROM ... AS deploy`:
  - было: `docker-internal.registry-ci.delta.sbrf.ru/ci04309835/ci04309835/sngx/sbel9:syngx-4.2.3-9373-repacked-358`;
  - стало: `docker-internal.registry-ci.delta.sbrf.ru/ci04309835/ci04309835/sngx/sbel9:syngx-4.2.4-9536-repacked-361`.
- Registry-хост (`docker-internal.registry-ci.delta.sbrf.ru`) и путь репозитория (`ci04309835/ci04309835/sngx/sbel9`) сохраняются — это текущая конвенция проекта, CI уже настроен на этот хост.
- Этапы `dependencies`/`source`/`test`/`build`, `USER syngx`, `EXPOSE`, `VOLUME`, `ENTRYPOINT` не меняются.
- Код приложения, SDK-контракты, mock-сервер и тесты не затрагиваются: изменение исключительно инфраструктурное.

## Capabilities

Изменение инфраструктурное: наблюдаемое поведение приложения и требования к нему не меняются, поэтому delta specs не создаются — в `.openspec.yaml` установлен `skip_specs: true`.

### New Capabilities

_(нет)_

### Modified Capabilities

_(нет)_

## Impact

- `Dockerfile` — одна строка `FROM ... AS deploy`.
- CI-сборка образа: потребуется pull нового тега из того же registry, где уже выполняется pull текущего тега; ожидается, что существующие docker-credentials CI подходят без изменений.
- Откат — revert коммита либо возврат предыдущего тега образа.
