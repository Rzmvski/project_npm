# region-sdk-3.0.5 Specification

## Purpose

Адаптация UI TCPF support к контракту SDK `@sber-pprb-tkp/tcpf-platform-admin-api` 3.0.5: `regionAvailability` перенесён из `RegionGroupDtoDto` в `RegionDtoDto`. Группы диапазонов (`GET /region/groups`, `PUT /region/groups`) больше не несут признак обслуживания; доступность управляется через `GET /invoke/support-admin/region` (`getAllRegions`) и `PUT /region` (список `RegionDtoDto[]`).

## BROKEN Requirements

### Requirement: regionAvailability в RegionGroupDtoDto (SDK 3.0.4)

~~Система SHALL получать доступность региона из `RegionGroupDtoDto.regionAvailability` при чтении групп (`GET /region/groups`) и использовать этот флаг для определения статуса обслуживания региона.~~ **УДАЛЕНО в SDK 3.0.5.**

## ADDED Requirements

### Requirement: deriveRegions использует доступность из RegionDtoDto[], по умолчанию false

Система SHALL определять доступность региона через `RegionDtoDto[]` (источник: SDK `getAllRegions()` / `GET /invoke/support-admin/region`), а не через `RegionGroupDtoDto`. Тип `deriveRegions` принимает `(groups: RegionGroupDtoDto[], known: RegionDtoDto[]): Region[]`, где `known` — список регионов с флагом `regionAvailability`.

- **Источник доступности:** `RegionDtoDto` (свойство `region: string`, `regionAvailability: boolean`) от `getAllRegions()`.
- **По умолчанию:** `false` — регионы недоступны, если информация об их доступности не получена от сервера.
- **hasRanges:** определяется по наличию групп диапазонов для региона в `RegionGroupDtoDto[]`. Регион с диапазонами может передаваться в `PUT /region`.
- **Объединение:** список регионов = уникальные `region` из групп ∪ из `known`. Регион без групп появляется в списке (флаг `hasRanges=false`), но не отправляется в `PUT /region`.

```ts
export type Region = RegionDtoDto & { hasRanges?: boolean }

export const deriveRegions = (
  groups: RegionGroupDtoDto[],
  known: RegionDtoDto[] = [],
): Region[] => {
  const groupsByRegion = groupBy(groups, 'region')
  const knownByRegion = keyBy(known, 'region')
  return uniq([...Object.keys(groupsByRegion), ...Object.keys(knownByRegion)]).map(
    (region) => ({
      region,
      regionAvailability: knownByRegion[region]?.regionAvailability ?? false,
      hasRanges: (groupsByRegion[region] ?? []).length > 0,
    }),
  )
}
```

- **Нет групп:** если `GET /region/groups` недоступен (404/405), регионы из групп отсутствуют; доступность берётся только из `known` (по умолчанию `false`). Селектор регионов скрывается, но страница работает.
- **Регион без диапазонов:** `hasRanges=false`; отображается в списке, но не отправляется в `PUT /region` и не участвует в toggle/transfer.

#### Scenario: Доступность известного региона

- **WHEN** `deriveRegions` вызван с `groups=[{region:'central',...}]` и `known=[{region:'central', regionAvailability:true}]`
- **THEN** результат: `{ region: 'central', regionAvailability: true, hasRanges: true }`

#### Scenario: Неизвестный регион по умолчанию недоступен

- **WHEN** `deriveRegions` вызван с `groups=[{region:'west', startInclusive:800, endExclusive:1000}]` и пустым `known=[]`
- **THEN** результат: `{ region: 'west', regionAvailability: false, hasRanges: true }`

#### Scenario: Регион без диапазонов

- **WHEN** `deriveRegions` вызван с `groups=[]` и `known=[{region:'east', regionAvailability:true}]`
- **THEN** результат: `{ region: 'east', regionAvailability: true, hasRanges: false }`

#### Scenario: Неизвестный регион без групп

- **WHEN** `deriveRegions` вызван с `groups=[]` и `known=[]`
- **THEN** результат: пустой массив `[]`

### Requirement: streamRegions объединяет данные из getAllRegions и getRegionGroups

Система SHALL получать доступность регионов через `getAllRegions()` (REST `GET /invoke/support-admin/region`) и группы диапазонов через `getRegionGroupsStream()` (SSE). Данные объединяются на уровне `useRegions` с ключом кэша `['regions']`.

- **getAllRegions:** REST-вызов через `regionManagementService.getAllRegions()`. Возвращает `RegionDtoDto[]`. Не поддерживает SSE в SDK 3.0.5 (нет `*ApiSse` для `getAllRegions`).
- **getRegionGroups:** SSE-поток через `regionManagementService.getRegionGroupsStream()` (`useSseQuery`, `bufferUntilComplete: true`). Возвращает `RegionGroupDtoDto[]` (без `regionAvailability`).
- **Инвалидация:** обе мутации (`useRegionAvailabilityMutation`, `useRegionGroupsMutation`) инвалидируют `['regions']`.

```ts
// useRegions.ts (упрощённо)
const regionsQueryKey = ['regions']

export const useRegions = () => {
  // REST: доступность регионов
  const regionsQuery = useQuery({
    queryKey: regionsQueryKey,
    queryFn: () => regionManagementService.getAllRegions(),
    retry: false,
  })

  // SSE: группы диапазонов
  const groupsQuery = useSseQuery({
    initialData: [] as RegionGroupDtoDto[],
    queryKey: regionsQueryKey,
    stream: (signal) => regionManagementService.getRegionGroupsStream({ signal }),
    bufferUntilComplete: true,
    retry: false,
  })

  const regions = useMemo(
    () => deriveRegions(groupsQuery.data, regionsQuery.data),
    [groupsQuery.data, regionsQuery.data],
  )

  return {
    ...regionsQuery,
    ...groupsQuery,
    data: regions,
    isInitialLoading: regionsQuery.isFetching && !regionsQuery.isFetched,
  }
}
```

#### Scenario: Regions загружены из обоих источников

- **WHEN** `GET /invoke/support-admin/region` возвращает `[{region:'central',regionAvailability:true}]` и `GET /region/groups` возвращает `[{startInclusive:0,endExclusive:500,region:'central'}]`
- **THEN** `useRegions` выводит `{ region: 'central', regionAvailability: true, hasRanges: true }`

#### Scenario: getAllRegions недоступен (404)

- **WHEN** `getAllRegions()` возвращает 404
- **THEN** `regionsQuery.error` установлен, все регионы считаются недоступными (`false`); шапка скрывается, страница продолжает работать.

### Requirement: PUT /region принимает RegionDtoDto[]

Система SHALL отправлять в `PUT /region` список `RegionDtoDto[]` с полями `{ region: string, regionAvailability: boolean }`. Тело содержит только регионы с `hasRanges === true`. Все остальные регионы игнорируются (не участвуют в toggle).

- **Мутирующий метод:** `useRegionAvailabilityMutation({ region, available })` читает актуальный кэш `getAllRegions()`, меняет флаг нужного региона, фильтрует по `hasRanges`, вызывает `updateRegionAvailability(body)`.
- **Тело запроса:** `[{ region: 'central', regionAvailability: false }, ...]` — полный список активных регионов.
- **Инвалидация:** `onSuccess` инвалидирует `['regions']`.

#### Scenario: Toggle доступности обновляет только целевой регион

- **WHEN** `useRegionAvailabilityMutation` вызван с `{ region: 'central', available: false }` и в кэше `[central (true), east (true)]`
- **THEN** PUT тело: `[{ region: 'central', regionAvailability: false }, { region: 'east', regionAvailability: true }]` (оба с `hasRanges`)

#### Scenario: PUT /region не включает регионы без диапазонов

- **WHEN** в кэше `[central (hasRanges=true), west (hasRanges=false)]`
- **THEN** PUT тело содержит только `{ region: 'central', ... }`; `west` игнорируется

### Requirement: PUT /region.groups принимает RegionGroupDtoDto[] без regionAvailability

Система SHALL отправлять в `PUT /region/groups` список `RegionGroupDtoDto[]` в формате SDK 3.0.5 (без поля `regionAvailability`). Операция используется для перевода диапазонов между регионами (`useRegionGroupsMutation`).

- **Мутирующий метод:** `useRegionGroupsMutation({ source, target, ranges? })` читает актуальный кэш групп, меняет `region` (и наследует `regionAvailability` целевого региона) у выбранных диапазонов, вызывает `updateRegionGroupsStream(body)`.
- **Наследование доступности:** переведённые диапазоны получают `regionAvailability` целевого региона из `deriveRegions(groups)`.

#### Scenario: Перевод диапазонов на целевой регион

- **WHEN** `useRegionGroupsMutation` вызван с `{ source: 'central', target: 'east' }` и целевой регион доступен (`regionAvailability=true`)
- **THEN** все диапазоны из `central` переназначаются на `east` с `regionAvailability=true`

## Modified Capabilities

### Capability: region-management (доля UI)

Изменён источник доступности региона: вместо `RegionGroupDtoDto.regionAvailability` (удалён в 3.0.5) используется `RegionDtoDto[].regionAvailability` из `getAllRegions()`. По умолчанию регионы недоступны (`false`). Группы (`RegionGroupDtoDto`) сохраняются для управления диапазонами и перевода между регионами.
