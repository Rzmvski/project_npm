## Context

Регионы управляются двумя операциями SDK 3.0.4/3.0.5:

| Контракт SDK 3.0.4 (старый)                                                                           | Контракт SDK 3.0.5 (новый)                                                                                                                       |
| ----------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------ |
| `RegionGroupDtoDto { startInclusive, endExclusive, region, regionAvailability }`                      | `RegionGroupDtoDto { startInclusive, endExclusive, region }` (без `regionAvailability`)                                                          |
| `RegionDtoDto { region, regionAvailability }` — `GET /invoke/support-admin/region` (same DTO existed) | `RegionManagementServiceApi.getAllRegions()` → `RegionDtoDto[]` — источник истины для доступности                                                |
| `getRegionGroups()` / `getRegionGroupsStream()`                                                       | `getAllRegions()` / `getAllRegionsStream()` + `updateRegionAvailabilityStream(RegionDtoDto[])` + `updateRegionGroupsStream(RegionGroupDtoDto[])` |

**Ключевой инсайт:** доступность региона теперь не связана с диапазонами (`RegionGroupDtoDto`). Группы — только про бакетные диапазоны `[startInclusive, endExclusive)` и привязку к региону. Доступность — про регион целиком (`RegionDtoDto`). UI должен объединять оба источника: группы для управления диапазоном, регионы для статусов.

## Goals / Non-Goals

**Goals:**

- `deriveRegions` больше не читает несуществующее `group.regionAvailability`; берёт доступность из `known: RegionDtoDto[]`.
- По умолчанию все регионы **недоступны** (`regionAvailability: false`), если не получены из `getAllRegions()`.
- Группы диапазонов сохраняются для `PUT /region/groups` (перевод диапазонов) и отображения ДЦ в сводке.
- Мутации (toggle доступности, перевод диапазонов) адаптированы под новый DTO.

**Non-Goals:**

- Изменение пользовательского сценария (шапка региона, диалоги, фильтрация).
- Переработка `mock-server` логики состояний (только структура данных).
- Обновление бэкенда или других репозиториев.

## Decisions

### 1. deriveRegions: доступность из known RegionDtoDto[], по умолчанию false

**Decision:** `deriveRegions(groups, known)` — где `groups: RegionGroupDtoDto[]` (диапазоны) и `known: RegionDtoDto[]` (регионы с доступностью). Алгоритм:

1. Собрать все уникальные регионы из групп и `known`.
2. Для каждого региона: `hasRanges = (группы региона).length > 0`.
3. `regionAvailability`: если регион есть в `known` → `known[region].regionAvailability`; иначе → `false` (по умолчанию, новые/неизвестные регионы недоступны).

```ts
export const deriveRegions = (groups: RegionGroup[], known: RegionDtoDto[] = []): Region[] => {
  const groupsByRegion = groupBy(groups, 'region')
  const knownByRegion = keyBy(known, 'region')
  return uniq([...Object.keys(groupsByRegion), ...Object.keys(knownByRegion)]).map(
    (region) => ({
      region,
      regionAvailability: knownByRegion[region]?.regionAvailability ?? false,
      hasRanges: (groupsByRegion[region] ?? []).length > 0,
    }),
  )
}
```

**Rationale:** Раньше `regionAvailability` бралась из флага на группе; если флаг не задан — бралась из `shard.region`. Теперь флага нет вовсе, поэтому единственный достоверный источник — `RegionDtoDto[]` из `getAllRegions()`. Значение по умолчанию `false` отражает политику «регионы недоступны без явного включения».

**Alternatives:** По умолчанию `true` (как было через `shard.region`) — отклонено: SDK 3.0.5 чётко устанавливает политику unavailable-by-default; UI должен это отражать. Использовать `shard.region` как fallback — отклонено: шард больше не несёт `regionAvailability`, а только `region[]` (идентификатор).

### 2. streamRegions: объединение getAllRegions и getRegionGroups

**Decision:** `streamRegions` собирает данные из двух SSE-потоков и объединяет их в один результат `RegionState { regions: RegionDtoDto[], groups: RegionGroupDtoDto[] }`. TanStack Query `useSseQuery` получает финальный список `RegionDtoDto[]` через `select`-функцию, которая комбинирует оба потока.

```ts
// streamRegions.ts
import { regionManagementService } from '@/shared/api'

/** Объединяет регионы с доступностью (getAllRegionsStream) и группы диапазонов (getRegionGroupsStream). */
export const streamRegions = async (signal: AbortSignal) => {
  // Получить полный список регионов с доступностью
  const regions = await regionManagementService.getAllRegions({ signal })
  return regions
}
```

Однако поскольку существующий паттерн `useSseQuery` работает через `AsyncGenerator`, а `getAllRegions()` — обычный REST call, потоки объединяются на уровне `useRegions`: группы остаются через SSE, доступность подтягивается отдельным `useQuery` с инвалидацией при мутации.

**Rationale:** `getAllRegions()` — REST endpoint без SSE (в SDK 3.0.5 нет `getAllRegionsStream`). `getRegionGroups()` нужен для PUT групп; для чтения доступности используем REST `getAllRegions()` как источник истины. Два запроса независимы; инвалидируются вместе ключом `['regions']`.

### 3. useRegionMutations: тело PUT из RegionDtoDto[]

**Decision:** `useRegionAvailabilityMutation` передаёт в `PUT /region` список `RegionDtoDto[]` (не вычисляемый из групп, а взятый из кэша `getAllRegions`). Тело содержит только регионы, у которых есть диапазоны (`hasRanges === true`).

```ts
// useRegionMutations.ts
const latestRegions = (client: QueryClient) =>
  client.getQueryData<RegionDtoDto[]>(regionsQueryKey) ?? []

export const useRegionAvailabilityMutation = () =>
  useMutation({
    mutationFn: async ({ region, available }: { region: string; available: boolean }) => {
      const client = queryClient
      const current = latestRegions(client) ?? []
      const body = current
        .filter((r) => r.hasRanges)
        .map((r) => ({
          region: r.region,
          regionAvailability: r.region === region ? available : r.regionAvailability,
        }))
      await regionManagementService.updateRegionAvailability(body)
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: regionsQueryKey }),
  })
```

**Rationale:** PUT `/region` принимает `RegionDtoDto[]` (DTO напрямую, не массив `{region, regionAvailability}`). Код 3.0.5 ожидает именно этот формат.

### 4. mock-server: регионы по умолчанию недоступны

**Decision:** `mock-server/src/fixtures.ts`: `state.regions` содержит массив `RegionDtoDto[]` с полями `{ region, regionAvailability }`. По умолчанию все регионы имеют `regionAvailability: false`. Endpoints `PUT /region` принимают `RegionDtoDto[]` и обновляют состояние. Groups (фактически `state.regions` как `RegionGroupDtoDto[]`) остаются для `PUT /region/groups`.

```ts
// fixtures.ts — обновлённый блок регионов
const state: MockState = {
  // ...
  regions: [
    { region: REGION_CENTRAL, regionAvailability: false },
    { region: REGION_EAST, regionAvailability: false },
  ],
  // группы диапазонов отдельно (для PUT /region/groups)
  regionGroups: INITIAL_REGION_GROUPS,
  // ...
}
```

Mock-эндпоинты `GET /region` и `PUT /region` возвращают/принимают `RegionDtoDto[]`. Mock-эндпоинты `GET/PUT /region/groups` — `RegionGroupDtoDto[]` (без `regionAvailability`).

**Rationale:** Соответствует контракту SDK 3.0.5 и политике unavailable-by-default. Groups без `regionAvailability` позволяют проверить, что deriveRegions правильно использует доступность из `RegionDtoDto[]`.

## Risks / Trade-offs

- [Risk] `getAllRegions()` недоступен на старом API (404/405).
  **Mitigation:** fallback — группы диапазонов без флагов доступности; все регионы помечаются как `false` (недоступны); шапка всё ещё показывается, но фильтры работают.
- [Risk] Параллельные мутации доступности.
  **Mitigation:** `PUT /region` идемпотентен (полное состояние); последующий GET — источник истины.

## Open Questions

- Нет. API сигнатуры SDK 3.0.5 подтверждены через public exports.
