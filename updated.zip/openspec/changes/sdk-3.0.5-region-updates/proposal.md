# sdk-3.0.5-region-updates

## Why

SDK `@sber-pprb-tkp/tcpf-platform-admin-api` 3.0.5 переработал модель регионов: доступность региона (`regionAvailability`) перенесена из `RegionGroupDtoDto` в `RegionDtoDto`, группы диапазонов больше не несут признак обслуживания. Текущий код в `deriveRegions` читает `group.regionAvailability`, которого нет — это ломает сборку и runtime-поведение. Требуется синхронизация UI с новым контрактом SDK 3.0.5.

## What Changes

- **Ломаное изменение:** поле `regionAvailability` удалено из `RegionGroupDtoDto`; теперь оно доступно только через `RegionDtoDto` (GET `/invoke/support-admin/region`, SDK `getAllRegions()`).
- `src/entities/region/model/types.ts`: `deriveRegions` переписан — доступность берётся из `known: RegionDtoDto[]` (список регионов с диапазоном), а не из флагов групп. Группы только для управления диапазонами `[startInclusive, endExclusive, region]`. По умолчанию `regionAvailability: false` (регионы недоступны без явного включения).
- `src/entities/region/api/streamRegions.ts`: источник данных групп остаётся `getRegionGroupsStream()` (для `PUT /region/groups`), но `streamRegions` дополнительно задействует `getAllRegionsStream()` для получения актуальной доступности.
- `src/entities/region/lib/useRegions.ts`: объединение данных из групп и списка регионов (`availableRegions: RegionDtoDto[]`), `deriveRegions(groups, known)` теперь использует доступность из `known`.
- `src/entities/region/lib/useRegionMutations.ts`: `useRegionAvailabilityMutation` строит тело PUT из `RegionDtoDto[]` (область видимости — регионы с диапазонами из `getAllRegions`), `useRegionGroupsMutation` переназначает диапазоны через `PUT /region/groups`.
- `mock-server/src/fixtures.ts`: `state.regions` получает полную структуру `RegionDtoDto[]` (включая `regionAvailability: false` по умолчанию); группы сохраняются как ранее.
- Тесты в `src/entities/region/`: обновление моков под новый контракт `RegionGroupDtoDto` (без `regionAvailability`) и новой сигнатуры `deriveRegions`.

## Capabilities

### Modified Capabilities

- region-management (доля UI): deriveRegions использует доступность из `RegionDtoDto[]` вместо `RegionGroupDtoDto.regionAvailability`.

## Impact

- **UI:** `src/entities/region/**`, `mock-server/src/fixtures.ts`.
- **SDK:** `@sber-pprb-tkp/tcpf-platform-admin-api` 3.0.5 — публичный контракт `RegionManagementServiceApi.getAllRegions()`, `RegionDtoDto.regionAvailability`, удалён `RegionGroupDtoDto.regionAvailability`.
