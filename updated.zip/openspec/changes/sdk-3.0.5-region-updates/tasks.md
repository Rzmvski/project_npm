# Tasks — sdk-3.0.5-region-updates (tcpf-support-admin-ui)

> Адаптация UI к контракту SDK `@sber-pprb-tkp/tcpf-platform-admin-api` 3.0.5:
> `regionAvailability` перенесён из `RegionGroupDtoDto` в `RegionDtoDto`.

## 1. Подготовка

- [ ] 1.1 [tcpf-support-admin-ui] Убедиться, что SDK 3.0.5 экспортирует `RegionManagementServiceApi.getAllRegions()`, `RegionDtoDto` и `RegionGroupDtoDto` (без `regionAvailability`). При отсутствии — зафиксировать блокер обновления SDK.
      _Verification:_ `pnpm run typecheck` проходит; типы `RegionDtoDto` и `RegionGroupDtoDto` импортируются из `@sber-pprb-tkp/tcpf-platform-admin-api`.

## 2. Модель: deriveRegions

- [ ] 2.1 [tcpf-support-admin-ui] Переписать `src/entities/region/model/types.ts`: `deriveRegions(groups, known)` берёт доступность из `known: RegionDtoDto[]`, по умолчанию `false`, `hasRanges` — фактическое наличие групп. Удалить `isBoolean`/`flatMap`/`every` логику, использовать простую маппинг-функцию. Тип `Region` остаётся `RegionDtoDto & { hasRanges?: boolean }`.
      _Verification:_ юнит-тест на deriveRegions: известный регион → его доступность, неизвестный регион → `false`, регион с группами → `hasRanges: true`, без групп → `hasRanges: false`.

## 3. Stream и query

- [ ] 3.1 [tcpf-support-admin-ui] Обновить `src/entities/region/api/streamRegions.ts`: вместо `getRegionGroupsStream` использовать `getAllRegions()` (REST) как источник доступности._groups_ читаются через отдельный `useQuery` для PUT групп.
      _Verification:_ `useRegions` получает `regions: RegionDtoDto[]`; `groups` доступен через дополнительный query для мутаций.

- [ ] 3.2 [tcpf-support-admin-ui] Обновить `src/entities/region/lib/useRegions.ts`: читать `RegionDtoDto[]` из нового источника; `deriveRegions(groups, known)` — группы из `['region-groups']`, known — из `['regions']`. Если `getAllRegions` недоступен (404/405), fallback на группы без флагов → все `false`.
      _Verification:_ шапка показывает регионы; отключённый регион → readOnly карточки; без API регионов → селектор скрывается, но без ошибок.

## 4. Мутации

- [ ] 4.1 [tcpf-support-admin-ui] Обновить `src/entities/region/lib/useRegionMutations.ts`: `useRegionAvailabilityMutation` строит тело `PUT /region` из `RegionDtoDto[]` (`{ region, regionAvailability }`), фильтр по `hasRanges`. `useRegionGroupsMutation` остаётся через `groups` для `PUT /region/groups`.
      _Verification:_ toggle доступности инвалидирует `['regions']`, PUT-тело содержит только регионы с диапазонами.

## 5. Mock-server

- [ ] 5.1 [tcpf-support-admin-ui] Обновить `mock-server/src/fixtures.ts`: `state.regions` → `RegionDtoDto[]` с `regionAvailability: false` по умолчанию; `state.regionGroups` → `RegionGroupDtoDto[]` без `regionAvailability`. Endpoints `GET /region` возвращает `state.regions`, `PUT /region` обновляет `state.regions`.
      _Verification:_ mock-тесты (`mock-server/__tests__`) проходят; `GET /region` → `[{ region, regionAvailability }]`; `PUT /region` обновляет состояние.

## 6. Тесты

- [ ] 6.1 [tcpf-support-admin-ui] Обновить тесты в `src/entities/region/`: mock DTO без `group.regionAvailability`, `deriveRegions` корректно использует `known`-флаги.
      _Verification:_ `pnpm test` проходит.

## 7. Валидация

- [ ] 7.1 [tcpf-support-admin-ui] Full-валидация. _Verification:_ `pnpm run validate` (lint + typecheck + test + build) проходит.
