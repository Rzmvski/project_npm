# Remaining React Doctor fixes

Goal: repair all confirmed findings in the current report without suppressions, any or casts through never.

- [ ] Accessibility and stable list identities: preserve keyboard/mouse behavior and use existing components.
- [ ] Effect cleanup and state: retain ownership, unsubscribe on unmount, avoid ref writes during render and unnecessary state copies.
- [ ] Review all seven cache warnings against actual cache owners; never add unrelated invalidations.
- [ ] Remove justified repeated form composition.
- [ ] Fix eight existing TypeScript errors against installed SDK signatures and real form types.
- [ ] Run focused tests, lint, typecheck, build and full React Doctor. Review changes and document false positives and unavailable checks.

Constraints: preserve existing edits; no commits; scope current report plus failing checks. Check repeated activation, unmount, keyboard activation, list reorder and SSE cancellation.
