import {
  type BucketRangeDto,
  type NodeDto,
  type PoolDto,
  PoolStateDto,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { groupBy, keyBy, map } from 'lodash-es'
import { useMemo } from 'react'

import { usePools } from '@/entities/connection-pool'
import { useNodes } from '@/entities/node'
import { calculateLoad, convertRange } from '@/entities/range'
import { useAvailableShards } from '@/entities/routing-shard'
import { type NodeType } from '@/features/change-shard-boundary'
import { type Node, type Shard } from '@/widgets/shard-item/model'

// Начиная с platform-api 2.1 NodeDto больше не содержит вложенные semaphores
// и connectionPool — данные о диапазонах бакетов переехали в bucketRanges
// шард (getShards()), а статус пула коннектов — в отдельный getPools().
// Собираем ноду из трёх источников, объединяя их по ключу ноды:
// BucketRangeDto.nodeKey и PoolDto.key соответствуют NodeDto.key.
const convertNode = (
  node: NodeDto,
  bucketRangesByNodeKey: Record<string, BucketRangeDto[]>,
  poolsByNodeKey: Record<string, PoolDto>,
  type: NodeType,
): Node => {
  const nodeRanges = bucketRangesByNodeKey[node.key] ?? []
  const ranges = nodeRanges.map((range) => convertRange({ ...range, dcKey: node.dcKey }))

  return {
    nodeKey: node.key,
    dcKey: node.dcKey,
    type,
    ranges,
    load: calculateLoad(ranges),
    connectionState: poolsByNodeKey[node.key]?.status ?? PoolStateDto.Unknown,
    frozen: nodeRanges.some(({ frozenNode }) => frozenNode == true),
  }
}

const mergeIntoShards = (
  nodes: NodeDto[],
  shardDtos: { id: number; bucketRanges?: BucketRangeDto[] }[],
  pools: PoolDto[],
): Shard[] => {
  const bucketRangesByNodeKey = groupBy(
    shardDtos.flatMap((shard) => shard.bucketRanges ?? []),
    (range) => range.nodeKey,
  )
  const poolsByNodeKey = keyBy(pools, (pool) => pool.key)

  const shard = groupBy(nodes, (node) => node.shardId)
  return map(shard, (dtos, id) => {
    // Шарде нужно минимум две ноды, чтобы иметь смысл (иначе это не шард, а
    // повреждённые данные). Больше двух — валидный случай: смена границы
    // (единая точка сплита) по-прежнему описывает только первую ноду и
    // "остальные", поэтому первая нода помечается 'left', а все следующие —
    // 'right', как и было для пары. Это сохраняет неизменной логику текущего
    // и нового диапазона (createRange/RangeInfo) и не требует нового NodeType.
    if (dtos.length < 2) throw new Error(`invalid shard with id ${id}`)
    const nodes = dtos.map((dto, index) =>
      convertNode(dto, bucketRangesByNodeKey, poolsByNodeKey, index === 0 ? 'left' : 'right'),
    )
    const disabled = nodes.some(
      ({ connectionState, frozen }) => connectionState != PoolStateDto.Active || frozen,
    )

    return { id: Number(id), nodes, disabled }
  })
}

export const useShards = () => {
  const nodesQuery = useNodes()
  const shardsQuery = useAvailableShards()
  const poolsQuery = usePools()
  const isInitialLoading = [nodesQuery, shardsQuery, poolsQuery].some(
    (query) => query.isLoading || (query.isFetching && (query.data?.length ?? 0) === 0),
  )

  const data = useMemo(
    () => mergeIntoShards(nodesQuery.data ?? [], shardsQuery.data ?? [], poolsQuery.data ?? []),
    [nodesQuery.data, shardsQuery.data, poolsQuery.data],
  )

  return {
    data,
    isLoading: isInitialLoading,
    isError: nodesQuery.isError || shardsQuery.isError || poolsQuery.isError,
    // Шарда собирается из трёх запросов, поэтому «Обновить» должно перезапросить
    // все три — иначе данные разъедутся между собой.
    refetch: () =>
      Promise.all([nodesQuery.refetch(), shardsQuery.refetch(), poolsQuery.refetch()]),
  }
}
