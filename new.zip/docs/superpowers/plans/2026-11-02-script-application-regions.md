# Script Application Regions Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add multi-region constraints to script applications, keep node restrictions inside the selected regions, and show region constraints in request review.

**Architecture:** Extend the platform SDK request DTO with optional `regions`, populate a required multi-select from `entities/region`, filter the existing node selector using node `dcKey` and region `dcs`, and render the stored regions in `ScriptViewer`. The mock request flow must preserve the new property.

**Tech Stack:** React, React Hook Form, Zod, VUIK, TanStack Query, SCSS Modules, platform admin API SDK, Vitest/RTL.

**Spec:** [OpenSpec design](../../../openspec/changes/add-script-application-region/design.md), [OpenSpec capability](../../../openspec/changes/add-script-application-region/specs/script-application-region/spec.md), [OpenSpec tasks](../../../openspec/changes/add-script-application-region/tasks.md)

## Global Constraints

- Use platform SDK public package exports in application code; update the local library source and built declarations/codecs because this is an approved temporary SDK edit.
- Keep multi-select and node restrictions in the existing run-script feature and use `entities/region` as the region source.
- Permit only active regions; require an explicit selection and at least one region.
- Node choices must map through `NodeDto.shardId`, `ShardDto.id`, and `ShardDto.region`; display labels use `NodeDto.key`.
- When deselection invalidates selected nodes, confirmation cancel preserves both selections; confirmation removes only invalid nodes.
- Keep request review compact and accessible; legacy applications without `regions` remain readable as unrestricted by region.
- Do not mark OpenSpec tasks complete until the matching implementation and checks finish.

## Review Focus

- A region may cover multiple DCs, and multiple regions form a union; node filtering must preserve all nodes from that union.
- A node must only be selectable when its shard belongs to one of the selected regions.
- Deselecting a region must not silently discard nodes; cancelling confirmation must preserve the prior form state.
- Removing a region must keep selected nodes still covered by another selected region.
- Legacy request DTOs omit `regions` and must display an understandable unrestricted state.

---

### Task 1: Extend local platform API SDK

**Files:**

- Modify: `../@sber-pprb-tkp/tcpf-platform-admin-api/src/models/CreateScriptApplicationRequestDto.ts`
- Modify/build: matching declarations and CJS/ESM artifacts under that package's `dist`.

**Interfaces:**

- Produces: `CreateScriptApplicationRequestDto.regions?: string[]` with JSON round-trip support.

- [ ] Add the optional `regions` model property and preserve it in `FromJSON`/`ToJSON`.
- [ ] Rebuild the library so package declarations and CJS/ESM codecs match source.
- [ ] Verify package typecheck and a request JSON round-trip for present and absent `regions`.

### Task 2: Add region multi-select and dependent node filtering

**Files:**

- Modify: `src/features/run-script/model/schema.ts`
- Modify: `src/features/run-script/lib/useScriptForm.ts`
- Modify: `src/features/run-script/ui/RestrictionSection/RestrictionSection.tsx` and its SCSS module
- Modify: `src/entities/routing-shard/ui/NodeSelector/NodeSelector.tsx` only if a focused selector API change is needed
- Modify: nearby feature/entity tests.

**Interfaces:**

- Consumes: `useRegions(): { data: Region[], is... }`, `NodeDto.dcKey`, and `Region.dcs`.
- Produces: form value `regions: string[]`; visible node options from shards assigned to selected regions.

- [ ] Add required-at-least-one region validation and an empty-array default.
- [ ] Add the accessible multi-select for active regions with explicit loading, error, empty, and selected states; do not auto-select.
- [ ] Derive eligible nodes by matching `NodeDto.shardId` to `ShardDto.id` and selected `ShardDto.region`; display `NodeDto.key`.
- [ ] On region change, detect selected nodes no longer covered. Apply immediately if none are affected; otherwise ask for confirmation. Cancel retains old region/node selections; confirm applies the region change and removes only invalid node keys.
- [ ] Send `regions` in the request while preserving existing restriction mode and warning behavior.

### Task 3: Show region restrictions in request review and mock state

**Files:**

- Modify: `src/features/manage-script-requests/ui/ScriptViewer/ScriptViewer.tsx` and SCSS
- Modify: `mock-server/src` request/application types and route if the new property is not already preserved by spread
- Modify: nearby viewer/mock tests.

**Interfaces:**

- Consumes: `ScriptApplicationDto.regions?: string[]`.
- Produces: compact “Регионы запуска” display and explicit legacy unrestricted-by-region text.

- [ ] Display the selected region names in the existing restrictions section, separate from node restrictions.
- [ ] For missing or empty `regions`, display “Все регионы (старая заявка)”.
- [ ] Verify the mock stores and returns the array without transformation.

### Task 4: Validate and close OpenSpec work

- [ ] Run focused tests for schema/form behavior, confirmation cancel/confirm, request viewing, and mock serialization.
- [ ] Run frontend typecheck, focused Oxlint, Stylelint, Oxfmt, and SDK build/typecheck.
- [ ] Run browser verification on `/script-runner` at desktop and compact content widths when browser tools are available.
- [ ] Run independent review/build validation where the runtime supports named project agents; otherwise report them as skipped.
- [ ] Check off only the OpenSpec tasks supported by completed evidence; leave the external production backend requirement open unless confirmed.
