# Code quality guide

## Команды

| Команда                      | Что проверяет                                |
| ---------------------------- | -------------------------------------------- |
| `pnpm run format:check`      | Форматирование исходников и docs через Oxfmt |
| `pnpm run lint:ox`           | JavaScript/TypeScript через Oxlint           |
| `pnpm run lint:styles`       | CSS/SCSS через Stylelint 16                  |
| `pnpm run lint`              | Oxlint + Stylelint + Oxfmt                   |
| `pnpm run lint:architecture` | FSD через Steiger                            |
| `pnpm run typecheck`         | TypeScript 7 type-check через Oxlint/Vite+   |
| `pnpm run test`              | Vitest 5, не более двух workers              |
| `pnpm run test:coverage`     | Vitest 5 с coverage                          |
| `pnpm run build`             | Production bundle через Vite+                |
| `pnpm run validate`          | Lint, typecheck, тесты и production build    |

`build` собирает production bundle. Типы проверяются отдельным `typecheck` и входят в полный `validate`. Если полный baseline не зелёный, в отчёте отдельно указываются существующие ошибки и новые regressions с командами, которыми они воспроизведены.

## Обязательные правила

- Не подавлять Oxlint/TypeScript без локального объяснения; предпочитать `@ts-expect-error` с причиной.
- Не оставлять `console.log`, тестовые данные и временные feature flags в production-коде.
- Не импортировать `src/*` из npm-пакетов и внутренности чужого slice.
- Hooks вызываются только в компонентах или custom hooks, не в произвольных table callbacks.
- Async effect должен иметь cleanup/abort, если результат может прийти после unmount.
- Ошибка API не маскируется успешным fallback без проверки причины.
- Форматирование большого legacy-массива выполняется отдельным изменением.

## Git hooks

- `pre-commit` запускает `pnpm run lint:staged`.
- `commit-msg` запускает Commitlint с conventional config.
- `pre-push` намеренно отсутствует: полный Vitest, typecheck, build и архитектурный анализ слишком медленные или нестабильные для каждого push.

Hooks должны давать обратную связь за секунды и проверять только локально изменяемый контекст. Vitest и production build выполняются в Docker/CI; focused-тесты разработчик запускает перед commit по таблице из `validation.md`. Полный `pnpm run validate` используется для cross-cutting изменений и как целевой quality gate после устранения известных baseline-ошибок.

`prepare` устанавливает Husky только внутри git-репозитория. При изменении hooks одновременно обновляются `code-quality.md` и `validation.md`.
