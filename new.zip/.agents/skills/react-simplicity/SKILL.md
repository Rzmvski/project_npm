---
name: react-simplicity
description: >
  Review, write and refactor React, TypeScript and JavaScript
  code for simplicity and maintainability. Remove unnecessary
  useEffect, useRef, subscriptions, derived state, memoization,
  custom hooks and overengineering. Use for React components,
  hook design, code reviews and React Doctor fixes.
---

# React Simplicity

Optimize for correctness, clarity and low conceptual complexity,
not for the number of patterns or abstractions used.

## Workflow

1. Understand the existing behavior and public API.
2. Identify the real source of truth for each piece of state.
3. Find and remove unnecessary synchronization and indirection.
4. Implement the simplest idiomatic solution.
5. Verify behavior with existing tests and static analysis.

## React rules

- Prefer deriving values during render over storing derived state.
- Use event handlers for user-initiated actions.
- Use useEffect only to synchronize with external systems.
- Never add an Effect solely to synchronize React state with React state.
- Avoid useRef as a workaround for stale closures or dependencies.
- Use refs for legitimate DOM access or mutable non-rendering values.
- Avoid useMemo and useCallback without a concrete reason.
- Prefer existing framework hooks over manual subscriptions.
- Use useSyncExternalStore only for genuine external stores.
- Keep state in its narrowest appropriate owner.
- Avoid custom hooks that only forward arguments without adding value.
- Each custom hook must have one clear responsibility.
- Avoid unnecessary Context providers, reducers and abstractions.
- Do not create generic frameworks for a single use case.

## TypeScript rules

- Prefer inferred types for local variables.
- Define explicit types at meaningful API boundaries.
- Use discriminated unions for genuinely distinct states.
- Avoid any, unsafe assertions and redundant generics.
- Reuse existing project types.
- Keep business logic separate from rendering where useful.

## Refactoring constraints

- Preserve behavior, public contracts and meaningful error handling.
- Prefer deleting complexity over relocating it.
- Do not replace one abstraction with several new abstractions.
- Do not add dependencies unless necessary.
- Prefer small cohesive changes over broad rewrites.
- Do not optimize speculative performance problems.

## Verification

- Run the repository's typecheck, lint and relevant tests.
- Check effect cleanup, async behavior and state ownership.
- Ensure no new derived state or redundant subscriptions remain.
- Explain any remaining complex hooks and why they are necessary.
- Report simplifications and unverified behavior.
