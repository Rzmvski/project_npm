# Аудит TS/JS

> Исторический аудит до миграции на TypeScript 7 и Oxlint. Ссылки на `eslint.config.mjs` и описанные ниже настройки не отражают текущую конфигурацию проекта.

Синтаксически проверено файлов: 1370.
Найдено: 304 any и 87 приведений к never в 149 файлах.
Это полный проход по перечисленным TS/JS-файлам на две запрещённые конструкции; он не заменяет ручную проверку поведения.

## Настройки

- tsconfig.app.json: strict и noImplicitAny не включены.
- eslint.config.mjs:163: no-explicit-any отключён для тестов.
- Приведения к never отдельно не запрещены правилами ESLint.

## Все подтверждённые вхождения

### src/entities/application/lib/**tests**/useApplications.test.ts

- Строка 4: any
- Строка 6: any

### src/entities/bean/lib/**tests**/useBeans.test.ts

- Строка 4: any
- Строка 6: any

### src/entities/connection-pool/lib/**tests**/usePools.test.ts

- Строка 6: any
- Строка 10: any

### src/entities/data-center/lib/**tests**/useDataCenters.test.ts

- Строка 5: any
- Строка 9: any

### src/entities/dictionary/lib/**tests**/useDictionaries.test.ts

- Строка 4: any
- Строка 6: any
- Строка 13: any

### src/entities/feature/lib/**tests**/useFeatureColumns.test.tsx

- Строка 35: never-cast

### src/entities/feature/lib/**tests**/useFeatures.test.ts

- Строка 12: any
- Строка 17: any

### src/entities/feature-application/api/**tests**/fetch.test.ts

- Строка 39: never-cast

### src/entities/feature-application/lib/**tests**/useFeatureApplicationColumns.test.tsx

- Строка 33: never-cast

### src/entities/feature-application/lib/**tests**/useFeatureResolve.test.tsx

- Строка 28: never-cast
- Строка 71: never-cast

### src/entities/index-cluster/lib/**tests**/useIndexClusters.test.ts

- Строка 7: any
- Строка 11: any

### src/entities/monitoring/lib/**tests**/useMonitoring.test.ts

- Строка 10: any
- Строка 14: any

### src/entities/node/lib/**tests**/useNodes.test.ts

- Строка 6: any
- Строка 11: any

### src/entities/operation-day/lib/**tests**/useOperationDay.test.ts

- Строка 4: any
- Строка 6: any

### src/entities/process/lib/**tests**/useActiveProcesses.test.ts

- Строка 6: any
- Строка 7: any
- Строка 8: any
- Строка 13: any
- Строка 17: any
- Строка 21: any
- Строка 34: any

### src/entities/process/lib/**tests**/useProcessColumns.test.ts

- Строка 18: never-cast

### src/entities/process-group/lib/**tests**/useProcessGroups.test.ts

- Строка 4: any
- Строка 6: any

### src/entities/process-history/lib/**tests**/useProcessHistoryColumns.test.ts

- Строка 18: never-cast

### src/entities/region/lib/**tests**/useRegionMutations.test.ts

- Строка 18: any

### src/entities/region/lib/**tests**/useRegions.test.ts

- Строка 13: any
- Строка 20: any
- Строка 30: any
- Строка 47: any
- Строка 64: any

### src/entities/revision/config/**tests**/statusConfig.test.tsx

- Строка 20: never-cast

### src/entities/revision/lib/**tests**/useRevisionColumns.test.tsx

- Строка 19: never-cast

### src/entities/revision/lib/**tests**/useRevisionDetails.test.ts

- Строка 6: any
- Строка 11: any
- Строка 13: any
- Строка 15: any

### src/entities/revision/lib/**tests**/useRevisionDetailsColumns.test.tsx

- Строка 19: never-cast

### src/entities/revision/lib/**tests**/useRevisions.test.ts

- Строка 6: any
- Строка 11: any
- Строка 13: any

### src/entities/revision-history/lib/**tests**/useRevisionHistoryFilter.test.ts

- Строка 11: any
- Строка 28: any

### src/entities/revision-history/ui/RevisionHistoryFilter/**tests**/RevisionHistoryFilter.test.tsx

- Строка 24: any
- Строка 35: any
- Строка 46: any
- Строка 56: any
- Строка 58: any

### src/entities/revision-report/lib/**tests**/useLoadRevisionReport.test.ts

- Строка 6: any
- Строка 8: any
- Строка 12: any
- Строка 15: any
- Строка 17: any
- Строка 18: any

### src/entities/revision-shard/lib/**tests**/useRevisionShards.test.ts

- Строка 4: any
- Строка 6: any

### src/entities/routing-shard/api/**tests**/fetchAvailableShards.test.ts

- Строка 5: never-cast
- Строка 14: never-cast
- Строка 23: never-cast

### src/entities/routing-shard/lib/**tests**/useAvailableShards.test.ts

- Строка 6: any
- Строка 10: any

### src/entities/routing-shard/ui/NodeSelector/**tests**/NodeSelector.test-model.tsx

- Строка 13: never-cast

### src/entities/routing-shard/ui/NodeSelector/**tests**/NodeSelector.test.tsx

- Строка 20: any
- Строка 35: any
- Строка 42: any
- Строка 49: any
- Строка 51: any

### src/entities/script-request/lib/**tests**/useScriptLogs.test.ts

- Строка 5: any
- Строка 7: any
- Строка 9: any
- Строка 11: any

### src/entities/script-request/lib/**tests**/useScriptRequests.test.ts

- Строка 4: any
- Строка 6: any

### src/entities/script-request/lib/**tests**/useUpdatableScriptRequests.test.ts

- Строка 8: any
- Строка 19: any

### src/entities/script-template/lib/**tests**/useTemplates.test.ts

- Строка 4: any
- Строка 6: any

### src/entities/script-template/ui/TemplateExplorer/**tests**/TemplateExplorer.test.tsx

- Строка 51: any
- Строка 52: any
- Строка 56: any
- Строка 64: any
- Строка 65: any
- Строка 72: any
- Строка 75: any
- Строка 79: any
- Строка 83: any

### src/entities/script-template/ui/TemplateInfo/**tests**/TemplateInfo.test-model.tsx

- Строка 6: any
- Строка 7: never-cast

### src/entities/script-template/ui/TreeItem/**tests**/TreeItem.test-model.tsx

- Строка 6: any
- Строка 19: never-cast

### src/entities/semaphore/lib/**tests**/useSemaphores.test.ts

- Строка 5: any
- Строка 9: any

### src/entities/traffic-restriction/lib/**tests**/useTrafficRestrictions.test.ts

- Строка 6: any
- Строка 10: any

### src/entities/traffic-restriction/ui/PartitionSelector/**tests**/PartitionSelector.test.tsx

- Строка 7: any

### src/entities/traffic-restriction/ui/RestrictionTooltip/**tests**/RestrictionTooltip.test.tsx

- Строка 8: any

### src/entities/traffic-restriction/ui/TrafficRestrictionViewer/**tests**/TrafficRestrictionViewer.test.tsx

- Строка 6: any
- Строка 11: any

### src/entities/transfer-history/lib/**tests**/useTransferHistoryColumns.test.ts

- Строка 22: never-cast

### src/features/beans-introspection/lib/**tests**/useBeanIntrospection.test.ts

- Строка 9: any
- Строка 16: any
- Строка 26: any
- Строка 65: never-cast
- Строка 81: never-cast
- Строка 95: never-cast
- Строка 111: never-cast
- Строка 118: never-cast

### src/features/beans-introspection/lib/useBeanIntrospection.ts

- Строка 55: any

### src/features/build-restriction-graph/lib/**tests**/useGraph.test.ts

- Строка 7: any
- Строка 22: never-cast

### src/features/build-restriction-graph/lib/**tests**/useGraphEdges.test.ts

- Строка 6: never-cast

### src/features/build-restriction-matrix/lib/**tests**/useMatrix.test.tsx

- Строка 18: any
- Строка 39: any
- Строка 42: any
- Строка 54: any

### src/features/change-range/api/**tests**/fetch.test.ts

- Строка 12: never-cast

### src/features/change-range/lib/**tests**/useChangeRangesMutation.test.ts

- Строка 6: any
- Строка 13: any
- Строка 17: any
- Строка 24: never-cast

### src/features/change-range/ui/RangeEditor/**tests**/RangeEditor.test-model.tsx

- Строка 17: never-cast
- Строка 19: never-cast
- Строка 29: never-cast

### src/features/change-range/ui/RangeEditor/**tests**/RangeEditor.test.tsx

- Строка 10: any
- Строка 14: any
- Строка 28: any
- Строка 31: any
- Строка 31: any
- Строка 34: any
- Строка 50: any
- Строка 60: any
- Строка 63: any
- Строка 66: any

### src/features/change-semaphore-state/api/**tests**/fetchChangeSemaphoreState.test.ts

- Строка 11: never-cast

### src/features/change-semaphore-state/lib/**tests**/useSemaphoreColumns.test.tsx

- Строка 15: never-cast

### src/features/change-semaphore-state/lib/**tests**/useSemaphoreDetails.test.ts

- Строка 7: any
- Строка 12: any
- Строка 18: any
- Строка 27: any

### src/features/change-semaphore-state/lib/**tests**/useSemaphoreStateMutation.test.ts

- Строка 6: any
- Строка 8: any
- Строка 12: any

### src/features/change-shard-boundary/lib/**tests**/calculateBoundary.test.ts

- Строка 7: never-cast
- Строка 13: never-cast
- Строка 19: never-cast

### src/features/change-shard-boundary/lib/**tests**/useChangeNodeBoundaryMutation.test.ts

- Строка 6: any
- Строка 14: any
- Строка 18: any

### src/features/change-shard-boundary/ui/LoadSlider/**tests**/LoadSlider.test.tsx

- Строка 6: any
- Строка 15: any

### src/features/clear-transfer-task/api/**tests**/fetch.test.ts

- Строка 9: never-cast

### src/features/clear-transfer-task/ui/**tests**/ClearTransferTaskForm.test.tsx

- Строка 21: any
- Строка 32: any
- Строка 43: any
- Строка 49: any
- Строка 63: any
- Строка 71: any
- Строка 75: any

### src/features/create-transfer-task/api/**tests**/fetch.test.ts

- Строка 10: never-cast
- Строка 29: never-cast

### src/features/create-transfer-task/lib/**tests**/useDisabledSteps.test.ts

- Строка 6: never-cast
- Строка 37: never-cast

### src/features/create-transfer-task/ui/Steps/**tests**/Steps.test.tsx

- Строка 22: any
- Строка 34: any
- Строка 48: any
- Строка 56: any
- Строка 67: any
- Строка 70: any
- Строка 72: any

### src/features/filter-feature-applications/ui/FeatureApplicationsFilters/**tests**/FeatureApplicationsFilters.test-model.tsx

- Строка 20: never-cast
- Строка 22: never-cast
- Строка 26: never-cast
- Строка 27: never-cast

### src/features/filter-feature-applications/ui/FeatureApplicationsFilters/**tests**/FeatureApplicationsFilters.test.tsx

- Строка 4: any
- Строка 7: any

### src/features/filter-features/ui/FeatureFilters/**tests**/FeatureFilters.test-model.tsx

- Строка 20: never-cast
- Строка 22: never-cast
- Строка 26: never-cast

### src/features/filter-features/ui/FeatureFilters/**tests**/FeatureFilters.test.tsx

- Строка 4: any
- Строка 7: any

### src/features/filter-restrictions/ui/RestrictionFilters/**tests**/RestrictionFilters.test-model.tsx

- Строка 20: never-cast

### src/features/filter-restrictions/ui/RestrictionFilters/**tests**/RestrictionFilters.test.tsx

- Строка 10: any

### src/features/find-shard-info/ui/**tests**/FindShardInfo.test.tsx

- Строка 9: any
- Строка 23: any

### src/features/import-feature/api/**tests**/fetch.test.ts

- Строка 8: never-cast

### src/features/import-feature/lib/**tests**/useImportFeature.test.tsx

- Строка 21: never-cast

### src/features/import-feature/lib/**tests**/useLoadDumpMutation.test.ts

- Строка 6: any
- Строка 13: any
- Строка 17: any
- Строка 26: never-cast

### src/features/import-feature/ui/FileError/**tests**/FileError.test.tsx

- Строка 24: never-cast

### src/features/import-feature/ui/ImportFeatureModal/**tests**/ImportFeatureModal.test.tsx

- Строка 22: any
- Строка 45: any
- Строка 84: any

### src/features/import-feature/ui/PreviewStep/**tests**/PreviewStep.test-model.tsx

- Строка 8: never-cast

### src/features/import-feature/ui/PreviewStep/**tests**/PreviewStep.test.tsx

- Строка 7: any
- Строка 16: any
- Строка 25: any
- Строка 30: any
- Строка 31: any

### src/features/manage-connection-pool/lib/**tests**/useChangePoolMutation.test.ts

- Строка 6: any
- Строка 13: any
- Строка 17: any
- Строка 25: never-cast

### src/features/manage-features/api/**tests**/fetch.test.ts

- Строка 10: never-cast

### src/features/manage-features/ui/CreateFeatureForm/**tests**/CreateFeatureForm.test.tsx

- Строка 14: any
- Строка 39: any

### src/features/manage-features/ui/DeleteFeatureForm/**tests**/DeleteFeatureForm.test-model.tsx

- Строка 16: never-cast

### src/features/manage-features/ui/DeleteFeatureForm/**tests**/DeleteFeatureForm.test.tsx

- Строка 6: any
- Строка 12: any
- Строка 15: any
- Строка 29: any
- Строка 34: any

### src/features/manage-features/ui/EditFeatureForm/**tests**/EditFeatureForm.test-model.tsx

- Строка 12: any
- Строка 18: never-cast

### src/features/manage-features/ui/EditFeatureForm/**tests**/EditFeatureForm.test.tsx

- Строка 8: any
- Строка 10: any
- Строка 20: any
- Строка 37: any
- Строка 50: any

### src/features/manage-features/ui/MainSection/**tests**/MainSection.test.tsx

- Строка 9: any
- Строка 20: any
- Строка 35: any
- Строка 38: any
- Строка 41: any
- Строка 43: any

### src/features/manage-features/ui/PermissionIdInput/**tests**/PermissionIdInput.test.tsx

- Строка 9: any
- Строка 22: any

### src/features/manage-indexes/lib/**tests**/useIndexActionNotifications.test.ts

- Строка 16: any
- Строка 25: never-cast

### src/features/manage-indexes/lib/**tests**/useManageIndexes.test.ts

- Строка 6: any
- Строка 17: any
- Строка 35: never-cast
- Строка 49: never-cast

### src/features/manage-indexes/ui/**tests**/IndexTable.test.tsx

- Строка 17: any
- Строка 18: any
- Строка 53: any
- Строка 67: any
- Строка 68: any
- Строка 100: any

### src/features/manage-revision/lib/**tests**/useRevisionActions.test.tsx

- Строка 58: never-cast
- Строка 61: never-cast

### src/features/manage-revision/lib/**tests**/useRunRevision.test.ts

- Строка 6: any
- Строка 12: any

### src/features/manage-script-requests/api/**tests**/fetchManageRequest.test.ts

- Строка 8: never-cast

### src/features/manage-script-requests/lib/**tests**/useArchivePartition.test.ts

- Строка 7: never-cast

### src/features/manage-script-requests/lib/**tests**/useChangeRequestStatus.test.ts

- Строка 7: any
- Строка 18: any
- Строка 31: never-cast

### src/features/manage-script-requests/lib/**tests**/useScriptModal.test.tsx

- Строка 13: any
- Строка 25: any
- Строка 29: never-cast

### src/features/manage-script-requests/lib/**tests**/useScriptRequestsColumns.test.tsx

- Строка 15: never-cast

### src/features/manage-script-requests/ui/ManageButtons/**tests**/ManageButtons.test-model.tsx

- Строка 8: never-cast

### src/features/manage-script-requests/ui/ManageButtons/**tests**/ManageButtons.test.tsx

- Строка 27: any
- Строка 33: any

### src/features/manage-script-requests/ui/ScriptViewer/**tests**/ScriptViewer.test-model.tsx

- Строка 10: never-cast

### src/features/manage-script-requests/ui/ScriptViewer/**tests**/ScriptViewer.test.tsx

- Строка 7: any

### src/features/manage-traffic-restriction/lib/**tests**/restrictionMutations.test.ts

- Строка 8: any
- Строка 16: any
- Строка 19: any
- Строка 20: any
- Строка 21: any
- Строка 29: never-cast
- Строка 30: never-cast

### src/features/manage-traffic-restriction/ui/TrafficRestrictionForm/**tests**/TrafficRestrictionForm.test.tsx

- Строка 29: any
- Строка 53: any
- Строка 64: any
- Строка 67: any
- Строка 70: any

### src/features/run-shard-replication/lib/**tests**/useShardReplicationMutation.test.ts

- Строка 9: any
- Строка 16: any
- Строка 19: any
- Строка 20: any

### src/features/start-process-group/api/**tests**/fetch.test.ts

- Строка 10: never-cast

### src/features/start-process-group/ui/ConfirmProcessGroup/**tests**/ConfirmProcessGroup.test.tsx

- Строка 12: any
- Строка 17: any

### src/features/start-process-group/ui/StartProcessGroupForm/**tests**/StartProcessGroupForm.test.tsx

- Строка 12: any
- Строка 19: any

### src/features/start-process-group/ui/StartProcessModal/**tests**/StartProcessModal.test.tsx

- Строка 21: any
- Строка 34: any

### src/features/sync-node-dictionaries/lib/**tests**/useNodeDictionariesMutation.test.ts

- Строка 6: any
- Строка 12: any
- Строка 16: any

### src/features/transfer-clients/api/**tests**/fetch.test.ts

- Строка 7: never-cast

### src/features/transfer-clients/ui/**tests**/TransferClientsForm.test.tsx

- Строка 20: any
- Строка 27: any
- Строка 37: any
- Строка 43: any
- Строка 59: any
- Строка 63: any

### src/pages/cluster-management/ui/NodeManagementTab/**tests**/NodeManagementTab.test.tsx

- Строка 29: any
- Строка 33: any

### src/pages/geo-balancing/ui/**tests**/GeoBalancingPage.test.tsx

- Строка 19: any
- Строка 25: any
- Строка 35: any
- Строка 50: any
- Строка 95: any
- Строка 102: any

### src/pages/node-balancing/ui/**tests**/NodeBalancingPage.test.tsx

- Строка 6: any

### src/shared/api/**tests**/apiProxy.test.ts

- Строка 81: any
- Строка 118: any
- Строка 119: any
- Строка 131: any
- Строка 132: any

### src/shared/api/**tests**/services.test.ts

- Строка 187: any
- Строка 214: any
- Строка 215: any
- Строка 222: any
- Строка 223: any

### src/shared/lib/**tests**/useConfirm.test.tsx

- Строка 69: any
- Строка 83: any

### src/shared/lib/**tests**/useSelectAll.test.tsx

- Строка 96: any

### src/shared/lib/**tests**/useTaskColumns.test.tsx

- Строка 32: any

### src/shared/lib/modal/**tests**/useConfirm.test.tsx

- Строка 14: any

### src/shared/lib/modal/**tests**/useInfoModal.test.tsx

- Строка 9: any

### src/shared/lib/modal/**tests**/useModal.test.ts

- Строка 18: never-cast

### src/shared/lib/table/plugins/**tests**/useEmptyState.test.tsx

- Строка 50: never-cast

### src/shared/lib/table/plugins/**tests**/useExpandedRow.test.tsx

- Строка 48: never-cast

### src/shared/lib/table/plugins/**tests**/usePinnedColumns.test.tsx

- Строка 109: never-cast
- Строка 118: never-cast
- Строка 133: never-cast
- Строка 141: never-cast

### src/shared/lib/table/plugins/**tests**/useSorting.test.tsx

- Строка 26: never-cast

### src/shared/lib/table/plugins/**tests**/useStyledRow.test.tsx

- Строка 50: never-cast

### src/shared/lib/table/runtime/**tests**/resolveContributions.test.ts

- Строка 20: never-cast
- Строка 34: never-cast
- Строка 35: never-cast

### src/shared/ui/ServiceTabs/ServiceTabs.tsx

- Строка 58: never-cast
- Строка 72: never-cast

### src/shared/ui/Table/columns/**tests**/ExpandColumn.test.tsx

- Строка 24: any
- Строка 26: any
- Строка 35: any
- Строка 37: any
- Строка 45: any
- Строка 47: any

### src/shared/ui/Tooltip/**tests**/Tooltip.test.tsx

- Строка 7: any

### src/widgets/clear-transfer-task-tab/ui/**tests**/ClearTransferTask.test.tsx

- Строка 20: any
- Строка 45: any

### src/widgets/create-transfer-task-tab/ui/**tests**/CreateTransferTask.test.tsx

- Строка 38: any
- Строка 83: any
- Строка 87: any

### src/widgets/manage-feature-applications-tab/ui/ManageFeatureApplicationsTab/**tests**/ManageFeatureApplicationsTab.test.tsx

- Строка 83: any

### src/widgets/manage-features-tab/ui/ManageFeaturesTab/**tests**/ManageFeaturesTab.test.tsx

- Строка 87: any

### src/widgets/manage-script-requests-tab/ui/**tests**/ManageScriptRequest.test.tsx

- Строка 53: any

### src/widgets/od-history-tab/ui/**tests**/OdHistory.test.tsx

- Строка 10: any
- Строка 29: any
- Строка 41: any
- Строка 47: any

### src/widgets/process-history-tab/ui/**tests**/ProcessHistory.test.tsx

- Строка 10: any
- Строка 32: any
- Строка 47: any
- Строка 53: any

### src/widgets/revision-history-tab/ui/RevisionHistoryTab/**tests**/RevisionHistoryTab.test.tsx

- Строка 19: any
- Строка 34: any
- Строка 44: any
- Строка 50: any
- Строка 65: any
- Строка 66: any
- Строка 86: any

### src/widgets/run-revision-tab/ui/**tests**/RunRevisionTab.test.tsx

- Строка 19: any
- Строка 45: any
- Строка 73: any
- Строка 85: any

### src/widgets/shard-item/ui/LoadTab/**tests**/LoadTab.test.tsx

- Строка 26: any

### src/widgets/shard-item/ui/NodeStatusGrid/**tests**/NodeStatusGrid.test.tsx

- Строка 31: never-cast

### src/widgets/shard-item/ui/RangesTab/**tests**/RangesTab.test.tsx

- Строка 43: any
- Строка 51: any

### src/widgets/start-process-tab/ui/**tests**/StartProcessTab.test.tsx

- Строка 6: any
- Строка 28: any
- Строка 60: any
- Строка 61: any
- Строка 62: any

### src/widgets/transfer-clients-tab/ui/**tests**/TransferClients.test.tsx

- Строка 20: any
- Строка 44: any

### src/widgets/transfer-history-tab/ui/**tests**/TransferHistory.test.tsx

- Строка 16: any
- Строка 32: any
- Строка 35: any
- Строка 53: any
