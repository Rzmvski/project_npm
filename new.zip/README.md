# TCPF Support Admin UI

Административный интерфейс ТКП для операционных и платформенных задач: закрытие операционного дня, запуск групп процессов, управление индексами, шардами,
переносами клиентов, скриптами, фичами, репликацией и гео-балансировкой.

## Быстрый старт

Для проекта используется Node.js из `.nvmrc` (24.11.1) и pnpm 9 или новее. В интерактивных терминалах nvm активирует версию по умолчанию; в уже открытом терминале выполните `nvm use`.

```bash
pnpm install
pnpm run dev
```

API-клиенты подключены как локальные `link:` dependencies (протокол pnpm). Ожидаемое расположение каталогов:

```text
Documents/
├── arm/
└── @sber-pprb-tkp/
    ├── tcpf-platform-admin-api/
    └── tcpf-support-admin-api/
```

Из `arm/package.json` им соответствуют пути `link:../@sber-pprb-tkp/...`. Команда `pnpm run login:nexus` нужна только для остальных приватных пакетов, если они
отсутствуют в локальном pnpm store.

`dev` через `concurrently` поднимает Vite и stateful Express mock API. В терминале процессы помечены как `WEB` и `API`; при остановке одного завершается второй.
Интерфейс доступен на адресе, который напечатает Vite (обычно `http://localhost:5173`), API — на `http://127.0.0.1:3001`. `dev:mock` оставлен как алиас.

Для работы с реальными локальными сервисами:

```bash
pnpm run dev:server
```

Команда `dev:server` включает Vite mode `dev`: запросы `/platform/*` и `/tkp/*` проксируются на порты из `.env.dev` (8091 и 8092). Основная команда `dev`
включает mode `mock`: оба префикса и `/config/*` направляются на Express-сервер.

## Команды

| Команда                      | Назначение                        |
| ---------------------------- | --------------------------------- |
| `pnpm run dev`               | Vite + Express через concurrently |
| `pnpm run dev:mock`          | Алиас для `pnpm run dev`          |
| `pnpm run dev:web`           | Только Vite в mock-режиме         |
| `pnpm run dev:api`           | Express mock API с watch          |
| `pnpm run start:api`         | Express mock API без watch        |
| `pnpm run dev:server`        | Vite с proxy на реальные API      |
| `pnpm test`                  | Vitest run                        |
| `pnpm run test:coverage`     | Vitest с coverage                 |
| `pnpm run lint`              | Oxlint + Stylelint + Oxfmt        |
| `pnpm run typecheck`         | Проверка типов через TypeScript 7 |
| `pnpm run lint:architecture` | Проверка FSD через Steiger        |
| `pnpm run build`             | Production-сборка через Vite+     |
| `pnpm run validate`          | Полная последовательная проверка  |

## Технологии и структура

Приложение использует React 19, TypeScript, Vite, React Router 6, TanStack Query 5, React Hook Form, Zod, VUIK и SCSS Modules. Код организован по слоям
Feature-Sliced Design:

```text
app → pages → widgets → features → entities → shared
```

Redux и каталог `src/shared/deprecated` удалены. Серверным состоянием владеет TanStack Query, формами — React Hook Form, локальным UI-состоянием — React.

Два OpenAPI-контракта и соответствующие сгенерированные клиенты:

- `apis/openapi.yml` — TCPF support admin API 15.0.0;
- `apis/openapi2.yml` — TCPF platform admin API 2.1.

Подробные правила, архитектура, mock API и актуальные результаты аудита находятся в [`docs/README.md`](docs/README.md).
