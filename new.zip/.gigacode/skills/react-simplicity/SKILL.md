---
name: react-simplicity
description: Audit or simplify a React component or hook by tracing state ownership and removing unnecessary synchronization while preserving behavior.
priority: 8
---

# React simplicity audit

Use when the requested change is a React/TypeScript refactor, when a component or hook is difficult to follow, or when a React Doctor finding concerns effects,
derived state, refs, memoization, or excess abstraction. Do not use for a feature that needs new behavior without a simplification goal.

## Procedure

1. Read the target component/hook, all direct callers, its tests, and the relevant `GIGACODE.md` / architecture guidance. Record externally visible behavior and the
   current owner of each piece of state.
2. For every state value, classify it as server state, form state, local interaction state, or a value derivable from props/state. In this project use TanStack Query
   for server state, React Hook Form + Zod for forms, and React state for local UI state.
3. Inspect each Effect: name the external system it synchronizes with. If the Effect only mirrors React state, computes a value, responds to a user action, or resets
   derived state, move that work to render, an event handler, or the existing form/query lifecycle as appropriate.
4. Inspect each ref, memo, callback, custom hook, context, and reducer. Keep it only when it serves DOM access, mutable non-rendering data, measured expensive work,
   stable identity required by a consumer, shared state, or a distinct reusable responsibility. Do not introduce abstractions just to reduce line count.
5. Make the smallest change in the owning FSD slice. Preserve public props, query behavior, validation, error handling, accessibility, and loading/empty/error/pending
   states. Do not combine simplification with unrelated formatting or redesign.
6. Update or add a focused test for changed observable behavior. Avoid tests that merely assert implementation choices such as the absence of a hook.

## Validation

- Run the focused Vitest file and focused Oxlint for changed TS/TSX files.
- Run `pnpm run typecheck` if types or public contracts changed.
- Run `pnpm run lint:architecture` if imports or slice ownership changed.
- For visible UI behavior, follow the project's browser-verification procedure.

## Result

Report the state/effect simplification, behavior preserved, changed files, exact checks and results, and any behavior that could not be verified. If no simplification
is justified, explain the evidence and leave the implementation unchanged.
