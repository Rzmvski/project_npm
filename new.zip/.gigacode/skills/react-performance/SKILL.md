---
name: react-performance
description: Investigate a reported React UI performance issue, establish a reproducible baseline, and implement only changes supported by profiling or build evidence.
priority: 7
---

# React performance investigation

Use for a user-reported slowdown, a measured regression, or a task explicitly asking for performance optimization. Do not optimize speculative rerenders.

## Procedure

1. Get the affected route, interaction, data size, and expected response time from the task or existing code. Reproduce the scenario before changing code. Record browser,
   viewport, dataset/mock state, and the observable symptom.
2. Trace the interaction through the route, components, query hooks, and API/mock calls. Check whether latency is in network/request sequencing, React rendering, DOM
   size, or bundle loading. Do not assume a React render is the cause.
3. For request sequencing, identify dependencies. Start independent work concurrently only if doing so preserves auth, error handling, loading states, and API semantics.
   Use TanStack Query and existing query keys; do not add SWR or a second request cache.
4. For rendering, use available browser/React profiling evidence. Inspect broad state subscriptions, expensive work in render, large lists, and unnecessary DOM. Keep
   memoization only when profiling shows useful work is avoided and dependencies remain correct. Use the existing `@tanstack/react-virtual` only when list size and
   measured rendering justify virtualization.
5. For bundle concerns, inspect Vite's existing output/build configuration. The repo has `pnpm run build` and `pnpm run bundle:analyze`; the latter invokes npx, so
   use it only if its package is already available or the user authorizes downloading it. Do not apply Next.js/RSC/server-cache guidance.
6. Implement one targeted optimization. Add a regression test for behavior or request semantics; performance assertions should be stable and based on the measured
   bottleneck, not arbitrary timing thresholds.
7. Repeat the exact baseline scenario under the same conditions. Compare the metric that identified the issue and check for interaction, accessibility, or memory
   regressions.

## Validation

Run focused tests and Oxlint; run `pnpm run typecheck` for type changes. For architectural/import changes run `pnpm run lint:architecture`. Run `pnpm run build` for
bundle/build changes. Use browser verification for UI changes.

## Result

Report the reproducible symptom, baseline and post-change evidence, cause, targeted fix, exact checks, and remaining uncertainty. Do not claim a speedup if the same
scenario was not measured before and after.
