---
name: verify-in-browser
description: Launch the app with the mock API and verify a UI change in a real browser using browser tools available in the current GigaCode session — render, console errors, network, interactions, responsive layout — then report proof. Use after any change visible in the browser.
priority: 10
---

# Verify in browser

Use when a change is observable in the browser (component, SCSS, route, mock API response). Skip for types, tests or tooling — run commands instead.

## Steps

1. **Server.** Check whether the dev server is already running. If not, start `pnpm run dev` (Vite on `5173` + mock API on `3001`) using the current runtime's
   supported background-process mechanism and wait until both services respond. Do not start a second copy.
2. **Open.** Use the browser navigation and accessibility snapshot tools available in this session to open the affected route and read its text and structure;
   prefer the accessibility tree over screenshots.
3. **Errors.** Inspect browser console and network tools when available. Confirm there are no uncaught errors or failed mock API requests caused by the change.
4. **Interact.** Exercise the changed scenario using available browser interaction tools, then inspect the result, including
   loading/empty/error/pending states where applicable. To reset mock state: `curl -X POST http://127.0.0.1:3001/__mock/reset`.
5. **Layout.** For layout or style changes use `browser_resize` (e.g. 1440×900 and 1024×768) and check the page next to the sidebar with long Russian strings.
6. **Fix loop.** If something is wrong, read the source, fix it, reload and repeat from step 3.
7. **Proof.** Capture the final state with an available screenshot tool for visual changes; for API changes report the relevant network request. If a required
   browser capability is unavailable, state the exact missing capability and the checks that remain unverified.

Browser-side script evaluation, if provided, is for inspection only (computed styles, DOM state) — never implement the fix through it.

## Report

Route checked, scenario performed, console/network result, screenshot or request as evidence, and anything not verified with the reason. Leave the dev server
running only if the user is actively working with it; otherwise stop the process you started using the runtime-supported mechanism.
