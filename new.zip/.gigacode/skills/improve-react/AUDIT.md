# React audit guide

Use these categories as investigation prompts, not as a checklist that requires a finding in every area. Confirm each issue in project code and describe a concrete
user or maintenance consequence.

## 1. Correctness and async behavior

Inspect state transitions, effect dependencies, callback freshness, stable list keys, controlled form values, numeric conditional rendering, stale query data, mutation
rollback, cancellation, and async races. Follow TanStack Query conventions and existing error/loading state patterns. A static pattern is not a defect unless the
relevant runtime path can produce incorrect behavior.

## 2. Performance

Identify hot interactions and large/frequently rendered surfaces first. Look for broad subscriptions, repeated expensive work, request waterfalls, unnecessary DOM,
large lists, and bundle cost. Treat memoization as an optimization hypothesis; request browser/React profiling evidence before prescribing it. Consider
`@tanstack/react-virtual` only for measured large-list costs.

## 3. Accessibility and interaction

Inspect semantic controls, accessible names, label associations, keyboard reachability, focus visibility/order/return, dialog dismissal, disabled/pending states,
announced status, contrast, zoom, and reduced motion. Verify context: a technically present label may still misdescribe an action. For UI changes, use available browser
tools; if unavailable, mark runtime behavior as unverified.

## 4. Security and access control

Trace untrusted input to HTML, URL, file, redirect, logging, storage, and privileged action sinks. Inspect route guards and mutation authorization paths. Check for
secrets, unsafe schemes, raw HTML, unsafe redirects, unvalidated files, and accidental exposure. State the attack path and affected boundary; do not report generic
risks without evidence.

## 5. Maintainability and architecture

Inspect FSD layer direction, slice ownership, public exports, large components with multiple responsibilities, repeated domain logic, boolean-prop combinations,
overloaded contexts, and effects used for user actions or derived values. Do not split files or add hooks only to satisfy size/abstraction preferences.

## Prioritization

- **High:** confirmed data loss, wrong privileged action, broken shared workflow, security/accessibility barrier on a critical path, or frequent severe latency.
- **Medium:** confirmed defect or repeated friction on a bounded route/state, or measurable performance cost with a targeted fix.
- **Low:** safe maintainability improvement or minor polish with clear scope and no urgent user impact.
- **Opportunity:** additive improvement without a confirmed defect. State the evidence needed before implementation.

For each item cite `path:line`, state the observed code/path, consequence, confidence, and smallest reasonable repair. Keep duplicate findings together.
