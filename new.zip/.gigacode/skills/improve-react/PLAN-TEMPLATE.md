# <Imperative change title>

- **Status:** TODO
- **Priority:** HIGH | MEDIUM | LOW
- **Finding:** `path/to/file.tsx:line` or manual audit
- **Scope:** <specific files/slices>

## Problem and evidence

Describe the reproducible user/maintenance impact and cite the relevant current code. Separate confirmed facts from assumptions.

## Target behavior

State what the user or caller should observe after the change. Preserve unrelated behavior and public contracts.

## Existing pattern

Name a concrete project exemplar with path and the convention to follow (FSD owner, API, styling, error handling, tests).

## Steps

1. <file> — <bounded change>.
2. <test file> — <observable behavior to cover>.
3. Re-read the diff and remove unrelated changes.

## Verification

- Focused test: <real command and file selector>.
- Static checks: <project commands justified by scope>.
- UI scenario: <route, interaction, state, and viewport, if applicable>.
- Done when: <observable acceptance criteria>.

## Risks and blockers

List only evidence-based risks or write `None identified`.
