---
name: react-composition
description: Refactor a React component API when booleans and conditionals encode multiple modes, using explicit variants or composition while preserving callers.
priority: 7
---

# React component composition

Use when a component has several interacting boolean props, repeated mode-specific branches, or callers need to inject content/behavior. Do not refactor a component
solely to adopt a pattern.

## Procedure

1. Read the component, every caller, related tests, and nearby components in the same UI layer. List the current modes and which props are meaningful in each mode.
2. Confirm the API problem with a concrete example: invalid prop combinations, repeated conditional logic, inability to compose content, or a change that requires
   editing a central component for every new mode.
3. Choose the smallest suitable structure:
   - Use a discriminated `variant` prop for a closed set of modes with distinct configuration.
   - Use `children` or a focused slot when callers need to compose presentation.
   - Extract a subcomponent when a branch has its own meaningful behavior or state.
   - Use compound components/context only when multiple coordinated parts share state and callers benefit from controlling their arrangement.
4. Keep prop types mutually exclusive where modes cannot coexist. Preserve defaults only when they are unambiguous; do not silently accept ignored props.
5. Migrate all call sites in the same change. Preserve accessible names, semantic markup, keyboard behavior, styling tokens, and state feedback. Keep business logic in its
   owning FSD feature/entity rather than moving it into a display wrapper.
6. Add/update tests for each supported mode and at least one invalid or absent configuration where relevant. Assert user-visible behavior, not internal component
   arrangement.

## Project constraints

- Reuse VUIK and `shared/ui` before creating a reusable primitive.
- Keep styling in SCSS Modules and follow `docs/design-system.md`.
- Keep cross-slice usage behind public `index.ts` exports.
- This is a Vite client app: do not introduce Next.js APIs, server components, Tailwind/shadcn, or a generic component framework.

## Validation and result

Run the focused Vitest file, Oxlint, and typecheck when prop/type contracts changed. Run architecture lint for import/slice changes and browser verification for visible
changes. Report the before/after API, migrated callers, exact command results, and any breaking change or unverified caller.
