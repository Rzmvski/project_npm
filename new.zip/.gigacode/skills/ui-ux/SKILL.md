---
name: ui-ux
description: Audit, design, or implement a TCPF support admin interface with clear operational hierarchy, accessible interactions, responsive behavior, and project components.
priority: 7
---

# TCPF admin UI design workflow

Use for a new or changed screen, component, layout, form, table, empty state, or visual UX review. For code implementation, coordinate with `react-ui-change`.

## Procedure

1. Read `GIGACODE.md`, `docs/README.md`, `docs/design-system.md`, the route and its owning FSD slices, relevant tests, and the existing VUIK/shared components and
   design tokens. Avoid reading unrelated design docs.
2. Describe the user task, primary action, critical information, and failure/destructive states. For a redesign/review, inspect the existing UI first and list concrete
   issues tied to hierarchy, discoverability, errors, accessibility, or responsive behavior.
3. Sketch the information order before coding: page title/context, filters or scope, primary action, result/status content, secondary actions. Keep destructive actions
   visually distinct and require confirmation where the existing project pattern does so.
4. Select existing VUIK and `shared/ui` components first. Use the project's SCSS Modules and variables in `src/shared/styles`. Do not add Tailwind, shadcn, arbitrary
   color/spacing scales, or a parallel component system.
5. Implement semantic HTML and explicit loading, empty, error, disabled, and pending states. All controls need accessible names; keyboard users need visible focus,
   logical order, and reachable actions. Never communicate status by color alone.
6. Check realistic content: long Russian labels, IDs/URLs, empty and large tables, error messages, and content inside the app next to its sidebar. Use wrapping by
   default; if truncation is necessary, make the full value available on keyboard and pointer interaction.
7. For responsive work, identify the actual content container and sidebar width. Verify desktop and the compact breakpoint where layout changes; ensure controls and the
   final form action remain reachable without competing nested scroll areas.

## Validation

Run focused RTL tests, Oxlint, Stylelint for SCSS, and Oxfmt on changed files. For visible changes use the browser-verification skill: inspect the accessibility tree,
exercise the task, check console/network errors, and capture the final visual state when browser tools are available. If they are unavailable, report that specific
limitation and provide the route and manual scenario; do not claim visual verification.

## Result

For implementation, report changed files, the user-visible behavior, exact validation results, and unverified viewport/state. For critique, report findings in priority
order with the affected screen/state and a concrete correction; separate defects from optional polish.
