/**
 * Контракт мока берётся из сгенерированных SDK `@sber-pprb-tkp/*`, а не
 * дублируется вручную.
 *
 * Для каждой операции SDK мок выясняет HTTP-метод, путь, query- и
 * header-параметры, тело запроса, вид ответа и то, отдаётся ли операция как
 * SSE. Для этого `<operation>Raw` вызывается с параметрами-маркерами и
 * подменённым `fetch`: запрос, который SDK отправил бы бэкенду, перехватывается.
 * Тела читаются и пишутся через `<Dto>FromJSON`/`<Dto>ToJSON` того же SDK,
 * поэтому wire-имена и форматы полей совпадают с тем, что ждёт UI.
 */
import * as platform from '@sber-pprb-tkp/tcpf-platform-admin-api'
import * as support from '@sber-pprb-tkp/tcpf-support-admin-api'

type Sdk = Readonly<Record<string, unknown>>

const SDKS: readonly Sdk[] = [platform, support]

// oxlint-disable-next-line @typescript-eslint/no-explicit-any -- конструкторы сгенерированных API
export type ApiClass<A> = abstract new (...args: any[]) => A

/** Имена операций API-класса: у каждой есть пара `<name>` и `<name>Raw`. */
export type OperationName<A> = {
  [K in keyof A & string]: K extends `${infer N}Raw` ? (N extends keyof A ? N : never) : never
}[keyof A & string]

/** Модель успешного ответа операции — то, что возвращает метод SDK. */
export type OperationResult<A, N extends OperationName<A>> = A[N] extends (
  ...args: never[]
) => Promise<infer R>
  ? R
  : never

type NoParameters = Record<never, never>

type RawParameters<A, N extends string> = `${N}Raw` extends keyof A
  ? A[`${N}Raw`] extends (first: infer P, ...rest: never[]) => unknown
    ? // У операций без параметров первым идёт initOverrides (RequestInit | функция).
      [Extract<P, (...args: never[]) => unknown>] extends [never]
      ? P
      : NoParameters
    : NoParameters
  : NoParameters

/**
 * Параметры в том виде, в каком они приходят по сети: path, query и header —
 * строки, тело — модель SDK, прочитанная `<Dto>FromJSON`.
 */
type Wire<T> = T extends Date | string | number | boolean
  ? string
  : T extends readonly (infer E)[]
    ? E extends Date | string | number | boolean
      ? string
      : T
    : T

export type OperationInput<A, N extends OperationName<A>> = {
  [K in keyof RawParameters<A, N>]: Wire<RawParameters<A, N>[K]>
}

type Converter = (value: unknown) => unknown

export interface Codec {
  readonly toJSON: Converter
  readonly fromJSON: Converter
}

const identity: Codec = { toJSON: (value) => value, fromJSON: (json) => json }

type Shape = 'single' | 'array' | 'map'

const converter = (sdk: Sdk, name: string): Converter => {
  const candidate = sdk[name]
  if (typeof candidate !== 'function') throw new Error(`SDK не экспортирует ${name}`)
  return candidate as Converter
}

/** Ошибка чтения тела запроса моделью SDK; Spring отвечает на такое 400. */
export class InvalidBody extends Error {
  readonly status = 400
}

const codecFor = (sdk: Sdk, dto: string, shape: Shape): Codec => {
  const lift =
    (convert: Converter): Converter =>
    (value) => {
      if (value == null) return value
      if (shape === 'array') return (value as unknown[]).map((item) => convert(item))
      if (shape === 'map') {
        return Object.fromEntries(
          Object.entries(value as object).map(([key, item]) => [key, convert(item)]),
        )
      }
      return convert(value)
    }
  const fromJSON = converter(sdk, `${dto}FromJSON`)
  // `instanceOf<Dto>` проверяет обязательные поля модели; у enum его нет.
  const isValid = sdk[`instanceOf${dto}`] as ((value: unknown) => boolean) | undefined
  const read: Converter = (json) => {
    let model: unknown
    try {
      model = fromJSON(json)
    } catch (error) {
      throw new InvalidBody(`${dto}: ${error instanceof Error ? error.message : String(error)}`)
    }
    const valid = (() => {
      try {
        return !isValid || isValid(model)
      } catch {
        return false
      }
    })()
    if (!valid) throw new InvalidBody(`${dto}: тело не соответствует модели`)
    return model
  }
  return { toJSON: lift(converter(sdk, `${dto}ToJSON`)), fromJSON: lift(read) }
}

/** Кодек ответа — по трансформеру `JSONApiResponse`, который создаёт SDK. */
const responseCodec = (sdk: Sdk, transformer: unknown): Codec => {
  const source = String(transformer)
  const dto = /(\w+)FromJSON\b/.exec(source)?.[1]
  if (!dto) return identity
  const shape = /mapValues/.test(source) ? 'map' : /\.map\(/.test(source) ? 'array' : 'single'
  return codecFor(sdk, dto, shape)
}

/** Кодек тела запроса — по вызову `<Dto>ToJSON(requestParameters…)` в SDK. */
const requestCodec = (sdk: Sdk, source: string, key: string): Codec => {
  const parameter = String.raw`requestParameters(?:\[['"]${key}['"]\]|\.${key})`
  const single = new RegExp(String.raw`(\w+)ToJSON\)?\(${parameter}`).exec(source)
  if (single) return codecFor(sdk, single[1], 'single')
  const array = new RegExp(String.raw`${parameter}!?\.map\((?:[\w$]+\.)?(\w+)ToJSON\)`).exec(
    source,
  )
  return array ? codecFor(sdk, array[1], 'array') : identity
}

export type ResponseKind = 'json' | 'text' | 'void'

export interface ResolvedOperation {
  /** `ClusterManagementServiceApi.getShards` */
  readonly id: string
  readonly method: string
  /** Путь в синтаксисе Express: `/shard/:ids/nodes`. */
  readonly path: string
  /** Путь в синтаксисе OpenAPI: `/shard/{ids}/nodes`. */
  readonly template: string
  /** В SDK есть `<operation>Stream`: бэкенд отдаёт операцию как `text/event-stream`. */
  readonly sse: boolean
  readonly response: ResponseKind
  readonly responseCodec: Codec
  readonly pathKeys: readonly string[]
  /** Имя query-параметра → ключ параметра операции. */
  readonly query: ReadonlyMap<string, string>
  /** Имя заголовка (lower case) → ключ параметра операции. */
  readonly headers: ReadonlyMap<string, string>
  readonly body?: { readonly key: string; readonly codec: Codec }
}

const MARKER = /__(\d+)__/g

/**
 * Значение-маркер параметра. Любое обращение к нему (`String()`,
 * `.toISOString()`, `.join()`, `<Dto>ToJSON` по полям) даёт строку-маркер, по
 * которой видно, куда SDK положил параметр: в путь, query, заголовок или тело.
 */
const markerValue = (text: string): unknown => {
  const self: unknown = new Proxy(() => text, {
    get: (_target, property) => {
      if (property === Symbol.toPrimitive) return () => text
      if (property === 'then') return undefined
      return self
    },
    apply: () => text,
  })
  return self
}

const sdkOf = (apiClass: object) => {
  const sdk = SDKS.find((candidate) => Object.values(candidate).includes(apiClass))
  if (!sdk) throw new Error('API-класс не принадлежит SDK @sber-pprb-tkp/*')
  return sdk
}

const sourceOf = (api: Readonly<Record<string, unknown>>, name: string) =>
  [`${name}RequestOpts`, `${name}Raw`]
    .map((method) => api[method])
    .filter((method) => typeof method === 'function')
    .map(String)
    .join('\n')

/** Разбирает операцию SDK: метод, путь, параметры, тело и вид ответа. */
export const resolveOperation = async <A extends object>(
  apiClass: ApiClass<A> & { name: string },
  name: OperationName<A>,
): Promise<ResolvedOperation> => {
  const sdk = sdkOf(apiClass)
  const keys: string[] = []
  const keyOf = (text: string) => {
    const index = /__(\d+)__/.exec(text)?.[1]
    return index === undefined ? undefined : keys[Number(index)]
  }
  const parameters = new Proxy(
    {},
    {
      get: (_target, key) => {
        // У операций без параметров объект попадает в initOverrides, и SDK
        // ждёт его через await: он не должен выглядеть как thenable.
        if (typeof key !== 'string' || key === 'then') return undefined
        if (!keys.includes(key)) keys.push(key)
        return markerValue(`__${keys.indexOf(key)}__`)
      },
    },
  )

  const query = new Map<string, string>()
  const queryParamsStringify = (params: object) => {
    for (const [queryName, value] of Object.entries(params)) {
      const key = keyOf(String(value))
      if (key) query.set(queryName, key)
    }
    return ''
  }

  let captured: { url: string; init: RequestInit } | undefined
  const fetchApi = async (url: Parameters<typeof fetch>[0], init?: RequestInit) => {
    captured = { url: String(url), init: init ?? {} }
    return new Response('null', { headers: { 'content-type': 'application/json' } })
  }

  const Configuration = sdk.Configuration as new (parameters: object) => object
  const Api = apiClass as unknown as new (configuration: object) => Record<string, unknown>
  const api = new Api(new Configuration({ basePath: '', fetchApi, queryParamsStringify }))
  const raw = api[`${name}Raw`] as (parameters: object) => Promise<unknown>
  const response = await raw.call(api, parameters)
  if (!captured) throw new Error(`SDK не отправил запрос для ${apiClass.name}.${name}`)

  const [path] = captured.url.split('?')
  const pathKeys = [...path.matchAll(MARKER)].map(([, index]) => keys[Number(index)])
  const headers = new Map<string, string>()
  for (const [headerName, value] of new Headers(captured.init.headers)) {
    const key = keyOf(value)
    if (key) headers.set(headerName, key)
  }
  const bound = new Set([...pathKeys, ...query.values(), ...headers.values()])
  const bodyKey =
    captured.init.body === undefined ? undefined : keys.find((key) => !bound.has(key))

  const source = sourceOf(api, name)
  const kind: ResponseKind = /TextApiResponse/.test(source)
    ? 'text'
    : response instanceof platform.VoidApiResponse ||
        response instanceof support.VoidApiResponse
      ? 'void'
      : 'json'
  const sseClass = sdk[`${apiClass.name}Sse`] as { prototype: object } | undefined

  return {
    id: `${apiClass.name}.${name}`,
    method: String(captured.init.method ?? 'GET').toUpperCase(),
    path: path.replace(MARKER, (_, index: string) => `:${keys[Number(index)]}`),
    template: path.replace(MARKER, (_, index: string) => `{${keys[Number(index)]}}`),
    sse: Boolean(sseClass && `${name}Stream` in sseClass.prototype),
    response: kind,
    responseCodec:
      kind === 'json'
        ? responseCodec(sdk, (response as { transformer?: unknown }).transformer)
        : identity,
    pathKeys,
    query,
    headers,
    body: bodyKey ? { key: bodyKey, codec: requestCodec(sdk, source, bodyKey) } : undefined,
  }
}

/** Все операции API-класса SDK — для проверки полноты мока. */
export const operationNames = <A extends object>(apiClass: ApiClass<A>): OperationName<A>[] => {
  const names: OperationName<A>[] = []
  for (const key of Object.getOwnPropertyNames(apiClass.prototype)) {
    if (key.endsWith('Raw')) names.push(key.slice(0, -'Raw'.length) as OperationName<A>)
  }
  return names
}

/** API-классы обоих SDK (без SSE-наследников). */
export const apiClasses = () =>
  SDKS.flatMap((sdk) => Object.values(sdk)).filter(
    (value): value is ApiClass<object> & { name: string } =>
      typeof value === 'function' &&
      value.name.endsWith('Api') &&
      Object.getOwnPropertyNames(value.prototype).some((key) => key.endsWith('Raw')),
  )
