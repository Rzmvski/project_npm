export default {
  extends: ['stylelint-config-standard-scss', 'stylelint-config-recommended-scss'],
  rules: {
    'selector-class-pattern': [
      '^[a-z][a-zA-Z0-9]*$',
      { message: 'CSS Modules classes must use camelCase' },
    ],
    'scss/at-use-no-unnamespaced': null,
    'scss/dollar-variable-pattern': '^[a-z][a-z0-9-]*$',
    'custom-property-pattern': '^app-[a-z0-9-]+$',
    'color-hex-length': 'long',
    'color-no-hex': true,
    'function-disallowed-list': ['rgb', 'rgba', 'hsl', 'hsla'],
    'declaration-no-important': true,
    'no-descending-specificity': null,
    'selector-pseudo-class-no-unknown': [true, { ignorePseudoClasses: ['global'] }],
  },
  ignoreFiles: ['dist/**', 'node_modules/**'],
}
