export const CATALOG_PAGE_SIZES = [10, 20, 50] as const
export const MONITORING_PAGE_SIZES = [25, 50, 100] as const

export interface PaginationSearchInput {
  page?: unknown
  size?: unknown
  sort?: unknown
}

export interface PaginationSearch {
  page: number
  size: number
  sort: string
}

interface PaginationSearchConfig {
  defaultSize: number
  defaultSort: string
  sizeOptions: readonly number[]
}

const SORT_PATTERN = /^(asc|desc):[a-z][A-Za-z0-9]*$/

export function parseOptionalSearchString(value: unknown): string | undefined {
  return typeof value === 'string' && value.trim() ? value.trim() : undefined
}

export function parsePaginationSearch(
  search: PaginationSearchInput,
  { defaultSize, defaultSort, sizeOptions }: PaginationSearchConfig,
): PaginationSearch {
  const page = Number(search.page)
  const size = Number(search.size)
  const sort = parseOptionalSearchString(search.sort)

  return {
    page: Number.isFinite(page) ? Math.max(0, page) : 0,
    size: sizeOptions.includes(size) ? size : defaultSize,
    sort: sort && SORT_PATTERN.test(sort) ? sort : defaultSort,
  }
}
