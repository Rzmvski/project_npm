import { describe, expect, it } from 'vitest'

import {
  CATALOG_PAGE_SIZES,
  parseOptionalSearchString,
  parsePaginationSearch,
} from './pagination'

const config = {
  defaultSize: 20,
  defaultSort: 'asc:processName',
  sizeOptions: CATALOG_PAGE_SIZES,
}

describe('pagination search', () => {
  it('normalizes page, size and direction-first camelCase sort', () => {
    expect(
      parsePaginationSearch({ page: '2', size: '50', sort: 'desc:createdAt' }, config),
    ).toEqual({ page: 2, size: 50, sort: 'desc:createdAt' })
  })

  it('uses configured defaults for invalid values', () => {
    expect(
      parsePaginationSearch({ page: -3, size: 25, sort: 'createdAt,desc' }, config),
    ).toEqual({ page: 0, size: 20, sort: 'asc:processName' })
  })

  it('trims optional strings and removes empty values', () => {
    expect(parseOptionalSearchString('  active  ')).toBe('active')
    expect(parseOptionalSearchString('   ')).toBeUndefined()
    expect(parseOptionalSearchString(123)).toBeUndefined()
  })
})
