import { modal } from '@v-uik/base'
import { useCallback } from 'react'

import { TextDetailsModal } from '@/shared/ui'

export interface TextDetailsModalOptions {
  title: string
  subtitle?: string
  text: string
}

let modalSequence = 0

export const useTextDetailsModal = () =>
  useCallback((options: TextDetailsModalOptions) => {
    const modalId = `text-details-modal-${modalSequence++}`
    const close = () => modal.close(modalId)

    modal.show(modalId, {
      width: 720,
      content: <TextDetailsModal {...options} onClose={close} />,
    } as unknown as Parameters<typeof modal.show>[1])
  }, [])
