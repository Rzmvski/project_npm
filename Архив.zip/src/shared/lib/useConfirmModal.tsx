import { modal } from '@v-uik/base'
import { useCallback } from 'react'

import { ConfirmModal } from '@/shared/ui'

export interface ConfirmModalOptions {
  title: string
  description: string
  confirmLabel?: string
  danger?: boolean
}

let modalSequence = 0

export const useConfirmModal = () =>
  useCallback(
    (options: ConfirmModalOptions) =>
      new Promise<boolean>((resolve) => {
        const modalId = `confirm-modal-${modalSequence++}`
        let settled = false

        const finish = (confirmed: boolean) => {
          if (settled) return
          settled = true
          modal.close(modalId)
          resolve(confirmed)
        }

        const showOptions = {
          width: 440,
          onClose: () => finish(false),
          content: (
            <ConfirmModal
              {...options}
              onCancel={() => finish(false)}
              onConfirm={() => finish(true)}
            />
          ),
        }

        modal.show(modalId, showOptions as unknown as Parameters<typeof modal.show>[1])
      }),
    [],
  )
