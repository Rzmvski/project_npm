import { describe, expect, it } from 'vitest'

import { formatDuration, truncateMiddle } from './format'

describe('date formatting', () => {
  it('formats a duration in minutes and seconds', () => {
    expect(formatDuration('2026-08-06T10:00:00', '2026-08-06T10:15:42')).toBe('15 мин 42 сек')
  })

  it('does not calculate an invalid or negative duration', () => {
    expect(formatDuration(null, null)).toBe('—')
    expect(formatDuration('2026-08-06T11:00:00', '2026-08-06T10:00:00')).toBe('—')
  })

  it('keeps both ends of a long identifier', () => {
    expect(truncateMiddle('1234567890abcdefghij', 11)).toBe('12345…fghij')
  })
})
