const dateTimeFormatter = new Intl.DateTimeFormat('ru-RU', {
  dateStyle: 'medium',
  timeStyle: 'short',
})

const dateFormatter = new Intl.DateTimeFormat('ru-RU', {
  dateStyle: 'medium',
})

export function formatDateTime(value?: string | null): string {
  if (!value) return '—'
  const date = new Date(value)
  return Number.isNaN(date.getTime()) ? value : dateTimeFormatter.format(date)
}

export function formatDate(value?: string | null): string {
  if (!value) return '—'
  const date = new Date(`${value}T00:00:00`)
  return Number.isNaN(date.getTime()) ? value : dateFormatter.format(date)
}

export function formatDuration(start?: string | null, end?: string | null): string {
  if (!start || !end) return '—'
  const duration = new Date(end).getTime() - new Date(start).getTime()
  if (!Number.isFinite(duration) || duration < 0) return '—'
  const seconds = Math.round(duration / 1000)
  if (seconds < 60) return `${seconds} сек`
  const minutes = Math.floor(seconds / 60)
  const rest = seconds % 60
  return rest ? `${minutes} мин ${rest} сек` : `${minutes} мин`
}

export function truncateMiddle(value: string, maxLength = 24): string {
  if (value.length <= maxLength) return value
  const side = Math.floor((maxLength - 1) / 2)
  return `${value.slice(0, side)}…${value.slice(-side)}`
}
