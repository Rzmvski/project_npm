export interface ComboBoxOption {
  value: string
  label: string
}

export const getComboBoxValue = (value: unknown) => {
  const option = Array.isArray(value) ? value[0] : value

  return typeof option === 'object' && option && 'value' in option ? String(option.value) : ''
}

export const getComboBoxValues = (value: unknown) =>
  Array.isArray(value)
    ? value
        .filter(
          (option): option is ComboBoxOption =>
            typeof option === 'object' && option !== null && 'value' in option,
        )
        .map((option) => String(option.value))
    : []

export const findComboBoxOption = <TOption extends ComboBoxOption>(
  value: string,
  options: TOption[],
) => options.find((option) => option.value === value) ?? null

export const findComboBoxOptions = <TOption extends ComboBoxOption>(
  values: string[],
  options: TOption[],
) => options.filter((option) => values.includes(option.value))
