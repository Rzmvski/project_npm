import { useSyncExternalStore } from 'react'

import { getDevMockRoles, subscribeDevMockRoles } from './devMockRoles'

export const useDevMockRoles = () =>
  useSyncExternalStore(subscribeDevMockRoles, getDevMockRoles, () => null)
