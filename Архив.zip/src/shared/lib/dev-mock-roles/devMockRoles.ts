const KEY = 'ppm.devMockRoles'
const listeners = new Set<() => void>()

function subscribe(listener: () => void) {
  listeners.add(listener)
  return () => listeners.delete(listener)
}

function emit() {
  listeners.forEach((listener) => listener())
}

/**
 * Comma-separated role codes to send as the `x-mock-roles` header, so the
 * Express mock server can resolve a different permission set per request
 * instead of only at process startup via `MOCK_USER_ROLES`.
 *
 * Dev-only: `shared/api` attaches this header only when `import.meta.env.DEV`,
 * and the mock server is the only thing that reads it — it has no effect
 * against a real backend.
 */
export function getDevMockRoles(): string | null {
  return localStorage.getItem(KEY)
}

export function setDevMockRoles(value: string | null) {
  if (value) localStorage.setItem(KEY, value)
  else localStorage.removeItem(KEY)
  emit()
}

export { subscribe as subscribeDevMockRoles }
