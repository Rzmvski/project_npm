import { modal } from '@v-uik/base'
import { useCallback } from 'react'

import type { ReactNode } from 'react'

interface ModalOptions {
  name: string
  width?: number
  render: (close: () => void) => ReactNode
}

let modalSequence = 0

export const useModal = () =>
  useCallback(({ name, width, render }: ModalOptions) => {
    const modalId = `${name}-${modalSequence++}`
    let closed = false

    const close = () => {
      if (closed) return
      closed = true
      modal.close(modalId)
    }

    modal.show(modalId, {
      width,
      onClose: close,
      content: render(close),
    } as unknown as Parameters<typeof modal.show>[1])

    return close
  }, [])
