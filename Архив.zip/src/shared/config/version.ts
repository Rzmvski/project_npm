import packageMetadata from '@/../package.json'

export const UI_VERSION = packageMetadata.version
