import { appTokens } from './tokens'

type CssVariables = Record<`--app-${string}`, string>

function flattenTokens(
  value: object,
  prefix: string[] = [],
  result: CssVariables = {} as CssVariables,
): CssVariables {
  Object.entries(value).forEach(([key, token]) => {
    const path = [...prefix, key]

    if (typeof token === 'object' && token !== null) {
      flattenTokens(token, path, result)
      return
    }

    const variableName = `--app-${path
      .join('-')
      .replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`)}` as const

    result[variableName] = String(token)
  })

  return result
}

const appCssVariables = flattenTokens(appTokens)

export const appCssVariablesCssText = `:root {\n${Object.entries(appCssVariables)
  .map(([name, value]) => `  ${name}: ${value};`)
  .join('\n')}\n}`
