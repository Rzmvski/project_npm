import type { AppTokens } from './tokens'

import '@v-uik/theme'

declare module '@v-uik/theme' {
  interface Theme {
    app: AppTokens
  }
}
