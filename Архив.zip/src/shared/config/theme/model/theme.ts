import { createTheme } from '@v-uik/theme'

import { componentTheme } from './componentTheme'
import { systemTheme } from './systemTheme'
import { appTokens } from './tokens'

/**
 * Single source for Platform V token overrides and application-specific tokens.
 * UI components must not override library colors locally.
 */
export const appTheme = createTheme({
  sys: systemTheme,
  comp: componentTheme,
  app: appTokens,
})
