import { describe, expect, it } from 'vitest'

import { appTheme } from './theme'
import { appTokens } from './tokens'

describe('appTheme', () => {
  it('maps application colors to VUIK semantic tokens', () => {
    expect(appTheme.sys.color).toMatchObject({
      backgroundAlpha: appTokens.color.surfacePrimary,
      backgroundBeta: appTokens.color.surfaceSecondary,
      onBackgroundHigh: appTokens.color.textPrimary,
      primaryAlpha: appTokens.color.brandPrimary,
      primaryBeta: appTokens.color.brandPrimaryHover,
      primaryGamma: appTokens.color.brandPrimaryActive,
      errorAlpha: appTokens.color.danger,
      focus: appTokens.color.brandPrimary,
    })
  })

  it('keeps primary controls and data presentation on the same palette', () => {
    expect(appTheme.comp.button).toMatchObject({
      colorBackgroundContainedPrimary: appTokens.color.brandPrimary,
      colorBackgroundContainedPrimaryHover: appTokens.color.brandPrimaryHover,
      colorBackgroundContainedPrimaryActive: appTokens.color.brandPrimaryActive,
    })
    expect(appTheme.comp.input).toMatchObject({
      colorBackground: appTokens.color.surfacePrimary,
      colorBorder: appTokens.color.borderStrong,
      colorText: appTokens.color.textPrimary,
    })
    expect(appTheme.comp.table).toMatchObject({
      headerColorBackground: appTokens.color.surfaceSecondary,
      headerColorBorder: appTokens.color.borderPrimary,
    })
  })
})
