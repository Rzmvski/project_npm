import { ThemeProvider } from '@v-uik/theme'
import { createPortal } from 'react-dom'

import { appCssVariablesCssText, appTheme } from '../../model'

import type { FC, PropsWithChildren } from 'react'

export const AppThemeProvider: FC<PropsWithChildren> = ({ children }) => {
  const hasThemeVariables = document.head.querySelector('[data-app-theme="variables"]')

  return (
    <ThemeProvider theme={appTheme}>
      {hasThemeVariables
        ? null
        : createPortal(
            <style data-app-theme='variables'>{appCssVariablesCssText}</style>,
            document.head,
          )}
      {children}
    </ThemeProvider>
  )
}
