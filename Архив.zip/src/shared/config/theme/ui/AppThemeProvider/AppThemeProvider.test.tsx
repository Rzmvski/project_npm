import { render, screen } from '@testing-library/react'
import { describe, expect, it } from 'vitest'

import { AppThemeProvider } from './AppThemeProvider'

describe('AppThemeProvider', () => {
  it('injects variables into head without adding a DOM wrapper', () => {
    const { container } = render(
      <AppThemeProvider>
        <main data-testid='content' />
      </AppThemeProvider>,
    )

    expect(container.firstElementChild).toBe(screen.getByTestId('content'))
    expect(document.head.querySelector('style[data-app-theme="variables"]')).toHaveTextContent(
      '--app-color-brand-primary: #175CD3;',
    )
  })
})
