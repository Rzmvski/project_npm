import { Pagination as VuikPagination, Select } from '@v-uik/base'

import styles from './Pagination.module.scss'

import type { FC } from 'react'

interface PaginationProps {
  page: number
  totalPages: number
  size: number
  totalElements: number
  onPageChange: (page: number) => void
  onSizeChange?: (size: number) => void
  sizeOptions?: number[]
  compact?: boolean
}

export const Pagination: FC<PaginationProps> = ({
  page,
  totalPages,
  size,
  totalElements,
  onPageChange,
  onSizeChange,
  sizeOptions = [10, 20, 50],
  compact,
}) => {
  const normalizedTotalPages = Math.max(totalPages, 1)
  const currentPage = Math.min(page + 1, normalizedTotalPages)

  return (
    <div className={styles.pagination} data-compact={compact || undefined}>
      <span>Всего: {totalElements}</span>
      <div className={styles.controls}>
        <VuikPagination
          size='sm'
          currentPage={currentPage}
          totalPageCount={normalizedTotalPages}
          disabled={totalPages <= 1}
          showNavigationFirst
          showNavigationLast
          firstButtonProps={{ 'aria-label': 'Первая страница' }}
          previousButtonProps={{ 'aria-label': 'Предыдущая страница' }}
          nextButtonProps={{ 'aria-label': 'Следующая страница' }}
          lastButtonProps={{ 'aria-label': 'Последняя страница' }}
          onPageChange={(nextPage) => onPageChange(nextPage - 1)}
        />

        {onSizeChange ? (
          <Select
            className={styles.sizeSelect}
            value={String(size)}
            options={sizeOptions.map((option) => ({
              value: String(option),
              label: `${option} / стр`,
            }))}
            onChange={(value) => onSizeChange(Number(value))}
            selectButtonProps={{ 'aria-label': 'Строк на странице' }}
          />
        ) : null}
      </div>
    </div>
  )
}
