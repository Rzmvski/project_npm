import { CircularProgress } from '@v-uik/base'

import styles from './LoadingState.module.scss'

import type { FC } from 'react'

interface LoadingStateProps {
  label?: string
}

export const LoadingState: FC<LoadingStateProps> = ({ label = 'Загрузка…' }) => {
  return (
    <div className={styles.state} role='status' aria-live='polite'>
      <CircularProgress size='md' />
      <span>{label}</span>
    </div>
  )
}
