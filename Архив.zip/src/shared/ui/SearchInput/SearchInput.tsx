import { Button, Input } from '@v-uik/base'
import { Search, X } from 'lucide-react'
import { useEffect, useRef, useState, type FC } from 'react'

import styles from './SearchInput.module.scss'

interface SearchInputProps {
  value: string
  onChange: (value: string) => void
  label?: string
  placeholder?: string
  debounceMs?: number
}

export const SearchInput: FC<SearchInputProps> = ({
  value,
  onChange,
  label,
  placeholder = 'Поиск',
  debounceMs = 300,
}) => {
  const [inputValue, setInputValue] = useState(value)
  const onChangeRef = useRef(onChange)

  useEffect(() => {
    onChangeRef.current = onChange
  }, [onChange])

  useEffect(() => {
    setInputValue(value)
  }, [value])

  useEffect(() => {
    if (inputValue === value) return
    const timeout = window.setTimeout(() => onChangeRef.current(inputValue), debounceMs)
    return () => window.clearTimeout(timeout)
  }, [debounceMs, inputValue, value])

  return (
    <Input
      className={styles.field}
      value={inputValue}
      onChange={setInputValue}
      label={label}
      placeholder={placeholder}
      prefix={<Search size={17} aria-hidden='true' />}
      suffix={
        inputValue ? (
          <Button
            type='button'
            kind='ghost'
            color='secondary'
            size='sm'
            prefixIcon={<X size={15} />}
            aria-label='Очистить'
            style={{ minWidth: 32, padding: 5 }}
            onClick={() => setInputValue('')}
          />
        ) : null
      }
      fullWidth
      inputProps={{ 'aria-label': placeholder }}
    />
  )
}
