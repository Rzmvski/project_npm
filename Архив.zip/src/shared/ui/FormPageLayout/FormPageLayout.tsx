import { useId, type FC, type ComponentPropsWithoutRef, type ReactNode } from 'react'

import styles from './FormPageLayout.module.scss'

type FormProps = Omit<ComponentPropsWithoutRef<'form'>, 'children' | 'title'>

interface FormPageLayoutProps extends FormProps {
  breadcrumbs?: ReactNode
  icon?: ReactNode
  eyebrow?: ReactNode
  title: ReactNode
  description?: ReactNode
  heroActions?: ReactNode
  children: ReactNode
  aside?: ReactNode
}

export const FormPageLayout: FC<FormPageLayoutProps> = ({
  breadcrumbs,
  icon,
  eyebrow,
  title,
  description,
  heroActions,
  children,
  aside,
  className,
  ...formProps
}) => {
  const generatedTitleId = useId()
  const titleId = formProps['aria-labelledby'] ?? generatedTitleId
  const rootClassName = className ? `${styles.root} ${className}` : styles.root

  return (
    <form {...formProps} className={rootClassName} aria-labelledby={titleId}>
      {breadcrumbs ? <div className={styles.breadcrumbs}>{breadcrumbs}</div> : null}

      <header className={styles.hero}>
        {icon ? <div className={styles.heroIcon}>{icon}</div> : null}
        <div className={styles.heroContent}>
          {eyebrow ? <span className={styles.eyebrow}>{eyebrow}</span> : null}
          <h1 id={titleId}>{title}</h1>
          {description ? <p>{description}</p> : null}
        </div>
        {heroActions ? <div className={styles.heroActions}>{heroActions}</div> : null}
      </header>

      <div className={styles.layout} data-has-aside={Boolean(aside)}>
        <main className={styles.content}>{children}</main>
        {aside ? <aside className={styles.aside}>{aside}</aside> : null}
      </div>
    </form>
  )
}
