import { InlineNotification } from '@v-uik/base'

import styles from './ErrorState.module.scss'

import type { FC } from 'react'

interface ErrorStateProps {
  title?: string
  description?: string
}

export const ErrorState: FC<ErrorStateProps> = ({
  title = 'Не удалось загрузить данные',
  description,
}) => {
  return (
    <div className={styles.state}>
      <InlineNotification
        className={styles.notification}
        kind='filled'
        status='error'
        direction='vertical'
        title={title}
      >
        {description}
      </InlineNotification>
    </div>
  )
}
