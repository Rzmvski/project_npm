import styles from './FormSection.module.scss'

import type { FC, ReactNode } from 'react'

interface FormSectionProps {
  title: ReactNode
  description?: ReactNode
  headerAction?: ReactNode
  children: ReactNode
}

export const FormSection: FC<FormSectionProps> = ({
  title,
  description,
  headerAction,
  children,
}) => {
  return (
    <section className={styles.section}>
      <div className={styles.header}>
        <div>
          <h2>{title}</h2>
          {description ? <p>{description}</p> : null}
        </div>
        {headerAction ? <div className={styles.headerAction}>{headerAction}</div> : null}
      </div>
      {children}
    </section>
  )
}
