import { Inbox } from 'lucide-react'

import styles from './EmptyState.module.scss'

import type { FC, ReactNode } from 'react'

interface EmptyStateProps {
  title: string
  description?: string
  action?: ReactNode
}

export const EmptyState: FC<EmptyStateProps> = ({ title, description, action }) => {
  return (
    <div className={styles.state}>
      <div className={styles.icon}>
        <Inbox size={22} />
      </div>
      <strong>{title}</strong>
      {description ? <p>{description}</p> : null}
      {action}
    </div>
  )
}
