import { Table, type TableProps } from '@v-uik/base'
import { useLayoutEffect, useRef, useState } from 'react'

import styles from './DataTable.module.scss'

import type { FC } from 'react'

type DataTableProps<DataSource> = Omit<
  TableProps<DataSource>,
  'bordered' | 'className' | 'classes' | 'fixedHeader' | 'height' | 'hoverable' | 'tableLayout'
> & {
  fillAvailableHeight?: boolean
  comfortable?: boolean
  scrollAfterRows?: number
  scrollHeight?: number | string
}

type DataTableComponent = <DataSource>(
  props: DataTableProps<DataSource>,
) => ReturnType<FC<DataTableProps<DataSource>>>

export const DataTable: DataTableComponent = ({
  dataSource,
  fillAvailableHeight = false,
  comfortable = false,
  scrollAfterRows = 8,
  scrollHeight = 'clamp(360px, calc(100dvh - 420px), 680px)',
  ...tableProps
}) => {
  const containerRef = useRef<HTMLDivElement>(null)
  const [hasHorizontalOverflow, setHasHorizontalOverflow] = useState(false)
  const isScrollable = dataSource.length > scrollAfterRows
  const hasFixedHeader = fillAvailableHeight || isScrollable

  useLayoutEffect(() => {
    const container = containerRef.current
    if (!container) return

    const updateOverflow = () => {
      const elements = [container, ...container.querySelectorAll<HTMLElement>('*')]
      setHasHorizontalOverflow(
        elements.some((element) => {
          const { overflowX } = window.getComputedStyle(element)
          return (
            (overflowX === 'auto' || overflowX === 'scroll') &&
            element.scrollWidth > element.clientWidth + 1
          )
        }),
      )
    }

    updateOverflow()
    if (typeof ResizeObserver === 'undefined') return

    const observer = new ResizeObserver(updateOverflow)
    observer.observe(container)
    return () => observer.disconnect()
  }, [dataSource, tableProps.columns])

  return (
    <div
      ref={containerRef}
      className={styles.container}
      data-fill-height={fillAvailableHeight}
      data-comfortable={comfortable || undefined}
      data-horizontal-overflow={hasHorizontalOverflow || undefined}
    >
      <Table
        {...tableProps}
        classes={{
          root: styles.root,
          headCell: styles.headCell,
          bodyCell: styles.bodyCell,
        }}
        dataSource={dataSource}
        height={fillAvailableHeight ? '100%' : isScrollable ? scrollHeight : undefined}
        fixedHeader={hasFixedHeader}
        tableLayout={'fixed'}
        bordered={'rows'}
        hoverable
        // stripe
      />
    </div>
  )
}
