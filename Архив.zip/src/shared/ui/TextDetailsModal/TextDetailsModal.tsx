import { Button, ModalBody, ModalFooter, ModalHeader } from '@v-uik/base'

import styles from './TextDetailsModal.module.scss'

import type { FC } from 'react'

interface TextDetailsModalProps {
  title: string
  subtitle?: string
  text: string
  onClose: () => void
}

export const TextDetailsModal: FC<TextDetailsModalProps> = ({
  title,
  subtitle,
  text,
  onClose,
}) => (
  <>
    <ModalHeader subtitle={subtitle} closeButtonProps={{ 'aria-label': 'Закрыть' }}>
      {title}
    </ModalHeader>
    <ModalBody>
      <pre className={styles.content}>{text}</pre>
    </ModalBody>
    <ModalFooter>
      <Button type='button' kind='outlined' color='secondary' onClick={onClose}>
        Закрыть
      </Button>
    </ModalFooter>
  </>
)
