export { TextDetailsModal } from './TextDetailsModal'
