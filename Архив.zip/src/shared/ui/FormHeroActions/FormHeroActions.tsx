import { Button } from '@v-uik/base'
import { Save, X } from 'lucide-react'

import styles from './FormHeroActions.module.scss'

import type { FC } from 'react'

interface FormHeroActionsProps {
  cancelDisabled?: boolean
  submitDisabled?: boolean
  pending?: boolean
  submitLabel: string
  pendingLabel?: string
  onCancel: () => void
}

export const FormHeroActions: FC<FormHeroActionsProps> = ({
  cancelDisabled = false,
  submitDisabled = false,
  pending = false,
  submitLabel,
  pendingLabel = 'Сохраняем…',
  onCancel,
}) => (
  <>
    <Button
      type='button'
      kind='ghost'
      color='secondary'
      prefixIcon={<X size={16} />}
      classes={{
        button: styles.cancelButton,
        text: styles.cancelText,
      }}
      disabled={cancelDisabled}
      onClick={onCancel}
    >
      Отмена
    </Button>
    <Button
      type='submit'
      kind='contained'
      color='secondary'
      prefixIcon={<Save size={16} />}
      classes={{
        button: submitDisabled ? styles.submitDisabled : styles.submitButton,
        text: submitDisabled ? styles.submitDisabledContent : styles.submitText,
        icon: submitDisabled ? styles.submitDisabledContent : styles.submitIcon,
      }}
      disabled={submitDisabled}
    >
      {pending ? pendingLabel : submitLabel}
    </Button>
  </>
)
