import styles from './PageLayout.module.scss'

import type { FC, ReactNode } from 'react'

interface PageLayoutProps {
  breadcrumbs?: ReactNode
  title: ReactNode
  description?: ReactNode
  headerMeta?: ReactNode
  actions?: ReactNode
  contentLayout?: 'default' | 'table'
  children: ReactNode
}

export const PageLayout: FC<PageLayoutProps> = ({
  breadcrumbs,
  title,
  description,
  headerMeta,
  actions,
  contentLayout = 'default',
  children,
}) => {
  return (
    <div
      className={styles.page}
      data-content-layout={contentLayout}
      data-has-breadcrumbs={Boolean(breadcrumbs)}
    >
      {breadcrumbs ? <div className={styles.breadcrumbs}>{breadcrumbs}</div> : null}
      <header className={styles.header}>
        <div>
          <h1>{title}</h1>
          {description ? <p>{description}</p> : null}
          {headerMeta ? <div className={styles.headerMeta}>{headerMeta}</div> : null}
        </div>
        {actions ? <div className={styles.actions}>{actions}</div> : null}
      </header>
      <div className={styles.content} data-layout={contentLayout}>
        {children}
      </div>
    </div>
  )
}
