import { UI_VERSION } from '@/shared/config'

import type { FC } from 'react'

interface UiVersionProps {
  className?: string
}

export const UiVersion: FC<UiVersionProps> = ({ className }) => {
  const label = `Версия UI ${UI_VERSION}`

  return (
    <span className={className} aria-label={label} title={label}>
      v{UI_VERSION}
    </span>
  )
}
