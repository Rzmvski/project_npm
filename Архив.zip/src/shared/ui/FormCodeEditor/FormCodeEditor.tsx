import { InputHelperText } from '@v-uik/base'
import { Controller, type Control, type FieldPath, type FieldValues } from 'react-hook-form'

import { CodeEditor } from '../CodeEditor'

import styles from './FormCodeEditor.module.scss'

import type { FC } from 'react'

interface FormCodeEditorProps<TFieldValues extends FieldValues> {
  name: FieldPath<TFieldValues>
  control: Control<TFieldValues>
  label: string
  required?: boolean
  helperText?: string
  height?: number
}

type FormCodeEditorComponent = <TFieldValues extends FieldValues>(
  props: FormCodeEditorProps<TFieldValues>,
) => ReturnType<FC<FormCodeEditorProps<TFieldValues>>>

export const FormCodeEditor: FormCodeEditorComponent = ({
  name,
  control,
  label,
  required,
  helperText,
  height = 360,
}) => {
  return (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState }) => (
        <div className={styles.field}>
          <div className={styles.label}>
            {label}
            {required ? <span aria-hidden='true'>*</span> : null}
          </div>
          <CodeEditor
            value={String(field.value ?? '')}
            height={height}
            onChange={field.onChange}
          />
          <InputHelperText error={Boolean(fieldState.error)}>
            {fieldState.error?.message ?? helperText}
          </InputHelperText>
        </div>
      )}
    />
  )
}
