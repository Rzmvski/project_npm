import { Breadcrumbs } from '@v-uik/base'

import styles from './PageBreadcrumbs.module.scss'

import type { FC, ReactNode } from 'react'

interface PageBreadcrumbsProps {
  children: ReactNode
}

export const PageBreadcrumbs: FC<PageBreadcrumbsProps> = ({ children }) => {
  return (
    <Breadcrumbs className={styles.breadcrumbs} aria-label='Навигация по разделам'>
      {children}
    </Breadcrumbs>
  )
}
