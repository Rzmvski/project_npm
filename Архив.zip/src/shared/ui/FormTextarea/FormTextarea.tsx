import { Textarea } from '@v-uik/base'
import { Controller, type Control, type FieldPath, type FieldValues } from 'react-hook-form'

import type { ComponentProps, FC } from 'react'

type TextareaProps = ComponentProps<typeof Textarea>

interface FormTextareaProps<TFieldValues extends FieldValues> extends Omit<
  TextareaProps,
  'value' | 'onChange' | 'error' | 'helperText'
> {
  name: FieldPath<TFieldValues>
  control: Control<TFieldValues>
  helperText?: TextareaProps['helperText']
}

type FormTextareaComponent = <TFieldValues extends FieldValues>(
  props: FormTextareaProps<TFieldValues>,
) => ReturnType<FC<FormTextareaProps<TFieldValues>>>

export const FormTextarea: FormTextareaComponent = ({
  name,
  control,
  helperText,
  textareaProps,
  ...props
}) => {
  return (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState }) => (
        <Textarea
          {...props}
          value={String(field.value ?? '')}
          error={Boolean(fieldState.error)}
          helperText={fieldState.error?.message ?? helperText}
          textareaProps={{
            ...textareaProps,
            name: field.name,
            onBlur: field.onBlur,
          }}
          onChange={field.onChange}
        />
      )}
    />
  )
}
