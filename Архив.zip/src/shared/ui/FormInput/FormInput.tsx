import { Input } from '@v-uik/base'
import { Controller, type Control, type FieldPath, type FieldValues } from 'react-hook-form'

import type { ComponentProps, FC } from 'react'

type InputProps = ComponentProps<typeof Input>

interface FormInputProps<TFieldValues extends FieldValues> extends Omit<
  InputProps,
  'value' | 'onChange' | 'error' | 'helperText'
> {
  name: FieldPath<TFieldValues>
  control: Control<TFieldValues>
  helperText?: InputProps['helperText']
}

type FormInputComponent = <TFieldValues extends FieldValues>(
  props: FormInputProps<TFieldValues>,
) => ReturnType<FC<FormInputProps<TFieldValues>>>

export const FormInput: FormInputComponent = ({
  name,
  control,
  helperText,
  inputProps,
  ...props
}) => {
  return (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState }) => (
        <Input
          {...props}
          value={String(field.value ?? '')}
          error={Boolean(fieldState.error)}
          helperText={fieldState.error?.message ?? helperText}
          inputProps={{
            ...inputProps,
            name: field.name,
            onBlur: field.onBlur,
          }}
          onChange={field.onChange}
        />
      )}
    />
  )
}
