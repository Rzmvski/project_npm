import { Button, ModalBody, ModalFooter, ModalHeader } from '@v-uik/base'

import type { FC } from 'react'

interface ConfirmModalProps {
  title: string
  description: string
  confirmLabel?: string
  danger?: boolean
  onCancel: () => void
  onConfirm: () => void
}

export const ConfirmModal: FC<ConfirmModalProps> = ({
  title,
  description,
  confirmLabel = 'Подтвердить',
  danger,
  onCancel,
  onConfirm,
}) => (
  <>
    <ModalHeader subtitle={description} closeButtonProps={{ 'aria-label': 'Закрыть' }}>
      {title}
    </ModalHeader>
    <ModalBody>
      <p>После подтверждения действие может быть невозможно отменить.</p>
    </ModalBody>
    <ModalFooter>
      <Button type='button' kind='outlined' color='secondary' onClick={onCancel}>
        Отмена
      </Button>
      <Button type='button' color={danger ? 'error' : 'primary'} onClick={onConfirm}>
        {confirmLabel}
      </Button>
    </ModalFooter>
  </>
)
