import 'ace-builds/src-noconflict/ace'
import 'ace-builds/src-noconflict/ext-language_tools'
import 'ace-builds/src-noconflict/mode-sql'
import 'ace-builds/src-noconflict/theme-textmate'
import AceEditor from 'react-ace'

import { appTokens } from '@/shared/config'

import styles from './CodeEditor.module.scss'

import type { FC } from 'react'

const defaultEditorHeight = Number.parseInt(appTokens.size.codeEditorHeight, 10)
const editorFontSize = Number.parseInt(appTokens.typography.fontSize.body, 10)
const editorLineHeight = Math.round(editorFontSize * 1.6)
const autoHeightPadding = 24
const autoHeightMin = 96

interface CodeEditorProps {
  value: string
  onChange?: (value: string) => void
  readOnly?: boolean
  /** Fixed pixel height, 'auto' for content, or 'fill' for the parent height. */
  height?: number | 'auto' | 'fill'
  maxAutoHeight?: number
}

export const CodeEditor: FC<CodeEditorProps> = ({
  value,
  onChange,
  readOnly,
  height = defaultEditorHeight,
  maxAutoHeight = defaultEditorHeight,
}) => {
  const resolvedHeight =
    height === 'fill'
      ? '100%'
      : height === 'auto'
        ? Math.min(
            maxAutoHeight,
            Math.max(
              autoHeightMin,
              value.split('\n').length * editorLineHeight + autoHeightPadding,
            ),
          )
        : height

  return (
    <div className={styles.editor} data-fill-height={height === 'fill' || undefined}>
      <AceEditor
        mode='sql'
        theme='textmate'
        value={value}
        onChange={onChange}
        readOnly={readOnly}
        width='100%'
        height={typeof resolvedHeight === 'number' ? `${resolvedHeight}px` : resolvedHeight}
        fontSize={editorFontSize}
        style={{ fontFamily: appTokens.typography.codeFontFamily }}
        showPrintMargin={false}
        showGutter
        highlightActiveLine={!readOnly}
        setOptions={{
          useWorker: false,
          tabSize: 2,
          showLineNumbers: true,
          enableBasicAutocompletion: true,
          enableLiveAutocompletion: true,
        }}
      />
    </div>
  )
}
