import { InputNumber } from '@v-uik/base'
import { Controller, type Control, type FieldPath, type FieldValues } from 'react-hook-form'

import type { ComponentProps, FC } from 'react'

type InputNumberProps = ComponentProps<typeof InputNumber>

interface FormNumberInputProps<TFieldValues extends FieldValues> extends Omit<
  InputNumberProps,
  'value' | 'onChange' | 'error' | 'helperText'
> {
  name: FieldPath<TFieldValues>
  control: Control<TFieldValues>
  helperText?: InputNumberProps['helperText']
}

type FormNumberInputComponent = <TFieldValues extends FieldValues>(
  props: FormNumberInputProps<TFieldValues>,
) => ReturnType<FC<FormNumberInputProps<TFieldValues>>>

export const FormNumberInput: FormNumberInputComponent = ({
  name,
  control,
  helperText,
  inputProps,
  ...props
}) => {
  return (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState }) => (
        <InputNumber
          {...props}
          value={typeof field.value === 'number' ? field.value : 0}
          error={Boolean(fieldState.error)}
          helperText={fieldState.error?.message ?? helperText}
          inputProps={{
            ...inputProps,
            name: field.name,
            onBlur: field.onBlur,
          }}
          onChange={(value) => field.onChange(value ?? 0)}
        />
      )}
    />
  )
}
