export function withQueryParams<T extends object>(path: string, params: T): string {
  const search = new URLSearchParams()

  Object.entries(params as Record<string, string | number | boolean | undefined>).forEach(
    ([key, value]) => {
      if (value !== undefined) search.set(key, String(value))
    },
  )

  const query = search.toString()
  return query ? `${path}?${query}` : path
}
