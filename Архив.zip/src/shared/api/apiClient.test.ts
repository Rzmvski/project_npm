import { afterEach, describe, expect, it, vi } from 'vitest'

import { apiDataRequest, apiRequest } from './apiClient'

describe('API client', () => {
  afterEach(() => {
    vi.unstubAllGlobals()
  })

  it('sends the tenant header and JSON body', async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValue(
        new Response(
          JSON.stringify({ status: 'SUCCESS', description: 'ok', data: { id: 1 } }),
          { status: 200, headers: { 'content-type': 'application/json' } },
        ),
      )
    vi.stubGlobal('fetch', fetchMock)

    await expect(
      apiDataRequest<{ id: number }>('/resource', {
        tenantId: 'tenant-1',
        method: 'POST',
        body: { name: 'test' },
      }),
    ).resolves.toEqual({ id: 1 })

    const [, request] = fetchMock.mock.calls[0] as [string, RequestInit]
    expect(new Headers(request.headers).get('tenant-id')).toBe('tenant-1')
    expect(new Headers(request.headers).get('content-type')).toBe('application/json')
    expect(request.body).toBe(JSON.stringify({ name: 'test' }))
  })

  it('uses backend description as the user-facing error', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue(
        new Response(JSON.stringify({ description: 'Процесс уже существует' }), {
          status: 409,
          headers: { 'content-type': 'application/json' },
        }),
      ),
    )

    await expect(apiRequest('/process')).rejects.toEqual(
      expect.objectContaining({
        name: 'ApiError',
        message: 'Процесс уже существует',
        status: 409,
      }),
    )
  })

  it('returns undefined for a successful response without content', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response(null, { status: 204 })))

    await expect(apiRequest('/resource', { method: 'DELETE' })).resolves.toBeUndefined()
  })
})
