import { describe, expect, it } from 'vitest'

import { withQueryParams } from './queryParams'

describe('query params', () => {
  it('serializes defined values and encodes sort', () => {
    expect(
      withQueryParams('/process', {
        page: 0,
        size: 20,
        sort: 'asc:processName',
        query: undefined,
      }),
    ).toBe('/process?page=0&size=20&sort=asc%3AprocessName')
  })

  it('does not append an empty query string', () => {
    expect(withQueryParams('/process', { page: undefined })).toBe('/process')
  })
})
