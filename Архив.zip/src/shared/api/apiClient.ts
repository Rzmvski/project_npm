import { getDevMockRoles } from '@/shared/lib'

import { ApiError } from './ApiError'

import type { ApiResponse } from './types'

const API_URL = import.meta.env.VITE_API_URL ?? '/api/v1'

type ApiRequestOptions = Omit<RequestInit, 'body'> & {
  tenantId?: string
  body?: unknown
}

export async function apiDataRequest<T>(
  path: string,
  options: ApiRequestOptions = {},
): Promise<T> {
  const payload = await apiRequest<ApiResponse<T>>(path, options)
  return payload.data
}

export async function apiRequest<T>(path: string, options: ApiRequestOptions = {}): Promise<T> {
  const { tenantId, body, headers, ...requestInit } = options
  const requestHeaders = new Headers(headers)

  requestHeaders.set('Accept', 'application/json')

  if (tenantId) {
    requestHeaders.set('tenant-id', tenantId)
  }

  if (import.meta.env.DEV) {
    const devMockRoles = getDevMockRoles()
    if (devMockRoles) requestHeaders.set('x-mock-roles', devMockRoles)
  }

  if (body !== undefined && !(body instanceof FormData)) {
    requestHeaders.set('Content-Type', 'application/json')
  }

  const response = await fetch(`${API_URL}${path}`, {
    credentials: 'include',
    ...requestInit,
    headers: requestHeaders,
    body:
      body === undefined ? undefined : body instanceof FormData ? body : JSON.stringify(body),
  })

  if (!response.ok) {
    const details = await readResponseBody(response)
    const message = getErrorMessage(details) ?? `HTTP ${response.status}`
    throw new ApiError(message, response.status, details)
  }

  if (response.status === 204) {
    return undefined as T
  }

  const bodyValue = await readResponseBody(response)
  return bodyValue as T
}

async function readResponseBody(response: Response): Promise<unknown> {
  const contentType = response.headers.get('content-type') ?? ''

  if (contentType.includes('application/json')) {
    return response.json()
  }

  const text = await response.text()
  return text || undefined
}

function getErrorMessage(details: unknown): string | undefined {
  if (typeof details === 'string') return details
  if (!details || typeof details !== 'object') return undefined

  if ('description' in details && typeof details.description === 'string') {
    return details.description
  }

  if ('message' in details && typeof details.message === 'string') {
    return details.message
  }

  return undefined
}
