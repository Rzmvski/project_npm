import { createAppRouter } from '../../router'
import { createQueryClient } from '../query-client'

export const queryClient = createQueryClient()
export const router = createAppRouter(queryClient)
