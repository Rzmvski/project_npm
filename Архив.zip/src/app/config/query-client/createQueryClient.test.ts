import { describe, expect, it } from 'vitest'

import { createQueryClient } from './createQueryClient'

describe('application query client', () => {
  it('uses stable production query defaults', () => {
    const queryClient = createQueryClient()
    const options = queryClient.getDefaultOptions().queries

    expect(options).toMatchObject({
      staleTime: 30_000,
      retry: 1,
      refetchOnWindowFocus: false,
    })
  })
})
