import { screen, waitFor } from '@testing-library/react'
import { describe, expect, it } from 'vitest'

import { renderApp, userAccessFixture } from '@/test'

describe('protected routes', () => {
  it('redirects a user without permission to the forbidden page', async () => {
    const { router } = await renderApp({
      route: '/processes',
      access: userAccessFixture([]),
    })

    await screen.findByRole('heading', { name: 'Доступ запрещён' })
    await waitFor(() => expect(router.state.location.pathname).toBe('/forbidden'))
  })

  it('renders an unknown workspace route inside the app layout', async () => {
    await renderApp({
      route: '/unknown-section',
      access: userAccessFixture([]),
    })

    expect(
      await screen.findByRole('heading', {
        name: 'Такого раздела не существует',
      }),
    ).toBeVisible()
    expect(screen.getByRole('navigation', { name: 'Основная навигация' })).toBeVisible()
  })
})
