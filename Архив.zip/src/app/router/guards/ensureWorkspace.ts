import { redirect } from '@tanstack/react-router'

import { userAccessQueryOptions } from '@/entities/access'
import {
  getSelectedTenantId,
  setSelectedTenantId,
  tenantListQueryOptions,
} from '@/entities/tenant'
import { userQueryOptions } from '@/entities/user'

import type { RouterContext } from '../routerContext'

export const ensureWorkspace = async (context: RouterContext) => {
  const tenantId = getSelectedTenantId()

  if (!tenantId) {
    throw redirect({ to: '/select-tenant' })
  }

  const tenants = await context.queryClient.ensureQueryData(tenantListQueryOptions())

  if (!tenants.some((tenant) => tenant.id === tenantId)) {
    setSelectedTenantId(null)
    throw redirect({ to: '/select-tenant' })
  }

  const [, access] = await Promise.all([
    context.queryClient.ensureQueryData(userQueryOptions()),
    context.queryClient.ensureQueryData(userAccessQueryOptions(tenantId)),
  ])

  return access
}
