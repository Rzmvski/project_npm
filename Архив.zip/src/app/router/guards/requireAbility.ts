import { redirect } from '@tanstack/react-router'

import { canAccess, userAccessQueryOptions, type AbilityId } from '@/entities/access'
import { getSelectedTenantId } from '@/entities/tenant'

import type { RouterContext } from '../routerContext'

export const requireAbility = (ability: AbilityId) => {
  return async ({ context }: { context: RouterContext }) => {
    const tenantId = getSelectedTenantId()

    if (!tenantId) {
      throw redirect({ to: '/select-tenant' })
    }

    const access = await context.queryClient.ensureQueryData(userAccessQueryOptions(tenantId))

    if (!canAccess(access, ability)) {
      throw redirect({ to: '/forbidden', replace: true })
    }
  }
}
