import { QueryClient } from '@tanstack/react-query'
import { afterEach, describe, expect, it } from 'vitest'

import { createAppRouter } from './router'

describe('createAppRouter', () => {
  const routers: Array<ReturnType<typeof createAppRouter>> = []

  afterEach(() => {
    routers.forEach((router) => router.history.destroy())
    routers.length = 0
    window.history.replaceState({}, '', '/')
  })

  it('uses the URL hash for application routes by default', () => {
    window.history.replaceState({}, '', '/#/history?page=2')

    const router = createAppRouter(new QueryClient())
    routers.push(router)

    expect(router.history.location).toMatchObject({
      pathname: '/history',
      search: '?page=2',
    })
    expect(router.history.createHref('/processes')).toBe('/#/processes')

    router.history.push('/processes')
    router.history.flush()

    expect(window.location.hash).toBe('#/processes')
  })
})
