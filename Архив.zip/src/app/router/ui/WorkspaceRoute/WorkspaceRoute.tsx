import { useRequiredTenantId } from '@/entities/tenant'

import { AppLayout } from '../../../layouts'
import { WorkspaceProviders } from '../../../providers/WorkspaceProviders'

import type { FC } from 'react'

export const WorkspaceRoute: FC = () => {
  const tenantId = useRequiredTenantId()

  return (
    <WorkspaceProviders tenantId={tenantId}>
      <AppLayout />
    </WorkspaceProviders>
  )
}
