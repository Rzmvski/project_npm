import { ErrorPage } from '@/pages/error'

import type { ErrorComponentProps } from '@tanstack/react-router'
import type { FC } from 'react'

export const RootErrorPage: FC<ErrorComponentProps> = ({ error, reset }) => (
  <ErrorPage error={error} onRetry={reset} />
)
