import { ErrorPage } from '@/pages/error'

import type { FC } from 'react'

export const RootNotFoundPage: FC = () => (
  <ErrorPage
    status='404'
    eyebrow='Страница не найдена'
    title='Такого адреса не существует'
    description='Проверьте адрес или вернитесь на главную страницу приложения.'
  />
)
