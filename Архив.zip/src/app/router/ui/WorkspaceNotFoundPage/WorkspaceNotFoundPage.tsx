import { ErrorPage } from '@/pages/error'

import type { FC } from 'react'

export const WorkspaceNotFoundPage: FC = () => (
  <ErrorPage
    embedded
    status='404'
    eyebrow='Страница не найдена'
    title='Такого раздела не существует'
    description='Проверьте адрес или перейдите в доступный раздел приложения.'
  />
)
