import { ErrorPage } from '@/pages/error'

import type { ErrorComponentProps } from '@tanstack/react-router'
import type { FC } from 'react'

export const WorkspaceErrorPage: FC<ErrorComponentProps> = ({ error, reset }) => (
  <ErrorPage embedded error={error} onRetry={reset} />
)
