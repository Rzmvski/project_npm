import { createHashHistory, createRouter, type RouterHistory } from '@tanstack/react-router'

import { routeTree } from './routes'
import { WorkspaceErrorPage } from './ui'

import type { RouterContext } from './routerContext'

export const createAppRouter = (
  queryClient: RouterContext['queryClient'],
  history?: RouterHistory,
) =>
  createRouter({
    routeTree,
    context: { queryClient },
    history: history ?? createHashHistory(),
    defaultPreload: 'intent',
    scrollRestoration: true,
    defaultErrorComponent: WorkspaceErrorPage,
  })

export type AppRouter = ReturnType<typeof createAppRouter>

declare module '@tanstack/react-router' {
  interface Register {
    router: AppRouter
  }
}
