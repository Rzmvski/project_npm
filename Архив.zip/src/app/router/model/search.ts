import type { SearchSchemaInput } from '@tanstack/react-router'

interface PaginatedSearchInput extends SearchSchemaInput {
  page?: unknown
  size?: unknown
  sort?: unknown
}

interface HistorySearchInput extends PaginatedSearchInput {
  query?: unknown
  status?: unknown
  category?: unknown
  from?: unknown
  to?: unknown
}

interface SchedulesSearchInput extends PaginatedSearchInput {
  query?: unknown
  category?: unknown
  day?: unknown
}

export interface PaginatedSearch {
  page: number
  size: number
  sort: string
}

export interface HistorySearch extends PaginatedSearch {
  query?: string
  status?: string
  category?: string
  from?: string
  to?: string
}

export interface SchedulesSearch extends PaginatedSearch {
  query?: string
  category?: string
  day?: string
}

interface ScheduleEditorSearchInput extends SearchSchemaInput {
  returnTo?: unknown
}

export interface ScheduleEditorSearch {
  returnTo?: 'process'
}

const parsePage = (value: unknown) =>
  Number.isFinite(Number(value)) ? Math.max(0, Number(value)) : 0

const parseSize = (value: unknown) =>
  [10, 20, 50].includes(Number(value)) ? Number(value) : 20

const parsePaginatedSearch = (
  search: PaginatedSearchInput,
  defaultSort: string,
): PaginatedSearch => ({
  page: parsePage(search.page),
  size: parseSize(search.size),
  sort: typeof search.sort === 'string' ? search.sort : defaultSort,
})

const parseOptionalString = (value: unknown) =>
  typeof value === 'string' && value.trim() ? value.trim() : undefined

export const validateHistorySearch = (search: HistorySearchInput): HistorySearch => ({
  ...parsePaginatedSearch(search, 'start_date_time:desc'),
  query: parseOptionalString(search.query),
  status: parseOptionalString(search.status),
  category: parseOptionalString(search.category),
  from: parseOptionalString(search.from),
  to: parseOptionalString(search.to),
})

export const validateSchedulesSearch = (search: SchedulesSearchInput): SchedulesSearch => ({
  ...parsePaginatedSearch(search, 'processName,asc'),
  query: parseOptionalString(search.query),
  category: parseOptionalString(search.category),
  day: parseOptionalString(search.day),
})

export const validateScheduleEditorSearch = (
  search: ScheduleEditorSearchInput,
): ScheduleEditorSearch => ({
  returnTo: search.returnTo === 'process' ? 'process' : undefined,
})
