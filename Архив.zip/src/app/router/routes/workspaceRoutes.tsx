import { createRoute } from '@tanstack/react-router'

import { ForbiddenPage } from '@/pages/forbidden'

import { ensureWorkspace } from '../guards'
import { WorkspaceNotFoundPage, WorkspaceRoute } from '../ui'

import { rootRoute } from './rootRoutes'

export const workspaceRoute = createRoute({
  getParentRoute: () => rootRoute,
  id: '_workspace',
  beforeLoad: ({ context }) => ensureWorkspace(context),
  component: WorkspaceRoute,
})

export const forbiddenRoute = createRoute({
  getParentRoute: () => workspaceRoute,
  path: 'forbidden',
  component: ForbiddenPage,
})

export const notFoundRoute = createRoute({
  getParentRoute: () => workspaceRoute,
  path: '$',
  component: WorkspaceNotFoundPage,
})
