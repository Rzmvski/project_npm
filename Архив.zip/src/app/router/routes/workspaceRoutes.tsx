import { createLazyRoute, createRoute } from '@tanstack/react-router'

import { loadForbiddenPage } from '@/pages/forbidden'

import { ensureWorkspace } from '../guards'
import { WorkspaceNotFoundPage, WorkspaceRoute } from '../ui'

import { rootRoute } from './rootRoutes'

export const workspaceRoute = createRoute({
  getParentRoute: () => rootRoute,
  id: '_workspace',
  beforeLoad: ({ context }) => ensureWorkspace(context),
  component: WorkspaceRoute,
})

export const forbiddenRoute = createRoute({
  getParentRoute: () => workspaceRoute,
  path: 'forbidden',
}).lazy(() =>
  loadForbiddenPage().then(({ ForbiddenPage }) =>
    createLazyRoute('/_workspace/forbidden')({ component: ForbiddenPage }),
  ),
)

export const notFoundRoute = createRoute({
  getParentRoute: () => workspaceRoute,
  path: '$',
  component: WorkspaceNotFoundPage,
})
