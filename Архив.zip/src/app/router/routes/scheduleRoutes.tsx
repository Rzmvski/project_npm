import { createRoute } from '@tanstack/react-router'

import { Ability } from '@/entities/access'
import { ScheduleDetailsPage } from '@/pages/schedule-details'
import { ScheduleEditorPage } from '@/pages/schedule-editor'
import { SchedulesPage } from '@/pages/schedules'

import { requireAbility } from '../guards'
import { validateScheduleEditorSearch, validateSchedulesSearch } from '../model'

import { workspaceRoute } from './workspaceRoutes'

export const schedulesRoute = createRoute({
  getParentRoute: () => workspaceRoute,
  path: 'schedules',
  beforeLoad: requireAbility(Ability.SCHEDULE_LIST),
  validateSearch: validateSchedulesSearch,
  component: SchedulesPage,
})

export const scheduleEditorRoute = createRoute({
  getParentRoute: () => workspaceRoute,
  path: 'schedules/$processId/edit',
  beforeLoad: requireAbility(Ability.SCHEDULE_EDIT),
  validateSearch: validateScheduleEditorSearch,
  component: () => {
    const { processId } = scheduleEditorRoute.useParams()
    return <ScheduleEditorPage processId={processId} />
  },
})

export const scheduleDetailsRoute = createRoute({
  getParentRoute: () => workspaceRoute,
  path: 'schedules/$processId',
  beforeLoad: requireAbility(Ability.SCHEDULE_READ),
  component: () => {
    const { processId } = scheduleDetailsRoute.useParams()
    return <ScheduleDetailsPage processId={processId} />
  },
})
