import { createLazyRoute, createRoute } from '@tanstack/react-router'

import { Ability } from '@/entities/access'
import { loadScheduleDetailsPage } from '@/pages/schedule-details'
import { loadScheduleEditorPage } from '@/pages/schedule-editor'
import { loadSchedulesPage } from '@/pages/schedules'

import { requireAbility } from '../guards'
import { validateScheduleEditorSearch, validateSchedulesSearch } from '../model'

import { workspaceRoute } from './workspaceRoutes'

export const schedulesRoute = createRoute({
  getParentRoute: () => workspaceRoute,
  path: 'schedules',
  beforeLoad: requireAbility(Ability.SCHEDULE_LIST),
  validateSearch: validateSchedulesSearch,
}).lazy(() =>
  loadSchedulesPage().then(({ SchedulesPage }) =>
    createLazyRoute('/_workspace/schedules')({ component: SchedulesPage }),
  ),
)

export const scheduleEditorRoute = createRoute({
  getParentRoute: () => workspaceRoute,
  path: 'schedules/$processId/edit',
  beforeLoad: requireAbility(Ability.SCHEDULE_EDIT),
  validateSearch: validateScheduleEditorSearch,
}).lazy(() =>
  loadScheduleEditorPage().then(({ ScheduleEditorPage }) =>
    createLazyRoute('/_workspace/schedules/$processId/edit')({
      component: () => {
        const { processId } = scheduleEditorRoute.useParams()
        return <ScheduleEditorPage processId={processId} />
      },
    }),
  ),
)

export const scheduleDetailsRoute = createRoute({
  getParentRoute: () => workspaceRoute,
  path: 'schedules/$processId',
  beforeLoad: requireAbility(Ability.SCHEDULE_READ),
}).lazy(() =>
  loadScheduleDetailsPage().then(({ ScheduleDetailsPage }) =>
    createLazyRoute('/_workspace/schedules/$processId')({
      component: () => {
        const { processId } = scheduleDetailsRoute.useParams()
        return <ScheduleDetailsPage processId={processId} />
      },
    }),
  ),
)
