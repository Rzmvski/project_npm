import { createRoute } from '@tanstack/react-router'

import { Ability } from '@/entities/access'
import { HistoryPage } from '@/pages/history'
import { ProcessSessionPage, validateProcessSessionSearch } from '@/pages/process-session'

import { requireAbility } from '../guards'
import { validateHistorySearch } from '../model'

import { workspaceRoute } from './workspaceRoutes'

export const historyRoute = createRoute({
  getParentRoute: () => workspaceRoute,
  path: 'history',
  beforeLoad: requireAbility(Ability.PROCESS_HISTORY),
  validateSearch: validateHistorySearch,
  component: HistoryPage,
})

export const processSessionRoute = createRoute({
  getParentRoute: () => workspaceRoute,
  path: 'history/$sessionProcessId',
  beforeLoad: requireAbility(Ability.PROCESS_HISTORY_DETAILS),
  validateSearch: validateProcessSessionSearch,
  component: () => {
    const { sessionProcessId } = processSessionRoute.useParams()
    return <ProcessSessionPage sessionProcessId={sessionProcessId} />
  },
})
