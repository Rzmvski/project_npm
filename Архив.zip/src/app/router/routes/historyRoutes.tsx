import { createLazyRoute, createRoute } from '@tanstack/react-router'

import { Ability } from '@/entities/access'
import { loadHistoryPage } from '@/pages/history'
import { loadProcessSessionPage, validateProcessSessionSearch } from '@/pages/process-session'

import { requireAbility } from '../guards'
import { validateHistorySearch } from '../model'

import { workspaceRoute } from './workspaceRoutes'

export const historyRoute = createRoute({
  getParentRoute: () => workspaceRoute,
  path: 'history',
  beforeLoad: requireAbility(Ability.PROCESS_HISTORY),
  validateSearch: validateHistorySearch,
}).lazy(() =>
  loadHistoryPage().then(({ HistoryPage }) =>
    createLazyRoute('/_workspace/history')({ component: HistoryPage }),
  ),
)

export const processSessionRoute = createRoute({
  getParentRoute: () => workspaceRoute,
  path: 'history/$sessionProcessId',
  beforeLoad: requireAbility(Ability.PROCESS_HISTORY_DETAILS),
  validateSearch: validateProcessSessionSearch,
}).lazy(() =>
  loadProcessSessionPage().then(({ ProcessSessionPage }) =>
    createLazyRoute('/_workspace/history/$sessionProcessId')({
      component: () => {
        const { sessionProcessId } = processSessionRoute.useParams()
        return <ProcessSessionPage sessionProcessId={sessionProcessId} />
      },
    }),
  ),
)
