import {
  Outlet,
  createLazyRoute,
  createRootRouteWithContext,
  createRoute,
  redirect,
} from '@tanstack/react-router'

import { getDefaultWorkspacePath } from '@/entities/access'
import { loadSelectTenantPage } from '@/pages/select-tenant'

import { ensureWorkspace } from '../guards'
import { RootErrorPage, RootNotFoundPage } from '../ui'

import type { RouterContext } from '../routerContext'

export const rootRoute = createRootRouteWithContext<RouterContext>()({
  component: Outlet,
  errorComponent: RootErrorPage,
  notFoundComponent: RootNotFoundPage,
})

export const indexRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/',
  beforeLoad: async ({ context }) => {
    const access = await ensureWorkspace(context)
    throw redirect({ to: getDefaultWorkspacePath(access) })
  },
})

export const selectTenantRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: 'select-tenant',
}).lazy(() =>
  loadSelectTenantPage().then(({ SelectTenantPage }) =>
    createLazyRoute('/select-tenant')({ component: SelectTenantPage }),
  ),
)
