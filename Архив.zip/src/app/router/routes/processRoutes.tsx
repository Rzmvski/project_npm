import { createRoute } from '@tanstack/react-router'

import { Ability } from '@/entities/access'
import { ProcessDetailsPage } from '@/pages/process-details'
import { ProcessFormPage } from '@/pages/process-form'
import { ProcessesPage, validateProcessesSearch } from '@/pages/processes'

import { requireAbility } from '../guards'

import { workspaceRoute } from './workspaceRoutes'

export const processesRoute = createRoute({
  getParentRoute: () => workspaceRoute,
  path: 'processes',
  beforeLoad: requireAbility(Ability.PROCESS_LIST),
  validateSearch: validateProcessesSearch,
  component: ProcessesPage,
})

export const processDetailsRoute = createRoute({
  getParentRoute: () => workspaceRoute,
  path: 'processes/$processId',
  beforeLoad: requireAbility(Ability.PROCESS_DETAILS),
  component: () => {
    const { processId } = processDetailsRoute.useParams()
    return <ProcessDetailsPage processId={processId} />
  },
})

export const processCreateRoute = createRoute({
  getParentRoute: () => workspaceRoute,
  path: 'processes/new',
  beforeLoad: requireAbility(Ability.PROCESS_CREATE),
  component: () => <ProcessFormPage mode='create' />,
})

export const processEditRoute = createRoute({
  getParentRoute: () => workspaceRoute,
  path: 'processes/$processId/edit',
  beforeLoad: requireAbility(Ability.PROCESS_UPDATE),
  component: () => {
    const { processId } = processEditRoute.useParams()
    return <ProcessFormPage mode='edit' processId={processId} />
  },
})
