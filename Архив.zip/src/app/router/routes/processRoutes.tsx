import { createLazyRoute, createRoute } from '@tanstack/react-router'

import { Ability } from '@/entities/access'
import { loadProcessDetailsPage } from '@/pages/process-details'
import { loadProcessFormPage } from '@/pages/process-form'
import { loadProcessesPage, validateProcessesSearch } from '@/pages/processes'

import { requireAbility } from '../guards'

import { workspaceRoute } from './workspaceRoutes'

export const processesRoute = createRoute({
  getParentRoute: () => workspaceRoute,
  path: 'processes',
  beforeLoad: requireAbility(Ability.PROCESS_LIST),
  validateSearch: validateProcessesSearch,
}).lazy(() =>
  loadProcessesPage().then(({ ProcessesPage }) =>
    createLazyRoute('/_workspace/processes')({ component: ProcessesPage }),
  ),
)

export const processDetailsRoute = createRoute({
  getParentRoute: () => workspaceRoute,
  path: 'processes/$processId',
  beforeLoad: requireAbility(Ability.PROCESS_DETAILS),
}).lazy(() =>
  loadProcessDetailsPage().then(({ ProcessDetailsPage }) =>
    createLazyRoute('/_workspace/processes/$processId')({
      component: () => {
        const { processId } = processDetailsRoute.useParams()
        return <ProcessDetailsPage processId={processId} />
      },
    }),
  ),
)

export const processCreateRoute = createRoute({
  getParentRoute: () => workspaceRoute,
  path: 'processes/new',
  beforeLoad: requireAbility(Ability.PROCESS_CREATE),
}).lazy(() =>
  loadProcessFormPage().then(({ ProcessFormPage }) =>
    createLazyRoute('/_workspace/processes/new')({
      component: () => <ProcessFormPage mode='create' />,
    }),
  ),
)

export const processEditRoute = createRoute({
  getParentRoute: () => workspaceRoute,
  path: 'processes/$processId/edit',
  beforeLoad: requireAbility(Ability.PROCESS_UPDATE),
}).lazy(() =>
  loadProcessFormPage().then(({ ProcessFormPage }) =>
    createLazyRoute('/_workspace/processes/$processId/edit')({
      component: () => {
        const { processId } = processEditRoute.useParams()
        return <ProcessFormPage mode='edit' processId={processId} />
      },
    }),
  ),
)
