export { getInitials } from './getInitials'
