import { Outlet, useNavigate, useRouterState } from '@tanstack/react-router'
import { Avatar, Bar, BarDivider, BarMenuItem } from '@v-uik/base'
import { Wrench } from 'lucide-react'

import { useAccess } from '@/entities/access'
import { useCurrentUser } from '@/entities/user'
import { RoleSwitcher } from '@/features/dev-switch-role'
import { TenantSwitcher } from '@/features/switch-tenant'
import { UiVersion } from '@/shared/ui'

import { getInitials } from '../../lib'
import { navigationItems } from '../../model'

import styles from './AppLayout.module.scss'

import type { FC } from 'react'

export const AppLayout: FC = () => {
  const navigate = useNavigate()
  const pathname = useRouterState({
    select: (state) => state.location.pathname,
  })
  const { can } = useAccess()
  const user = useCurrentUser()

  return (
    <div className={styles.layout}>
      <Bar
        className={styles.bar}
        direction='vertical'
        kind='dark'
        expanded
        aria-label='Основная навигация'
      >
        <div className={styles.brand}>
          <span className={styles.logo}>
            <Wrench size={22} />
          </span>
          <span className={styles.brandText}>
            <strong>Platform Maintenance</strong>
            <span className={styles.brandMeta}>
              <small>Manager</small>
              <UiVersion className={styles.version} />
            </span>
          </span>
        </div>

        <TenantSwitcher />
        <BarDivider />

        {navigationItems
          .filter(({ ability }) => can(ability))
          .map(({ to, label, icon: Icon }) => (
            <BarMenuItem
              key={to}
              icon={<Icon size={18} />}
              selected={pathname.startsWith(to)}
              onClick={() => void navigate({ to })}
            >
              {label}
            </BarMenuItem>
          ))}

        <div className={styles.spacer} />
        <BarDivider />
        <div className={styles.user}>
          <div className={styles.userIdentity}>
            <Avatar aria-label={user.displayName}>{getInitials(user.displayName)}</Avatar>
            <div className={styles.userText}>
              <strong>{user.displayName}</strong>
              {!import.meta.env.DEV ? <RoleSwitcher /> : null}
            </div>
          </div>
          {import.meta.env.DEV ? <RoleSwitcher /> : null}
        </div>
      </Bar>

      <main className={styles.main}>
        <Outlet />
      </main>
    </div>
  )
}
