import { AccessProvider } from '@/entities/access'

import type { FC, PropsWithChildren } from 'react'

interface WorkspaceProvidersProps extends PropsWithChildren {
  tenantId: string
}

export const WorkspaceProviders: FC<WorkspaceProvidersProps> = ({ tenantId, children }) => (
  <AccessProvider tenantId={tenantId}>{children}</AccessProvider>
)
