import DateFnsAdapter from '@date-io/date-fns'
import { QueryClientProvider } from '@tanstack/react-query'
import { RouterProvider } from '@tanstack/react-router'
import { DateLibAdapterProvider, ModalContainer, NotificationContainer } from '@v-uik/base'
import { ru } from 'date-fns/locale'

import { AppThemeProvider } from '@/shared/config'

import { queryClient, router } from '../../config'

import type { FC } from 'react'

export const AppProviders: FC = () => {
  return (
    <AppThemeProvider>
      <DateLibAdapterProvider dateAdapter={DateFnsAdapter} options={{ locale: ru }}>
        <QueryClientProvider client={queryClient}>
          <RouterProvider router={router} />
          <ModalContainer />
          <NotificationContainer
            position='top-right'
            autoClose={3_200}
            limit={3}
            closeButtonAriaLabel='Закрыть'
          />
        </QueryClientProvider>
      </DateLibAdapterProvider>
    </AppThemeProvider>
  )
}
