import { useNavigate } from '@tanstack/react-router'
import { Button, Tag, type ColumnProps, type RecordDataSource } from '@v-uik/base'
import { Eye } from 'lucide-react'
import { useMemo, type FC } from 'react'

import { Ability, useAccess } from '@/entities/access'
import { ProcessCategoryTag } from '@/entities/process'
import { ProcessStatusBadge, type ProcessHistoryItem } from '@/entities/process-history'
import { StopProcessButton } from '@/features/stop-process'
import { formatDateTime, formatDuration } from '@/shared/lib'
import { DataTable, EmptyState } from '@/shared/ui'

import styles from './HistoryTable.module.scss'

type HistoryRow = RecordDataSource<ProcessHistoryItem>

interface HistoryTableProps {
  items: ProcessHistoryItem[]
}

export const HistoryTable: FC<HistoryTableProps> = ({ items }) => {
  const navigate = useNavigate()
  const { can, canAny } = useAccess()
  const canOpenDetails = can(Ability.PROCESS_HISTORY_DETAILS)
  const showActions = canAny([Ability.PROCESS_HISTORY_DETAILS, Ability.PROCESS_STOP])

  const dataSource = useMemo<HistoryRow[]>(
    () =>
      items.map((item) => ({
        ...item,
        key: `${item.processId}-${item.sessionProcessId ?? 'empty'}`,
      })),
    [items],
  )

  const columns = useMemo<ColumnProps<HistoryRow>[]>(
    () => [
      {
        key: 'processName',
        dataIndex: 'processName',
        title: 'Процесс',
        width: 300,
        fixed: 'start',
        renderCellContent: ({ row }) => (
          <div className={styles.name}>
            <strong>{row.processName}</strong>
            <div>
              <Tag kind='lite'>{row.processType}</Tag>
              {row.label ? <ProcessCategoryTag category={row.label} /> : null}
              {row.isDeleted ? (
                <Tag kind='color' color='red'>
                  Удалён
                </Tag>
              ) : null}
            </div>
          </div>
        ),
      },
      {
        key: 'statusCode',
        dataIndex: 'statusCode',
        title: 'Статус',
        width: 150,
        renderCellContent: ({ row }) => (
          <ProcessStatusBadge code={row.statusCode} name={row.statusName} />
        ),
      },
      {
        key: 'startDateTime',
        dataIndex: 'startDateTime',
        title: 'Начало',
        width: 170,
        renderCellContent: ({ row }) => formatDateTime(row.startDateTime),
      },
      {
        key: 'endDateTime',
        dataIndex: 'endDateTime',
        title: 'Окончание',
        width: 170,
        renderCellContent: ({ row }) => formatDateTime(row.endDateTime),
      },
      {
        key: 'duration',
        title: 'Длительность',
        width: 140,
        renderCellContent: ({ row }) => formatDuration(row.startDateTime, row.endDateTime),
      },
      {
        key: 'sessionProcessId',
        dataIndex: 'sessionProcessId',
        title: 'Сессия',
        width: 120,
        renderCellContent: ({ row }) => (
          <code>{row.sessionProcessId ? `${row.sessionProcessId.slice(0, 8)}…` : '—'}</code>
        ),
      },
      ...(showActions
        ? [
            {
              key: 'actions',
              title: 'Действия',
              width: 104,
              fixed: 'end',
              align: 'center',
              renderCellContent: ({ row }: { row: HistoryRow }) => (
                <div className={styles.actions}>
                  {row.statusCode === 'WORKS' && row.sessionProcessId ? (
                    <StopProcessButton compact sessionId={row.sessionProcessId} />
                  ) : null}
                  {canOpenDetails && row.sessionProcessId ? (
                    <Button
                      kind='ghost'
                      color='secondary'
                      size='sm'
                      prefixIcon={<Eye size={17} />}
                      aria-label='Открыть детали'
                      title='Детали'
                      onClick={() =>
                        void navigate({
                          to: '/history/$sessionProcessId',
                          params: { sessionProcessId: row.sessionProcessId! },
                        })
                      }
                    />
                  ) : null}
                </div>
              ),
            } satisfies ColumnProps<HistoryRow>,
          ]
        : []),
    ],
    [canOpenDetails, navigate, showActions],
  )

  if (!items.length) {
    return (
      <EmptyState
        title='История пуста'
        description='Для текущей страницы и фильтра нет запусков.'
      />
    )
  }

  return (
    <DataTable
      fillAvailableHeight
      dataSource={dataSource}
      columns={columns}
      rowKey={(row) => `${row.processId}-${row.sessionProcessId ?? 'empty'}`}
    />
  )
}
