import type { DayOfWeek, TenantScheduleInfo } from '@/entities/schedule'
import type { ComboBoxOption } from '@/shared/lib'

export interface ScheduleFiltersSearch {
  query?: string
  category?: string
  day?: string
}

export interface ScheduleFiltersFormValues {
  query: string
  categories: string[]
  days: string[]
}

export const scheduleDayOptions: Array<ComboBoxOption & { value: DayOfWeek }> = [
  { value: 'MON', label: 'Понедельник' },
  { value: 'TUE', label: 'Вторник' },
  { value: 'WED', label: 'Среда' },
  { value: 'THU', label: 'Четверг' },
  { value: 'FRI', label: 'Пятница' },
  { value: 'SAT', label: 'Суббота' },
  { value: 'SUN', label: 'Воскресенье' },
]

const splitValues = (value?: string) => value?.split(',').filter(Boolean) ?? []

export const createScheduleFiltersValues = (
  search: ScheduleFiltersSearch,
): ScheduleFiltersFormValues => ({
  query: search.query ?? '',
  categories: splitValues(search.category),
  days: splitValues(search.day),
})

export const toScheduleFiltersSearch = (
  values: ScheduleFiltersFormValues,
): ScheduleFiltersSearch => ({
  query: values.query.trim() || undefined,
  category: values.categories.length ? values.categories.join(',') : undefined,
  day: values.days.length ? values.days.join(',') : undefined,
})

export const getScheduleCategoryOptions = (items: TenantScheduleInfo[]) =>
  [
    ...new Set(
      items.map(({ label }) => label).filter((label): label is string => Boolean(label)),
    ),
  ]
    .sort((left, right) => left.localeCompare(right, 'ru'))
    .map((value) => ({ value, label: value }))
