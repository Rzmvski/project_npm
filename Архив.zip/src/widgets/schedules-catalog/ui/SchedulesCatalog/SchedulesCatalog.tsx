import { keepPreviousData, useQuery } from '@tanstack/react-query'
import { useNavigate, useSearch } from '@tanstack/react-router'
import { Tag, type ColumnProps, type RecordDataSource } from '@v-uik/base'
import { useMemo, type FC } from 'react'

import { ProcessCategoryTag } from '@/entities/process'
import {
  schedulesQueryOptions,
  type ScheduleDay,
  type TenantScheduleInfo,
} from '@/entities/schedule'
import { useRequiredTenantId } from '@/entities/tenant'
import { DataTable, EmptyState, ErrorState, LoadingState, Pagination } from '@/shared/ui'

import { getScheduleCategoryOptions, type ScheduleFiltersSearch } from '../../model'
import { ScheduleFilters } from '../ScheduleFilters'
import { ScheduleTableActions } from '../ScheduleTableActions'

import styles from './SchedulesCatalog.module.scss'

const dayNames: Record<string, string> = {
  MON: 'Пн',
  TUE: 'Вт',
  WED: 'Ср',
  THU: 'Чт',
  FRI: 'Пт',
  SAT: 'Сб',
  SUN: 'Вс',
}

const groupSchedule = (scheduleDays: ScheduleDay[]) => {
  const groups = new Map<string, string[]>()

  scheduleDays.forEach((day) => {
    const key = `${day.startTime}–${day.endTime} · каждые ${day.intervalMin} мин.`
    groups.set(key, [...(groups.get(key) ?? []), dayNames[day.dayOfWeek] ?? day.dayOfWeek])
  })

  return [...groups.entries()]
}

type ScheduleRow = RecordDataSource<TenantScheduleInfo>

export const SchedulesCatalog: FC = () => {
  const tenantId = useRequiredTenantId()
  const search = useSearch({ from: '/_workspace/schedules' })
  const navigate = useNavigate({ from: '/schedules' })
  // q/category/day are local filter state only — GET /process/schedule documents just
  // page/size/sort, so they aren't forwarded to the backend.
  const query = useQuery({
    ...schedulesQueryOptions(tenantId, {
      page: search.page,
      size: search.size,
      sort: search.sort,
    }),
    placeholderData: keepPreviousData,
  })

  const setSearch = (patch: Partial<typeof search>) => {
    void navigate({
      search: (current) => ({ ...current, ...patch }),
      replace: true,
    })
  }

  const dataSource = useMemo<ScheduleRow[]>(
    () =>
      (query.data?.content ?? []).map((schedule) => ({
        ...schedule,
        key: schedule.processId,
      })),
    [query.data?.content],
  )

  const categoryOptions = useMemo(() => {
    const options = getScheduleCategoryOptions(query.data?.content ?? [])
    const selected = search.category?.split(',').filter(Boolean) ?? []
    const knownValues = new Set(options.map(({ value }) => value))

    return [
      ...options,
      ...selected
        .filter((value) => !knownValues.has(value))
        .map((value) => ({ value, label: value })),
    ]
  }, [query.data?.content, search.category])

  const columns = useMemo<ColumnProps<ScheduleRow>[]>(
    () => [
      {
        key: 'processName',
        dataIndex: 'processName',
        title: 'Процесс',
        width: 320,
        fixed: 'start',
        renderCellContent: ({ row }) => (
          <div className={styles.process}>
            <strong>{row.processName}</strong>
            <span>{row.description || 'Без описания'}</span>
          </div>
        ),
      },
      {
        key: 'processType',
        dataIndex: 'processType',
        title: 'Тип',
        width: 150,
        renderCellContent: ({ row }) => <Tag kind='lite'>{row.processType}</Tag>,
      },
      {
        key: 'label',
        dataIndex: 'label',
        title: 'Категория',
        width: 160,
        renderCellContent: ({ row }) =>
          row.label ? (
            <ProcessCategoryTag category={row.label} />
          ) : (
            <span className={styles.muted}>Не указана</span>
          ),
      },
      {
        key: 'scheduleDays',
        dataIndex: 'scheduleDays',
        title: 'Расписание',
        width: 360,
        renderCellContent: ({ row }) => (
          <div className={styles.groups}>
            {groupSchedule(row.scheduleDays).map(([rule, days]) => (
              <div key={rule}>
                <b>{days.join(', ')}</b>
                <span>{rule}</span>
              </div>
            ))}
          </div>
        ),
      },
      {
        key: 'actions',
        title: 'Действия',
        width: 136,
        fixed: 'end',
        align: 'center',
        renderCellContent: ({ row }: { row: ScheduleRow }) => (
          <ScheduleTableActions processId={row.processId} processName={row.processName} />
        ),
      } satisfies ColumnProps<ScheduleRow>,
    ],
    [],
  )

  if (query.isPending) return <LoadingState label='Загружаем расписания…' />
  if (query.isError) return <ErrorState title='Не удалось загрузить расписания' />

  const hasActiveFilters = Boolean(search.query || search.category || search.day)

  return (
    <div className={styles.catalog}>
      <ScheduleFilters
        search={search}
        categoryOptions={categoryOptions}
        onChange={(filters: ScheduleFiltersSearch) => setSearch({ ...filters, page: 0 })}
      />
      {dataSource.length ? (
        <>
          <DataTable
            fillAvailableHeight
            dataSource={dataSource}
            columns={columns}
            rowKey='processId'
          />
          <Pagination
            page={query.data.number}
            totalPages={query.data.totalPages}
            size={query.data.size}
            totalElements={query.data.totalElements}
            onPageChange={(page) => setSearch({ page })}
            onSizeChange={(size) => setSearch({ size, page: 0 })}
          />
        </>
      ) : (
        <EmptyState
          title={hasActiveFilters ? 'Расписания не найдены' : 'Расписания не настроены'}
          description={
            hasActiveFilters
              ? 'Измените параметры фильтрации.'
              : 'Создайте расписание для процесса с помощью действия в заголовке страницы.'
          }
        />
      )}
    </div>
  )
}
