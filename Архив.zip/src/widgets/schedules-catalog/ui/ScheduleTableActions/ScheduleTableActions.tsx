import { useNavigate } from '@tanstack/react-router'
import { Button } from '@v-uik/base'
import { Eye, Pencil } from 'lucide-react'

import { Ability, useCan } from '@/entities/access'
import { DeleteScheduleButton } from '@/features/manage-schedule'

import styles from './ScheduleTableActions.module.scss'

import type { FC } from 'react'

interface ScheduleTableActionsProps {
  processId: string
  processName: string
}

export const ScheduleTableActions: FC<ScheduleTableActionsProps> = ({
  processId,
  processName,
}) => {
  const navigate = useNavigate()
  const canEdit = useCan(Ability.SCHEDULE_UPDATE)

  return (
    <div className={styles.actions}>
      <Button
        type='button'
        kind='ghost'
        color='secondary'
        size='sm'
        prefixIcon={<Eye size={17} />}
        aria-label={`Открыть расписание ${processName}`}
        title='Открыть расписание'
        onClick={() =>
          void navigate({
            to: '/schedules/$processId',
            params: { processId },
          })
        }
      />

      {canEdit ? (
        <Button
          type='button'
          kind='ghost'
          color='secondary'
          size='sm'
          prefixIcon={<Pencil size={17} />}
          aria-label={`Редактировать расписание ${processName}`}
          title='Редактировать'
          onClick={() =>
            void navigate({
              to: '/schedules/$processId/edit',
              params: { processId },
            })
          }
        />
      ) : null}

      <DeleteScheduleButton compact processId={processId} processName={processName} />
    </div>
  )
}
