import { Button, ComboBox } from '@v-uik/base'
import { FilterX } from 'lucide-react'
import { useEffect, useMemo, type FC } from 'react'
import { Controller, useForm } from 'react-hook-form'

import { findComboBoxOptions, getComboBoxValues, type ComboBoxOption } from '@/shared/lib'
import { SearchInput } from '@/shared/ui'

import {
  createScheduleFiltersValues,
  scheduleDayOptions,
  toScheduleFiltersSearch,
  type ScheduleFiltersFormValues,
  type ScheduleFiltersSearch,
} from '../../model'

import styles from './ScheduleFilters.module.scss'

interface ScheduleFiltersProps {
  search: ScheduleFiltersSearch
  categoryOptions: ComboBoxOption[]
  onChange: (search: ScheduleFiltersSearch) => void
}

export const ScheduleFilters: FC<ScheduleFiltersProps> = ({
  search,
  categoryOptions,
  onChange,
}) => {
  const searchKey = JSON.stringify(search)
  const initialValues = useMemo(() => createScheduleFiltersValues(search), [search])
  const { control, getValues, reset } = useForm<ScheduleFiltersFormValues>({
    defaultValues: initialValues,
  })

  useEffect(() => {
    reset(initialValues)
  }, [initialValues, reset])

  const updateFilters = (patch: Partial<ScheduleFiltersFormValues>) => {
    const nextSearch = toScheduleFiltersSearch({ ...getValues(), ...patch })
    if (JSON.stringify(nextSearch) !== searchKey) onChange(nextSearch)
  }

  const resetFilters = () => {
    const emptyFilters = createScheduleFiltersValues({})
    reset(emptyFilters)
    onChange({})
  }

  const hasActiveFilters = Object.values(search).some(Boolean)

  return (
    <form className={styles.filters} aria-label='Фильтры расписаний'>
      <div className={styles.filterGrid}>
        <div className={styles.searchField}>
          <Controller
            name='query'
            control={control}
            render={({ field }) => (
              <SearchInput
                label='Процесс'
                value={field.value}
                placeholder='Название процесса'
                debounceMs={250}
                onChange={(value) => {
                  field.onChange(value)
                  updateFilters({ query: value })
                }}
              />
            )}
          />
        </div>

        <Controller
          name='categories'
          control={control}
          render={({ field }) => (
            <ComboBox<ComboBoxOption>
              multiple
              canClear
              isSearchable
              openOnFocus
              disableCloseOnSelect
              limitTags={2}
              label='Теги'
              placeholder='Все теги'
              noOptionsText='Теги не найдены'
              options={categoryOptions}
              value={findComboBoxOptions(field.value, categoryOptions)}
              inputProps={{ name: field.name }}
              controlInnerProps={{ onBlur: field.onBlur }}
              onChange={(_value, _event, fullValue) => {
                const values = getComboBoxValues(fullValue)
                field.onChange(values)
                updateFilters({ categories: values })
              }}
            />
          )}
        />

        <Controller
          name='days'
          control={control}
          render={({ field }) => (
            <ComboBox<ComboBoxOption>
              multiple
              canClear
              openOnFocus
              disableCloseOnSelect
              limitTags={2}
              label='Дни недели'
              placeholder='Все дни'
              options={scheduleDayOptions}
              value={findComboBoxOptions(field.value, scheduleDayOptions)}
              inputProps={{ name: field.name }}
              controlInnerProps={{ onBlur: field.onBlur }}
              onChange={(_value, _event, fullValue) => {
                const values = getComboBoxValues(fullValue)
                field.onChange(values)
                updateFilters({ days: values })
              }}
            />
          )}
        />

        <Button
          type='button'
          kind='ghost'
          color='secondary'
          prefixIcon={<FilterX size={16} />}
          disabled={!hasActiveFilters}
          onClick={resetFilters}
        >
          Сбросить
        </Button>
      </div>
    </form>
  )
}
