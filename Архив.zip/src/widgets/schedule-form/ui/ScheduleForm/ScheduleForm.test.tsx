import { waitFor } from '@testing-library/react'
import { beforeEach, describe, expect, it, vi } from 'vitest'

import * as scheduleApi from '@/entities/schedule'
import { TEST_PROCESS_ID, TEST_TENANT_ID } from '@/test'

import { ScheduleFormTestModel } from './ScheduleForm.test-model'

describe('schedule form', () => {
  beforeEach(() => {
    vi.spyOn(scheduleApi, 'getSchedule').mockResolvedValue(null)
  })

  it('creates one schedule day for every selected weekday', async () => {
    const createSchedule = vi.spyOn(scheduleApi, 'createSchedule').mockResolvedValue(undefined)
    const form = await ScheduleFormTestModel.create()

    await form.selectWeekdays()
    form.expectSelectedDays('Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница')
    await form.setCommonInterval(30)
    await form.submit()

    await waitFor(() =>
      expect(createSchedule).toHaveBeenCalledWith(TEST_TENANT_ID, {
        processId: TEST_PROCESS_ID,
        scheduleDays: [
          { dayOfWeek: 'MON', startTime: '09:00', endTime: '18:00', intervalMin: 30 },
          { dayOfWeek: 'TUE', startTime: '09:00', endTime: '18:00', intervalMin: 30 },
          { dayOfWeek: 'WED', startTime: '09:00', endTime: '18:00', intervalMin: 30 },
          { dayOfWeek: 'THU', startTime: '09:00', endTime: '18:00', intervalMin: 30 },
          { dayOfWeek: 'FRI', startTime: '09:00', endTime: '18:00', intervalMin: 30 },
        ],
      }),
    )
  })

  it('shows manually selected days in calendar order instead of click order', async () => {
    const form = await ScheduleFormTestModel.create()

    await form.selectDays('Пт', 'Пн', 'Ср', 'Вс')

    form.expectDayOrder('Понедельник', 'Среда', 'Пятница', 'Воскресенье')
  })
})
