import { zodResolver } from '@hookform/resolvers/zod'
import { useQuery } from '@tanstack/react-query'
import { Link, useNavigate, useSearch } from '@tanstack/react-router'
import { notification } from '@v-uik/base'
import { CalendarClock } from 'lucide-react'
import { useEffect, type FC } from 'react'
import { useFieldArray, useForm, useWatch } from 'react-hook-form'

import { Ability, useAccess } from '@/entities/access'
import { processListQueryOptions } from '@/entities/process'
import { scheduleQueryOptions, type DayOfWeek } from '@/entities/schedule'
import { useRequiredTenantId } from '@/entities/tenant'
import { DeleteScheduleButton, useSaveSchedule } from '@/features/manage-schedule'
import {
  ErrorState,
  FormHeroActions,
  FormPageLayout,
  LoadingState,
  PageBreadcrumbs,
} from '@/shared/ui'

import {
  createDefaultDay,
  defaultScheduleFormValues,
  orderDayCodes,
  scheduleFormSchema,
  sortScheduleDays,
  type ScheduleFormValues,
} from '../../model'
import { ScheduleCommonSettings } from '../ScheduleCommonSettings'
import { ScheduleDaysEditor } from '../ScheduleDaysEditor'
import { ScheduleDaySelector } from '../ScheduleDaySelector'
import { SchedulePreview } from '../SchedulePreview'

interface ScheduleFormProps {
  processId: string
}

export const ScheduleForm: FC<ScheduleFormProps> = ({ processId }) => {
  const tenantId = useRequiredTenantId()
  const { can } = useAccess()
  const navigate = useNavigate()
  const search = useSearch({ from: '/_workspace/schedules/$processId/edit' })
  const processesQuery = useQuery(processListQueryOptions(tenantId))
  const scheduleQuery = useQuery(scheduleQueryOptions(tenantId, processId))
  const exists = Boolean(scheduleQuery.data)
  const canSave = can(exists ? Ability.SCHEDULE_UPDATE : Ability.SCHEDULE_CREATE)
  const mutation = useSaveSchedule(exists)

  const {
    control,
    getValues,
    handleSubmit,
    reset,
    formState: { isDirty, isValid },
  } = useForm<ScheduleFormValues>({
    resolver: zodResolver(scheduleFormSchema),
    defaultValues: defaultScheduleFormValues,
    mode: 'onChange',
    reValidateMode: 'onChange',
  })

  const { fields, remove, replace } = useFieldArray({
    control,
    name: 'scheduleDays',
    keyName: 'fieldId',
  })
  const days = useWatch({ control, name: 'scheduleDays' })

  useEffect(() => {
    if (!scheduleQuery.data) return
    const firstDay = scheduleQuery.data.scheduleDays[0]
    reset({
      commonStart: firstDay?.startTime ?? defaultScheduleFormValues.commonStart,
      commonEnd: firstDay?.endTime ?? defaultScheduleFormValues.commonEnd,
      commonInterval: firstDay?.intervalMin ?? defaultScheduleFormValues.commonInterval,
      scheduleDays: sortScheduleDays(scheduleQuery.data.scheduleDays),
    })
  }, [reset, scheduleQuery.data])

  const process = processesQuery.data?.find((item) => item.id === processId)

  if (processesQuery.isPending || scheduleQuery.isPending) {
    return <LoadingState label='Загружаем расписание…' />
  }
  if (processesQuery.isError || scheduleQuery.isError) {
    return <ErrorState title='Не удалось загрузить расписание' />
  }
  if (!process) return <ErrorState title='Процесс не найден' />
  if (!canSave) {
    return (
      <ErrorState
        title='Недостаточно прав'
        description='Ролевая модель не разрешает сохранять это расписание.'
      />
    )
  }

  const setSelectedDays = (codes: DayOfWeek[]) => {
    const current = new Map(getValues('scheduleDays').map((day) => [day.dayOfWeek, day]))
    replace(orderDayCodes(codes).map((code) => current.get(code) ?? createDefaultDay(code)))
  }

  const applyCommon = () => {
    const commonStart = getValues('commonStart')
    const commonEnd = getValues('commonEnd')
    const commonInterval = getValues('commonInterval')
    replace(
      getValues('scheduleDays').map((day) => ({
        ...day,
        startTime: commonStart,
        endTime: commonEnd,
        intervalMin: commonInterval,
      })),
    )
  }

  const returnToProcess = search.returnTo === 'process'

  const leaveEditor = () => {
    if (returnToProcess) {
      void navigate({
        to: '/processes/$processId',
        params: { processId },
      })
      return
    }
    void navigate({ to: '/schedules' })
  }

  const cancel = () => {
    if (isDirty && !window.confirm('Несохранённые изменения будут потеряны. Продолжить?')) {
      return
    }
    leaveEditor()
  }

  return (
    <FormPageLayout
      breadcrumbs={
        <PageBreadcrumbs>
          <Link to='/schedules'>Расписания</Link>
          {exists ? (
            <Link to='/schedules/$processId' params={{ processId }}>
              {process.processName}
            </Link>
          ) : (
            <span>{process.processName}</span>
          )}
          <span aria-current='page'>
            {exists ? 'Редактирование расписания' : 'Создание расписания'}
          </span>
        </PageBreadcrumbs>
      }
      icon={<CalendarClock size={24} />}
      eyebrow='Недельное интервальное расписание'
      title={process.processName}
      description='В выбранные дни процесс запускается внутри временного окна через заданный интервал.'
      aside={
        <SchedulePreview
          days={days}
          action={
            exists ? (
              <DeleteScheduleButton processId={processId} onDeleted={leaveEditor} />
            ) : null
          }
        />
      }
      heroActions={
        <FormHeroActions
          cancelDisabled={mutation.isPending}
          submitDisabled={!isDirty || !isValid || mutation.isPending}
          pending={mutation.isPending}
          submitLabel={exists ? 'Сохранить изменения' : 'Создать расписание'}
          onCancel={cancel}
        />
      }
      noValidate
      onSubmit={handleSubmit((values) => {
        mutation.mutate(
          { processId, scheduleDays: values.scheduleDays },
          {
            onSuccess: () => {
              notification.success(exists ? 'Расписание обновлено' : 'Расписание создано')
              leaveEditor()
            },
            onError: (error) => notification.error(error.message),
          },
        )
      })}
    >
      <ScheduleDaySelector
        value={days.map((day) => day.dayOfWeek)}
        onChange={setSelectedDays}
      />
      <ScheduleCommonSettings control={control} disabled={!days.length} onApply={applyCommon} />
      <ScheduleDaysEditor control={control} fields={fields} onRemove={remove} />
    </FormPageLayout>
  )
}
