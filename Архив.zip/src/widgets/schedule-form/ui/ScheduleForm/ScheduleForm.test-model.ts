import { screen, waitFor } from '@testing-library/react'
import { expect } from 'vitest'

import { Permission } from '@/entities/access'
import { processFixture, renderApp, TEST_PROCESS_ID, userAccessFixture } from '@/test'

import type { UserEvent } from '@testing-library/user-event'

export class ScheduleFormTestModel {
  private constructor(readonly user: UserEvent) {}

  static async create() {
    const app = await renderApp({
      route: `/schedules/${TEST_PROCESS_ID}/edit?returnTo=process`,
      access: userAccessFixture([Permission.SCHEDULE_CREATE, Permission.SCHEDULE_DELETE]),
      processes: [processFixture()],
      schedule: null,
    })

    await screen.findByRole('heading', { name: 'Дневная загрузка данных' })
    return new ScheduleFormTestModel(app.user)
  }

  async selectWeekdays() {
    await this.user.click(screen.getByRole('button', { name: 'Будни' }))
  }

  async selectDays(...days: string[]) {
    for (const day of days) {
      await this.user.click(screen.getByRole('button', { name: new RegExp(`^${day}$`) }))
    }
  }

  async setCommonInterval(value: number) {
    const input = screen.getByRole('spinbutton', { name: 'Интервал, мин.' })
    await this.user.clear(input)
    await this.user.type(input, String(value))
    await this.user.click(screen.getByRole('button', { name: 'Применить ко всем' }))
  }

  expectSelectedDays(...days: string[]) {
    for (const day of days) {
      expect(screen.getByText(day)).toBeVisible()
    }
  }

  expectDayOrder(...days: string[]) {
    expect(
      screen
        .getAllByRole('button', { name: /^Удалить / })
        .map((button) => button.getAttribute('aria-label')),
    ).toEqual(days.map((day) => `Удалить ${day}`))
  }

  async submit() {
    const button = screen.getByRole('button', { name: 'Создать расписание' })
    await waitFor(() => expect(button).toBeEnabled())
    await this.user.click(button)
  }
}
