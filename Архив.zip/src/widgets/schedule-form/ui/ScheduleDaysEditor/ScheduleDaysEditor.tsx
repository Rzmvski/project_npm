import { Button } from '@v-uik/base'
import { Trash2 } from 'lucide-react'

import { FormNumberInput, FormSection } from '@/shared/ui'

import { dayMeta, type ScheduleFormValues } from '../../model'
import { ScheduleTimePicker } from '../ScheduleTimePicker'

import styles from './ScheduleDaysEditor.module.scss'

import type { FC } from 'react'
import type { Control, FieldArrayWithId } from 'react-hook-form'

interface ScheduleDaysEditorProps {
  control: Control<ScheduleFormValues>
  fields: FieldArrayWithId<ScheduleFormValues, 'scheduleDays', 'fieldId'>[]
  onRemove: (index: number) => void
}

export const ScheduleDaysEditor: FC<ScheduleDaysEditorProps> = ({
  control,
  fields,
  onRemove,
}) => {
  return (
    <FormSection
      title='3. Настройте дни'
      description='Задайте временное окно и интервал отдельно для каждого выбранного дня.'
    >
      {fields.length ? (
        <div className={styles.rows}>
          {fields.map((day, index) => {
            const meta = dayMeta.find((item) => item.code === day.dayOfWeek)
            return (
              <div className={styles.row} key={day.fieldId}>
                <div className={styles.dayHeader}>
                  <div className={styles.day}>
                    <span>{meta?.short}</span>
                    <strong>{meta?.label}</strong>
                  </div>
                  <Button
                    type='button'
                    kind='ghost'
                    color='error'
                    size='sm'
                    prefixIcon={<Trash2 size={16} />}
                    classes={{ button: styles.removeButton }}
                    aria-label={`Удалить ${meta?.label ?? day.dayOfWeek}`}
                    onClick={() => onRemove(index)}
                  />
                </div>
                <div className={styles.fields}>
                  <ScheduleTimePicker
                    name={`scheduleDays.${index}.startTime` as const}
                    control={control}
                    label='Начало'
                  />
                  <ScheduleTimePicker
                    name={`scheduleDays.${index}.endTime` as const}
                    control={control}
                    label='Окончание'
                  />
                  <div className={styles.interval}>
                    <FormNumberInput
                      name={`scheduleDays.${index}.intervalMin` as const}
                      control={control}
                      label='Каждые, мин.'
                      precision={0}
                      fullWidth
                      inputProps={{ min: 1 }}
                    />
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      ) : (
        <div className={styles.empty}>Выберите хотя бы один день недели.</div>
      )}
    </FormSection>
  )
}
