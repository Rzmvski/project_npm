import { Button, ButtonGroup } from '@v-uik/base'
import { RotateCcw } from 'lucide-react'

import type { DayOfWeek } from '@/entities/schedule'
import { FormSection } from '@/shared/ui'

import { dayMeta } from '../../model'

import styles from './ScheduleDaySelector.module.scss'

import type { FC } from 'react'

interface ScheduleDaySelectorProps {
  value: DayOfWeek[]
  onChange: (days: DayOfWeek[]) => void
}

export const ScheduleDaySelector: FC<ScheduleDaySelectorProps> = ({ value, onChange }) => {
  return (
    <FormSection
      title='1. Выберите дни'
      description='Можно использовать быстрый пресет или настроить дни вручную.'
      headerAction={
        <div className={styles.presets}>
          <Button
            type='button'
            kind='outlined'
            color='secondary'
            size='sm'
            onClick={() => onChange(['MON', 'TUE', 'WED', 'THU', 'FRI'])}
          >
            Будни
          </Button>
          <Button
            type='button'
            kind='outlined'
            color='secondary'
            size='sm'
            onClick={() => onChange(dayMeta.map((day) => day.code))}
          >
            Каждый день
          </Button>
          <Button
            type='button'
            kind='ghost'
            color='secondary'
            size='sm'
            prefixIcon={<RotateCcw size={14} />}
            onClick={() => onChange([])}
          >
            Очистить
          </Button>
        </div>
      }
    >
      <div className={styles.days}>
        <ButtonGroup
          kind='multi'
          color='primary'
          value={value}
          onChange={(_event, nextValue) => {
            if (Array.isArray(nextValue)) onChange(nextValue as DayOfWeek[])
          }}
        >
          {dayMeta.map((day) => (
            <Button key={day.code} type='button' name={day.code}>
              {day.short}
            </Button>
          ))}
        </ButtonGroup>
      </div>
    </FormSection>
  )
}
