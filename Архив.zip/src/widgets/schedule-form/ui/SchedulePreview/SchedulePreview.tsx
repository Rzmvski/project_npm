import type { ScheduleDay } from '@/entities/schedule'

import { dayMeta } from '../../model'

import styles from './SchedulePreview.module.scss'

import type { FC, ReactNode } from 'react'

interface SchedulePreviewProps {
  days: ScheduleDay[]
  title?: string
  emptyMessage?: string
  action?: ReactNode
}

export const SchedulePreview: FC<SchedulePreviewProps> = ({
  days,
  title = 'Предпросмотр',
  emptyMessage = 'Расписание ещё не заполнено.',
  action,
}) => {
  return (
    <section className={styles.preview}>
      <h2>{title}</h2>
      <div className={styles.list}>
        {days.map((day) => {
          const meta = dayMeta.find((item) => item.code === day.dayOfWeek)
          return (
            <div key={day.dayOfWeek}>
              <span>{meta?.short}</span>
              <p>
                <b>
                  {day.startTime}–{day.endTime}
                </b>
                <small>каждые {day.intervalMin} мин.</small>
              </p>
            </div>
          )
        })}
      </div>
      {!days.length ? <p className={styles.muted}>{emptyMessage}</p> : null}
      {action ? <div className={styles.action}>{action}</div> : null}
    </section>
  )
}
