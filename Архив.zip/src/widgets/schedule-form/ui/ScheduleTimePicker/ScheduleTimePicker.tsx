import { TimePicker } from '@v-uik/base'
import { Clock3 } from 'lucide-react'
import { Controller } from 'react-hook-form'

import type { ScheduleFormValues } from '../../model'
import type { FC } from 'react'
import type { Control, FieldPathByValue } from 'react-hook-form'

interface ScheduleTimePickerProps {
  name: FieldPathByValue<ScheduleFormValues, string>
  control: Control<ScheduleFormValues>
  label: string
}

const parseTime = (value: string): Date | null => {
  const match = /^(\d{2}):(\d{2})$/.exec(value)
  if (!match) return null

  const hours = Number(match[1])
  const minutes = Number(match[2])
  if (hours > 23 || minutes > 59) return null

  return new Date(2000, 0, 1, hours, minutes)
}

const formatTime = (value: Date) =>
  `${String(value.getHours()).padStart(2, '0')}:${String(value.getMinutes()).padStart(2, '0')}`

export const ScheduleTimePicker: FC<ScheduleTimePickerProps> = ({ name, control, label }) => (
  <Controller
    name={name}
    control={control}
    render={({ field, fieldState }) => (
      <TimePicker<Date>
        label={label}
        format='HH:mm'
        mask='11:11'
        value={parseTime(String(field.value ?? ''))}
        error={Boolean(fieldState.error)}
        helperText={fieldState.error?.message}
        inputProps={{
          fullWidth: true,
          suffix: <Clock3 size={16} aria-hidden />,
          inputProps: {
            name: field.name,
            onBlur: field.onBlur,
            'aria-label': label,
          },
        }}
        onChange={(value) => field.onChange(value ? formatTime(value) : '')}
      />
    )}
  />
)
