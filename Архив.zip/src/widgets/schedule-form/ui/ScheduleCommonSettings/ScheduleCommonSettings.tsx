import { Button } from '@v-uik/base'
import { Copy } from 'lucide-react'

import { FormNumberInput, FormSection } from '@/shared/ui'

import { ScheduleTimePicker } from '../ScheduleTimePicker'

import styles from './ScheduleCommonSettings.module.scss'

import type { ScheduleFormValues } from '../../model'
import type { FC } from 'react'
import type { Control } from 'react-hook-form'

interface ScheduleCommonSettingsProps {
  control: Control<ScheduleFormValues>
  disabled: boolean
  onApply: () => void
}

export const ScheduleCommonSettings: FC<ScheduleCommonSettingsProps> = ({
  control,
  disabled,
  onApply,
}) => {
  return (
    <FormSection
      title='2. Общие параметры'
      description='Примените одинаковое окно ко всем выбранным дням, затем скорректируйте отдельные строки.'
    >
      <div className={styles.grid}>
        <ScheduleTimePicker name='commonStart' control={control} label='Начало' />
        <ScheduleTimePicker name='commonEnd' control={control} label='Окончание' />
        <FormNumberInput
          name='commonInterval'
          control={control}
          label='Интервал, мин.'
          precision={0}
          fullWidth
          inputProps={{ min: 1 }}
        />
        <Button
          type='button'
          prefixIcon={<Copy size={16} />}
          onClick={onApply}
          disabled={disabled}
        >
          Применить ко всем
        </Button>
      </div>
    </FormSection>
  )
}
