import { CalendarDays, Clock3, RefreshCw } from 'lucide-react'

import type { DayOfWeek, ScheduleDay } from '@/entities/schedule'

import styles from './ScheduleWeekCard.module.scss'

import type { FC } from 'react'

const week: Array<{ code: DayOfWeek; short: string; label: string }> = [
  { code: 'MON', short: 'Пн', label: 'Понедельник' },
  { code: 'TUE', short: 'Вт', label: 'Вторник' },
  { code: 'WED', short: 'Ср', label: 'Среда' },
  { code: 'THU', short: 'Чт', label: 'Четверг' },
  { code: 'FRI', short: 'Пт', label: 'Пятница' },
  { code: 'SAT', short: 'Сб', label: 'Суббота' },
  { code: 'SUN', short: 'Вс', label: 'Воскресенье' },
]

const pluralDays = (count: number) => {
  if (count % 10 === 1 && count % 100 !== 11) return `${count} активный день`
  if ([2, 3, 4].includes(count % 10) && ![12, 13, 14].includes(count % 100)) {
    return `${count} активных дня`
  }
  return `${count} активных дней`
}

interface ScheduleWeekCardProps {
  days: ScheduleDay[]
}

export const ScheduleWeekCard: FC<ScheduleWeekCardProps> = ({ days }) => {
  const daysByCode = new Map(days.map((day) => [day.dayOfWeek, day]))

  return (
    <section className={styles.card} aria-labelledby='weekly-schedule-title'>
      <div className={styles.cardHeader}>
        <div className={styles.heading}>
          <span className={styles.icon}>
            <CalendarDays size={20} aria-hidden />
          </span>
          <div>
            <h2 id='weekly-schedule-title'>Недельное расписание</h2>
            <p>Временные окна и интервалы повторного запуска.</p>
          </div>
        </div>
        <span className={styles.daysCounter}>{pluralDays(days.length)}</span>
      </div>

      <div className={styles.week}>
        {week.map((meta) => {
          const day = daysByCode.get(meta.code)

          return (
            <article
              className={styles.day}
              data-active={Boolean(day) || undefined}
              key={meta.code}
            >
              <div className={styles.dayHeader}>
                <span>{meta.short}</span>
                <strong>{meta.label}</strong>
              </div>
              {day ? (
                <div className={styles.dayDetails}>
                  <div>
                    <Clock3 size={15} aria-hidden />
                    <span>
                      {day.startTime}–{day.endTime}
                    </span>
                  </div>
                  <div>
                    <RefreshCw size={15} aria-hidden />
                    <span>Каждые {day.intervalMin} мин.</span>
                  </div>
                </div>
              ) : (
                <span className={styles.inactive}>Запуски отключены</span>
              )}
            </article>
          )
        })}
      </div>
    </section>
  )
}
