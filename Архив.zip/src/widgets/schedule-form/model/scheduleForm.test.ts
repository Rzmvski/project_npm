import { describe, expect, it } from 'vitest'

import {
  createDefaultDay,
  orderDayCodes,
  scheduleFormSchema,
  sortScheduleDays,
} from './scheduleForm'

describe('schedule form domain model', () => {
  it('requires at least one selected day', () => {
    const result = scheduleFormSchema.safeParse({
      commonStart: '09:00',
      commonEnd: '18:00',
      commonInterval: 60,
      scheduleDays: [],
    })

    expect(result.success).toBe(false)
  })

  it('requires the end time to be later than the start time', () => {
    const result = scheduleFormSchema.safeParse({
      commonStart: '09:00',
      commonEnd: '18:00',
      commonInterval: 60,
      scheduleDays: [
        {
          dayOfWeek: 'MON',
          startTime: '18:00',
          endTime: '09:00',
          intervalMin: 60,
        },
      ],
    })

    expect(result.success).toBe(false)
    if (!result.success) {
      expect(result.error.issues[0]).toMatchObject({
        path: ['scheduleDays', 0, 'endTime'],
        message: 'Окончание должно быть позже начала',
      })
    }
  })

  it('creates a day with safe defaults', () => {
    expect(createDefaultDay('FRI')).toEqual({
      dayOfWeek: 'FRI',
      startTime: '09:00',
      endTime: '18:00',
      intervalMin: 60,
    })
  })

  it('orders selected days from Monday to Sunday', () => {
    expect(orderDayCodes(['FRI', 'MON', 'SUN', 'WED'])).toEqual(['MON', 'WED', 'FRI', 'SUN'])

    expect(
      sortScheduleDays([
        createDefaultDay('SUN'),
        createDefaultDay('TUE'),
        createDefaultDay('SAT'),
      ]).map((day) => day.dayOfWeek),
    ).toEqual(['TUE', 'SAT', 'SUN'])
  })
})
