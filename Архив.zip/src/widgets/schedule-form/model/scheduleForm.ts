import { z } from 'zod'

import type { DayOfWeek, ScheduleDay } from '@/entities/schedule'

const DAY_CODES = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'] as const
const TIME_PATTERN = /^([01]\d|2[0-3]):[0-5]\d$/

const getDayIndex = (day: DayOfWeek) => DAY_CODES.indexOf(day)

const scheduleDaySchema = z
  .object({
    dayOfWeek: z.enum(DAY_CODES),
    startTime: z.string().regex(TIME_PATTERN, 'Укажите время начала'),
    endTime: z.string().regex(TIME_PATTERN, 'Укажите время окончания'),
    intervalMin: z
      .number()
      .int('Укажите целое число')
      .min(1, 'Интервал должен быть больше нуля'),
  })
  .refine((day) => day.startTime < day.endTime, {
    path: ['endTime'],
    message: 'Окончание должно быть позже начала',
  })

export const scheduleFormSchema = z.object({
  commonStart: z.string().regex(TIME_PATTERN, 'Укажите время начала'),
  commonEnd: z.string().regex(TIME_PATTERN, 'Укажите время окончания'),
  commonInterval: z.number().int().min(1, 'Интервал должен быть больше нуля'),
  scheduleDays: z.array(scheduleDaySchema).min(1, 'Выберите хотя бы один день'),
})

export type ScheduleFormValues = z.infer<typeof scheduleFormSchema>

export interface DayMeta {
  code: DayOfWeek
  short: string
  label: string
}

export const dayMeta: DayMeta[] = [
  { code: 'MON', short: 'Пн', label: 'Понедельник' },
  { code: 'TUE', short: 'Вт', label: 'Вторник' },
  { code: 'WED', short: 'Ср', label: 'Среда' },
  { code: 'THU', short: 'Чт', label: 'Четверг' },
  { code: 'FRI', short: 'Пт', label: 'Пятница' },
  { code: 'SAT', short: 'Сб', label: 'Суббота' },
  { code: 'SUN', short: 'Вс', label: 'Воскресенье' },
]

export const defaultScheduleFormValues: ScheduleFormValues = {
  commonStart: '09:00',
  commonEnd: '18:00',
  commonInterval: 60,
  scheduleDays: [],
}

export function createDefaultDay(dayOfWeek: DayOfWeek): ScheduleDay {
  return {
    dayOfWeek,
    startTime: '09:00',
    endTime: '18:00',
    intervalMin: 60,
  }
}

export const orderDayCodes = (days: readonly DayOfWeek[]) =>
  [...days].sort((left, right) => getDayIndex(left) - getDayIndex(right))

export const sortScheduleDays = (days: readonly ScheduleDay[]) =>
  [...days].sort((left, right) => getDayIndex(left.dayOfWeek) - getDayIndex(right.dayOfWeek))
