export type SessionView = 'summary' | 'routes' | 'threads'

export interface ProcessSessionSearchState {
  view: SessionView
  routePage: number
  routeSize: number
  routeSort: string
  routeQuery?: string
  routeStatus?: string
  threadRouteSessionId?: string
  threadRouteKey?: string
  threadPod?: string
  threadStatus?: string
  threadPage: number
  threadSize: number
  threadSort: string
}
