import type { ProcessStatusCode } from '@/entities/process-history'
import type { ComboBoxOption } from '@/shared/lib'

export interface RouteFiltersValues {
  query: string
  statuses: string[]
}

export interface ThreadFiltersValues {
  route: string
  pod: string
  statuses: string[]
}

export const sessionStatusOptions: Array<ComboBoxOption & { value: ProcessStatusCode }> = [
  { value: 'CREATED', label: 'Создан' },
  { value: 'WORKS', label: 'Исполняется' },
  { value: 'SUCCESS', label: 'Завершён' },
  { value: 'ERROR', label: 'Ошибка' },
  { value: 'CANCELED', label: 'Отменён' },
  { value: 'STOPPED', label: 'Остановлен' },
]

export const splitFilterValues = (value?: string) => value?.split(',').filter(Boolean) ?? []
