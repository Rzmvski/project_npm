import { screen, within } from '@testing-library/react'
import { expect } from 'vitest'

import { Permission } from '@/entities/access'
import { historyKeys } from '@/entities/process-history'
import {
  pageFixture,
  processDetailFixture,
  renderApp,
  routeSessionFixture,
  TEST_ROUTE_SESSION_ID,
  TEST_SESSION_ID,
  TEST_TENANT_ID,
  threadSessionFixture,
  userAccessFixture,
} from '@/test'

import type { UserEvent } from '@testing-library/user-event'

export class ProcessSessionTestModel {
  private constructor(
    readonly user: UserEvent,
    readonly router: Awaited<ReturnType<typeof renderApp>>['router'],
  ) {}

  static async open(
    permissions: string[] = [
      Permission.PROCESS_HISTORY,
      Permission.PROCESS_HISTORY_DETAILS,
      Permission.PROCESS_HISTORY_ERROR_DETAILS,
    ],
  ) {
    const route = routeSessionFixture({
      statusCode: 'ERROR',
      statusName: 'Ошибка',
      errorDescription: 'Route execution failed',
    })
    const thread = threadSessionFixture({
      errorDescription: 'SQL statement timeout',
    })
    const app = await renderApp({
      route: `/history/${TEST_SESSION_ID}`,
      access: userAccessFixture(permissions),
      seed: (queryClient) => {
        queryClient.setQueryData(
          historyKeys.detail(TEST_TENANT_ID, TEST_SESSION_ID),
          processDetailFixture(),
        )
        queryClient.setQueryData(
          historyKeys.routes(TEST_TENANT_ID, TEST_SESSION_ID, {
            page: 0,
            size: 50,
            sort: 'startDateTime,asc',
          }),
          pageFixture([route]),
        )
        queryClient.setQueryData(
          historyKeys.threads(TEST_TENANT_ID, TEST_SESSION_ID, {
            page: 0,
            size: 1,
            sort: 'threadNumber,asc',
          }),
          pageFixture([thread], { totalElements: 1000, size: 1 }),
        )
        queryClient.setQueryData(
          historyKeys.routes(TEST_TENANT_ID, TEST_SESSION_ID, {
            page: 0,
            size: 1,
            sort: 'startDateTime,asc',
          }),
          pageFixture([route], { totalElements: 1000, size: 1 }),
        )
        queryClient.setQueryData(
          historyKeys.threads(TEST_TENANT_ID, TEST_SESSION_ID, {
            page: 0,
            size: 50,
            sort: 'threadNumber,asc',
            routeSessionId: TEST_ROUTE_SESSION_ID,
          }),
          pageFixture([thread]),
        )
      },
    })

    await screen.findByRole('heading', {
      name: 'Детали выполнения',
    })
    return new ProcessSessionTestModel(app.user, app.router)
  }

  routeTable() {
    return screen.getByRole('table', { name: /route/i })
  }

  threadTable() {
    return screen.getByRole('table', { name: /thread/i })
  }

  expectOnlyRouteTable() {
    expect(screen.getByRole('tab', { name: 'Route-сессии', selected: true })).toBeVisible()
    expect(screen.getAllByRole('table')).toHaveLength(1)
    expect(screen.getByText('db-main.users')).toBeVisible()
  }

  async showRoutes() {
    await this.user.click(screen.getByRole('tab', { name: 'Route-сессии' }))
  }

  async showThreadsFor(routeKey: string) {
    const row = screen.getByRole('row', { name: new RegExp(routeKey, 'i') })
    await this.user.click(within(row).getByRole('button', { name: /Потоки/i }))
  }
}
