import { Tab, Tabs } from '@v-uik/base'

import type { ProcessDetail } from '@/entities/process-history'

import { ProcessExecutionSummary } from '../ProcessExecutionSummary'
import { RouteSessionsPanel } from '../RouteSessionsPanel'
import { ThreadSessionsPanel } from '../ThreadSessionsPanel'

import styles from './ProcessSessionMonitoring.module.scss'

import type { ProcessSessionSearchState, SessionView } from '../../model'
import type { FC } from 'react'

interface ProcessSessionMonitoringProps {
  detail: ProcessDetail
  search: ProcessSessionSearchState
  onSearchChange: (patch: Partial<ProcessSessionSearchState>) => void
}

export const ProcessSessionMonitoring: FC<ProcessSessionMonitoringProps> = ({
  detail,
  search,
  onSearchChange,
}) => {
  const changeView = (value: string | number) => {
    if (value === 'summary' || value === 'routes' || value === 'threads') {
      onSearchChange({ view: value as SessionView })
    }
  }

  return (
    <div className={styles.layout}>
      <Tabs
        className={styles.tabs}
        classes={{ tabs: styles.tabList, content: styles.tabContent }}
        value={search.view}
        onChange={changeView}
      >
        <Tab value='summary' header='Сводка'>
          <div className={styles.summaryPanel}>
            <ProcessExecutionSummary detail={detail} />
          </div>
        </Tab>
        <Tab value='routes' header='Route-сессии'>
          <RouteSessionsPanel detail={detail} search={search} onSearchChange={onSearchChange} />
        </Tab>
        <Tab value='threads' header='Thread-сессии'>
          <ThreadSessionsPanel
            detail={detail}
            search={search}
            onSearchChange={onSearchChange}
          />
        </Tab>
      </Tabs>
    </div>
  )
}
