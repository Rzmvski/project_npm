import styles from './Metric.module.scss'

import type { FC } from 'react'

interface MetricProps {
  label: string
  value: number
  failed?: boolean
}

export const Metric: FC<MetricProps> = ({ label, value, failed }) => (
  <div className={styles.metric} data-failed={failed || undefined}>
    <span>{label}</span>
    <strong>{value.toLocaleString('ru-RU')}</strong>
  </div>
)
