import { Button } from '@v-uik/base'
import { FilterX } from 'lucide-react'
import { useEffect, useMemo, type FC } from 'react'
import { Controller, useForm } from 'react-hook-form'

import { splitFilterValues, type ThreadFiltersValues } from '../../model'
import { FilterSearchField } from '../FilterSearchField'
import { StatusFilter } from '../StatusFilter'

import styles from './ThreadSessionFilters.module.scss'

interface ThreadSessionFiltersProps {
  route?: string
  pod?: string
  status?: string
  onChange: (patch: {
    threadRouteKey?: string
    threadRouteSessionId?: string
    threadPod?: string
    threadStatus?: string
  }) => void
}

export const ThreadSessionFilters: FC<ThreadSessionFiltersProps> = ({
  route,
  pod,
  status,
  onChange,
}) => {
  const initialValues = useMemo<ThreadFiltersValues>(
    () => ({ route: route ?? '', pod: pod ?? '', statuses: splitFilterValues(status) }),
    [pod, route, status],
  )
  const { control, reset } = useForm<ThreadFiltersValues>({ defaultValues: initialValues })

  useEffect(() => reset(initialValues), [initialValues, reset])

  return (
    <form className={styles.form} aria-label='Фильтры thread-сессий'>
      <FilterSearchField
        name='route'
        label='Route'
        placeholder='Название route'
        control={control}
        onChange={(value) =>
          onChange({
            threadRouteKey: value.trim() || undefined,
            threadRouteSessionId: undefined,
          })
        }
      />
      <FilterSearchField
        name='pod'
        label='Pod'
        placeholder='Название pod'
        control={control}
        onChange={(value) => onChange({ threadPod: value.trim() || undefined })}
      />
      <Controller
        name='statuses'
        control={control}
        render={({ field }) => (
          <StatusFilter
            name={field.name}
            value={field.value}
            onBlur={field.onBlur}
            onChange={(values) => {
              field.onChange(values)
              onChange({ threadStatus: values.length ? values.join(',') : undefined })
            }}
          />
        )}
      />
      <Button
        type='button'
        kind='ghost'
        color='secondary'
        prefixIcon={<FilterX size={16} />}
        disabled={!route && !pod && !status}
        onClick={() => {
          reset({ route: '', pod: '', statuses: [] })
          onChange({
            threadRouteKey: undefined,
            threadRouteSessionId: undefined,
            threadPod: undefined,
            threadStatus: undefined,
          })
        }}
      >
        Сбросить
      </Button>
    </form>
  )
}
