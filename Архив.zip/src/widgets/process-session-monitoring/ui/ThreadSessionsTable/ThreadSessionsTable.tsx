import { Button, type ColumnProps, type RecordDataSource } from '@v-uik/base'
import { CircleAlert } from 'lucide-react'
import { useMemo, type FC } from 'react'

import { Ability, useCan } from '@/entities/access'
import { ProcessStatusBadge, type ThreadSessionMonitoring } from '@/entities/process-history'
import { formatDateTime, formatDuration, useTextDetailsModal } from '@/shared/lib'
import { DataTable } from '@/shared/ui'

import styles from './ThreadSessionsTable.module.scss'

type ThreadRow = RecordDataSource<ThreadSessionMonitoring>

const shortId = (value: string | null) => (value ? `${value.slice(0, 8)}…` : 'Без route')

interface ThreadSessionsTableProps {
  items: ThreadSessionMonitoring[]
}

export const ThreadSessionsTable: FC<ThreadSessionsTableProps> = ({ items }) => {
  const canViewErrorDetails = useCan(Ability.PROCESS_HISTORY_ERROR_DETAILS)
  const showTextDetails = useTextDetailsModal()
  const dataSource = useMemo<ThreadRow[]>(
    () => items.map((item) => ({ ...item, key: item.threadSessionId })),
    [items],
  )

  const columns = useMemo<ColumnProps<ThreadRow>[]>(
    () => [
      {
        key: 'threadNumber',
        dataIndex: 'threadNumber',
        title: 'Поток',
        width: 80,
        renderCellContent: ({ row }) => (
          <strong>
            {row.threadNumber}/{row.maxThreads}
          </strong>
        ),
      },
      {
        key: 'routeSessionId',
        dataIndex: 'routeSessionId',
        title: 'Route',
        width: 180,
        renderCellContent: ({ row }) => (
          <span className={styles.route} title={row.routeKey ?? undefined}>
            {row.routeKey ?? shortId(row.routeSessionId)}
          </span>
        ),
      },
      {
        key: 'podName',
        dataIndex: 'podName',
        title: 'Pod',
        width: 160,
        renderCellContent: ({ row }) => (
          <code className={styles.pod}>{row.podName ?? '—'}</code>
        ),
      },
      {
        key: 'statusCode',
        dataIndex: 'statusCode',
        title: 'Статус',
        width: 170,
        renderCellContent: ({ row }) => (
          <div className={styles.status}>
            <ProcessStatusBadge code={row.statusCode} name={row.statusName} />
            {canViewErrorDetails && row.errorDescription ? (
              <Button
                type='button'
                kind='ghost'
                color='error'
                size='sm'
                prefixIcon={<CircleAlert size={16} />}
                aria-label={`Показать ошибку потока ${row.threadNumber}`}
                title='Показать ошибку'
                onClick={() =>
                  showTextDetails({
                    title: `Ошибка потока ${row.threadNumber}`,
                    subtitle: row.podName ?? row.threadSessionId,
                    text: row.errorDescription!,
                  })
                }
              />
            ) : null}
          </div>
        ),
      },
      {
        key: 'startDateTime',
        dataIndex: 'startDateTime',
        title: 'Начало',
        width: 155,
        renderCellContent: ({ row }) => formatDateTime(row.startDateTime),
      },
      {
        key: 'duration',
        title: 'Длительность',
        width: 100,
        renderCellContent: ({ row }) => formatDuration(row.startDateTime, row.endDateTime),
      },
      {
        key: 'successfulRecords',
        dataIndex: 'successfulRecords',
        title: 'Успешно',
        width: 90,
        renderCellContent: ({ row }) => row.successfulRecords.toLocaleString('ru-RU'),
      },
      {
        key: 'failedRecords',
        dataIndex: 'failedRecords',
        title: 'Ошибки',
        width: 80,
        renderCellContent: ({ row }) => (
          <span className={row.failedRecords > 0 ? styles.failed : undefined}>
            {row.failedRecords.toLocaleString('ru-RU')}
          </span>
        ),
      },
    ],
    [canViewErrorDetails, showTextDetails],
  )

  return (
    <DataTable
      fillAvailableHeight
      comfortable
      dataSource={dataSource}
      columns={columns}
      rowKey='threadSessionId'
      aria-label='Thread-сессии'
    />
  )
}
