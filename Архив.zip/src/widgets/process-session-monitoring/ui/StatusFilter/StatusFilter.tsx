import { ComboBox } from '@v-uik/base'

import { findComboBoxOptions, getComboBoxValues, type ComboBoxOption } from '@/shared/lib'

import { sessionStatusOptions } from '../../model'

import type { FC } from 'react'

interface StatusFilterProps {
  name: string
  value: string[]
  onBlur: () => void
  onChange: (values: string[]) => void
}

export const StatusFilter: FC<StatusFilterProps> = ({ name, value, onBlur, onChange }) => (
  <ComboBox<ComboBoxOption>
    multiple
    canClear
    openOnFocus
    disableCloseOnSelect
    limitTags={1}
    label='Статус'
    placeholder='Все статусы'
    options={sessionStatusOptions}
    value={findComboBoxOptions(value, sessionStatusOptions)}
    inputProps={{ name }}
    controlInnerProps={{ onBlur }}
    onChange={(_value, _event, fullValue) => onChange(getComboBoxValues(fullValue))}
  />
)
