import { Controller, type Control } from 'react-hook-form'

import { SearchInput } from '@/shared/ui'

import styles from './FilterSearchField.module.scss'

import type { ThreadFiltersValues } from '../../model'
import type { FC } from 'react'

interface FilterSearchFieldProps {
  name: 'route' | 'pod'
  label: string
  placeholder: string
  control: Control<ThreadFiltersValues>
  onChange: (value: string) => void
}

export const FilterSearchField: FC<FilterSearchFieldProps> = ({
  name,
  label,
  placeholder,
  control,
  onChange,
}) => (
  <div className={styles.field}>
    <Controller
      name={name}
      control={control}
      render={({ field }) => (
        <SearchInput
          label={label}
          value={field.value}
          placeholder={placeholder}
          debounceMs={250}
          onChange={(value) => {
            field.onChange(value)
            onChange(value)
          }}
        />
      )}
    />
  </div>
)
