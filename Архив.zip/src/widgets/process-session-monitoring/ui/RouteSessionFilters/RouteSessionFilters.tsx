import { Button } from '@v-uik/base'
import { FilterX } from 'lucide-react'
import { useEffect, useMemo, type FC } from 'react'
import { Controller, useForm } from 'react-hook-form'

import { SearchInput } from '@/shared/ui'

import { splitFilterValues, type RouteFiltersValues } from '../../model'
import { StatusFilter } from '../StatusFilter'

import styles from './RouteSessionFilters.module.scss'

interface RouteSessionFiltersProps {
  query?: string
  status?: string
  onChange: (patch: { routeQuery?: string; routeStatus?: string }) => void
}

export const RouteSessionFilters: FC<RouteSessionFiltersProps> = ({
  query,
  status,
  onChange,
}) => {
  const initialValues = useMemo<RouteFiltersValues>(
    () => ({ query: query ?? '', statuses: splitFilterValues(status) }),
    [query, status],
  )
  const { control, reset } = useForm<RouteFiltersValues>({ defaultValues: initialValues })

  useEffect(() => reset(initialValues), [initialValues, reset])

  return (
    <form className={styles.form} aria-label='Фильтры route-сессий'>
      <div className={styles.search}>
        <Controller
          name='query'
          control={control}
          render={({ field }) => (
            <SearchInput
              label='Route'
              value={field.value}
              placeholder='Название route'
              debounceMs={250}
              onChange={(value) => {
                field.onChange(value)
                onChange({ routeQuery: value.trim() || undefined })
              }}
            />
          )}
        />
      </div>
      <Controller
        name='statuses'
        control={control}
        render={({ field }) => (
          <StatusFilter
            name={field.name}
            value={field.value}
            onBlur={field.onBlur}
            onChange={(values) => {
              field.onChange(values)
              onChange({ routeStatus: values.length ? values.join(',') : undefined })
            }}
          />
        )}
      />
      <Button
        type='button'
        kind='ghost'
        color='secondary'
        prefixIcon={<FilterX size={16} />}
        disabled={!query && !status}
        onClick={() => {
          reset({ query: '', statuses: [] })
          onChange({ routeQuery: undefined, routeStatus: undefined })
        }}
      >
        Сбросить
      </Button>
    </form>
  )
}
