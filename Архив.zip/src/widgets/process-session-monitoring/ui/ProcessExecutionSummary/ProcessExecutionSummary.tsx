import { Tag } from '@v-uik/base'
import { CalendarCheck2, CalendarClock, Clock3, Fingerprint, ListTree } from 'lucide-react'

import { ProcessCategoryTag } from '@/entities/process'
import { ProcessStatusBadge, type ProcessDetail } from '@/entities/process-history'
import { formatDateTime, formatDuration } from '@/shared/lib'

import { Metric } from '../Metric'

import styles from './ProcessExecutionSummary.module.scss'

import type { FC } from 'react'

const formatParamValue = (value: unknown) => {
  if (typeof value === 'string') return value
  if (value === null) return 'null'
  if (typeof value === 'object') return JSON.stringify(value)
  return String(value)
}

const parseAdditionalParams = (value: string) => {
  try {
    const parsed: unknown = JSON.parse(value)
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      return Object.entries(parsed).map(([key, paramValue]) => ({
        key,
        value: formatParamValue(paramValue),
      }))
    }
  } catch {
    // Строковые параметры отображаются как единое значение.
  }

  return [{ key: 'Значение', value }]
}

interface ProcessExecutionSummaryProps {
  detail: ProcessDetail
}

export const ProcessExecutionSummary: FC<ProcessExecutionSummaryProps> = ({ detail }) => {
  const session = detail.processSession
  const params = session.additionalParams ? parseAdditionalParams(session.additionalParams) : []

  return (
    <div className={styles.layout}>
      <div className={styles.topGrid}>
        <section className={styles.card}>
          <div className={styles.cardHeader}>
            <div>
              <h2>Основная информация</h2>
              <p>Параметры и состояние текущего выполнения.</p>
            </div>
            <ProcessStatusBadge code={session.statusCode} name={session.statusName} />
          </div>

          <dl className={styles.details}>
            <div>
              <dt>
                <ListTree size={16} /> Процесс
              </dt>
              <dd>{detail.processName}</dd>
            </div>
            <div>
              <dt>
                <Fingerprint size={16} /> P-сессия
              </dt>
              <dd>
                <code>{session.processSessionId}</code>
              </dd>
            </div>
            <div>
              <dt>
                <CalendarClock size={16} /> Начало
              </dt>
              <dd>{formatDateTime(session.startDateTime)}</dd>
            </div>
            <div>
              <dt>
                <CalendarCheck2 size={16} /> Окончание
              </dt>
              <dd>
                {session.endDateTime ? formatDateTime(session.endDateTime) : 'Ещё выполняется'}
              </dd>
            </div>
            <div>
              <dt>
                <Clock3 size={16} /> Длительность
              </dt>
              <dd>{formatDuration(session.startDateTime, session.endDateTime)}</dd>
            </div>
          </dl>

          <div className={styles.tags}>
            <Tag kind='lite'>{detail.processType}</Tag>
            {detail.label ? <ProcessCategoryTag category={detail.label} /> : null}
          </div>
          <p className={styles.description}>{detail.description || 'Описание не указано'}</p>
        </section>

        <section className={styles.card}>
          <div className={styles.cardHeader}>
            <div>
              <h2>Результаты обработки</h2>
              <p>Количество записей в текущем выполнении.</p>
            </div>
          </div>
          <div className={styles.metrics}>
            <Metric label='К обработке' value={session.recordsToProcess} />
            <Metric label='Обработано' value={session.totalRecords} />
            <Metric label='Успешно' value={session.successfulRecords} />
            <Metric label='Ошибки' value={session.failedRecords} failed />
          </div>
        </section>
      </div>

      {params.length ? (
        <section className={styles.card}>
          <div className={styles.paramsHeader}>
            <header>
              <h2>Параметры запуска</h2>
              <p>Значения, переданные процессу при старте.</p>
            </header>
            <span className={styles.counter}>{params.length}</span>
          </div>
          <dl className={styles.params}>
            {params.map((param) => (
              <div key={param.key}>
                <dt>{param.key}</dt>
                <dd title={param.value}>{param.value}</dd>
              </div>
            ))}
          </dl>
        </section>
      ) : null}
    </div>
  )
}
