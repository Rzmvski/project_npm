import { keepPreviousData, useQuery } from '@tanstack/react-query'

import { threadSessionsQueryOptions, type ProcessDetail } from '@/entities/process-history'
import { useRequiredTenantId } from '@/entities/tenant'
import { MONITORING_PAGE_SIZES } from '@/shared/lib'
import { EmptyState, ErrorState, LoadingState, Pagination } from '@/shared/ui'

import { ThreadSessionFilters } from '../ThreadSessionFilters'
import { ThreadSessionsTable } from '../ThreadSessionsTable'

import styles from './ThreadSessionsPanel.module.scss'

import type { ProcessSessionSearchState } from '../../model'
import type { FC } from 'react'

interface ThreadSessionsPanelProps {
  detail: ProcessDetail
  search: ProcessSessionSearchState
  onSearchChange: (patch: Partial<ProcessSessionSearchState>) => void
}

export const ThreadSessionsPanel: FC<ThreadSessionsPanelProps> = ({
  detail,
  search,
  onSearchChange,
}) => {
  const tenantId = useRequiredTenantId()
  // routeKey/pod/status are local filter state only — GET .../thread-sessions only documents
  // routeSessionId/page/size/sort, so they aren't forwarded to the backend.
  const query = useQuery({
    ...threadSessionsQueryOptions(tenantId, detail.processSession.processSessionId, {
      page: search.threadPage,
      size: search.threadSize,
      sort: search.threadSort,
      routeSessionId: search.threadRouteSessionId,
    }),
    placeholderData: keepPreviousData,
    refetchInterval: detail.processSession.statusCode === 'WORKS' ? 5_000 : false,
  })

  const hasFilters = Boolean(search.threadRouteKey || search.threadPod || search.threadStatus)

  return (
    <section className={styles.panel} aria-label='Thread-сессии'>
      <ThreadSessionFilters
        route={search.threadRouteKey}
        pod={search.threadPod}
        status={search.threadStatus}
        onChange={(patch) => onSearchChange({ ...patch, threadPage: 0 })}
      />

      {query.isPending ? (
        <LoadingState label='Загружаем thread-сессии…' />
      ) : query.isError ? (
        <ErrorState title='Не удалось загрузить thread-сессии' />
      ) : query.data.content.length === 0 ? (
        <EmptyState
          title='Thread-сессии не найдены'
          description={
            hasFilters
              ? 'Измените параметры фильтрации.'
              : 'Для этого запуска thread-сессии отсутствуют.'
          }
        />
      ) : (
        <>
          <ThreadSessionsTable items={query.data.content} />
          <Pagination
            compact
            page={query.data.number}
            totalPages={query.data.totalPages}
            size={query.data.size}
            totalElements={query.data.totalElements}
            sizeOptions={MONITORING_PAGE_SIZES}
            onPageChange={(threadPage) => onSearchChange({ threadPage })}
            onSizeChange={(threadSize) => onSearchChange({ threadSize, threadPage: 0 })}
          />
        </>
      )}
    </section>
  )
}
