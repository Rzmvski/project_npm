import { keepPreviousData, useQuery } from '@tanstack/react-query'

import { routeSessionsQueryOptions, type ProcessDetail } from '@/entities/process-history'
import { useRequiredTenantId } from '@/entities/tenant'
import { EmptyState, ErrorState, LoadingState, Pagination } from '@/shared/ui'

import { RouteSessionFilters } from '../RouteSessionFilters'
import { RouteSessionsTable } from '../RouteSessionsTable'

import styles from './RouteSessionsPanel.module.scss'

import type { ProcessSessionSearchState } from '../../model'
import type { FC } from 'react'

interface RouteSessionsPanelProps {
  detail: ProcessDetail
  search: ProcessSessionSearchState
  onSearchChange: (patch: Partial<ProcessSessionSearchState>) => void
}

export const RouteSessionsPanel: FC<RouteSessionsPanelProps> = ({
  detail,
  search,
  onSearchChange,
}) => {
  const tenantId = useRequiredTenantId()
  // routeQuery/routeStatus are local filter state only — GET .../route-sessions documents
  // just page/size/sort, so they aren't forwarded to the backend.
  const query = useQuery({
    ...routeSessionsQueryOptions(tenantId, detail.processSession.processSessionId, {
      page: search.routePage,
      size: search.routeSize,
      sort: search.routeSort,
    }),
    placeholderData: keepPreviousData,
    refetchInterval: detail.processSession.statusCode === 'WORKS' ? 5_000 : false,
  })

  return (
    <section className={styles.panel} aria-label='Route-сессии'>
      <RouteSessionFilters
        query={search.routeQuery}
        status={search.routeStatus}
        onChange={(patch) => onSearchChange({ ...patch, routePage: 0 })}
      />

      {query.isPending ? (
        <LoadingState label='Загружаем route-сессии…' />
      ) : query.isError ? (
        <ErrorState title='Не удалось загрузить route-сессии' />
      ) : query.data.content.length === 0 ? (
        <EmptyState
          title='Route-сессии не найдены'
          description={
            search.routeQuery || search.routeStatus
              ? 'Измените параметры фильтрации.'
              : 'Для этого запуска route-сессии отсутствуют.'
          }
        />
      ) : (
        <>
          <RouteSessionsTable
            items={query.data.content}
            onShowThreads={(route) =>
              onSearchChange({
                view: 'threads',
                threadRouteSessionId: route.routeSessionId,
                threadRouteKey: route.routeKey,
                threadPage: 0,
              })
            }
          />
          <Pagination
            compact
            page={query.data.number}
            totalPages={query.data.totalPages}
            size={query.data.size}
            totalElements={query.data.totalElements}
            sizeOptions={[25, 50, 100]}
            onPageChange={(routePage) => onSearchChange({ routePage })}
            onSizeChange={(routeSize) => onSearchChange({ routeSize, routePage: 0 })}
          />
        </>
      )}
    </section>
  )
}
