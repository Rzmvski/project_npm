import { ProcessTargetBadge, type ProcessSummary } from '@/entities/process'

import styles from './TargetSummary.module.scss'

import type { FC } from 'react'

interface TargetSummaryProps {
  process: ProcessSummary
}

export const TargetSummary: FC<TargetSummaryProps> = ({ process }) => {
  const { routes: targets } = process

  if (!targets.length) return <span className={styles.muted}>Не настроено</span>

  const visibleTargets = targets.slice(0, 2)
  const hiddenTargets = targets.slice(2)

  return (
    <div className={styles.targets}>
      {visibleTargets.map((target) => {
        const { isLabel, routeKey } = target

        return <ProcessTargetBadge key={`${isLabel}-${routeKey}`} target={target} />
      })}
      {hiddenTargets.length ? (
        <span
          className={styles.more}
          title={hiddenTargets
            .map(
              ({ isLabel, routeKey }) => `${isLabel ? 'DB set' : 'База данных'}: ${routeKey}`,
            )
            .join(', ')}
        >
          +{hiddenTargets.length}
        </span>
      ) : null}
    </div>
  )
}
