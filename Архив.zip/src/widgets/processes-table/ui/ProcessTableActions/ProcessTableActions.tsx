import { useNavigate } from '@tanstack/react-router'
import { Button, DropdownMenu, DropdownMenuItem } from '@v-uik/base'
import { CalendarClock, Eye, MoreHorizontal, Pencil, Trash2 } from 'lucide-react'

import { Ability, useAccess } from '@/entities/access'
import { getTargetNames, type ProcessSummary } from '@/entities/process'
import { useDeleteProcess } from '@/features/delete-process'
import { StartProcessButton } from '@/features/start-process'

import styles from './ProcessTableActions.module.scss'

import type { FC } from 'react'

interface ProcessTableActionsProps {
  process: ProcessSummary
}

export const ProcessTableActions: FC<ProcessTableActionsProps> = ({ process }) => {
  const { id, processName, routes } = process
  const navigate = useNavigate()
  const { can } = useAccess()
  const { requestDelete } = useDeleteProcess({
    processId: id,
    processName,
  })
  const showMenu =
    can(Ability.PROCESS_UPDATE) || can(Ability.SCHEDULE_EDIT) || can(Ability.PROCESS_DELETE)

  return (
    <div className={styles.actions}>
      <Button
        type='button'
        kind='ghost'
        color='secondary'
        size='sm'
        prefixIcon={<Eye size={17} />}
        aria-label={`Открыть карточку процесса ${processName}`}
        title='Открыть карточку'
        onClick={() =>
          void navigate({
            to: '/processes/$processId',
            params: { processId: id },
          })
        }
      />

      <StartProcessButton
        compact
        processId={id}
        processName={processName}
        routes={getTargetNames(routes)}
      />

      {showMenu ? (
        <DropdownMenu
          action='click'
          placement='bottom-end'
          content={
            <>
              {can(Ability.PROCESS_UPDATE) ? (
                <DropdownMenuItem
                  closeMenuOnClick
                  prefix={<Pencil size={16} />}
                  aria-label={`Редактировать процесс ${processName}`}
                  onClick={() =>
                    void navigate({
                      to: '/processes/$processId/edit',
                      params: { processId: id },
                    })
                  }
                >
                  Редактировать
                </DropdownMenuItem>
              ) : null}

              {can(Ability.SCHEDULE_EDIT) ? (
                <DropdownMenuItem
                  closeMenuOnClick
                  prefix={<CalendarClock size={16} />}
                  aria-label={`Управлять расписанием процесса ${processName}`}
                  onClick={() =>
                    void navigate({
                      to: '/schedules/$processId/edit',
                      params: { processId: id },
                    })
                  }
                >
                  Расписание
                </DropdownMenuItem>
              ) : null}

              {can(Ability.PROCESS_DELETE) ? (
                <DropdownMenuItem
                  critical
                  closeMenuOnClick
                  prefix={<Trash2 size={16} />}
                  aria-label={`Удалить процесс ${processName}`}
                  onClick={() => void requestDelete()}
                >
                  Удалить
                </DropdownMenuItem>
              ) : null}
            </>
          }
        >
          <Button
            type='button'
            kind='ghost'
            color='secondary'
            size='sm'
            prefixIcon={<MoreHorizontal size={18} />}
            aria-label={`Другие действия с процессом ${processName}`}
            title='Другие действия'
          />
        </DropdownMenu>
      ) : null}
    </div>
  )
}
