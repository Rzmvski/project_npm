import { Tag, type ColumnProps, type RecordDataSource } from '@v-uik/base'
import { useMemo, type FC } from 'react'

import { Ability, useAccess } from '@/entities/access'
import { ProcessCategoryTag, type ProcessSummary } from '@/entities/process'
import { DataTable, EmptyState } from '@/shared/ui'

import { ProcessTableActions } from '../ProcessTableActions'
import { TargetSummary } from '../TargetSummary'

import styles from './ProcessesTable.module.scss'

type ProcessRow = RecordDataSource<ProcessSummary>

interface ProcessesTableProps {
  processes: ProcessSummary[]
}

export const ProcessesTable: FC<ProcessesTableProps> = ({ processes }) => {
  const { canAny } = useAccess()
  const showActions = canAny([
    Ability.PROCESS_DETAILS,
    Ability.PROCESS_START,
    Ability.PROCESS_UPDATE,
    Ability.PROCESS_DELETE,
    Ability.SCHEDULE_EDIT,
  ])

  const dataSource = useMemo<ProcessRow[]>(
    () => processes.map((process) => ({ ...process, key: process.id })),
    [processes],
  )

  const columns = useMemo<ColumnProps<ProcessRow>[]>(
    () => [
      {
        key: 'processName',
        dataIndex: 'processName',
        title: 'Процесс',
        width: 310,
        fixed: 'start',
        renderCellContent: ({ row }) => (
          <div className={styles.name}>
            <strong>{row.processName}</strong>
            <span>{row.description || 'Без описания'}</span>
          </div>
        ),
      },
      {
        key: 'processType',
        dataIndex: 'processType',
        title: 'Тип',
        width: 150,
        renderCellContent: ({ row }) => <Tag kind='lite'>{row.processType}</Tag>,
      },
      {
        key: 'label',
        dataIndex: 'label',
        title: 'Категория',
        width: 170,
        renderCellContent: ({ row }) =>
          row.label ? (
            <ProcessCategoryTag category={row.label} />
          ) : (
            <span className={styles.muted}>Не указана</span>
          ),
      },
      {
        key: 'targets',
        title: 'Область выполнения',
        width: 280,
        renderCellContent: ({ row }) => <TargetSummary process={row} />,
      },
      ...(showActions
        ? [
            {
              key: 'actions',
              title: 'Действия',
              width: 136,
              fixed: 'end',
              align: 'center',
              renderCellContent: ({ row }: { row: ProcessRow }) => (
                <ProcessTableActions process={row} />
              ),
            } satisfies ColumnProps<ProcessRow>,
          ]
        : []),
    ],
    [showActions],
  )

  if (!processes.length) {
    return (
      <EmptyState
        title='Процессы не найдены'
        description='Измените фильтры или создайте первый процесс.'
      />
    )
  }

  return <DataTable fillAvailableHeight dataSource={dataSource} columns={columns} rowKey='id' />
}
