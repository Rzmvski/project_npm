export const loadProcessFormPage = () => import('./ui')
