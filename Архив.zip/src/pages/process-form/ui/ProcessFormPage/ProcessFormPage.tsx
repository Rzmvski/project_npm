import { SaveProcessForm } from '@/features/save-process'

import type { FC } from 'react'

interface ProcessFormPageProps {
  mode: 'create' | 'edit'
  processId?: string
}

export const ProcessFormPage: FC<ProcessFormPageProps> = ({ mode, processId }) => (
  <SaveProcessForm mode={mode} processId={processId} />
)
