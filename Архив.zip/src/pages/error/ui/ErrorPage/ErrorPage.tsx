import { useNavigate } from '@tanstack/react-router'
import { Button } from '@v-uik/base'
import { House, RefreshCcw, TriangleAlert } from 'lucide-react'

import styles from './ErrorPage.module.scss'

import type { FC } from 'react'

interface ErrorPageProps {
  error?: unknown
  onRetry?: () => void
  embedded?: boolean
  status?: '404' | '500'
  eyebrow?: string
  title?: string
  description?: string
}

const getErrorMessage = (error: unknown) => {
  if (error instanceof Error) return error.message
  if (typeof error === 'string') return error
  return null
}

export const ErrorPage: FC<ErrorPageProps> = ({
  error,
  onRetry,
  embedded = false,
  status = '500',
  eyebrow = 'Непредвиденная ошибка',
  title = 'Не удалось открыть страницу',
  description = 'Попробуйте повторить запрос. Если ошибка сохранится, передайте время возникновения проблемы команде поддержки.',
}) => {
  const navigate = useNavigate()
  const errorMessage = getErrorMessage(error)

  return (
    <div className={embedded ? styles.embedded : styles.page}>
      <section className={styles.card}>
        <div className={styles.status}>{status}</div>
        <div className={styles.icon}>
          <TriangleAlert size={32} />
        </div>
        <p className={styles.eyebrow}>{eyebrow}</p>
        <h1>{title}</h1>
        <p className={styles.description}>{description}</p>

        {import.meta.env.DEV && errorMessage ? (
          <code className={styles.details}>{errorMessage}</code>
        ) : null}

        <div className={styles.actions}>
          {onRetry ? (
            <Button type='button' onClick={onRetry} prefixIcon={<RefreshCcw size={17} />}>
              Повторить
            </Button>
          ) : null}
          <Button
            type='button'
            kind='outlined'
            color='secondary'
            onClick={() => void navigate({ to: '/' })}
            prefixIcon={<House size={17} />}
          >
            На главную
          </Button>
        </div>
      </section>
    </div>
  )
}
