export { validateProcessesSearch, type ProcessesSearch } from './model'
export const loadProcessesPage = () => import('./ui')
