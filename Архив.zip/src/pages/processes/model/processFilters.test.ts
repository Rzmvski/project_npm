import { describe, expect, it } from 'vitest'

import type { ProcessSummary } from '@/entities/process'

import {
  createProcessFiltersValues,
  filterProcesses,
  toProcessesSearch,
} from './processFilters'

const createProcess = (id: string, isLabel: boolean): ProcessSummary => ({
  id,
  processName: id,
  processType: 'DB_PROCESS',
  description: null,
  label: null,
  routes: [{ routeKey: 'COMMON', isLabel }],
  cmd: 'run',
})

describe('process target filters', () => {
  it('distinguishes a database from a DB set with the same name', () => {
    const processes = [
      createProcess('database-process', false),
      createProcess('db-set-process', true),
    ]

    expect(
      filterProcesses(processes, createProcessFiltersValues({ target: 'db:COMMON' })).map(
        ({ id }) => id,
      ),
    ).toEqual(['database-process'])
  })

  it('serializes all selected targets into one URL parameter', () => {
    const search = toProcessesSearch({
      query: '',
      processType: '',
      category: '',
      targets: ['dbSet:GAMMA', 'db:ALPHA'],
    })

    expect(search).toMatchObject({ target: 'db:ALPHA,dbSet:GAMMA' })
    expect(search).not.toHaveProperty('db')
    expect(search).not.toHaveProperty('dbSet')
  })
})
