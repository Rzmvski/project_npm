import { describe, expect, it } from 'vitest'

import { validateProcessesSearch } from './processSearch'

describe('process search', () => {
  it('provides pagination and direction-first camelCase sort defaults', () => {
    expect(validateProcessesSearch({})).toMatchObject({
      page: 0,
      size: 20,
      sort: 'asc:processName',
    })
  })

  it('rejects legacy and non-camelCase sort formats', () => {
    expect(validateProcessesSearch({ sort: 'processName,asc' }).sort).toBe('asc:processName')
    expect(validateProcessesSearch({ sort: 'desc:process_name' }).sort).toBe('asc:processName')
    expect(validateProcessesSearch({ sort: 'desc:createdAt' }).sort).toBe('desc:createdAt')
  })
})
