import type { SearchSchemaInput } from '@tanstack/react-router'

interface ProcessesSearchInput extends SearchSchemaInput {
  query?: unknown
  type?: unknown
  category?: unknown
  target?: unknown
}

export interface ProcessesSearch {
  query?: string
  type?: string
  category?: string
  target?: string
}

const parseOptionalString = (value: unknown) => {
  if (typeof value !== 'string') return undefined
  return value.trim() || undefined
}

export const validateProcessesSearch = (search: ProcessesSearchInput): ProcessesSearch => ({
  query: parseOptionalString(search.query),
  type: parseOptionalString(search.type),
  category: parseOptionalString(search.category),
  target: parseOptionalString(search.target),
})
