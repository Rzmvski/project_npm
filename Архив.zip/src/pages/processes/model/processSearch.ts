import {
  CATALOG_PAGE_SIZES,
  parseOptionalSearchString,
  parsePaginationSearch,
  type PaginationSearch,
  type PaginationSearchInput,
} from '@/shared/lib'

import type { SearchSchemaInput } from '@tanstack/react-router'

interface ProcessesSearchInput extends SearchSchemaInput, PaginationSearchInput {
  query?: unknown
  type?: unknown
  category?: unknown
  target?: unknown
}

export interface ProcessesSearch extends PaginationSearch {
  query?: string
  type?: string
  category?: string
  target?: string
}

export type ProcessFiltersSearch = Pick<
  ProcessesSearch,
  'query' | 'type' | 'category' | 'target'
>

export function validateProcessesSearch(search: Record<string, unknown>): ProcessesSearch
export function validateProcessesSearch(search: ProcessesSearchInput): ProcessesSearch
export function validateProcessesSearch(
  search: ProcessesSearchInput | Record<string, unknown>,
): ProcessesSearch {
  return {
    ...parsePaginationSearch(search, {
      defaultSize: 20,
      defaultSort: 'asc:processName',
      sizeOptions: CATALOG_PAGE_SIZES,
    }),
    query: parseOptionalSearchString(search.query),
    type: parseOptionalSearchString(search.type),
    category: parseOptionalSearchString(search.category),
    target: parseOptionalSearchString(search.target),
  }
}
