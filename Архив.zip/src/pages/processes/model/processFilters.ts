import type { ProcessSummary, RouteTarget } from '@/entities/process'

import type { ProcessesSearch } from './processSearch'

export interface ProcessFilterOption {
  value: string
  label: string
  targetKind?: 'database' | 'dbSet'
}

export interface ProcessFiltersFormValues {
  query: string
  processType: string
  category: string
  targets: string[]
}

export interface ProcessFilterOptions {
  processTypes: ProcessFilterOption[]
  categories: ProcessFilterOption[]
  targets: ProcessFilterOption[]
}

const parseSearchList = (value?: string) =>
  value
    ? [
        ...new Set(
          value
            .split(',')
            .map((item) => item.trim())
            .filter(Boolean),
        ),
      ]
    : []

const serializeSearchList = (values: string[]) =>
  values.length ? [...new Set(values)].sort().join(',') : undefined

const toOptions = (values: string[]): ProcessFilterOption[] =>
  [...new Set(values)]
    .sort((left, right) => left.localeCompare(right, 'ru-RU'))
    .map((value) => ({ value, label: value }))

const getTargetFilterValue = (target: RouteTarget) =>
  `${target.isLabel ? 'dbSet' : 'db'}:${target.routeKey}`

const toTargetOptions = (processes: ProcessSummary[]) => {
  const targets = new Map<string, ProcessFilterOption>()

  processes
    .flatMap(({ routes }) => routes)
    .forEach((target) => {
      const value = getTargetFilterValue(target)
      targets.set(value, {
        value,
        label: target.routeKey,
        targetKind: target.isLabel ? 'dbSet' : 'database',
      })
    })

  return [...targets.values()].sort((left, right) =>
    left.label.localeCompare(right.label, 'ru-RU'),
  )
}

export const createProcessFiltersValues = (
  search: ProcessesSearch,
): ProcessFiltersFormValues => ({
  query: search.query ?? '',
  processType: search.type ?? '',
  category: search.category ?? '',
  targets: parseSearchList(search.target),
})

export const toProcessesSearch = (values: ProcessFiltersFormValues): ProcessesSearch => ({
  query: values.query.trim() || undefined,
  type: values.processType || undefined,
  category: values.category || undefined,
  target: serializeSearchList(values.targets),
})

export const getProcessFilterOptions = (processes: ProcessSummary[]): ProcessFilterOptions => ({
  processTypes: toOptions(processes.map((process) => process.processType)),
  categories: toOptions(
    processes
      .map((process) => process.label)
      .filter((value): value is string => Boolean(value)),
  ),
  targets: toTargetOptions(processes),
})

export const filterProcesses = (
  processes: ProcessSummary[],
  filters: ProcessFiltersFormValues,
) => {
  const query = filters.query.toLocaleLowerCase('ru-RU').trim()

  return processes.filter((process) => {
    const targets = process.routes.map(getTargetFilterValue)

    if (filters.processType && process.processType !== filters.processType) {
      return false
    }
    if (filters.category && process.label !== filters.category) return false
    if (filters.targets.length && !filters.targets.some((target) => targets.includes(target))) {
      return false
    }
    if (!query) return true

    return `${process.processName} ${process.description ?? ''} ${process.label ?? ''}`
      .toLocaleLowerCase('ru-RU')
      .includes(query)
  })
}
