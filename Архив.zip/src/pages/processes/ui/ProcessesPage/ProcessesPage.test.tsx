import { screen } from '@testing-library/react'
import { describe, expect, it } from 'vitest'

import { Permission } from '@/entities/access'
import { UI_VERSION } from '@/shared/config'

import { ProcessesPageTestModel, processListPermission } from './ProcessesPage.test-model'

describe('process list', () => {
  it('shows the process card link and all actions allowed by the role', async () => {
    const page = await ProcessesPageTestModel.open([
      processListPermission,
      Permission.PROCESS_CREATE,
      Permission.PROCESS_UPDATE,
      Permission.PROCESS_DELETE,
      Permission.PROCESS_START,
      Permission.SCHEDULE_CREATE,
    ])

    expect(screen.getByLabelText(`Версия UI ${UI_VERSION}`)).toBeVisible()
    page.expectProcessVisible('Дневная загрузка данных')
    expect(page.action(/Создать процесс/i)).toBeVisible()
    expect(
      page.rowAction('Дневная загрузка данных', /Открыть карточку процесса/i),
    ).toBeVisible()
    expect(page.rowAction('Дневная загрузка данных', /Запустить процесс/i)).toBeVisible()
    expect(page.rowAction('Дневная загрузка данных', /Редактировать процесс/i)).toBeVisible()
    expect(page.rowAction('Дневная загрузка данных', /Управлять расписанием/i)).toBeVisible()
    expect(page.rowAction('Дневная загрузка данных', /Удалить процесс/i)).toBeVisible()
  })

  it('opens the process card for a read-only user without exposing edit actions', async () => {
    const page = await ProcessesPageTestModel.open([processListPermission])

    expect(
      page.rowAction('Дневная загрузка данных', /Открыть карточку процесса/i),
    ).toBeVisible()
    expect(
      page.rowAction('Дневная загрузка данных', /Запустить процесс/i),
    ).not.toBeInTheDocument()
    expect(
      page.rowAction('Дневная загрузка данных', /Управлять расписанием/i),
    ).not.toBeInTheDocument()
    expect(
      page.rowAction('Дневная загрузка данных', /Редактировать процесс/i),
    ).not.toBeInTheDocument()
    expect(
      page.rowAction('Дневная загрузка данных', /Удалить процесс/i),
    ).not.toBeInTheDocument()
    expect(page.action(/Создать процесс/i)).not.toBeInTheDocument()
    expect(page.action(/^История$/i)).not.toBeInTheDocument()
    expect(page.action(/^Расписания$/i)).not.toBeInTheDocument()

    await page.openProcessCard('Дневная загрузка данных')
  })

  it('filters processes by user-entered text', async () => {
    const page = await ProcessesPageTestModel.open([processListPermission])

    await page.search('Очистка архивов')

    page.expectProcessVisible('Очистка архивов')
    page.expectProcessHidden('Дневная загрузка данных')
    expect(page.searchParams()).toMatchObject({ query: 'Очистка архивов' })
  })

  it('filters by target and stores the filter in the URL search', async () => {
    const page = await ProcessesPageTestModel.open([processListPermission])

    await page.filterByTarget('db:db-archive')

    page.expectProcessVisible('Очистка архивов')
    page.expectProcessHidden('Дневная загрузка данных')
    expect(page.searchParams()).toMatchObject({ target: 'db:db-archive' })
  })
})
