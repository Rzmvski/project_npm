import { useQuery } from '@tanstack/react-query'
import { useNavigate, useSearch } from '@tanstack/react-router'
import { Button } from '@v-uik/base'
import { Plus, RefreshCw } from 'lucide-react'
import { useCallback, useMemo, type FC } from 'react'

import { Ability, useCan } from '@/entities/access'
import { processListQueryOptions } from '@/entities/process'
import { useRequiredTenantId } from '@/entities/tenant'
import { ErrorState, LoadingState, PageLayout } from '@/shared/ui'
import { ProcessesTable } from '@/widgets/processes-table'

import {
  createProcessFiltersValues,
  filterProcesses,
  getProcessFilterOptions,
  type ProcessesSearch,
} from '../../model'
import { ProcessFilters } from '../ProcessFilters'

export const ProcessesPage: FC = () => {
  const tenantId = useRequiredTenantId()
  const search = useSearch({ from: '/_workspace/processes' })
  const navigate = useNavigate({ from: '/processes' })
  const query = useQuery(processListQueryOptions(tenantId))
  const canCreate = useCan(Ability.PROCESS_CREATE)
  const processes = useMemo(() => query.data ?? [], [query.data])

  const filterOptions = useMemo(() => getProcessFilterOptions(processes), [processes])
  const filterValues = useMemo(() => createProcessFiltersValues(search), [search])
  const filteredProcesses = useMemo(
    () => filterProcesses(processes, filterValues),
    [filterValues, processes],
  )

  const setSearch = useCallback(
    (nextSearch: ProcessesSearch) => {
      void navigate({ search: nextSearch, replace: true })
    },
    [navigate],
  )

  if (query.isPending) return <LoadingState label='Загружаем процессы…' />
  if (query.isError) return <ErrorState title='Не удалось загрузить процессы' />

  return (
    <PageLayout
      contentLayout='table'
      title='Процессы'
      description='Управляйте процессами, запускайте их вручную и настраивайте параметры выполнения.'
      actions={
        <>
          <Button
            type='button'
            kind='outlined'
            color='secondary'
            prefixIcon={<RefreshCw size={17} />}
            disabled={query.isFetching}
            onClick={() => void query.refetch()}
          >
            {query.isFetching ? 'Обновляем…' : 'Обновить'}
          </Button>
          {canCreate ? (
            <Button
              type='button'
              prefixIcon={<Plus size={17} />}
              onClick={() => void navigate({ to: '/processes/new' })}
            >
              Создать процесс
            </Button>
          ) : null}
        </>
      }
    >
      <ProcessFilters search={search} options={filterOptions} onChange={setSearch} />
      <ProcessesTable processes={filteredProcesses} />
    </PageLayout>
  )
}
