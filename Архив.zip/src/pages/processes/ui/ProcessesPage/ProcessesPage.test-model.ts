import { screen, waitFor, within } from '@testing-library/react'
import { expect } from 'vitest'

import { Permission } from '@/entities/access'
import { processFixture, renderApp, userAccessFixture } from '@/test'

import type { UserEvent } from '@testing-library/user-event'

export class ProcessesPageTestModel {
  private constructor(
    private readonly user: UserEvent,
    private readonly getSearch: () => Record<string, unknown>,
  ) {}

  static async open(permissions: string[]) {
    const app = await renderApp({
      route: '/processes',
      access: userAccessFixture(permissions),
      processes: [
        processFixture(),
        processFixture({
          id: 'process-2',
          processName: 'Очистка архивов',
          processType: 'MAINTENANCE',
          label: 'Обслуживание',
          description: 'Удаляет устаревшие данные.',
          routes: [
            { routeKey: 'db-archive', isLabel: false },
            { routeKey: 'Архивные данные', isLabel: true },
          ],
        }),
      ],
      processTypes: ['DB_PROCESS', 'MAINTENANCE'],
    })

    await screen.findByRole('heading', { name: 'Процессы' })
    return new ProcessesPageTestModel(app.user, () => app.router.state.location.search)
  }

  process(name: string) {
    return screen.getByRole('row', { name: new RegExp(name, 'i') })
  }

  expectProcessVisible(name: string) {
    expect(screen.getByText(name, { selector: 'strong' })).toBeVisible()
  }

  expectProcessHidden(name: string) {
    expect(screen.queryByText(name, { selector: 'strong' })).not.toBeInTheDocument()
  }

  action(name: RegExp) {
    return screen.queryByRole('button', { name })
  }

  async search(value: string) {
    const input = screen.getByRole('textbox', {
      name: 'Название, описание или категория',
    })
    await this.user.clear(input)
    await this.user.type(input, value)
    await waitFor(() => expect(screen.getAllByRole('row')).toHaveLength(2))
  }

  async filterByTarget(value: string) {
    await this.user.selectOptions(
      screen.getByRole('listbox', { name: 'Область выполнения' }),
      value,
    )
    await waitFor(() => expect(screen.getAllByRole('row')).toHaveLength(2))
  }

  searchParams() {
    return this.getSearch()
  }

  rowAction(processName: string, actionName: RegExp) {
    return within(this.process(processName)).queryByRole('button', {
      name: actionName,
    })
  }

  async openProcessCard(processName: string) {
    const action = this.rowAction(processName, /Открыть карточку процесса/i)
    if (!action) throw new Error(`Process card action is missing for ${processName}`)

    await this.user.click(action)
    await screen.findByRole('heading', { name: processName })
  }
}

export const processListPermission = Permission.PROCESS_LIST
