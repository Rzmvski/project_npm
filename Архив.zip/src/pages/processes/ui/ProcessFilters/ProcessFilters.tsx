import { Button, ComboBox } from '@v-uik/base'
import { Database, FilterX, Tag as LabelIcon } from 'lucide-react'
import { useEffect, useMemo, type FC } from 'react'
import { Controller, useForm } from 'react-hook-form'

import {
  findComboBoxOption,
  findComboBoxOptions,
  getComboBoxValue,
  getComboBoxValues,
} from '@/shared/lib'
import { SearchInput } from '@/shared/ui'

import {
  createProcessFiltersValues,
  toProcessesSearch,
  type ProcessFilterOption,
  type ProcessFilterOptions,
  type ProcessFiltersSearch,
  type ProcessFiltersFormValues,
  type ProcessesSearch,
} from '../../model'

import styles from './ProcessFilters.module.scss'

interface ProcessFiltersProps {
  search: ProcessesSearch
  options: ProcessFilterOptions
  onChange: (search: ProcessFiltersSearch) => void
}

export const ProcessFilters: FC<ProcessFiltersProps> = ({ search, options, onChange }) => {
  const searchKey = JSON.stringify({
    query: search.query,
    type: search.type,
    category: search.category,
    target: search.target,
  })
  const initialValues = useMemo(
    () =>
      createProcessFiltersValues({
        query: search.query,
        type: search.type,
        category: search.category,
        target: search.target,
      }),
    [search.category, search.query, search.target, search.type],
  )
  const { control, getValues, reset } = useForm<ProcessFiltersFormValues>({
    defaultValues: initialValues,
  })

  useEffect(() => {
    reset(initialValues)
  }, [initialValues, reset])

  const updateFilters = (patch: Partial<ProcessFiltersFormValues>) => {
    const nextSearch = toProcessesSearch({ ...getValues(), ...patch })
    if (JSON.stringify(nextSearch) !== searchKey) onChange(nextSearch)
  }

  const resetFilters = () => {
    const emptyFilters = createProcessFiltersValues({})
    reset(emptyFilters)
    onChange({})
  }

  const hasActiveFilters = Boolean(
    search.query || search.type || search.category || search.target,
  )

  return (
    <form className={styles.filters} aria-label='Фильтры процессов'>
      <div className={styles.filterGrid}>
        <div className={styles.searchField}>
          <Controller
            name='query'
            control={control}
            render={({ field }) => (
              <SearchInput
                label='Поиск'
                value={field.value}
                onChange={(value) => {
                  field.onChange(value)
                  updateFilters({ query: value })
                }}
                placeholder='Название, описание или категория'
                debounceMs={250}
              />
            )}
          />
        </div>

        <Controller
          name='processType'
          control={control}
          render={({ field }) => (
            <ComboBox<ProcessFilterOption>
              canClear
              isSearchable
              openOnFocus
              label='Тип процесса'
              placeholder='Все типы'
              noOptionsText='Типы не найдены'
              options={options.processTypes}
              value={findComboBoxOption(field.value, options.processTypes)}
              inputProps={{ name: field.name }}
              controlInnerProps={{ onBlur: field.onBlur }}
              onChange={(_value, _event, fullValue) => {
                const value = getComboBoxValue(fullValue)
                field.onChange(value)
                updateFilters({ processType: value })
              }}
            />
          )}
        />

        <Controller
          name='category'
          control={control}
          render={({ field }) => (
            <ComboBox<ProcessFilterOption>
              canClear
              isSearchable
              openOnFocus
              label='Категория'
              placeholder='Все категории'
              noOptionsText='Категории не найдены'
              options={options.categories}
              value={findComboBoxOption(field.value, options.categories)}
              inputProps={{ name: field.name }}
              controlInnerProps={{ onBlur: field.onBlur }}
              onChange={(_value, _event, fullValue) => {
                const value = getComboBoxValue(fullValue)
                field.onChange(value)
                updateFilters({ category: value })
              }}
            />
          )}
        />

        <div className={styles.targetsFilter}>
          <Controller
            name='targets'
            control={control}
            render={({ field }) => (
              <ComboBox<ProcessFilterOption>
                multiple
                canClear
                isSearchable
                openOnFocus
                disableCloseOnSelect
                limitTags={2}
                label='Область выполнения'
                placeholder='Все БД и DB sets'
                noOptionsText='Цели не найдены'
                options={options.targets}
                value={findComboBoxOptions(field.value, options.targets)}
                getOptionPrefix={(option) =>
                  option.targetKind === 'database' ? (
                    <Database size={16} />
                  ) : (
                    <LabelIcon size={16} />
                  )
                }
                inputProps={{ name: field.name }}
                controlInnerProps={{ onBlur: field.onBlur }}
                onChange={(_value, _event, fullValue) => {
                  const values = getComboBoxValues(fullValue)
                  field.onChange(values)
                  updateFilters({ targets: values })
                }}
              />
            )}
          />
        </div>

        <Button
          type='button'
          kind='ghost'
          color='secondary'
          prefixIcon={<FilterX size={16} />}
          disabled={!hasActiveFilters}
          onClick={resetFilters}
        >
          Сбросить
        </Button>
      </div>
    </form>
  )
}
