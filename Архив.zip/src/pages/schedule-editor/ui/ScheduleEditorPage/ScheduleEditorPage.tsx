import { ScheduleForm } from '@/widgets/schedule-form'

import type { FC } from 'react'

interface ScheduleEditorPageProps {
  processId: string
}

export const ScheduleEditorPage: FC<ScheduleEditorPageProps> = ({ processId }) => (
  <ScheduleForm processId={processId} />
)
