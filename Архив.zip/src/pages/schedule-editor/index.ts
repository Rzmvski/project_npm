export const loadScheduleEditorPage = () => import('./ui')
