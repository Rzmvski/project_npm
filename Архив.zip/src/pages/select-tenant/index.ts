export { SelectTenantPage } from './ui'
