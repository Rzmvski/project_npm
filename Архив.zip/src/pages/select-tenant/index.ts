export const loadSelectTenantPage = () => import('./ui')
