import { screen, waitFor } from '@testing-library/react'
import { describe, expect, it } from 'vitest'

import { Permission } from '@/entities/access'
import { UI_VERSION } from '@/shared/config'
import { renderApp, tenantFixture, userAccessFixture } from '@/test'

describe('namespace selection', () => {
  it('filters namespaces and shows an empty state', async () => {
    const app = await renderApp({
      route: '/select-tenant',
      access: userAccessFixture([Permission.PROCESS_LIST]),
    })

    await screen.findByRole('heading', { name: 'Доступные namespaces' })
    expect(screen.getByText(tenantFixture.code)).toBeVisible()
    expect(screen.getByLabelText('Роль пользователя')).toHaveTextContent('Суперадминистратор')
    expect(screen.getByLabelText(`Версия UI ${UI_VERSION}`)).toHaveTextContent(`v${UI_VERSION}`)
    expect(screen.queryByText('user@example.com')).not.toBeInTheDocument()

    await app.user.type(screen.getByPlaceholderText('Поиск по коду или UUID'), 'missing')

    expect(await screen.findByText('Ничего не найдено')).toBeVisible()
    await waitFor(() => expect(screen.queryByText(tenantFixture.code)).not.toBeInTheDocument())
  })

  it('selects a namespace and opens the first permitted workspace page', async () => {
    const app = await renderApp({
      route: '/select-tenant',
      access: userAccessFixture([Permission.PROCESS_LIST]),
    })

    await app.user.click(
      await screen.findByRole('button', { name: new RegExp(tenantFixture.code) }),
    )

    await waitFor(() => expect(app.router.state.location.pathname).toBe('/processes'))
  })
})
