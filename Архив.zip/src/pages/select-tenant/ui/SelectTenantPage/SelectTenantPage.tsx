import { useQuery, useQueryClient } from '@tanstack/react-query'
import { useNavigate } from '@tanstack/react-router'
import { Avatar, Button, notification } from '@v-uik/base'
import { ArrowRight, Box, RefreshCw, SearchX, ShieldCheck, Wrench } from 'lucide-react'
import { useMemo, useState, type FC } from 'react'

import { getDefaultWorkspacePath, userAccessQueryOptions } from '@/entities/access'
import { setSelectedTenantId, tenantListQueryOptions } from '@/entities/tenant'
import { userQueryOptions } from '@/entities/user'
import { formatRoles } from '@/features/dev-switch-role'
import { ErrorState, LoadingState, SearchInput, UiVersion } from '@/shared/ui'

import styles from './SelectTenantPage.module.scss'

const getInitials = (name: string) =>
  name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join('')

export const SelectTenantPage: FC = () => {
  const tenantQuery = useQuery(tenantListQueryOptions())
  const userQuery = useQuery(userQueryOptions())
  const queryClient = useQueryClient()
  const navigate = useNavigate()
  const [search, setSearch] = useState('')
  const [selectingId, setSelectingId] = useState<string | null>(null)
  const roleLabel = formatRoles(userQuery.data?.roles ?? [])

  const tenants = useMemo(() => {
    const value = search.toLocaleLowerCase('ru-RU').trim()
    return (tenantQuery.data ?? []).filter((tenant) =>
      `${tenant.code} ${tenant.id}`.toLocaleLowerCase('ru-RU').includes(value),
    )
  }, [tenantQuery.data, search])

  if (tenantQuery.isPending || userQuery.isPending) {
    return (
      <div className={styles.center}>
        <LoadingState label='Загружаем данные…' />
      </div>
    )
  }

  if (tenantQuery.isError || userQuery.isError) {
    return (
      <div className={styles.center}>
        <ErrorState title='Не удалось загрузить данные страницы' />
      </div>
    )
  }

  const user = userQuery.data

  const select = async (tenantId: string) => {
    setSelectingId(tenantId)

    try {
      const access = await queryClient.ensureQueryData(userAccessQueryOptions(tenantId))
      setSelectedTenantId(tenantId)
      await queryClient.invalidateQueries({ queryKey: ['tenant'] })
      await navigate({ to: getDefaultWorkspacePath(access) })
    } catch (error) {
      notification.error(
        error instanceof Error ? error.message : 'Не удалось выбрать namespace',
      )
      setSelectingId(null)
    }
  }

  return (
    <main className={styles.page}>
      <section className={styles.intro}>
        <div className={styles.introContent}>
          <div className={styles.logo}>
            <Wrench size={19} />
          </div>
          <h1>
            <span>Platform</span>
            <span>Maintenance</span>
            <span>Manager</span>
          </h1>
          <p>
            Все процессы, расписания и история будут показаны в контексте выбранного
            пространства. Контекст можно сменить в меню приложения.
          </p>
          <UiVersion className={styles.version} />
        </div>
        <div className={styles.user}>
          <Avatar aria-label={user.displayName}>{getInitials(user.displayName)}</Avatar>
          <div className={styles.userInfo}>
            <strong>{user.displayName}</strong>
            <span className={styles.userRole} aria-label='Роль пользователя' title={roleLabel}>
              <ShieldCheck size={13} aria-hidden />
              <span>{roleLabel}</span>
            </span>
          </div>
        </div>
      </section>
      <section className={styles.panel}>
        <div className={styles.selector}>
          <header className={styles.panelHeader}>
            <span>Выбор контекста</span>
            <h2>Доступные namespaces</h2>
            <p>Найдите пространство по короткому коду или техническому UUID.</p>
          </header>

          <div className={styles.toolbar}>
            <SearchInput
              value={search}
              onChange={setSearch}
              placeholder='Поиск по коду или UUID'
            />
            <Button
              type='button'
              kind='outlined'
              color='secondary'
              aria-label='Обновить список namespaces'
              title='Обновить список'
              disabled={tenantQuery.isFetching}
              onClick={() => void tenantQuery.refetch()}
            >
              <RefreshCw
                className={tenantQuery.isFetching ? styles.spinning : undefined}
                size={18}
              />
            </Button>
          </div>

          {tenants.length ? (
            <div className={styles.list} aria-busy={Boolean(selectingId)}>
              {tenants.map((tenant) => (
                <div key={tenant.id} className={styles.tenantCard}>
                  <Button
                    className={styles.tenant}
                    type='button'
                    kind='ghost'
                    color='secondary'
                    fullWidth
                    disabled={Boolean(selectingId)}
                    onClick={() => void select(tenant.id)}
                  >
                    <span className={styles.tenantContent}>
                      <span className={styles.tenantIcon}>
                        <Box size={20} />
                      </span>
                      <span className={styles.tenantInfo}>
                        <strong>{tenant.code}</strong>
                        <span>{tenant.id}</span>
                      </span>
                      <span className={styles.tenantAction}>
                        {selectingId === tenant.id ? (
                          <span className={styles.selecting}>Открываем…</span>
                        ) : (
                          <ArrowRight size={20} />
                        )}
                      </span>
                    </span>
                  </Button>
                </div>
              ))}
            </div>
          ) : (
            <div className={styles.empty}>
              <SearchX size={30} />
              <strong>Ничего не найдено</strong>
              <span>Измените запрос или очистите строку поиска.</span>
            </div>
          )}
        </div>
      </section>
    </main>
  )
}
