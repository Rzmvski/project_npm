import { Button } from '@v-uik/base'
import { Pencil, Plus } from 'lucide-react'

import type { ScheduleResponse } from '@/entities/schedule'
import { DeleteScheduleButton } from '@/features/manage-schedule'
import { SchedulePreview } from '@/widgets/schedule-form'

import type { FC } from 'react'

interface ProcessScheduleCardProps {
  schedule?: ScheduleResponse | null
  canCreate: boolean
  canUpdate: boolean
  canDelete: boolean
  onEdit: () => void
}

export const ProcessScheduleCard: FC<ProcessScheduleCardProps> = ({
  schedule,
  canCreate,
  canUpdate,
  canDelete,
  onEdit,
}) => {
  const canEdit = schedule ? canUpdate : canCreate
  const hasActions = canEdit || (Boolean(schedule) && canDelete)

  return (
    <SchedulePreview
      title='Расписание'
      days={schedule?.scheduleDays ?? []}
      emptyMessage='Расписание не настроено'
      action={
        hasActions ? (
          <>
            {canEdit ? (
              <Button
                type='button'
                kind={schedule ? 'outlined' : undefined}
                color={schedule ? 'secondary' : undefined}
                prefixIcon={schedule ? <Pencil size={16} /> : <Plus size={16} />}
                onClick={onEdit}
              >
                {schedule ? 'Изменить расписание' : 'Создать расписание'}
              </Button>
            ) : null}
            {schedule && canDelete ? (
              <DeleteScheduleButton processId={schedule.processId} />
            ) : null}
          </>
        ) : null
      }
    />
  )
}
