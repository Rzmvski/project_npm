import { ProcessTargetBadge, type ProcessSummary } from '@/entities/process'

import styles from './ProcessTargetsCard.module.scss'

import type { FC } from 'react'

interface ProcessTargetsCardProps {
  process: ProcessSummary
}

export const ProcessTargetsCard: FC<ProcessTargetsCardProps> = ({ process }) => (
  <section className={styles.card}>
    <div className={styles.header}>
      <h2>Область выполнения</h2>
      <span aria-label={`Количество областей выполнения: ${process.routes.length}`}>
        {process.routes.length}
      </span>
    </div>

    <div className={styles.targets}>
      {process.routes.map((target) => (
        <ProcessTargetBadge key={`${target.isLabel}-${target.routeKey}`} target={target} />
      ))}
      {!process.routes.length ? (
        <span className={styles.empty}>Область выполнения не настроена</span>
      ) : null}
    </div>
  </section>
)
