import { Database, Tag as LabelIcon } from 'lucide-react'

import { ProcessTargetBadge, type RouteTarget } from '@/entities/process'

import styles from './TargetGroup.module.scss'

import type { FC } from 'react'

interface TargetGroupProps {
  title: string
  targets: RouteTarget[]
  isLabel: boolean
}

export const TargetGroup: FC<TargetGroupProps> = ({ title, targets, isLabel }) => {
  const Icon = isLabel ? LabelIcon : Database

  return (
    <div className={styles.group}>
      <div className={styles.title}>
        <Icon size={16} aria-hidden='true' />
        <strong>{title}</strong>
        <span>{targets.length}</span>
      </div>
      <div className={styles.badges}>
        {targets.length ? (
          targets.map((target) => {
            const { isLabel: targetIsLabel, routeKey } = target

            return <ProcessTargetBadge key={`${targetIsLabel}-${routeKey}`} target={target} />
          })
        ) : (
          <span className={styles.empty}>Не выбраны</span>
        )}
      </div>
    </div>
  )
}
