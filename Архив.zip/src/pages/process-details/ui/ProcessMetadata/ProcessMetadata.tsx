import { Tag } from '@v-uik/base'

import { ProcessCategoryTag, type ProcessSummary } from '@/entities/process'

import styles from './ProcessMetadata.module.scss'

import type { FC } from 'react'

interface ProcessMetadataProps {
  process: ProcessSummary
}

export const ProcessMetadata: FC<ProcessMetadataProps> = ({ process }) => (
  <section className={styles.metadata} aria-label='Основные параметры процесса'>
    <div className={styles.tags}>
      <Tag kind='lite'>{process.processType}</Tag>
      {process.label ? (
        <ProcessCategoryTag category={process.label} />
      ) : (
        <Tag kind='lite'>Без категории</Tag>
      )}
    </div>
  </section>
)
