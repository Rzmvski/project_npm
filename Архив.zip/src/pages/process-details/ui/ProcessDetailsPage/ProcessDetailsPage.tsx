import { useQuery } from '@tanstack/react-query'
import { Link, useNavigate } from '@tanstack/react-router'
import { Button } from '@v-uik/base'
import clsx from 'clsx'
import { Pencil } from 'lucide-react'

import { Ability, useCan } from '@/entities/access'
import { getTargetNames, processListQueryOptions } from '@/entities/process'
import { scheduleQueryOptions } from '@/entities/schedule'
import { useRequiredTenantId } from '@/entities/tenant'
import { DeleteProcessButton } from '@/features/delete-process'
import { StartProcessButton } from '@/features/start-process'
import { CodeEditor, ErrorState, LoadingState, PageBreadcrumbs, PageLayout } from '@/shared/ui'

import { ProcessMetadata } from '../ProcessMetadata'
import { ProcessScheduleCard } from '../ProcessScheduleCard'
import { ProcessTargetsCard } from '../ProcessTargetsCard'

import styles from './ProcessDetailsPage.module.scss'

import type { FC } from 'react'

interface ProcessDetailsPageProps {
  processId: string
}

export const ProcessDetailsPage: FC<ProcessDetailsPageProps> = ({ processId }) => {
  const tenantId = useRequiredTenantId()
  const navigate = useNavigate()
  const canReadSchedule = useCan(Ability.SCHEDULE_READ)
  const canEditProcess = useCan(Ability.PROCESS_UPDATE)
  const canCreateSchedule = useCan(Ability.SCHEDULE_CREATE)
  const canUpdateSchedule = useCan(Ability.SCHEDULE_UPDATE)
  const canDeleteSchedule = useCan(Ability.SCHEDULE_DELETE)
  const processesQuery = useQuery(processListQueryOptions(tenantId))
  const scheduleQuery = useQuery({
    ...scheduleQueryOptions(tenantId, processId),
    enabled: canReadSchedule,
  })

  if (processesQuery.isPending || (canReadSchedule && scheduleQuery.isPending)) {
    return <LoadingState label='Загружаем процесс…' />
  }

  if (processesQuery.isError || (canReadSchedule && scheduleQuery.isError)) {
    return <ErrorState title='Не удалось загрузить процесс' />
  }

  const process = processesQuery.data.content.find((item) => item.id === processId)
  if (!process) return <ErrorState title='Процесс не найден' />

  const openProcessEditor = () =>
    void navigate({
      to: '/processes/$processId/edit',
      params: { processId },
    })

  const openScheduleEditor = () =>
    void navigate({
      to: '/schedules/$processId/edit',
      params: { processId },
      search: { returnTo: 'process' },
    })

  return (
    <PageLayout
      contentLayout='table'
      breadcrumbs={
        <PageBreadcrumbs>
          <Link to='/processes'>Процессы</Link>
          <span aria-current='page'>{process.processName}</span>
        </PageBreadcrumbs>
      }
      title={process.processName}
      description={process.description || 'Описание процесса не указано.'}
      headerMeta={<ProcessMetadata process={process} />}
      actions={
        <>
          <StartProcessButton
            processId={process.id}
            processName={process.processName}
            routes={getTargetNames(process.routes)}
          />
          {canEditProcess ? (
            <Button
              type='button'
              kind='outlined'
              color='secondary'
              prefixIcon={<Pencil size={17} />}
              onClick={openProcessEditor}
            >
              Редактировать
            </Button>
          ) : null}
          <DeleteProcessButton
            processId={process.id}
            processName={process.processName}
            onDeleted={() => void navigate({ to: '/processes' })}
          />
        </>
      }
    >
      <div className={styles.detailsGrid}>
        <section className={clsx(styles.card, styles.commandCard)}>
          <div className={styles.cardHeader}>
            <div>
              <h2>Команда запуска</h2>
              <p>Команда, которая будет выполнена при старте процесса.</p>
            </div>
          </div>
          <CodeEditor value={process.cmd ?? ''} readOnly height='fill' />
        </section>

        <div className={styles.aside}>
          <ProcessTargetsCard process={process} />
          {canReadSchedule ? (
            <ProcessScheduleCard
              schedule={scheduleQuery.data}
              canCreate={canCreateSchedule}
              canUpdate={canUpdateSchedule}
              canDelete={canDeleteSchedule}
              onEdit={openScheduleEditor}
            />
          ) : null}
        </div>
      </div>
    </PageLayout>
  )
}
