export { ProcessDetailsPage } from './ui'
