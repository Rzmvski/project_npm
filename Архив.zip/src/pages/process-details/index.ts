export const loadProcessDetailsPage = () => import('./ui')
