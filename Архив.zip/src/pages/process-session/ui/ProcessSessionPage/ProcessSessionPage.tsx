import { useQuery } from '@tanstack/react-query'
import { Link, useNavigate, useSearch } from '@tanstack/react-router'
import { Button } from '@v-uik/base'
import { RefreshCw } from 'lucide-react'

import { processDetailQueryOptions } from '@/entities/process-history'
import { useRequiredTenantId } from '@/entities/tenant'
import { StopProcessButton } from '@/features/stop-process'
import { ErrorState, LoadingState, PageBreadcrumbs, PageLayout } from '@/shared/ui'
import { ProcessSessionMonitoring } from '@/widgets/process-session-monitoring'

import styles from './ProcessSessionPage.module.scss'

import type { ProcessSessionSearch } from '../../model'
import type { FC } from 'react'

interface ProcessSessionPageProps {
  sessionProcessId: string
}

export const ProcessSessionPage: FC<ProcessSessionPageProps> = ({ sessionProcessId }) => {
  const tenantId = useRequiredTenantId()
  const search = useSearch({ from: '/_workspace/history/$sessionProcessId' })
  const navigate = useNavigate({ from: '/history/$sessionProcessId' })
  const query = useQuery({
    ...processDetailQueryOptions(tenantId, sessionProcessId),
    refetchInterval: (state) =>
      state.state.data?.processSession.statusCode === 'WORKS' ? 5_000 : false,
  })

  if (query.isPending) return <LoadingState label='Загружаем детали выполнения…' />
  if (query.isError) return <ErrorState title='Не удалось загрузить детали выполнения' />

  const setSearch = (patch: Partial<ProcessSessionSearch>) => {
    void navigate({
      search: (current) => ({ ...current, ...patch }),
      replace: true,
    })
  }

  return (
    <PageLayout
      breadcrumbs={
        <PageBreadcrumbs>
          <Link to='/history'>История</Link>
          <span aria-current='page'>{query.data.processName}</span>
        </PageBreadcrumbs>
      }
      title='Детали выполнения'
      contentLayout={search.view === 'summary' ? 'default' : 'table'}
      actions={
        <div className={styles.actions}>
          <Button
            type='button'
            kind='outlined'
            color='secondary'
            prefixIcon={<RefreshCw size={16} />}
            onClick={() => void query.refetch()}
          >
            Обновить
          </Button>
          {query.data.processSession.statusCode === 'WORKS' ? (
            <StopProcessButton sessionId={query.data.processSession.processSessionId} />
          ) : null}
        </div>
      }
    >
      <ProcessSessionMonitoring
        detail={query.data}
        search={search}
        onSearchChange={setSearch}
      />
    </PageLayout>
  )
}
