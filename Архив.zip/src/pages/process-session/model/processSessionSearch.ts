import {
  MONITORING_PAGE_SIZES,
  parseOptionalSearchString,
  parsePaginationSearch,
} from '@/shared/lib'
import type { ProcessSessionSearchState } from '@/widgets/process-session-monitoring'

import type { SearchSchemaInput } from '@tanstack/react-router'

export type ProcessSessionSearch = ProcessSessionSearchState
type SearchInput = Record<string, unknown>

export function validateProcessSessionSearch(search: SearchInput): ProcessSessionSearch
export function validateProcessSessionSearch(
  search: SearchInput & SearchSchemaInput,
): ProcessSessionSearch
export function validateProcessSessionSearch(search: SearchInput): ProcessSessionSearch {
  const routePagination = parsePaginationSearch(
    { page: search.routePage, size: search.routeSize, sort: search.routeSort },
    {
      defaultSize: 50,
      defaultSort: 'asc:startDateTime',
      sizeOptions: MONITORING_PAGE_SIZES,
    },
  )
  const threadPagination = parsePaginationSearch(
    { page: search.threadPage, size: search.threadSize, sort: search.threadSort },
    {
      defaultSize: 50,
      defaultSort: 'asc:threadNumber',
      sizeOptions: MONITORING_PAGE_SIZES,
    },
  )

  return {
    view: search.view === 'routes' || search.view === 'threads' ? search.view : 'summary',
    routePage: routePagination.page,
    routeSize: routePagination.size,
    routeSort: routePagination.sort,
    routeQuery: parseOptionalSearchString(search.routeQuery),
    routeStatus: parseOptionalSearchString(search.routeStatus),
    threadRouteSessionId: parseOptionalSearchString(search.threadRouteSessionId),
    threadRouteKey: parseOptionalSearchString(search.threadRouteKey),
    threadPod: parseOptionalSearchString(search.threadPod),
    threadStatus: parseOptionalSearchString(search.threadStatus),
    threadPage: threadPagination.page,
    threadSize: threadPagination.size,
    threadSort: threadPagination.sort,
  }
}
