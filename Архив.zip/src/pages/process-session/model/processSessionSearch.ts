import type { ProcessSessionSearchState } from '@/widgets/process-session-monitoring'

import type { SearchSchemaInput } from '@tanstack/react-router'

const PAGE_SIZES = [25, 50, 100]

export type ProcessSessionSearch = ProcessSessionSearchState
type SearchInput = Record<string, unknown>

function optionalString(value: unknown): string | undefined {
  return typeof value === 'string' && value.trim() ? value : undefined
}

function pageNumber(value: unknown): number {
  return Number.isFinite(Number(value)) ? Math.max(0, Number(value)) : 0
}

function pageSize(value: unknown): number {
  const size = Number(value)
  return PAGE_SIZES.includes(size) ? size : 50
}

export function validateProcessSessionSearch(search: SearchInput): ProcessSessionSearch
export function validateProcessSessionSearch(
  search: SearchInput & SearchSchemaInput,
): ProcessSessionSearch
export function validateProcessSessionSearch(search: SearchInput): ProcessSessionSearch {
  return {
    view: search.view === 'routes' || search.view === 'threads' ? search.view : 'summary',
    routePage: pageNumber(search.routePage),
    routeSize: pageSize(search.routeSize),
    routeSort: optionalString(search.routeSort) ?? 'startDateTime,asc',
    routeQuery: optionalString(search.routeQuery),
    routeStatus: optionalString(search.routeStatus),
    threadRouteSessionId: optionalString(search.threadRouteSessionId),
    threadRouteKey: optionalString(search.threadRouteKey),
    threadPod: optionalString(search.threadPod),
    threadStatus: optionalString(search.threadStatus),
    threadPage: pageNumber(search.threadPage),
    threadSize: pageSize(search.threadSize),
    threadSort: optionalString(search.threadSort) ?? 'threadNumber,asc',
  }
}
