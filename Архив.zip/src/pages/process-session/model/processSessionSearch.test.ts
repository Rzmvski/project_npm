import { describe, expect, it } from 'vitest'

import { validateProcessSessionSearch } from './processSessionSearch'

describe('process session search', () => {
  it('returns stable defaults for an empty URL', () => {
    expect(validateProcessSessionSearch({})).toEqual({
      view: 'summary',
      routePage: 0,
      routeSize: 50,
      routeSort: 'startDateTime,asc',
      routeQuery: undefined,
      routeStatus: undefined,
      threadRouteSessionId: undefined,
      threadRouteKey: undefined,
      threadPod: undefined,
      threadStatus: undefined,
      threadPage: 0,
      threadSize: 50,
      threadSort: 'threadNumber,asc',
    })
  })

  it('normalizes invalid pages and unsupported sizes', () => {
    expect(
      validateProcessSessionSearch({
        view: 'threads',
        routePage: -5,
        routeSize: 12,
        threadPage: '3',
        threadSize: 100,
      }),
    ).toMatchObject({
      view: 'threads',
      routePage: 0,
      routeSize: 50,
      threadPage: 3,
      threadSize: 100,
    })
  })
})
