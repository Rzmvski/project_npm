import { useNavigate } from '@tanstack/react-router'
import { Button, InlineNotification } from '@v-uik/base'
import { ArrowLeft, ShieldX } from 'lucide-react'

import { getDefaultWorkspacePath, useAccess } from '@/entities/access'
import { PageLayout } from '@/shared/ui'

import styles from './ForbiddenPage.module.scss'

import type { FC } from 'react'

export const ForbiddenPage: FC = () => {
  const navigate = useNavigate()
  const { permissions } = useAccess()
  const target = getDefaultWorkspacePath([...permissions])

  return (
    <PageLayout
      title='Доступ запрещён'
      description='У вашей учётной записи нет разрешения на открытие этой страницы.'
    >
      <section className={styles.card}>
        <span className={styles.status}>403</span>
        <div className={styles.icon}>
          <ShieldX size={34} />
        </div>
        <div className={styles.content}>
          <h2>Недостаточно прав</h2>
          <p>
            Доступ ограничен ролевой моделью. Обратитесь к администратору IAM, если
            функциональность должна быть доступна вашей роли.
          </p>
        </div>
        <InlineNotification kind='outlined' status='warning' title='Запрос не был выполнен'>
          Ваши данные и настройки не изменены.
        </InlineNotification>
        {target !== '/forbidden' ? (
          <Button type='button' onClick={() => void navigate({ to: target })}>
            <ArrowLeft size={17} />
            Перейти в доступный раздел
          </Button>
        ) : null}
      </section>
    </PageLayout>
  )
}
