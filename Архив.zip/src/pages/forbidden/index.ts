export const loadForbiddenPage = () => import('./ui/ForbiddenPage')
