export const loadScheduleDetailsPage = () => import('./ui')
