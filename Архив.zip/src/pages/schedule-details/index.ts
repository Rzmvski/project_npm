export { ScheduleDetailsPage } from './ui'
