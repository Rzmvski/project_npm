import { useQuery } from '@tanstack/react-query'
import { Link, useNavigate } from '@tanstack/react-router'
import { Button, Tag } from '@v-uik/base'
import { Pencil } from 'lucide-react'

import { Ability, useCan } from '@/entities/access'
import { ProcessCategoryTag, processListQueryOptions } from '@/entities/process'
import { scheduleQueryOptions } from '@/entities/schedule'
import { useRequiredTenantId } from '@/entities/tenant'
import { ErrorState, LoadingState, PageBreadcrumbs, PageLayout } from '@/shared/ui'
import { ScheduleWeekCard } from '@/widgets/schedule-form'

import styles from './ScheduleDetailsPage.module.scss'

import type { FC } from 'react'

interface ScheduleDetailsPageProps {
  processId: string
}

export const ScheduleDetailsPage: FC<ScheduleDetailsPageProps> = ({ processId }) => {
  const tenantId = useRequiredTenantId()
  const navigate = useNavigate()
  const canEdit = useCan(Ability.SCHEDULE_UPDATE)
  const processesQuery = useQuery(processListQueryOptions(tenantId))
  const scheduleQuery = useQuery(scheduleQueryOptions(tenantId, processId))

  if (processesQuery.isPending || scheduleQuery.isPending) {
    return <LoadingState label='Загружаем расписание…' />
  }
  if (processesQuery.isError || scheduleQuery.isError) {
    return <ErrorState title='Не удалось загрузить расписание' />
  }

  const process = processesQuery.data.find((item) => item.id === processId)
  if (!process) return <ErrorState title='Процесс не найден' />
  if (!scheduleQuery.data) return <ErrorState title='Расписание не настроено' />

  return (
    <PageLayout
      breadcrumbs={
        <PageBreadcrumbs>
          <Link to='/schedules'>Расписания</Link>
          <span aria-current='page'>{process.processName}</span>
        </PageBreadcrumbs>
      }
      title={process.processName}
      description='Расписание автоматических запусков процесса по дням недели.'
      actions={
        canEdit ? (
          <Button
            type='button'
            kind='outlined'
            color='secondary'
            prefixIcon={<Pencil size={17} />}
            onClick={() =>
              void navigate({
                to: '/schedules/$processId/edit',
                params: { processId },
              })
            }
          >
            Редактировать
          </Button>
        ) : null
      }
    >
      <div className={styles.layout}>
        <ScheduleWeekCard days={scheduleQuery.data.scheduleDays} />

        <aside className={styles.aside}>
          <section className={styles.processCard}>
            <div className={styles.cardHeader}>
              <div>
                <h2>О процессе</h2>
                <p>Процесс, который запускается по этому расписанию.</p>
              </div>
            </div>
            <div className={styles.tags}>
              <Tag kind='lite'>{process.processType}</Tag>
              {process.label ? <ProcessCategoryTag category={process.label} /> : null}
            </div>
            <p className={styles.processDescription}>
              {process.description || 'Описание процесса не указано.'}
            </p>
            <div className={styles.identifier}>
              <span>ID процесса</span>
              <code title={process.id}>{process.id}</code>
            </div>
          </section>
        </aside>
      </div>
    </PageLayout>
  )
}
