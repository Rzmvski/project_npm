import { useIsFetching, useQueryClient } from '@tanstack/react-query'
import { Button } from '@v-uik/base'
import { RefreshCw } from 'lucide-react'

import { scheduleKeys } from '@/entities/schedule'
import { useRequiredTenantId } from '@/entities/tenant'
import { CreateScheduleButton } from '@/features/manage-schedule'
import { PageLayout } from '@/shared/ui'
import { SchedulesCatalog } from '@/widgets/schedules-catalog'

import type { FC } from 'react'

export const SchedulesPage: FC = () => {
  const tenantId = useRequiredTenantId()
  const queryClient = useQueryClient()
  const isRefreshing = useIsFetching({ queryKey: scheduleKeys.all(tenantId) }) > 0

  return (
    <PageLayout
      contentLayout='table'
      title='Расписания'
      description='Управление недельными интервалами запуска процессов.'
      actions={
        <>
          <Button
            type='button'
            kind='outlined'
            color='secondary'
            prefixIcon={<RefreshCw size={17} />}
            disabled={isRefreshing}
            onClick={() =>
              void queryClient.invalidateQueries({ queryKey: scheduleKeys.all(tenantId) })
            }
          >
            {isRefreshing ? 'Обновляем…' : 'Обновить'}
          </Button>
          <CreateScheduleButton />
        </>
      }
    >
      <SchedulesCatalog />
    </PageLayout>
  )
}
