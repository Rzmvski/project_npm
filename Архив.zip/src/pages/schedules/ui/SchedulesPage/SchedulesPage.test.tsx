import { screen, waitFor, within } from '@testing-library/react'
import { describe, expect, it } from 'vitest'

import { Permission } from '@/entities/access'
import { scheduleKeys } from '@/entities/schedule'
import {
  pageFixture,
  processFixture,
  renderApp,
  scheduleFixture,
  scheduleListItemFixture,
  TEST_TENANT_ID,
  userAccessFixture,
} from '@/test'

describe('schedule catalog', () => {
  it('shows configured days and an edit action for a scheduler', async () => {
    await renderApp({
      route: '/schedules',
      access: userAccessFixture([
        Permission.SCHEDULE_LIST,
        Permission.SCHEDULE_UPDATE,
        Permission.SCHEDULE_DELETE,
      ]),
      seed: (queryClient) => {
        queryClient.setQueryData(
          scheduleKeys.list(TEST_TENANT_ID, {
            page: 0,
            size: 20,
            sort: 'processName,asc',
          }),
          pageFixture([scheduleListItemFixture()], { size: 20 }),
        )
      },
    })

    await screen.findByRole('heading', { name: 'Расписания' })
    const row = screen.getByRole('row', {
      name: /Дневная загрузка данных/i,
    })

    expect(within(row).getByText('Пн')).toBeVisible()
    expect(
      within(row).getByRole('button', {
        name: /Редактировать расписание/i,
      }),
    ).toBeVisible()
    expect(
      within(row).getByRole('button', {
        name: /Удалить расписание/i,
      }),
    ).toBeVisible()
  })

  it('starts schedule creation for a process without a schedule', async () => {
    const process = processFixture()
    const app = await renderApp({
      route: '/schedules',
      access: userAccessFixture([Permission.SCHEDULE_LIST, Permission.SCHEDULE_CREATE]),
      processes: [process],
      seed: (queryClient) => {
        queryClient.setQueryData(
          scheduleKeys.list(TEST_TENANT_ID, {
            page: 0,
            size: 20,
            sort: 'processName,asc',
          }),
          pageFixture([], { size: 20 }),
        )
        queryClient.setQueryData(
          [...scheduleKeys.all(TEST_TENANT_ID), 'scheduled-process-ids'],
          [],
        )
      },
    })

    await app.user.click(
      await screen.findByRole('button', {
        name: 'Создать расписание',
      }),
    )
    await screen.findByRole('heading', { name: 'Создание расписания' })
    await app.user.selectOptions(screen.getByRole('combobox', { name: 'Процесс' }), process.id)
    await app.user.click(screen.getByRole('button', { name: 'Продолжить' }))

    await waitFor(() =>
      expect(app.router.state.location.pathname).toBe(`/schedules/${process.id}/edit`),
    )
  })

  it('opens the schedule details page from the view action', async () => {
    const process = processFixture()
    const app = await renderApp({
      route: '/schedules',
      access: userAccessFixture([Permission.SCHEDULE_LIST]),
      processes: [process],
      schedule: scheduleFixture,
      seed: (queryClient) => {
        queryClient.setQueryData(
          scheduleKeys.list(TEST_TENANT_ID, {
            page: 0,
            size: 20,
            sort: 'processName,asc',
          }),
          pageFixture([scheduleListItemFixture()], { size: 20 }),
        )
      },
    })

    const openButton = await screen.findByRole('button', {
      name: `Открыть расписание ${process.processName}`,
    })
    const row = screen.getByRole('row', { name: /Дневная загрузка данных/i })
    expect(screen.queryByRole('button', { name: 'Создать расписание' })).not.toBeInTheDocument()
    expect(
      within(row).queryByRole('button', { name: /Редактировать расписание/i }),
    ).not.toBeInTheDocument()
    expect(
      within(row).queryByRole('button', { name: /Удалить расписание/i }),
    ).not.toBeInTheDocument()

    await app.user.click(openButton)

    await screen.findByRole('heading', { name: process.processName })
    expect(screen.getByRole('heading', { name: 'Недельное расписание' })).toBeVisible()
    expect(screen.getByText('1 активный день')).toBeVisible()
    expect(app.router.state.location.pathname).toBe(`/schedules/${process.id}`)
  })
})
