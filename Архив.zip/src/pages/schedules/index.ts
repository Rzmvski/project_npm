export const loadSchedulesPage = () => import('./ui')
