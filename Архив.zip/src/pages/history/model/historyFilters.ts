import { format, isValid, parseISO } from 'date-fns'

import type { ProcessHistoryItem, ProcessStatusCode } from '@/entities/process-history'
import type { ComboBoxOption } from '@/shared/lib'

export interface HistoryFiltersSearch {
  query?: string
  status?: string
  category?: string
  from?: string
  to?: string
}

export interface HistoryFiltersFormValues {
  query: string
  statuses: string[]
  categories: string[]
  dateRange: [Date | null, Date | null]
}

export const historyStatusOptions: Array<ComboBoxOption & { value: ProcessStatusCode }> = [
  { value: 'CREATED', label: 'Создан' },
  { value: 'WORKS', label: 'Исполняется' },
  { value: 'SUCCESS', label: 'Завершён' },
  { value: 'ERROR', label: 'Ошибка' },
  { value: 'CANCELED', label: 'Отменён' },
  { value: 'STOPPED', label: 'Остановлен' },
]

const parseDate = (value?: string) => {
  if (!value) return null
  const date = parseISO(value)
  return isValid(date) ? date : null
}

const serializeDate = (value: Date | null) =>
  value && isValid(value) ? format(value, 'yyyy-MM-dd') : undefined

const splitValues = (value?: string) => value?.split(',').filter(Boolean) ?? []

export const createHistoryFiltersValues = (
  search: HistoryFiltersSearch,
): HistoryFiltersFormValues => ({
  query: search.query ?? '',
  statuses: splitValues(search.status),
  categories: splitValues(search.category),
  dateRange: [parseDate(search.from), parseDate(search.to)],
})

export const toHistoryFiltersSearch = (
  values: HistoryFiltersFormValues,
): HistoryFiltersSearch => ({
  query: values.query.trim() || undefined,
  status: values.statuses.length ? values.statuses.join(',') : undefined,
  category: values.categories.length ? values.categories.join(',') : undefined,
  from: serializeDate(values.dateRange[0]),
  to: serializeDate(values.dateRange[1]),
})

export const getHistoryCategoryOptions = (items: ProcessHistoryItem[]) =>
  [
    ...new Set(
      items.map(({ label }) => label).filter((label): label is string => Boolean(label)),
    ),
  ]
    .sort((left, right) => left.localeCompare(right, 'ru'))
    .map((value) => ({ value, label: value }))
