export const loadHistoryPage = () => import('./ui')
