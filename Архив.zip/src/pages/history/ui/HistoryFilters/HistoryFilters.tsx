import { Button, ComboBox, RangePicker } from '@v-uik/base'
import { CalendarDays, FilterX } from 'lucide-react'
import { useEffect, useMemo, type FC } from 'react'
import { Controller, useForm } from 'react-hook-form'

import { findComboBoxOptions, getComboBoxValues, type ComboBoxOption } from '@/shared/lib'
import { SearchInput } from '@/shared/ui'

import {
  createHistoryFiltersValues,
  historyStatusOptions,
  toHistoryFiltersSearch,
  type HistoryFiltersFormValues,
  type HistoryFiltersSearch,
} from '../../model'

import styles from './HistoryFilters.module.scss'

interface HistoryFiltersProps {
  search: HistoryFiltersSearch
  categoryOptions: ComboBoxOption[]
  onChange: (search: HistoryFiltersSearch) => void
}

const normalizeDate = (value: Date | number | null) =>
  value === null ? null : value instanceof Date ? value : new Date(value)

export const HistoryFilters: FC<HistoryFiltersProps> = ({
  search,
  categoryOptions,
  onChange,
}) => {
  const searchKey = JSON.stringify(search)
  const initialValues = useMemo(() => createHistoryFiltersValues(search), [search])
  const { control, getValues, reset } = useForm<HistoryFiltersFormValues>({
    defaultValues: initialValues,
  })

  useEffect(() => {
    reset(initialValues)
  }, [initialValues, reset])

  const updateFilters = (patch: Partial<HistoryFiltersFormValues>) => {
    const nextSearch = toHistoryFiltersSearch({ ...getValues(), ...patch })
    if (JSON.stringify(nextSearch) !== searchKey) onChange(nextSearch)
  }

  const resetFilters = () => {
    const emptyFilters = createHistoryFiltersValues({})
    reset(emptyFilters)
    onChange({})
  }

  const hasActiveFilters = Object.values(search).some(Boolean)

  return (
    <form className={styles.filters} aria-label='Фильтры истории'>
      <div className={styles.filterGrid}>
        <div className={styles.searchField}>
          <Controller
            name='query'
            control={control}
            render={({ field }) => (
              <SearchInput
                label='Процесс'
                value={field.value}
                placeholder='Название процесса'
                debounceMs={250}
                onChange={(value) => {
                  field.onChange(value)
                  updateFilters({ query: value })
                }}
              />
            )}
          />
        </div>

        <Controller
          name='statuses'
          control={control}
          render={({ field }) => (
            <ComboBox<ComboBoxOption>
              multiple
              canClear
              openOnFocus
              disableCloseOnSelect
              limitTags={1}
              label='Статус'
              placeholder='Все статусы'
              options={historyStatusOptions}
              value={findComboBoxOptions(field.value, historyStatusOptions)}
              inputProps={{ name: field.name }}
              controlInnerProps={{ onBlur: field.onBlur }}
              onChange={(_value, _event, fullValue) => {
                const values = getComboBoxValues(fullValue)
                field.onChange(values)
                updateFilters({ statuses: values })
              }}
            />
          )}
        />

        <Controller
          name='categories'
          control={control}
          render={({ field }) => (
            <ComboBox<ComboBoxOption>
              multiple
              canClear
              isSearchable
              openOnFocus
              disableCloseOnSelect
              limitTags={1}
              label='Теги'
              placeholder='Все теги'
              noOptionsText='Теги не найдены'
              options={categoryOptions}
              value={findComboBoxOptions(field.value, categoryOptions)}
              inputProps={{ name: field.name }}
              controlInnerProps={{ onBlur: field.onBlur }}
              onChange={(_value, _event, fullValue) => {
                const values = getComboBoxValues(fullValue)
                field.onChange(values)
                updateFilters({ categories: values })
              }}
            />
          )}
        />

        <Controller
          name='dateRange'
          control={control}
          render={({ field }) => (
            <RangePicker<Date>
              fullWidth
              canClear
              classes={{ inputContainer: styles.dateRange }}
              label='Период запуска'
              format='dd.MM.yyyy'
              mask='11.11.1111'
              suffix={<CalendarDays size={18} aria-hidden />}
              value={field.value}
              startInputProps={{
                placeholder: 'ДД.ММ.ГГГГ',
                inputProps: {
                  'aria-label': 'Дата запуска с',
                },
              }}
              endInputProps={{
                placeholder: 'ДД.ММ.ГГГГ',
                inputProps: {
                  'aria-label': 'Дата запуска по',
                },
              }}
              onChange={(value) => {
                const range: [Date | null, Date | null] = [
                  normalizeDate(value[0]),
                  normalizeDate(value[1]),
                ]
                field.onChange(range)
                updateFilters({ dateRange: range })
              }}
            />
          )}
        />

        <Button
          type='button'
          kind='ghost'
          color='secondary'
          prefixIcon={<FilterX size={16} />}
          disabled={!hasActiveFilters}
          onClick={resetFilters}
        >
          Сбросить
        </Button>
      </div>
    </form>
  )
}
