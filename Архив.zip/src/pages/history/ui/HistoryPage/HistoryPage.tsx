import { keepPreviousData, useQuery } from '@tanstack/react-query'
import { useNavigate, useSearch } from '@tanstack/react-router'
import { Button } from '@v-uik/base'
import { RefreshCw } from 'lucide-react'
import { useMemo, type FC } from 'react'

import { processHistoryQueryOptions } from '@/entities/process-history'
import { useRequiredTenantId } from '@/entities/tenant'
import { ErrorState, LoadingState, PageLayout, Pagination } from '@/shared/ui'
import { HistoryTable } from '@/widgets/history-table'

import { getHistoryCategoryOptions, type HistoryFiltersSearch } from '../../model'
import { HistoryFilters } from '../HistoryFilters'

export const HistoryPage: FC = () => {
  const tenantId = useRequiredTenantId()
  const search = useSearch({ from: '/_workspace/history' })
  const navigate = useNavigate({ from: '/history' })
  // q/status/category/from/to are local filter state only (see model/historyFilters) —
  // GET /process/history documents just page/size/sort, so they aren't forwarded to the backend.
  const query = useQuery({
    ...processHistoryQueryOptions(tenantId, {
      page: search.page,
      size: search.size,
      sort: search.sort,
    }),
    placeholderData: keepPreviousData,
  })

  const setSearch = (patch: Partial<typeof search>) => {
    void navigate({
      search: (current) => ({ ...current, ...patch }),
      replace: true,
    })
  }

  const categoryOptions = useMemo(() => {
    const options = getHistoryCategoryOptions(query.data?.content ?? [])
    const selected = search.category?.split(',').filter(Boolean) ?? []
    const knownValues = new Set(options.map(({ value }) => value))

    return [
      ...options,
      ...selected
        .filter((value) => !knownValues.has(value))
        .map((value) => ({ value, label: value })),
    ]
  }, [query.data?.content, search.category])

  if (query.isPending) return <LoadingState label='Загружаем историю…' />
  if (query.isError) return <ErrorState title='Не удалось загрузить историю' />

  return (
    <PageLayout
      contentLayout='table'
      title='История процессов'
      description='Последняя P-сессия каждого процесса, включая soft-deleted процессы.'
      actions={
        <Button
          type='button'
          kind='outlined'
          color='secondary'
          prefixIcon={<RefreshCw size={16} />}
          disabled={query.isFetching}
          onClick={() => void query.refetch()}
        >
          Обновить
        </Button>
      }
    >
      <HistoryFilters
        search={search}
        categoryOptions={categoryOptions}
        onChange={(filters: HistoryFiltersSearch) => setSearch({ ...filters, page: 0 })}
      />
      <HistoryTable items={query.data.content} />
      <Pagination
        page={query.data.number}
        totalPages={query.data.totalPages}
        size={query.data.size}
        totalElements={query.data.totalElements}
        onPageChange={(page) => setSearch({ page })}
        onSizeChange={(size) => setSearch({ size, page: 0 })}
      />
    </PageLayout>
  )
}
