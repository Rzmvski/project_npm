import { screen, within } from '@testing-library/react'
import { describe, expect, it } from 'vitest'

import { Permission } from '@/entities/access'
import { historyKeys } from '@/entities/process-history'
import {
  historyItemFixture,
  pageFixture,
  renderApp,
  TEST_SESSION_ID,
  TEST_TENANT_ID,
  userAccessFixture,
} from '@/test'

describe('process history', () => {
  it('shows actions that are valid for an active process session', async () => {
    await renderApp({
      route: '/history',
      access: userAccessFixture([
        Permission.PROCESS_HISTORY,
        Permission.PROCESS_HISTORY_DETAILS,
        Permission.PROCESS_START,
        Permission.PROCESS_STOP,
      ]),
      seed: (queryClient) => {
        queryClient.setQueryData(
          historyKeys.list(TEST_TENANT_ID, {
            page: 0,
            size: 20,
            sort: 'start_date_time:desc',
          }),
          pageFixture(
            [
              historyItemFixture({
                statusCode: 'WORKS',
                statusName: 'Исполняется',
                endDateTime: null,
                sessionProcessId: TEST_SESSION_ID,
              }),
            ],
            { size: 20 },
          ),
        )
      },
    })

    await screen.findByRole('heading', { name: 'История процессов' })
    const row = screen.getByRole('row', {
      name: /Дневная загрузка данных/i,
    })

    expect(within(row).getByRole('button', { name: 'Остановить' })).toBeVisible()
    expect(within(row).getByRole('button', { name: 'Открыть детали' })).toBeVisible()
  })

  it('does not expose the details action without historyService_getDetailed', async () => {
    await renderApp({
      route: '/history',
      access: userAccessFixture([Permission.PROCESS_HISTORY]),
      seed: (queryClient) => {
        queryClient.setQueryData(
          historyKeys.list(TEST_TENANT_ID, {
            page: 0,
            size: 20,
            sort: 'start_date_time:desc',
          }),
          pageFixture([historyItemFixture({ sessionProcessId: TEST_SESSION_ID })], {
            size: 20,
          }),
        )
      },
    })

    await screen.findByRole('heading', { name: 'История процессов' })
    expect(screen.queryByRole('button', { name: 'Открыть детали' })).not.toBeInTheDocument()
  })
})
