import { afterEach, describe, expect, it, vi } from 'vitest'

import { getUserAccess } from '@/entities/access'
import {
  createProcess,
  deleteProcess,
  getProcesses,
  getProcessTypes,
  startProcess,
  stopProcess,
  updateProcess,
} from '@/entities/process'
import {
  getProcessDetail,
  getProcessHistory,
  getRouteSessions,
  getThreadSessions,
} from '@/entities/process-history'
import { getAvailableRoutes } from '@/entities/route'
import {
  createSchedule,
  deleteSchedule,
  getSchedule,
  getSchedules,
  updateSchedule,
} from '@/entities/schedule'
import { getTenants } from '@/entities/tenant'
import { getCurrentUser } from '@/entities/user'
import { ApiError, apiDataRequest, apiRequest } from '@/shared/api'
import {
  processFixture,
  processMutationFixture,
  routesFixture,
  scheduleFixture,
  TEST_PROCESS_ID,
  TEST_SESSION_ID,
  TEST_TENANT_ID,
} from '@/test'

vi.mock('@/shared/api', () => ({
  ApiError: class ApiError extends Error {
    constructor(
      message: string,
      readonly status: number,
    ) {
      super(message)
      this.name = 'ApiError'
    }
  },
  apiDataRequest: vi.fn(),
  apiRequest: vi.fn(),
}))

const dataRequestMock = vi.mocked(apiDataRequest)
const requestMock = vi.mocked(apiRequest)

describe('entity API contracts', () => {
  afterEach(() => {
    vi.clearAllMocks()
    vi.unstubAllEnvs()
  })

  it('loads the current user profile from its endpoint', async () => {
    dataRequestMock.mockResolvedValueOnce({
      login: 'tester@example.com',
      displayName: 'Tester',
      roles: ['USER'],
    })

    await getCurrentUser()
    expect(dataRequestMock).toHaveBeenLastCalledWith('/user')

    vi.stubEnv('VITE_USER_ENDPOINT', '/current-user')
    await getCurrentUser()
    expect(dataRequestMock).toHaveBeenLastCalledWith('/current-user')
  })

  it('uses configured permissions or loads them from the access endpoint', async () => {
    vi.stubEnv('VITE_USER_PERMISSIONS', 'PROCESS_READ, ,PROCESS_START')

    await expect(getUserAccess(TEST_TENANT_ID)).resolves.toEqual([
      'PROCESS_READ',
      'PROCESS_START',
    ])
    expect(dataRequestMock).not.toHaveBeenCalled()

    vi.stubEnv('VITE_USER_PERMISSIONS', '')
    dataRequestMock.mockResolvedValueOnce([])
    await getUserAccess(TEST_TENANT_ID)
    expect(dataRequestMock).toHaveBeenLastCalledWith('/user/permissions', {
      tenantId: TEST_TENANT_ID,
    })

    vi.stubEnv('VITE_PERMISSIONS_ENDPOINT', '/custom-permissions')
    await getUserAccess(TEST_TENANT_ID)
    expect(dataRequestMock).toHaveBeenLastCalledWith('/custom-permissions', {
      tenantId: TEST_TENANT_ID,
    })
  })

  it('builds process requests with the expected paths and methods', async () => {
    const process = processFixture()
    const processRequest = {
      rqUid: 'request-uid',
      processName: process.processName,
      processType: process.processType,
      description: process.description ?? undefined,
      label: process.label ?? undefined,
      routes: process.routes,
      cmd: process.cmd,
    }
    const mutation = processMutationFixture()
    dataRequestMock
      .mockResolvedValueOnce([process])
      .mockResolvedValueOnce({ processTypes: ['DB_PROCESS'] })
      .mockResolvedValueOnce(mutation)
      .mockResolvedValueOnce(mutation)
      .mockResolvedValueOnce(null)
      .mockResolvedValueOnce(null)
      .mockResolvedValueOnce({ processSessionId: TEST_SESSION_ID })
      .mockResolvedValueOnce(null)
      .mockResolvedValueOnce(null)

    await getProcesses(TEST_TENANT_ID)
    await getProcessTypes(TEST_TENANT_ID)
    await createProcess(TEST_TENANT_ID, processRequest)
    await updateProcess(TEST_TENANT_ID, TEST_PROCESS_ID, processRequest)
    await deleteProcess(TEST_TENANT_ID, TEST_PROCESS_ID)
    await deleteProcess(TEST_TENANT_ID, TEST_PROCESS_ID, 'request id')
    await startProcess(TEST_TENANT_ID, {
      rqUid: 'request-uid',
      processId: TEST_PROCESS_ID,
    })
    await stopProcess(TEST_TENANT_ID, TEST_SESSION_ID)
    await stopProcess(TEST_TENANT_ID, TEST_SESSION_ID, 'request id')

    expect(dataRequestMock.mock.calls).toEqual([
      ['/process', { tenantId: TEST_TENANT_ID }],
      ['/process/types', { tenantId: TEST_TENANT_ID }],
      ['/process', { tenantId: TEST_TENANT_ID, method: 'POST', body: processRequest }],
      [
        `/process/${TEST_PROCESS_ID}`,
        { tenantId: TEST_TENANT_ID, method: 'PUT', body: processRequest },
      ],
      [`/process/${TEST_PROCESS_ID}`, { tenantId: TEST_TENANT_ID, method: 'DELETE' }],
      [
        `/process/${TEST_PROCESS_ID}?rqUid=request%20id`,
        { tenantId: TEST_TENANT_ID, method: 'DELETE' },
      ],
      [
        '/process/start',
        {
          tenantId: TEST_TENANT_ID,
          method: 'POST',
          body: { rqUid: 'request-uid', processId: TEST_PROCESS_ID },
        },
      ],
      [`/process/stop/${TEST_SESSION_ID}`, { tenantId: TEST_TENANT_ID, method: 'POST' }],
      [
        `/process/stop/${TEST_SESSION_ID}?rqUid=request%20id`,
        { tenantId: TEST_TENANT_ID, method: 'POST' },
      ],
    ])
  })

  it('only serializes the page/size/sort params documented for these endpoints', async () => {
    // q/status/category/routeKey/pod are UI-only filter state (see the corresponding page/
    // widget model). None of them are documented for these endpoints, so the API layer must
    // not accept or forward them — only page/size/sort(/routeSessionId) may reach the backend.
    dataRequestMock.mockResolvedValue({})

    await getProcessHistory(TEST_TENANT_ID, {
      page: 2,
      size: 20,
      sort: 'start_date_time:desc',
    })
    await getProcessDetail(TEST_TENANT_ID, TEST_SESSION_ID)
    await getRouteSessions(TEST_TENANT_ID, TEST_SESSION_ID, {
      page: 0,
      size: 50,
      sort: 'startDateTime,asc',
    })
    await getThreadSessions(TEST_TENANT_ID, TEST_SESSION_ID, {
      page: 1,
      size: 25,
      sort: 'threadNumber,asc',
      routeSessionId: 'route-session-1',
    })

    expect(dataRequestMock).toHaveBeenNthCalledWith(
      1,
      '/process/history?page=2&size=20&sort=start_date_time%3Adesc',
      { tenantId: TEST_TENANT_ID },
    )
    expect(dataRequestMock).toHaveBeenNthCalledWith(
      2,
      `/process/history/${TEST_SESSION_ID}/detail`,
      { tenantId: TEST_TENANT_ID },
    )
    expect(dataRequestMock).toHaveBeenNthCalledWith(
      3,
      `/process/history/${TEST_SESSION_ID}/route-sessions?page=0&size=50&sort=startDateTime%2Casc`,
      { tenantId: TEST_TENANT_ID },
    )
    expect(dataRequestMock).toHaveBeenNthCalledWith(
      4,
      `/process/history/${TEST_SESSION_ID}/thread-sessions?page=1&size=25&sort=threadNumber%2Casc&routeSessionId=route-session-1`,
      { tenantId: TEST_TENANT_ID },
    )
  })

  it('handles schedule reads, writes and a missing schedule', async () => {
    dataRequestMock.mockResolvedValueOnce(scheduleFixture)

    await expect(getSchedule(TEST_TENANT_ID, TEST_PROCESS_ID)).resolves.toEqual(scheduleFixture)

    dataRequestMock.mockRejectedValueOnce(new ApiError('Не найдено', 404))
    await expect(getSchedule(TEST_TENANT_ID, TEST_PROCESS_ID)).resolves.toBeNull()

    const backendError = new ApiError('Backend unavailable', 503)
    dataRequestMock.mockRejectedValueOnce(backendError)
    await expect(getSchedule(TEST_TENANT_ID, TEST_PROCESS_ID)).rejects.toBe(backendError)

    dataRequestMock.mockResolvedValueOnce({ content: [] })
    // GET /process/schedule only documents page/size/sort — q/category/day are UI-only
    // filter state and must not be forwarded to the backend.
    await getSchedules(TEST_TENANT_ID, {
      page: 0,
      size: 20,
      sort: 'processName,asc',
    })
    await createSchedule(TEST_TENANT_ID, scheduleFixture)
    await updateSchedule(TEST_TENANT_ID, scheduleFixture)
    await deleteSchedule(TEST_TENANT_ID, TEST_PROCESS_ID)

    expect(dataRequestMock.mock.calls.at(-1)?.[0]).toBe(
      '/process/schedule?page=0&size=20&sort=processName%2Casc',
    )
    expect(requestMock.mock.calls).toEqual([
      [
        '/process/schedule',
        { tenantId: TEST_TENANT_ID, method: 'POST', body: scheduleFixture },
      ],
      ['/process/schedule', { tenantId: TEST_TENANT_ID, method: 'PUT', body: scheduleFixture }],
      [
        '/process/schedule',
        {
          tenantId: TEST_TENANT_ID,
          method: 'DELETE',
          body: { processId: TEST_PROCESS_ID },
        },
      ],
    ])
  })

  it('loads tenants and routes through their public API', async () => {
    dataRequestMock.mockResolvedValueOnce([]).mockResolvedValueOnce(routesFixture)

    await getTenants()
    await getAvailableRoutes(TEST_TENANT_ID)

    expect(dataRequestMock.mock.calls).toEqual([
      ['/tenants'],
      ['/routes', { tenantId: TEST_TENANT_ID }],
    ])
  })
})
