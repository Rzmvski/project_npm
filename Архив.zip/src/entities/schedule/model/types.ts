import type { Page, PaginationParams } from '@/shared/api'

export type DayOfWeek = 'MON' | 'TUE' | 'WED' | 'THU' | 'FRI' | 'SAT' | 'SUN'

export interface ScheduleDay {
  dayOfWeek: DayOfWeek
  startTime: string
  endTime: string
  intervalMin: number
}

export interface ScheduleRequest {
  processId: string
  scheduleDays: ScheduleDay[]
}

export interface ScheduleResponse extends ScheduleRequest {
  tenantId: string
}

export interface TenantScheduleInfo {
  processId: string
  processName: string
  processType: string
  description: string | null
  label: string | null
  scheduleDays: ScheduleDay[]
}

// GET /process/schedule only documents page, size, sort — q/category/day are UI-only
// filter state (see widgets/schedules-catalog/model) and must not be sent to the backend.
export type ScheduleListParams = PaginationParams

export type SchedulePage = Page<TenantScheduleInfo>
