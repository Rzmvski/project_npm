import { ApiError, apiDataRequest, apiRequest } from '@/shared/api'

import type {
  ScheduleListParams,
  SchedulePage,
  ScheduleRequest,
  ScheduleResponse,
} from '../model'

function paramsToString(params: ScheduleListParams) {
  const search = new URLSearchParams()

  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined) search.set(key, String(value))
  })

  return search.toString()
}

export async function getSchedule(
  tenantId: string,
  processId: string,
): Promise<ScheduleResponse | null> {
  try {
    return await apiDataRequest<ScheduleResponse>(`/process/schedule/${processId}`, {
      tenantId,
    })
  } catch (error) {
    if (error instanceof ApiError && error.status === 404) return null
    throw error
  }
}

export function getSchedules(tenantId: string, params: ScheduleListParams) {
  return apiDataRequest<SchedulePage>(`/process/schedule?${paramsToString(params)}`, {
    tenantId,
  })
}

export function createSchedule(tenantId: string, body: ScheduleRequest) {
  return apiRequest<void>('/process/schedule', {
    tenantId,
    method: 'POST',
    body,
  })
}

export function updateSchedule(tenantId: string, body: ScheduleRequest) {
  return apiRequest<void>('/process/schedule', {
    tenantId,
    method: 'PUT',
    body,
  })
}

export function deleteSchedule(tenantId: string, processId: string) {
  return apiRequest<void>('/process/schedule', {
    tenantId,
    method: 'DELETE',
    body: { processId },
  })
}
