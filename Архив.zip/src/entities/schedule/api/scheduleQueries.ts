import { queryOptions } from '@tanstack/react-query'

import { getSchedule, getSchedules } from './scheduleApi'

import type { ScheduleListParams } from '../model'

export const scheduleKeys = {
  all: (tenantId: string) => ['tenant', tenantId, 'schedules'] as const,
  list: (tenantId: string, params: ScheduleListParams) =>
    [...scheduleKeys.all(tenantId), 'list', params] as const,
  detail: (tenantId: string, processId: string) =>
    [...scheduleKeys.all(tenantId), 'detail', processId] as const,
}

export function schedulesQueryOptions(tenantId: string, params: ScheduleListParams) {
  return queryOptions({
    queryKey: scheduleKeys.list(tenantId, params),
    queryFn: () => getSchedules(tenantId, params),
  })
}

export function scheduleQueryOptions(tenantId: string, processId: string) {
  return queryOptions({
    queryKey: scheduleKeys.detail(tenantId, processId),
    queryFn: () => getSchedule(tenantId, processId),
    retry: false,
  })
}
