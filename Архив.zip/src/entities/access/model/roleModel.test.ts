/// <reference types="node" />

import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import process from 'node:process'

import { describe, expect, it } from 'vitest'

import { Permission } from './permissions'

const roleModel = readFileSync(resolve(process.cwd(), 'roleModel.xml'), 'utf8')
const rolePermissions = new Map(
  [...roleModel.matchAll(/<role\s+code="([^"]+)"[^>]*>([\s\S]*?)<\/role>/g)].map((role) => {
    const code = role[1] ?? ''
    const body = role[2] ?? ''
    const permissions = [...body.matchAll(/<permission-ref\s+id="([^"]+)"/g)].map(
      (permission) => permission[1] ?? '',
    )

    return [code, permissions] as [string, string[]]
  }),
)

const allPermissions = Object.values(Permission).sort()
const readPermissions = [
  Permission.TENANT_LIST,
  Permission.PROCESS_LIST,
  Permission.PROCESS_TYPES,
  Permission.PROCESS_HISTORY,
  Permission.PROCESS_HISTORY_DETAILS,
  Permission.PROCESS_HISTORY_ERROR_DETAILS,
  Permission.SCHEDULE_LIST,
  Permission.SCHEDULE_READ_PROCESS,
].sort()

describe('role model', () => {
  it('declares only the current tenant-scoped roles', () => {
    expect([...rolePermissions.keys()]).toEqual(['SUPER_ADMIN', 'ADMIN', 'USER'])
  })

  it('grants all operations to global and tenant administrators', () => {
    expect(rolePermissions.get('SUPER_ADMIN')?.sort()).toEqual(allPermissions)
    expect(rolePermissions.get('ADMIN')?.sort()).toEqual(allPermissions)
  })

  it('grants only read operations to the tenant viewer', () => {
    expect(rolePermissions.get('USER')?.sort()).toEqual(readPermissions)
  })
})
