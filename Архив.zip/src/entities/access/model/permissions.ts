export const Permission = {
  TENANT_LIST: 'tenantService_getAll',

  PROCESS_LIST: 'processService_getAll',
  PROCESS_TYPES: 'processService_getTypes',
  PROCESS_CREATE: 'processService_create',
  PROCESS_UPDATE: 'processService_update',
  PROCESS_DELETE: 'processService_delete',
  PROCESS_START: 'executeService_executeCommand',
  PROCESS_START_WITH_PARAMS: 'executeService_executeWithParams',
  PROCESS_STOP: 'executeService_stopCommand',
  PROCESS_HISTORY: 'historyService_getHistory',
  PROCESS_HISTORY_DETAILS: 'historyService_getDetailed',
  PROCESS_HISTORY_ERROR_DETAILS: 'historyService_getErrorDetails',

  SCHEDULE_LIST: 'scheduleService_getAll',
  SCHEDULE_READ_PROCESS: 'scheduleService_getByProcessId',
  SCHEDULE_CREATE: 'scheduleService_create',
  SCHEDULE_UPDATE: 'scheduleService_update',
  SCHEDULE_DELETE: 'scheduleService_delete',
} as const

export type PermissionId = (typeof Permission)[keyof typeof Permission]
