export type UserAccess = string[]
