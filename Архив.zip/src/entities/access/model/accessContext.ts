import { createContext } from 'react'

import type { AbilityId } from './abilities'

export interface AccessContextValue {
  permissions: ReadonlySet<string>
  can: (ability: AbilityId) => boolean
  canAny: (abilities: readonly AbilityId[]) => boolean
}

export const AccessContext = createContext<AccessContextValue | null>(null)
