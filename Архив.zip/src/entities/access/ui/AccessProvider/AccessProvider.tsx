import { useSuspenseQuery } from '@tanstack/react-query'
import { useCallback, useMemo, type FC, type PropsWithChildren } from 'react'

import { userAccessQueryOptions } from '../../api/accessQueries'
import { canAccess, canAccessAny } from '../../lib/canAccess'
import { AccessContext } from '../../model/accessContext'

import type { AbilityId } from '../../model/abilities'

interface AccessProviderProps extends PropsWithChildren {
  tenantId: string
}

export const AccessProvider: FC<AccessProviderProps> = ({ tenantId, children }) => {
  const { data: access } = useSuspenseQuery(userAccessQueryOptions(tenantId))
  const permissions = useMemo(() => new Set(access), [access])

  const can = useCallback(
    (ability: AbilityId) => canAccess(permissions, ability),
    [permissions],
  )

  const canAny = useCallback(
    (abilities: readonly AbilityId[]) => canAccessAny(permissions, abilities),
    [permissions],
  )

  const value = useMemo(() => ({ permissions, can, canAny }), [can, canAny, permissions])

  return <AccessContext.Provider value={value}>{children}</AccessContext.Provider>
}
