import { useCan } from '../../lib/useAccess'

import type { AbilityId } from '../../model/abilities'
import type { FC, ReactNode } from 'react'

interface CanProps {
  ability: AbilityId
  children: ReactNode
  fallback?: ReactNode
}

export const Can: FC<CanProps> = ({ ability, children, fallback = null }) =>
  useCan(ability) ? children : fallback
