import { render, screen } from '@testing-library/react'
import { beforeEach, describe, expect, it, vi } from 'vitest'

import { useCan } from '../../lib/useAccess'
import { Ability } from '../../model/abilities'

import { Can } from './Can'

vi.mock('../../lib/useAccess', () => ({
  useCan: vi.fn(),
}))

const useCanMock = vi.mocked(useCan)

describe('Can', () => {
  beforeEach(() => {
    useCanMock.mockReset()
  })

  it('renders children when the ability is allowed', () => {
    useCanMock.mockReturnValue(true)

    render(<Can ability={Ability.PROCESS_LIST}>Разрешено</Can>)

    expect(screen.getByText('Разрешено')).toBeVisible()
  })

  it('renders the fallback when the ability is denied', () => {
    useCanMock.mockReturnValue(false)

    render(
      <Can ability={Ability.PROCESS_LIST} fallback='Недоступно'>
        Разрешено
      </Can>,
    )

    expect(screen.getByText('Недоступно')).toBeVisible()
    expect(screen.queryByText('Разрешено')).not.toBeInTheDocument()
  })
})
