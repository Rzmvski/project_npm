import { queryOptions } from '@tanstack/react-query'

import { getUserAccess } from './accessApi'

export const accessKeys = {
  all: ['access'] as const,
  tenant: (tenantId: string) => [...accessKeys.all, tenantId] as const,
}

export function userAccessQueryOptions(tenantId: string) {
  return queryOptions({
    queryKey: accessKeys.tenant(tenantId),
    queryFn: () => getUserAccess(tenantId),
    staleTime: 5 * 60_000,
  })
}
