import { apiDataRequest } from '@/shared/api'

import type { UserAccess } from '../model/types'

function splitEnvironmentValue(value: string | undefined): string[] {
  return value
    ? value
        .split(',')
        .map((item) => item.trim())
        .filter(Boolean)
    : []
}

export function getUserAccess(tenantId: string): Promise<UserAccess> {
  const configuredPermissions = splitEnvironmentValue(import.meta.env.VITE_USER_PERMISSIONS)

  if (configuredPermissions.length) {
    return Promise.resolve(configuredPermissions)
  }

  const endpoint = import.meta.env.VITE_PERMISSIONS_ENDPOINT ?? '/user/permissions'

  return apiDataRequest<UserAccess>(endpoint, { tenantId })
}
