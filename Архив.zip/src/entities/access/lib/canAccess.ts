import { abilityPolicy, type AbilityId } from '../model/abilities'

export function canAccess(
  permissions: ReadonlySet<string> | readonly string[],
  ability: AbilityId,
): boolean {
  const permissionSet = permissions instanceof Set ? permissions : new Set(permissions)

  return abilityPolicy[ability].some((permission) => permissionSet.has(permission))
}

export function canAccessAny(
  permissions: ReadonlySet<string> | readonly string[],
  abilities: readonly AbilityId[],
): boolean {
  return abilities.some((ability) => canAccess(permissions, ability))
}
