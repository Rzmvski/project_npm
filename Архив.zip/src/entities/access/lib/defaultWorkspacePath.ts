import { Ability, type AbilityId } from '../model/abilities'

import { canAccess } from './canAccess'

export type WorkspacePath = '/processes' | '/history' | '/schedules' | '/forbidden'

const entries: ReadonlyArray<{ ability: AbilityId; path: WorkspacePath }> = [
  { ability: Ability.PROCESS_LIST, path: '/processes' },
  { ability: Ability.PROCESS_HISTORY, path: '/history' },
  { ability: Ability.SCHEDULE_LIST, path: '/schedules' },
]

export const getDefaultWorkspacePath = (permissions: readonly string[]): WorkspacePath => {
  return entries.find(({ ability }) => canAccess(permissions, ability))?.path ?? '/forbidden'
}
