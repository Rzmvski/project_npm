import { useContext } from 'react'

import { AccessContext } from '../model/accessContext'

import type { AbilityId } from '../model/abilities'

export const useAccess = () => {
  const value = useContext(AccessContext)

  if (!value) {
    throw new Error('useAccess must be used inside AccessProvider')
  }

  return value
}

export const useCan = (ability: AbilityId) => useAccess().can(ability)
