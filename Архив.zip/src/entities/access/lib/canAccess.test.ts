import { describe, expect, it } from 'vitest'

import { Ability, Permission } from '../model'

import { canAccess, canAccessAny } from './canAccess'

describe('access policy', () => {
  it('uses the agreed backend permission IDs', () => {
    expect(Permission).toMatchObject({
      TENANT_LIST: 'tenantService_getAll',
      PROCESS_LIST: 'processService_getAll',
      PROCESS_TYPES: 'processService_getTypes',
      PROCESS_CREATE: 'processService_create',
      PROCESS_UPDATE: 'processService_update',
      PROCESS_DELETE: 'processService_delete',
      PROCESS_START: 'executeService_executeCommand',
      PROCESS_START_WITH_PARAMS: 'executeService_executeWithParams',
      PROCESS_STOP: 'executeService_stopCommand',
      PROCESS_HISTORY: 'historyService_getHistory',
      PROCESS_HISTORY_DETAILS: 'historyService_getDetailed',
      PROCESS_HISTORY_ERROR_DETAILS: 'historyService_getErrorDetails',
      SCHEDULE_LIST: 'scheduleService_getAll',
      SCHEDULE_READ_PROCESS: 'scheduleService_getByProcessId',
      SCHEDULE_CREATE: 'scheduleService_create',
      SCHEDULE_UPDATE: 'scheduleService_update',
      SCHEDULE_DELETE: 'scheduleService_delete',
    })
  })

  it('allows a business action when one of its permissions is present', () => {
    const permissions = [Permission.SCHEDULE_CREATE]

    expect(canAccess(permissions, Ability.SCHEDULE_EDIT)).toBe(true)
  })

  it('denies a business action when required permissions are absent', () => {
    expect(canAccess([], Ability.PROCESS_START)).toBe(false)
  })

  it('keeps process CRUD permissions independent from list access', () => {
    const permissions = [Permission.PROCESS_LIST]

    expect(canAccess(permissions, Ability.PROCESS_LIST)).toBe(true)
    expect(canAccess(permissions, Ability.PROCESS_CREATE)).toBe(false)
    expect(canAccess(permissions, Ability.PROCESS_UPDATE)).toBe(false)
    expect(canAccess(permissions, Ability.PROCESS_DELETE)).toBe(false)
  })

  it('requires a separate permission for parameters and error details', () => {
    const permissions = [Permission.PROCESS_START, Permission.PROCESS_HISTORY_DETAILS]

    expect(canAccess(permissions, Ability.PROCESS_START)).toBe(true)
    expect(canAccess(permissions, Ability.PROCESS_START_WITH_PARAMS)).toBe(false)
    expect(canAccess(permissions, Ability.PROCESS_HISTORY_DETAILS)).toBe(true)
    expect(canAccess(permissions, Ability.PROCESS_HISTORY_ERROR_DETAILS)).toBe(false)
  })

  it('requires a separate permission to stop a process', () => {
    const permissions = [Permission.PROCESS_START]

    expect(canAccess(permissions, Ability.PROCESS_START)).toBe(true)
    expect(canAccess(permissions, Ability.PROCESS_STOP)).toBe(false)
    expect(canAccess([Permission.PROCESS_STOP], Ability.PROCESS_STOP)).toBe(true)
  })

  it('answers whether at least one requested action is available', () => {
    const permissions = [Permission.PROCESS_HISTORY]

    expect(canAccessAny(permissions, [Ability.PROCESS_LIST, Ability.PROCESS_HISTORY])).toBe(
      true,
    )
  })
})
