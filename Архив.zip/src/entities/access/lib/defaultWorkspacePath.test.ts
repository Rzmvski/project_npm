import { describe, expect, it } from 'vitest'

import { Permission } from '../model'

import { getDefaultWorkspacePath } from './defaultWorkspacePath'

describe('default workspace', () => {
  it.each([
    [[Permission.PROCESS_LIST], '/processes'],
    [[Permission.PROCESS_HISTORY], '/history'],
    [[Permission.SCHEDULE_LIST], '/schedules'],
    [[], '/forbidden'],
  ] as const)('selects %s as %s', (permissions, expectedPath) => {
    expect(getDefaultWorkspacePath([...permissions])).toBe(expectedPath)
  })

  it('prefers the process list when several sections are available', () => {
    expect(getDefaultWorkspacePath([Permission.SCHEDULE_LIST, Permission.PROCESS_LIST])).toBe(
      '/processes',
    )
  })
})
