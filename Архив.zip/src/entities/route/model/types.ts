export interface RouteInfo {
  routeKey: string
  isLabel: boolean
}

export interface AvailableRoutesResponse {
  tenantId: string
  routes: RouteInfo[]
}
