import { queryOptions } from '@tanstack/react-query'

import { getAvailableRoutes } from './routeApi'

export const routeKeys = {
  list: (tenantId: string) => ['tenant', tenantId, 'routes'] as const,
}

export function routeListQueryOptions(tenantId: string) {
  return queryOptions({
    queryKey: routeKeys.list(tenantId),
    queryFn: () => getAvailableRoutes(tenantId),
    staleTime: 60_000,
  })
}
