import { apiDataRequest } from '@/shared/api'

import type { AvailableRoutesResponse } from '../model'

export function getAvailableRoutes(tenantId: string) {
  return apiDataRequest<AvailableRoutesResponse>('/routes', { tenantId })
}
