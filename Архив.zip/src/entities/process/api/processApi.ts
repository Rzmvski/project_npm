import { apiDataRequest } from '@/shared/api'

import type {
  CreateProcessRequest,
  ProcessMutationResponse,
  ProcessSummary,
  ProcessTypesResponse,
  StartProcessRequest,
  StartProcessResponse,
  UpdateProcessRequest,
} from '../model'

export function getProcesses(tenantId: string) {
  return apiDataRequest<ProcessSummary[]>('/process', { tenantId })
}

export function getProcessTypes(tenantId: string) {
  return apiDataRequest<ProcessTypesResponse>('/process/types', { tenantId })
}

export function createProcess(tenantId: string, body: CreateProcessRequest) {
  return apiDataRequest<ProcessMutationResponse>('/process', {
    tenantId,
    method: 'POST',
    body,
  })
}

export function updateProcess(tenantId: string, processId: string, body: UpdateProcessRequest) {
  return apiDataRequest<ProcessMutationResponse>(`/process/${processId}`, {
    tenantId,
    method: 'PUT',
    body,
  })
}

export function deleteProcess(tenantId: string, processId: string, rqUid?: string) {
  const search = rqUid ? `?rqUid=${encodeURIComponent(rqUid)}` : ''
  return apiDataRequest<null>(`/process/${processId}${search}`, {
    tenantId,
    method: 'DELETE',
  })
}

export function startProcess(tenantId: string, body: StartProcessRequest) {
  return apiDataRequest<StartProcessResponse>('/process/start', {
    tenantId,
    method: 'POST',
    body,
  })
}

export function stopProcess(tenantId: string, sessionId: string, rqUid?: string) {
  const search = rqUid ? `?rqUid=${encodeURIComponent(rqUid)}` : ''
  return apiDataRequest<null>(`/process/stop/${sessionId}${search}`, {
    tenantId,
    method: 'POST',
  })
}
