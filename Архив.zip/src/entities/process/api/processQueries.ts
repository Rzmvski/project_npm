import { queryOptions } from '@tanstack/react-query'

import { getProcesses, getProcessTypes } from './processApi'

export const processKeys = {
  all: (tenantId: string) => ['tenant', tenantId, 'processes'] as const,
  list: (tenantId: string) => [...processKeys.all(tenantId), 'list'] as const,
  types: (tenantId: string) => [...processKeys.all(tenantId), 'types'] as const,
}

export function processListQueryOptions(tenantId: string) {
  return queryOptions({
    queryKey: processKeys.list(tenantId),
    queryFn: () => getProcesses(tenantId),
  })
}

export function processTypesQueryOptions(tenantId: string) {
  return queryOptions({
    queryKey: processKeys.types(tenantId),
    queryFn: () => getProcessTypes(tenantId),
    select: (response) =>
      [...response.processTypes].sort((left, right) => left.localeCompare(right, 'ru')),
  })
}
