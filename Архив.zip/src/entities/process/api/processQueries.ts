import { queryOptions } from '@tanstack/react-query'

import { getProcesses, getProcessTypes } from './processApi'

import type { ProcessListParams } from '../model'

const defaultProcessListParams = {
  page: 0,
  size: 20,
  sort: 'asc:processName',
} satisfies ProcessListParams

export const processKeys = {
  all: (tenantId: string) => ['tenant', tenantId, 'processes'] as const,
  list: (tenantId: string, params: ProcessListParams = defaultProcessListParams) =>
    [...processKeys.all(tenantId), 'list', params] as const,
  types: (tenantId: string) => [...processKeys.all(tenantId), 'types'] as const,
}

export function processListQueryOptions(
  tenantId: string,
  params: ProcessListParams = defaultProcessListParams,
) {
  return queryOptions({
    queryKey: processKeys.list(tenantId, params),
    queryFn: () => getProcesses(tenantId, params),
  })
}

export function processTypesQueryOptions(tenantId: string) {
  return queryOptions({
    queryKey: processKeys.types(tenantId),
    queryFn: () => getProcessTypes(tenantId),
    select: (response) =>
      [...response.processTypes].sort((left, right) => left.localeCompare(right, 'ru')),
  })
}
