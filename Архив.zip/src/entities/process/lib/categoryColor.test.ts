import { describe, expect, it } from 'vitest'

import { getProcessCategoryColor } from './categoryColor'

describe('getProcessCategoryColor', () => {
  it('assigns a stable distinct color to the standard process categories', () => {
    const categories = ['Закрытие дня', 'Архивирование', 'Сверка', 'Экспорт', 'Отчётность']

    const colors = categories.map(getProcessCategoryColor)

    expect(new Set(colors)).toHaveLength(categories.length)
    expect(categories.map(getProcessCategoryColor)).toEqual(colors)
  })
})
