import { describe, expect, it } from 'vitest'

import { getDbRouteTargets, getDbSetTargets, getTargetNames } from './processTargets'

const targets = [
  { routeKey: 'db-main.users', isLabel: false },
  { routeKey: 'Основные витрины', isLabel: true },
]

describe('process targets', () => {
  it('separates concrete database routes from DB sets', () => {
    expect(getDbRouteTargets(targets)).toEqual([targets[0]])
    expect(getDbSetTargets(targets)).toEqual([targets[1]])
  })

  it('returns user-facing target names in their original order', () => {
    expect(getTargetNames(targets)).toEqual(['db-main.users', 'Основные витрины'])
  })
})
