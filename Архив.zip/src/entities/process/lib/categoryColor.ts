import type { TTagColor } from '@v-uik/base'

const categoryColors: TTagColor[] = [
  'blue',
  'violet',
  'green',
  'yellow',
  'azure',
  'red',
  'gray',
]

export const getProcessCategoryColor = (category: string): TTagColor => {
  const hash = [...category].reduce(
    (value, character) => (Math.imul(value, 23) + character.codePointAt(0)!) >>> 0,
    0,
  )

  return categoryColors[hash % categoryColors.length] ?? 'gray'
}
