import type { RouteTarget } from '../model'

export function getDbRouteTargets(targets: RouteTarget[]): RouteTarget[] {
  return targets.filter((target) => !target.isLabel)
}

export function getDbSetTargets(targets: RouteTarget[]): RouteTarget[] {
  return targets.filter((target) => target.isLabel)
}

export function getTargetNames(targets: RouteTarget[]): string[] {
  return targets.map((target) => target.routeKey)
}
