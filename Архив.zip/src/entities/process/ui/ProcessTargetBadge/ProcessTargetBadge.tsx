import { Tag } from '@v-uik/base'
import { Database, Tag as LabelIcon } from 'lucide-react'

import styles from './ProcessTargetBadge.module.scss'

import type { RouteTarget } from '../../model'
import type { FC } from 'react'

interface ProcessTargetBadgeProps {
  target: Pick<RouteTarget, 'routeKey' | 'isLabel'>
}

export const ProcessTargetBadge: FC<ProcessTargetBadgeProps> = ({ target }) => {
  const { isLabel, routeKey } = target
  const Icon = isLabel ? LabelIcon : Database
  const typeLabel = isLabel ? 'DB set' : 'База данных'

  return (
    <Tag
      kind='lite'
      title={`${typeLabel}: ${routeKey}`}
      aria-label={`${typeLabel}: ${routeKey}`}
    >
      <span className={styles.content}>
        <Icon size={13} aria-hidden='true' />
        <span>{routeKey}</span>
      </span>
    </Tag>
  )
}
