import { Tag } from '@v-uik/base'

import styles from './ProcessCategoryTag.module.scss'

import type { FC } from 'react'

interface ProcessCategoryTagProps {
  category: string
}

export const ProcessCategoryTag: FC<ProcessCategoryTagProps> = ({ category }) => (
  <Tag kind='secondary'>
    <span className={styles.content}>{category}</span>
  </Tag>
)
