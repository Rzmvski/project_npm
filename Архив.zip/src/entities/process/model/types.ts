export interface RouteTarget {
  routeKey: string
  isLabel: boolean
}

export interface ProcessSummary {
  id: string
  processName: string
  processType: string
  description: string | null
  label: string | null
  routes: RouteTarget[]
  cmd: string
}

export interface CreateProcessRequest {
  rqUid: string
  processName: string
  processType: string
  description?: string
  label?: string
  routes: RouteTarget[]
  cmd: string
}

export interface UpdateProcessRequest {
  rqUid: string
  processName: string
  processType: string
  description?: string
  label?: string
  routes: RouteTarget[]
  cmd: string
}

export interface ProcessMutationResponse {
  processId: string
  processName: string
  processType: string
  description: string | null
  label: string | null
}

export interface ProcessTypesResponse {
  processTypes: string[]
}

export interface StartProcessRequest {
  rqUid: string
  processId: string
  additionalParams?: Record<string, string>
  login?: string
  startDate?: string
}

export interface StartProcessResponse {
  processSessionId: string
}
