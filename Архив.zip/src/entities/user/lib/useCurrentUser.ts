import { useSuspenseQuery } from '@tanstack/react-query'

import { userQueryOptions } from '../api'

export function useCurrentUser() {
  return useSuspenseQuery(userQueryOptions()).data
}
