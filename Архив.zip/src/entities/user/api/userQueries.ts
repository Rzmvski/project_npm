import { queryOptions } from '@tanstack/react-query'

import { getCurrentUser } from './userApi'

export const userKeys = {
  all: ['user'] as const,
  current: () => [...userKeys.all, 'current'] as const,
}

export function userQueryOptions() {
  return queryOptions({
    queryKey: userKeys.current(),
    queryFn: getCurrentUser,
    staleTime: 5 * 60_000,
  })
}
