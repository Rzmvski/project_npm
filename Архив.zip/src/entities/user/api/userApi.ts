import { apiDataRequest } from '@/shared/api'

import type { UserProfile } from '../model'

export function getCurrentUser(): Promise<UserProfile> {
  const endpoint = import.meta.env.VITE_USER_ENDPOINT ?? '/user'
  return apiDataRequest<UserProfile>(endpoint)
}
