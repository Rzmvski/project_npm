export interface UserProfile {
  login: string
  displayName: string
  roles: string[]
}
