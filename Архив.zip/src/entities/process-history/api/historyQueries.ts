import { queryOptions } from '@tanstack/react-query'

import {
  getProcessDetail,
  getProcessHistory,
  getRouteSessions,
  getThreadSessions,
} from './historyApi'

import type { HistoryParams, RouteSessionsParams, ThreadSessionsParams } from '../model'

export const historyKeys = {
  all: (tenantId: string) => ['tenant', tenantId, 'history'] as const,
  list: (tenantId: string, params: HistoryParams) =>
    [...historyKeys.all(tenantId), 'list', params] as const,
  detail: (tenantId: string, id: string) =>
    [...historyKeys.all(tenantId), 'detail', id] as const,
  routes: (tenantId: string, id: string, params: RouteSessionsParams) =>
    [...historyKeys.all(tenantId), 'routes', id, params] as const,
  threads: (tenantId: string, id: string, params: ThreadSessionsParams) =>
    [...historyKeys.all(tenantId), 'threads', id, params] as const,
}

export function processHistoryQueryOptions(tenantId: string, params: HistoryParams) {
  return queryOptions({
    queryKey: historyKeys.list(tenantId, params),
    queryFn: () => getProcessHistory(tenantId, params),
  })
}

export function processDetailQueryOptions(tenantId: string, id: string) {
  return queryOptions({
    queryKey: historyKeys.detail(tenantId, id),
    queryFn: () => getProcessDetail(tenantId, id),
  })
}

export function routeSessionsQueryOptions(
  tenantId: string,
  id: string,
  params: RouteSessionsParams,
) {
  return queryOptions({
    queryKey: historyKeys.routes(tenantId, id, params),
    queryFn: () => getRouteSessions(tenantId, id, params),
  })
}

export function threadSessionsQueryOptions(
  tenantId: string,
  id: string,
  params: ThreadSessionsParams,
) {
  return queryOptions({
    queryKey: historyKeys.threads(tenantId, id, params),
    queryFn: () => getThreadSessions(tenantId, id, params),
  })
}
