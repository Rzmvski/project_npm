import { apiDataRequest } from '@/shared/api'

import type {
  HistoryParams,
  ProcessDetail,
  ProcessHistoryPage,
  RouteSessionsPage,
  RouteSessionsParams,
  ThreadSessionsPage,
  ThreadSessionsParams,
} from '../model'

function paramsToString<T extends object>(params: T) {
  const search = new URLSearchParams()

  Object.entries(params as Record<string, string | number | undefined>).forEach(
    ([key, value]) => {
      if (value !== undefined) search.set(key, String(value))
    },
  )

  return search.toString()
}

export function getProcessHistory(tenantId: string, params: HistoryParams) {
  return apiDataRequest<ProcessHistoryPage>(`/process/history?${paramsToString(params)}`, {
    tenantId,
  })
}

export function getProcessDetail(tenantId: string, sessionProcessId: string) {
  return apiDataRequest<ProcessDetail>(`/process/history/${sessionProcessId}/detail`, {
    tenantId,
  })
}

export function getRouteSessions(
  tenantId: string,
  processSessionId: string,
  params: RouteSessionsParams,
) {
  return apiDataRequest<RouteSessionsPage>(
    `/process/history/${processSessionId}/route-sessions?${paramsToString(params)}`,
    { tenantId },
  )
}

export function getThreadSessions(
  tenantId: string,
  processSessionId: string,
  params: ThreadSessionsParams,
) {
  return apiDataRequest<ThreadSessionsPage>(
    `/process/history/${processSessionId}/thread-sessions?${paramsToString(params)}`,
    { tenantId },
  )
}
