import { apiDataRequest, withQueryParams } from '@/shared/api'

import type {
  HistoryParams,
  ProcessDetail,
  ProcessHistoryPage,
  RouteSessionsPage,
  RouteSessionsParams,
  ThreadSessionsPage,
  ThreadSessionsParams,
} from '../model'

export function getProcessHistory(tenantId: string, params: HistoryParams) {
  return apiDataRequest<ProcessHistoryPage>(withQueryParams('/process/history', params), {
    tenantId,
  })
}

export function getProcessDetail(tenantId: string, sessionProcessId: string) {
  return apiDataRequest<ProcessDetail>(`/process/history/${sessionProcessId}/detail`, {
    tenantId,
  })
}

export function getRouteSessions(
  tenantId: string,
  processSessionId: string,
  params: RouteSessionsParams,
) {
  return apiDataRequest<RouteSessionsPage>(
    withQueryParams(`/process/history/${processSessionId}/route-sessions`, params),
    { tenantId },
  )
}

export function getThreadSessions(
  tenantId: string,
  processSessionId: string,
  params: ThreadSessionsParams,
) {
  return apiDataRequest<ThreadSessionsPage>(
    withQueryParams(`/process/history/${processSessionId}/thread-sessions`, params),
    { tenantId },
  )
}
