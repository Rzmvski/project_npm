import { Tag } from '@v-uik/base'
import { Ban, CheckCircle2, CircleDot, CircleX, LoaderCircle, OctagonX } from 'lucide-react'

import styles from './ProcessStatusBadge.module.scss'

import type { ProcessStatusCode } from '../../model'
import type { FC } from 'react'

const colors: Record<ProcessStatusCode, 'gray' | 'blue' | 'green' | 'yellow' | 'red'> = {
  CREATED: 'gray',
  WORKS: 'blue',
  SUCCESS: 'green',
  ERROR: 'red',
  CANCELED: 'yellow',
  STOPPED: 'yellow',
}

const icons: Record<ProcessStatusCode, typeof CircleDot> = {
  CREATED: CircleDot,
  WORKS: LoaderCircle,
  SUCCESS: CheckCircle2,
  ERROR: CircleX,
  CANCELED: Ban,
  STOPPED: OctagonX,
}

interface ProcessStatusBadgeProps {
  code?: ProcessStatusCode | null
  name?: string | null
}

export const ProcessStatusBadge: FC<ProcessStatusBadgeProps> = ({ code, name }) => {
  if (!code) {
    return (
      <Tag kind='color' color='gray'>
        <span className={styles.content}>
          <CircleDot size={14} aria-hidden />
          <span>Нет запусков</span>
        </span>
      </Tag>
    )
  }

  const StatusIcon = icons[code]

  return (
    <Tag kind='color' color={colors[code]}>
      <span className={styles.content}>
        <StatusIcon size={14} aria-hidden />
        <span>{name ?? code}</span>
      </span>
    </Tag>
  )
}
