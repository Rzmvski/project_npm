import type { Page } from '@/shared/api'

export type ProcessStatusCode =
  'CREATED' | 'WORKS' | 'SUCCESS' | 'ERROR' | 'CANCELED' | 'STOPPED'

export interface ProcessHistoryItem {
  processId: string
  processName: string
  processType: string
  description: string | null
  label: string | null
  isDeleted: boolean
  startDate: string | null
  statusCode: ProcessStatusCode | null
  statusName: string | null
  startDateTime: string | null
  endDateTime: string | null
  sessionProcessId: string | null
}

export interface ProcessSessionMonitoring {
  processSessionId: string
  statusCode: ProcessStatusCode
  statusName: string
  startDateTime: string
  endDateTime: string | null
  recordsToProcess: number
  totalRecords: number
  successfulRecords: number
  failedRecords: number
  additionalParams: string | null
}

export interface ProcessDetail {
  processId: string
  processName: string
  processType: string
  description: string | null
  label: string | null
  isDeleted: boolean
  startDate: string | null
  processSession: ProcessSessionMonitoring
}

export interface RouteSessionMonitoring {
  routeSessionId: string
  routeKey: string
  statusCode: ProcessStatusCode
  statusName: string
  startDateTime: string
  endDateTime: string | null
  recordsToProcess: number
  totalRecords: number
  successfulRecords: number
  failedRecords: number
  errorDescription: string | null
}

export interface ThreadSessionMonitoring {
  threadSessionId: string
  routeSessionId: string | null
  routeKey?: string | null
  threadNumber: number
  maxThreads: number
  statusCode: ProcessStatusCode
  statusName: string
  startDateTime: string
  endDateTime: string | null
  recordsToProcess: number
  totalRecords: number
  successfulRecords: number
  failedRecords: number
  podName: string | null
  errorDescription: string | null
}

// GET /process/history only documents page, size, sort, rqUid — q/status/category/from/to
// are UI-only filter state (see pages/history/model) and must not be sent to the backend.
export interface HistoryParams {
  page: number
  size: number
  sort: string
}

// GET /process/history/{id}/route-sessions only documents page, size, sort, rqUid.
export interface RouteSessionsParams {
  page: number
  size: number
  sort: string
}

// GET /process/history/{id}/thread-sessions only documents routeSessionId, page, size, sort, rqUid —
// routeKey/pod/status are UI-only filter state and must not be sent to the backend.
export interface ThreadSessionsParams {
  page: number
  size: number
  sort: string
  routeSessionId?: string
}

export type ProcessHistoryPage = Page<ProcessHistoryItem>
export type RouteSessionsPage = Page<RouteSessionMonitoring>
export type ThreadSessionsPage = Page<ThreadSessionMonitoring>
