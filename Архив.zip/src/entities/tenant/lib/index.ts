export { useRequiredTenantId, useSelectedTenantId } from './useTenantId'
