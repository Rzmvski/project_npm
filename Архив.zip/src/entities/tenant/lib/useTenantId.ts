import { useSyncExternalStore } from 'react'

import { getSelectedTenantId, subscribe } from '../model/tenantStore'

export const useSelectedTenantId = () =>
  useSyncExternalStore(subscribe, getSelectedTenantId, () => null)

export const useRequiredTenantId = () => {
  const tenantId = useSelectedTenantId()

  if (!tenantId) throw new Error('Tenant is not selected')

  return tenantId
}
