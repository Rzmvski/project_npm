import { queryOptions } from '@tanstack/react-query'

import { getTenants } from './tenantApi'

export const tenantKeys = {
  all: ['tenants'] as const,
}

export function tenantListQueryOptions() {
  return queryOptions({
    queryKey: tenantKeys.all,
    queryFn: getTenants,
    staleTime: 5 * 60_000,
  })
}
