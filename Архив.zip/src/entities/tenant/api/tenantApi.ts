import { apiDataRequest } from '@/shared/api'

import type { Tenant } from '../model'

export function getTenants() {
  return apiDataRequest<Tenant[]>('/tenants')
}
