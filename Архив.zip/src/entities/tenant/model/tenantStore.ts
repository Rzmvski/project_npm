const KEY = 'ppm.selectedTenantId'
const listeners = new Set<() => void>()

function subscribe(listener: () => void) {
  listeners.add(listener)
  return () => listeners.delete(listener)
}

function emit() {
  listeners.forEach((listener) => listener())
}

export function getSelectedTenantId(): string | null {
  return localStorage.getItem(KEY)
}

export function setSelectedTenantId(value: string | null) {
  if (value) localStorage.setItem(KEY, value)
  else localStorage.removeItem(KEY)
  emit()
}

export { subscribe }
