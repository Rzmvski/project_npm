export interface Tenant {
  id: string
  code: string
}
