import { useMutation, useQueryClient } from '@tanstack/react-query'
import { Button, notification } from '@v-uik/base'
import { Square } from 'lucide-react'

import { Ability, useCan } from '@/entities/access'
import { stopProcess } from '@/entities/process'
import { historyKeys } from '@/entities/process-history'
import { useRequiredTenantId } from '@/entities/tenant'
import { createRequestUid } from '@/shared/lib'

import type { FC } from 'react'

interface StopProcessButtonProps {
  sessionId: string
  compact?: boolean
}

export const StopProcessButton: FC<StopProcessButtonProps> = ({
  sessionId,
  compact = false,
}) => {
  const tenantId = useRequiredTenantId()
  const allowed = useCan(Ability.PROCESS_STOP)
  const queryClient = useQueryClient()

  const mutation = useMutation({
    mutationFn: () => stopProcess(tenantId, sessionId, createRequestUid()),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: historyKeys.all(tenantId) })
      notification.success('Процесс остановлен')
    },
    onError: (error) => notification.error(error.message),
  })

  if (!allowed) return null

  return (
    <Button
      color='error'
      size='sm'
      prefixIcon={compact ? <Square size={15} /> : undefined}
      aria-label={compact ? 'Остановить' : undefined}
      title={compact ? 'Остановить' : undefined}
      onClick={() => mutation.mutate()}
      disabled={mutation.isPending}
    >
      {compact ? null : (
        <>
          <Square size={15} />
          {mutation.isPending ? 'Останавливаем…' : 'Остановить'}
        </>
      )}
    </Button>
  )
}
