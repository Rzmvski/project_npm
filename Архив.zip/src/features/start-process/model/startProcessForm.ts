import { z } from 'zod'

const paramSchema = z.object({
  key: z.string().trim().min(1, 'Укажите ключ'),
  value: z.string(),
})

export const startProcessFormSchema = z
  .object({
    startDate: z.date({
      required_error: 'Укажите дату запуска',
      invalid_type_error: 'Укажите дату запуска',
    }),
    params: z.array(paramSchema),
  })
  .superRefine((values, context) => {
    const keys = new Set<string>()
    values.params.forEach((param, index) => {
      const normalized = param.key.trim().toLocaleLowerCase('ru-RU')
      if (keys.has(normalized)) {
        context.addIssue({
          code: z.ZodIssueCode.custom,
          path: ['params', index, 'key'],
          message: 'Такой ключ уже добавлен',
        })
      }
      keys.add(normalized)
    })
  })

export type StartProcessFormValues = z.infer<typeof startProcessFormSchema>

export function createDefaultStartProcessFormValues(): StartProcessFormValues {
  return {
    startDate: new Date(),
    params: [],
  }
}

export function formatLocalDate(date: Date): string {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
}
