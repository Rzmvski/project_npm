import { describe, expect, it } from 'vitest'

import { formatLocalDate, startProcessFormSchema } from './startProcessForm'

describe('start process form domain model', () => {
  it('rejects duplicate parameter keys regardless of casing', () => {
    const result = startProcessFormSchema.safeParse({
      startDate: new Date(2026, 7, 6),
      params: [
        { key: 'Batch', value: '1' },
        { key: 'batch', value: '2' },
      ],
    })

    expect(result.success).toBe(false)
    if (!result.success) {
      expect(result.error.issues[0]).toMatchObject({
        path: ['params', 1, 'key'],
        message: 'Такой ключ уже добавлен',
      })
    }
  })

  it('serializes a calendar date without timezone conversion', () => {
    expect(formatLocalDate(new Date(2026, 7, 6))).toBe('2026-08-06')
  })
})
