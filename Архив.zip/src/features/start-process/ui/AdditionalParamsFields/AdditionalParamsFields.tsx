import { Button } from '@v-uik/base'
import { Braces, Plus, Trash2 } from 'lucide-react'
import { useFieldArray, type Control } from 'react-hook-form'

import { FormInput } from '@/shared/ui'

import styles from './AdditionalParamsFields.module.scss'

import type { StartProcessFormValues } from '../../model'
import type { FC } from 'react'

interface AdditionalParamsFieldsProps {
  control: Control<StartProcessFormValues>
}

export const AdditionalParamsFields: FC<AdditionalParamsFieldsProps> = ({ control }) => {
  const { fields, append, remove } = useFieldArray({
    control,
    name: 'params',
  })

  return (
    <section className={styles.params}>
      <div className={styles.header}>
        <span className={styles.icon}>
          <Braces size={18} aria-hidden />
        </span>
        <div className={styles.heading}>
          <strong>Дополнительные параметры</strong>
          <span>Необязательные значения в формате «ключ — значение».</span>
        </div>
        <Button
          type='button'
          kind='outlined'
          color='secondary'
          size='sm'
          prefixIcon={<Plus size={15} />}
          onClick={() => append({ key: '', value: '' })}
        >
          Добавить
        </Button>
      </div>

      {fields.length ? (
        <div className={styles.list}>
          <div className={styles.columnLabels} aria-hidden>
            <span>Ключ</span>
            <span>Значение</span>
          </div>
          {fields.map((field, index) => (
            <div className={styles.param} key={field.id}>
              <FormInput
                name={`params.${index}.key` as const}
                control={control}
                placeholder='Ключ'
                fullWidth
                inputProps={{ 'aria-label': 'Ключ параметра' }}
              />
              <FormInput
                name={`params.${index}.value` as const}
                control={control}
                placeholder='Значение'
                fullWidth
                inputProps={{ 'aria-label': 'Значение параметра' }}
              />
              <Button
                type='button'
                kind='ghost'
                color='error'
                size='sm'
                prefixIcon={<Trash2 size={16} />}
                classes={{ button: styles.removeButton }}
                aria-label='Удалить параметр'
                onClick={() => remove(index)}
              />
            </div>
          ))}
        </div>
      ) : (
        <p className={styles.empty}>Параметры не добавлены.</p>
      )}
    </section>
  )
}
