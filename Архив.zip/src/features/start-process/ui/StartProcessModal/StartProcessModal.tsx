import { zodResolver } from '@hookform/resolvers/zod'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import {
  Button,
  DatePicker,
  ModalBody,
  ModalFooter,
  ModalHeader,
  Tag,
  notification,
} from '@v-uik/base'
import { CalendarDays, Database, Play, X } from 'lucide-react'
import { Controller, useForm } from 'react-hook-form'

import { startProcess } from '@/entities/process'
import { historyKeys } from '@/entities/process-history'
import { useRequiredTenantId } from '@/entities/tenant'
import { createRequestUid } from '@/shared/lib'

import {
  createDefaultStartProcessFormValues,
  formatLocalDate,
  startProcessFormSchema,
  type StartProcessFormValues,
} from '../../model'
import { AdditionalParamsFields } from '../AdditionalParamsFields'

import styles from './StartProcessModal.module.scss'

import type { FC } from 'react'

interface StartProcessModalProps {
  processId: string
  processName: string
  routes: string[]
  login: string
  canUseAdditionalParams: boolean
  onClose: () => void
}

export const StartProcessModal: FC<StartProcessModalProps> = ({
  processId,
  processName,
  routes,
  login,
  canUseAdditionalParams,
  onClose,
}) => {
  const tenantId = useRequiredTenantId()
  const queryClient = useQueryClient()
  const {
    control,
    handleSubmit,
    formState: { isValid },
  } = useForm<StartProcessFormValues>({
    resolver: zodResolver(startProcessFormSchema),
    defaultValues: createDefaultStartProcessFormValues(),
    mode: 'onChange',
  })

  const mutation = useMutation({
    mutationFn: (values: StartProcessFormValues) =>
      startProcess(tenantId, {
        rqUid: createRequestUid(),
        processId,
        login,
        startDate: formatLocalDate(values.startDate),
        additionalParams: Object.fromEntries(
          values.params.map(({ key, value }) => [key.trim(), value]),
        ),
      }),
    onSuccess: async ({ processSessionId }) => {
      await queryClient.invalidateQueries({
        queryKey: historyKeys.all(tenantId),
      })
      notification.success(`Процесс запущен. Сессия: ${processSessionId.slice(0, 8)}…`)
      onClose()
    },
    onError: (error: unknown) =>
      notification.error(
        error instanceof Error ? error.message : 'Не удалось запустить процесс',
      ),
  })

  return (
    <form
      className={styles.form}
      noValidate
      onSubmit={handleSubmit((values) => mutation.mutate(values))}
    >
      <ModalHeader
        closeButtonProps={{
          'aria-label': 'Закрыть',
          className: styles.closeButton,
        }}
      >
        Запуск процесса
      </ModalHeader>
      <ModalBody className={styles.modalBody}>
        <div className={styles.content}>
          <div className={styles.process}>
            <span>Процесс</span>
            <strong>{processName}</strong>
          </div>

          <section className={styles.section} aria-labelledby='start-settings-title'>
            <div className={styles.sectionHeader}>
              <span className={styles.sectionIcon}>
                <CalendarDays size={18} aria-hidden />
              </span>
              <div>
                <h3 id='start-settings-title'>Основные параметры</h3>
                <p>Дата, за которую процесс должен обработать данные.</p>
              </div>
            </div>

            <div className={styles.dateField}>
              <Controller
                name='startDate'
                control={control}
                render={({ field, fieldState }) => (
                  <DatePicker<Date>
                    label='Дата запуска'
                    value={field.value}
                    onChange={field.onChange}
                    format='dd.MM.yyyy'
                    mask='11.11.1111'
                    error={Boolean(fieldState.error)}
                    helperText={fieldState.error?.message}
                    inputProps={{
                      fullWidth: true,
                      placeholder: 'дд.мм.гггг',
                      suffix: <CalendarDays size={18} aria-hidden />,
                      inputProps: {
                        name: field.name,
                        onBlur: field.onBlur,
                        'aria-label': 'Дата запуска',
                      },
                    }}
                  />
                )}
              />
            </div>
          </section>

          <section className={styles.section} aria-label='Область выполнения'>
            <div className={styles.sectionHeader}>
              <span className={styles.sectionIcon}>
                <Database size={18} aria-hidden />
              </span>
              <div>
                <div className={styles.titleWithCounter}>
                  <h3>Область выполнения</h3>
                  <span>{routes.length}</span>
                </div>
                <p>Базы данных и DB sets, выбранные в настройках процесса.</p>
              </div>
            </div>
            {routes.length ? (
              <div className={styles.targetList}>
                {routes.map((route) => (
                  <Tag key={route} kind='lite'>
                    {route}
                  </Tag>
                ))}
              </div>
            ) : (
              <span className={styles.emptyTargets}>Не указаны</span>
            )}
          </section>

          {canUseAdditionalParams ? <AdditionalParamsFields control={control} /> : null}
        </div>
      </ModalBody>
      <ModalFooter>
        <Button
          type='button'
          kind='outlined'
          color='secondary'
          prefixIcon={<X size={16} />}
          disabled={mutation.isPending}
          onClick={onClose}
        >
          Отмена
        </Button>
        <Button
          type='submit'
          prefixIcon={<Play size={16} />}
          disabled={!isValid || mutation.isPending}
        >
          {mutation.isPending ? 'Запускаем…' : 'Запустить'}
        </Button>
      </ModalFooter>
    </form>
  )
}
