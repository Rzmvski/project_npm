import { fireEvent, screen } from '@testing-library/react'
import { expect } from 'vitest'

import { Permission } from '@/entities/access'
import { processFixture, renderApp, userAccessFixture } from '@/test'

import type { UserEvent } from '@testing-library/user-event'

export class StartProcessTestModel {
  private constructor(readonly user: UserEvent) {}

  static async open(
    permissions: string[] = [
      Permission.PROCESS_LIST,
      Permission.PROCESS_START,
      Permission.PROCESS_START_WITH_PARAMS,
    ],
  ) {
    const app = await renderApp({
      route: '/processes',
      access: userAccessFixture(permissions),
      processes: [processFixture()],
    })

    await screen.findByRole('heading', { name: 'Процессы' })
    return new StartProcessTestModel(app.user)
  }

  async openDialog() {
    await this.user.click(
      screen.getByRole('button', {
        name: 'Запустить процесс Дневная загрузка данных',
      }),
    )
    await screen.findByRole('dialog')
  }

  setDate(value: string) {
    fireEvent.change(screen.getByLabelText('Дата запуска'), {
      target: { value },
    })
  }

  async addParameter(key: string, value: string) {
    await this.user.click(screen.getByRole('button', { name: 'Добавить' }))
    await this.user.type(screen.getByRole('textbox', { name: 'Ключ параметра' }), key)
    await this.user.type(screen.getByRole('textbox', { name: 'Значение параметра' }), value)
  }

  async submit() {
    await this.user.click(screen.getByRole('button', { name: 'Запустить' }))
  }

  async closeDialog() {
    await this.user.click(screen.getByRole('button', { name: 'Отмена' }))
  }

  expectNoParameters() {
    expect(screen.queryByRole('textbox', { name: 'Ключ параметра' })).not.toBeInTheDocument()
  }

  expectAdditionalParamsUnavailable() {
    expect(screen.queryByRole('button', { name: 'Добавить' })).not.toBeInTheDocument()
    expect(screen.queryByText('Дополнительные параметры')).not.toBeInTheDocument()
  }
}
