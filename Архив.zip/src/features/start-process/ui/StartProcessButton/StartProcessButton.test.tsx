import { waitFor } from '@testing-library/react'
import { describe, expect, it, vi } from 'vitest'

import { Permission } from '@/entities/access'
import * as processApi from '@/entities/process'
import { TEST_PROCESS_ID, TEST_TENANT_ID } from '@/test'

import { StartProcessTestModel } from './StartProcessButton.test-model'

describe('start process', () => {
  it('starts the selected process with the current date and additional parameters', async () => {
    const startProcess = vi.spyOn(processApi, 'startProcess').mockResolvedValue({
      processSessionId: 'session-12345678',
    })
    const dialog = await StartProcessTestModel.open()

    await dialog.openDialog()
    dialog.setDate('2026-08-07')
    await dialog.addParameter('batch', 'nightly')
    await dialog.submit()

    await waitFor(() =>
      expect(startProcess).toHaveBeenCalledWith(TEST_TENANT_ID, {
        rqUid: expect.any(String),
        processId: TEST_PROCESS_ID,
        login: 'tester@example.com',
        startDate: '2026-08-07',
        additionalParams: { batch: 'nightly' },
      }),
    )
  })

  it('clears an unfinished draft after the modal is closed', async () => {
    const dialog = await StartProcessTestModel.open()

    await dialog.openDialog()
    await dialog.addParameter('batch', 'nightly')
    await dialog.closeDialog()
    await dialog.openDialog()

    dialog.expectNoParameters()
    await dialog.closeDialog()
  })

  it('allows a regular start but hides additional parameters without their permission', async () => {
    const dialog = await StartProcessTestModel.open([
      Permission.PROCESS_LIST,
      Permission.PROCESS_START,
    ])

    await dialog.openDialog()
    dialog.expectAdditionalParamsUnavailable()
    await dialog.closeDialog()
  })
})
