import { Button } from '@v-uik/base'
import { Play } from 'lucide-react'

import { Ability, useAccess } from '@/entities/access'
import { useCurrentUser } from '@/entities/user'
import { useModal } from '@/shared/lib'

import { StartProcessModal } from '../StartProcessModal'

import type { FC } from 'react'

interface StartProcessButtonProps {
  processId: string
  processName: string
  routes: string[]
  compact?: boolean
}

export const StartProcessButton: FC<StartProcessButtonProps> = ({
  processId,
  processName,
  routes,
  compact = false,
}) => {
  const { can } = useAccess()
  const user = useCurrentUser()
  const allowed = can(Ability.PROCESS_START)
  const canUseAdditionalParams = can(Ability.PROCESS_START_WITH_PARAMS)
  const showModal = useModal()

  if (!allowed) return null

  const open = () =>
    showModal({
      name: 'start-process',
      width: 680,
      render: (close) => (
        <StartProcessModal
          processId={processId}
          processName={processName}
          routes={routes}
          login={user.login}
          canUseAdditionalParams={canUseAdditionalParams}
          onClose={close}
        />
      ),
    })

  return (
    <Button
      type='button'
      kind={compact ? 'ghost' : undefined}
      size={compact ? 'sm' : undefined}
      prefixIcon={<Play size={17} />}
      aria-label={compact ? `Запустить процесс ${processName}` : undefined}
      title={compact ? 'Запустить' : undefined}
      onClick={open}
    >
      {compact ? null : 'Запустить'}
    </Button>
  )
}
