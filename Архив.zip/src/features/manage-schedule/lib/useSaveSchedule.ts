import { useMutation, useQueryClient } from '@tanstack/react-query'

import {
  createSchedule,
  scheduleKeys,
  updateSchedule,
  type ScheduleRequest,
} from '@/entities/schedule'
import { useRequiredTenantId } from '@/entities/tenant'

export function useSaveSchedule(exists: boolean) {
  const tenantId = useRequiredTenantId()
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (body: ScheduleRequest) =>
      exists ? updateSchedule(tenantId, body) : createSchedule(tenantId, body),
    onSuccess: () =>
      queryClient.invalidateQueries({
        queryKey: scheduleKeys.all(tenantId),
      }),
  })
}
