import { modal } from '@v-uik/base'
import { useCallback } from 'react'

import { CreateScheduleModal } from '../ui/CreateScheduleModal'

import type { ScheduleProcessOption } from '../model'

let modalSequence = 0

export const useCreateScheduleModal = () =>
  useCallback(
    (processOptions: ScheduleProcessOption[]) =>
      new Promise<string | undefined>((resolve) => {
        const modalId = `create-schedule-modal-${modalSequence++}`
        let settled = false

        const finish = (processId?: string) => {
          if (settled) return
          settled = true
          modal.close(modalId)
          resolve(processId)
        }

        modal.show(modalId, {
          width: 520,
          onClose: () => finish(),
          content: (
            <CreateScheduleModal
              processOptions={processOptions}
              onCancel={() => finish()}
              onSubmit={finish}
            />
          ),
        } as unknown as Parameters<typeof modal.show>[1])
      }),
    [],
  )
