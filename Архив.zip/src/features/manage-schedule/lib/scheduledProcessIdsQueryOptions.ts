import { queryOptions } from '@tanstack/react-query'

import { getSchedules, scheduleKeys } from '@/entities/schedule'

const PAGE_SIZE = 100

const getScheduledProcessIds = async (tenantId: string) => {
  const processIds: string[] = []
  let page = 0
  let totalPages = 1

  while (page < totalPages) {
    const response = await getSchedules(tenantId, {
      page,
      size: PAGE_SIZE,
      sort: 'processName,asc',
    })

    const { content, totalPages: responseTotalPages } = response
    processIds.push(...content.map(({ processId }) => processId))
    totalPages = responseTotalPages
    page += 1
  }

  return processIds
}

export const scheduledProcessIdsQueryOptions = (tenantId: string) =>
  queryOptions({
    queryKey: [...scheduleKeys.all(tenantId), 'scheduled-process-ids'],
    queryFn: () => getScheduledProcessIds(tenantId),
  })
