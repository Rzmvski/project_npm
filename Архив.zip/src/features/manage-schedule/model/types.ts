import type { ComboBoxOption } from '@/shared/lib'

export type ScheduleProcessOption = ComboBoxOption
