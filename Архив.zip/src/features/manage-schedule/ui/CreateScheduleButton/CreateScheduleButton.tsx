import { useQuery } from '@tanstack/react-query'
import { useNavigate } from '@tanstack/react-router'
import { Button } from '@v-uik/base'
import { CalendarPlus } from 'lucide-react'
import { useMemo, type FC } from 'react'

import { Ability, useCan } from '@/entities/access'
import { processListQueryOptions } from '@/entities/process'
import { useRequiredTenantId } from '@/entities/tenant'

import { scheduledProcessIdsQueryOptions } from '../../lib/scheduledProcessIdsQueryOptions'
import { useCreateScheduleModal } from '../../lib/useCreateScheduleModal'

export const CreateScheduleButton: FC = () => {
  const tenantId = useRequiredTenantId()
  const allowed = useCan(Ability.SCHEDULE_CREATE)
  const navigate = useNavigate({ from: '/schedules' })
  const selectProcess = useCreateScheduleModal()
  const processesQuery = useQuery({
    ...processListQueryOptions(tenantId),
    enabled: allowed,
  })
  const scheduledProcessIdsQuery = useQuery({
    ...scheduledProcessIdsQueryOptions(tenantId),
    enabled: allowed,
  })

  const processOptions = useMemo(() => {
    const scheduledProcessIds = new Set(scheduledProcessIdsQuery.data ?? [])

    return (processesQuery.data ?? [])
      .filter(({ id }) => !scheduledProcessIds.has(id))
      .map(({ id, processName }) => ({
        value: id,
        label: processName,
      }))
      .sort((left, right) => left.label.localeCompare(right.label, 'ru'))
  }, [processesQuery.data, scheduledProcessIdsQuery.data])

  if (!allowed) return null

  const isPending = processesQuery.isPending || scheduledProcessIdsQuery.isPending
  const isError = processesQuery.isError || scheduledProcessIdsQuery.isError
  const isDisabled = isPending || isError || processOptions.length === 0
  const title = isError
    ? 'Не удалось загрузить процессы'
    : processOptions.length === 0 && !isPending
      ? 'Для всех процессов уже настроено расписание'
      : 'Создать расписание для процесса'

  const createSchedule = async () => {
    const processId = await selectProcess(processOptions)
    if (!processId) return

    await navigate({
      to: '/schedules/$processId/edit',
      params: { processId },
    })
  }

  return (
    <Button
      type='button'
      prefixIcon={<CalendarPlus size={17} />}
      disabled={isDisabled}
      title={title}
      onClick={() => void createSchedule()}
    >
      Создать расписание
    </Button>
  )
}
