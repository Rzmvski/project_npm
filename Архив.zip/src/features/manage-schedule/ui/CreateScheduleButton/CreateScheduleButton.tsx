import { useQuery } from '@tanstack/react-query'
import { useNavigate } from '@tanstack/react-router'
import { Button, notification } from '@v-uik/base'
import { CalendarPlus } from 'lucide-react'
import { type FC } from 'react'

import { Ability, useCan } from '@/entities/access'
import { processListQueryOptions } from '@/entities/process'
import { useRequiredTenantId } from '@/entities/tenant'

import { scheduledProcessIdsQueryOptions } from '../../lib/scheduledProcessIdsQueryOptions'
import { useCreateScheduleModal } from '../../lib/useCreateScheduleModal'

export const CreateScheduleButton: FC = () => {
  const tenantId = useRequiredTenantId()
  const allowed = useCan(Ability.SCHEDULE_CREATE)
  const navigate = useNavigate({ from: '/schedules' })
  const selectProcess = useCreateScheduleModal()
  const processesQuery = useQuery({
    ...processListQueryOptions(tenantId),
    enabled: allowed,
  })
  const scheduledProcessIdsQuery = useQuery({
    ...scheduledProcessIdsQueryOptions(tenantId),
    enabled: false,
  })

  const getProcessOptions = (scheduledIds: string[]) => {
    const scheduledProcessIds = new Set(scheduledIds)

    return (processesQuery.data?.content ?? [])
      .filter(({ id }) => !scheduledProcessIds.has(id))
      .map(({ id, processName }) => ({
        value: id,
        label: processName,
      }))
      .sort((left, right) => left.label.localeCompare(right.label, 'ru'))
  }

  if (!allowed) return null

  const isPending = processesQuery.isPending || scheduledProcessIdsQuery.isFetching
  const { isError } = processesQuery
  const hasProcesses = Boolean(processesQuery.data?.content.length)
  const isDisabled = isPending || isError || !hasProcesses
  const title = isError ? 'Не удалось загрузить процессы' : 'Создать расписание для процесса'

  const createSchedule = async () => {
    const { data: cachedIds } = scheduledProcessIdsQuery
    const scheduledIds =
      cachedIds && !scheduledProcessIdsQuery.isStale
        ? cachedIds
        : (await scheduledProcessIdsQuery.refetch()).data

    if (!scheduledIds) {
      notification.error('Не удалось загрузить список расписаний')
      return
    }

    const processOptions = getProcessOptions(scheduledIds)
    if (processOptions.length === 0) {
      notification.error('Для всех доступных процессов уже настроено расписание')
      return
    }

    const processId = await selectProcess(processOptions)
    if (!processId) return

    await navigate({
      to: '/schedules/$processId/edit',
      params: { processId },
    })
  }

  return (
    <Button
      type='button'
      prefixIcon={<CalendarPlus size={17} />}
      disabled={isDisabled}
      title={title}
      onClick={() => void createSchedule()}
    >
      Создать расписание
    </Button>
  )
}
