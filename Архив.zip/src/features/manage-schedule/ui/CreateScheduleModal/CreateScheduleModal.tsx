import { Button, ComboBox, ModalBody, ModalFooter, ModalHeader } from '@v-uik/base'
import { CalendarPlus, X } from 'lucide-react'
import { Controller, useForm } from 'react-hook-form'

import { findComboBoxOption, getComboBoxValue } from '@/shared/lib'

import styles from './CreateScheduleModal.module.scss'

import type { ScheduleProcessOption } from '../../model'
import type { FC } from 'react'

interface CreateScheduleModalProps {
  processOptions: ScheduleProcessOption[]
  onCancel: () => void
  onSubmit: (processId: string) => void
}

interface FormValues {
  processId: string
}

export const CreateScheduleModal: FC<CreateScheduleModalProps> = ({
  processOptions,
  onCancel,
  onSubmit,
}) => {
  const {
    control,
    handleSubmit,
    formState: { isValid },
  } = useForm<FormValues>({
    defaultValues: { processId: '' },
    mode: 'onChange',
  })

  return (
    <form onSubmit={handleSubmit(({ processId }) => onSubmit(processId))}>
      <ModalHeader
        subtitle='Выберите процесс, для которого расписание ещё не настроено.'
        closeButtonProps={{ 'aria-label': 'Закрыть' }}
      >
        Создание расписания
      </ModalHeader>
      <ModalBody>
        <div className={styles.field}>
          <Controller
            name='processId'
            control={control}
            rules={{ required: 'Выберите процесс' }}
            render={({ field, fieldState }) => (
              <ComboBox<ScheduleProcessOption>
                openOnFocus
                isSearchable
                clearInputOnBlur
                label='Процесс'
                placeholder='Найдите процесс'
                noOptionsText='Доступные процессы не найдены'
                options={processOptions}
                value={findComboBoxOption(field.value, processOptions)}
                error={Boolean(fieldState.error)}
                helperText={fieldState.error?.message}
                inputProps={{ name: field.name }}
                controlInnerProps={{ onBlur: field.onBlur }}
                onChange={(_value, _event, fullValue) =>
                  field.onChange(getComboBoxValue(fullValue))
                }
              />
            )}
          />
        </div>
      </ModalBody>
      <ModalFooter>
        <Button
          type='button'
          kind='outlined'
          color='secondary'
          prefixIcon={<X size={16} />}
          onClick={onCancel}
        >
          Отмена
        </Button>
        <Button type='submit' prefixIcon={<CalendarPlus size={16} />} disabled={!isValid}>
          Продолжить
        </Button>
      </ModalFooter>
    </form>
  )
}
