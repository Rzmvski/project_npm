import { useMutation, useQueryClient } from '@tanstack/react-query'
import { Button, notification } from '@v-uik/base'
import { Trash2 } from 'lucide-react'

import { Ability, useCan } from '@/entities/access'
import { deleteSchedule, scheduleKeys } from '@/entities/schedule'
import { useRequiredTenantId } from '@/entities/tenant'
import { useConfirmModal } from '@/shared/lib'

import type { FC } from 'react'

interface DeleteScheduleButtonProps {
  processId: string
  processName?: string
  onDeleted?: () => void
  compact?: boolean
}

export const DeleteScheduleButton: FC<DeleteScheduleButtonProps> = ({
  processId,
  processName,
  onDeleted,
  compact = false,
}) => {
  const tenantId = useRequiredTenantId()
  const allowed = useCan(Ability.SCHEDULE_DELETE)
  const queryClient = useQueryClient()
  const confirm = useConfirmModal()

  const mutation = useMutation({
    mutationFn: () => deleteSchedule(tenantId, processId),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: scheduleKeys.all(tenantId) })
      notification.success('Расписание удалено')
      onDeleted?.()
    },
    onError: (error) => notification.error(error.message),
  })

  if (!allowed) return null

  const requestDelete = async () => {
    const confirmed = await confirm({
      title: processName ? `Удалить расписание «${processName}»?` : 'Удалить расписание?',
      description: 'Все запланированные задачи этого процесса будут отменены.',
      confirmLabel: 'Удалить',
      danger: true,
    })

    if (confirmed) mutation.mutate()
  }

  return (
    <Button
      type='button'
      kind={compact ? 'ghost' : 'outlined'}
      color='error'
      size={compact ? 'sm' : undefined}
      prefixIcon={<Trash2 size={compact ? 17 : 16} />}
      aria-label={
        compact ? `Удалить расписание${processName ? ` ${processName}` : ''}` : undefined
      }
      title={compact ? 'Удалить расписание' : undefined}
      disabled={mutation.isPending}
      onClick={() => void requestDelete()}
    >
      {compact ? null : 'Удалить расписание'}
    </Button>
  )
}
