import { useQueryClient } from '@tanstack/react-query'
import { useNavigate } from '@tanstack/react-router'
import { BarSelect } from '@v-uik/base'
import { ShieldCheck } from 'lucide-react'

import { getDefaultWorkspacePath, userAccessQueryOptions } from '@/entities/access'
import { useRequiredTenantId } from '@/entities/tenant'
import { useCurrentUser } from '@/entities/user'
import { getDevMockRoles, setDevMockRoles, useDevMockRoles } from '@/shared/lib'

import { DEFAULT_ROLE, formatRoles, ROLE_OPTIONS } from '../../model'

import styles from './RoleSwitcher.module.scss'

import type { FC } from 'react'

/**
 * Displays the user's current role. In dev builds it also lets a developer
 * pick which roleModel.xml role the Express mock server should resolve
 * permissions for, without restarting either local server.
 */
export const RoleSwitcher: FC = () => {
  const user = useCurrentUser()

  if (!import.meta.env.DEV) {
    return (
      <section className={styles.role} aria-label='Роль пользователя'>
        <span className={styles.value} title={formatRoles(user.roles)}>
          <ShieldCheck size={13} aria-hidden />
          <span>{formatRoles(user.roles)}</span>
        </span>
      </section>
    )
  }

  return <RoleSwitcherContent roles={user.roles} />
}

const RoleSwitcherContent: FC<{ roles: string[] }> = ({ roles }) => {
  const tenantId = useRequiredTenantId()
  const queryClient = useQueryClient()
  const navigate = useNavigate()
  const storedRoles = useDevMockRoles()
  const hasStaticOverride = Boolean(import.meta.env.VITE_USER_PERMISSIONS)

  const changeRole = async (nextValue: string) => {
    const nextRoles = nextValue || null
    if (nextRoles === getDevMockRoles()) return

    setDevMockRoles(nextRoles)
    await queryClient.invalidateQueries()
    const access = await queryClient.fetchQuery(userAccessQueryOptions(tenantId))
    await navigate({ to: getDefaultWorkspacePath(access), replace: true })
  }

  return (
    <section className={styles.role} aria-label='Роль пользователя'>
      <BarSelect
        value={storedRoles ?? roles[0] ?? DEFAULT_ROLE}
        options={ROLE_OPTIONS}
        onChange={(value) => void changeRole(value)}
        selectProps={{
          'aria-label': 'Роль пользователя. Выбрать другую',
          disabled: hasStaticOverride,
          title: hasStaticOverride
            ? 'VITE_USER_PERMISSIONS задан в .env — переключатель роли не влияет на права'
            : undefined,
          size: 'sm',
          classes: {
            button: styles.selectButton,
          },
        }}
      />
    </section>
  )
}
