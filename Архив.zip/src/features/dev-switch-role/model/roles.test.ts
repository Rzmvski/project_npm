/// <reference types="node" />

import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import process from 'node:process'

import { describe, expect, it } from 'vitest'

import { formatRoles, ROLE_OPTIONS } from './roles'

const roleModel = readFileSync(resolve(process.cwd(), 'roleModel.xml'), 'utf8')
const roleModelCodes = [...roleModel.matchAll(/<role\s+code="([^"]+)"/g)].map(
  (match) => match[1],
)

describe('formatRoles', () => {
  it('formats known user roles for display', () => {
    expect(formatRoles(['ADMIN', 'USER'])).toBe('Администратор, Пользователь')
  })

  it('keeps an unknown role code visible', () => {
    expect(formatRoles(['CUSTOM_ROLE'])).toBe('CUSTOM_ROLE')
  })

  it('shows when the user has no roles', () => {
    expect(formatRoles([])).toBe('Без ролей')
  })

  it('keeps dev options synchronized with roleModel.xml', () => {
    const optionCodes = ROLE_OPTIONS.filter(({ value }) => value !== 'NONE').map(
      ({ value }) => value,
    )

    expect(optionCodes).toEqual(roleModelCodes)
  })
})
