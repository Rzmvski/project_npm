// Mirrors the role codes declared in roleModel.xml. Keep in sync if the XML
// gains or renames roles — there is no separate permissions service yet to
// read this list from at runtime.
export const ROLE_OPTIONS = [
  { value: 'SUPER_ADMIN', label: 'Суперадминистратор' },
  { value: 'ADMIN', label: 'Администратор' },
  { value: 'USER', label: 'Пользователь' },
  { value: 'NONE', label: 'Без ролей (нет прав)' },
]

export const DEFAULT_ROLE = 'SUPER_ADMIN'

export const formatRoles = (roles: string[]) => {
  if (!roles.length) return 'Без ролей'

  return roles
    .map((role) => ROLE_OPTIONS.find((option) => option.value === role)?.label ?? role)
    .join(', ')
}
