import { screen, waitFor, within } from '@testing-library/react'
import { describe, expect, it, vi } from 'vitest'

import { Permission } from '@/entities/access'
import * as processApi from '@/entities/process'
import {
  pageFixture,
  processFixture,
  renderApp,
  TEST_PROCESS_ID,
  TEST_TENANT_ID,
  userAccessFixture,
} from '@/test'

describe('delete process', () => {
  it('asks for confirmation before deleting a process', async () => {
    vi.spyOn(processApi, 'getProcesses').mockResolvedValue(pageFixture([]))
    const deleteProcess = vi.spyOn(processApi, 'deleteProcess').mockResolvedValue(null)
    const { user } = await renderApp({
      route: '/processes',
      access: userAccessFixture([Permission.PROCESS_LIST, Permission.PROCESS_DELETE]),
      processes: [processFixture()],
    })
    const row = await screen.findByRole('row', {
      name: /Дневная загрузка данных/i,
    })

    await user.click(
      within(row).getByRole('button', {
        name: 'Удалить процесс Дневная загрузка данных',
      }),
    )

    const dialog = await screen.findByRole('dialog')
    expect(
      within(dialog).getByRole('heading', {
        name: 'Удалить «Дневная загрузка данных»?',
      }),
    ).toBeVisible()
    expect(deleteProcess).not.toHaveBeenCalled()

    await user.click(within(dialog).getByRole('button', { name: 'Удалить' }))

    await waitFor(() =>
      expect(deleteProcess).toHaveBeenCalledWith(
        TEST_TENANT_ID,
        TEST_PROCESS_ID,
        expect.any(String),
      ),
    )
  })
})
