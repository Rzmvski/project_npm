import { Button } from '@v-uik/base'
import { Trash2 } from 'lucide-react'

import { Ability, useCan } from '@/entities/access'

import { useDeleteProcess } from '../../lib'

import type { FC } from 'react'

interface DeleteProcessButtonProps {
  processId: string
  processName: string
  onDeleted?: () => void
  compact?: boolean
}

export const DeleteProcessButton: FC<DeleteProcessButtonProps> = ({
  processId,
  processName,
  onDeleted,
  compact = false,
}) => {
  const allowed = useCan(Ability.PROCESS_DELETE)
  const { isPending, requestDelete } = useDeleteProcess({
    processId,
    processName,
    onDeleted,
  })

  if (!allowed) return null

  return (
    <Button
      type='button'
      kind={compact ? 'ghost' : 'outlined'}
      color='error'
      size={compact ? 'sm' : undefined}
      prefixIcon={<Trash2 size={17} />}
      aria-label={compact ? `Удалить процесс ${processName}` : undefined}
      title={compact ? 'Удалить' : undefined}
      disabled={isPending}
      onClick={() => void requestDelete()}
    >
      {compact ? null : 'Удалить процесс'}
    </Button>
  )
}
