import { useMutation, useQueryClient } from '@tanstack/react-query'
import { notification } from '@v-uik/base'

import { deleteProcess, processKeys } from '@/entities/process'
import { useRequiredTenantId } from '@/entities/tenant'
import { createRequestUid, useConfirmModal } from '@/shared/lib'

interface Options {
  processId: string
  processName: string
  onDeleted?: () => void
}

export const useDeleteProcess = ({ processId, processName, onDeleted }: Options) => {
  const tenantId = useRequiredTenantId()
  const queryClient = useQueryClient()
  const confirm = useConfirmModal()

  const mutation = useMutation({
    mutationFn: () => deleteProcess(tenantId, processId, createRequestUid()),
    onSuccess: async () => {
      await queryClient.invalidateQueries({
        queryKey: processKeys.all(tenantId),
      })
      notification.success('Процесс удалён')
      onDeleted?.()
    },
    onError: (error: unknown) =>
      notification.error(error instanceof Error ? error.message : 'Не удалось удалить процесс'),
  })

  const requestDelete = async () => {
    const confirmed = await confirm({
      title: `Удалить «${processName}»?`,
      description: 'Процесс будет помечен как удалённый и останется доступен в истории.',
      confirmLabel: 'Удалить',
      danger: true,
    })

    if (confirmed) mutation.mutate()
  }

  return {
    isPending: mutation.isPending,
    requestDelete,
  }
}
