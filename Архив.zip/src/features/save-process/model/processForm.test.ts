import { describe, expect, it } from 'vitest'

import { processFixture } from '@/test'

import {
  createProcessFormSchema,
  formValuesToTargets,
  processSummaryToFormValues,
} from './processForm'

describe('process form domain model', () => {
  it('requires a name, system type, command and at least one target', () => {
    const result = createProcessFormSchema('create').safeParse({
      processName: '',
      processType: '',
      category: '',
      description: '',
      cmd: '',
      dbRoutes: [],
      dbSets: [],
    })

    expect(result.success).toBe(false)
    if (!result.success) {
      expect(result.error.flatten().fieldErrors).toMatchObject({
        processName: ['Укажите название процесса'],
        processType: ['Выберите тип процесса'],
        cmd: ['Укажите команду процесса'],
        dbRoutes: ['Выберите хотя бы один DB route или DB set'],
      })
    }
  })

  it('prefills edit values from the process returned by backend', () => {
    expect(processSummaryToFormValues(processFixture())).toEqual({
      processName: 'Дневная загрузка данных',
      processType: 'DB_PROCESS',
      category: 'Загрузка данных',
      description: 'Загружает данные из источников в витрины.',
      cmd: 'python /opt/etl/daily_load.py --date today',
      dbRoutes: ['db-main.users'],
      dbSets: ['Основные витрины'],
    })
  })

  it('converts independently selected routes and DB sets to API targets', () => {
    expect(
      formValuesToTargets({
        processName: 'Process',
        processType: 'DB_PROCESS',
        category: '',
        description: '',
        cmd: 'run',
        dbRoutes: ['db-main.users', 'db-main.orders'],
        dbSets: ['Основные витрины'],
      }),
    ).toEqual([
      { routeKey: 'db-main.users', isLabel: false },
      { routeKey: 'db-main.orders', isLabel: false },
      { routeKey: 'Основные витрины', isLabel: true },
    ])
  })
})
