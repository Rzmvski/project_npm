import { z } from 'zod'

import {
  getDbRouteTargets,
  getDbSetTargets,
  type ProcessSummary,
  type RouteTarget,
} from '@/entities/process'

export type ProcessFormMode = 'create' | 'edit'

const processFormSchema = z
  .object({
    processName: z
      .string()
      .trim()
      .min(1, 'Укажите название процесса')
      .max(200, 'Название не должно превышать 200 символов'),
    processType: z
      .string()
      .trim()
      .min(1, 'Выберите тип процесса')
      .max(100, 'Тип не должен превышать 100 символов'),
    category: z.string().trim().max(200, 'Категория не должна превышать 200 символов'),
    description: z.string().trim().max(2_000, 'Описание не должно превышать 2000 символов'),
    cmd: z
      .string()
      .trim()
      .min(1, 'Укажите команду процесса')
      .max(100_000, 'Команда не должна превышать 100 000 символов'),
    dbRoutes: z.array(z.string()),
    dbSets: z.array(z.string()),
  })
  .superRefine((values, context) => {
    if (values.dbRoutes.length === 0 && values.dbSets.length === 0) {
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['dbRoutes'],
        message: 'Выберите хотя бы один DB route или DB set',
      })
    }
  })

export function createProcessFormSchema(_mode: ProcessFormMode) {
  return processFormSchema
}

export type ProcessFormValues = z.infer<typeof processFormSchema>

export interface SelectOption {
  value: string
  label: string
}

export function createDefaultProcessFormValues(_mode: ProcessFormMode): ProcessFormValues {
  return {
    processName: '',
    processType: '',
    category: '',
    description: '',
    cmd: '',
    dbRoutes: [],
    dbSets: [],
  }
}

export function processSummaryToFormValues(process: ProcessSummary): ProcessFormValues {
  return {
    processName: process.processName,
    processType: process.processType,
    category: process.label ?? '',
    description: process.description ?? '',
    cmd: process.cmd ?? '',
    dbRoutes: getDbRouteTargets(process.routes).map((route) => route.routeKey),
    dbSets: getDbSetTargets(process.routes).map((route) => route.routeKey),
  }
}

export function formValuesToTargets(values: ProcessFormValues): RouteTarget[] {
  return [
    ...values.dbRoutes.map((routeKey) => ({
      routeKey,
      isLabel: false,
    })),
    ...values.dbSets.map((routeKey) => ({
      routeKey,
      isLabel: true,
    })),
  ]
}

export function getSelectedOptions(
  selectedValues: string[],
  options: SelectOption[],
): SelectOption[] {
  const selected = new Set(selectedValues)
  return options.filter((option) => selected.has(option.value))
}
