import { zodResolver } from '@hookform/resolvers/zod'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Link, useNavigate } from '@tanstack/react-router'
import { notification } from '@v-uik/base'
import { Workflow } from 'lucide-react'
import { useEffect, useMemo, type FC } from 'react'
import { useForm, useWatch } from 'react-hook-form'

import {
  createProcess,
  processKeys,
  processListQueryOptions,
  processTypesQueryOptions,
  updateProcess,
  type CreateProcessRequest,
  type UpdateProcessRequest,
} from '@/entities/process'
import { routeListQueryOptions } from '@/entities/route'
import { useRequiredTenantId } from '@/entities/tenant'
import { createRequestUid } from '@/shared/lib'
import {
  ErrorState,
  FormHeroActions,
  FormPageLayout,
  LoadingState,
  PageBreadcrumbs,
} from '@/shared/ui'

import {
  createDefaultProcessFormValues,
  createProcessFormSchema,
  formValuesToTargets,
  processSummaryToFormValues,
  type ProcessFormMode,
  type ProcessFormValues,
  type SelectOption,
} from '../../model'
import { ProcessCommandField } from '../ProcessCommandField'
import { ProcessMainFields } from '../ProcessMainFields'
import { ProcessTargetsField } from '../ProcessTargetsField'

interface SaveProcessFormProps {
  mode: ProcessFormMode
  processId?: string
}

function getErrorMessage(error: unknown): string {
  return error instanceof Error ? error.message : 'Не удалось сохранить процесс'
}

export const SaveProcessForm: FC<SaveProcessFormProps> = ({ mode, processId }) => {
  const tenantId = useRequiredTenantId()
  const navigate = useNavigate()
  const queryClient = useQueryClient()

  const processesQuery = useQuery(processListQueryOptions(tenantId))
  const processTypesQuery = useQuery(processTypesQueryOptions(tenantId))
  const routesQuery = useQuery(routeListQueryOptions(tenantId))

  const currentProcess = useMemo(
    () => processesQuery.data?.content.find((process) => process.id === processId),
    [processId, processesQuery.data],
  )

  const schema = useMemo(() => createProcessFormSchema(mode), [mode])

  const {
    control,
    handleSubmit,
    reset,
    formState: { isDirty, isValid },
  } = useForm<ProcessFormValues>({
    resolver: zodResolver(schema),
    defaultValues: createDefaultProcessFormValues(mode),
    mode: 'onChange',
    reValidateMode: 'onChange',
  })

  const processName = useWatch({ control, name: 'processName' })

  useEffect(() => {
    if (mode === 'edit' && currentProcess) {
      reset(processSummaryToFormValues(currentProcess))
    }
  }, [currentProcess, mode, reset])

  const categoryOptions = useMemo(
    () =>
      Array.from(
        new Set(
          (processesQuery.data?.content ?? [])
            .map((process) => process.label?.trim())
            .filter((label): label is string => Boolean(label)),
        ),
      ).sort((left, right) => left.localeCompare(right, 'ru')),
    [processesQuery.data],
  )

  const processTypes = useMemo(
    () => [...(processTypesQuery.data ?? [])],
    [processTypesQuery.data],
  )

  const { dbRouteOptions, dbSetOptions } = useMemo(() => {
    const routes = routesQuery.data?.routes ?? []
    const toOption = (routeKey: string): SelectOption => ({
      value: routeKey,
      label: routeKey,
    })

    return {
      dbRouteOptions: routes
        .filter((route) => !route.isLabel)
        .map((route) => toOption(route.routeKey))
        .sort((left, right) => left.label.localeCompare(right.label, 'ru')),
      dbSetOptions: routes
        .filter((route) => route.isLabel)
        .map((route) => toOption(route.routeKey))
        .sort((left, right) => left.label.localeCompare(right.label, 'ru')),
    }
  }, [routesQuery.data])

  const mutation = useMutation({
    mutationFn: async (formValues: ProcessFormValues) => {
      const commonRequest = {
        rqUid: createRequestUid(),
        processName: formValues.processName.trim(),
        processType: formValues.processType.trim(),
        description: formValues.description.trim() || undefined,
        label: formValues.category.trim() || undefined,
        routes: formValuesToTargets(formValues),
        cmd: formValues.cmd.trim(),
      }

      if (mode === 'create') {
        return createProcess(tenantId, commonRequest satisfies CreateProcessRequest)
      }

      if (!processId) throw new Error('Не указан идентификатор процесса')

      return updateProcess(tenantId, processId, commonRequest satisfies UpdateProcessRequest)
    },
    onSuccess: async (result) => {
      await queryClient.invalidateQueries({
        queryKey: processKeys.all(tenantId),
      })
      notification.success(mode === 'create' ? 'Процесс создан' : 'Процесс обновлён')
      await navigate({
        to: '/processes/$processId',
        params: { processId: result.processId },
      })
    },
    onError: (error: unknown) => notification.error(getErrorMessage(error)),
  })

  const cancel = () => {
    if (isDirty && !window.confirm('Несохранённые изменения будут потеряны. Продолжить?')) {
      return
    }

    if (mode === 'edit' && processId) {
      void navigate({
        to: '/processes/$processId',
        params: { processId },
      })
      return
    }

    void navigate({ to: '/processes' })
  }

  const isLoading =
    processesQuery.isPending || processTypesQuery.isPending || routesQuery.isPending

  if (isLoading) return <LoadingState label='Загружаем форму…' />
  if (processesQuery.isError || processTypesQuery.isError || routesQuery.isError) {
    return <ErrorState title='Не удалось загрузить данные формы' />
  }
  if (mode === 'edit' && !currentProcess) {
    return <ErrorState title='Процесс не найден' />
  }

  const pageTitle = mode === 'create' ? 'Создание процесса' : 'Редактирование процесса'
  const heroTitle = processName.trim() || currentProcess?.processName || 'Новый процесс'
  const isSaveDisabled = !isDirty || !isValid || mutation.isPending
  const targetsField = (
    <ProcessTargetsField
      control={control}
      dbRouteOptions={dbRouteOptions}
      dbSetOptions={dbSetOptions}
      compact
    />
  )

  return (
    <FormPageLayout
      breadcrumbs={
        <PageBreadcrumbs>
          <Link to='/processes'>Процессы</Link>
          {mode === 'edit' && processId ? (
            <Link to='/processes/$processId' params={{ processId }}>
              {currentProcess?.processName ?? 'Процесс'}
            </Link>
          ) : null}
          <span aria-current='page'>{pageTitle}</span>
        </PageBreadcrumbs>
      }
      icon={<Workflow size={24} />}
      eyebrow={mode === 'create' ? 'Новый процесс' : 'Настройка процесса'}
      title={heroTitle}
      description={
        mode === 'create'
          ? 'Настройте системный тип, пользовательскую категорию, команду и область выполнения.'
          : 'Измените параметры, команду запуска и область выполнения процесса.'
      }
      aside={targetsField}
      heroActions={
        <FormHeroActions
          cancelDisabled={mutation.isPending}
          submitDisabled={isSaveDisabled}
          pending={mutation.isPending}
          submitLabel={mode === 'create' ? 'Создать процесс' : 'Сохранить изменения'}
          onCancel={cancel}
        />
      }
      noValidate
      onSubmit={handleSubmit((formValues) => mutation.mutate(formValues))}
    >
      <ProcessMainFields
        control={control}
        processTypes={processTypes}
        categories={categoryOptions}
        compact
      />
      <ProcessCommandField control={control} compact />
    </FormPageLayout>
  )
}
