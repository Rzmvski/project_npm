import { FormCodeEditor, FormSection } from '@/shared/ui'

import type { ProcessFormValues } from '../../model'
import type { FC } from 'react'
import type { Control } from 'react-hook-form'

interface ProcessCommandFieldProps {
  control: Control<ProcessFormValues>
  compact?: boolean
}

export const ProcessCommandField: FC<ProcessCommandFieldProps> = ({
  control,
  compact = false,
}) => (
  <FormSection
    title='Команда запуска'
    description='Команда, которая будет выполнена при старте процесса.'
  >
    <FormCodeEditor
      name='cmd'
      control={control}
      label='Команда'
      required
      height={compact ? 220 : 420}
      helperText='Введите полную команду выполнения процесса'
    />
  </FormSection>
)
