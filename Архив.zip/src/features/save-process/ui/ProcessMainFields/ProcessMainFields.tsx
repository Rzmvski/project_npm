import { Creatable, InlineNotification, Select } from '@v-uik/base'
import clsx from 'clsx'
import { Controller, type Control } from 'react-hook-form'

import { FormInput, FormSection, FormTextarea } from '@/shared/ui'

import styles from './ProcessMainFields.module.scss'

import type { ProcessFormValues, SelectOption } from '../../model'
import type { FC } from 'react'

interface ProcessMainFieldsProps {
  control: Control<ProcessFormValues>
  processTypes: string[]
  categories: string[]
  compact?: boolean
}

export const ProcessMainFields: FC<ProcessMainFieldsProps> = ({
  control,
  processTypes,
  categories,
  compact = false,
}) => {
  const typeOptions = processTypes.map((type) => ({
    value: type,
    label: type,
  }))
  const categoryOptions: SelectOption[] = categories.map((category) => ({
    value: category,
    label: category,
  }))

  return (
    <FormSection
      title='Основная информация'
      description='Название, системный тип и пользовательская категория процесса.'
    >
      <div className={clsx(styles.grid, compact && styles.compact)}>
        <div className={styles.name}>
          <FormInput
            name='processName'
            control={control}
            label='Название'
            required
            fullWidth
            placeholder='Например, Reindex Databases'
            inputProps={{ maxLength: 200 }}
          />
        </div>

        <div className={styles.type}>
          <Controller
            name='processType'
            control={control}
            render={({ field, fieldState }) => (
              <Select
                label='Тип процесса'
                required
                value={field.value}
                options={typeOptions}
                placeholder='Выберите тип'
                disabled={typeOptions.length === 0}
                error={Boolean(fieldState.error)}
                helperText={
                  fieldState.error?.message ??
                  (compact ? undefined : 'Значения загружаются из GET /process/types')
                }
                inputProps={{ name: field.name }}
                selectButtonProps={{ onBlur: field.onBlur }}
                onChange={field.onChange}
              />
            )}
          />
        </div>

        <div className={styles.category}>
          <Controller
            name='category'
            control={control}
            render={({ field, fieldState }) => {
              const selectedOption =
                categoryOptions.find((option) => option.value === field.value) ??
                (field.value ? { value: field.value, label: field.value } : null)

              return (
                <Creatable<SelectOption>
                  label='Категория'
                  canClear
                  clearInputOnBlur
                  openOnFocus
                  value={selectedOption}
                  options={categoryOptions}
                  placeholder='Выберите или создайте категорию'
                  noOptionsText='Категории не найдены'
                  formatLabel={(value) => `Создать категорию «${value}»`}
                  error={Boolean(fieldState.error)}
                  helperText={
                    fieldState.error?.message ??
                    (compact ? undefined : 'Необязательная пользовательская категория процесса')
                  }
                  inputProps={{ name: field.name }}
                  controlInnerProps={{ onBlur: field.onBlur }}
                  onChange={(option) => field.onChange(option?.value ?? '')}
                />
              )
            }}
          />
        </div>

        <div className={styles.description}>
          <FormTextarea
            name='description'
            control={control}
            label='Описание'
            rows={compact ? 3 : 5}
            resize='vertical'
            fullWidth
            showCount
            placeholder='Опишите назначение процесса'
            helperText={compact ? undefined : 'Необязательное поле'}
            textareaProps={{ maxLength: 2_000 }}
          />
        </div>
      </div>

      {typeOptions.length === 0 ? (
        <InlineNotification
          kind='outlined'
          status='warning'
          title='Типы процессов не настроены'
        >
          Backend вернул пустой список processTypes. Создание процесса недоступно, пока
          справочник не будет заполнен.
        </InlineNotification>
      ) : null}
    </FormSection>
  )
}
