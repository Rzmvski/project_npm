import { ComboBox, InlineNotification } from '@v-uik/base'
import clsx from 'clsx'
import { Database, Tag as LabelIcon } from 'lucide-react'
import { Controller, type Control, useWatch } from 'react-hook-form'

import { FormSection } from '@/shared/ui'

import { getSelectedOptions, type ProcessFormValues, type SelectOption } from '../../model'

import styles from './ProcessTargetsField.module.scss'

import type { FC } from 'react'

interface ProcessTargetsFieldProps {
  control: Control<ProcessFormValues>
  dbRouteOptions: SelectOption[]
  dbSetOptions: SelectOption[]
  compact?: boolean
}

function optionsFromChange(value: unknown): SelectOption[] {
  return Array.isArray(value) ? (value as SelectOption[]) : []
}

export const ProcessTargetsField: FC<ProcessTargetsFieldProps> = ({
  control,
  dbRouteOptions,
  dbSetOptions,
  compact = false,
}) => {
  const dbRoutes = useWatch({ control, name: 'dbRoutes' })
  const dbSets = useWatch({ control, name: 'dbSets' })
  const selectedCount = dbRoutes.length + dbSets.length

  return (
    <FormSection
      title='Область выполнения'
      description='Базы данных и DB sets, на которых выполняется процесс.'
      headerAction={
        <span
          className={clsx(styles.counter, compact && styles.counterCompact)}
          title={`Выбрано целей: ${selectedCount}`}
        >
          {compact
            ? selectedCount
            : selectedCount > 0
              ? `Выбрано целей: ${selectedCount}`
              : 'Цели не выбраны'}
        </span>
      }
    >
      <div className={clsx(styles.grid, compact && styles.compact)}>
        <Controller
          name='dbRoutes'
          control={control}
          render={({ field, fieldState }) => (
            <ComboBox<SelectOption>
              multiple
              canClear
              isSearchable
              openOnFocus
              clearInputOnBlur
              disableCloseOnSelect
              disableClearInputOnChange
              limitTags={2}
              label='Базы данных'
              placeholder='Выберите DB routes'
              noOptionsText='Базы данных не найдены'
              options={dbRouteOptions}
              value={getSelectedOptions(field.value, dbRouteOptions)}
              getOptionPrefix={() => <Database size={16} />}
              disabled={dbRouteOptions.length === 0}
              error={Boolean(fieldState.error)}
              helperText={
                fieldState.error?.message ??
                (field.value.length
                  ? `Выбрано баз данных: ${field.value.length}`
                  : 'Конкретные маршруты подключения к БД')
              }
              controlInnerProps={{ onBlur: field.onBlur }}
              inputProps={{ name: field.name }}
              onChange={(_value, _event, fullValue) =>
                field.onChange(optionsFromChange(fullValue).map((option) => option.value))
              }
            />
          )}
        />

        <Controller
          name='dbSets'
          control={control}
          render={({ field }) => (
            <ComboBox<SelectOption>
              multiple
              canClear
              isSearchable
              openOnFocus
              clearInputOnBlur
              disableCloseOnSelect
              disableClearInputOnChange
              limitTags={2}
              label='DB sets'
              placeholder='Выберите DB sets'
              noOptionsText='DB sets не найдены'
              options={dbSetOptions}
              value={getSelectedOptions(field.value, dbSetOptions)}
              getOptionPrefix={() => <LabelIcon size={16} />}
              disabled={dbSetOptions.length === 0}
              helperText={
                field.value.length
                  ? `Выбрано DB sets: ${field.value.length}`
                  : 'Сохранённые группы баз данных'
              }
              controlInnerProps={{ onBlur: field.onBlur }}
              inputProps={{ name: field.name }}
              onChange={(_value, _event, fullValue) =>
                field.onChange(optionsFromChange(fullValue).map((option) => option.value))
              }
            />
          )}
        />
      </div>

      {dbRouteOptions.length === 0 && dbSetOptions.length === 0 ? (
        <InlineNotification
          kind='outlined'
          status='warning'
          title='Область выполнения не настроена'
        >
          Для текущего tenant отсутствуют DB routes и DB sets.
        </InlineNotification>
      ) : null}
    </FormSection>
  )
}
