import { useQuery, useQueryClient } from '@tanstack/react-query'
import { useNavigate } from '@tanstack/react-router'
import { BarSelect } from '@v-uik/base'

import { getDefaultWorkspacePath, userAccessQueryOptions } from '@/entities/access'
import {
  setSelectedTenantId,
  tenantListQueryOptions,
  useRequiredTenantId,
} from '@/entities/tenant'

import styles from './TenantSwitcher.module.scss'

import type { FC } from 'react'

export const TenantSwitcher: FC = () => {
  const tenantId = useRequiredTenantId()
  const tenants = useQuery(tenantListQueryOptions())
  const queryClient = useQueryClient()
  const navigate = useNavigate()
  const changeTenant = async (nextTenantId: string) => {
    if (nextTenantId === tenantId) return

    const access = await queryClient.ensureQueryData(userAccessQueryOptions(nextTenantId))
    setSelectedTenantId(nextTenantId)
    await queryClient.invalidateQueries({ queryKey: ['tenant'] })
    await navigate({
      to: getDefaultWorkspacePath(access),
      replace: true,
    })
  }

  return (
    <section className={styles.switcher} aria-label='Текущий namespace'>
      <BarSelect
        value={tenantId}
        options={(tenants.data ?? []).map((tenant) => ({
          value: tenant.id,
          label: tenant.code,
        }))}
        onChange={(value) => void changeTenant(value)}
        selectProps={{
          'aria-label': 'Текущий namespace. Выбрать другой',
          disabled: tenants.isPending,
          size: 'sm',
          classes: {
            button: styles.selectButton,
          },
        }}
      />
    </section>
  )
}
