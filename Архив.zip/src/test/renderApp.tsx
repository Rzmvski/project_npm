import DateFnsAdapter from '@date-io/date-fns'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { createMemoryHistory, RouterProvider } from '@tanstack/react-router'
import { render } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { DateLibAdapterProvider, ModalContainer } from '@v-uik/base'
import { ru } from 'date-fns/locale'

import { createAppRouter } from '@/app/router'
import { accessKeys, type UserAccess } from '@/entities/access'
import { processKeys, type ProcessSummary } from '@/entities/process'
import { routeKeys, type AvailableRoutesResponse } from '@/entities/route'
import { scheduleKeys, type ScheduleResponse } from '@/entities/schedule'
import { setSelectedTenantId, tenantKeys, type Tenant } from '@/entities/tenant'
import { userKeys, type UserProfile } from '@/entities/user'
import { AppThemeProvider } from '@/shared/config'

import {
  routesFixture,
  tenantFixture,
  TEST_TENANT_ID,
  userAccessFixture,
  userFixture,
} from './fixtures'

import type { ReactElement } from 'react'

export function createTestQueryClient() {
  return new QueryClient({
    defaultOptions: {
      queries: {
        retry: false,
        staleTime: Number.POSITIVE_INFINITY,
      },
      mutations: { retry: false },
    },
  })
}

export interface RenderAppOptions {
  route: string
  tenant?: Tenant
  access?: UserAccess
  profile?: UserProfile
  processes?: ProcessSummary[]
  processTypes?: string[]
  routes?: AvailableRoutesResponse
  schedule?: ScheduleResponse | null
  seed?: (queryClient: QueryClient) => void
}

export async function renderApp({
  route,
  tenant = tenantFixture,
  access = userAccessFixture(),
  profile = userFixture(),
  processes = [],
  processTypes = ['DB_PROCESS'],
  routes = routesFixture,
  schedule,
  seed,
}: RenderAppOptions) {
  setSelectedTenantId(tenant.id)

  const queryClient = createTestQueryClient()
  queryClient.setQueryData(tenantKeys.all, [tenant])
  queryClient.setQueryData(accessKeys.tenant(tenant.id), access)
  queryClient.setQueryData(userKeys.current(), profile)
  queryClient.setQueryData(processKeys.list(tenant.id), processes)
  queryClient.setQueryData(processKeys.types(tenant.id), { processTypes })
  queryClient.setQueryData(routeKeys.list(tenant.id), routes)

  if (schedule !== undefined) {
    const processId = processes[0]?.id
    if (processId) {
      queryClient.setQueryData(scheduleKeys.detail(tenant.id, processId), schedule)
    }
  }

  seed?.(queryClient)

  const history = createMemoryHistory({ initialEntries: [route] })
  const router = createAppRouter(queryClient, history)
  const user = userEvent.setup()

  const result = render(
    <AppThemeProvider>
      <DateLibAdapterProvider dateAdapter={DateFnsAdapter} options={{ locale: ru }}>
        <QueryClientProvider client={queryClient}>
          <RouterProvider router={router} />
          <ModalContainer />
        </QueryClientProvider>
      </DateLibAdapterProvider>
    </AppThemeProvider>,
  )

  await router.load()

  return {
    ...result,
    queryClient,
    router,
    user,
  }
}

export function renderWithDateProvider(ui: ReactElement) {
  const user = userEvent.setup()
  return {
    user,
    ...render(
      <AppThemeProvider>
        <DateLibAdapterProvider dateAdapter={DateFnsAdapter} options={{ locale: ru }}>
          {ui}
          <ModalContainer />
        </DateLibAdapterProvider>
      </AppThemeProvider>,
    ),
  }
}

export { TEST_TENANT_ID }
