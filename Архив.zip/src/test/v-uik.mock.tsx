import { Children, cloneElement, isValidElement, useSyncExternalStore } from 'react'
import { vi } from 'vitest'

import type { ComponentPropsWithoutRef, ReactElement, ReactNode } from 'react'

type Option = { value: string; label: ReactNode }

export const notification = {
  success: vi.fn(),
  error: vi.fn(),
  info: vi.fn(),
  warning: vi.fn(),
}

export function Button({
  children,
  prefixIcon,
  isLoading: _isLoading,
  loadingTitle: _loadingTitle,
  kind: _kind,
  color: _color,
  size: _size,
  fullWidth: _fullWidth,
  ...props
}: ComponentPropsWithoutRef<'button'> & Record<string, unknown>) {
  return (
    <button {...props}>
      {prefixIcon as ReactNode}
      {children}
    </button>
  )
}

export function DropdownMenu({
  children,
  content,
}: {
  children: ReactNode
  content: ReactNode
}) {
  return (
    <div>
      {children}
      <div>{content}</div>
    </div>
  )
}

export function DropdownMenuItem({
  children,
  prefix,
  closeMenuOnClick: _closeMenuOnClick,
  critical: _critical,
  ...props
}: ComponentPropsWithoutRef<'button'> & Record<string, unknown> & { prefix?: ReactNode }) {
  return (
    <button type='button' {...props}>
      {prefix}
      {children}
    </button>
  )
}

export function Input({
  label,
  value = '',
  onChange,
  helperText,
  error,
  inputProps,
  prefix,
  suffix,
  fullWidth: _fullWidth,
  required,
  inputRef,
  ...props
}: Record<string, any>) {
  const ariaLabel = inputProps?.['aria-label'] ?? label ?? props.placeholder
  return (
    <label>
      {label ? <span>{label}</span> : null}
      {prefix}
      <input
        {...props}
        {...inputProps}
        ref={inputRef}
        aria-label={ariaLabel}
        aria-invalid={error || undefined}
        required={required}
        value={value ?? ''}
        onChange={(event) => onChange?.(event.target.value)}
      />
      {suffix}
      {helperText ? <span role={error ? 'alert' : undefined}>{helperText}</span> : null}
    </label>
  )
}

export function Textarea({
  label,
  value = '',
  onChange,
  helperText,
  error,
  textareaProps,
  textareaRef,
  resize: _resize,
  fullWidth: _fullWidth,
  showCount: _showCount,
  ...props
}: Record<string, any>) {
  const ariaLabel = textareaProps?.['aria-label'] ?? label ?? props.placeholder
  return (
    <label>
      {label ? <span>{label}</span> : null}
      <textarea
        {...props}
        {...textareaProps}
        ref={textareaRef}
        aria-label={ariaLabel}
        aria-invalid={error || undefined}
        value={value ?? ''}
        onChange={(event) => onChange?.(event.target.value)}
      />
      {helperText ? <span role={error ? 'alert' : undefined}>{helperText}</span> : null}
    </label>
  )
}

export function InputNumber({
  label,
  value = '',
  onChange,
  helperText,
  error,
  inputProps,
  precision: _precision,
  fullWidth: _fullWidth,
  ...props
}: Record<string, any>) {
  return (
    <label>
      {label ? <span>{label}</span> : null}
      <input
        {...props}
        {...inputProps}
        aria-label={inputProps?.['aria-label'] ?? label}
        aria-invalid={error || undefined}
        type='number'
        value={value ?? ''}
        onChange={(event) =>
          onChange?.(event.target.value === '' ? null : Number(event.target.value))
        }
      />
      {helperText ? <span role={error ? 'alert' : undefined}>{helperText}</span> : null}
    </label>
  )
}

export function Select({
  label,
  value = '',
  options = [],
  onChange,
  placeholder,
  helperText,
  error,
  selectButtonProps,
  inputProps,
  ...props
}: Record<string, any>) {
  return (
    <label>
      {label ? <span>{label}</span> : null}
      <select
        {...props}
        {...selectButtonProps}
        name={inputProps?.name}
        aria-label={selectButtonProps?.['aria-label'] ?? label ?? placeholder}
        aria-invalid={error || undefined}
        value={value ?? ''}
        onChange={(event) => onChange?.(event.target.value)}
      >
        <option value=''>{placeholder ?? 'Не выбрано'}</option>
        {(options as Option[]).map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
      {helperText ? <span role={error ? 'alert' : undefined}>{helperText}</span> : null}
    </label>
  )
}

export function Creatable({
  label,
  value,
  onChange,
  helperText,
  error,
  placeholder,
  inputProps,
  disabled,
  required,
  className,
}: Record<string, any>) {
  return (
    <label>
      {label ? <span>{label}</span> : null}
      <input
        {...inputProps}
        className={className}
        disabled={disabled}
        required={required}
        aria-label={label ?? placeholder}
        aria-invalid={error || undefined}
        placeholder={placeholder}
        value={value?.value ?? ''}
        onChange={(event) => {
          const next = event.target.value
          onChange?.(next ? { value: next, label: next } : null)
        }}
      />
      {helperText ? <span role={error ? 'alert' : undefined}>{helperText}</span> : null}
    </label>
  )
}

export function ComboBox({
  label,
  value = [],
  options = [],
  onChange,
  helperText,
  error,
  inputProps,
  multiple,
  placeholder,
  disabled,
  required,
  className,
}: Record<string, any>) {
  const selectedValues = Array.isArray(value)
    ? value.map((item: Option) => item.value)
    : value?.value
      ? [value.value]
      : []

  return (
    <label>
      {label ? <span>{label}</span> : null}
      <select
        className={className}
        disabled={disabled}
        required={required}
        name={inputProps?.name}
        aria-label={label ?? placeholder}
        aria-invalid={error || undefined}
        multiple={Boolean(multiple)}
        value={multiple ? selectedValues : (selectedValues[0] ?? '')}
        onChange={(event) => {
          const selected = Array.from(event.target.selectedOptions).map((item) =>
            (options as Option[]).find((option) => option.value === item.value)!,
          )
          onChange?.(
            multiple ? selected : (selected[0] ?? null),
            event,
            multiple ? selected : (selected[0] ?? null),
          )
        }}
      >
        {(options as Option[]).map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
      {helperText ? <span role={error ? 'alert' : undefined}>{helperText}</span> : null}
    </label>
  )
}

export function DatePicker({
  label,
  value,
  onChange,
  helperText,
  error,
  inputProps,
}: Record<string, any>) {
  const formatted =
    value instanceof Date
      ? [
          value.getFullYear(),
          String(value.getMonth() + 1).padStart(2, '0'),
          String(value.getDate()).padStart(2, '0'),
        ].join('-')
      : ''
  return (
    <label>
      <span>{label}</span>
      <input
        {...inputProps?.inputProps}
        aria-label={inputProps?.inputProps?.['aria-label'] ?? label}
        aria-invalid={error || undefined}
        type='date'
        value={formatted}
        onChange={(event) => {
          const [year, month, day] = event.target.value.split('-').map(Number)
          if (!year || !month || !day) {
            onChange?.(null)
            return
          }
          onChange?.(new Date(year, month - 1, day))
        }}
      />
      {helperText ? <span role={error ? 'alert' : undefined}>{helperText}</span> : null}
    </label>
  )
}

export function TimePicker({
  label,
  value,
  onChange,
  helperText,
  error,
  inputProps,
}: Record<string, any>) {
  const formatted =
    value instanceof Date
      ? `${String(value.getHours()).padStart(2, '0')}:${String(value.getMinutes()).padStart(2, '0')}`
      : ''

  return (
    <label>
      <span>{label}</span>
      <input
        {...inputProps?.inputProps}
        aria-label={inputProps?.inputProps?.['aria-label'] ?? label}
        aria-invalid={error || undefined}
        type='time'
        value={formatted}
        onChange={(event) => {
          const [hours, minutes] = event.target.value.split(':').map(Number)
          if (!Number.isFinite(hours) || !Number.isFinite(minutes)) {
            onChange?.(null)
            return
          }
          onChange?.(new Date(2000, 0, 1, hours, minutes))
        }}
      />
      {helperText ? <span role={error ? 'alert' : undefined}>{helperText}</span> : null}
    </label>
  )
}

export function RangePicker({
  label,
  value = [null, null],
  onChange,
  startInputProps,
  endInputProps,
}: Record<string, any>) {
  const formatValue = (date: unknown) =>
    date instanceof Date
      ? [
          date.getFullYear(),
          String(date.getMonth() + 1).padStart(2, '0'),
          String(date.getDate()).padStart(2, '0'),
        ].join('-')
      : ''

  const parseValue = (date: string) => {
    const [year, month, day] = date.split('-').map(Number)
    return year && month && day ? new Date(year, month - 1, day) : null
  }

  return (
    <fieldset aria-label={label}>
      <legend>{label}</legend>
      <input
        {...startInputProps?.inputProps}
        aria-label={startInputProps?.inputProps?.['aria-label'] ?? `${label} с`}
        type='date'
        value={formatValue(value?.[0])}
        onChange={(event) => onChange?.([parseValue(event.target.value), value?.[1] ?? null])}
      />
      <input
        {...endInputProps?.inputProps}
        aria-label={endInputProps?.inputProps?.['aria-label'] ?? `${label} по`}
        type='date'
        value={formatValue(value?.[1])}
        onChange={(event) => onChange?.([value?.[0] ?? null, parseValue(event.target.value)])}
      />
    </fieldset>
  )
}

export function InputHelperText({
  children,
  error,
}: {
  children?: ReactNode
  error?: boolean
}) {
  return <span role={error ? 'alert' : undefined}>{children}</span>
}

export function Modal({ open, children }: { open: boolean; children: ReactNode }) {
  return open ? <div role='dialog'>{children}</div> : null
}

interface MockModalOptions {
  content?: ReactNode
  onClose?: () => void
}

const mockModalStore = new Map<string, MockModalOptions>()
const mockModalListeners = new Set<() => void>()
let mockModalVersion = 0

const emitModalChange = () => {
  mockModalVersion += 1
  mockModalListeners.forEach((listener) => listener())
}

export const modal = {
  show: (id: string | number | symbol, options: MockModalOptions) => {
    mockModalStore.set(String(id), options)
    emitModalChange()
  },
  close: (id: string) => {
    mockModalStore.delete(id)
    emitModalChange()
  },
  closeAll: () => {
    mockModalStore.clear()
    emitModalChange()
  },
}

export function ModalContainer() {
  useSyncExternalStore(
    (listener) => {
      mockModalListeners.add(listener)
      return () => mockModalListeners.delete(listener)
    },
    () => mockModalVersion,
    () => mockModalVersion,
  )

  return (
    <>
      {[...mockModalStore.entries()].map(([id, options]) => (
        <div key={id} role='dialog'>
          {options.content}
        </div>
      ))}
    </>
  )
}

export function ModalHeader({ children, subtitle, closeButtonProps }: Record<string, any>) {
  return (
    <header>
      <h2>{children}</h2>
      {subtitle ? <p>{subtitle}</p> : null}
      {closeButtonProps ? <button {...closeButtonProps}>×</button> : null}
    </header>
  )
}

export function ModalBody({ children }: { children: ReactNode }) {
  return <div>{children}</div>
}

export function ModalFooter({ children }: { children: ReactNode }) {
  return <footer>{children}</footer>
}

export function Tag({ children }: { children: ReactNode }) {
  return <span>{children}</span>
}

export function InlineNotification({
  title,
  children,
}: {
  title?: ReactNode
  children?: ReactNode
}) {
  return (
    <div role='status'>
      {title ? <strong>{title}</strong> : null}
      {children}
    </div>
  )
}

export function CircularProgress() {
  return <span role='progressbar' />
}

export function Breadcrumbs({ children, ...props }: Record<string, any>) {
  return <nav {...props}>{children}</nav>
}

export function Bar({ children, className, 'aria-label': ariaLabel }: Record<string, any>) {
  return (
    <nav className={className} aria-label={ariaLabel}>
      {children}
    </nav>
  )
}

export function BarMenuItem({ children, icon, selected, onClick }: Record<string, any>) {
  return (
    <button type='button' aria-current={selected ? 'page' : undefined} onClick={onClick}>
      {icon}
      {children}
    </button>
  )
}

export function BarDivider() {
  return <hr />
}

export function BarSelect({ options = [], value, onChange, selectProps }: Record<string, any>) {
  return (
    <select {...selectProps} value={value} onChange={(event) => onChange?.(event.target.value)}>
      {(options as Option[]).map((option) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </select>
  )
}

export function Avatar({ children, ...props }: Record<string, any>) {
  return <span {...props}>{children}</span>
}

export function ButtonGroup({ children, kind, value, onChange }: Record<string, any>) {
  const selected = Array.isArray(value) ? value : [value]

  return (
    <div role={kind === 'radio' ? 'radiogroup' : 'group'}>
      {Children.map(children, (child) => {
        if (!isValidElement(child)) return child

        const element = child as ReactElement<Record<string, any>>
        const { name } = element.props
        const pressed = name ? selected.includes(name) : false

        return cloneElement(element, {
          'aria-pressed': pressed,
          onClick: (event: unknown) => {
            element.props.onClick?.(event)
            if (!name) return

            const nextValue =
              kind === 'multi'
                ? pressed
                  ? selected.filter((item) => item !== name)
                  : [...selected.filter(Boolean), name]
                : name

            onChange?.(event, nextValue)
          },
        })
      })}
    </div>
  )
}

export function Accordion({ children }: { children: ReactNode }) {
  return <div>{children}</div>
}

export function AccordionItem({ title, children }: { title?: ReactNode; children: ReactNode }) {
  return (
    <section>
      {title ? <h3>{title}</h3> : null}
      {children}
    </section>
  )
}

export function Tabs({
  children,
  value,
  onChange,
}: {
  children: ReactNode
  value?: string | number
  onChange?: (value: string | number) => void
}) {
  const tabs = Children.toArray(children).filter(isValidElement) as ReactElement<{
    value: string | number
    header?: ReactNode
    children?: ReactNode
  }>[]

  return (
    <div>
      <div role='tablist'>
        {tabs.map((tab) => (
          <button
            key={tab.props.value}
            type='button'
            role='tab'
            aria-selected={tab.props.value === value}
            onClick={() => onChange?.(tab.props.value)}
          >
            {tab.props.header}
          </button>
        ))}
      </div>
      {tabs.find((tab) => tab.props.value === value)?.props.children}
    </div>
  )
}

export function Tab(_props: {
  value: string | number
  header?: ReactNode
  children?: ReactNode
}) {
  return null
}

export function Pagination({
  currentPage = 1,
  totalPageCount = 1,
  onPageChange,
  disabled,
}: Record<string, any>) {
  return (
    <nav aria-label='Пагинация'>
      {Array.from({ length: totalPageCount }, (_, index) => {
        const page = index + 1
        return (
          <button
            key={page}
            type='button'
            aria-current={currentPage === page ? 'page' : undefined}
            disabled={disabled}
            onClick={() => onPageChange?.(page)}
          >
            {page}
          </button>
        )
      })}
    </nav>
  )
}

export function Table({
  dataSource = [],
  columns = [],
  rowKey,
  className,
  'aria-label': ariaLabel,
  ...props
}: Record<string, any>) {
  void props
  return (
    <table className={className} aria-label={ariaLabel}>
      <thead>
        <tr>
          {(columns as any[]).map((column) => (
            <th key={column.key}>{column.title}</th>
          ))}
        </tr>
      </thead>
      <tbody>
        {(dataSource as any[]).map((row, index) => {
          const key =
            typeof rowKey === 'function' ? rowKey(row) : (row[rowKey] ?? row.key ?? index)
          return (
            <tr key={String(key)}>
              {(columns as any[]).map((column) => (
                <td key={column.key}>
                  {column.renderCellContent
                    ? column.renderCellContent({ row })
                    : column.dataIndex
                      ? row[column.dataIndex]
                      : null}
                </td>
              ))}
            </tr>
          )
        })}
      </tbody>
    </table>
  )
}

export function DateLibAdapterProvider({ children }: { children: ReactNode }) {
  return <>{children}</>
}

export function NotificationContainer() {
  return null
}

export type ColumnProps<_T> = any
export type RecordDataSource<T> = T & { key?: string }
