import { execFileSync } from 'node:child_process'
import console from 'node:console'
import { existsSync } from 'node:fs'
import process from 'node:process'

if (process.env.CI || process.env.HUSKY === '0') {
  process.exit(0)
}

if (!existsSync('.git')) {
  console.info('Husky setup skipped: .git directory was not found.')
  process.exit(0)
}

const npmExecutable = process.platform === 'win32' ? 'npm.cmd' : 'npm'
execFileSync(npmExecutable, ['exec', '--', 'husky'], { stdio: 'inherit' })
