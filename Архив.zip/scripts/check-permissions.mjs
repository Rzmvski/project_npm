import console from 'node:console'
import { readFileSync } from 'node:fs'
import process from 'node:process'
import { URL } from 'node:url'

const roleModel = readFileSync(new URL('../roleModel.xml', import.meta.url), 'utf8')
const permissionSource = readFileSync(
  new URL('../src/entities/access/model/permissions.ts', import.meta.url),
  'utf8',
)

const declaredList = [...roleModel.matchAll(/<permission\s+[^>]*id="([^"]+)"/g)].map(
  (match) => match[1],
)
const declared = new Set(declaredList)

const used = [
  ...permissionSource.matchAll(/:\s*['"]([a-zA-Z][a-zA-Z0-9_.]+Service[_.][a-zA-Z0-9_]+)['"]/g),
].map((match) => match[1])

const usedSet = new Set(used)
const roles = [...roleModel.matchAll(/<role\s+code="([^"]+)"[^>]*>([\s\S]*?)<\/role>/g)].map(
  (match) => ({
    code: match[1],
    permissions: [...match[2].matchAll(/<permission-ref\s+id="([^"]+)"/g)].map(
      (permission) => permission[1],
    ),
  }),
)
const permissionRefs = roles.flatMap((role) => role.permissions)

const missing = used.filter((permission) => !declared.has(permission))
const unused = declaredList.filter((permission) => !usedSet.has(permission))
const danglingRefs = permissionRefs.filter((permission) => !declared.has(permission))
const unassigned = declaredList.filter((permission) => !permissionRefs.includes(permission))
const duplicateDeclarations = declaredList.filter(
  (permission, index) => declaredList.indexOf(permission) !== index,
)
const duplicateRoleRefs = roles.flatMap((role) =>
  role.permissions
    .filter((permission, index) => role.permissions.indexOf(permission) !== index)
    .map((permission) => `${role.code}: ${permission}`),
)

const errors = [
  ['Permission IDs missing in roleModel.xml:', missing],
  ['Permission IDs not used by the UI:', unused],
  ['Role references to undeclared permissions:', danglingRefs],
  ['Permission IDs not assigned to any role:', unassigned],
  ['Duplicate permission declarations:', duplicateDeclarations],
  ['Duplicate permission references inside a role:', duplicateRoleRefs],
].filter(([, permissions]) => permissions.length)

if (errors.length) {
  errors.forEach(([title, permissions]) => {
    console.error(title)
    const uniquePermissions = new Set(permissions)
    uniquePermissions.forEach((permission) => console.error(`- ${permission}`))
  })
  process.exit(1)
}

console.log(`Validated ${used.length} UI permission IDs and ${roles.length} roles`)
