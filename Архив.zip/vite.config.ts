import { fileURLToPath, URL } from 'node:url'

import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

import { appCssVariablesCssText } from './src/shared/config/theme/model/cssVariables'

export default defineConfig({
  plugins: [
    {
      name: 'app-theme-variables',
      transformIndexHtml: {
        order: 'pre',
        handler: () => [
          {
            tag: 'style',
            attrs: { 'data-app-theme': 'variables' },
            children: appCssVariablesCssText,
            injectTo: 'head-prepend',
          },
        ],
      },
    },
    react(),
  ],
  build: {
    chunkSizeWarningLimit: 600,
    sourcemap: true,
  },
  css: {
    devSourcemap: true,
  },
  base: './',
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
    },
  },
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:8080',
        changeOrigin: true,
      },
    },
  },
})
