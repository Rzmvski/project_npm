# Platform Process Manager REST contract

This is the canonical API contract consumed by the frontend and implemented by
the local Express mock. Agents must update this file together with entity API
types, mock handlers and API tests whenever the contract changes.

## Conventions

- Base path: `/api/v1`.
- All protected calls use the current authenticated session/token.
- `/user` and `/tenants` do not require `tenant-id`.
- `/user/permissions` and all domain endpoints require header
  `tenant-id: <uuid>`.
- JSON reads and process commands use `ApiResponse<T>`.
- Schedule create/update return empty `200`; schedule delete returns empty `204`.
- Dates use `YYYY-MM-DD`; date-times use ISO-compatible strings.
- IDs are UUID strings unless a backend-owned string key is stated.

## Endpoint index

| Method | Path                                                  | Tenant | Response data                   |
| ------ | ----------------------------------------------------- | :----: | ------------------------------- |
| GET    | `/user`                                               |   No   | `UserProfile`                   |
| GET    | `/user/permissions`                                   |  Yes   | `string[]`                      |
| GET    | `/tenants`                                            |   No   | `Tenant[]`                      |
| GET    | `/routes`                                             |  Yes   | `AvailableRoutesResponse`       |
| GET    | `/process/types`                                      |  Yes   | `ProcessTypesResponse`          |
| GET    | `/process`                                            |  Yes   | `ProcessSummary[]`              |
| POST   | `/process`                                            |  Yes   | `ProcessMutationResponse`       |
| PUT    | `/process/{processId}`                                |  Yes   | `ProcessMutationResponse`       |
| DELETE | `/process/{processId}`                                |  Yes   | `null`                          |
| POST   | `/process/start`                                      |  Yes   | `StartProcessResponse`          |
| POST   | `/process/stop/{processSessionId}`                    |  Yes   | `null`                          |
| GET    | `/process/history`                                    |  Yes   | `Page<ProcessHistoryItem>`      |
| GET    | `/process/history/{sessionProcessId}/detail`          |  Yes   | `ProcessDetail`                 |
| GET    | `/process/history/{processSessionId}/route-sessions`  |  Yes   | `Page<RouteSessionMonitoring>`  |
| GET    | `/process/history/{processSessionId}/thread-sessions` |  Yes   | `Page<ThreadSessionMonitoring>` |
| GET    | `/process/schedule`                                   |  Yes   | `Page<TenantScheduleInfo>`      |
| GET    | `/process/schedule/{processId}`                       |  Yes   | `ScheduleResponse`              |
| POST   | `/process/schedule`                                   |  Yes   | empty `200`                     |
| PUT    | `/process/schedule`                                   |  Yes   | empty `200`                     |
| DELETE | `/process/schedule`                                   |  Yes   | empty `204`                     |

Health endpoints used only by local infrastructure:

```http
GET /api/health
GET /api/v1/health
```

## Common envelopes

### Successful JSON response

```ts
interface ApiResponse<T> {
  status: string
  description: string
  data: T
}
```

Example:

```json
{
  "status": "SUCCESS",
  "description": "OK",
  "data": {}
}
```

### Error response

```json
{
  "status": "FORBIDDEN",
  "description": "Missing permission: processService_create",
  "data": null
}
```

The frontend uses HTTP status for control flow and `description` as the primary
backend error message.

### Page

```ts
interface Page<T> {
  content: T[]
  totalElements: number
  totalPages: number
  size: number
  number: number
  numberOfElements?: number
  first?: boolean
  last?: boolean
  empty?: boolean
  pageable?: {
    pageNumber: number
    pageSize: number
    offset: number
    paged: boolean
    unpaged: boolean
    sort: Sort
  }
  sort?: Sort
}

interface Sort {
  empty: boolean
  sorted: boolean
  unsorted: boolean
}
```

## User and tenant initialization

### GET `/user`

Returns the authenticated user profile before tenant selection.

```ts
interface UserProfile {
  login: string
  displayName: string
  roles: string[]
}
```

```json
{
  "status": "SUCCESS",
  "description": "User profile retrieved successfully",
  "data": {
    "login": "user@example.com",
    "displayName": "Тестовый пользователь",
    "roles": ["SUPER_ADMIN"]
  }
}
```

### GET `/user/permissions`

Required header:

```http
tenant-id: 550e8400-e29b-41d4-a716-446655440000
```

The response data is directly an array of permission IDs. Do not introduce an
inner `{ permissions: [...] }` wrapper.

```json
{
  "status": "SUCCESS",
  "description": "Permissions retrieved successfully",
  "data": ["processService_getAll", "historyService_getHistory"]
}
```

### GET `/tenants`

Returns only tenants assigned to the user. `SUPER_ADMIN` may receive all
tenants.

```ts
interface Tenant {
  id: string
  code: string
}
```

## Processes

### Process models

```ts
interface RouteTarget {
  routeKey: string
  isLabel: boolean
}

interface ProcessSummary {
  id: string
  processName: string
  processType: string
  description: string | null
  label: string | null
  routes: RouteTarget[]
  cmd: string
}

interface ProcessMutationResponse {
  processId: string
  processName: string
  processType: string
  description: string | null
  label: string | null
}
```

`isLabel: true` means a backend-managed DB set. It is not the process category.
The UI label **Категория** maps to the `label` field.

### GET `/process`

Returns `ApiResponse<ProcessSummary[]>`.

This endpoint is also the source for the read-only card and edit form. It must
return the saved `cmd`; there is no `GET /process/{processId}` detail endpoint.

### GET `/process/types`

```ts
interface ProcessTypesResponse {
  processTypes: string[]
}
```

Users cannot create arbitrary process types in the UI.

### GET `/routes`

```ts
interface AvailableRoutesResponse {
  tenantId: string
  routes: RouteTarget[]
}
```

The endpoint is needed only when creating or editing a process.

### POST `/process`

```ts
interface CreateProcessRequest {
  rqUid: string
  processName: string
  processType: string
  description?: string
  label?: string
  routes: RouteTarget[]
  cmd: string
}
```

Returns `ApiResponse<ProcessMutationResponse>`.

### PUT `/process/{processId}`

Uses the same complete payload as create. The command is required and is always
sent in full; an empty string is not a partial-update marker.

Returns `ApiResponse<ProcessMutationResponse>`.

### DELETE `/process/{processId}`

Optional query parameter:

```text
rqUid=<request identifier>
```

Performs soft delete and returns `ApiResponse<null>`.

## Manual execution

### POST `/process/start`

```ts
interface StartProcessRequest {
  rqUid: string
  processId: string
  additionalParams?: Record<string, string>
  login?: string
  startDate?: string
}

interface StartProcessResponse {
  processSessionId: string
}
```

Returns `ApiResponse<StartProcessResponse>`.

### POST `/process/stop/{processSessionId}`

Optional query parameter: `rqUid`.

Returns `ApiResponse<null>`.

## Execution history

### Status values

```ts
type ProcessStatusCode = 'CREATED' | 'WORKS' | 'SUCCESS' | 'ERROR' | 'CANCELED' | 'STOPPED'
```

### GET `/process/history`

Supported query parameters:

| Parameter | Required | Description             |
| --------- | :------: | ----------------------- |
| `page`    |   Yes    | Zero-based page         |
| `size`    |   Yes    | Page size               |
| `sort`    |   Yes    | Backend sort expression |

Search, status, category and date-range filters are UI-only state and must not
be sent to this endpoint.

```ts
interface ProcessHistoryItem {
  processId: string
  processName: string
  processType: string
  description: string | null
  label: string | null
  isDeleted: boolean
  startDate: string | null
  statusCode: ProcessStatusCode | null
  statusName: string | null
  startDateTime: string | null
  endDateTime: string | null
  sessionProcessId: string | null
}
```

Returns `ApiResponse<Page<ProcessHistoryItem>>`.

### GET `/process/history/{sessionProcessId}/detail`

```ts
interface ProcessDetail {
  processId: string
  processName: string
  processType: string
  description: string | null
  label: string | null
  isDeleted: boolean
  startDate: string | null
  processSession: ProcessSessionMonitoring
}

interface ProcessSessionMonitoring {
  processSessionId: string
  statusCode: ProcessStatusCode
  statusName: string
  startDateTime: string
  endDateTime: string | null
  recordsToProcess: number
  totalRecords: number
  successfulRecords: number
  failedRecords: number
  additionalParams: string | null
}
```

### GET `/process/history/{processSessionId}/route-sessions`

Supported query parameters: `page`, `size`, `sort`.

```ts
interface RouteSessionMonitoring {
  routeSessionId: string
  routeKey: string
  statusCode: ProcessStatusCode
  statusName: string
  startDateTime: string
  endDateTime: string | null
  recordsToProcess: number
  totalRecords: number
  successfulRecords: number
  failedRecords: number
  errorDescription: string | null
}
```

Returns `ApiResponse<Page<RouteSessionMonitoring>>`.

### GET `/process/history/{processSessionId}/thread-sessions`

Supported query parameters:

| Parameter        | Required | Description                           |
| ---------------- | :------: | ------------------------------------- |
| `page`           |   Yes    | Zero-based page                       |
| `size`           |   Yes    | Page size                             |
| `sort`           |   Yes    | Backend sort expression               |
| `routeSessionId` |    No    | Restrict threads to one route session |

Route key, pod and status filters are UI-only state and must not be sent.

```ts
interface ThreadSessionMonitoring {
  threadSessionId: string
  routeSessionId: string | null
  routeKey?: string | null
  threadNumber: number
  maxThreads: number
  statusCode: ProcessStatusCode
  statusName: string
  startDateTime: string
  endDateTime: string | null
  recordsToProcess: number
  totalRecords: number
  successfulRecords: number
  failedRecords: number
  podName: string | null
  errorDescription: string | null
}
```

Returns `ApiResponse<Page<ThreadSessionMonitoring>>`.

There is no separate thread-detail endpoint.

## Schedules

### Models

```ts
type DayOfWeek = 'MON' | 'TUE' | 'WED' | 'THU' | 'FRI' | 'SAT' | 'SUN'

interface ScheduleDay {
  dayOfWeek: DayOfWeek
  startTime: string
  endTime: string
  intervalMin: number
}

interface ScheduleRequest {
  processId: string
  scheduleDays: ScheduleDay[]
}

interface ScheduleResponse extends ScheduleRequest {
  tenantId: string
}

interface TenantScheduleInfo {
  processId: string
  processName: string
  processType: string
  description: string | null
  label: string | null
  scheduleDays: ScheduleDay[]
}
```

Schedule days are displayed and edited in weekday order `MON` through `SUN`,
regardless of the order in which the user added them.

### GET `/process/schedule`

Supported query parameters: `page`, `size`, `sort`.

Search, category and weekday filters are UI-only state and must not be sent.

Returns `ApiResponse<Page<TenantScheduleInfo>>`.

### GET `/process/schedule/{processId}`

Returns `ApiResponse<ScheduleResponse>`.

`404` means no schedule is configured. The frontend maps that response to
`null`; other errors remain errors.

### POST `/process/schedule`

Body: `ScheduleRequest`. Creates a schedule and returns an empty `200` response.

### PUT `/process/schedule`

Body: `ScheduleRequest`. Replaces a schedule and returns an empty `200` response.

### DELETE `/process/schedule`

```json
{
  "processId": "770e8400-e29b-41d4-a716-446655440002"
}
```

Returns an empty `204` response.

## Contract change checklist

Follow [`docs/api-contract-update.md`](docs/api-contract-update.md). At minimum:

1. Update this document.
2. Update `src/entities/*/model` and `src/entities/*/api`.
3. Include tenant UUID in new tenant-aware query keys.
4. Update `mock-server/index.js`.
5. Update API and user-flow tests.
6. Run typecheck, relevant tests and production build.
