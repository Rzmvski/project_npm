import crypto from 'node:crypto'
import { readFileSync } from 'node:fs'
import express from 'express'

import { createCompletedSession, statusNames, stores, tenants } from './data.js'

const app = express()
const port = Number(process.env.MOCK_PORT ?? 8080)
const base = '/api/v1'

const roleModelXml = readFileSync(new URL('../roleModel.xml', import.meta.url), 'utf8')

function parseRolePermissions(xml) {
  const result = new Map()
  const rolePattern = /<role\s+code="([^"]+)"[^>]*>([\s\S]*?)<\/role>/g

  for (const match of xml.matchAll(rolePattern)) {
    const permissions = [...match[2].matchAll(/<permission-ref\s+id="([^"]+)"/g)].map(
      (permission) => permission[1],
    )
    result.set(match[1], permissions)
  }

  return result
}

const permissionsByRole = parseRolePermissions(roleModelXml)
const defaultRoles = process.env.MOCK_USER_ROLES ?? 'SUPER_ADMIN'

function splitRoles(value) {
  return value
    .split(',')
    .map((role) => role.trim())
    .filter(Boolean)
}

// Resolved per request (not once at startup) so a local dev switcher can pick
// a different role via the `x-mock-roles` header without restarting the mock
// server. Falls back to MOCK_USER_ROLES, then the SUPER_ADMIN default.
function resolveActiveRoles(request) {
  const headerRoles = request.header('x-mock-roles')
  return splitRoles(headerRoles && headerRoles.trim() ? headerRoles : defaultRoles)
}

function resolveActivePermissions(roles) {
  return new Set(roles.flatMap((role) => permissionsByRole.get(role) ?? []))
}

function resolveMockUser(request) {
  const roles = resolveActiveRoles(request)
  return {
    login: process.env.MOCK_USER_LOGIN ?? 'user@example.com',
    displayName: process.env.MOCK_USER_NAME ?? 'Тестовый пользователь',
    roles,
  }
}

function resolveMockAccess(request) {
  return [...resolveActivePermissions(resolveActiveRoles(request))].sort()
}

const permission = {
  processTypes: 'processService_getTypes',
  processList: 'processService_getAll',
  processCreate: 'processService_create',
  processUpdate: 'processService_update',
  processDelete: 'processService_delete',
  processStart: 'executeService_executeCommand',
  processStartWithParams: 'executeService_executeWithParams',
  processStop: 'executeService_stopCommand',
  processHistory: 'historyService_getHistory',
  processHistoryDetails: 'historyService_getDetailed',
  processHistoryErrorDetails: 'historyService_getErrorDetails',
  scheduleList: 'scheduleService_getAll',
  scheduleReadProcess: 'scheduleService_getByProcessId',
  scheduleCreate: 'scheduleService_create',
  scheduleUpdate: 'scheduleService_update',
  scheduleDelete: 'scheduleService_delete',
}

function requiredPermissions(request) {
  const path = request.path
  const method = request.method

  if (path === '/user/permissions') return { all: [], any: [] }

  if (path === '/process/schedule' && method === 'GET') {
    return { all: [permission.scheduleList], any: [] }
  }
  if (/^\/process\/schedule\/[^/]+$/.test(path) && method === 'GET') {
    return { all: [permission.scheduleReadProcess], any: [] }
  }
  if (path === '/process/schedule' && method === 'POST') {
    return { all: [permission.scheduleCreate], any: [] }
  }
  if (path === '/process/schedule' && method === 'PUT') {
    return { all: [permission.scheduleUpdate], any: [] }
  }
  if (path === '/process/schedule' && method === 'DELETE') {
    return { all: [permission.scheduleDelete], any: [] }
  }

  if (path === '/routes') {
    return { all: [], any: [permission.processCreate, permission.processUpdate] }
  }
  if (path === '/process/types') {
    return { all: [permission.processTypes], any: [] }
  }
  if (path === '/process' && method === 'GET') {
    return { all: [permission.processList], any: [] }
  }
  if (path === '/process' && method === 'POST') {
    return { all: [permission.processCreate], any: [] }
  }
  if (/^\/process\/[^/]+$/.test(path) && method === 'PUT') {
    return { all: [permission.processUpdate], any: [] }
  }
  if (/^\/process\/[^/]+$/.test(path) && method === 'DELETE') {
    return { all: [permission.processDelete], any: [] }
  }
  if (path === '/process/start') {
    const hasAdditionalParams =
      request.body?.additionalParams && Object.keys(request.body.additionalParams).length > 0
    return {
      all: hasAdditionalParams
        ? [permission.processStart, permission.processStartWithParams]
        : [permission.processStart],
      any: [],
    }
  }
  if (path.startsWith('/process/stop/')) {
    return { all: [permission.processStop], any: [] }
  }
  if (path === '/process/history') {
    return { all: [permission.processHistory], any: [] }
  }
  if (path.startsWith('/process/history/')) {
    return { all: [permission.processHistoryDetails], any: [] }
  }

  return { all: [], any: [] }
}

app.use(express.json({ limit: '1mb' }))
app.use((request, response, next) => {
  response.setHeader('Access-Control-Allow-Origin', request.headers.origin ?? '*')
  response.setHeader('Access-Control-Allow-Headers', 'Content-Type, tenant-id, x-mock-roles')
  response.setHeader('Access-Control-Allow-Credentials', 'true')
  response.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS')
  if (request.method === 'OPTIONS') return response.sendStatus(204)
  next()
})

const api = (data, description = 'OK', status = 'SUCCESS') => ({
  status,
  description,
  data,
})

const fail = (response, statusCode, description, status = 'ERROR') =>
  response.status(statusCode).json(api(null, description, status))

function tenantMiddleware(request, response, next) {
  const tenantId = request.header('tenant-id')
  if (!tenantId) {
    return fail(response, 400, 'Header tenant-id is required', 'BAD_REQUEST')
  }

  const store = stores.get(tenantId)
  if (!store) return fail(response, 404, 'Tenant not found', 'NOT_FOUND')

  request.tenantId = tenantId
  request.store = store
  next()
}

function sortState(sort) {
  const sorted = Boolean(sort)
  return { empty: !sorted, sorted, unsorted: !sorted }
}

function page(items, pageNumber = 0, size = 20, sort) {
  const safePage = Math.max(0, Number(pageNumber) || 0)
  const safeSize = Math.max(1, Math.min(1000, Number(size) || 20))
  const start = safePage * safeSize
  const content = items.slice(start, start + safeSize)
  const totalPages = items.length === 0 ? 0 : Math.ceil(items.length / safeSize)
  const sortInfo = sortState(sort)

  return {
    content,
    pageable: {
      pageNumber: safePage,
      pageSize: safeSize,
      sort: sortInfo,
      offset: start,
      paged: true,
      unpaged: false,
    },
    totalPages,
    totalElements: items.length,
    last: totalPages === 0 || safePage >= totalPages - 1,
    size: safeSize,
    number: safePage,
    sort: sortInfo,
    numberOfElements: content.length,
    first: safePage === 0,
    empty: content.length === 0,
  }
}

function parseSort(value, fallbackField = 'startDateTime', fallbackDirection = 'desc') {
  if (!value) return [fallbackField, fallbackDirection]
  const raw = String(value)
  const [field, direction] = raw.includes(':') ? raw.split(':') : raw.split(',')
  return [field || fallbackField, direction === 'asc' ? 'asc' : 'desc']
}

function sortBy(items, sort, aliases = {}, fallbackField, fallbackDirection) {
  const [rawField, direction] = parseSort(sort, fallbackField, fallbackDirection)
  const field = aliases[rawField] ?? rawField

  return [...items].sort((left, right) => {
    const a = left[field] ?? ''
    const b = right[field] ?? ''
    const comparison =
      typeof a === 'number' && typeof b === 'number'
        ? a - b
        : String(a).localeCompare(String(b))
    return comparison * (direction === 'asc' ? 1 : -1)
  })
}

function processTargets(process) {
  return [
    ...process.routes,
    ...(process.dbSets ?? []).map((routeKey) => ({ routeKey, isLabel: true })),
  ]
}

function processDto(process) {
  return {
    id: process.id,
    processName: process.processName,
    processType: process.processType,
    description: process.description,
    label: process.label,
    routes: processTargets(process),
    cmd: process.cmd ?? '',
  }
}

function mutationDto(process) {
  return {
    processId: process.id,
    processName: process.processName,
    processType: process.processType,
    description: process.description,
    label: process.label,
  }
}

function historyDto(process, session) {
  return {
    processId: process.id,
    processName: process.processName,
    processType: process.processType,
    description: process.description,
    label: process.label,
    isDeleted: process.deleted,
    startDate: session?.startDate ?? null,
    statusCode: session?.statusCode ?? null,
    statusName: session?.statusName ?? null,
    startDateTime: session?.startDateTime ?? null,
    endDateTime: session?.endDateTime ?? null,
    sessionProcessId: session?.sessionProcessId ?? null,
  }
}

function allThreads(session) {
  return [
    ...session.directThreadSessions,
    ...session.routeSessions.flatMap((route) => route.threadSessions),
  ]
}

function saveSchedule(request, response, replace) {
  const { processId, scheduleDays } = request.body ?? {}
  const process = request.store.processes.find((item) => item.id === processId && !item.deleted)

  if (!process) return fail(response, 404, 'Process not found', 'NOT_FOUND')
  if (!Array.isArray(scheduleDays) || !scheduleDays.length) {
    return fail(response, 400, 'scheduleDays is required', 'BAD_REQUEST')
  }
  if (!replace && request.store.schedules.has(processId)) {
    return fail(response, 409, 'Schedule already exists', 'CONFLICT')
  }

  request.store.schedules.set(processId, {
    processId,
    tenantId: request.tenantId,
    scheduleDays,
  })
  response.status(200).end()
}

app.get(['/api/health', `${base}/health`], (_request, response) =>
  response.json({ status: 'UP', port }),
)
app.get(`${base}/tenants`, (_request, response) =>
  response.json(api(tenants, 'TENANTS_LIST_RECEIVED')),
)
app.get(`${base}/user`, (request, response) =>
  response.json(api(resolveMockUser(request), 'User profile retrieved successfully')),
)

app.use(base, (request, response, next) => {
  if (request.path === '/tenants' || request.path === '/health') return next()
  return tenantMiddleware(request, response, next)
})

app.get(`${base}/user/permissions`, (request, response) => {
  response.json(api(resolveMockAccess(request), 'Permissions retrieved successfully'))
})

app.use(base, (request, response, next) => {
  const required = requiredPermissions(request)

  if (required.all.length === 0 && required.any.length === 0) return next()

  const activePermissions = resolveActivePermissions(resolveActiveRoles(request))
  const hasAll = required.all.every((permissionId) => activePermissions.has(permissionId))
  const hasAny =
    required.any.length === 0 ||
    required.any.some((permissionId) => activePermissions.has(permissionId))

  if (hasAll && hasAny) {
    return next()
  }

  const missingAll = required.all.filter((permissionId) => !activePermissions.has(permissionId))
  const description = missingAll.length
    ? `Missing permission: ${missingAll.join(' and ')}`
    : `Missing one of permissions: ${required.any.join(' or ')}`
  return fail(response, 403, description, 'FORBIDDEN')
})

app.get(`${base}/routes`, (request, response) => {
  response.json(
    api(
      { tenantId: request.tenantId, routes: request.store.routes },
      'Routes retrieved successfully',
    ),
  )
})

app.get(`${base}/process/types`, (request, response) => {
  response.json(
    api(
      { processTypes: [...request.store.processTypes].sort() },
      'Process types retrieved successfully',
    ),
  )
})

app.get(`${base}/process/schedule`, (request, response) => {
  const items = [...request.store.schedules.values()].map((schedule) => {
    const process = request.store.processes.find((item) => item.id === schedule.processId)
    return {
      processId: schedule.processId,
      processName: process?.processName ?? 'Unknown process',
      processType: process?.processType ?? 'UNKNOWN',
      description: process?.description ?? null,
      label: process?.label ?? null,
      scheduleDays: schedule.scheduleDays,
    }
  })

  const query = String(request.query.q ?? '')
    .trim()
    .toLocaleLowerCase('ru')
  const categories = String(request.query.category ?? '')
    .split(',')
    .filter(Boolean)
  const days = String(request.query.day ?? '')
    .split(',')
    .filter(Boolean)
  const filtered = items.filter((item) => {
    const matchesQuery = !query || item.processName.toLocaleLowerCase('ru').includes(query)
    const matchesCategory =
      !categories.length || (item.label && categories.includes(item.label))
    const matchesDay =
      !days.length || item.scheduleDays.some(({ dayOfWeek }) => days.includes(dayOfWeek))

    return matchesQuery && matchesCategory && matchesDay
  })

  const sorted = sortBy(filtered, request.query.sort, {}, 'processName', 'asc')
  response.json(
    api(
      page(sorted, request.query.page, request.query.size, request.query.sort),
      'Schedules retrieved successfully',
    ),
  )
})

app.get(`${base}/process/schedule/:processId`, (request, response) => {
  const schedule = request.store.schedules.get(request.params.processId)
  if (!schedule) {
    return fail(response, 404, 'Schedule not found for process', 'NOT_FOUND')
  }
  response.json(api(schedule, 'Schedule retrieved successfully'))
})
app.post(`${base}/process/schedule`, (request, response) =>
  saveSchedule(request, response, false),
)
app.put(`${base}/process/schedule`, (request, response) =>
  saveSchedule(request, response, true),
)
app.delete(`${base}/process/schedule`, (request, response) => {
  const processId = request.body?.processId
  if (!request.store.schedules.has(processId)) {
    return fail(response, 404, 'Schedule not found', 'NOT_FOUND')
  }
  request.store.schedules.delete(processId)
  response.status(204).end()
})

app.get(`${base}/process`, (request, response) => {
  const processes = request.store.processes
    .filter((process) => !process.deleted)
    .map(processDto)
  response.json(api(processes, 'Processes retrieved successfully'))
})

app.post(`${base}/process`, (request, response) => {
  const {
    rqUid,
    processName,
    processType,
    description = null,
    label = null,
    routes,
    cmd = null,
  } = request.body ?? {}

  if (
    !rqUid ||
    !processName ||
    !processType ||
    !Array.isArray(routes) ||
    typeof cmd !== 'string' ||
    !cmd.trim()
  ) {
    return fail(
      response,
      400,
      'rqUid, processName, processType, routes and cmd are required',
      'BAD_REQUEST',
    )
  }
  if (!request.store.processTypes.has(processType)) {
    return fail(response, 400, 'Unsupported processType', 'BAD_REQUEST')
  }
  if (
    request.store.processes.some(
      (process) => !process.deleted && process.processName === processName,
    )
  ) {
    return fail(response, 409, 'Process with this name already exists', 'CONFLICT')
  }

  const process = {
    id: crypto.randomUUID(),
    processName,
    processType,
    description,
    label,
    dbSets: routes.filter((route) => route.isLabel).map((route) => route.routeKey),
    routes: routes
      .filter((route) => !route.isLabel)
      .map((route) => ({ routeKey: route.routeKey, isLabel: false })),
    cmd,
    deleted: false,
    createdAt: new Date().toISOString(),
  }

  request.store.processes.push(process)
  response.json(api(mutationDto(process), 'Process created successfully'))
})

app.put(`${base}/process/:processId`, (request, response) => {
  const process = request.store.processes.find(
    (item) => item.id === request.params.processId && !item.deleted,
  )
  if (!process) return fail(response, 404, 'Process not found', 'NOT_FOUND')

  const { rqUid, processName, processType, description, label, routes, cmd } =
    request.body ?? {}

  if (
    !rqUid ||
    !processName ||
    !processType ||
    !Array.isArray(routes) ||
    typeof cmd !== 'string' ||
    !cmd.trim()
  ) {
    return fail(
      response,
      400,
      'rqUid, processName, processType, routes and cmd are required',
      'BAD_REQUEST',
    )
  }
  if (!request.store.processTypes.has(processType)) {
    return fail(response, 400, 'Unsupported processType', 'BAD_REQUEST')
  }

  process.processName = processName
  process.processType = processType
  if ('description' in request.body) process.description = description ?? null
  if ('label' in request.body) process.label = label ?? null
  if (Array.isArray(routes)) {
    process.dbSets = routes.filter((route) => route.isLabel).map((route) => route.routeKey)
    process.routes = routes
      .filter((route) => !route.isLabel)
      .map((route) => ({ routeKey: route.routeKey, isLabel: false }))
  }
  process.cmd = cmd

  response.json(api(mutationDto(process), 'Process updated successfully'))
})

app.delete(`${base}/process/:processId`, (request, response) => {
  const process = request.store.processes.find(
    (item) => item.id === request.params.processId && !item.deleted,
  )
  if (!process) return fail(response, 404, 'Process not found', 'NOT_FOUND')
  process.deleted = true
  response.json(api(null, 'Process soft-deleted successfully'))
})

app.post(`${base}/process/start`, (request, response) => {
  const {
    rqUid,
    processId,
    additionalParams = {},
    login = null,
    startDate = null,
  } = request.body ?? {}
  const process = request.store.processes.find((item) => item.id === processId && !item.deleted)
  if (!rqUid || !process) {
    return fail(response, 400, 'Cannot start process', 'BAD_REQUEST')
  }

  const now = new Date().toISOString().slice(0, 19)
  const routeKeys = processTargets(process).map((route) => route.routeKey)
  const running = createCompletedSession(process.id, 'SUCCESS', 0, routeKeys)
  running.statusCode = 'WORKS'
  running.statusName = statusNames.WORKS
  running.startDate = startDate ?? now.slice(0, 10)
  running.startDateTime = now
  running.endDateTime = null
  running.additionalParams = JSON.stringify({ ...additionalParams, login })
  running.routeSessions.forEach((route) => {
    route.statusCode = 'WORKS'
    route.statusName = statusNames.WORKS
    route.endDateTime = null
    route.threadSessions.forEach((thread) => {
      thread.statusCode = 'WORKS'
      thread.statusName = statusNames.WORKS
      thread.endDateTime = null
    })
  })

  request.store.sessions.push(running)
  setTimeout(() => {
    if (running.statusCode !== 'WORKS') return
    const end = new Date().toISOString().slice(0, 19)
    running.statusCode = 'SUCCESS'
    running.statusName = statusNames.SUCCESS
    running.endDateTime = end
    running.routeSessions.forEach((route) => {
      route.statusCode = 'SUCCESS'
      route.statusName = statusNames.SUCCESS
      route.endDateTime = end
      route.threadSessions.forEach((thread) => {
        thread.statusCode = 'SUCCESS'
        thread.statusName = statusNames.SUCCESS
        thread.endDateTime = end
      })
    })
  }, 9_000)

  response.json(
    api({ processSessionId: running.sessionProcessId }, 'Process started successfully'),
  )
})

app.post(`${base}/process/stop/:processSessionId`, (request, response) => {
  const session = request.store.sessions.find(
    (item) => item.sessionProcessId === request.params.processSessionId,
  )
  if (!session || session.statusCode !== 'WORKS') {
    return fail(response, 400, 'Session is not running', 'BAD_REQUEST')
  }

  const end = new Date().toISOString().slice(0, 19)
  session.statusCode = 'STOPPED'
  session.statusName = statusNames.STOPPED
  session.endDateTime = end
  session.routeSessions.forEach((route) => {
    if (route.statusCode !== 'WORKS') return
    route.statusCode = 'STOPPED'
    route.statusName = statusNames.STOPPED
    route.endDateTime = end
    route.threadSessions.forEach((thread) => {
      if (thread.statusCode !== 'WORKS') return
      thread.statusCode = 'STOPPED'
      thread.statusName = statusNames.STOPPED
      thread.endDateTime = end
    })
  })
  session.directThreadSessions.forEach((thread) => {
    if (thread.statusCode !== 'WORKS') return
    thread.statusCode = 'STOPPED'
    thread.statusName = statusNames.STOPPED
    thread.endDateTime = end
  })
  response.json(api(null, 'Process stopped successfully'))
})

app.get(`${base}/process/history`, (request, response) => {
  const latest = request.store.processes.map((process) => {
    const sessions = request.store.sessions
      .filter((session) => session.processId === process.id)
      .sort((a, b) => String(b.startDateTime).localeCompare(String(a.startDateTime)))
    return { ...historyDto(process, sessions[0]), _createdAt: process.createdAt }
  })

  const query = String(request.query.q ?? '')
    .trim()
    .toLocaleLowerCase('ru')
  const statuses = String(request.query.status ?? '')
    .split(',')
    .filter(Boolean)
  const categories = String(request.query.category ?? '')
    .split(',')
    .filter(Boolean)
  const from = String(request.query.from ?? '')
  const to = String(request.query.to ?? '')
  const filtered = latest.filter((item) => {
    const startDate = item.startDateTime?.slice(0, 10) ?? ''
    const matchesQuery = !query || item.processName.toLocaleLowerCase('ru').includes(query)
    const matchesStatus =
      !statuses.length || (item.statusCode && statuses.includes(item.statusCode))
    const matchesCategory =
      !categories.length || (item.label && categories.includes(item.label))
    const matchesFrom = !from || (startDate && startDate >= from)
    const matchesTo = !to || (startDate && startDate <= to)

    return matchesQuery && matchesStatus && matchesCategory && matchesFrom && matchesTo
  })

  const sorted = sortBy(
    filtered,
    request.query.sort,
    {
      created_at: '_createdAt',
      process_name: 'processName',
      start_date: 'startDate',
      start_date_time: 'startDateTime',
    },
    'startDateTime',
    'desc',
  )

  const result = page(sorted, request.query.page, request.query.size, request.query.sort)
  result.content = result.content.map(({ _createdAt, ...item }) => item)

  response.json(api(result, 'Processes retrieved successfully'))
})

app.get(`${base}/process/history/:sessionProcessId/detail`, (request, response) => {
  const session = request.store.sessions.find(
    (item) => item.sessionProcessId === request.params.sessionProcessId,
  )
  if (!session) {
    return fail(response, 404, 'Process session not found', 'NOT_FOUND')
  }
  const process = request.store.processes.find((item) => item.id === session.processId)
  if (!process) return fail(response, 404, 'Process not found', 'NOT_FOUND')

  response.json(
    api(
      {
        processId: process.id,
        processName: process.processName,
        processType: process.processType,
        description: process.description,
        label: process.label,
        isDeleted: process.deleted,
        startDate: session.startDate,
        processSession: {
          processSessionId: session.sessionProcessId,
          statusCode: session.statusCode,
          statusName: session.statusName,
          startDateTime: session.startDateTime,
          endDateTime: session.endDateTime,
          recordsToProcess: session.recordsToProcess,
          totalRecords: session.totalRecords,
          successfulRecords: session.successfulRecords,
          failedRecords: session.failedRecords,
          additionalParams: session.additionalParams,
        },
      },
      'Process detail retrieved successfully',
    ),
  )
})

app.get(`${base}/process/history/:processSessionId/route-sessions`, (request, response) => {
  const session = request.store.sessions.find(
    (item) => item.sessionProcessId === request.params.processSessionId,
  )
  if (!session) {
    return fail(response, 404, 'Process session not found', 'NOT_FOUND')
  }

  const query = String(request.query.q ?? '')
    .trim()
    .toLocaleLowerCase('ru')
  const statuses = String(request.query.status ?? '')
    .split(',')
    .filter(Boolean)
  const canViewErrorDetails = resolveActivePermissions(resolveActiveRoles(request)).has(
    permission.processHistoryErrorDetails,
  )
  const routes = session.routeSessions
    .map(({ threadSessions, ...route }) => ({
      ...route,
      errorDescription: canViewErrorDetails ? route.errorDescription : null,
    }))
    .filter((route) => {
      const matchesQuery = !query || route.routeKey.toLocaleLowerCase('ru').includes(query)
      const matchesStatus = !statuses.length || statuses.includes(route.statusCode)
      return matchesQuery && matchesStatus
    })
  const sorted = sortBy(routes, request.query.sort, {}, 'startDateTime', 'desc')
  response.json(
    api(
      page(sorted, request.query.page, request.query.size ?? 50, request.query.sort),
      'Route sessions retrieved successfully',
    ),
  )
})

app.get(`${base}/process/history/:processSessionId/thread-sessions`, (request, response) => {
  const session = request.store.sessions.find(
    (item) => item.sessionProcessId === request.params.processSessionId,
  )
  if (!session) {
    return fail(response, 404, 'Process session not found', 'NOT_FOUND')
  }

  const routeKeysBySessionId = new Map(
    session.routeSessions.map((route) => [route.routeSessionId, route.routeKey]),
  )
  const canViewErrorDetails = resolveActivePermissions(resolveActiveRoles(request)).has(
    permission.processHistoryErrorDetails,
  )
  let threads = allThreads(session).map((thread) => ({
    ...thread,
    routeKey: thread.routeSessionId
      ? (routeKeysBySessionId.get(thread.routeSessionId) ?? null)
      : null,
    errorDescription: canViewErrorDetails ? thread.errorDescription : null,
  }))
  if (request.query.routeSessionId) {
    threads = threads.filter((thread) => thread.routeSessionId === request.query.routeSessionId)
  }
  const routeQuery = String(request.query.routeKey ?? '')
    .trim()
    .toLocaleLowerCase('ru')
  const podQuery = String(request.query.pod ?? '')
    .trim()
    .toLocaleLowerCase('ru')
  const statuses = String(request.query.status ?? '')
    .split(',')
    .filter(Boolean)
  threads = threads.filter((thread) => {
    const matchesRoute =
      !routeQuery || thread.routeKey?.toLocaleLowerCase('ru').includes(routeQuery)
    const matchesPod = !podQuery || thread.podName?.toLocaleLowerCase('ru').includes(podQuery)
    const matchesStatus = !statuses.length || statuses.includes(thread.statusCode)
    return matchesRoute && matchesPod && matchesStatus
  })
  const sorted = sortBy(threads, request.query.sort, {}, 'startDateTime', 'desc')
  response.json(
    api(
      page(sorted, request.query.page, request.query.size ?? 50, request.query.sort),
      'Thread sessions retrieved successfully',
    ),
  )
})

app.use((error, _request, response, _next) => {
  console.error(error)
  fail(response, 500, error instanceof Error ? error.message : 'Internal server error')
})

app.listen(port, () => {
  console.log(`Mock Process Manager API: http://localhost:${port}${base}`)
})
