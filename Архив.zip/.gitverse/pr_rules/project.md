# Project context

Platform Process Manager UI is a React 19, TypeScript and Vite application with
an Express mock API. It manages processes, execution history and weekly
schedules in a selected tenant.

Review against these sources of truth:

- REST contract: `API_DOCUMENTATION.md`;
- roles and permissions: `roleModel.xml`;
- UI abilities: `src/entities/access/model/abilities.ts`;
- entity DTOs: `src/entities/*/model/types.ts`;
- local backend behavior: `mock-server/index.js`;
- architecture and testing rules: `docs/architecture.md`, `docs/testing.md`.

Flag undocumented endpoint, DTO or permission changes. Require tests for
observable behavior changes and report missing validation explicitly.
