# Architecture review rules

- Preserve FSD direction:
  `app -> pages -> widgets -> features -> entities -> shared`.
- Import other slices only through public `index.ts` entry points.
- Do not create sibling-slice imports inside the same FSD layer.
- Keep TanStack hash history for production IAM deployment. Internal route
  definitions and navigation targets remain paths without the `#` prefix.
- Tenant UUID is context, not a route parameter.
- Tenant-aware requests must send `tenant-id`.
- Tenant-aware React Query keys must include tenant UUID.
- Use `@v-uik/base` and existing design tokens instead of duplicate controls.
- Editable forms use React Hook Form and Zod.
- Monitoring and schedule catalogs remain server-paginated.
- UI-only filters must not leak into backend requests.
