# Security and quality review rules

- UI authorization checks use `Ability`, not raw permission IDs or role names.
- Keep `roleModel.xml`, frontend permissions, abilities and mock authorization
  synchronized.
- `SUPER_ADMIN` may operate across tenants; `ADMIN` and `USER` are tenant
  scoped; `USER` remains read-only where the product contract requires it.
- Role switching must not be available outside Vite dev mode.
- `GET /user` does not require `tenant-id`.
- `GET /user/permissions` requires `tenant-id` and returns
  `ApiResponse<string[]>`.
- Do not expose unnecessary identity data in the UI or logs.
- Prefer focused tests plus explicit lint, typecheck and build commands.
