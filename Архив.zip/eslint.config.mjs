import path from 'node:path'
import fs from 'node:fs'
import { fileURLToPath } from 'node:url'

import eslint from '@eslint/js'
import boundaries from 'eslint-plugin-boundaries'
import importPlugin from 'eslint-plugin-import'
import reactHooks from 'eslint-plugin-react-hooks'
import reactRefresh from 'eslint-plugin-react-refresh'
import globals from 'globals'
import tseslint from 'typescript-eslint'
import prettier from 'eslint-config-prettier'

const root = path.dirname(fileURLToPath(import.meta.url))
const layers = ['app', 'pages', 'widgets', 'features', 'entities', 'shared']
const layerWeight = new Map(layers.map((layer, index) => [layer, layers.length - index]))
const slicedLayers = new Set(['pages', 'widgets', 'features', 'entities'])
const conventionalSegments = new Set(['api', 'config', 'lib', 'model', 'ui'])

function directoryHasTypeScript(directory) {
  if (!fs.existsSync(directory)) return false

  return fs.readdirSync(directory, { withFileTypes: true }).some((entry) => {
    const entryPath = path.join(directory, entry.name)
    if (entry.isDirectory()) return directoryHasTypeScript(entryPath)
    return entry.isFile() && /\.tsx?$/.test(entry.name) && entry.name !== 'index.ts'
  })
}

function collectPublicApiDirectories() {
  const sourceRoot = path.join(root, 'src')
  const directories = layers.map((layer) => path.join(sourceRoot, layer))

  for (const layer of slicedLayers) {
    const layerDirectory = path.join(sourceRoot, layer)
    if (!fs.existsSync(layerDirectory)) continue

    for (const slice of fs.readdirSync(layerDirectory, { withFileTypes: true })) {
      if (!slice.isDirectory()) continue
      const sliceDirectory = path.join(layerDirectory, slice.name)
      directories.push(sliceDirectory)

      for (const segment of fs.readdirSync(sliceDirectory, { withFileTypes: true })) {
        if (!segment.isDirectory() || !conventionalSegments.has(segment.name)) continue
        const segmentDirectory = path.join(sliceDirectory, segment.name)
        if (directoryHasTypeScript(segmentDirectory)) directories.push(segmentDirectory)
      }
    }
  }

  const sharedDirectory = path.join(sourceRoot, 'shared')
  if (fs.existsSync(sharedDirectory)) {
    for (const namespace of fs.readdirSync(sharedDirectory, { withFileTypes: true })) {
      if (!namespace.isDirectory()) continue
      const namespaceDirectory = path.join(sharedDirectory, namespace.name)
      if (directoryHasTypeScript(namespaceDirectory)) directories.push(namespaceDirectory)

      for (const segment of fs.readdirSync(namespaceDirectory, { withFileTypes: true })) {
        if (!segment.isDirectory()) continue
        const segmentDirectory = path.join(namespaceDirectory, segment.name)
        if (directoryHasTypeScript(segmentDirectory)) directories.push(segmentDirectory)
      }
    }
  }

  return [...new Set(directories)]
}

function getFsdLocation(filename) {
  const relative = path.relative(path.join(root, 'src'), filename).replaceAll(path.sep, '/')
  const [layer, slice] = relative.split('/')
  return { layer, slice, relative }
}

function parseImportTarget(source, filename) {
  if (source.startsWith('@/')) {
    const [layer, slice, ...rest] = source.slice(2).split('/')
    return { layer, slice, rest, source, isRelative: false }
  }

  if (source.startsWith('.')) {
    const resolved = path.resolve(path.dirname(filename), source)
    const target = getFsdLocation(resolved)
    return { ...target, rest: [], source, isRelative: true }
  }

  return null
}

const fsdPlugin = {
  rules: {
    'layer-imports': {
      meta: {
        type: 'problem',
        docs: { description: 'Enforce Feature-Sliced Design layer dependency direction' },
        schema: [],
        messages: {
          higherLayer: '{{from}} cannot import from higher layer {{to}}',
          crossSlice: '{{layer}} slice {{fromSlice}} cannot import sibling slice {{toSlice}}',
        },
      },
      create(context) {
        const current = getFsdLocation(context.filename)

        return {
          ImportDeclaration(node) {
            const target = parseImportTarget(node.source.value, context.filename)
            if (!target || !layerWeight.has(current.layer) || !layerWeight.has(target.layer))
              return

            const currentWeight = layerWeight.get(current.layer)
            const targetWeight = layerWeight.get(target.layer)

            if (targetWeight > currentWeight) {
              context.report({
                node: node.source,
                messageId: 'higherLayer',
                data: { from: current.layer, to: target.layer },
              })
              return
            }

            if (
              current.layer === target.layer &&
              slicedLayers.has(current.layer) &&
              current.slice !== target.slice
            ) {
              context.report({
                node: node.source,
                messageId: 'crossSlice',
                data: {
                  layer: current.layer,
                  fromSlice: current.slice,
                  toSlice: target.slice,
                },
              })
            }
          },
        }
      },
    },
    'public-api': {
      meta: {
        type: 'problem',
        docs: { description: 'Require imports through FSD segment or slice public API' },
        schema: [],
        messages: {
          deepImport:
            'Import {{source}} bypasses a public API. Import from {{publicApi}} instead.',
          crossBoundaryRelative:
            'Relative import {{source}} crosses an FSD boundary. Import from {{publicApi}} instead.',
        },
      },
      create(context) {
        return {
          ImportDeclaration(node) {
            const target = parseImportTarget(node.source.value, context.filename)
            if (!target) return

            const current = getFsdLocation(context.filename)
            const publicApi = `@/${target.layer}/${target.slice}`

            if (target.isRelative) {
              const crossesLayer = current.layer !== target.layer
              const crossesSlice =
                current.layer === target.layer &&
                (slicedLayers.has(current.layer) || current.layer === 'shared') &&
                current.slice !== target.slice

              if (crossesLayer || crossesSlice) {
                context.report({
                  node: node.source,
                  messageId: 'crossBoundaryRelative',
                  data: { source: target.source, publicApi },
                })
              }
              return
            }

            const depth = [target.layer, target.slice, ...target.rest].filter(Boolean).length
            if (depth <= 2) return

            context.report({
              node: node.source,
              messageId: 'deepImport',
              data: { source: target.source, publicApi },
            })
          },
        }
      },
    },
    'slice-index': {
      meta: {
        type: 'problem',
        docs: { description: 'Require an index.ts public API for every FSD slice' },
        schema: [],
        messages: { missing: 'FSD slice {{slice}} must expose public API in {{indexPath}}' },
      },
      create(context) {
        const current = getFsdLocation(context.filename)
        if (current.relative === `${current.layer}/index.ts`) return {}
        if (!slicedLayers.has(current.layer) || !current.slice) return {}

        const indexPath = path.join(root, 'src', current.layer, current.slice, 'index.ts')
        if (fs.existsSync(indexPath)) return {}

        return {
          Program(node) {
            context.report({
              node,
              messageId: 'missing',
              data: {
                slice: `${current.layer}/${current.slice}`,
                indexPath: path.relative(root, indexPath),
              },
            })
          },
        }
      },
    },
    'public-api-files': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Require public API index.ts files for FSD layers, slices, and segments',
        },
        schema: [],
        messages: {
          missing: 'Public API is missing: {{indexPath}}',
        },
      },
      create(context) {
        const current = getFsdLocation(context.filename)
        if (current.relative !== 'main.tsx') return {}

        const missing = collectPublicApiDirectories()
          .map((directory) => path.join(directory, 'index.ts'))
          .filter((indexPath) => !fs.existsSync(indexPath))

        if (!missing.length) return {}

        return {
          Program(node) {
            for (const indexPath of missing) {
              context.report({
                node,
                messageId: 'missing',
                data: { indexPath: path.relative(root, indexPath) },
              })
            }
          },
        }
      },
    },
  },
}

export default tseslint.config(
  { ignores: ['dist/**', 'node_modules/**', 'coverage/**', 'mock-server/**'] },
  eslint.configs.recommended,
  ...tseslint.configs.recommended,
  {
    files: ['**/*.{ts,tsx}'],
    languageOptions: {
      ecmaVersion: 'latest',
      sourceType: 'module',
      globals: { ...globals.browser, ...globals.es2022 },
      parserOptions: {
        projectService: true,
        tsconfigRootDir: root,
      },
    },
    plugins: {
      import: importPlugin,
      boundaries,
      'react-hooks': reactHooks,
      'react-refresh': reactRefresh,
      fsd: fsdPlugin,
    },
    settings: {
      'import/resolver': {
        typescript: { project: './tsconfig.app.json' },
      },
      'boundaries/include': ['src/**/*'],
      'boundaries/elements': [
        { type: 'app', pattern: 'src/app/**' },
        { type: 'page', pattern: 'src/pages/*/**', capture: ['slice'] },
        { type: 'widget', pattern: 'src/widgets/*/**', capture: ['slice'] },
        { type: 'feature', pattern: 'src/features/*/**', capture: ['slice'] },
        { type: 'entity', pattern: 'src/entities/*/**', capture: ['slice'] },
        { type: 'shared', pattern: 'src/shared/**' },
      ],
    },
    rules: {
      ...reactHooks.configs.recommended.rules,
      ...reactRefresh.configs.vite.rules,
      'boundaries/no-unknown-dependencies': 'error',
      'boundaries/no-unknown-files': 'error',
      'boundaries/dependencies': [
        'error',
        {
          default: 'disallow',
          policies: [
            {
              from: { element: { type: 'app' } },
              allow: {
                to: {
                  element: {
                    types: { anyOf: ['app', 'page', 'widget', 'feature', 'entity', 'shared'] },
                  },
                },
              },
            },
            {
              from: { element: { type: 'page' } },
              allow: {
                to: {
                  element: {
                    types: { anyOf: ['page', 'widget', 'feature', 'entity', 'shared'] },
                  },
                },
              },
            },
            {
              from: { element: { type: 'widget' } },
              allow: {
                to: {
                  element: { types: { anyOf: ['widget', 'feature', 'entity', 'shared'] } },
                },
              },
            },
            {
              from: { element: { type: 'feature' } },
              allow: {
                to: { element: { types: { anyOf: ['feature', 'entity', 'shared'] } } },
              },
            },
            {
              from: { element: { type: 'entity' } },
              allow: { to: { element: { types: { anyOf: ['entity', 'shared'] } } } },
            },
            {
              from: { element: { type: 'shared' } },
              allow: { to: { element: { type: 'shared' } } },
            },
          ],
        },
      ],
      'fsd/layer-imports': 'error',
      'fsd/public-api': 'error',
      'fsd/slice-index': 'error',
      'fsd/public-api-files': 'error',
      'import/no-cycle': ['error', { maxDepth: 8, ignoreExternal: true }],
      'import/no-duplicates': 'error',
      'import/order': [
        'error',
        {
          groups: ['builtin', 'external', 'internal', 'parent', 'sibling', 'index', 'type'],
          pathGroups: [{ pattern: '@/**', group: 'internal', position: 'before' }],
          alphabetize: { order: 'asc', caseInsensitive: true },
          'newlines-between': 'always',
        },
      ],
      '@typescript-eslint/consistent-type-imports': [
        'error',
        { prefer: 'type-imports', fixStyle: 'inline-type-imports' },
      ],
      '@typescript-eslint/no-explicit-any': 'error',
      '@typescript-eslint/no-unused-vars': [
        'error',
        { argsIgnorePattern: '^_', varsIgnorePattern: '^_', caughtErrorsIgnorePattern: '^_' },
      ],
      'prefer-destructuring': [
        'error',
        { array: false, object: true },
        { enforceForRenamedProperties: false },
      ],
      'no-restricted-syntax': [
        'error',
        {
          selector:
            "JSXOpeningElement[name.name='button'], JSXOpeningElement[name.name='input'], JSXOpeningElement[name.name='select'], JSXOpeningElement[name.name='textarea']",
          message: 'Use the corresponding component from @v-uik/base.',
        },
      ],
    },
  },
  {
    files: [
      'src/main.tsx',
      'src/vite-env.d.ts',
      'src/{pages,widgets,features,entities}/index.ts',
    ],
    rules: {
      'boundaries/no-unknown-files': 'off',
      'boundaries/no-unknown-dependencies': 'off',
    },
  },
  {
    files: ['src/shared/ui/**/*.{ts,tsx}'],
    rules: {
      'no-restricted-imports': [
        'error',
        {
          patterns: [
            {
              group: ['@v-uik/theme', '@v-uik/theme/*'],
              message: 'Platform V theme configuration belongs to shared/config/theme.',
            },
          ],
        },
      ],
    },
  },
  {
    files: [
      'vite.config.ts',
      'vitest.config.ts',
      'eslint.config.mjs',
      'stylelint.config.mjs',
      'commitlint.config.mjs',
    ],
    languageOptions: { globals: { ...globals.node } },
    rules: {
      'boundaries/no-unknown-files': 'off',
      'boundaries/no-unknown-dependencies': 'off',
      'fsd/layer-imports': 'off',
      'fsd/public-api': 'off',
      'fsd/slice-index': 'off',
      'fsd/public-api-files': 'off',
    },
  },
  {
    files: [
      'src/test/**/*.{ts,tsx}',
      'src/**/*.{test,spec}.{ts,tsx}',
      'src/**/*.test-model.{ts,tsx}',
    ],
    rules: {
      'boundaries/no-unknown-dependencies': 'off',
      'boundaries/no-unknown-files': 'off',
      'boundaries/dependencies': 'off',
      'fsd/layer-imports': 'off',
      'fsd/public-api': 'off',
      'fsd/slice-index': 'off',
      'import/no-cycle': 'off',
      'react-refresh/only-export-components': 'off',
      'no-restricted-syntax': 'off',
      '@typescript-eslint/no-explicit-any': 'off',
    },
  },
  prettier,
)
