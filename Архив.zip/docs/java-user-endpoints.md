# Java user endpoints with Spring Security

This guide implements the user contracts required by the UI around an existing,
immutable authentication library.

Target stack: Java 17+, Spring Boot 3 and Spring Security 6.

## Required HTTP contracts

```http
GET /api/v1/user
```

```json
{
  "status": "SUCCESS",
  "description": "User profile retrieved successfully",
  "data": {
    "login": "user@example.com",
    "displayName": "Иван Иванов",
    "roles": ["ADMIN"]
  }
}
```

```http
GET /api/v1/user/permissions
tenant-id: <uuid>
```

```json
{
  "status": "SUCCESS",
  "description": "Permissions retrieved successfully",
  "data": ["processService_getAll", "historyService_getHistory"]
}
```

The permission endpoint returns `ApiResponse<List<String>>`. Do not add a
`UserPermissionsResponse` wrapper.

## Existing immutable library flow

The supplied library authenticates requests as follows:

```text
BearerAuthenticationFilter / MockAuthenticationFilter
  → AuthenticationManager
  → IamTokenAuthenticatorProvider / MockAuthenticatorProvider
  → UserDetailsService.loadUserByUsername(ticketKey)
  → UfsUser + GrantedAuthority collection
  → authenticated UsernamePasswordAuthenticationToken
  → DelegatingSessionAwareAuthenticationManager
  → SecurityContextHolder
```

Important: the filters do not store the returned `Authentication` themselves.
The `AuthenticationManager` injected into them must therefore be the library's
`DelegatingSessionAwareAuthenticationManager` (or another manager that stores
the successful result in `SecurityContextHolder`). Passing a plain
`ProviderManager` would leave the context empty because the filter ignores the
return value.

After authentication, application code can use:

```java
Authentication authentication;
UfsUser user = (UfsUser) authentication.getPrincipal();
Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
```

Do not set `SecurityContextHolder` again in controllers.

## Recommended responsibility split

```text
Authentication library
  ├── verifies token/ticket
  ├── loads UfsUser
  └── stores IAM roles/global permissions in SecurityContext

Application authorization
  ├── reads user UUID from UfsUser
  ├── loads user → tenant → role assignment from DB
  ├── calculates effective permissions for requested tenant
  ├── protects backend operations
  └── returns the same permission list to UI
```

Tenant access should not be represented only by an unscoped
`SimpleGrantedAuthority`. `hasAuthority("processService_update")` cannot tell
whether that authority belongs to tenant A or tenant B.

Keep identity/global IAM authorities in the context. Resolve tenant scope in a
dedicated application service on every authorization decision, with caching if
needed.

## When the upstream permission service returns `List<String>`

If only `/api/v1/user/permissions` returns strings, no authentication-library
change is required: this endpoint is an output derived from the current
`Authentication` and tenant assignments.

If the upstream endpoint used inside `SpasUserDetailsService` changed from
`List<Form>` to `List<String>`, the immutable implementation cannot deserialize
the new response. Add an application-owned `@Primary UserDetailsService`.

The library providers depend on the `UserDetailsService` interface, so Spring
can select the primary application implementation:

```java
@Service
@Primary
@RequiredArgsConstructor
public class ApplicationUserDetailsService implements UserDetailsService {

    private final PermissionClient permissionClient;
    private final RoleClient roleClient;
    private final UserClient userClient;
    private final Converter<
            Collection<Role>,
            Collection<? extends GrantedAuthority>
    > roleConverter;

    @Override
    public UserDetails loadUserByUsername(String ticketKey) {
        List<String> permissions = permissionClient.getPermissions(ticketKey);
        List<Role> roles = roleClient.getRoles(ticketKey);
        UfsUser user = userClient.getUser(ticketKey)
                .orElseThrow(() -> new UsernameNotFoundException(
                        "User for ticket %s not found".formatted(ticketKey)
                ));

        var authorities = new LinkedHashSet<GrantedAuthority>();

        permissions.stream()
                .filter(Objects::nonNull)
                .map(String::trim)
                .filter(permission -> !permission.isEmpty())
                .filter(UiPermissions::contains)
                .map(SimpleGrantedAuthority::new)
                .forEach(authorities::add);

        Collection<? extends GrantedAuthority> roleAuthorities =
                roleConverter.convert(roles);

        if (roleAuthorities != null) {
            authorities.addAll(roleAuthorities);
        }

        user.setAuthorities(List.copyOf(authorities));
        return user;
    }
}
```

If library configuration injects the concrete `SpasUserDetailsService` instead
of `UserDetailsService`, `@Primary` will not affect it. In that case, replace the
provider/configuration bean through the library's supported auto-configuration
extension point. Avoid `BeanPostProcessor` mutation unless no explicit extension
point exists.

## Database model

Use the stable external UUID from `UfsUser.UUID`, not login, as the user key.
Login can change.

Recommended schema when a user may have a different role in each tenant:

```sql
create table user_tenant_role (
    user_uuid varchar(64) not null,
    tenant_id uuid not null references tenant(id),
    role_code varchar(32) not null,
    primary key (user_uuid, tenant_id, role_code),
    check (role_code in ('ADMIN', 'USER'))
);

create index ix_user_tenant_role_tenant
    on user_tenant_role (tenant_id, user_uuid);
```

`SUPER_ADMIN` remains a global IAM role and does not need one row per tenant.

If one role always applies to all tenants assigned to a user, a simpler
membership table is sufficient:

```sql
create table user_tenant (
    user_uuid varchar(64) not null,
    tenant_id uuid not null references tenant(id),
    primary key (user_uuid, tenant_id)
);
```

Choose one invariant and enforce it. Do not use a membership-only table if the
same user can be `ADMIN` in one tenant and `USER` in another.

## Role permission policy

Tenant roles must be expanded through the same permission model represented by
`roleModel.xml`.

```java
public interface RolePermissionPolicy {

    Set<String> permissionsFor(Collection<String> roleCodes);
}
```

The implementation may load a validated role model at startup or use a map
generated from the same source. Do not maintain an unrelated permission matrix
by hand without a synchronization test.

Filter technical authorities before returning data to the UI:

```java
public final class UiPermissions {

    public static final Set<String> ALL = Set.of(
            "tenantService_getAll",
            "processService_getAll",
            "processService_getTypes",
            "processService_create",
            "processService_update",
            "processService_delete",
            "executeService_executeCommand",
            "executeService_executeWithParams",
            "executeService_stopCommand",
            "historyService_getHistory",
            "historyService_getDetailed",
            "historyService_getErrorDetails",
            "scheduleService_getAll",
            "scheduleService_getByProcessId",
            "scheduleService_create",
            "scheduleService_update",
            "scheduleService_delete"
    );

    private UiPermissions() {
    }

    public static boolean contains(String authority) {
        return ALL.contains(authority);
    }
}
```

## Tenant permission service

Effective tenant permissions are the intersection of:

1. permissions granted to the authenticated user by IAM; and
2. permissions allowed by roles assigned to that user in the requested tenant.

This fails closed if IAM and database assignments disagree.

```java
@Service
@RequiredArgsConstructor
public class TenantPermissionService {

    private static final String SUPER_ADMIN = "ROLE_SUPER_ADMIN";

    private final UserTenantRoleRepository userTenantRoleRepository;
    private final RolePermissionPolicy rolePermissionPolicy;

    public List<String> getPermissions(
            Authentication authentication,
            UUID tenantId
    ) {
        UfsUser user = requireUser(authentication);

        Set<String> iamPermissions = authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .filter(Objects::nonNull)
                .filter(UiPermissions::contains)
                .collect(Collectors.toCollection(HashSet::new));

        if (hasAuthority(authentication, SUPER_ADMIN)) {
            return sorted(iamPermissions);
        }

        Set<String> tenantRoles = userTenantRoleRepository.findRoleCodes(
                user.getUUID(),
                tenantId
        );

        if (tenantRoles.isEmpty()) {
            throw new AccessDeniedException(
                    "User is not assigned to tenant " + tenantId
            );
        }

        Set<String> allowedByTenantRole =
                rolePermissionPolicy.permissionsFor(tenantRoles);

        iamPermissions.retainAll(allowedByTenantRole);
        return sorted(iamPermissions);
    }

    private UfsUser requireUser(Authentication authentication) {
        if (authentication == null
                || !authentication.isAuthenticated()
                || authentication instanceof AnonymousAuthenticationToken
                || !(authentication.getPrincipal() instanceof UfsUser user)) {
            throw new AuthenticationCredentialsNotFoundException(
                    "Authenticated UfsUser is required"
            );
        }

        return user;
    }

    private boolean hasAuthority(
            Authentication authentication,
            String expected
    ) {
        return authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .anyMatch(expected::equals);
    }

    private List<String> sorted(Collection<String> permissions) {
        return permissions.stream().distinct().sorted().toList();
    }
}
```

If permissions are guaranteed identical in every assigned tenant, replace the
role expansion/intersection with a membership check and return the filtered IAM
permissions. Document and test that invariant.

## API DTOs

```java
public record ApiResponse<T>(
        String status,
        String description,
        T data
) {
    public static <T> ApiResponse<T> success(String description, T data) {
        return new ApiResponse<>("SUCCESS", description, data);
    }
}
```

```java
public record UserProfileResponse(
        String login,
        String displayName,
        List<String> roles
) {
}
```

## Current user service

```java
@Service
public class CurrentUserService {

    private static final String ROLE_PREFIX = "ROLE_";

    public UserProfileResponse getProfile(Authentication authentication) {
        if (!(authentication.getPrincipal() instanceof UfsUser user)) {
            throw new AuthenticationCredentialsNotFoundException(
                    "Authenticated UfsUser is required"
            );
        }

        List<String> roles = authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .filter(Objects::nonNull)
                .filter(authority -> authority.startsWith(ROLE_PREFIX))
                .map(authority -> authority.substring(ROLE_PREFIX.length()))
                .distinct()
                .sorted()
                .toList();

        String displayName = Stream.of(
                        user.getLastName(),
                        user.getName(),
                        user.getMiddleName()
                )
                .filter(Objects::nonNull)
                .map(String::trim)
                .filter(value -> !value.isEmpty())
                .collect(Collectors.joining(" "));

        if (displayName.isEmpty()) {
            displayName = user.getUsername();
        }

        return new UserProfileResponse(
                user.getUsername(),
                displayName,
                roles
        );
    }
}
```

If roles differ by tenant, `/user` returns only global/aggregate role
information and is not sufficient for tenant authorization. Tenant-specific
role display should come from the tenant assignment contract, not from a global
role branch in UI code.

## Controller

```java
@RestController
@RequestMapping("/api/v1/user")
@RequiredArgsConstructor
public class CurrentUserController {

    private final CurrentUserService currentUserService;
    private final TenantPermissionService tenantPermissionService;

    @GetMapping
    public ApiResponse<UserProfileResponse> getCurrentUser(
            Authentication authentication
    ) {
        return ApiResponse.success(
                "User profile retrieved successfully",
                currentUserService.getProfile(authentication)
        );
    }

    @GetMapping("/permissions")
    public ApiResponse<List<String>> getPermissions(
            Authentication authentication,
            @RequestHeader("tenant-id") UUID tenantId
    ) {
        return ApiResponse.success(
                "Permissions retrieved successfully",
                tenantPermissionService.getPermissions(authentication, tenantId)
        );
    }
}
```

Missing/invalid `tenant-id` produces `400`. A user not assigned to the tenant
receives `403`.

## Tenant list

`GET /tenants` and `/user/permissions` must use the same assignment source:

```java
public List<TenantDto> getAvailableTenants(Authentication authentication) {
    UfsUser user = requireUser(authentication);

    if (hasAuthority(authentication, "ROLE_SUPER_ADMIN")) {
        return tenantRepository.findAllProjected();
    }

    return tenantRepository.findAssignedToUser(user.getUUID());
}
```

Returning a tenant that the permission service later rejects creates a broken
selection flow. Returning an unassigned tenant is also an authorization leak.

## Protecting business endpoints

The UI permission response is not authorization. Reuse the same service for
backend decisions:

```java
@Component("tenantAuthorization")
@RequiredArgsConstructor
public class TenantAuthorization {

    private final TenantPermissionService tenantPermissionService;

    public boolean hasPermission(
            Authentication authentication,
            UUID tenantId,
            String permission
    ) {
        return tenantPermissionService
                .getPermissions(authentication, tenantId)
                .contains(permission);
    }
}
```

```java
@PreAuthorize("""
        @tenantAuthorization.hasPermission(
            authentication,
            #tenantId,
            'processService_getAll'
        )
        """)
@GetMapping("/api/v1/process")
public ApiResponse<List<ProcessDto>> getProcesses(
        @RequestHeader("tenant-id") UUID tenantId
) {
    // ...
}
```

Compile with Java parameter metadata or otherwise ensure `#tenantId` is
available to method-security expressions.

## Caching

Cache database-derived tenant role permissions, not the entire
`Authentication`:

```text
cache key: user UUID + tenant UUID
value: role-derived permission set
```

Intersect cached role permissions with current IAM authorities on each request.
Evict the cache when a tenant assignment or role changes. Avoid caching by
ticket key or login.

## Required tests

- profile fields and `ROLE_` prefix removal;
- permission response is a JSON string array;
- `SUPER_ADMIN` can resolve every tenant;
- assigned `ADMIN` receives write permissions;
- assigned `USER` receives read permissions only;
- unassigned tenant returns `403`;
- IAM/DB mismatch fails closed through intersection;
- `/tenants` and permission resolution use identical assignment scope;
- business endpoint cannot be accessed by changing only `tenant-id`;
- custom `@Primary UserDetailsService` converts `List<String>` into
  `SimpleGrantedAuthority` when the upstream contract uses strings.

## Avoid

- calling `/user/permissions` internally from business services;
- trusting tenant UUID from the header without checking assignment;
- using login as the permanent user key;
- granting tenant permissions from a global union of all tenant roles;
- relying only on `hasAuthority` when roles differ by tenant;
- storing role/permission rules independently in several unvalidated places;
- changing the immutable authentication library when an application bean or
  authorization service provides a supported extension point.
