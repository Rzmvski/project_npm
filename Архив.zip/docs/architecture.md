# Architecture guide

Use this document before changing application structure, routes, tenant state or
data loading.

## Layer model

```text
app → pages → widgets → features → entities → shared
```

| Layer      | Responsibility                                                    |
| ---------- | ----------------------------------------------------------------- |
| `app`      | Providers, router, guards, layouts and runtime configuration      |
| `pages`    | Route-level compositions and URL/search state                     |
| `widgets`  | Large reusable domain sections and tables                         |
| `features` | User actions and mutations                                        |
| `entities` | Domain types, API calls, queries and small entity UI              |
| `shared`   | API client, generic utilities, theme and application compositions |

Rules enforced by ESLint:

- dependencies move only to the right in the layer chain;
- sliced layers cannot import sibling slices;
- cross-slice imports use the target slice's `index.ts`;
- conventional segments (`api`, `model`, `lib`, `ui`, `config`) expose an
  `index.ts`;
- relative imports are allowed inside one slice.

Correct:

```ts
import { processListQueryOptions } from '@/entities/process'
```

Incorrect:

```ts
import { processListQueryOptions } from '@/entities/process/api/processQueries'
```

## Application boot

```text
AppProviders
├── AppThemeProvider
├── DateLibAdapterProvider
├── QueryClientProvider
├── RouterProvider
└── NotificationContainer
```

Workspace routes run `ensureWorkspace` before rendering. It verifies the saved
tenant, preloads the current user and tenant permissions, then mounts
`WorkspaceProviders` and `AppLayout`.

## Routes

Production navigation uses TanStack Router hash history. Browser URLs have the
form `https://host/application/#/processes`; route definitions, `Link` targets
and `navigate` calls continue to use internal paths such as `/processes`.

| Browser route                  | Required ability                       |
| ------------------------------ | -------------------------------------- |
| `/#/select-tenant`             | Authenticated profile/tenant list only |
| `/#/processes`                 | `PROCESS_LIST`                         |
| `/#/processes/new`             | `PROCESS_CREATE`                       |
| `/#/processes/:processId`      | `PROCESS_DETAILS`                      |
| `/#/processes/:processId/edit` | `PROCESS_UPDATE`                       |
| `/#/history`                   | `PROCESS_HISTORY`                      |
| `/#/history/:sessionProcessId` | `PROCESS_HISTORY_DETAILS`              |
| `/#/schedules`                 | `SCHEDULE_LIST`                        |
| `/#/schedules/:processId`      | `SCHEDULE_READ`                        |
| `/#/schedules/:processId/edit` | `SCHEDULE_EDIT`                        |

The index route selects the first workspace page allowed by the resolved
permissions. A failed ability check redirects to `/forbidden`.

## Tenant flow

Tenant is application context, not route identity.

```text
GET /tenants
  → user selects tenant
  → localStorage: ppm.selectedTenantId
  → GET /user/permissions with tenant-id
  → navigate to first permitted workspace route
```

Rules:

- use `useRequiredTenantId()` inside tenant-aware queries and mutations;
- pass tenant explicitly to entity API functions;
- let `shared/api` create the `tenant-id` header;
- include tenant UUID in every tenant-aware query key;
- never use an unscoped cache key for process, history, route or schedule data;
- tenant switching invalidates tenant state and navigates into the new scope.

## User and access data

User identity and permissions are separate queries:

```text
GET /user                 → UserProfile, tenant-independent
GET /user/permissions     → string[], tenant-dependent
```

`useCurrentUser()` reads the shared user query. `AccessProvider` reads the
tenant permission array and exposes `can`, `canAny` and a permission set.
Components do not query profile or access through ad-hoc fetches.

## Query ownership

- Entity slices define API functions, query keys and query options.
- Pages/widgets consume query options and own view state.
- Features own mutations and invalidation caused by user actions.
- Router guards may preload canonical entity queries.
- Query keys contain only server identity/scope, not duplicated presentation
  state.

## Process data strategy

`GET /process` supplies the server-paginated catalog, read-only process card and
edit form. Catalog queries request one page at a time and retain the returned
optional `cmd`.

Domain terminology:

- `processType`: backend-owned value from `GET /process/types`;
- `label`: user-editable category;
- `RouteTarget` with `isLabel: true`: DB set in execution scope;
- `RouteTarget` with `isLabel: false`: concrete DB route.

Create and update send the full execution scope and command. The UI requires a
non-blank command even though the backend contract marks `cmd` as optional.

## Monitoring loading strategy

The detail page renders one server-paginated table at a time:

1. process session summary;
2. route sessions; or
3. thread sessions, optionally restricted by `routeSessionId`.

View, page, size, sort and selected route live in validated TanStack Router
search state. Search/status/category/date filters are local UI state where the
backend contract does not support them. Do not serialize those filters into API
requests.

## Schedule loading strategy

- The catalog uses paginated `GET /process/schedule`.
- The editor/details use `GET /process/schedule/{processId}`.
- `404` from the single schedule endpoint maps to `null`.
- Weekdays are normalized to `MON → SUN` after every form mutation and before
  preview rendering.
- Do not introduce an N+1 request from the schedule catalog.

## Adding a slice

1. Choose the lowest layer that owns the behavior.
2. Create only required segments.
3. Add segment and slice `index.ts` files.
4. Import the slice through its public API.
5. Add entity query keys with tenant scope where required.
6. Run `npm run lint:architecture` and relevant tests.
