# API documentation moved

The canonical REST contract is
[`../API_DOCUMENTATION.md`](../API_DOCUMENTATION.md).

This compatibility file intentionally contains no copied endpoint definitions.
Update only the root document to prevent contract drift.
