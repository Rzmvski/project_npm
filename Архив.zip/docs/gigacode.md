# GigaCode in this project

The repository uses a project-local GigaCode extension. Its entry point is
`.gigacode/GIGACODE.md`; project rules, skills and subagents are stored inside
`.gigacode/extensions/platform-process-manager-ui/`.

## Structure

```text
.gigacode/
├── GIGACODE.md
└── extensions/
    ├── extension-enablement.json
    └── platform-process-manager-ui/
        ├── GIGACODE.md
        ├── SKILL.md
        ├── gigacode-extension.json
        ├── agents/
        └── skills/

.gitverse/pr_rules/
├── architecture.md
├── project.md
└── security-and-quality.md
```

`extension-enablement.json` enables the extension only where its project-local
directory is discovered. No tokens, personal settings or machine-specific
paths are stored in the repository.

## Subagents

| Subagent                  | Responsibility                                                |
| ------------------------- | ------------------------------------------------------------- |
| `frontend-engineer-agent` | React, FSD, VUIK, forms, routing and UI behavior              |
| `api-contract-agent`      | REST DTOs, entity API clients, mock server and contract tests |
| `access-control-agent`    | Roles, permissions, abilities, guards and tenant scope        |
| `quality-reviewer-agent`  | Read-only review and proportional validation                  |

The main agent selects a profile from `agents/` and delegates only a bounded
part of a task. The main agent remains responsible for integrating the result
and validating the complete change.

## Skills

| Skill                 | Trigger example                               |
| --------------------- | --------------------------------------------- |
| `frontend-change`     | "Измени страницу расписания и добавь тест"    |
| `api-contract-change` | "Переименуй endpoint и обнови mock"           |
| `rbac-change`         | "Добавь permission и распредели его по ролям" |
| `verify-change`       | "Проверь текущие изменения перед merge"       |

GigaCode should choose skills by the `name` and `description` frontmatter in
each `SKILL.md`. Skills contain workflows; detailed project facts remain in the
canonical documents linked from those workflows.

## GitVerse review agent

GigaCode review in merge requests loads all Markdown files from
`.gitverse/pr_rules/`. These files contain a compact review-oriented copy of
the non-negotiable project rules. Product and API details remain canonical in
`API_DOCUMENTATION.md`, `roleModel.xml` and `docs/`.

## Maintenance

- Update `.gigacode/.../GIGACODE.md` when repository-wide rules change.
- Update the relevant `agents/*.md` only when a role's responsibility changes.
- Update a skill when its repeatable workflow or validation sequence changes.
- Keep `.gitverse/pr_rules/` short and focused on reviewable invariants.
- Keep AI configuration project-local and specific to GigaCode.
