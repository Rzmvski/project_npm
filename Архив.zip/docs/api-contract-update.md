# API contract change runbook

Use this checklist for any path, method, header, query parameter, request body,
response body or status-code change.

## Before editing

1. Read [`../API_DOCUMENTATION.md`](../API_DOCUMENTATION.md).
2. Locate the entity API under `src/entities/*/api`.
3. Locate the DTO under `src/entities/*/model`.
4. Locate the matching Express handler in `mock-server/index.js`.
5. Locate contract coverage in `src/entities/api.test.ts`.

## Implementation order

1. Update the canonical contract.
2. Update TypeScript DTOs.
3. Update the entity API function.
4. Update query keys/options if identity or scope changed.
5. Update consumers without bypassing slice public APIs.
6. Update mock response, validation and permission enforcement.
7. Update API tests and affected user-flow tests.

## Invariants to check

- Tenant-aware requests send `tenant-id`.
- Tenant-aware query keys include tenant UUID.
- `apiDataRequest<T>` is used only for `ApiResponse<T>` responses.
- Empty responses use `apiRequest<void>`.
- No unsupported UI filters enter the query string.
- `/user/permissions` resolves to `string[]`.
- `GET /process` returns paginated items and preserves the optional `cmd` value.
- Schedule `404` continues to map to `null` only for the detail read.

## Validation

```bash
npm run typecheck
npx vitest run src/entities/api.test.ts
npm test
npm run build
```

If the mock changed, start it and exercise the exact endpoint with representative
headers and body.
