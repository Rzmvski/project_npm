# Form architecture guide

This file describes the current form rules despite its historical filename.

## Baseline

- Editable domain forms use React Hook Form.
- Zod owns validation and is connected with `zodResolver`.
- API DTOs and form values are separate when their shapes or nullability differ.
- Containers own loading, default values, submit mapping and mutation lifecycle.
- Presentational field groups receive typed RHF controls/props.

## Shared adapters

Use the existing adapters for repeated standard fields:

- `FormInput`;
- `FormTextarea`;
- `FormNumberInput`;
- `FormCodeEditor`.

Keep VUIK controls with rich value contracts (`Select`, `Creatable`,
`ComboBox`, date/time controls) in local `Controller` blocks unless a stable
cross-slice pattern exists.

## Process form

- `processType` is required and comes only from `/process/types`.
- `label` is optional and displayed as **Категория**.
- Concrete routes and DB sets share `RouteTarget[]`; `isLabel` distinguishes
  them.
- `cmd` is required by the UI, even though the backend field is optional.
- Edit mode preloads `cmd` from the process list query.
- Create/update always send the complete command and targets.

When adding a field, update:

1. form value type;
2. Zod schema;
3. default values;
4. API-to-form mapping;
5. form-to-request mapping;
6. create and edit tests.

## Schedule form

- Schedule days use `useFieldArray`.
- Presets, common settings and per-day edits mutate one RHF state.
- Weekday order is always `MON`, `TUE`, `WED`, `THU`, `FRI`, `SAT`, `SUN`.
- Normalize after append/replace operations and use the same normalized data in
  editor and preview.
- Do not keep a parallel local array of days.

## Manual start form

- Additional parameters use `useFieldArray`.
- Empty parameter keys/values are validated before request mapping.
- Start date uses the VUIK date component through `Controller`.
- Additional parameters require their dedicated ability.

## Submission behavior

- Disable or otherwise guard duplicate submission.
- Surface backend `description` through notifications/form feedback.
- Invalidate only queries affected by the mutation.
- Navigate only after successful mutation.
- Preserve form state on backend failure where possible.

## Tests

Cover defaults, validation, mapping and the user-visible success/failure path.
Use domain test-model methods for multi-step forms instead of exposing raw DOM
helpers.
