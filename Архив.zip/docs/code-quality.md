# Code quality guide

## Validation commands

| Command                     | Purpose                                             |
| --------------------------- | --------------------------------------------------- |
| `npm run check:permissions` | Synchronize XML roles and TypeScript permission IDs |
| `npm run format`            | Rewrite supported files with Prettier               |
| `npm run format:check`      | Check formatting without changes                    |
| `npm run lint:eslint`       | TypeScript/React/import/FSD rules                   |
| `npm run lint:styles`       | Sass Module and token rules                         |
| `npm run lint:architecture` | FSD boundary rules only                             |
| `npm run typecheck`         | `tsc -b`                                            |
| `npm test`                  | Full Vitest suite                                   |
| `npm run build`             | Typecheck and production Vite build                 |

## Expected order

For a cross-cutting change:

```bash
npm run check:permissions
npm run format:check
npm run lint:eslint
npm run lint:styles
npm run typecheck
npm test
npm run build
```

Run focused tests while iterating, then expand validation based on risk.

## ESLint architecture rules

- FSD dependency direction is enforced.
- Sibling slice imports are rejected.
- Deep alias imports bypassing public APIs are rejected.
- Cycles and duplicate imports are rejected.
- Required `index.ts` files are checked.
- Native interactive controls are rejected when VUIK supplies an equivalent.

Do not suppress an architecture error until the ownership problem has been
examined. Moving code to a lower shared layer or composing slices in `app` is
usually safer than creating a sibling dependency.

## Style rules

- Prettier is the formatter for source and Markdown.
- Stylelint checks Sass Modules and token conventions.
- CSS Module class names are camelCase.
- `!important` is forbidden.
- New colors, spacing, radii and shadows use existing semantic tokens.

## Git hooks

- `pre-commit`: lint-staged fixes/checks staged files;
- `commit-msg`: Conventional Commit validation;
- `pre-push`: TypeScript and FSD checks.

Example:

```text
fix(schedule): preserve weekday order
```

## Validation reporting

Agents must report commands actually run, not historical repository claims.
If a check fails because of an unrelated pre-existing file, identify that file
and still run focused checks for changed files.
