# RBAC change runbook

Use this checklist for every role, permission or ability change.

## Files that must agree

```text
roleModel.xml
src/entities/access/model/permissions.ts
src/entities/access/model/abilities.ts
mock-server/index.js
src/entities/access/model/roleModel.test.ts
```

The dev role selector also mirrors role codes in:

```text
src/features/dev-switch-role/model/roles.ts
```

## Adding or renaming a permission

1. Add/rename the `<permission>` in `roleModel.xml`.
2. Assign it with `<permission-ref>` to at least one role.
3. Update `Permission` in `permissions.ts`.
4. Update the relevant `Ability` mapping.
5. Update mock endpoint enforcement.
6. Update role-model and behavior tests.
7. Update `docs/access-control.md`.

## Adding or renaming a role

1. Update `roleModel.xml`.
2. Update role matrix tests.
3. Update dev selector options and labels.
4. Update mock default/role parsing where necessary.
5. Never add production component branches based on the new role code.

## Validation

```bash
npm run check:permissions
npx vitest run src/entities/access
npm test
npm run build
```

`check:permissions` fails on missing, unused, dangling, unassigned or duplicate
permission IDs. It does not prove tenant isolation; backend tests must cover a
user attempting to access an unassigned tenant.
