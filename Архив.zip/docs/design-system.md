# Design system guide

Read this document before changing layout, spacing, typography, colors or shared
UI compositions.

## Component ownership

Import standard controls directly from `@v-uik/base` in pages, widgets and
features. Do not create wrappers that only rename VUIK props.

`src/shared/ui` is reserved for application-specific behavior or repeated
composition. Current examples:

- `PageLayout`, `FormPageLayout`, `FormSection`, `PageBreadcrumbs`;
- `FormInput`, `FormTextarea`, `FormNumberInput`, `FormCodeEditor`;
- `DataTable`, `Pagination`, `SearchInput`;
- `ConfirmModal`, `TextDetailsModal`;
- `EmptyState`, `ErrorState`, `LoadingState`;
- `CodeEditor`, `FormHeroActions`.

Native `button`, `input`, `select` and `textarea` are rejected in application
TSX where VUIK has an equivalent. Semantic HTML containers (`main`, `section`,
`header`, `form`) remain appropriate.

## Token pipeline

```text
src/shared/config/theme/model/tokens.ts
  ├── Platform V theme configuration
  └── generated --app-* CSS variables
        └── src/shared/styles/_tokens.scss
              └── CSS Modules
```

Files:

| File                | Responsibility                         |
| ------------------- | -------------------------------------- |
| `tokens.ts`         | Application semantic values            |
| `systemTheme.ts`    | VUIK system theme values               |
| `componentTheme.ts` | VUIK component overrides               |
| `cssVariables.ts`   | `--app-*` generation                   |
| `_tokens.scss`      | Sass aliases to CSS variables          |
| `_mixins.scss`      | Reusable application layout patterns   |
| `_breakpoints.scss` | Responsive scale and `viewport-down()` |

Do not add literal design values when an appropriate semantic token exists.
When a reusable semantic value is missing, add it to the token pipeline rather
than only one CSS Module.

## Sass Module rules

- File name: `ComponentName.module.scss`.
- Start modules with `@use '@/shared/styles' as *;`.
- CSS Module class names use camelCase.
- Reuse mixins such as `card-surface`, `table-container`, `page-container`,
  `filter-grid`, `truncate` and `visually-hidden`.
- Do not use `!important`.
- Keep VUIK interaction states, control geometry and focus behavior owned by
  VUIK unless a documented component-theme override is required.

## Layout rules

- Catalog/detail pages use `PageLayout`.
- Editable pages use `FormPageLayout` and `FormSection`.
- Tables use `DataTable`; catalog action columns stay fixed at the end.
- Use container-aware `filter-grid` for filter toolbars beside the fixed
  sidebar; viewport breakpoints alone do not represent available content width.
- Avoid extra nested cards, borders and padding when an existing parent already
  establishes the visual surface.
- Tabs and their content must share the same horizontal alignment.

## User identity block

- Show avatar initials and `displayName`.
- Do not show email/login in the sidebar or tenant-selection identity block.
- Production shows a static role label with icon.
- Development shows the role selector as a separate full-width control.
- Do not shrink role text to force it into a narrow selector; preserve readable
  typography and sufficient width.

## Visual validation

For layout changes, inspect at least:

- normal desktop width;
- width where sidebar reduces available content;
- long process/user/role text;
- empty/loading/error state;
- table with enough rows to exercise vertical sizing and pagination.

Run `npm run lint:styles` after Sass changes.
