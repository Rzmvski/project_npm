# Access control guide

Read this document before changing roles, permissions, route guards, action
visibility or the mock role switcher.

## Runtime model

```text
roleModel.xml
  → backend/IAM resolves permission IDs
  → GET /user/permissions (tenant-id)
  → string[]
  → abilityPolicy
  → router guards and useCan/useAccess
```

Roles are display and backend assignment data. Production UI behavior must not
branch on `SUPER_ADMIN`, `ADMIN` or `USER`; it checks abilities only.

## User contracts

```http
GET /api/v1/user
```

```json
{
  "status": "SUCCESS",
  "description": "User profile retrieved successfully",
  "data": {
    "login": "user@example.com",
    "displayName": "Тестовый пользователь",
    "roles": ["USER"]
  }
}
```

```http
GET /api/v1/user/permissions
tenant-id: <uuid>
```

```json
{
  "status": "SUCCESS",
  "description": "Permissions retrieved successfully",
  "data": ["processService_getAll", "historyService_getHistory"]
}
```

The permission response is an array inside `ApiResponse`; do not add an inner
DTO wrapper.

## Sources of truth

| Concern                           | File                                               |
| --------------------------------- | -------------------------------------------------- |
| Declared roles and permission IDs | `roleModel.xml`                                    |
| TypeScript constants              | `src/entities/access/model/permissions.ts`         |
| Ability-to-permission mapping     | `src/entities/access/model/abilities.ts`           |
| Route/action checks               | `src/entities/access/lib`, `src/app/router/guards` |
| Mock enforcement                  | `mock-server/index.js`                             |
| Synchronization script            | `scripts/check-permissions.mjs`                    |

`abilityPolicy` entries use OR semantics: an ability is granted when at least
one listed permission is present.

## Permission matrix

| Ability               | Permission ID                      |
| --------------------- | ---------------------------------- |
| Process list/details  | `processService_getAll`            |
| Process types         | `processService_getTypes`          |
| Process create        | `processService_create`            |
| Process update        | `processService_update`            |
| Process delete        | `processService_delete`            |
| Start process         | `executeService_executeCommand`    |
| Start with parameters | `executeService_executeWithParams` |
| Stop process          | `executeService_stopCommand`       |
| History list          | `historyService_getHistory`        |
| History details       | `historyService_getDetailed`       |
| Error details         | `historyService_getErrorDetails`   |
| Schedule list         | `scheduleService_getAll`           |
| Read process schedule | `scheduleService_getByProcessId`   |
| Schedule create       | `scheduleService_create`           |
| Schedule update       | `scheduleService_update`           |
| Schedule delete       | `scheduleService_delete`           |
| Tenant initialization | `tenantService_getAll`             |

`SCHEDULE_READ` is intentionally available when the user has the explicit read
permission or any schedule mutation permission, so an editor can also open the
schedule card.

## Role matrix

| Capability                       | SUPER_ADMIN |      ADMIN      |      USER       |
| -------------------------------- | :---------: | :-------------: | :-------------: |
| Scope                            | All tenants | Assigned tenant | Assigned tenant |
| Read processes/history/schedules |     Yes     |       Yes       |       Yes       |
| Process mutations                |     Yes     |       Yes       |       No        |
| Start/stop                       |     Yes     |       Yes       |       No        |
| Schedule mutations               |     Yes     |       Yes       |       No        |

`SUPER_ADMIN` and `ADMIN` have the same operation permissions. Their difference
is tenant scope, enforced by backend/IAM rather than frontend role checks.

## Frontend usage

Route:

```ts
beforeLoad: requireAbility(Ability.PROCESS_UPDATE)
```

Component:

```ts
const canUpdate = useCan(Ability.PROCESS_UPDATE)
```

Multiple actions:

```ts
const { canAny } = useAccess()
const showActions = canAny([Ability.PROCESS_START, Ability.PROCESS_UPDATE])
```

Do not write:

```ts
user.roles.includes('ADMIN')
permissions.includes('processService_update')
```

## Backend requirements

- Authenticate both user endpoints.
- `/user` is tenant-independent.
- `/user/permissions` validates the requested tenant and returns only effective
  permission strings for that tenant.
- `/tenants` returns only assigned tenants except for global administrators.
- Every business endpoint repeats authorization; the permission list is only a
  UI capability hint.
- If roles vary by tenant, do not treat unscoped `SimpleGrantedAuthority` as
  sufficient authorization. Use tenant-aware database assignments and an
  authorization service/manager.

See [`java-user-endpoints.md`](java-user-endpoints.md) for a Spring Security
implementation compatible with the immutable authentication library described
there.

## Development role switcher

Only Vite dev builds render the switcher.

1. Selection is stored in `localStorage` as `ppm.devMockRoles`.
2. `shared/api` adds `x-mock-roles` only when `import.meta.env.DEV`.
3. Express resolves role permissions for every request.
4. React Query caches are invalidated and navigation moves to an allowed route.

Production renders a static role label from `/user`; it never sends
`x-mock-roles`.

`VITE_USER_PERMISSIONS` bypasses `/user/permissions` and disables meaningful
mock role switching. Use it only as a temporary frontend fallback.

## Change checklist

Use [`rbac-validation.md`](rbac-validation.md). Always run:

```bash
npm run check:permissions
npx vitest run src/entities/access
npm test
```
