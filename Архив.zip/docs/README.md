# Documentation map

Use this page to select the minimum documentation needed for a task.

## Canonical documents

| Document                                               | Use it for                                            |
| ------------------------------------------------------ | ----------------------------------------------------- |
| [`../.gigacode/GIGACODE.md`](../.gigacode/GIGACODE.md) | GigaCode entry point and extension routing            |
| [`gigacode.md`](gigacode.md)                           | GigaCode agents, skills and project setup             |
| [`../README.md`](../README.md)                         | Setup and product overview                            |
| [`../API_DOCUMENTATION.md`](../API_DOCUMENTATION.md)   | REST endpoints, DTOs, headers and status codes        |
| [`architecture.md`](architecture.md)                   | FSD, routing, tenant/query flows and loading strategy |
| [`access-control.md`](access-control.md)               | Roles, permissions, abilities and dev role switching  |
| [`backend-contract.md`](backend-contract.md)           | Frontend/backend integration rules and edge cases     |
| [`design-system.md`](design-system.md)                 | Tokens, layout and CSS rules                          |
| [`refactoring-rhf.md`](refactoring-rhf.md)             | Current form architecture and mapping rules           |
| [`testing.md`](testing.md)                             | Test strategy, fixtures and commands                  |
| [`code-quality.md`](code-quality.md)                   | Linters, formatting, hooks and validation sequence    |
| [`java-user-endpoints.md`](java-user-endpoints.md)     | Spring Security implementation of user endpoints      |

## Change runbooks

| Document                                           | Use it when changing                               |
| -------------------------------------------------- | -------------------------------------------------- |
| [`api-contract-update.md`](api-contract-update.md) | Any REST path, DTO, query parameter or status code |
| [`rbac-validation.md`](rbac-validation.md)         | `roleModel.xml`, permissions or abilities          |
| [`validation.md`](validation.md)                   | Selecting and reporting validation commands        |
| [`vuik-refactoring.md`](vuik-refactoring.md)       | UI primitives or VUIK integration                  |

## Duplication policy

- `API_DOCUMENTATION.md` at repository root is the only API source of truth.
- `docs/API_DOCUMENTATION.md` is only a compatibility pointer.
- Historical migration metrics and environment-specific validation reports are
  intentionally not maintained; use the runbooks and current commands instead.
