# Testing guide

The project uses Vitest, React Testing Library, `user-event` and
`@testing-library/jest-dom` in a jsdom environment.

## Test levels

| Level                     | Purpose                                          | Typical location             |
| ------------------------- | ------------------------------------------------ | ---------------------------- |
| Pure unit                 | Policies, parsers, schemas, mapping and sorting  | Next to production module    |
| Entity API contract       | Paths, headers/options, body and error handling  | `src/entities/api.test.ts`   |
| Component integration     | Observable user behavior with real app providers | Next to component/page       |
| Router/access integration | Guards, redirects and search state               | `src/app/router`, page tests |
| Mock integration          | Real HTTP shape and permission enforcement       | Manual/focused server check  |

## Principles

- Test observable behavior, not implementation details.
- Prefer accessible role, label, visible text and field value queries.
- Do not assert CSS class names or VUIK internal markup.
- Test pure domain rules without React.
- Mock entity API functions at the application boundary; keep Router, Query,
  RHF and application components real.
- Use `user-event` for interactions.
- Add regression coverage for every fixed bug when practical.

## Application harness

`src/test/renderApp.tsx` creates:

- memory history and the real application router;
- a test QueryClient with retries disabled;
- selected tenant state;
- seeded tenant, user, access, process, route and schedule queries;
- theme/date/modal providers;
- a configured `user-event` instance.

Use `renderApp` for route/page/feature behavior. Use `renderWithDateProvider`
only for isolated UI that does not need the router or query cache.

Shared fixtures live in `src/test/fixtures.ts`. Extend fixtures with optional
overrides instead of copying large DTO objects into tests.

## Domain test models

For multi-step UI, place a test model beside the test:

```text
ScheduleForm.tsx
ScheduleForm.test.tsx
ScheduleForm.test-model.ts
```

Expose domain actions such as `selectWeekdays`, `fillCommand` or
`showThreadsForRoute`. Do not build generic wrappers around every DOM API.

## Required regression areas

- access policy and protected routes;
- user/tenant initialization;
- process card availability for read-only users;
- process create/update request mapping including full `cmd`;
- start/stop/delete permission visibility;
- schedule weekday ordering in editor and preview;
- schedule create/update/delete and `404 → null` handling;
- monitoring pagination, tabs and `routeSessionId` routing;
- API paths, query serialization, headers and error messages.

## Commands

```bash
# Full suite
npm test

# One file
npx vitest run src/entities/api.test.ts

# One named case
npx vitest run -t "returns permissions as a string array"

# Watch mode
npm run test:watch

# Coverage
npm run test:coverage
```

Coverage thresholds in `vitest.config.ts` are 80% lines/functions/statements
and 60% branches. Coverage is a guardrail, not a substitute for scenario
selection.

## Async test rules

- Await `router.load()` through the harness.
- Use `findBy*` for asynchronously rendered content.
- Use `waitFor` for state transitions, not arbitrary sleeps.
- Clear assumptions about seeded query keys; tenant ID must match route scope.
- Assert rejected API behavior when a change affects errors or status codes.
