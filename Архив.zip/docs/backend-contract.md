# Backend integration rules

The canonical endpoint and DTO reference is
[`../API_DOCUMENTATION.md`](../API_DOCUMENTATION.md). This document records
integration rules that are easy to violate while editing frontend code.

## Request rules

- `GET /user` and `GET /tenants` are available before tenant selection.
- `GET /user/permissions` and all domain endpoints require `tenant-id`.
- The API client unwraps `ApiResponse<T>` through `apiDataRequest<T>`.
- Use `apiRequest<void>` for empty schedule mutation responses.
- Do not add a tenant header to an endpoint unless its entity API accepts
  `tenantId`.
- Do not send undocumented query parameters.

## Response rules

- `/user/permissions` response data is `string[]`, not
  `{ permissions: string[] }`.
- `/process` returns the complete saved `cmd`.
- `404` from `/process/schedule/{processId}` means no schedule and maps to
  `null`; other failures are propagated.
- Schedule POST/PUT return empty `200`; schedule DELETE returns empty `204`.
- API errors expose HTTP status and use `description` as the preferred message.

## UI-only filters

These values may live in Router search state or component state but must not be
sent to backend:

| Endpoint            | UI-only values                          |
| ------------------- | --------------------------------------- |
| `/process/history`  | search, status, category, from/to dates |
| route sessions      | route search, status/error filters      |
| thread sessions     | route key, pod, status/error filters    |
| `/process/schedule` | search, category, weekday               |

The only supported thread filter is `routeSessionId`.

## Domain terminology

| UI term   | API representation                    |
| --------- | ------------------------------------- |
| Тип       | `processType` from `/process/types`   |
| Категория | free-text `label`                     |
| DB route  | `routes[]` item with `isLabel: false` |
| DB set    | `routes[]` item with `isLabel: true`  |

## Contract change procedure

Use [`api-contract-update.md`](api-contract-update.md). A contract change is not
complete until the canonical documentation, entity types/API, mock and tests
agree.
