const UNCATEGORIZED_TEMPLATES_LABEL = 'Без категории'

export const getTemplateCategoryPath = (path: string) => {
  const pathParts = path.split(/[\\/]/).filter(Boolean)

  if (pathParts.length <= 1) return UNCATEGORIZED_TEMPLATES_LABEL

  return pathParts.slice(0, -1).join('/')
}
