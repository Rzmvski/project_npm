import { type TemplateMetadataDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import {
  createUseStyles,
  generateId,
  modal,
  ModalBody,
  ModalHeader,
  type ShowOptions,
} from '@v-uik/base'
import React, { useState } from 'react'

import { type Template } from '@/entities/script-template'
import { TemplateExplorer } from '@/entities/script-template/ui/TemplateExplorer'

interface UseTemplateModalParams {
  onSelect: (template: Template) => void
  onClear: () => void
}

const useStyles = createUseStyles(() => ({
  modalContent: {
    width: '80vw',
    minWidth: '80vw',
    height: '90vh',
    maxWidth: 'calc(100vw - 32px)',
    maxHeight: 'calc(100vh - 32px)',
  },
}))

export const useTemplateExplorer = ({ onSelect, onClear }: UseTemplateModalParams) => {
  const [selectedTemplate, setSelectedTemplate] = useState<Nullable<TemplateMetadataDto>>(null)
  const modalId = generateId()
  const { modalContent } = useStyles()

  const handleTemplateSelect = (template: Template) => {
    onSelect(template)
    setSelectedTemplate(template)
    modal.close(modalId)
  }

  const handleTemplateClear = () => {
    onClear()
    setSelectedTemplate(null)
  }

  const handleTemplateClick = () => {
    modal.show(modalId, {
      classes: {
        modalContent,
      },
      content: (
        <React.Fragment>
          <ModalHeader>{'Выбор шаблона'}</ModalHeader>
          <ModalBody>
            <TemplateExplorer onSelect={handleTemplateSelect} />
          </ModalBody>
        </React.Fragment>
      ),
    } as ShowOptions)
  }

  return {
    selectedTemplate,
    handleTemplateClick,
    handleTemplateClear,
  }
}
