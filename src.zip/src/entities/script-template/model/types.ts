import { type TemplateMetadataDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

export interface Template extends TemplateMetadataDto {
  script: string
}
