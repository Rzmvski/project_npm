import { useQuery } from '@tanstack/react-query'

import { type IndexCluster, fetchIndexClusters } from '@/entities/index-cluster'
import { createPollingQueryPolicy } from '@/shared/api'

export const useIndexClusters = () => {
  const { data, isLoading, isFetching, refetch } = useQuery({
    queryKey: ['clusters'],
    queryFn: fetchIndexClusters,
    ...createPollingQueryPolicy({
      stopPredicate: (clusters: IndexCluster[]) =>
        clusters.every(({ updateRequired }) => !updateRequired),
    }),
  })

  const clusters = data ?? []
  const hasUpdates = clusters.some(({ updateRequired }) => updateRequired)

  return {
    clusters,
    isLoading,
    isPolling: hasUpdates || isFetching,
    refetch,
  }
}
