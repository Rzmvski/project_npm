import {
  type ClusterInfoDto,
  type ClusterStateDto,
  type IndexActionsDto,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'

export interface IndexCluster extends ClusterInfoDto {
  clusterId: string
  state: ClusterStateDto
  availableActions: IndexActionsDto
}
