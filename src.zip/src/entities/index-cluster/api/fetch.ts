import {
  ClusterStateDto,
  IndexActionsDto,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { type IndexCluster } from '@/entities/index-cluster'
import { zoneIndexService } from '@/shared/api'

export async function fetchIndexClusters(): Promise<IndexCluster[]> {
  const response = await zoneIndexService.clusterInfo()
  return response.map(({ clusterId, availableActions, state, ...cluster }) => {
    if (!clusterId)
      throw Error('invalid response, cluster must have cluster id')

    return {
      clusterId,
      state: state ?? ClusterStateDto.Unrecognized,
      availableActions: availableActions ?? IndexActionsDto.Unrecognized,
      ...cluster,
    }
  })
}
