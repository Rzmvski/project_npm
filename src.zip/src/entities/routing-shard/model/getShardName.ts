export const getShardName = (id: number, name: string): string => {
  return `${id} - ${name}`
}
