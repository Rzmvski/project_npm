export interface Shard {
  id: number
  nodes: string[]
}
