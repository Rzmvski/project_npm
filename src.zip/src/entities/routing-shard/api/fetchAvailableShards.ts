import { type NodeDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { map } from 'lodash'
import { groupBy } from 'lodash-es'

import { type Shard } from '@/entities/routing-shard/model'

export const mergeNodesIntoShards = (nodes: NodeDto[]): Shard[] => {
  const shard = groupBy(nodes, (node) => node.shardId)
  return map(shard, (dtos, id) => {
    const nodes = dtos.map(({ key }) => key)

    return { id: Number(id), nodes }
  })
}
