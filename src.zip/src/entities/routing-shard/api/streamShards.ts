import { clusterManagementService } from '@/shared/api'

export const streamAvailableShards = (signal: AbortSignal) => {
  return clusterManagementService.getShardsStream({ signal })
}
