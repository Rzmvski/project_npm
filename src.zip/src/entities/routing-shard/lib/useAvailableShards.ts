import { type QueryKey } from '@tanstack/react-query'

import { streamAvailableShards } from '@/entities/routing-shard/api'
import { useSseQuery } from '@/shared/lib'

export const availableShardsQueryKey: QueryKey = ['available-shards']

/**
 * Сырые данные шард БД (ShardDto[]) вместе с диапазонами бакетов
 * (bucketRanges). В отличие от useRoutingShards, который агрегирует пары нод
 * по queryKey ['nodes'], этот хук отражает queryKey ['available-shards'] —
 * ответ clusterManagementService.getShards().
 */
export const useAvailableShards = () => {
  return useSseQuery({
    initialData: [],
    queryKey: availableShardsQueryKey,
    stream: streamAvailableShards,
  })
}
