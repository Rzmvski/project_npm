import { useMemo } from 'react'

import { useNodes } from '@/entities/node'

import { mergeNodesIntoShards } from '../api/fetchAvailableShards'

const EMPTY_SHARDS: ReturnType<typeof mergeNodesIntoShards> = []

export const useRoutingShards = () => {
  // Раньше здесь был отдельный useQuery(['routing-shards'], fetchNodePairInfo),
  // который дублировал запрос к /cluster-management-service/nodes — тот же
  // эндпоинт, что и useNodes (queryKey ['nodes']). При одновременном
  // использовании useRoutingShards и useNodes/useShards на одной странице это
  // приводило к двум одинаковым сетевым запросам. Переиспользуем общий кэш
  // useNodes и просто по-другому агрегируем те же данные.
  const query = useNodes({ select: mergeNodesIntoShards })
  const shards = query.data ?? EMPTY_SHARDS
  const derived = useMemo(() => {
    const shardEntities = Object.fromEntries(shards.map((shard) => [shard.id, shard]))
    const shardNameEntities = Object.fromEntries(
      shards.map((shard) => [shard.id, shard.nodes.join('/')]),
    )
    const nodes = shards.flatMap(({ nodes }) => nodes)
    const idsByNodes = new Map<string, number>(
      Object.entries(shardEntities).map(([key, value]) => {
        const nodesKey = value.nodes.toSorted().join()
        const shardId = Number(key)
        return [nodesKey, shardId]
      }),
    )

    return { shardEntities, shardNameEntities, nodes, idsByNodes }
  }, [shards])

  return {
    isLoading: query.isLoading,
    isError: query.isError,
    shards,
    ...derived,
  }
}
