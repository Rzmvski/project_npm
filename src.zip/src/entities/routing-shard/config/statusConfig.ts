import {
  ClusterStateDto,
  MonitoringStateDto,
  PoolStateDto,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'
import {
  CheckCircle2,
  Lock,
  PencilOff,
  Wifi,
  WifiOff,
  XCircle,
} from 'lucide-react'
import { type ComponentType } from 'react'

type IndicatorType = 'connection' | 'semaphore' | 'frozen' | 'monitoring'
type IconDictionary = Record<string, ComponentType>

interface IndicatorConfig {
  title: string
  iconDictionary: IconDictionary
}

export const statusConfig: Record<IndicatorType, IndicatorConfig> = {
  connection: {
    title: 'Статус коннектов:',
    iconDictionary: {
      [PoolStateDto.Active]: Wifi,
      [PoolStateDto.Suspended]: WifiOff,
    },
  },
  semaphore: {
    title: 'Статус семафора:',
    iconDictionary: {
      [ClusterStateDto.Active]: Wifi,
      [ClusterStateDto.Inactive]: WifiOff,
    },
  },
  monitoring: {
    title: 'Мониторинг:',
    iconDictionary: {
      [MonitoringStateDto.Up]: CheckCircle2,
      [MonitoringStateDto.Down]: XCircle,
      [MonitoringStateDto.OnlyRead]: PencilOff,
    },
  },
  frozen: {
    title: '',
    iconDictionary: {
      frozen: Lock,
    },
  },
}
