import { useQuery } from '@tanstack/react-query'

import { fetchProcessGroups } from '../api/fetch'

export const useProcessGroups = () => {
  const query = useQuery({
    queryKey: ['process-groups'],
    queryFn: fetchProcessGroups,
  })

  return {
    isLoading: query.isLoading,
    isError: query.isError,
    processGroups: query.data ?? [],
  }
}
