import { type DictionaryItemDto } from '@sber-pprb-tkp/tcpf-support-admin-api'

export interface ProcessGroup extends DictionaryItemDto {
  status?: string
  startDate?: Date
}
