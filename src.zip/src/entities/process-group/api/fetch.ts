import { type DictionaryItemDto } from '@sber-pprb-tkp/tcpf-support-admin-api'

import { processManagementService } from '@/shared/api'

export const fetchProcessGroups = (): Promise<DictionaryItemDto[]> => {
  return processManagementService.processList()
}
