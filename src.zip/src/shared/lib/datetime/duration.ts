const UNITS: Record<string, number> = {
  day: 86400,
  days: 86400,
  hour: 3600,
  hours: 3600,
  minute: 60,
  minutes: 60,
  second: 1,
  seconds: 1,
}

const regexp = /(\d+)\s+(day|days|hour|minute|minutes|second|seconds)/g

const DISPLAY_UNITS = [
  { seconds: 86400, suffix: 'д' },
  { seconds: 3600, suffix: 'ч' },
  { seconds: 60, suffix: 'мин' },
  { seconds: 1, suffix: 'с' },
] as const

const numberFormatter = new Intl.NumberFormat('ru-RU')

export function parseDurationWords(value: string): number {
  const matches = value.matchAll(regexp)

  let total = 0

  for (const [, amount, unit] of matches) {
    total += Number(amount) * UNITS[unit]
  }

  return total
}

export function formatDurationSeconds(value: number): string {
  let secondsLeft = Math.max(0, Math.floor(value))

  if (secondsLeft === 0) {
    return '0 с'
  }

  const parts: string[] = []

  for (const unit of DISPLAY_UNITS) {
    const amount = Math.floor(secondsLeft / unit.seconds)

    if (amount > 0) {
      parts.push(`${numberFormatter.format(amount)} ${unit.suffix}`)
      secondsLeft %= unit.seconds
    }

    if (parts.length === 2) {
      break
    }
  }

  return parts.join(' ')
}

export function formatDurationMilliseconds(value: number): string {
  const milliseconds = Math.max(0, value)

  if (milliseconds < 1_000) {
    return `${numberFormatter.format(milliseconds)} мс`
  }

  if (milliseconds < 60_000) {
    return `${numberFormatter.format(milliseconds / 1_000)} с`
  }

  return formatDurationSeconds(milliseconds / 1_000)
}
