import '@testing-library/jest-dom/vitest'
import { cleanup } from '@testing-library/react'
import { afterEach, beforeEach, vi } from 'vitest'

import type React from 'react'

vi.mock('@v-uik/base', () => import('./v-uik.mock'))
vi.mock('@v-uik/theme', () => ({
  ThemeProvider: ({ children }: { children: React.ReactNode }) => children,
  createTheme: (theme: unknown) => theme,
}))

vi.mock('ace-builds/src-noconflict/ace', () => ({}))
vi.mock('ace-builds/src-noconflict/ext-language_tools', () => ({}))
vi.mock('ace-builds/src-noconflict/mode-sql', () => ({}))
vi.mock('ace-builds/src-noconflict/theme-textmate', () => ({}))

vi.mock('react-ace', () => ({
  default: ({
    value,
    onChange,
    readOnly,
  }: {
    value: string
    onChange?: (value: string) => void
    readOnly?: boolean
  }) => (
    <textarea
      aria-label='Редактор команды'
      value={value}
      readOnly={readOnly}
      onChange={(event) => onChange?.(event.target.value)}
    />
  ),
}))

class ResizeObserverMock {
  observe() {}
  unobserve() {}
  disconnect() {}
}

Object.defineProperty(globalThis, 'ResizeObserver', {
  configurable: true,
  value: ResizeObserverMock,
})

Object.defineProperty(window, 'matchMedia', {
  configurable: true,
  writable: true,
  value: vi.fn().mockImplementation((query: string) => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: vi.fn(),
    removeListener: vi.fn(),
    addEventListener: vi.fn(),
    removeEventListener: vi.fn(),
    dispatchEvent: vi.fn(),
  })),
})

Object.defineProperty(HTMLElement.prototype, 'scrollIntoView', {
  configurable: true,
  value: vi.fn(),
})

Object.defineProperty(window, 'scrollTo', {
  configurable: true,
  value: vi.fn(),
})

if (!globalThis.crypto) {
  Object.defineProperty(globalThis, 'crypto', {
    configurable: true,
    value: {},
  })
}

let uuidSequence = 0

Object.defineProperty(globalThis.crypto, 'randomUUID', {
  configurable: true,
  value: vi.fn(() => `00000000-0000-4000-8000-${String(++uuidSequence).padStart(12, '0')}`),
})

beforeEach(() => {
  uuidSequence = 0
})

afterEach(() => {
  cleanup()
  localStorage.clear()
  sessionStorage.clear()
  vi.unstubAllGlobals()
})
