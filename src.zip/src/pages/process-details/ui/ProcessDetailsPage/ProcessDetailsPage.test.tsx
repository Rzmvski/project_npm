import { screen } from '@testing-library/react'
import { describe, expect, it } from 'vitest'

import { Permission } from '@/entities/access'
import { processFixture, renderApp, TEST_PROCESS_ID, userAccessFixture } from '@/test'

describe('process details', () => {
  it('shows a read-only card without process actions', async () => {
    await renderApp({
      route: `/processes/${TEST_PROCESS_ID}`,
      access: userAccessFixture([Permission.PROCESS_LIST]),
      processes: [processFixture()],
    })

    await screen.findByRole('heading', { name: 'Дневная загрузка данных' })
    expect(screen.queryByText(TEST_PROCESS_ID)).not.toBeInTheDocument()
    expect(
      await screen.findByRole('textbox', { name: 'Редактор команды' }, { timeout: 3_000 }),
    ).toHaveValue('python /opt/etl/daily_load.py --date today')
    expect(screen.queryByRole('button', { name: 'Редактировать' })).not.toBeInTheDocument()
    expect(screen.queryByRole('button', { name: 'Удалить процесс' })).not.toBeInTheDocument()
    expect(screen.queryByRole('button', { name: 'Запустить процесс' })).not.toBeInTheDocument()
  })

  it('shows the complete command and process targets', async () => {
    await renderApp({
      route: `/processes/${TEST_PROCESS_ID}`,
      access: userAccessFixture([
        Permission.PROCESS_LIST,
        Permission.PROCESS_UPDATE,
        Permission.PROCESS_DELETE,
      ]),
      processes: [processFixture()],
    })

    await screen.findByRole('heading', {
      name: 'Дневная загрузка данных',
    })
    expect(
      await screen.findByRole('textbox', { name: 'Редактор команды' }, { timeout: 3_000 }),
    ).toHaveValue('python /opt/etl/daily_load.py --date today')
    expect(screen.getByText('db-main.users')).toBeVisible()
    expect(screen.getByText('Основные витрины')).toBeVisible()
    expect(screen.getByLabelText('Количество областей выполнения: 2')).toHaveTextContent('2')
    expect(screen.getByRole('button', { name: 'Редактировать' })).toBeVisible()
    expect(screen.getByRole('button', { name: 'Удалить процесс' })).toBeVisible()
    expect(screen.queryByRole('heading', { name: 'Расписание' })).not.toBeInTheDocument()
  })

  it('offers schedule creation when the process has no schedule', async () => {
    await renderApp({
      route: `/processes/${TEST_PROCESS_ID}`,
      access: userAccessFixture([
        Permission.PROCESS_LIST,
        Permission.SCHEDULE_LIST,
        Permission.SCHEDULE_CREATE,
      ]),
      processes: [processFixture()],
      schedule: null,
    })

    expect(await screen.findByRole('button', { name: 'Создать расписание' })).toBeVisible()
    expect(screen.getByText('Расписание не настроено')).toBeVisible()
  })
})
