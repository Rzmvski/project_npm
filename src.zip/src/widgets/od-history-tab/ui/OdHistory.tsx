import { type ProcessDataHistoryDto } from '@sber-pprb-tkp/tcpf-support-admin-api'
import { useMutation } from '@tanstack/react-query'
import { type ColumnDef } from '@tanstack/react-table'
import { LinearProgress } from '@v-uik/base'
import React, { type FC } from 'react'

import { ProcessGroupDictionary } from '@/entities/process-group'
import {
  fetchProcessHistory,
  type FetchProcessHistoryParams,
  useProcessHistoryColumns,
} from '@/entities/process-history'
import {
  OdHistoryFilter,
  type OdHistoryFilterOutputValues,
  OdProcessDetails,
} from '@/features/od-history'
import { useExpandedRow, useVirtualization } from '@/shared/lib'
import { Table } from '@/shared/ui/Table'

import styles from './OdHistory.module.scss'

export const OdHistory: FC = () => {
  const { data, mutate, isPending, reset } = useMutation({
    mutationFn: (params: FetchProcessHistoryParams) => {
      return fetchProcessHistory(params)
    },
  })

  const loadHistory = ({ period }: OdHistoryFilterOutputValues) => {
    const [startDate, endDate] = period
    const groupIds = [ProcessGroupDictionary.EOD_AND_OOD_BY_CONTRACT]
    mutate({
      startDate,
      endDate,
      groupIds,
      groupName: 'VIEW_CLOSING_OPERATION_DAY_HISTORY',
    })
  }

  const columns: ColumnDef<ProcessDataHistoryDto>[] = useProcessHistoryColumns()

  const virtualizationPlugin = useVirtualization<ProcessDataHistoryDto>()

  const expandedPlugin = useExpandedRow<ProcessDataHistoryDto>({
    renderExpandedContent: ({ original }) => (
      <OdProcessDetails sessionId={Number(original.sessionId)} />
    ),
  })

  return (
    <div className={styles.container}>
      <OdHistoryFilter onSubmit={loadHistory} onClear={reset} />
      <div className={styles.tableWrapper}>
        <Table
          data={data ?? []}
          columns={columns}
          noDataText={'Нет данных за выбранный период'}
          plugins={[virtualizationPlugin, expandedPlugin]}
        />
        <LinearProgress style={{ display: isPending ? 'block' : 'none' }} />
      </div>
    </div>
  )
}
