import { type ProcessInfoDto } from '@sber-pprb-tkp/tcpf-support-admin-api'
import { type ColumnDef } from '@tanstack/react-table'
import { LinearProgress, Underlay } from '@v-uik/base'
import React, { type FC, useMemo } from 'react'
import { type FieldNamesMarkedBoolean, FormProvider } from 'react-hook-form'

import { useStatusColumn } from '@/entities/dictionary'
import { useActiveProcesses } from '@/entities/process'
import { ProcessGroupDictionary } from '@/entities/process-group'
import { getShardName, useRoutingShards } from '@/entities/routing-shard'
import { type ListModeValues, type ScriptModeValues } from '@/entities/transfer-task'
import {
  fetchCreateTask,
  TransferTaskForm,
  useCreateTransferTaskForm,
  useDisabledSteps,
  STEP_DEFS,
  type StepDef,
} from '@/features/create-transfer-task'
import { formatDate, humanize } from '@/shared/lib'
import { Table } from '@/shared/ui/Table'

import styles from './CreateTransferTask.module.scss'

export const CreateTransferTask: FC = () => {
  const { isLoading, setActiveProcessId, activeProcess, hasActiveProcess } =
    useActiveProcesses(ProcessGroupDictionary.GET_TASK_TO_TRANSFERRING)
  const { form, mode } = useCreateTransferTaskForm()
  const {
    watch,
    handleSubmit,
    formState: { dirtyFields },
  } = form
  const shard = watch('receiverShardId')
  const { shardNameEntities } = useRoutingShards()
  const scriptSourceStepDef: StepDef<ScriptModeValues> = {
    id: 'source',
    fields: ['script', 'shards'],
  }

  const listSourceStepDef: StepDef<ListModeValues> = {
    id: 'source',
    fields: ['clientIds'],
  }

  const disabledSteps = useDisabledSteps(
    dirtyFields as Partial<Readonly<FieldNamesMarkedBoolean<never>>>,
    [...STEP_DEFS, mode == 'script' ? scriptSourceStepDef : listSourceStepDef]
  )

  const onSubmitHandler = handleSubmit((data) => {
    fetchCreateTask(data).then(({ idOfStartedProcess, errorMessage }) => {
      if (!idOfStartedProcess || errorMessage) {
        throw Error(errorMessage)
      }
      setActiveProcessId(idOfStartedProcess)
    })
  })

  const statusColumn = useStatusColumn<ProcessInfoDto>('status')

  const columns: ColumnDef<ProcessInfoDto>[] = useMemo(
    () => [
      {
        header: 'Процесс',
        accessorFn: () => 'Формирование задания',
      },
      statusColumn,
      {
        header: 'Шарды',
        accessorFn: ({ nodeCode }) => (mode == 'list' ? shard : nodeCode),
        cell: ({ getValue }) => {
          const shardId = Number(getValue())
          const name = shardNameEntities[shardId]
          return getShardName(shardId, name)
        },
      },
      {
        header: 'Кол-во заданий по клиентам',
        accessorKey: 'recordsWillBeProcessed',
      },
      {
        header: 'Старт',
        accessorKey: 'startTime',
        cell: ({ getValue }) => {
          const startTime = getValue<Nullable<Date>>()
          return formatDate(startTime, 'dd.MM.yyyy HH:mm')
        },
      },
      {
        header: 'Завершение',
        accessorKey: 'endTime',
        cell: ({ getValue }) => {
          const endTime = getValue<Nullable<Date>>()
          return formatDate(endTime, 'dd.MM.yyyy HH:mm')
        },
      },
      {
        header: 'Время',
        cell: ({ row: { original } }) => {
          const { endTime, startTime } = original
          return humanize(startTime, endTime)
        },
      },
    ],
    [shard, mode, statusColumn, shardNameEntities]
  )

  return (
    <div className={styles.container}>
      <FormProvider {...form}>
        <TransferTaskForm
          onSubmit={onSubmitHandler}
          formDisabled={hasActiveProcess}
          disabledSteps={disabledSteps}
        />
      </FormProvider>
      <Underlay
        classes={{
          root: styles.tableContainer,
          content: styles.tableContainerContent,
        }}
      >
        <Table
          data={activeProcess?.data?.groupOfProcesses?.fields ?? []}
          columns={columns}
          noDataText={'Активных процессов не найдено'}
          loading={isLoading}
        />
        {hasActiveProcess && <LinearProgress />}
      </Underlay>
    </div>
  )
}
