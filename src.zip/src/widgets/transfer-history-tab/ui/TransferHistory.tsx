import { type ProcessInfoDto } from '@sber-pprb-tkp/tcpf-support-admin-api'
import { useMutation } from '@tanstack/react-query'
import { type ColumnDef } from '@tanstack/react-table'
import { LinearProgress } from '@v-uik/base'
import React, { type FC, useMemo } from 'react'

import { ProcessGroupDictionary } from '@/entities/process-group'
import {
  fetchHistory,
  type FetchHistoryParams,
  useTransferHistoryColumns,
} from '@/entities/transfer-history'
import {
  HistoryFilter,
  type ProcessHistoryFilterOutputValues,
} from '@/features/process-history'
import { useVirtualization } from '@/shared/lib'
import { type Option } from '@/shared/model'
import { Table } from '@/shared/ui/Table'

import styles from './TransferHistory.module.scss'

export const TransferHistory: FC = () => {
  const { isPending, data, mutate, reset } = useMutation({
    mutationFn: (params: FetchHistoryParams) => {
      return fetchHistory(params)
    },
  })

  const loadHistory = ({
    period,
    groupIds,
  }: ProcessHistoryFilterOutputValues) => {
    const [startDate, endDate] = period
    mutate({ groupIds, startDate, endDate })
  }

  const processesSelectOptions: Option<number[]>[] = [
    {
      label: 'Формирование задания',
      value: [ProcessGroupDictionary.GET_TASK_TO_TRANSFERRING],
    },
    { label: 'Перенос', value: [ProcessGroupDictionary.TRANSFER_CLIENTS] },
    {
      label: 'Очистка',
      value: [ProcessGroupDictionary.DELETE_TRANSFERRED_CLIENTS],
    },
  ]

  const columns: ColumnDef<ProcessInfoDto>[] = useTransferHistoryColumns()

  const defaultOption: Option<number[]> = {
    label: 'Все',
    value: [
      ProcessGroupDictionary.GET_TASK_TO_TRANSFERRING,
      ProcessGroupDictionary.TRANSFER_CLIENTS,
      ProcessGroupDictionary.DELETE_TRANSFERRED_CLIENTS,
    ],
  }

  const processInfo = useMemo(
    () => data?.flatMap(({ fields }) => fields ?? []),
    [data]
  )

  const virtualizationPlugin = useVirtualization<ProcessInfoDto>()

  return (
    <div className={styles.container}>
      <HistoryFilter
        groupIdOptions={[defaultOption, ...processesSelectOptions]}
        onSubmit={loadHistory}
        onClear={reset}
      />
      <div className={styles.tableWrapper}>
        <Table
          data={processInfo ?? []}
          columns={columns}
          noDataText={'Нет данных за выбранный период'}
          plugins={[virtualizationPlugin]}
        />
        <LinearProgress style={{ display: isPending ? 'block' : 'none' }} />
      </div>
    </div>
  )
}
