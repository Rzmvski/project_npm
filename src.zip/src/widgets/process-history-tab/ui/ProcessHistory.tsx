import { type ProcessDataHistoryDto } from '@sber-pprb-tkp/tcpf-support-admin-api'
import { useMutation } from '@tanstack/react-query'
import { type ColumnDef } from '@tanstack/react-table'
import { CircularProgress, LinearProgress } from '@v-uik/base'
import React, { type FC } from 'react'

import { useProcessGroups } from '@/entities/process-group'
import {
  fetchProcessHistory,
  type FetchProcessHistoryParams,
  useProcessHistoryColumns,
} from '@/entities/process-history'
import {
  HistoryFilter,
  ProcessDetails,
  type ProcessHistoryFilterOutputValues,
} from '@/features/process-history'
import { useExpandedRow, useVirtualization } from '@/shared/lib'
import { type Option } from '@/shared/model'
import { Table } from '@/shared/ui/Table'

import styles from './ProcessHistory.module.scss'

export const ProcessHistory: FC = () => {
  const { isPending, data, mutate, reset } = useMutation({
    mutationFn: (params: FetchProcessHistoryParams) => {
      return fetchProcessHistory(params)
    },
  })
  const { processGroups, isLoading: isProcessGroupsLoading } = useProcessGroups()
  const options: Option<number[]>[] = processGroups.map(({ id, label }) => ({
    value: [Number(id)],
    label,
  }))

  const loadHistory = ({ period, groupIds }: ProcessHistoryFilterOutputValues) => {
    const [startDate, endDate] = period
    mutate({ startDate, endDate, groupIds, groupName: 'VIEW_PROCESS_HISTORY' })
  }

  const columns: ColumnDef<ProcessDataHistoryDto>[] = useProcessHistoryColumns()

  const virtualizationPlugin = useVirtualization<ProcessDataHistoryDto>()

  const expandedPlugin = useExpandedRow<ProcessDataHistoryDto>({
    renderExpandedContent: ({ original }) => {
      return <ProcessDetails sessionId={Number(original.sessionId)} />
    },
  })

  return (
    <div className={styles.container}>
      <CircularProgress isLoading={isProcessGroupsLoading}>
        <HistoryFilter groupIdOptions={options} onSubmit={loadHistory} onClear={reset} />
      </CircularProgress>
      <div className={styles.tableWrapper}>
        <Table
          data={data ?? []}
          columns={columns}
          noDataText={'Нет данных за выбранный период'}
          plugins={[virtualizationPlugin, expandedPlugin]}
        />
        <LinearProgress style={{ display: isPending ? 'block' : 'none' }} />
      </div>
    </div>
  )
}
