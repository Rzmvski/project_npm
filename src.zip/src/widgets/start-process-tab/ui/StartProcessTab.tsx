import { useQueries } from '@tanstack/react-query'
import { type ColumnDef } from '@tanstack/react-table'
import { Button, generateId, modal, type ShowOptions } from '@v-uik/base'
import { PlayIcon } from 'lucide-react'
import React, { type FC, useMemo, useState } from 'react'

import { StatusTag } from '@/entities/dictionary'
import { fetchProcessById, useProcessColumns } from '@/entities/process'
import { type ProcessGroup, useProcessGroups } from '@/entities/process-group'
import { type ActiveProcessGroup, StartProcessModal } from '@/features/start-process-group'
import {
  formatDate,
  useBeforeUnload,
  useExpandedRow,
  useManagedRow,
  usePinnedColumns,
  useVirtualization,
} from '@/shared/lib'
import { ErrorBoundary } from '@/shared/ui/ErrorBoundary'
import { Table } from '@/shared/ui/Table'

import styles from './StartProcessTab.module.scss'

export const StartProcessTab: FC = () => {
  const { isLoading, processGroups } = useProcessGroups()
  const [activeGroups, setActiveGroups] = useState<ActiveProcessGroup[]>([])
  const detailsColumns = useProcessColumns()

  const processQueries = useQueries({
    queries: activeGroups.map(({ activeProcessId }) => ({
      queryKey: ['process', activeProcessId],
      queryFn: () => fetchProcessById(activeProcessId),
      refetchInterval: (query: { state: { data?: { done: boolean } } }) =>
        query.state.data?.done ? false : 1000,
    })),
  })

  const activeGroupEntities = useMemo(
    () => Object.fromEntries(activeGroups.map((group) => [group.groupId, group])),
    [activeGroups],
  )
  const processEntities = useMemo(
    () =>
      Object.fromEntries(
        activeGroups.flatMap((group, index) => {
          const process = processQueries[index]?.data
          return process ? [[group.activeProcessId, process]] : []
        }),
      ),
    [activeGroups, processQueries],
  )
  const isPending = activeGroups.some((group) => {
    const process = processEntities[group.activeProcessId]
    return !process?.done
  })

  useBeforeUnload({ isPending })

  const handleStarted = (group: ActiveProcessGroup) => {
    setActiveGroups((current) => [
      ...current.filter(({ groupId }) => groupId !== group.groupId),
      group,
    ])
  }

  const columns: ColumnDef<ProcessGroup>[] = useMemo(
    () => [
      {
        header: 'Наименование',
        accessorKey: 'label',
        size: 230,
        minSize: 230,
        maxSize: 360,
      },
      {
        id: 'status',
        header: 'Статус',
        cell: ({ row: { original } }) => {
          const activeGroup = activeGroupEntities[original.id]
          if (!activeGroup) return null
          const process = processEntities[activeGroup.activeProcessId]
          const statusId = !process
            ? 'CREATED'
            : !process.done || !process.data?.groupOfProcesses?.statusGroup
              ? 'WORKS'
              : process.data.groupOfProcesses.statusGroup
          return <StatusTag statusId={statusId} />
        },
      },
      {
        id: 'startDate',
        header: 'Дата запуска',
        cell: ({ row: { original } }) => {
          const startDate = activeGroupEntities[original.id]?.startDate
          return startDate ? formatDate(startDate, 'dd.MM.yyyy') : null
        },
      },
    ],
    [activeGroupEntities, processEntities],
  )

  const virtualizationPlugin = useVirtualization<ProcessGroup>()
  const expandedRowPlugin = useExpandedRow<ProcessGroup>({
    renderExpandedContent: ({ original }) => {
      const activeGroup = activeGroupEntities[original.id]
      if (!activeGroup) return null
      const process = processEntities[activeGroup.activeProcessId]
      return (
        <ErrorBoundary>
          <Table
            data={process?.data?.groupOfProcesses?.fields ?? []}
            columns={detailsColumns}
          />
        </ErrorBoundary>
      )
    },
  })
  const managedRowPlugin = useManagedRow<ProcessGroup>({
    options: {
      header: 'Действие',
      maxSize: 150,
    },
    template: ({ row: { original } }) => {
      const handleClick = () => {
        const modalId = generateId()
        modal.show(modalId, {
          content: (
            <StartProcessModal
              modalId={modalId}
              processGroup={original}
              onStarted={handleStarted}
            />
          ),
        } as ShowOptions)
      }

      return (
        <Button
          aria-label={`Запустить группу «${original.label}»`}
          title={`Запустить группу «${original.label}»`}
          kind={'ghost'}
          color={'secondary'}
          size={'sm'}
          prefixIcon={<PlayIcon />}
          onClick={handleClick}
          disabled={Boolean(activeGroupEntities[original.id])}
        />
      )
    },
  })
  const pinnedColumnsPlugin = usePinnedColumns<ProcessGroup>({ left: ['label'] })

  return (
    <div className={styles.container}>
      <div className={styles.containerContent}>
        <Table
          data={processGroups}
          columns={columns}
          loading={isLoading}
          plugins={[
            virtualizationPlugin,
            expandedRowPlugin,
            managedRowPlugin,
            pinnedColumnsPlugin,
          ]}
        />
      </div>
    </div>
  )
}
