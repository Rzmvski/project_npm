import {
  ReplicationStateDto,
  ServiceModeStateDto,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { useServiceMode } from '@/entities/service-mode'
import {
  ShardState,
  useShardReplicationStatus,
} from '@/entities/shard-replication'

const getShardState = (
  serviceModeRequired: boolean,
  serviceModeEnabled: boolean,
  replicationState: ReplicationStateDto
) => {
  if (serviceModeRequired && !serviceModeEnabled) {
    return ShardState.SERVICE_MODE_REQUIRED
  }

  switch (replicationState) {
    case ReplicationStateDto.Required:
      return ShardState.SYNC_REQUIRED
    case ReplicationStateDto.InProgress:
      return ShardState.SYNCING
    case ReplicationStateDto.Failed:
      return ShardState.FAILED
    case ReplicationStateDto.Done:
      return ShardState.READY
  }
}

export const useShardAvailability = (shardId: number) => {
  const { data: serviceMode, isLoading: isModeLoading } = useServiceMode()
  const isServiceModeSupported =
    serviceMode?.status !== ServiceModeStateDto.Unsupported
  const {
    data: replication,
    isEnabled: isReplicationEnabled,
    isLoading: isReplicationLoading,
  } = useShardReplicationStatus({
    shardId,
    enabled: isServiceModeSupported,
  })

  const shardState = getShardState(
    isServiceModeSupported,
    serviceMode?.status === ServiceModeStateDto.Enabled,
    replication?.status ?? ReplicationStateDto.Required
  )

  return {
    shardState,
    editable: shardState === ShardState.READY || !isReplicationEnabled,
    showStatus: isReplicationEnabled,
    isStateLoading: isModeLoading || isReplicationLoading,
  }
}
