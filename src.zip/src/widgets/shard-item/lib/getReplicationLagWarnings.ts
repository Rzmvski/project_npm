import { type ActiveWarning } from '@/entities/warning'
import { formatDurationMilliseconds } from '@/shared/lib/datetime'

interface LoadInfo {
  nodeKey: string
  load: number
}

interface MonitoringInfo {
  replicaLag?: number | null
}

export const replicationLagWarningType = 'replication-lag'

export const getReplicationLagWarnings = (
  currentNodes: LoadInfo[],
  nextNodes: LoadInfo[],
  monitoringEntities: Record<string, MonitoringInfo>,
  unsafeLagThreshold?: number,
): ActiveWarning[] => {
  const currentLoad = new Map(currentNodes.map((node) => [node.nodeKey, node.load]))
  const loadChanged = nextNodes.some(({ nodeKey, load }) => load !== currentLoad.get(nodeKey))

  if (!loadChanged || unsafeLagThreshold == null) {
    return []
  }

  return nextNodes.flatMap(({ nodeKey }) => {
    const replicaLag = monitoringEntities[nodeKey]?.replicaLag

    if (replicaLag == null || replicaLag < unsafeLagThreshold) {
      return []
    }

    return [
      {
        id: nodeKey,
        type: replicationLagWarningType,
        message: `На ноде ${nodeKey} лаг репликации ${formatDurationMilliseconds(replicaLag)} превышает безопасный порог ${formatDurationMilliseconds(unsafeLagThreshold)}.`,
      },
    ]
  })
}
