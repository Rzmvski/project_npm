import {
  ApplicationStatusDto,
  type ScriptApplicationDto,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { Button, Checkbox, Input, LabelControl } from '@v-uik/base'
import { ArchiveIcon, RefreshCwIcon, Search } from 'lucide-react'
import React, { type FC } from 'react'

import { useScriptRequests, useUpdatableScriptRequests } from '@/entities/script-request'
import {
  useScriptRequestsColumns,
  useArchivePartition,
  useManageSelectedRequests,
  ManageButtons,
} from '@/features/manage-script-requests'
import {
  createObjectMatcher,
  useManagedRow,
  usePagination,
  usePinnedColumns,
  useRowSelection,
  useSearch,
} from '@/shared/lib'
import { Paginator } from '@/shared/ui/Paginator'
import { Table } from '@/shared/ui/Table'

import styles from './ManageScriptRequest.module.scss'

const matcher = createObjectMatcher<ScriptApplicationDto>({
  caseSensitive: false,
  deep: true,
  fields: ['reasonId', 'jiraId', 'createdBy', 'status', 'resolvedBy'],
})

export const ManageScriptRequest: FC = () => {
  const columns = useScriptRequestsColumns()
  const { requests, isLoading, isFetching, refetch } = useScriptRequests()

  useUpdatableScriptRequests()

  const { partitionedApplications, toggleShowArchived, showArchived } =
    useArchivePartition(requests)
  const {
    result: filteredRequests,
    searchQuery,
    setSearchQuery,
  } = useSearch({
    items: partitionedApplications,
    searchFn: (items, query) =>
      items.filter((application) => {
        return matcher(application, query)
      }),
  })

  const {
    selectedIds,
    removeRowSelection,
    plugin: selectionPlugin,
  } = useRowSelection<ScriptApplicationDto>({
    getRowId: ({ reasonId }) => reasonId,
    selectOptions: {
      enableRowSelection: ({ original }) => {
        const { status } = original
        if (!status) return false
        const disableRowSelectionStatuses = [
          ApplicationStatusDto.Archived,
          ApplicationStatusDto.Works,
        ]
        return !disableRowSelectionStatuses.includes(status)
      },
    },
  })

  const { mutate } = useManageSelectedRequests({
    selectedRequestIds: selectedIds,
    removeRowSelection,
  })

  const handleBatchArchiveClick = () => {
    mutate(ApplicationStatusDto.Archived)
  }

  const {
    plugin: paginationPlugin,
    pageIndex,
    pageSize,
    changeSize,
    changePage,
  } = usePagination<ScriptApplicationDto>()
  const pinnedColumnsPlugin = usePinnedColumns<ScriptApplicationDto>({
    left: ['select', 'reasonId'],
  })
  const managedRowPlugin = useManagedRow<ScriptApplicationDto>({
    options: {
      size: 160,
    },
    template: ({ row: { original } }) => <ManageButtons application={original} />,
  })

  return (
    <div className={styles.container}>
      <div className={styles.tableSection}>
        <div className={styles.tableSectionContent}>
          <div className={styles.header}>
            <div className={styles.filters}>
              <Input
                value={searchQuery}
                prefix={<Search />}
                onChange={setSearchQuery}
                placeholder={'Поиск по заявкам'}
                size={'sm'}
              />
              <div>
                <LabelControl
                  size={'sm'}
                  label={'Показать архивные заявки'}
                  control={<Checkbox />}
                  checked={showArchived}
                  onChange={toggleShowArchived}
                />
              </div>
            </div>
          </div>
          <div className={styles.table}>
            <Table
              data={filteredRequests}
              columns={columns}
              loading={isLoading}
              defaultSorting={[
                {
                  id: 'created',
                  desc: true,
                },
              ]}
              plugins={[selectionPlugin, paginationPlugin, pinnedColumnsPlugin, managedRowPlugin]}
            />
          </div>
        </div>
      </div>
      <div className={styles.footer}>
        <div className={styles.buttons}>
          <Button
            kind={'outlined'}
            disabled={isFetching}
            onClick={() => refetch()}
            prefixIcon={<RefreshCwIcon />}
          >
            {'Обновить'}
          </Button>
          <Button
            kind={'outlined'}
            disabled={!selectedIds.length}
            prefixIcon={<ArchiveIcon />}
            onClick={handleBatchArchiveClick}
          >
            {'Архивировать'}
          </Button>
        </div>
        <Paginator
          rowAmount={filteredRequests.length}
          pageNumber={pageIndex}
          pageSize={pageSize}
          onPageChange={changePage}
          onPageSizeChange={changeSize}
        />
      </div>
    </div>
  )
}
