import { type GeoBalancingServiceDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { ModalBody, ModalHeader } from '@v-uik/base'
import '@xyflow/react/dist/style.css'
import React, { type FC, useState } from 'react'
import { FormProvider, useWatch } from 'react-hook-form'

import {
  type TrafficRestriction,
  TrafficRestrictionViewer,
} from '@/entities/traffic-restriction'
import { RestrictionGraph } from '@/features/build-restriction-graph'
import {
  type ManageMode,
  TrafficRestrictionForm,
  useTrafficRestrictionForm,
} from '@/features/manage-traffic-restriction'

import styles from './TrafficRestrictionModal.module.scss'

const headers: Record<ManageMode, string> = {
  create: 'Создание ограничения',
  edit: 'Редактирование ограничения',
  view: 'Просмотр ограничения',
}

interface TrafficRestrictionModalProps {
  mode: ManageMode
  restriction?: TrafficRestriction
  onClose: () => void
  onDelete: (id: string) => void
  dataCenters: string[]
  services: GeoBalancingServiceDto[]
}

export const TrafficRestrictionModal: FC<TrafficRestrictionModalProps> = ({
  mode,
  restriction,
  onClose,
  onDelete,
  dataCenters,
  services,
}) => {
  const [currentMode, setCurrentMode] = useState<ManageMode>(mode)
  const form = useTrafficRestrictionForm({ restriction })
  const { control } = form
  const restrictedApplications = useWatch({ control, name: 'applications' })
  const restrictedDataCentres = useWatch({ control, name: 'dataCenters' })
  const restrictionId = useWatch({
    control,
    name: 'id',
  })

  const handleEditClick = () => {
    setCurrentMode('edit')
  }

  const handleCancel = () => {
    form.reset()
    onClose()
  }

  return (
    <>
      <ModalHeader>
        <span>{headers[currentMode]}</span>
      </ModalHeader>
      <ModalBody
        classes={{
          scrollContainer: styles.modalBody,
          body: styles.modalContainer,
        }}
      >
        <div className={styles.leftPanel}>
          <FormProvider {...form}>
            {currentMode == 'view' && restriction ? (
              <TrafficRestrictionViewer
                restriction={restriction}
                onEditClick={handleEditClick}
                onDeleteClick={onDelete}
              />
            ) : (
              <TrafficRestrictionForm
                onClose={handleCancel}
                mode={currentMode}
              />
            )}
          </FormProvider>
        </div>
        <div className={styles.rightPanel}>
          <RestrictionGraph
            allDataCenters={dataCenters}
            services={services}
            restrictedApplications={restrictedApplications}
            restrictedDataCenters={restrictedDataCentres}
            currentRestrictionId={restrictionId}
          />
        </div>
      </ModalBody>
    </>
  )
}
