import { useNavigate } from '@tanstack/react-router'
import React, { type FC } from 'react'

import { DashboardServiceCard } from '@/entities/service'
import { AccessGuard } from '@/features/access-check'
import { useServices } from '@/features/service-config'
import { type RoutePath } from '@/shared/config'

import styles from './ServiceGrid.module.scss'

export const ServiceGrid: FC = () => {
  const navigate = useNavigate()
  const { services } = useServices()

  const handleServiceClick = (route: RoutePath) => {
    navigate({ to: route })
  }

  if (services.length === 0) {
    return (
      <div>
        <h3>Нет доступных сервисов</h3>
      </div>
    )
  }

  return (
    <div className={styles.container}>
      {services.map(({ route, title, permissions, Icon }) => (
        <AccessGuard key={route} requiredPermissions={permissions}>
          <DashboardServiceCard
            Icon={Icon}
            title={title}
            onClick={() => handleServiceClick(route)}
          />
        </AccessGuard>
      ))}
    </div>
  )
}
