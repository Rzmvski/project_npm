import { type ProcessInfoDto } from '@sber-pprb-tkp/tcpf-support-admin-api'
import { type ColumnDef } from '@tanstack/react-table'
import { LinearProgress, Underlay } from '@v-uik/base'
import React, { type FC } from 'react'
import { FormProvider } from 'react-hook-form'

import { useActiveProcesses } from '@/entities/process'
import { ProcessGroupDictionary } from '@/entities/process-group'
import { useTransferHistoryColumns } from '@/entities/transfer-history'
import {
  fetchTransfer,
  TransferClientsForm,
  useTransferClientForm,
} from '@/features/transfer-clients'
import { Table } from '@/shared/ui/Table'



import styles from './TransferClients.module.scss'

export const TransferClients: FC = () => {
  const {
    isLoading,
    setActiveProcessId,
    activeProcess,
    hasActiveProcess,
    stopActiveProcess,
  } = useActiveProcesses(ProcessGroupDictionary.TRANSFER_CLIENTS)

  const form = useTransferClientForm()
  const { handleSubmit } = form

  const columns: ColumnDef<ProcessInfoDto>[] = useTransferHistoryColumns()

  const onSubmitHandler = handleSubmit((data) => {
    fetchTransfer(data).then(({ idOfStartedProcess, errorMessage }) => {
      if (!idOfStartedProcess || errorMessage) {
        throw Error(errorMessage)
      }
      setActiveProcessId(idOfStartedProcess)
    })
  })

  return (
    <div className={styles.container}>
      <FormProvider {...form}>
        <TransferClientsForm
          onSubmit={onSubmitHandler}
          onCancel={stopActiveProcess}
          hasActiveProcesses={hasActiveProcess}
        />
      </FormProvider>
      <Underlay className={styles.row} classes={{ content: styles.rowContent }}>
        <Table
          data={activeProcess?.data?.groupOfProcesses?.fields ?? []}
          columns={columns}
          noDataText={'Активных процессов не найдено'}
          loading={isLoading}
        />
        {hasActiveProcess && <LinearProgress />}
      </Underlay>
    </div>
  )
}
