import { waitFor } from '@testing-library/react'
import { beforeEach, describe, expect, it, vi } from 'vitest'

import * as processApi from '@/entities/process'
import * as routeApi from '@/entities/route'
import {
  processFixture,
  processMutationFixture,
  routesFixture,
  TEST_PROCESS_ID,
  TEST_TENANT_ID,
} from '@/test'

import { ProcessFormTestModel } from './SaveProcessForm.test-model'

describe('process form', () => {
  beforeEach(() => {
    vi.spyOn(processApi, 'getProcesses').mockResolvedValue([processFixture()])
    vi.spyOn(processApi, 'getProcessTypes').mockResolvedValue({
      processTypes: ['DB_PROCESS', 'MAINTENANCE'],
    })
    vi.spyOn(routeApi, 'getAvailableRoutes').mockResolvedValue(routesFixture)
  })

  it('creates a process from user-entered data', async () => {
    const createProcess = vi.spyOn(processApi, 'createProcess').mockResolvedValue(
      processMutationFixture({
        processId: 'new-process-id',
        processName: 'Ночной перерасчёт',
        label: 'Расчёты',
      }),
    )
    const form = await ProcessFormTestModel.create()

    await form.fillRequiredFields()
    await form.submit('Создать процесс')

    await waitFor(() =>
      expect(createProcess).toHaveBeenCalledWith(
        TEST_TENANT_ID,
        expect.objectContaining({
          processName: 'Ночной перерасчёт',
          processType: 'DB_PROCESS',
          label: 'Расчёты',
          cmd: 'python /opt/jobs/recalculate.py',
          routes: [{ routeKey: 'db-main.users', isLabel: false }],
        }),
      ),
    )
  })

  it('prefills and sends the complete command when a process is edited', async () => {
    const updateProcess = vi
      .spyOn(processApi, 'updateProcess')
      .mockResolvedValue(processMutationFixture())
    const form = await ProcessFormTestModel.edit()

    expect(await form.command()).toHaveValue('python /opt/etl/daily_load.py --date today')

    await form.replaceCommand('python /opt/etl/daily_load.py --date tomorrow')
    await form.submit('Сохранить изменения')

    await waitFor(() =>
      expect(updateProcess).toHaveBeenCalledWith(
        TEST_TENANT_ID,
        TEST_PROCESS_ID,
        expect.objectContaining({
          cmd: 'python /opt/etl/daily_load.py --date tomorrow',
        }),
      ),
    )
  })
})
