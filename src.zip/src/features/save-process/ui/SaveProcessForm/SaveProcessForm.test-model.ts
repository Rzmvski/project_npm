import { screen, waitFor } from '@testing-library/react'
import { expect } from 'vitest'

import { Permission } from '@/entities/access'
import { processFixture, renderApp, TEST_PROCESS_ID, userAccessFixture } from '@/test'

import type { UserEvent } from '@testing-library/user-event'

export class ProcessFormTestModel {
  private constructor(
    readonly user: UserEvent,
    readonly router: Awaited<ReturnType<typeof renderApp>>['router'],
  ) {}

  static async create() {
    const app = await renderApp({
      route: '/processes/new',
      access: userAccessFixture([Permission.PROCESS_LIST, Permission.PROCESS_CREATE]),
      processes: [processFixture()],
      processTypes: ['DB_PROCESS', 'MAINTENANCE'],
    })

    await screen.findByRole('heading', { name: 'Новый процесс' })
    return new ProcessFormTestModel(app.user, app.router)
  }

  static async edit() {
    const app = await renderApp({
      route: `/processes/${TEST_PROCESS_ID}/edit`,
      access: userAccessFixture([Permission.PROCESS_LIST, Permission.PROCESS_UPDATE]),
      processes: [processFixture()],
      processTypes: ['DB_PROCESS'],
    })

    await screen.findByRole('heading', {
      name: 'Дневная загрузка данных',
    })
    return new ProcessFormTestModel(app.user, app.router)
  }

  field(name: string | RegExp) {
    return screen.getByRole('textbox', { name })
  }

  command() {
    return screen.findByRole('textbox', { name: 'Редактор команды' }, { timeout: 3_000 })
  }

  async fillRequiredFields() {
    await this.user.type(this.field('Название'), 'Ночной перерасчёт')
    await this.user.selectOptions(
      screen.getByRole('combobox', { name: 'Тип процесса' }),
      'DB_PROCESS',
    )
    await this.user.type(this.field('Категория'), 'Расчёты')
    await this.user.type(await this.command(), 'python /opt/jobs/recalculate.py')
    await this.user.selectOptions(
      screen.getByRole('listbox', { name: 'Базы данных' }),
      'db-main.users',
    )
  }

  async replaceCommand(command: string) {
    const editor = await this.command()
    await this.user.clear(editor)
    await this.user.type(editor, command)
  }

  async submit(label: 'Создать процесс' | 'Сохранить изменения') {
    const button = screen.getByRole('button', { name: label })
    await waitFor(() => expect(button).toBeEnabled())
    await this.user.click(button)
  }
}
