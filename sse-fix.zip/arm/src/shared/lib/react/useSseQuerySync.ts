import { type QueryKey, useQueryClient } from '@tanstack/react-query'
import { useRef } from 'react'

import { type SseStreamFactory } from '@/shared/api/sse'

import { useSse } from './useSse'

export interface UseSseQuerySyncOptions<TItem> {
  /** Ключ запроса react-query, кэш которого обновляет поток. */
  queryKey: QueryKey
  /** Поток элементов: одно SSE-событие — один элемент списка. */
  stream: SseStreamFactory<TItem>
  enabled?: boolean
  /** По умолчанию считается из `queryKey`. */
  subscriptionKey?: string
  /**
   * Пауза перед переподключением, мс. По умолчанию `null` — не
   * переподключаться.
   *
   * Списочные эндпоинты admin-app закрывают поток сразу после последнего
   * элемента: это снимок, а не живой стрим. С автоматическим ретраем UI
   * открывал бы новое соединение каждые несколько секунд, не получая новых
   * данных. Когда бэкенд начнёт досылать обновления в открытое соединение,
   * значение можно будет вернуть.
   */
  retryDelay?: number | null
  onMessage?: (items: TItem[]) => void
}

/**
 * Держит SSE-подписку и складывает пришедшие элементы в кэш react-query по
 * `queryKey`. Начальную загрузку по-прежнему делает обычный `useQuery` — поток
 * только поддерживает данные в актуальном состоянии.
 *
 * Каждое событие — один элемент списка, поэтому элементы копятся в буфер, а в
 * кэш уходит накопленный массив: таблица заполняется по мере прихода данных.
 * Новое соединение начинает снимок заново, иначе после переподключения список
 * задвоился бы.
 */
export const useSseQuerySync = <TItem>({
  queryKey,
  stream,
  enabled = true,
  subscriptionKey,
  retryDelay = null,
  onMessage,
}: UseSseQuerySyncOptions<TItem>) => {
  const queryClient = useQueryClient()
  const bufferRef = useRef<TItem[]>([])

  return useSse<TItem>({
    stream,
    enabled,
    retryDelay,
    subscriptionKey: subscriptionKey ?? JSON.stringify(queryKey),
    onOpen: () => {
      bufferRef.current = []
    },
    onMessage: (item) => {
      bufferRef.current = [...bufferRef.current, item]
      queryClient.setQueryData(queryKey, bufferRef.current)
      onMessage?.(bufferRef.current)
    },
  })
}
