import { useEffect, useRef, useState } from 'react'

import { type SseStreamFactory, subscribeToSse } from '@/shared/api/sse'

export type SseStatus = 'closed' | 'connecting' | 'open' | 'error'

export interface UseSseOptions<T> {
  /**
   * Фабрика потока из сгенерированного клиента, например
   * `(signal) => clusterManagementService.getNodesStream({ signal })`.
   * Она пересоздаётся на каждом рендере, поэтому в зависимости эффекта не
   * входит — за переоткрытие потока отвечает `subscriptionKey`.
   */
  stream: SseStreamFactory<T>
  /** Стабильный ключ подписки: при его смене поток переоткрывается. */
  subscriptionKey?: string
  enabled?: boolean
  /** Пауза перед переподключением, мс. `null` — не переподключаться. */
  retryDelay?: number | null
  onMessage?: (data: T) => void
  /** Вызывается перед первым событием каждого установленного соединения. */
  onOpen?: () => void
  onError?: (error: unknown) => void
}

const DEFAULT_RETRY_DELAY = 3000

export const useSse = <T>({
  stream,
  subscriptionKey = '',
  enabled = true,
  retryDelay = DEFAULT_RETRY_DELAY,
  onMessage,
  onOpen,
  onError,
}: UseSseOptions<T>) => {
  const [data, setData] = useState<T>()
  const [error, setError] = useState<unknown>()
  const [status, setStatus] = useState<SseStatus>(enabled ? 'connecting' : 'closed')
  const streamRef = useRef(stream)
  const onMessageRef = useRef(onMessage)
  const onOpenRef = useRef(onOpen)
  const onErrorRef = useRef(onError)

  streamRef.current = stream
  onMessageRef.current = onMessage
  onOpenRef.current = onOpen
  onErrorRef.current = onError

  useEffect(() => {
    if (!enabled) {
      setStatus('closed')
      return
    }

    setStatus('connecting')
    setError(undefined)

    const subscription = subscribeToSse<T>({
      stream: (signal) => streamRef.current(signal),
      retryDelay,
      onOpen: () => {
        setStatus('open')
        onOpenRef.current?.()
      },
      onError: (nextError) => {
        setError(nextError)
        setStatus('error')
        onErrorRef.current?.(nextError)
      },
      onMessage: (nextData) => {
        setData(nextData)
        onMessageRef.current?.(nextData)
      },
    })

    return subscription.close
    // subscriptionKey не используется в теле эффекта: это внешний сигнал
    // «поток изменился, переподпишись», поэтому он и стоит в зависимостях.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled, retryDelay, subscriptionKey])

  return {
    data,
    error,
    status,
    isConnecting: status === 'connecting',
    isOpen: status === 'open',
  }
}
