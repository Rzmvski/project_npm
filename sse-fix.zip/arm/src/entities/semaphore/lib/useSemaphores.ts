import { type QueryKey, useQuery } from '@tanstack/react-query'

import { fetchSemaphores, streamSemaphores } from '@/entities/semaphore/api'
import { type Semaphore } from '@/entities/semaphore/model'
import { useSseQuerySync } from '@/shared/lib'

export const semaphoresQueryKey: QueryKey = ['semaphores']

interface UseSemaphoresOptions {
  /**
   * Держать SSE-подписку `ClusterManagementServiceApiSse.semaphoreInfoStream()`
   * и обновлять кэш ['semaphores'] по мере прихода событий.
   */
  subscribeToUpdates?: boolean
}

export const useSemaphores = ({ subscribeToUpdates = false }: UseSemaphoresOptions = {}) => {
  useSseQuerySync<Semaphore>({
    queryKey: semaphoresQueryKey,
    stream: streamSemaphores,
    enabled: subscribeToUpdates,
  })

  return useQuery({
    initialData: [],
    queryKey: semaphoresQueryKey,
    queryFn: fetchSemaphores,
  })
}
