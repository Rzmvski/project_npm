import { ClusterStateDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { type Semaphore } from '@/entities/semaphore/model'
import { clusterManagementService, collectSse } from '@/shared/api'

/** Снимок состояния семафорных кластеров: эндпоинт отвечает только SSE. */
export const fetchSemaphores = async (): Promise<Semaphore[]> => {
  const response = await collectSse(clusterManagementService.semaphoreInfoStream())

  return response.map(({ status, ...semaphore }) => ({
    ...semaphore,
    status: status ?? ClusterStateDto.Unrecognized,
  }))
}
