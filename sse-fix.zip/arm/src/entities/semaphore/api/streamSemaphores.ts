import { ClusterStateDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { type Semaphore } from '@/entities/semaphore/model'
import { clusterManagementService } from '@/shared/api'
import { type SseStream } from '@/shared/api/sse'

/**
 * SSE-поток состояния семафорных кластеров: одно событие — один кластер.
 *
 * Нормализация статуса повторяет `fetchSemaphores`, чтобы данные из потока и
 * из обычного запроса ложились в один и тот же кэш без расхождений.
 */
export const streamSemaphores = async function* (
  signal: AbortSignal,
): SseStream<Semaphore> {
  const stream = clusterManagementService.semaphoreInfoStream({ signal })

  for await (const { status, ...semaphore } of stream) {
    yield {
      ...semaphore,
      status: status ?? ClusterStateDto.Unrecognized,
    }
  }
}
