import { type NodeDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { type QueryKey, useQuery } from '@tanstack/react-query'

import { fetchNodeInfo, streamNodeInfo } from '@/entities/node'
import { useSseQuerySync } from '@/shared/lib'

export const nodesQueryKey: QueryKey = ['nodes']

interface UseNodesOptions<TData> {
  select?: (data: NodeDto[]) => TData
  /**
   * Держать SSE-подписку `ClusterManagementServiceApiSse.getNodesStream()` и
   * обновлять кэш ['nodes'] по мере прихода событий.
   */
  subscribeToUpdates?: boolean
}

export const useNodes = <TData = NodeDto[]>({
  select,
  subscribeToUpdates = false,
}: UseNodesOptions<TData> = {}) => {
  useSseQuerySync<NodeDto>({
    queryKey: nodesQueryKey,
    stream: streamNodeInfo,
    enabled: subscribeToUpdates,
  })

  return useQuery({
    initialData: [],
    queryKey: nodesQueryKey,
    queryFn: fetchNodeInfo,
    select,
  })
}
