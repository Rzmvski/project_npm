import { type NodeDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { clusterManagementService } from '@/shared/api'
import { type SseStream } from '@/shared/api/sse'

/**
 * SSE-поток состояния нод кластера: одно событие — одна нода.
 *
 * `ClusterManagementServiceApiSse.getNodesStream()` бьёт в тот же путь, что и
 * `getNodes()`, но с заголовком `Accept: text/event-stream`.
 */
export const streamNodeInfo = (signal: AbortSignal): SseStream<NodeDto> => {
  return clusterManagementService.getNodesStream({ signal })
}
