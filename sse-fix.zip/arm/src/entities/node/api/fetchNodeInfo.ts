import { type NodeDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { clusterManagementService, collectSse } from '@/shared/api'

/**
 * Разовый снимок состояния нод.
 *
 * Эндпоинт объявлен в контракте только как `text/event-stream`, поэтому
 * обычный `getNodes()` тут не работает: рантайм сгенерированного клиента зовёт
 * `response.json()` и падает на теле SSE. Берём тот же поток и дочитываем его
 * до конца.
 */
export const fetchNodeInfo = (): Promise<NodeDto[]> => {
  return collectSse(clusterManagementService.getNodesStream())
}
