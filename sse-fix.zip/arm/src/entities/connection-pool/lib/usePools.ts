import { type PoolDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { type QueryKey, useQuery } from '@tanstack/react-query'

import { fetchPools, streamPools } from '@/entities/connection-pool/api'
import { useSseQuerySync } from '@/shared/lib'

export const poolsQueryKey: QueryKey = ['pools']

interface UsePoolsOptions {
  /**
   * Держать SSE-подписку
   * `ConnectionPoolManagementServiceApiSse.getPoolsStream()` и обновлять кэш
   * ['pools'] по мере прихода событий.
   */
  subscribeToUpdates?: boolean
}

export const usePools = ({ subscribeToUpdates = false }: UsePoolsOptions = {}) => {
  useSseQuerySync<PoolDto>({
    queryKey: poolsQueryKey,
    stream: streamPools,
    enabled: subscribeToUpdates,
  })

  return useQuery({
    initialData: [],
    queryKey: poolsQueryKey,
    queryFn: fetchPools,
  })
}
