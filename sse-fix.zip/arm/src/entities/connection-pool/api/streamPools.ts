import { type PoolDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { connectionPoolManagementService } from '@/shared/api'
import { type SseStream } from '@/shared/api/sse'

/** SSE-поток состояния пулов соединений к БД: одно событие — один пул. */
export const streamPools = (signal: AbortSignal): SseStream<PoolDto> => {
  return connectionPoolManagementService.getPoolsStream({ signal })
}
