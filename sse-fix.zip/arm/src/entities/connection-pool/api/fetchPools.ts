import { type PoolDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { collectSse, connectionPoolManagementService } from '@/shared/api'

/**
 * Получить список доступных пулов соединений к БД (по ноде).
 * Method: GET
 * URL: /invoke/support-admin/cluster-management-service/pools
 *
 * Эндпоинт отвечает только `text/event-stream`, поэтому снимок собираем из
 * потока — см. `collectSse`.
 */
export const fetchPools = (): Promise<PoolDto[]> => {
  return collectSse(connectionPoolManagementService.getPoolsStream())
}
