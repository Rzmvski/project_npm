import { IgniteTypeDto, type MonitoringDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { type DbMonitoringInfo } from '@/entities/monitoring/model'
import { collectSse, monitoringManagementService } from '@/shared/api'

/**
 * Оба эндпоинта мониторинга объявлены только как `text/event-stream`, поэтому
 * разовый снимок собираем из потока: обычные методы клиента разбирают тело как
 * JSON и на SSE падают.
 */
export function fetchIgniteMonitoring(
  type: IgniteTypeDto = IgniteTypeDto.All,
): Promise<MonitoringDto[]> {
  return collectSse(monitoringManagementService.getIgniteMonitoringsStream(type))
}

export function fetchDbMonitoring(): Promise<DbMonitoringInfo[]> {
  // Контракт MonitoringDto (platform-api 2.1) по-прежнему не содержит
  // `lastSwitchTime`/`replicaLag` как обязательных полей. Оставляем
  // приведение как формальность до появления этих полей в контракте:
  // `DbMonitoringInfo` добавляет только опциональные поля.
  return collectSse(monitoringManagementService.getDbMonitoringsStream()) as Promise<
    DbMonitoringInfo[]
  >
}
