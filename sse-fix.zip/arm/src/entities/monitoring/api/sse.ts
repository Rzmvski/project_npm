import { type IgniteTypeDto, type MonitoringDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { type DbMonitoringInfo } from '@/entities/monitoring/model'
import { monitoringManagementService } from '@/shared/api'
import { type SseStream } from '@/shared/api/sse'

/**
 * SSE-поток мониторинга БД: одно событие — одна запись мониторинга.
 *
 * Путь, заголовок `Accept: text/event-stream` и разбор событий берёт на себя
 * `MonitoringManagementServiceApiSse` из tcpf-platform-admin-api, поэтому URL
 * здесь больше не собирается руками.
 *
 * Приведение к `DbMonitoringInfo` — та же формальность, что и в
 * `fetchDbMonitoring`: контракт `MonitoringDto` пока не объявляет
 * `lastSwitchTime`/`replicaLag`, а `DbMonitoringInfo` добавляет их
 * опционально.
 */
export const streamDbMonitoring = (signal: AbortSignal): SseStream<DbMonitoringInfo> => {
  return monitoringManagementService.getDbMonitoringsStream({
    signal,
  }) as SseStream<DbMonitoringInfo>
}

/** SSE-поток мониторинга Ignite по выбранному типу. */
export const streamIgniteMonitoring =
  (type?: IgniteTypeDto) =>
  (signal: AbortSignal): SseStream<MonitoringDto> => {
    return monitoringManagementService.getIgniteMonitoringsStream(type, { signal })
  }
