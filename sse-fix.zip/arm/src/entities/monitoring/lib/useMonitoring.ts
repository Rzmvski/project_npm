import { type IgniteTypeDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { useQuery } from '@tanstack/react-query'

import { type DbMonitoringInfo } from '@/entities/monitoring/model'
import { type SseStream } from '@/shared/api'
import { useSseQuerySync } from '@/shared/lib'

import { fetchDbMonitoring, fetchIgniteMonitoring } from '../api/fetch'
import { streamDbMonitoring, streamIgniteMonitoring } from '../api/sse'

export const enum DbType {
  DB = 'DB',
}

interface UseMonitoringParams {
  monitoringType: DbType | IgniteTypeDto
  subscribeToUpdates?: boolean
}

export const useMonitoring = ({
  monitoringType,
  subscribeToUpdates = false,
}: UseMonitoringParams) => {
  const queryKey = ['monitoring', monitoringType] as const
  const query = useQuery({
    queryKey,
    queryFn: () => {
      switch (monitoringType) {
        case DbType.DB:
          return fetchDbMonitoring()
        default:
          return fetchIgniteMonitoring(monitoringType)
      }
    },
  })

  // Первичная загрузка остаётся за useQuery, поток лишь обновляет её кэш.
  const sse = useSseQuerySync<DbMonitoringInfo>({
    queryKey,
    enabled: subscribeToUpdates,
    stream:
      monitoringType === DbType.DB
        ? streamDbMonitoring
        : (streamIgniteMonitoring(monitoringType) as (
            signal: AbortSignal,
          ) => SseStream<DbMonitoringInfo>),
  })

  const monitoringEntities: Record<string, DbMonitoringInfo> = Object.fromEntries(
    (query.data ?? []).map((item) => [item.id, item]),
  )

  return {
    monitoringEntities,
    isLoading: query.isLoading,
    isError: query.isError,
    query,
    sse,
  }
}
