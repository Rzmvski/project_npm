import { type QueryKey, useQuery } from '@tanstack/react-query'

import { fetchDataCenters, streamDataCenters } from '@/entities/data-center'
import { useSseQuerySync } from '@/shared/lib'

export const dataCentersQueryKey: QueryKey = ['data-centers']

interface UseDataCentersOptions {
  /**
   * Держать SSE-подписку
   * `GeoBalancingManagementServiceApiSse.getDataCentersStream()` и обновлять
   * кэш ['data-centers'] по мере прихода событий.
   */
  subscribeToUpdates?: boolean
}

export const useDataCenters = ({
  subscribeToUpdates = false,
}: UseDataCentersOptions = {}) => {
  useSseQuerySync<string>({
    queryKey: dataCentersQueryKey,
    stream: streamDataCenters,
    enabled: subscribeToUpdates,
  })

  return useQuery({
    initialData: [],
    queryKey: dataCentersQueryKey,
    queryFn: () => fetchDataCenters(),
  })
}
