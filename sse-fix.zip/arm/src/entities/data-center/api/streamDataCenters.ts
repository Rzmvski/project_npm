import { geoBalancingManagementService } from '@/shared/api'
import { type SseStream } from '@/shared/api/sse'

/** SSE-поток списка ЦОДов: одно событие — один ЦОД. */
export const streamDataCenters = (signal: AbortSignal): SseStream<string> => {
  return geoBalancingManagementService.getDataCentersStream({ signal })
}
