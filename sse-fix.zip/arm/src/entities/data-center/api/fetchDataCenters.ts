import { collectSse, geoBalancingManagementService } from '@/shared/api'

/** Снимок списка ЦОДов: эндпоинт отвечает только `text/event-stream`. */
export const fetchDataCenters = (): Promise<string[]> => {
  return collectSse(geoBalancingManagementService.getDataCentersStream())
}
