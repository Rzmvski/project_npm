import { type TrafficRestriction } from '@/entities/traffic-restriction/model'
import { geoBalancingManagementService } from '@/shared/api'
import { type SseStream } from '@/shared/api/sse'

/**
 * SSE-поток ограничений трафика: одно событие — одно ограничение.
 *
 * Приведение к `TrafficRestriction` повторяет `fetchRestrictions`, чтобы поток
 * и обычный запрос писали в кэш одну и ту же форму данных.
 */
export const streamRestrictions = async function* (
  signal: AbortSignal,
): SseStream<TrafficRestriction> {
  const stream = geoBalancingManagementService.getTrafficRestrictionsStream({ signal })

  for await (const item of stream) {
    const { services, comment } = item

    yield {
      ...item,
      createComment: comment,
      services: services ?? [],
    } satisfies TrafficRestriction
  }
}
