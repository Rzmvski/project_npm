import { type TrafficRestriction } from '@/entities/traffic-restriction'
import { collectSse, geoBalancingManagementService } from '@/shared/api'

/**
 * У SSE-запросов ошибку бросает рантайм сгенерированного клиента (`ResponseError`),
 * а не наш `HttpError`: middleware для потоков возвращает исходный ответ. Статус
 * достаём утиной типизацией, чтобы не зависеть от того, реэкспортирует ли пакет
 * класс ошибки.
 */
const isNotFound = (error: unknown): boolean => {
  if (typeof error !== 'object' || error === null) return false

  const { response, status } = error as {
    response?: { status?: number }
    status?: number
  }

  return response?.status === 404 || status === 404
}

/** Снимок ограничений трафика: эндпоинт отвечает только `text/event-stream`. */
export const fetchRestrictions = async (): Promise<TrafficRestriction[]> => {
  try {
    const restrictions = await collectSse(
      geoBalancingManagementService.getTrafficRestrictionsStream(),
    )

    return restrictions.map((item) => {
      const { services, comment } = item

      return {
        ...item,
        createComment: comment,
        services: services ?? [],
      } satisfies TrafficRestriction
    })
  } catch (error) {
    if (isNotFound(error)) return []
    throw error
  }
}
