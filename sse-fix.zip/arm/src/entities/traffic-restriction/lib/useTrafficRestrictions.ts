import { type QueryKey, useQuery } from '@tanstack/react-query'
import { useCallback, useState } from 'react'

import { fetchRestrictions, streamRestrictions } from '@/entities/traffic-restriction/api'
import { type TrafficRestriction } from '@/entities/traffic-restriction/model'
import { useSseQuerySync } from '@/shared/lib'

export const trafficRestrictionQueryKey: QueryKey = ['traffic-restrictions']

interface UseTrafficRestrictionsOptions {
  /**
   * Держать SSE-подписку
   * `GeoBalancingManagementServiceApiSse.getTrafficRestrictionsStream()` и
   * обновлять кэш ['traffic-restrictions'] по мере прихода событий.
   */
  subscribeToUpdates?: boolean
}

export const useTrafficRestrictions = ({
  subscribeToUpdates = false,
}: UseTrafficRestrictionsOptions = {}) => {
  const [selectedRestrictionIds, setSelectedRestrictionIds] = useState<
    string[]
  >([])

  const toggleRestriction = useCallback((id: string) => {
    setSelectedRestrictionIds((prev) =>
      prev.includes(id) ? prev.filter((r) => r !== id) : [...prev, id]
    )
  }, [])

  useSseQuerySync<TrafficRestriction>({
    queryKey: trafficRestrictionQueryKey,
    stream: streamRestrictions,
    enabled: subscribeToUpdates,
  })

  const query = useQuery({
    initialData: [],
    queryKey: trafficRestrictionQueryKey,
    queryFn: () => fetchRestrictions(),
  })

  return {
    ...query,
    selectedRestrictionIds,
    toggleRestriction,
  }
}
