import { type ShardDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { clusterManagementService } from '@/shared/api'
import { type SseStream } from '@/shared/api/sse'

/** SSE-поток шард БД вместе с диапазонами бакетов: одно событие — одна шарда. */
export const streamAvailableShards = (signal: AbortSignal): SseStream<ShardDto> => {
  return clusterManagementService.getShardsStream({ signal })
}
