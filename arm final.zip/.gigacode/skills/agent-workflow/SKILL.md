---
name: agent-workflow
description: Coordinate non-trivial project changes through bounded implement, review, validate, and fix cycles with structured feedback between GigaCode agents.
priority: 20
---

# Agent workflow

Use for changes that need implementation plus independent quality checks. Do not activate the full cycle for a read-only answer, a trivial text correction, or a one-line mechanical edit with an obvious focused check.

## Cycle

1. Select one implementation owner from `.gigacode/agents` and give it the requirement, allowed file scope, and acceptance criteria.
2. Require the implementer response contract: `STATUS`, `CHANGED_FILES`, `VALIDATION`, `HANDOFF`.
3. Run `reviewer` and `build-validator` independently after implementation. Add `fsd-architect` for new/moved files, changed public APIs, or import restructuring.
4. Aggregate only actionable `REQUIRED_FIXES`; deduplicate findings and preserve exact command failures.
5. Return the bundle to the same implementation owner. Include file/line, observed result, expected result, and recheck command.
6. Re-run independent checks for the corrected scope.

Stop when all required verifiers return `VERDICT: pass`, when a real blocker needs the user, or after three fix iterations. Recommendations do not keep the cycle open. Never start parallel writers on overlapping files; read-only verifiers may run in parallel.

Use `orchestrator` for this protocol when nested agent delegation is available. Otherwise the primary agent follows the protocol directly.
