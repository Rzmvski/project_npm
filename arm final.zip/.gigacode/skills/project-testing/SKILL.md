---
name: project-testing
description: Add focused Vitest/RTL/mock tests or select and run proportionate validation commands for changes in this project.
priority: 8
---

# Project testing

Read `docs/testing.md` and `docs/validation.md`.

Choose the smallest checks that prove the changed behavior, then expand for cross-cutting risk:

- TS logic: focused test, focused ESLint, TypeScript when contracts/types changed.
- React: focused RTL test and focused ESLint.
- SCSS: focused Stylelint plus browser verification.
- API/mock: mock/API tests and a real local scenario.
- Imports/new slices: Steiger architecture check.
- Cross-cutting changes: `npm run validate`.

Test observable behavior and contracts. Prefer accessible queries and real interactions; avoid arbitrary sleeps, implementation-detail assertions, and coverage-only cases. Use `test-engineer` for writing tests and `build-validator` for independent command execution. A validator must report exact commands, exit codes, skipped checks, and whether a failure is attributable to the change.

Keep test files and `*.test-model.*` artifacts in the nearest `__tests__` directory, mirroring the owning production segment. Do not mix them into the production file list or create a disconnected global mirror of the FSD tree.
