---
name: documentation-maintenance
description: Update README, maintained docs, GIGACODE.md, and GigaCode agent/skill configuration while removing stale duplication and broken references.
priority: 8
---

# Documentation maintenance

Use `docs/README.md` as the documentation map and verify every technical claim against current source/config.

- Keep durable current-state guidance; remove completed migration notes, dated audits, copied external contracts, and compatibility files with no active caller.
- Give each fact one canonical owner and link to it from other documents.
- README describes the project for humans; `GIGACODE.md` contains short persistent agent rules.
- Locked versions and public exports of `@sber-pprb-tkp/*` libraries own the frontend contract. Local `file:` dependencies are temporary and must not become a permanent documented architecture. Production imports use package roots; do not maintain a handwritten endpoint/schema copy.
- GigaCode project skills live at `.gigacode/skills/<name>/SKILL.md`; agent definitions live at `.gigacode/agents/<name>.md`.
- Skill names are lowercase ASCII with hyphens and must match their directory. Agent/skill frontmatter must include a precise `name` and `description`.
- Agent feedback cycles must have explicit response contracts, a single implementation owner, independent read-only checks, a maximum iteration count, and blocker handling.

Use `documentation-writer` for implementation. Run Prettier, validate local Markdown links, and check YAML frontmatter before completion.
