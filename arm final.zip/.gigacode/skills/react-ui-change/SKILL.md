---
name: react-ui-change
description: Implement or review React, VUIK, SCSS Module, responsive layout, accessibility, or visual-state changes in TCPF Support Admin UI.
priority: 10
---

# React UI change

Read `GIGACODE.md`, `docs/design-system.md`, and the target component with its direct styles/tests.

- Reuse VUIK and existing `shared/ui` before creating a primitive.
- Keep business rules in the owning feature/entity, not presentational wrappers.
- Use project Sass variables/tokens and camelCase CSS Module classes.
- Preserve keyboard access, accessible names, focus behavior, and loading/empty/error/pending states.
- For responsive work, reason about the actual content container beside the sidebar, not viewport width alone. Prefer container queries when behavior depends on a card or panel width.
- Avoid nested scroll containers unless each scroll axis has a clear owner. Confirm that the last field and primary action can be reached.

Run focused component tests, ESLint, Stylelint, and Prettier. For layout changes, start the mock app and visually verify the affected route at desktop and the relevant compact breakpoint. Use `ui-react-specialist` as implementation owner and the `agent-workflow` cycle for non-trivial changes.
