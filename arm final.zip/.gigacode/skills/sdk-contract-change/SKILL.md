---
name: sdk-contract-change
description: Adapt TCPF support/platform public SDK usage, TanStack Query hooks, SSE integration, or matching Express mock behavior after @sber-pprb-tkp library changes.
priority: 10
---

# SDK contract change

Read `GIGACODE.md`, `docs/sdk-contract.md`, `docs/mock-server.md`, and the public exports of the locked `@sber-pprb-tkp` library version. When a dependency temporarily uses `file:`, its local `package.json` and `dist/index.d.ts` may be inspected.

Keep these artifacts synchronized:

1. dependency version or local `file:` source;
2. public SDK usage in the owning slice;
3. query keys, caching, invalidation, or SSE consumption;
4. `mock-server/index.js` and fixtures;
5. mock/SDK tests and the affected UI scenario.

Treat the locked package version and its public exports as the contract source. A `Downloads` build is only a temporary pre-publication dependency; normal integration uses a semver package from the internal registry. Import only from the package root in production code. Do not edit `node_modules` or library sources, import package internals, publish private packages without authorization, or replace SDK calls with manual URLs. If a required type or method is absent from public exports, report a library-change blocker. Use generated `LocalDate` helpers, `*ApiSse`, and `useSseQuery` instead of legacy adapters or hand-written serialization. Distinguish absent endpoints (`404`/`405`) from network and server failures before applying fallback behavior.

Use `api-integration-specialist` as implementation owner. Validate the exact endpoint shape, focused tests, TypeScript, and a running mock scenario when behavior is user-visible.
