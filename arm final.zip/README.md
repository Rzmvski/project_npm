# TCPF Support Admin UI

Административный интерфейс ТКП для операционных и платформенных задач: закрытие операционного дня, запуск групп процессов, управление индексами, шардами, переносами клиентов, скриптами, фичами, репликацией и гео-балансировкой.

## Быстрый старт

```bash
npm install
npm run dev
```

API-клиенты должны подключаться как обычные версионируемые библиотеки `@sber-pprb-tkp/*` из внутреннего npm registry. Текущие локальные `file:` dependencies из `/Users/rzmvski/Downloads/@sber-pprb-tkp` — временный способ разработки:

- `tcpf-platform-admin-api` версии `3.0.0`;
- `tcpf-support-admin-api` версии `15.0.4`.

Пока используются временные ссылки, перед `npm install` в каждом каталоге должны существовать `package.json`, `dist/index.js` и `dist/index.d.ts`. После публикации пакетов `file:`-ссылки нужно заменить на согласованные semver-версии. Команда `npm run login:nexus` авторизует npm для установки приватных пакетов.

`dev` через `concurrently` поднимает Vite и stateful Express mock API. В терминале процессы помечены как `WEB` и `API`; при остановке одного завершается второй. Интерфейс доступен на адресе, который напечатает Vite (обычно `http://localhost:5173`), API — на `http://127.0.0.1:3001`. `dev:mock` оставлен как алиас.

Для работы с реальными локальными сервисами:

```bash
npm run dev:server
```

Команда `dev:server` включает Vite mode `dev`: запросы `/platform/*` и `/tkp/*` проксируются на порты из `.env.dev` (8091 и 8092). Основная команда `dev` включает mode `mock`: оба префикса и `/config/*` направляются на Express-сервер.

## Команды

| Команда                     | Назначение                        |
| --------------------------- | --------------------------------- |
| `npm run dev`               | Vite + Express через concurrently |
| `npm run dev:mock`          | Алиас для `npm run dev`           |
| `npm run dev:web`           | Только Vite в mock-режиме         |
| `npm run dev:api`           | Express mock API с watch          |
| `npm run start:api`         | Express mock API без watch        |
| `npm run dev:server`        | Vite с proxy на реальные API      |
| `npm test`                  | Vitest run                        |
| `npm run test:coverage`     | Vitest с coverage                 |
| `npm run lint`              | ESLint + Stylelint + Prettier     |
| `npm run typecheck`         | TypeScript project build          |
| `npm run lint:architecture` | Проверка FSD через Steiger        |
| `npm run build`             | Production-сборка Vite            |
| `npm run validate`          | Полная последовательная проверка  |

## Технологии и структура

Приложение использует React 19, TypeScript, Vite, TanStack Router, TanStack Query 5, React Hook Form, Zod, VUIK и SCSS Modules. Код организован по слоям Feature-Sliced Design:

```text
app → pages → widgets → features → entities → shared
```

Redux и каталог `src/shared/deprecated` удалены. Серверным состоянием владеет TanStack Query, формами — React Hook Form, локальным UI-состоянием — React.

Контракты frontend получает из публичных exports двух библиотек:

- `@sber-pprb-tkp/tcpf-support-admin-api`;
- `@sber-pprb-tkp/tcpf-platform-admin-api`.

Типы DTO, enum, сервисы, `LocalDate`-преобразования и SSE-классы импортируются только из корня этих пакетов. Актуальную версию фиксируют корневые `package.json` и lockfile проекта; путь в `Downloads` используется лишь на время локального подключения.

Подробные правила, архитектура и mock API находятся в [`docs/README.md`](docs/README.md). Инструкции для GigaCode — в [`GIGACODE.md`](GIGACODE.md).
