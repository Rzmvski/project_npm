import React, { type FC } from 'react'

import { ROUTES } from '@/shared/config'
import { ServiceTabs, type TabContent } from '@/shared/ui/ServiceTabs'
import { FeatureStatisticsTab } from '@/widgets/feature-statistics-tab'
import { ManageFeatureApplicationsTab } from '@/widgets/manage-feature-applications-tab'
import { ManageFeaturesTab } from '@/widgets/manage-features-tab'

export const FeatureTogglingPage: FC = () => {
  const tabs = [
    {
      title: 'Фичи',
      tabName: 'main',
      component: ManageFeaturesTab,
    },
    {
      title: 'Заявки',
      tabName: 'applications',
      component: ManageFeatureApplicationsTab,
    },
    {
      title: 'Статистика',
      tabName: 'statistics',
      component: FeatureStatisticsTab,
    },
  ] as const satisfies readonly TabContent[]

  return (
    <ServiceTabs
      serviceName={'feature-toggling'}
      defaultTabName={'main'}
      routePath={ROUTES.FEATURE_TOGGLING}
      tabs={tabs}
    />
  )
}
