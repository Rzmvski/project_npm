import React, { type FC } from 'react'

import { ROUTES } from '@/shared/config'
import { ServiceTabs, type TabContent } from '@/shared/ui/ServiceTabs'
import { ClearTransferTask } from '@/widgets/clear-transfer-task-tab'
import { CreateTransferTask } from '@/widgets/create-transfer-task-tab'
import { TransferClients } from '@/widgets/transfer-clients-tab'
import { TransferHistory } from '@/widgets/transfer-history-tab'

export const NodeBalancingPage: FC = () => {
  const nodeBalancingTabs = [
    {
      title: 'Формирование задания',
      tabName: 'forming-task',
      component: CreateTransferTask,
    },
    {
      title: 'Перенос',
      tabName: 'moving',
      component: TransferClients,
    },
    {
      title: 'Очистка',
      tabName: 'clean',
      component: ClearTransferTask,
    },
    {
      title: 'История',
      tabName: 'history',
      component: TransferHistory,
    },
  ] as const satisfies readonly TabContent[]

  return (
    <ServiceTabs
      serviceName={'node-balancing'}
      defaultTabName={'forming-task'}
      routePath={ROUTES.NODE_BALANCING}
      tabs={nodeBalancingTabs}
    />
  )
}
