import React, { type FC } from 'react'

import { FindShardInfo } from '@/features/find-shard-info'

import styles from './ShardInfoPage.module.scss'

/**
 * Форма получения данных о шарде на котором расположена запись клиента
 */
export const ShardInfoPage: FC = () => {
  return (
    <div className={styles.container}>
      <FindShardInfo className={styles.filters} resultClassName={styles.result} />
    </div>
  )
}
