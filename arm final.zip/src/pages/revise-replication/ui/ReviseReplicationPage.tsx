import React, { type FC } from 'react'

import { ROUTES } from '@/shared/config'
import { ServiceTabs, type TabContent } from '@/shared/ui/ServiceTabs'
import { RevisionHistoryTab } from '@/widgets/revision-history-tab'
import { RunRevisionTab } from '@/widgets/run-revision-tab'

export const ReviseReplicationPage: FC = () => {
  const tabs = [
    {
      title: 'Последняя сверка по шарде',
      tabName: 'revise',
      component: RunRevisionTab,
    },
    {
      title: 'История',
      tabName: 'history',
      component: RevisionHistoryTab,
    },
  ] as const satisfies readonly TabContent[]

  return (
    <ServiceTabs
      serviceName={'revise-replication'}
      defaultTabName={'revise'}
      routePath={ROUTES.REVISE_REPLICATION}
      tabs={tabs}
    />
  )
}
