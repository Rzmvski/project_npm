import { TriangleAlert } from 'lucide-react'
import React, { type FC } from 'react'

import { StatusPage } from '@/shared/ui/StatusPage'

interface ErrorPageProps {
  onRetry?: () => void
}

export const ErrorPage: FC<ErrorPageProps> = ({ onRetry }) => {
  const handleRetry = onRetry ?? (() => window.location.reload())

  return (
    <StatusPage
      code={'500'}
      description={
        'Не удалось загрузить страницу. Попробуйте ещё раз — если ошибка повторится, сообщите в поддержку.'
      }
      Icon={TriangleAlert}
      primaryAction={{ label: 'Попробовать снова', onClick: handleRetry }}
      secondaryAction={{ label: 'На главную', to: '/' }}
      title={'Что-то пошло не так'}
    />
  )
}
