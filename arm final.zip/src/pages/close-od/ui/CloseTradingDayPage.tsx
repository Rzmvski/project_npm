import React, { type FC } from 'react'

import { ROUTES } from '@/shared/config'
import { ServiceTabs, type TabContent } from '@/shared/ui/ServiceTabs'
import { CloseOd } from '@/widgets/close-od-tab'
import { OdHistory } from '@/widgets/od-history-tab'

/**
 * Основной контейнер для группы страниц запуска процессов
 */
export const CloseTradingDayPage: FC = () => {
  const closeOdTabs = [
    {
      tabName: 'close-od',
      title: 'Текущие задачи',
      component: CloseOd,
    },
    {
      tabName: 'close-od-history',
      title: 'История запусков',
      component: OdHistory,
    },
  ] as const satisfies readonly TabContent[]

  return (
    <ServiceTabs
      serviceName={'close-od'}
      defaultTabName={'close-od'}
      routePath={ROUTES.CLOSE_TRADING_DAY}
      tabs={closeOdTabs}
    />
  )
}
