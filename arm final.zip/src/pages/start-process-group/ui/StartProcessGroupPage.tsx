import React, { type FC } from 'react'

import { ROUTES } from '@/shared/config'
import { ServiceTabs, type TabContent } from '@/shared/ui/ServiceTabs'
import { ProcessHistory } from '@/widgets/process-history-tab'
import { StartProcessTab } from '@/widgets/start-process-tab'

export const StartProcessGroupPage: FC = () => {
  const startProcessGroupTabs = [
    {
      tabName: 'start-process',
      title: 'Текущие задачи',
      component: StartProcessTab,
    },
    {
      tabName: 'process-group-history',
      title: 'История запусков',
      component: ProcessHistory,
    },
  ] as const satisfies readonly TabContent[]

  return (
    <ServiceTabs
      serviceName={'process-group'}
      defaultTabName={'start-process'}
      routePath={ROUTES.START_PROCESS_GROUP}
      tabs={startProcessGroupTabs}
    />
  )
}
