import { Button, generateId, Input, modal, type ShowOptions } from '@v-uik/base'
import classNames from 'classnames'
import { PlusIcon, SearchIcon } from 'lucide-react'
import React, { type FC, memo, useCallback, useMemo } from 'react'

import { useApplications } from '@/entities/application'
import { useDataCenters } from '@/entities/data-center'
import {
  RestrictionTooltip,
  type TrafficRestriction,
  TrafficRestrictionItem,
  useTrafficRestrictions,
} from '@/entities/traffic-restriction'
import { type MatrixCell, type MatrixRow, useMatrix } from '@/features/build-restriction-matrix'
import { RestrictionFilters, useRestrictionFilters } from '@/features/filter-restrictions'
import { type ManageMode, useRestrictionDelete } from '@/features/manage-traffic-restriction'
import { type CellWrapperProps, useCellWrapper, useConfirm } from '@/shared/lib'
import { Table } from '@/shared/ui/Table'
import { TrafficRestrictionModal } from '@/widgets/traffic-restriction-modal'

import styles from './GeoBalancing.module.scss'

export const GeoBalancingPage: FC = () => {
  const { data: restrictions } = useTrafficRestrictions()
  const { data: allDataCenters, isLoading: isDcsLoading } = useDataCenters()
  const { data: allApplications, isLoading: isAppsLoading } = useApplications()
  const { mutate: mutateDelete } = useRestrictionDelete()
  const confirm = useConfirm()
  const applicationNames = useMemo(
    () => allApplications.map(({ name }) => name),
    [allApplications],
  )

  const { searchQuery, setSearchQuery, result, ...filterProps } = useRestrictionFilters({
    restrictions,
    allDataCenters,
    allApplications: applicationNames,
  })

  const { data, columns } = useMatrix({
    services: allApplications,
    allDataCenters,
    existingRestrictions: restrictions,
  })

  const modalId = useMemo(() => generateId(), [])

  const handleModalClose = useCallback(() => {
    modal.close(modalId)
  }, [modalId])

  const handleDelete = useCallback(
    async (id: string) => {
      const isConfirmed = await confirm({
        title: 'Удалить ограничение',
        text: `Вы действительно хотите снять ограничение ${id}?`,
      })
      if (isConfirmed) {
        mutateDelete(id)
        handleModalClose()
      }
    },
    [confirm, handleModalClose, mutateDelete],
  )

  const openRestrictionModal = useCallback(
    (mode: ManageMode, restriction?: TrafficRestriction) => {
      modal.show(modalId, {
        content: (
          <TrafficRestrictionModal
            mode={mode}
            restriction={restriction}
            dataCenters={allDataCenters}
            services={allApplications}
            onClose={handleModalClose}
            onDelete={handleDelete}
          />
        ),
        width: '70vw',
      } as ShowOptions)
    },
    [allApplications, allDataCenters, handleDelete, handleModalClose, modalId],
  )

  const CellWrapper = useMemo(
    () =>
      memo(({ children, cell }: CellWrapperProps<MatrixRow>) => {
        const value = cell.getValue<MatrixCell | string>()
        if (typeof value === 'string') return children
        const { restrictionIds, available } = value

        if (!restrictionIds.length || !available) return children

        const currentRestrictions = restrictions.filter(({ id }) => {
          if (!id) return false
          return restrictionIds.includes(id)
        })

        return (
          <RestrictionTooltip
            restrictions={currentRestrictions}
            onClick={(restriction) => openRestrictionModal('view', restriction)}
          >
            {children}
          </RestrictionTooltip>
        )
      }),
    [openRestrictionModal, restrictions],
  )

  const cellPlugin = useCellWrapper<MatrixRow>({
    Wrapper: CellWrapper,
    getCellClass: ({ getValue }) => {
      const value = getValue<MatrixCell | string>()
      if (typeof value === 'string') return undefined
      const { restricted, available } = value

      return classNames(styles.matrixCell, {
        [styles.matrixCellNotAvailable]: !available,
        [styles.matrixCellAllowed]: !restricted && available,
        [styles.matrixCellBlocked]: restricted,
      })
    },
  })

  return (
    <div className={styles.container}>
      <div className={styles.section}>
        <div className={styles.toolbar}>
          <Input
            fullWidth
            prefix={<SearchIcon />}
            placeholder={'Поиск ограничений'}
            onChange={(value) => setSearchQuery(value)}
            value={searchQuery}
            className={styles.search}
          />
          <Button
            size={'sm'}
            prefixIcon={<PlusIcon />}
            kind={'outlined'}
            onClick={() => openRestrictionModal('create')}
          >
            {'Создать'}
          </Button>
        </div>
        <div className={styles.filters}>
          <RestrictionFilters {...filterProps} />
        </div>
        <div className={styles.sectionList}>
          {result.length === 0 && (
            <span className={styles.emptyMessage}>{'Ограничения не найдены'}</span>
          )}
          {result.map((restriction) => {
            const { id } = restriction
            return (
              <TrafficRestrictionItem
                key={id}
                restriction={restriction}
                onCardClick={() => openRestrictionModal('view', restriction)}
                onEditClick={() => openRestrictionModal('edit', restriction)}
                onDeleteClick={() => id && handleDelete(id)}
              />
            )
          })}
        </div>
      </div>
      <div className={styles.matrix}>
        <Table<MatrixRow, MatrixCell>
          loading={isDcsLoading || isAppsLoading}
          columns={columns}
          data={data}
          plugins={[cellPlugin]}
        />
      </div>
    </div>
  )
}
