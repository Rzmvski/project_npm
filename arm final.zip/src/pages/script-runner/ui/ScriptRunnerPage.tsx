import React, { type FC } from 'react'

import { ROUTES } from '@/shared/config'
import { ServiceTabs, type TabContent } from '@/shared/ui/ServiceTabs'
import { ManageScriptRequest } from '@/widgets/manage-script-requests-tab'
import { RunScriptTab } from '@/widgets/run-script-tab'

export const ScriptRunnerPage: FC = () => {
  const tabs = [
    {
      title: 'Скрипт',
      tabName: 'main',
      component: RunScriptTab,
    },
    {
      title: 'Заявки',
      tabName: 'requests',
      component: ManageScriptRequest,
    },
  ] as const satisfies readonly TabContent[]

  return (
    <ServiceTabs
      serviceName={'script-runner'}
      defaultTabName={'main'}
      routePath={ROUTES.SCRIPT_RUNNER}
      tabs={tabs}
    />
  )
}
