import React, { type FC } from 'react'

import { ServiceGrid } from '@/widgets/service-grid'

export const DesktopPage: FC = () => {
  return <ServiceGrid />
}
