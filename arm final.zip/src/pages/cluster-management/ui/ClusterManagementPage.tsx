import { NodeManagementTab } from '@/pages/cluster-management/ui/NodeManagementTab'
import { ROUTES } from '@/shared/config'
import { ServiceTabs, type TabContent } from '@/shared/ui/ServiceTabs'
import { SemaphoreManagementTab } from '@/widgets/semaphore-management-tab'

import styles from './ClusterManagementPage.module.scss'

export const ClusterManagementPage = () => {
  const tabs = [
    {
      tabName: 'node-management',
      title: 'Узлы',
      component: NodeManagementTab,
    },
    {
      tabName: 'semaphore-management',
      title: 'Семафоры',
      component: SemaphoreManagementTab,
    },
  ] as const satisfies readonly TabContent[]

  return (
    <div className={styles.clusterManagement}>
      <ServiceTabs
        serviceName={'cluster-management'}
        defaultTabName={'node-management'}
        routePath={ROUTES.CLUSTER_MANAGEMENT}
        tabs={tabs}
      />
    </div>
  )
}
