import { ShieldX } from 'lucide-react'
import React, { type FC } from 'react'

import { StatusPage } from '@/shared/ui/StatusPage'

export const ForbiddenPage: FC = () => {
  return (
    <StatusPage
      code={'403'}
      description={
        'У вашей учётной записи нет прав для просмотра этой страницы. Выберите доступный сервис или вернитесь на главную.'
      }
      Icon={ShieldX}
      primaryAction={{ label: 'На главную', to: '/' }}
      title={'Доступ запрещён'}
    />
  )
}
