import React, { type FC } from 'react'

import { IndexTable } from '@/features/manage-indexes'

import styles from './IndexManagementPage.module.scss'

export const IndexManagementPage: FC = () => {
  return (
    <div className={styles.container}>
      <IndexTable />
    </div>
  )
}
