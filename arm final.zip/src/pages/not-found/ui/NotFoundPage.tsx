import { FileQuestion } from 'lucide-react'
import React, { type FC } from 'react'

import { StatusPage } from '@/shared/ui/StatusPage'

export const NotFoundPage: FC = () => {
  return (
    <StatusPage
      code={'404'}
      description={
        'Такой страницы не существует или она была перемещена. Выберите сервис в меню или вернитесь на главную.'
      }
      Icon={FileQuestion}
      primaryAction={{ label: 'На главную', to: '/' }}
      title={'Страница не найдена'}
    />
  )
}
