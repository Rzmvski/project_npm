import {
  type QueryKey,
  type QueryObserverOptions,
  type QueryOptions,
  useQueries,
  useQueryClient,
} from '@tanstack/react-query'
import { isEqual } from 'lodash-es'
import { useEffect, useMemo } from 'react'

import { createPollingQueryPolicy } from '@/shared/api'


interface UseVisibleRowsPollingOptions<TData> {
  rows: TData[]
  queryKey: QueryKey
  getRowId: (row: TData) => string
  fetchItem: (row: TData) => Promise<TData>
  stopPredicate: (row: TData) => boolean
}

export const useVisibleRowsPolling = <TData>({
  rows,
  queryKey,
  getRowId,
  fetchItem,
  stopPredicate,
}: UseVisibleRowsPollingOptions<TData>) => {
  const queryClient = useQueryClient()

  const pollingRows = useMemo(() => rows.filter((row) => !stopPredicate(row)), [rows])

  const queryResults = useQueries({
    queries: pollingRows.map((row) => ({
      queryKey: [queryKey, getRowId(row)],
      queryFn: () => fetchItem(row),
      ...createPollingQueryPolicy({
        stopPredicate,
      }),
      refetchOnMount: false,
      refetchOnWindowFocus: false,
    })) satisfies (QueryOptions<TData> | QueryObserverOptions<TData>)[],
  })

  useEffect(() => {
    const updatedItems: TData[] = []

    queryResults.forEach((result) => {
      if (result.data) {
        updatedItems.push(result.data)
      }
    })

    if (!updatedItems.length) return

    const updatedMap = new Map(updatedItems.map((item) => [getRowId(item), item]))

    queryClient.setQueryData<TData[]>(queryKey, (old) => {
      return old?.map((item) => {
        const id = getRowId(item)
        const updatedItem = updatedMap.get(id)
        return updatedItem && !isEqual(updatedItem, item) ? updatedItem : item
      })
    })
  }, [queryResults, queryClient])
}
