import {
  type DefinedUseQueryResult,
  hashKey,
  type QueryClient,
  type QueryKey,
  type UseQueryResult,
  type UseQueryOptions,
  useQuery,
  useQueryClient,
} from '@tanstack/react-query'
import { useEffect } from 'react'

const SSE_CONNECTION_KEEP_ALIVE_MS = 1_000

type SharedSseConnection = {
  controller: AbortController
  promise?: Promise<unknown[]>
  subscribers: number
  closeTimer?: ReturnType<typeof setTimeout>
}

const connections = new WeakMap<QueryClient, Map<string, SharedSseConnection>>()

const getConnections = (queryClient: QueryClient) => {
  const current = connections.get(queryClient)
  if (current) return current

  const created = new Map<string, SharedSseConnection>()
  connections.set(queryClient, created)
  return created
}

const getConnection = (queryClient: QueryClient, connectionKey: string) => {
  const clientConnections = getConnections(queryClient)
  const current = clientConnections.get(connectionKey)
  if (current) return current

  const created: SharedSseConnection = {
    controller: new AbortController(),
    subscribers: 0,
  }
  clientConnections.set(connectionKey, created)
  return created
}

const retainConnection = (queryClient: QueryClient, connectionKey: string) => {
  const connection = getConnection(queryClient, connectionKey)
  connection.subscribers += 1
  clearTimeout(connection.closeTimer)
  connection.closeTimer = undefined

  return () => {
    connection.subscribers -= 1
    if (connection.subscribers > 0) return

    connection.closeTimer = setTimeout(() => {
      if (connection.subscribers > 0) return

      connection.controller.abort()
      getConnections(queryClient).delete(connectionKey)
    }, SSE_CONNECTION_KEEP_ALIVE_MS)
  }
}

export interface UseSseQueryOptions<TItem, TData = TItem[]> extends Omit<
  UseQueryOptions<TItem[], Error, TData, QueryKey>,
  'queryFn'
> {
  stream: (signal: AbortSignal) => AsyncIterable<TItem>
  /** Для живого потока новое событие заменяет состояние той же сущности. */
  getItemKey?: (item: TItem) => PropertyKey
}

/**
 * Выполняет SSE-поток как обычный react-query запрос.
 *
 * Конечный Flux сам переводит query в success после последнего события. Пока
 * поток открыт, каждое событие сразу попадает в кэш. Поэтому хук подходит
 * и для конечных списков, и для бесконечного DB-monitoring Sink.
 * Подписчики с одинаковым QueryClient и queryKey используют один поток.
 * Небольшой keep-alive сохраняет его во время переключения роутов.
 */
export function useSseQuery<TItem, TData = TItem[]>(
  options: UseSseQueryOptions<TItem, TData> & {
    initialData: TItem[] | (() => TItem[])
  },
): DefinedUseQueryResult<TData, Error>
export function useSseQuery<TItem, TData = TItem[]>(
  options: UseSseQueryOptions<TItem, TData>,
): UseQueryResult<TData, Error>
export function useSseQuery<TItem, TData = TItem[]>({
  stream,
  getItemKey,
  queryKey,
  ...options
}: UseSseQueryOptions<TItem, TData>): UseQueryResult<TData, Error> {
  const queryClient = useQueryClient()
  const connectionKey = hashKey(queryKey)
  const enabled = options.enabled !== false

  useEffect(() => {
    if (!enabled) return
    return retainConnection(queryClient, connectionKey)
  }, [connectionKey, enabled, queryClient])

  return useQuery<TItem[], Error, TData, QueryKey>({
    ...options,
    queryKey,
    queryFn: () => {
      const connection = getConnection(queryClient, connectionKey)
      if (connection.promise) return connection.promise as Promise<TItem[]>

      const promise = (async () => {
        let items = getItemKey ? (queryClient.getQueryData<TItem[]>(queryKey) ?? []) : []

        for await (const item of stream(connection.controller.signal)) {
          if (connection.controller.signal.aborted) break

          if (getItemKey) {
            const key = getItemKey(item)
            const index = items.findIndex((current) => getItemKey(current) === key)
            items =
              index === -1
                ? [...items, item]
                : items.map((current, currentIndex) =>
                    currentIndex === index ? item : current,
                  )
          } else {
            items = [...items, item]
          }

          queryClient.setQueryData(queryKey, items)
        }

        return items
      })()

      connection.promise = promise
      void promise.then(
        () => {
          if (connection.promise === promise) connection.promise = undefined
        },
        () => {
          if (connection.promise === promise) connection.promise = undefined
        },
      )

      return promise
    },
  })
}
