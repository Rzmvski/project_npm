import { useContext } from 'react'

import { TabContext } from '@/shared/ui/ServiceTabs'

export const useTab = () => {
  const context = useContext(TabContext)
  if (!context) throw Error('useTab must be used inside TabProvider')
  return { ...context }
}
