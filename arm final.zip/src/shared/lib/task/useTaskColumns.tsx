import { type ClientTransferStatusDto } from '@sber-pprb-tkp/tcpf-support-admin-api'
import { type ColumnDef } from '@tanstack/react-table'
import { createUseStyles } from '@v-uik/base'
import React, { useMemo } from 'react'

const useStyles = createUseStyles((thema) => ({
  activeColumn: {
    fontWeight: thema.ref.typography.fontWeight.bold,
    color: 'black',
  },
  inactiveColumn: {
    fontWeight: thema.ref.typography.fontWeight.regular,
    color: thema.sys.color.neutralBeta,
  },
}))

export const useTaskColumns = (
  isAttemptActive: boolean,
): ColumnDef<ClientTransferStatusDto>[] => {
  const { inactiveColumn, activeColumn } = useStyles()
  return useMemo(
    () => [
      {
        header: 'Шарды',
        accessorFn: ({ shard }) => {
          const { id, name } = shard
          return `${id} - ${name}`
        },
      },
      {
        header: 'Кол-во новых заданий по клиентам',
        accessorKey: 'taskAmount',
        cell: ({ getValue }) => {
          const value = getValue<string>()

          return (
            <span className={isAttemptActive ? inactiveColumn : activeColumn}>{value}</span>
          )
        },
      },
      {
        header: 'Количество заданий по докату клиентов',
        accessorKey: 'attemptTaskAmount',
        cell: ({ getValue }) => {
          const value = getValue<string>()

          return (
            <span className={isAttemptActive ? activeColumn : inactiveColumn}>{value}</span>
          )
        },
      },
    ],
    [activeColumn, inactiveColumn, isAttemptActive],
  )
}
