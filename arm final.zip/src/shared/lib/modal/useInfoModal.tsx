import React, { type ReactNode } from 'react'

import { Modal } from '@/shared/ui/Modal'

import { useModal } from './useModal'

type UseInfoModalOptions = {
  title: string
  message: string | ReactNode
}

export const useInfoModal = () => {
  const { open: openModal, close } = useModal()

  const open = ({ title, message }: UseInfoModalOptions) => {
    openModal({
      renderModal: () => (
        <Modal
          isOpen
          title={title}
          onClose={close}
          textAgreeBtn={'Понятно'}
          onClickAgreeBtn={close}
        >
          {message}
        </Modal>
      ),
    })
  }

  return {
    open,
    close,
  }
}
