import { generateId, modal, type ShowOptions } from '@v-uik/base'
import { type Classes } from '@v-uik/modal/dist/esm/classes'
import { type ReactNode } from 'react'

interface UseModalOptions {
  renderModal: () => ReactNode
  width?: string | number
  classes?: Partial<Classes>
}

export const useModal = () => {
  const modalId = generateId()

  const close = () => {
    modal.close(modalId)
  }

  const open = ({ renderModal, width, classes }: UseModalOptions) => {
    modal.show(modalId, {
      classes,
      content: renderModal(),
      width,
    } as ShowOptions)
  }

  return {
    open,
    close,
  }
}
