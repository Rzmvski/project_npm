import { generateId, modal, type ShowOptions } from '@v-uik/base'
import { type ReactNode } from 'react'

import { ConfirmContent } from './ConfirmContent'

interface UseConfirmParams {
  title: string
  text: string
  additionalContent?: ReactNode
  confirmationLabel?: string
  confirmText?: string
}

export const useConfirm =
  () =>
  (params: UseConfirmParams): Promise<boolean> => {
    const id = generateId()

    return new Promise((resolve) => {
      const handleResolve = (result: boolean) => {
        resolve(result)
        modal.close(id)
      }

      modal.show(id, {
        width: 560,
        content: <ConfirmContent {...params} onResolve={handleResolve} />,
      } as ShowOptions)
    })
  }
