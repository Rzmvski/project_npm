import '@tanstack/react-table'

declare module '@tanstack/table-core' {
  interface TableMeta {
    loading?: boolean
    disabled?: boolean
    invalid?: boolean
  }
}
