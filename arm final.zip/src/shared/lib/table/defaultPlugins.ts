import { type RowData } from '@tanstack/react-table'
import { type ColumnSort } from '@tanstack/table-core'

import { useEmptyState } from '@/shared/lib/table/plugins/useEmptyState'
import { useSkeletonLoading } from '@/shared/lib/table/plugins/useSkeletonLoading'
import { useSorting } from '@/shared/lib/table/plugins/useSorting'

import { type TablePlugin } from './types'

export interface DefaultTablePluginsParams {
  noDataText?: string
  defaultSorting?: ColumnSort[]
}

/**
 * The baseline behaviour every `<Table />` ships with out of the box:
 * clickable column sorting, a skeleton overlay while `loading` is true,
 * and a "no data" placeholder when the row set is empty.
 *
 * This is the ONLY place that decides what the default preset is made of —
 * `useTable` itself has no knowledge of these (or any) concrete plugins,
 * it just folds whatever plugin list it is given. Consumers who want a
 * different baseline (or none at all) can ignore this preset entirely and
 * assemble their own plugin list around `useTable`, the same way `<Table />`
 * does here.
 *
 * Adding the same plugin again from a consumer is safe: slot contributions
 * are de-duplicated by key, so e.g. passing `useSorting(defaultSorting)`
 * explicitly refines the default instead of stacking a second indicator on
 * every header.
 */
export function useDefaultTablePlugins<TData extends RowData>({
  noDataText,
  defaultSorting,
}: DefaultTablePluginsParams): TablePlugin<TData>[] {
  return [
    useSorting<TData>(defaultSorting),
    useSkeletonLoading<TData>(),
    useEmptyState<TData>({ noDataText }),
  ]
}
