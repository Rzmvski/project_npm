import {
  type Cell,
  type ColumnDef,
  getCoreRowModel,
  type Header,
  type Row,
  type RowData,
  type TableMeta,
  type TableOptions,
  useReactTable,
} from '@tanstack/react-table'
import { type ColumnSort } from '@tanstack/table-core'
import React, { type ReactNode, useRef } from 'react'

import { useDefaultTablePlugins } from './defaultPlugins'
import { resolveContributions } from './runtime/resolveContributions'
import { useStabilityWarnings } from './runtime/useStabilityWarnings'
import { useTableEffects } from './runtime/useTableEffects'
import {
  type CellProps,
  type HeaderProps,
  type RowProps,
  type TableContribution,
  type TableElementProps,
  type TablePlugin,
  type TableRenderContext,
  type TableView,
} from './types'

interface UseTableParams<TData extends RowData, TValue = unknown> {
  columns: ColumnDef<TData, TValue>[]
  data: TData[]
  plugins?: TablePlugin<TData>[]
  loading?: boolean
  noDataText?: string
  invalid?: boolean
  disabled?: boolean
  defaultSorting?: ColumnSort[]
}

const sizeStyle = (size: number, minSize?: number, maxSize?: number) => ({
  flex: `1 0 ${size}px`,
  width: size,
  minWidth: minSize,
  maxWidth: maxSize,
})

/**
 * The abstract table engine.
 *
 * `useTable` has no opinion about sorting, loading UI, empty states or
 * anything else a table might do — it only knows how to fold a list of
 * plugins into a `TableView` that `<Table />` can render. Every feature lives
 * in a plugin; `useDefaultTablePlugins` is just the specific, swappable list
 * that makes up the ready-made `<Table />` experience.
 *
 * The fold happens in three passes:
 *
 * 1. `setup` — each plugin adjusts the TanStack options, then the instance is
 *    created once.
 * 2. `use` — the rare plugin that needs React hooks against the built instance
 *    contributes here (see the note on plugin-list stability in `TablePlugin`).
 * 3. contributions — everything each plugin declared as data is resolved into
 *    prop decorators, slots and effects.
 */
export const useTable = <TData extends RowData, TValue = unknown>({
  columns,
  data,
  plugins = [],
  noDataText = 'Нет данных',
  loading,
  invalid,
  disabled,
  defaultSorting,
}: UseTableParams<TData, TValue>): TableView<TData> => {
  const scrollRef = useRef<HTMLDivElement | null>(null)
  const defaultPlugins = useDefaultTablePlugins<TData>({ noDataText, defaultSorting })
  const activePlugins: TablePlugin<TData>[] = [...defaultPlugins, ...plugins]

  const meta: TableMeta<TData> = {
    loading,
    invalid,
    disabled,
  }

  const baseOptions: TableOptions<TData> = {
    columns,
    data,
    meta,
    getCoreRowModel: getCoreRowModel(),
  }

  const options = activePlugins.reduce(
    (current, plugin) => (plugin.setup ? plugin.setup(current) : current),
    baseOptions,
  )

  const instance = useReactTable(options)

  // Interleaved so that a plugin's hook-phase contributions apply at the
  // plugin's own position in the list, not after every other plugin's.
  const contributionList = activePlugins.flatMap<TableContribution<TData>>((plugin) => {
    const fromHook = plugin.use?.({ instance, scrollRef })
    return fromHook ? [plugin, fromHook] : [plugin]
  })

  const contributions = resolveContributions(contributionList)
  useStabilityWarnings(activePlugins, contributions)

  const rows = contributions.rows.reduce<Row<TData>[]>(
    (current, narrow) => narrow(current),
    instance.getRowModel().rows,
  )

  const context: TableRenderContext<TData> = { instance, rows, scrollRef }

  useTableEffects(contributions.effects.flatMap((declare) => declare(context)))

  const getRowProps = (row: Row<TData>): RowProps =>
    contributions.rowProps.reduce<RowProps>((current, decorate) => decorate(row, current), {
      role: 'rowgroup',
    })

  const getCellProps = (cell: Cell<TData, unknown>): CellProps =>
    contributions.cellProps.reduce<CellProps>((current, decorate) => decorate(cell, current), {
      role: 'cell',
      style: sizeStyle(
        cell.column.getSize(),
        cell.column.columnDef.minSize,
        cell.column.columnDef.maxSize,
      ),
    })

  const getHeaderProps = (header: Header<TData, unknown>): HeaderProps =>
    contributions.headerProps.reduce<HeaderProps>(
      (current, decorate) => decorate(header, current),
      {
        role: 'cell',
        style: sizeStyle(
          header.column.getSize(),
          header.column.columnDef.minSize,
          header.column.columnDef.maxSize,
        ),
      },
    )

  const renderHeaderContent = (header: Header<TData, unknown>): ReactNode =>
    contributions.headerContent.map((slot) => (
      <React.Fragment key={slot.key}>{slot.render(header)}</React.Fragment>
    ))

  const { rowRenderer, cellRenderer } = contributions

  const renderRow = (row: Row<TData>, children: ReactNode): ReactNode => {
    const rowProps = getRowProps(row)

    if (!rowRenderer) return <div {...rowProps}>{children}</div>

    const { Component, options: rendererOptions } = rowRenderer

    return (
      <Component row={row} rowProps={rowProps} context={context} options={rendererOptions}>
        {children}
      </Component>
    )
  }

  const renderCell = (cell: Cell<TData, unknown>, children: ReactNode): ReactNode => {
    const cellProps = getCellProps(cell)

    if (!cellRenderer) return <div {...cellProps}>{children}</div>

    const { Component, options: rendererOptions } = cellRenderer

    return (
      <Component cell={cell} cellProps={cellProps} context={context} options={rendererOptions}>
        {children}
      </Component>
    )
  }

  // Composed outermost-first: the highest-priority decorator ends up on the
  // outside. Every `Component` here is a module-level constant, so this tree
  // reconciles normally instead of remounting.
  const renderBody = (children: ReactNode): ReactNode =>
    contributions.bodyDecorators.reduceRight<ReactNode>(
      (current, { Component, options: decoratorOptions, key }) => (
        <Component key={key} context={context} options={decoratorOptions}>
          {current}
        </Component>
      ),
      children,
    )

  const renderContainerOverlay = (): ReactNode =>
    contributions.containerOverlays.map((slot) => (
      <React.Fragment key={slot.key}>{slot.render(context)}</React.Fragment>
    ))

  const activeBodyState = contributions.bodyStates.find((slot) => slot.match(context))

  const bodyProps = contributions.bodyProps.reduce<TableElementProps>(
    (current, decorate) => decorate(current),
    {},
  )

  const scrollProps = contributions.scrollProps.reduce<TableElementProps>(
    (current, decorate) => decorate(current),
    {},
  )

  const containerProps = contributions.containerProps.reduce<TableElementProps>(
    (current, decorate) => decorate(current),
    {},
  )

  return {
    instance,
    scrollRef,
    rows,
    getRowProps,
    getCellProps,
    getHeaderProps,
    renderHeaderContent,
    renderRow,
    renderCell,
    renderBody,
    bodyState: activeBodyState ? activeBodyState.render(context) : null,
    renderContainerOverlay,
    bodyProps,
    scrollProps,
    containerProps,
  }
}
