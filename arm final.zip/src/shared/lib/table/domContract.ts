/**
 * The DOM markers `<Table />` guarantees.
 *
 * A plugin that has to measure the rendered table needs to find its parts, and
 * doing that through CSS-module class names would couple the plugin to a
 * stylesheet whose names are hashed at build time. These few stable hooks are
 * the contract instead: `<Table />` promises to emit them, plugins are allowed
 * to query them, and nothing else about the markup is public.
 */

/** Marks the element wrapping the rendered rows (or the active body state). */
export const TABLE_BODY_ATTRIBUTE = 'data-table-body'

export const TABLE_BODY_SELECTOR = `[${TABLE_BODY_ATTRIBUTE}]`

/** Marks detail content that belongs to an expanded parent row. */
export const EXPANDED_ROW_CONTENT_ATTRIBUTE = 'data-expanded-row-content'

export const EXPANDED_ROW_CONTENT_SELECTOR = `[${EXPANDED_ROW_CONTENT_ATTRIBUTE}]`

/** Header rows, scoped to the scroll viewport so nested tables are excluded. */
export const HEADER_ROW_SELECTOR = ':scope > [role="columnheader"] > [role="row"]'
