import {
  type Cell,
  type Header,
  type Row,
  type RowData,
  type Table,
  type TableOptions,
} from '@tanstack/react-table'
import {
  type ComponentType,
  type DetailedHTMLProps,
  type HTMLAttributes,
  type MutableRefObject,
  type PropsWithChildren,
  type ReactElement,
  type ReactNode,
} from 'react'

/**
 * Props applied to one of the table's structural `<div>`s — a row, a body
 * cell or a header cell.
 *
 * Plugins never render these elements themselves: they only describe how the
 * props should look, and `<Table />` renders them. That separation is the
 * whole point of the plugin contract — see `TablePlugin` below.
 */
export type TableElementProps = DetailedHTMLProps<
  HTMLAttributes<HTMLDivElement>,
  HTMLDivElement
> & {
  'data-pinned'?: 'left' | 'right'
  'data-pinned-edge'?: 'left' | 'right'
  'data-horizontal-overflow'?: true
  'data-sortable'?: true
  'data-selected'?: true
  'data-index'?: number
}

export type RowProps = TableElementProps
export type CellProps = TableElementProps
export type HeaderProps = TableElementProps

/**
 * Everything a slot renderer or an effect is allowed to read about the table
 * it belongs to. Deliberately narrow: the raw TanStack instance for state and
 * column access, the row window actually being rendered, and the scroll
 * container.
 */
export interface TableRenderContext<TData extends RowData> {
  /** The raw TanStack table instance. */
  instance: Table<TData>
  /**
   * Rows currently rendered, after any windowing a plugin applied. Use
   * `instance.getRowModel().rows` instead when the question is "does this
   * table have data at all" — a virtualized window can legitimately be empty
   * while the table is full.
   */
  rows: Row<TData>[]
  /** The scrollable viewport holding the header and the body. */
  scrollRef: MutableRefObject<HTMLDivElement | null>
}

interface TableSlotBase {
  /**
   * Identifies the slot. Two contributions with the same key collapse into
   * one — the last registration wins. That is what keeps a plugin that is
   * applied twice (e.g. `useSorting` both as a default and explicitly by a
   * consumer) from rendering its indicator twice.
   */
  key: string
  /** Higher wins where a slot is exclusive. Defaults to 0. */
  priority?: number
}

/** Extra content appended inside a header cell, after its label. */
export interface TableHeaderContentSlot<TData extends RowData> extends TableSlotBase {
  render: (header: Header<TData, unknown>) => ReactNode
}

/**
 * A full replacement for the table body — "no data", "failed to load", and so
 * on. These are mutually exclusive by nature, so the runtime picks the single
 * highest-priority slot whose `match` returns true rather than nesting them.
 */
export interface TableBodyStateSlot<TData extends RowData> extends TableSlotBase {
  match: (context: TableRenderContext<TData>) => boolean
  render: (context: TableRenderContext<TData>) => ReactNode
}

export interface TableBodyDecoratorProps<TData extends RowData> extends PropsWithChildren {
  context: TableRenderContext<TData>
  options: unknown
}

/**
 * Wraps whatever the body currently is (rows or a body state) in extra
 * markup — the skeleton overlay is the canonical example.
 *
 * Unlike the wrapper chain this replaced, `Component` MUST be a stable
 * reference declared at module level. A component created inside a plugin
 * factory gets a new identity on every render, which makes React unmount and
 * remount the entire body instead of updating it. The runtime warns in dev if
 * it catches that happening.
 */
export interface TableBodyDecoratorSlot<TData extends RowData> extends TableSlotBase {
  Component: ComponentType<TableBodyDecoratorProps<TData>>
  options?: unknown
}

export interface TableRowRendererProps<TData extends RowData> extends PropsWithChildren {
  row: Row<TData>
  rowProps: RowProps
  context: TableRenderContext<TData>
  options: unknown
}

/**
 * Replaces the default `<div {...rowProps}>` around a row — used by expandable
 * rows, which need to render a second element underneath the row itself.
 * Exclusive: the highest-priority renderer wins. `Component` must be stable
 * for the same reason as `TableBodyDecoratorSlot['Component']`.
 */
export interface TableRowRendererSlot<TData extends RowData> extends TableSlotBase {
  Component: ComponentType<TableRowRendererProps<TData>>
  options?: unknown
}

export interface TableCellRendererProps<TData extends RowData> extends PropsWithChildren {
  cell: Cell<TData, unknown>
  cellProps: CellProps
  context: TableRenderContext<TData>
  options: unknown
}

/**
 * Replaces the default `<div {...cellProps}>` around a cell — used to wrap
 * cells in a tooltip or a popover. Exclusive: the highest-priority renderer
 * wins. `Component` must be stable, same as the other component slots.
 */
export interface TableCellRendererSlot<TData extends RowData> extends TableSlotBase {
  Component: ComponentType<TableCellRendererProps<TData>>
  options?: unknown
}

/**
 * Props handed to a consumer-supplied cell wrapper by `useCellWrapper`.
 * `children` is the fully rendered cell element, so a wrapper that decides not
 * to decorate can simply return it.
 */
export interface CellWrapperProps<TData extends RowData, TValue = unknown> {
  cell: Cell<TData, TValue>
  cellProps?: TableElementProps
  children: ReactElement
}

/**
 * Extra nodes rendered inside the outer container, stacked over the table —
 * a plugin's own chrome (the pinned-column shadows, for instance) that has to
 * sit outside the scroll viewport to stay put while the table scrolls.
 */
export interface TableOverlaySlot<TData extends RowData> extends TableSlotBase {
  render: (context: TableRenderContext<TData>) => ReactNode
}

/**
 * A side effect owned by a plugin. The runtime runs all of them from a single
 * `useEffect` and diffs `deps` itself, so a plugin can subscribe to the DOM or
 * to table state without calling React hooks — and therefore without making
 * the number of hooks depend on the plugin list.
 */
export interface TableEffect {
  key: string
  deps: readonly unknown[]
  run: () => void | (() => void)
}

/**
 * What a plugin contributes to the rendered table. Every field is data or a
 * pure function of the table — nothing here renders on its own.
 */
export interface TableContribution<TData extends RowData> {
  /** Decorates the props of every row. Receives the props built so far. */
  rowProps?: (row: Row<TData>, base: RowProps) => RowProps
  /** Decorates the props of every body cell. */
  cellProps?: (cell: Cell<TData, unknown>, base: CellProps) => CellProps
  /** Decorates the props of every header cell. */
  headerProps?: (header: Header<TData, unknown>, base: HeaderProps) => HeaderProps
  /** Appends content inside a header cell. */
  headerContent?: TableHeaderContentSlot<TData>
  /** Replaces the body entirely when it matches. */
  bodyState?: TableBodyStateSlot<TData>
  /** Wraps the body in extra markup. */
  bodyDecorator?: TableBodyDecoratorSlot<TData>
  /** Replaces the element rendered around each row. */
  rowRenderer?: TableRowRendererSlot<TData>
  /** Replaces the element rendered around each body cell. */
  cellRenderer?: TableCellRendererSlot<TData>
  /** Narrows or reorders the rows that get rendered (virtualization). */
  rows?: (rows: Row<TData>[]) => Row<TData>[]
  /** Decorates the props of the inner body element. */
  bodyProps?: (base: TableElementProps) => TableElementProps
  /** Decorates the props of the scrollable viewport (`scrollRef`'s element). */
  scrollProps?: (base: TableElementProps) => TableElementProps
  /** Decorates the props of the outermost container element. */
  containerProps?: (base: TableElementProps) => TableElementProps
  /** Renders chrome inside the outer container, over the table. */
  containerOverlay?: TableOverlaySlot<TData>
  /** Declares effects; called during render with the current context. */
  effects?: (context: TableRenderContext<TData>) => TableEffect[]
}

export interface TablePluginHookContext<TData extends RowData> {
  instance: Table<TData>
  scrollRef: MutableRefObject<HTMLDivElement | null>
}

/**
 * A table plugin.
 *
 * `setup` adjusts the TanStack options before the instance is created;
 * everything else describes what the plugin adds to the rendered output. Both
 * halves are plain data, which is what makes plugins combinable: the runtime
 * folds them in order, chaining prop decorators and resolving slot conflicts
 * by priority.
 *
 * `use` is an escape hatch for the rare plugin that must call React hooks
 * against the built table instance (virtualization is the only one today).
 * Because it runs inside a loop over the plugin list, **the set of plugins
 * passed to a single `<Table />` must stay stable across renders** — do not
 * build it conditionally. The runtime warns in dev if it changes.
 */
export interface TablePlugin<TData extends RowData> extends TableContribution<TData> {
  /** Stable identity, used for slot de-duplication and dev diagnostics. */
  id: string
  setup?: (options: TableOptions<TData>) => TableOptions<TData>
  use?: (context: TablePluginHookContext<TData>) => TableContribution<TData> | void
}

/**
 * The rendered view of a table: the TanStack instance plus everything
 * `<Table />` needs in order to draw it. Produced by `useTable`.
 */
export interface TableView<TData extends RowData> {
  instance: Table<TData>
  scrollRef: MutableRefObject<HTMLDivElement | null>
  /** Rows to render, after windowing. */
  rows: Row<TData>[]
  getRowProps: (row: Row<TData>) => RowProps
  getCellProps: (cell: Cell<TData, unknown>) => CellProps
  getHeaderProps: (header: Header<TData, unknown>) => HeaderProps
  /** Extra content for a header cell, already resolved and ordered. */
  renderHeaderContent: (header: Header<TData, unknown>) => ReactNode
  /** Wraps a row's cells in whatever row renderer is active. */
  renderRow: (row: Row<TData>, children: ReactNode) => ReactNode
  /** Wraps a cell's content in whatever cell renderer is active. */
  renderCell: (cell: Cell<TData, unknown>, children: ReactNode) => ReactNode
  /** Wraps the body content in the active decorators. */
  renderBody: (children: ReactNode) => ReactNode
  /** The active body state, or `null` when the rows should be rendered. */
  bodyState: ReactNode | null
  /** Plugin chrome to render inside the outer container, over the table. */
  renderContainerOverlay: () => ReactNode
  bodyProps: TableElementProps
  scrollProps: TableElementProps
  containerProps: TableElementProps
}
