import { renderHook, act } from '@testing-library/react'
import React from 'react'
import { describe, it, expect, vi } from 'vitest'

import { useSelectAll } from '../collections/useSelectAll'

const mockOptions = [
  { value: 1, label: 'Option 1' },
  { value: 2, label: 'Option 2' },
  { value: 3, label: 'Option 3' },
]

vi.mock('@v-uik/base', () => ({
  createUseStyles: () => () => ({
    allOption: 'all-option-mock',
  }),
  defaultComboboxComponents: {
    OptionItem: 'div',
  },
}))

vi.mock('@/shared/ui/Checkbox', () => ({
  Checkbox: ({ checked, indeterminate }: { checked?: boolean; indeterminate?: boolean }) => (
    <input
      type='checkbox'
      defaultChecked={checked}
      aria-checked={indeterminate ? 'mixed' : checked}
    />
  ),
}))

describe('useSelectAll', () => {
  it('should prepend selectAll option to options list', () => {
    const { result } = renderHook(() =>
      useSelectAll({
        options: mockOptions,
        selectedValues: [],
        onChange: vi.fn(),
      }),
    )

    expect(result.current.optionsWithSelectAll).toHaveLength(4)
    expect(result.current.optionsWithSelectAll[0]).toEqual({
      value: '__select_all__',
      label: 'Все',
    })
  })

  it('should detect that all values are selected', () => {
    const { result } = renderHook(() =>
      useSelectAll({
        options: mockOptions,
        selectedValues: [1, 2, 3],
        onChange: vi.fn(),
      }),
    )

    expect(result.current.selectedOptions).toHaveLength(3)
    expect(result.current.selectedOptions.map((o) => o.value)).toEqual([1, 2, 3])
  })

  it('should detect that none values are selected', () => {
    const { result } = renderHook(() =>
      useSelectAll({
        options: mockOptions,
        selectedValues: [],
        onChange: vi.fn(),
      }),
    )

    expect(result.current.selectedOptions).toHaveLength(0)
  })

  it('should detect isAllSelected when all values match', () => {
    const { result } = renderHook(() =>
      useSelectAll({
        options: mockOptions,
        selectedValues: [],
        onChange: vi.fn(),
      }),
    )
    expect(result.current.optionsWithSelectAll).toHaveLength(4)
  })

  it('should trigger toggleSelectAll when change contains selectAll value', () => {
    const onChange = vi.fn()
    const { result } = renderHook(() =>
      useSelectAll({
        options: mockOptions,
        selectedValues: [1, 2, 3],
        onChange,
      }),
    )

    const fakeEvent = {} as React.ChangeEvent<unknown>
    const fakeFullValue = [{ value: '__select_all__', label: 'Все' }, ...mockOptions] as any[]

    act(() => {
      result.current.handleChange([1, 2, 3], fakeEvent, fakeFullValue)
    })

    // All selected -> toggleSelectAll calls deselectAll -> onChange([])
    expect(onChange).toHaveBeenCalledWith([])
  })

  it('should handle normal change without selectAll', () => {
    const onChange = vi.fn()
    const { result } = renderHook(() =>
      useSelectAll({
        options: mockOptions,
        selectedValues: [1],
        onChange,
      }),
    )

    const fakeEvent = {} as React.ChangeEvent<unknown>

    act(() => {
      result.current.handleChange([1], fakeEvent)
    })

    expect(onChange).toHaveBeenCalledWith([1])
  })
})
