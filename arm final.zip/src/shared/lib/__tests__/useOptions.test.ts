import { renderHook } from '@testing-library/react'
import React from 'react'
import { describe, it, expect } from 'vitest'

import { useOptions } from '../collections/useOptions'

describe('useOptions', () => {
  it('should convert string values to options with default label', () => {
    const { result } = renderHook(() => useOptions({ values: ['a', 'b', 'c'] }))

    expect(result.current).toEqual([
      { value: 'a', label: 'a', prefix: undefined, suffix: undefined },
      { value: 'b', label: 'b', prefix: undefined, suffix: undefined },
      { value: 'c', label: 'c', prefix: undefined, suffix: undefined },
    ])
  })

  it('should use custom getLabel function', () => {
    const { result } = renderHook(() =>
      useOptions({
        values: [
          { id: 1, name: 'First' },
          { id: 2, name: 'Second' },
        ],
        getLabel: (value) => value.name,
      }),
    )

    expect(result.current).toEqual([
      {
        value: { id: 1, name: 'First' },
        label: 'First',
        prefix: undefined,
        suffix: undefined,
      },
      {
        value: { id: 2, name: 'Second' },
        label: 'Second',
        prefix: undefined,
        suffix: undefined,
      },
    ])
  })

  it('should use getPrefix and getSuffix', () => {
    const { result } = renderHook(() =>
      useOptions({
        values: ['a', 'b'],
        getPrefix: (v) => React.createElement('span', null, `pre-${v}`),
        getSuffix: (v) => React.createElement('span', null, `suf-${v}`),
      }),
    )

    expect(result.current).toHaveLength(2)
    expect(result.current[0].value).toBe('a')
    expect(result.current[0].label).toBe('a')
    expect(result.current[1].value).toBe('b')
    expect(result.current[1].label).toBe('b')
  })

  it('should memoize result and not recompute when same values with stable label', () => {
    const values = [1, 2, 3]
    const getLabel = (v: number) => String(v)
    const { result, rerender } = renderHook(() => useOptions({ values, getLabel }))

    const firstRender = result.current

    rerender()

    expect(result.current).toBe(firstRender)
  })

  it('should recompute when values change', () => {
    const { result, rerender } = renderHook(({ values }) => useOptions({ values }), {
      initialProps: { values: [1, 2] },
    })

    const firstRender = result.current

    rerender({ values: [1, 2, 3] })

    expect(result.current).not.toBe(firstRender)
    expect(result.current).toHaveLength(3)
  })
})
