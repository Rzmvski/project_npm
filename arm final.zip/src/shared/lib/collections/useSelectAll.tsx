import { createUseStyles, defaultComboboxComponents } from '@v-uik/base'
import { type ComboBoxComponentsConfig } from '@v-uik/combo-box/dist/esm/components'
import {
  type defaultOptionItemElement,
  type defaultOptionListElement,
} from '@v-uik/combo-box/dist/esm/config'
import React, { useCallback, useMemo } from 'react'

import { type Option } from '@/shared/model'
import { Checkbox } from '@/shared/ui/Checkbox'


const SELECT_ALL_VALUE = '__select_all__'

const { OptionItem } = defaultComboboxComponents

type DefaultComponentsConfig<
  T,
  ListElement extends React.ElementType = typeof defaultOptionListElement,
  OptionItemElement extends React.ElementType = typeof defaultOptionItemElement,
> = ComboBoxComponentsConfig<Option<T>, ListElement, OptionItemElement>

interface SelectAllOption extends Option<unknown> {
  value: typeof SELECT_ALL_VALUE
}

type ExtendedOption<T> = Option<T> | SelectAllOption

const useStyles = createUseStyles((theme) => ({
  allOption: {
    borderBottom: `1px solid ${theme.comp.dropdownMenu.colorBorder}`,
  },
}))

interface UseSelectAllProps<T> {
  options: Option<T>[]
  selectedValues: T[]
  onChange: (values: T[]) => void
  selectAllLabel?: string
}

export function useSelectAll<T>({
  options,
  selectedValues,
  onChange,
  selectAllLabel = 'Все',
}: UseSelectAllProps<T>) {
  const allValues = useMemo(() => options.map(({ value }) => value), [options])
  const classes = useStyles()

  const selectAllOption: SelectAllOption = {
    value: SELECT_ALL_VALUE,
    label: selectAllLabel,
  }

  const isAllSelected = useMemo(() => {
    if (!selectedValues.length) return false
    return allValues.every((val) => selectedValues.includes(val))
  }, [selectedValues, allValues])

  const isSomeSelected = useMemo(() => {
    if (!selectedValues.length) return false
    return selectedValues.some((val) => allValues.includes(val))
  }, [selectedValues, allValues])

  const selectAll = () => {
    onChange([...allValues])
  }

  const deselectAll = () => {
    onChange([])
  }

  const toggleSelectAll = useCallback(() => {
    if (isAllSelected) {
      deselectAll()
    } else {
      selectAll()
    }
  }, [isAllSelected, deselectAll, selectAll])

  const handleChange = useCallback(
    (value: T[], _event?: React.ChangeEvent<unknown>, fullValue?: ExtendedOption<T>[]) => {
      if (fullValue?.some(({ value }) => value == SELECT_ALL_VALUE)) {
        return toggleSelectAll()
      }

      return onChange(value)
    },
    [onChange, toggleSelectAll],
  )

  const optionsWithSelectAll = useMemo<ExtendedOption<T>[]>(() => {
    return [selectAllOption, ...options]
  }, [options, selectAllOption])

  const selectedOptions = useMemo(() => {
    return options.filter(({ value }) => selectedValues.includes(value))
  }, [selectedValues, options, allValues, selectAllLabel])

  const components: DefaultComponentsConfig<T> = {
    OptionItem: (props) => {
      const { isInfoOption } = props
      if (isInfoOption) {
        return <OptionItem {...props} />
      }

      const { option, getOptionValue } = props
      const optionValue = getOptionValue(option)

      if (optionValue !== SELECT_ALL_VALUE) {
        return <OptionItem {...props} />
      }

      return (
        <OptionItem
          {...props}
          isOptionSelected={() => isAllSelected}
          className={classes.allOption}
          renderOptionPrefix={() => {
            return (
              <Checkbox
                checked={isAllSelected}
                indeterminate={isSomeSelected && !isAllSelected}
              />
            )
          }}
        />
      )
    },
  }

  return {
    optionsWithSelectAll,
    selectedOptions,
    handleChange,
    components,
  }
}
