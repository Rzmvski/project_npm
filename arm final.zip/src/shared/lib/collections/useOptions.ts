import { type ReactNode, useMemo } from 'react'

import { type Option } from '@/shared/model'

type ValueFunction<T, V = string> = (value: T) => V

interface UseOptionsParams<T> {
  values: T[]
  getLabel?: ValueFunction<T>
  getPrefix?: ValueFunction<T, ReactNode>
  getSuffix?: ValueFunction<T, ReactNode>
}

export function useOptions<T>({
  values,
  getLabel = (value) => String(value),
  getPrefix,
  getSuffix,
}: UseOptionsParams<T>): Option<T>[] {
  return useMemo(
    () =>
      values.map((value) => ({
        value,
        label: getLabel(value),
        prefix: getPrefix?.(value),
        suffix: getSuffix?.(value),
      })),
    [getLabel, getPrefix, getSuffix, values],
  )
}
