interface MatcherOptions<T extends object> {
  deep: boolean
  caseSensitive: boolean
  fields?: Array<keyof T>
}

export const createObjectMatcher = <T extends object>({
  caseSensitive,
  deep,
  fields,
}: MatcherOptions<T>) => {
  return (obj: T, query: string): boolean => {
    if (!query.trim()) return true

    const normalizedQuery = caseSensitive ? query : query.toLowerCase()

    const values = fields ? fields.map((field) => obj[field]) : Object.values(obj)

    return values.some((value) => {
      return matchValue(value, normalizedQuery, deep, caseSensitive)
    })
  }
}

function matchValue(
  value: unknown,
  query: string,
  deep: boolean,
  caseSensitive: boolean,
): boolean {
  if (value === null) return false

  if (typeof value === 'string' || typeof value === 'number') {
    const stringValue = value.toString()
    return caseSensitive
      ? stringValue.includes(query)
      : stringValue.toLowerCase().includes(query)
  }

  if (deep && typeof value == 'object') {
    return Object.values(value).some((v) => {
      return matchValue(v, query, deep, caseSensitive)
    })
  }

  return false
}
