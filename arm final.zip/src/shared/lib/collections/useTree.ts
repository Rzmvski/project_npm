import { type TreeItem } from '@v-uik/base'
import { useMemo } from 'react'

export interface TreeNode<T> extends TreeItem {
  payload?: T
  children?: TreeNode<T>[]
}

interface UseTreeParams<T> {
  targetArray: T[]
  nodeCreator: (target: T) => TreeNode<T>
  keySelector: (target: T) => string
  idSelector: (target: T) => string
}

interface TreeBuilderGroup<T> {
  key: string
  label: string
  children: TreeBuilderMap<T>
}

type TreeBuilderMap<T> = { [key: string]: TreeBuilderGroup<T> | TreeNode<T> }

export const useTree = <T>({
  targetArray,
  nodeCreator,
  keySelector,
  idSelector,
}: UseTreeParams<T>): TreeNode<T>[] => {
  return useMemo(() => {
    const tree: TreeBuilderMap<T> = {}

    targetArray.forEach((target) => {
      const keys = keySelector(target).split('/')
      let current = tree

      keys.forEach((part, index) => {
        if (!current[part]) {
          current[part] = {
            key: keys.slice(0, index + 1).join('/'),
            label: part,
            children: {},
          }
        }
        current = (current[part] as TreeBuilderGroup<T>).children
      })

      const id = idSelector(target)

      current[id] = nodeCreator(target)
    })

    return convertToArray(tree)
  }, [targetArray])
}

const convertToArray = <T>(obj: TreeBuilderMap<T>): TreeNode<T>[] => {
  return Object.values(obj).map((item) => {
    const children = (item as TreeBuilderGroup<T>).children

    return {
      ...item,
      children:
        children && Object.keys(children).length > 0
          ? convertToArray(children)
          : undefined,
    }
  })
}
