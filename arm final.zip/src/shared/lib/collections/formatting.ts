/**
 * Функция преобразования из массива в объект с ключем
 * module:standIn/actions
 * @function
 * @returns {Promise}
 */
export const convertArrayToObject = <T extends Record<K, PropertyKey>, K extends keyof T>(
  array: T[],
  key: K,
): Record<T[K], T> => {
  return array.reduce(
    (acc, curr) => {
      acc[curr[key]] = curr
      return acc
    },
    {} as Record<T[K], T>,
  )
}
