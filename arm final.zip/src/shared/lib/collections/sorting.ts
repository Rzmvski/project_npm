/**
 * Стандартная быстрая сортировка
 */
export const standardSorting = <T>(a: T, b: T): number => (a > b ? 1 : -1)
