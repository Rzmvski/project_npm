import { useDeferredValue, useMemo, useState } from 'react'

interface UseSearchParams<TData> {
  items: TData[]
  searchFn: (items: TData[], query: string) => TData[]
}

export const useSearch = <TData extends object>({
  items,
  searchFn,
}: UseSearchParams<TData>) => {
  const [searchQuery, setSearchQuery] = useState('')
  const deferredQuery = useDeferredValue(searchQuery)

  const isSearching = searchQuery !== deferredQuery

  const result = useMemo(() => {
    const query = deferredQuery.toLowerCase()
    if (!query.trim()) return items
    return searchFn(items, query)
  }, [deferredQuery, items, searchFn])

  return {
    result,
    searchQuery,
    setSearchQuery,
    isSearching,
  }
}
