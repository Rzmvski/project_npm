const LOGIN_STORAGE_KEY = 'tcpf_login'

export const sessionUserLogin = {
  get: () => localStorage.getItem(LOGIN_STORAGE_KEY),
  set: (login: string) => localStorage.setItem(LOGIN_STORAGE_KEY, login),
  remove: () => localStorage.removeItem(LOGIN_STORAGE_KEY),
}
