import { useEffect } from 'react'

interface UseBeforeUnloadParams {
  isPending: boolean
}

export const useBeforeUnload = ({ isPending }: UseBeforeUnloadParams) => {
  useEffect(() => {
    if (!isPending) return

    const handler = (event: BeforeUnloadEvent) => {
      event.preventDefault()
      event.returnValue = ''
    }

    window.addEventListener('beforeunload', handler)

    return () => {
      window.removeEventListener('beforeunload', handler)
    }
  }, [isPending])
}
