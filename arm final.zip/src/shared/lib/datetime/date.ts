// eslint-disable-next-line import/no-duplicates
import { format, formatDistance } from 'date-fns'
// eslint-disable-next-line import/no-duplicates
import { ru } from 'date-fns/locale'

const DEFAULT_OPTIONS = {
  locale: ru,
}

export const TODAY = new Date()

export const humanize = (startTime?: Nullable<Date>, endTime?: Nullable<Date>) => {
  if (!startTime || !endTime) return null
  return formatDistance(startTime, endTime, { ...DEFAULT_OPTIONS })
}

export const formatDate = (date: Nullable<Date> | undefined, formatString = 'dd.MM.yyyy') => {
  if (!date) return null
  return format(date, formatString, { ...DEFAULT_OPTIONS })
}
