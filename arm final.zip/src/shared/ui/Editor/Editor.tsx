import classNames from 'classnames'
import React, { useEffect } from 'react'
// react-ace must be imported before the ace-builds extensions below: it sets
// up the global `ace` object those side-effect imports rely on.
import ReactAceModule, { type IAceEditorProps } from 'react-ace'
import 'ace-builds/src-noconflict/ext-language_tools'
import 'ace-builds/src-noconflict/theme-tomorrow'

import styles from './Editor.module.scss'

const AceEditor =
  (
    ReactAceModule as typeof ReactAceModule & {
      default?: typeof ReactAceModule
    }
  ).default ?? ReactAceModule

interface EditorProps extends IAceEditorProps {
  value: string
  onChange: (value: string) => void
  onError?: () => void
  placeholder?: string
  invalid?: boolean
  disabled?: boolean
  resizable?: boolean
}

export const Editor = ({
  value,
  onChange,
  placeholder,
  invalid,
  onError,
  className,
  readOnly,
  disabled,
  resizable,
  style,
  ...props
}: EditorProps) => {
  useEffect(() => {
    if (invalid) onError?.()
  }, [invalid, onError])

  return (
    <AceEditor
      style={{
        resize: resizable ? 'vertical' : 'none',
        height: '100%',
        ...style,
      }}
      className={classNames(styles.editor, className, {
        [styles.editorInvalid]: invalid,
        [styles.editorDisabled]: disabled,
      })}
      theme={'tomorrow'}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      setOptions={{
        useWorker: false,
        enableBasicAutocompletion: true,
        enableLiveAutocompletion: true,
        enableSnippets: false,
        showPrintMargin: false,
        wrap: true,
        highlightActiveLine: false,
        highlightGutterLine: false,
        readOnly: readOnly || disabled,
        ...props.setOptions,
      }}
      {...props}
    />
  )
}
