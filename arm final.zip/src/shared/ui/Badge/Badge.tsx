import classNames from 'classnames'
import React, { type FC } from 'react'

import { Tooltip } from '@/shared/ui/Tooltip'

import styles from './Badge.module.scss'

export type BadgeColor = 'gray' | 'green' | 'yellow' | 'red' | 'blue' | 'transparent'

export type BadgeConfig = {
  color: BadgeColor
  text: string
  icon?: React.JSX.Element
}

interface BadgeProps {
  color: BadgeColor
  text: string
  icon?: React.JSX.Element
  className?: string
  tooltip?: string
  tooltipPortal?: boolean
  tooltipPlacement?: 'top' | 'bottom'
}

export const Badge: FC<BadgeProps> = ({
  color,
  text,
  icon,
  className,
  tooltip,
  tooltipPortal = false,
  tooltipPlacement,
}) => {
  return (
    <Tooltip
      dropdownProps={{
        content: tooltip,
        placement: tooltipPlacement,
        ...(tooltipPortal
          ? {
              disablePortal: false,
              container: () => (typeof document === 'undefined' ? null : document.body),
            }
          : {}),
      }}
    >
      <span role={'status'} className={classNames(styles.badge, styles[color], className)}>
        {icon}
        <span>{text}</span>
      </span>
    </Tooltip>
  )
}
