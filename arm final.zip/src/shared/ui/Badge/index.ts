export { Badge, type BadgeConfig, type BadgeColor } from './Badge'
