import { useNavigate, useParams } from '@tanstack/react-router'
import { Tab, Tabs, useStorage } from '@v-uik/base'
import React, { type ReactNode, useEffect, useMemo, useState, type ComponentType } from 'react'

import styles from './ServiceTabs.module.scss'
import { TabContext, type TabName } from './TabContext'

type TabNames<TTabs extends readonly TabContent[]> = TTabs[number]['tabName']

interface ServiceTabsProps<TTabs extends readonly TabContent[]> {
  serviceName: string
  defaultTabName: TabNames<TTabs>
  activeTabName?: TabNames<TTabs>
  routePath?: string
  tabs: TTabs
  onChange?: (tab: TabNames<TTabs>) => void
}

export interface TabContent<TName extends TabName = TabName> {
  tabName: TName
  title: ReactNode
  component: ComponentType
  tabProps?: object
  className?: string
}

export function ServiceTabs<TTabs extends readonly TabContent[]>({
  routePath,
  ...props
}: ServiceTabsProps<TTabs>) {
  if (routePath) {
    return <RoutedServiceTabs {...props} routePath={routePath} />
  }

  return <ServiceTabsContent {...props} />
}

type RoutedServiceTabsProps<TTabs extends readonly TabContent[]> = Omit<
  ServiceTabsProps<TTabs>,
  'routePath'
> & { routePath: string }

function RoutedServiceTabs<TTabs extends readonly TabContent[]>({
  routePath,
  tabs,
  defaultTabName,
  onChange,
  ...props
}: RoutedServiceTabsProps<TTabs>) {
  const { tab } = useParams({ strict: false })
  const navigate = useNavigate()
  const activeTab = tabs.find(({ tabName }) => tabName === tab)?.tabName ?? defaultTabName
  const routePattern = `${routePath}/{-$tab}`

  useEffect(() => {
    if (tab === activeTab) return

    void navigate({
      to: routePattern,
      params: { tab: activeTab },
      replace: true,
    } as never)
  }, [activeTab, navigate, routePattern, tab])

  return (
    <ServiceTabsContent
      {...props}
      tabs={tabs}
      defaultTabName={defaultTabName}
      activeTabName={activeTab}
      onChange={(nextTab) => {
        void navigate({
          to: routePattern,
          params: { tab: nextTab },
        } as never)
        onChange?.(nextTab)
      }}
    />
  )
}

function ServiceTabsContent<TTabs extends readonly TabContent[]>({
  serviceName,
  defaultTabName,
  activeTabName,
  tabs,
  onChange,
}: Omit<ServiceTabsProps<TTabs>, 'routePath'>) {
  const [storedActiveTab, setStoredActiveTab] = useStorage(
    'session',
    serviceName,
    defaultTabName,
  )
  const activeTab = activeTabName ?? storedActiveTab
  const [mountedTabs, setMountedTabs] = useState<Set<string>>(
    () => new Set([defaultTabName, activeTab]),
  )

  useEffect(() => {
    setMountedTabs((current) => {
      if (current.has(activeTab)) return current
      return new Set(current).add(activeTab)
    })
  }, [activeTab])

  const handleChange = (tab: string) => {
    setMountedTabs((current) => {
      if (current.has(tab)) return current
      return new Set(current).add(tab)
    })
    setStoredActiveTab(tab)
    onChange?.(tab)
  }

  const contextValue = useMemo(() => ({ activeTab }), [activeTab])

  return (
    <Tabs
      keepMounted
      value={activeTab}
      onChange={(value) => handleChange(value as string)}
      classes={{ root: styles.container, content: styles.content }}
    >
      {tabs.map((config) => {
        const { tabName, component, title } = config
        const Content = component
        return (
          <Tab key={tabName} header={title} value={tabName}>
            <TabContext.Provider value={contextValue}>
              {mountedTabs.has(tabName) ? <Content /> : null}
            </TabContext.Provider>
          </Tab>
        )
      })}
    </Tabs>
  )
}
