import { Tooltip as UIKitTooltip } from '@v-uik/base'
import React, { type ComponentProps } from 'react'

export type TooltipProps = ComponentProps<typeof UIKitTooltip>

const getPortalContainer = () => (typeof document === 'undefined' ? null : document.body)

/**
 * Application-wide tooltip defaults.
 *
 * Tooltips must not live inside scroll, sticky or virtualized containers:
 * those containers create clipping and positioning contexts of their own.
 * Rendering the popup in `document.body` keeps one coordinate system for
 * tables, dropdowns, modals and regular content alike.
 */
export const Tooltip = ({
  dropdownProps,
  pointAtCenter = true,
  single = false,
  hideOnScroll = true,
  ...props
}: TooltipProps) => {
  const {
    disablePortal = false,
    container = getPortalContainer,
    ...restDropdownProps
  } = dropdownProps ?? {}

  return (
    <UIKitTooltip
      {...props}
      pointAtCenter={pointAtCenter}
      single={single}
      hideOnScroll={hideOnScroll}
      dropdownProps={{
        ...restDropdownProps,
        disablePortal,
        container,
      }}
    />
  )
}
