import { type LucideIcon, Plug, Slash } from 'lucide-react'

export const PlugOffIcon: LucideIcon = (props) => (
  <Plug {...props}>
    <Slash />
  </Plug>
)
