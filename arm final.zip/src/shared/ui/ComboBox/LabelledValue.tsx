import { type SingleValueProps } from '@v-uik/combo-box/dist/esm/components/SingleValue'
import React from 'react'

import { type Option } from '@/shared/model'

import styles from './LabelledValue.module.scss'

interface LabelledValueProps<T> extends SingleValueProps<Option<T>> {
  label: string
}

export function LabelledValue<T>({
  selectedValue,
  label,
}: LabelledValueProps<T>) {
  const [option] = selectedValue
  const { label: optionLabel } = option
  return (
    <div className={styles.labelled}>
      <span className={styles.label}>{`${label}:`}</span>
      <span>{optionLabel}</span>
    </div>
  )
}
