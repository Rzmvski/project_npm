import classNames from 'classnames'
import React, { type ComponentType } from 'react'

import { type StatusTone } from '@/shared/model'
import { Tooltip } from '@/shared/ui/Tooltip'

import styles from './StatusBadge.module.scss'

export type StatusBadgeVariant = 'icon' | 'labeled' | 'compact-labeled'

interface StatusIndicatorProps {
  title: string
  label: string
  Icon: ComponentType
  tone?: StatusTone
  animated?: boolean
  /**
   * `icon` — компактная иконка с подсказкой по ховеру (по умолчанию).
   * `labeled` — иконка и подпись всегда видны, без скрытия за тултипом.
   * `compact-labeled` — уменьшенная и менее акцентная версия с подписью.
   */
  variant?: StatusBadgeVariant
  tooltipPortal?: boolean
  tooltipPlacement?: 'top' | 'bottom'
}

export const StatusBadge = ({
  title,
  label,
  Icon,
  tone = 'neutral',
  animated = false,
  variant = 'icon',
  tooltipPortal = false,
  tooltipPlacement,
}: StatusIndicatorProps) => {
  if (variant === 'labeled' || variant === 'compact-labeled') {
    const labeledToneClass = {
      neutral: styles.labeledNeutral,
      success: styles.labeledSuccess,
      warning: styles.labeledWarning,
      danger: styles.labeledDanger,
    }[tone]

    return (
      <span
        className={classNames(styles.statusBadgeLabeled, labeledToneClass, {
          [styles.animated]: animated,
          [styles.compactLabeled]: variant === 'compact-labeled',
        })}
        title={`${title} ${label}`}
      >
        <Icon />
        <span className={styles.labelText}>{label}</span>
      </span>
    )
  }

  return (
    <Tooltip
      pointAtCenter
      dropdownProps={{
        content: `${title} ${label}`,
        placement: tooltipPlacement,
        ...(tooltipPortal
          ? {
              disablePortal: false,
              container: () => (typeof document === 'undefined' ? null : document.body),
            }
          : {}),
      }}
    >
      <div
        className={classNames(styles.statusBadge, styles[tone], {
          [styles.animated]: animated,
        })}
      >
        <Icon />
      </div>
    </Tooltip>
  )
}
