import React, { type ComponentType, type FC } from 'react'

import { type RoutePath } from '@/shared/config'
import { Button } from '@/shared/ui/Button'

import styles from './StatusPage.module.scss'

interface StatusPageAction {
  label: string
  onClick?: () => void
  to?: RoutePath | '/'
}

interface StatusPageProps {
  code: string
  description: string
  Icon: ComponentType
  primaryAction: StatusPageAction
  secondaryAction?: StatusPageAction
  title: string
}

const StatusAction: FC<StatusPageAction & { secondary?: boolean }> = ({
  label,
  onClick,
  secondary,
  to,
}) => {
  const className = secondary ? styles.secondaryAction : styles.primaryAction

  if (to) {
    return (
      <a className={className} href={`#${to}`}>
        {label}
      </a>
    )
  }

  return (
    <Button className={className} type={'button'} onClick={onClick}>
      {label}
    </Button>
  )
}

export const StatusPage: FC<StatusPageProps> = ({
  code,
  description,
  Icon,
  primaryAction,
  secondaryAction,
  title,
}) => {
  return (
    <section className={styles.container} aria-labelledby={'status-page-title'}>
      <div className={styles.decor} aria-hidden={'true'}>
        {code}
      </div>

      <div className={styles.content}>
        <div className={styles.icon} aria-hidden={'true'}>
          <Icon />
        </div>

        <span className={styles.code}>Ошибка {code}</span>
        <h1 id={'status-page-title'}>{title}</h1>
        <p>{description}</p>

        <div className={styles.actions}>
          <StatusAction {...primaryAction} />
          {secondaryAction && <StatusAction {...secondaryAction} secondary />}
        </div>
      </div>
    </section>
  )
}
