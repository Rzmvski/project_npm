import { Button as PlatformButton } from '@v-uik/base'
import { type ButtonProps } from '@v-uik/button/dist/esm/Button'
import classNames from 'classnames'
import React, { type FC } from 'react'

import styles from './Button.module.scss'

export const Button: FC<ButtonProps> = ({ className, ...props }) => {
  return (
    <PlatformButton
      className={classNames(className, styles.button)}
      {...props}
    />
  )
}
