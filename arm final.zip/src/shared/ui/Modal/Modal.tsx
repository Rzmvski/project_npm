import {
  Modal as PlatformModal,
  ModalBody,
  ModalFooter,
  ModalHeader,
} from '@v-uik/base'
import classNames from 'classnames'
import React, { type FC, type PropsWithChildren } from 'react'

import { Button } from '@/shared/ui/Button'

import styles from './Modal.module.scss'


interface ModalProps extends PropsWithChildren {
  // id для тестов
  id?: string
  title: string
  className?: string
  isOpen?: boolean
  content?: JSX.Element | string
  footer?: JSX.Element
  onClose?: () => void
  // ширина окна
  // width?: string | number,
  formId?: string
  // текст для кнопки положительного ответа
  textAgreeBtn?: string
  // текст для кнопки отрицательного ответа
  textCancelBtn?: string
  // обработчик клика кнопки положительного ответа
  onClickAgreeBtn?: () => void
  // флаг, отключающий кнопку положительного ответа
  isAgreeBtnDisabled?: boolean
  // обработчик клика кнопки отрицательного ответа
  onClickCancelBtn?: () => void
  // флаг переводящий модалку в режим отображения ошибки
  isError?: boolean
}

export const Modal: FC<ModalProps> = ({
  title,
  content,
  children,
  formId,
  isOpen,
  onClose,
  footer,
  textAgreeBtn = 'Подтвердить',
  textCancelBtn = 'Отмена',
  onClickAgreeBtn,
  onClickCancelBtn,
  className,
  isAgreeBtnDisabled,
}) => {
  return (
    <PlatformModal
      width={'auto'}
      classes={{ modalContent: className }}
      className={classNames(styles.modal, className)}
      open={isOpen}
      onClose={onClose}
    >
      <ModalHeader className={styles.modalHeader}>
        <h3>{title}</h3>
      </ModalHeader>
      <ModalBody className={styles.modalContent}>
        {content ?? children}
      </ModalBody>
      <ModalFooter className={styles.modalFooter}>
        {!!footer && footer}
        {!!onClickAgreeBtn && (
          <Button
            color={'primary'}
            type={'submit'}
            form={formId}
            onClick={onClickAgreeBtn}
            // className={styles.submitButton}
            disabled={isAgreeBtnDisabled}
          >
            {textAgreeBtn}
          </Button>
        )}
        {!!onClickCancelBtn && (
          <Button
            color={'secondary'}
            onClick={onClickCancelBtn}
            // className={styles.cancelButton}
          >
            {textCancelBtn}
          </Button>
        )}
      </ModalFooter>
    </PlatformModal>
  )
}
