import { Labelled, type LabelledProps } from '@v-uik/base'
import classNames from 'classnames'
import React, { type FC } from 'react'
import { type FieldError } from 'react-hook-form'

import styles from './Field.module.scss'


interface FieldProps extends LabelledProps {
  label: string
  fieldError?: FieldError
  showMessage?: boolean
  isRequired?: boolean
}

export const Field: FC<FieldProps> = ({ children, ...props }) => {
  const { error, isRequired, showMessage, fieldError } = props

  return (
    <div
      className={classNames({ 'required-field': isRequired }, styles.field, {
        [styles.fieldInvalid]: error,
      })}
    >
      <Labelled {...props}>{children}</Labelled>
      {fieldError && showMessage && (
        <span role={'alert'} className={styles.fieldError}>
          {fieldError.message}
        </span>
      )}
    </div>
  )
}
