import { ComboBox, Pagination } from '@v-uik/base'
import React from 'react'

import { type Option } from '@/shared/model'

import styles from './Paginator.module.scss'

interface PaginatorProps {
  rowAmount: number
  pageNumber: number
  onPageChange: (page: number) => void
  pageSize?: number
  siblingCount?: number
  onPageSizeChange?: (size: number) => void
  availablePageSizes?: number[]
}

export const Paginator = ({
  rowAmount,
  pageNumber,
  onPageChange,
  pageSize = 25,
  onPageSizeChange,
  availablePageSizes = [10, 25, 50, 100, 150],
}: PaginatorProps) => {
  const totalPages = Math.ceil(rowAmount / pageSize)

  const createSizeOption = (size: number) => ({
    value: size,
    label: `${size} / стр.`,
  })

  const defaultPageSize: Option<number> = createSizeOption(pageSize)

  const pageSizeOptions: Option<number>[] = availablePageSizes?.map((size) =>
    createSizeOption(size)
  )

  const handlePageChange = (page: number) => {
    onPageChange(page - 1)
  }

  return (
    <div className={styles.container}>
      <Pagination
        currentPage={pageNumber + 1}
        onPageChange={handlePageChange}
        totalPageCount={totalPages}
        size={'sm'}
      />

      {onPageSizeChange && (
        <ComboBox
          classes={{ root: styles.paginationSelection }}
          options={pageSizeOptions}
          defaultValue={defaultPageSize}
          onChange={(_value, _event, fullValue) => {
            if (fullValue) onPageSizeChange(fullValue.value)
          }}
          size={'sm'}
        />
      )}
    </div>
  )
}
