import { useLayoutEffect, useRef, useState } from 'react'

import { SKELETON_FADE_MS } from '@/shared/lib/table/plugins/SkeletonBody'

// The skeleton overlay keeps fading out for `SKELETON_FADE_MS` after
// `loading` actually flips to false (see `SkeletonBodyWrapper`), so the
// table's measured height can still shrink a moment *after* the flip, not
// only in the same tick as it. The suppression window has to outlast that
// fade, plus a small margin for layout/paint timing — hence the +100ms.
const SETTLE_MS = SKELETON_FADE_MS + 100

/**
 * Returns `true` for a brief window right after `loading` changes value,
 * `false` otherwise.
 *
 * A table's total content height jumps sharply whenever loading starts or
 * finishes (skeleton rows vs. real rows rarely match in count), and
 * animating that jump makes the whole table look like it's physically
 * growing or shrinking. Other height changes — most notably expanding a
 * row — don't have this problem and should keep animating smoothly.
 *
 * Consumers use the returned flag to switch off the height transition only
 * for the loading-driven jump, e.g. via a `data-*` attribute a CSS rule
 * reacts to, rather than removing the transition altogether.
 */
export function useSkipHeightTransitionOnLoadingChange(loading: boolean | undefined): boolean {
  const [skip, setSkip] = useState(false)
  const previousLoadingRef = useRef(loading)

  useLayoutEffect(() => {
    if (previousLoadingRef.current === loading) return
    previousLoadingRef.current = loading

    setSkip(true)
    const timeoutId = window.setTimeout(() => setSkip(false), SETTLE_MS)
    return () => window.clearTimeout(timeoutId)
  }, [loading])

  return skip
}
