import { type SortDirection } from '@tanstack/react-table'
import { ChevronDown, ChevronsUpDown, ChevronUp } from 'lucide-react'
import React, { type FC } from 'react'

interface SortingIndicatorProps {
  sortDirection: SortDirection | false
  className?: string
}

export const SortingIndicator: FC<SortingIndicatorProps> = ({
  sortDirection,
  className,
}) => {
  switch (sortDirection) {
    case 'asc':
      return <ChevronUp className={className} />
    case 'desc':
      return <ChevronDown className={className} />
    default:
      return <ChevronsUpDown className={className} />
  }
}
