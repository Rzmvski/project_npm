import { useLayoutEffect, useRef, useState } from 'react'

import styles from './Table.module.scss'

import type { CSSProperties, FC, PropsWithChildren } from 'react'

interface TableBodyHeightAnimatorProps extends PropsWithChildren {
  disabled?: boolean
}

export const TableBodyHeightAnimator: FC<TableBodyHeightAnimatorProps> = ({
  children,
  disabled,
}) => {
  const contentRef = useRef<HTMLDivElement>(null)
  const [height, setHeight] = useState<number>()

  useLayoutEffect(() => {
    if (disabled || typeof ResizeObserver === 'undefined') {
      return
    }

    const content = contentRef.current
    if (!content) return

    const updateHeight = () => {
      setHeight(content.getBoundingClientRect().height)
    }

    updateHeight()
    const observer = new ResizeObserver(updateHeight)
    observer.observe(content)

    return () => observer.disconnect()
  }, [disabled])

  const style: CSSProperties | undefined = disabled
    ? undefined
    : { height: height === undefined ? 'auto' : height }

  return (
    <div className={styles.bodyAnimator} style={style}>
      <div ref={contentRef} className={styles.bodyAnimatorContent}>
        {children}
      </div>
    </div>
  )
}
