import { type ColumnDef, flexRender, type Header, type RowData } from '@tanstack/react-table'
import { type ColumnSort } from '@tanstack/table-core'
import React from 'react'

import {
  TABLE_BODY_ATTRIBUTE,
  type TablePlugin,
  type TableView,
  useTable,
} from '@/shared/lib/table'

import styles from './Table.module.scss'
import { TableBodyHeightAnimator } from './TableBodyHeightAnimator'
import { useSkipHeightTransitionOnLoadingChange } from './useSkipHeightTransitionOnLoadingChange'

interface TableProps<TData extends RowData, TValue = unknown> {
  data: TData[]
  columns: ColumnDef<TData, TValue>[]
  plugins?: TablePlugin<TData>[]
  noDataText?: string
  loading?: boolean
  invalid?: boolean
  disabled?: boolean
  defaultSorting?: ColumnSort[]
}

/**
 * Renders a table. All of the rendering, and none of the behaviour: sorting,
 * loading, empty and error states, pinning, virtualization and the rest arrive
 * as plugins through `useTable`, which folds them into the `TableView` this
 * component draws.
 *
 * Nothing here knows what any individual plugin does. The component owns four
 * elements — container, scroll viewport, body, cells — and offers each of them
 * to plugins as props, slots and overlays; what ends up in them is not this
 * file's business.
 */
export function Table<TData extends RowData, TValue = unknown>({
  data,
  columns,
  plugins,
  ...options
}: TableProps<TData, TValue>) {
  const view = useTable({ data, columns, plugins, ...options })
  const { instance, scrollRef, rows, bodyProps, scrollProps, containerProps } = view

  const hasManagedBodyHeight = bodyProps.style?.height !== undefined

  // Loading toggling on/off changes the table's total content height sharply
  // (skeleton rows vs. real rows). Animating *that* jump makes the whole
  // table look like it's resizing like a window, so it's skipped — other
  // height changes (e.g. expanding a row) keep animating normally.
  const skipHeightTransition = useSkipHeightTransitionOnLoadingChange(
    instance.options.meta?.loading,
  )

  return (
    <div className={styles.container} {...containerProps}>
      <div ref={scrollRef} role={'table'} className={styles.table} {...scrollProps}>
        <div role={'columnheader'}>
          {instance.getHeaderGroups().map((headerGroup) => (
            <div key={headerGroup.id} role={'row'}>
              {headerGroup.headers.map((header) => (
                <TableHeaderCell key={header.id} header={header} view={view} />
              ))}
            </div>
          ))}
        </div>
        <div className={styles.tbody} role={'rowgroup'}>
          <div
            className={styles.tbodyInner}
            {...{ [TABLE_BODY_ATTRIBUTE]: '' }}
            {...bodyProps}
            data-skip-height-transition={skipHeightTransition || undefined}
          >
            <TableBodyHeightAnimator disabled={hasManagedBodyHeight}>
              {view.renderBody(
                view.bodyState ??
                  rows.map((row) => (
                    <React.Fragment key={row.id}>
                      {view.renderRow(
                        row,
                        <div role={'row'}>
                          {row.getVisibleCells().map((cell) => (
                            <React.Fragment key={cell.id}>
                              {view.renderCell(
                                cell,
                                flexRender(cell.column.columnDef.cell, cell.getContext()),
                              )}
                            </React.Fragment>
                          ))}
                        </div>,
                      )}
                    </React.Fragment>
                  )),
              )}
            </TableBodyHeightAnimator>
          </div>
        </div>
      </div>
      {view.renderContainerOverlay()}
    </div>
  )
}

interface TableHeaderCellProps<TData extends RowData> {
  header: Header<TData, unknown>
  view: TableView<TData>
}

function TableHeaderCell<TData extends RowData>({ header, view }: TableHeaderCellProps<TData>) {
  const headerProps = view.getHeaderProps(header)

  if (header.isPlaceholder) {
    return <div {...headerProps} style={{ ...headerProps.style, flex: header.colSpan }} />
  }

  return (
    <div {...headerProps}>
      <span>{flexRender(header.column.columnDef.header, header.getContext())}</span>
      {view.renderHeaderContent(header)}
    </div>
  )
}
