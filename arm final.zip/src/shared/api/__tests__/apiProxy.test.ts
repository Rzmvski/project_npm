import { describe, it, expect, vi, beforeEach } from 'vitest'

import { ApiProxy } from '../apiProxy'
import { apiVersionManager } from '../apiVersionManager'

import type { BaseAPI } from '@sber-pprb-tkp/tcpf-platform-admin-api'

class MockBaseAPI {
  async newMethod(data: string) {
    return `new:${data}`
  }

  async deprecatedMethod(data: string) {
    return `deprecated:${data}`
  }

  async newMethodFails(_data: string) {
    throw new Error('new method failed')
  }

  async newMethodThrowsString(_data: string) {
    throw 'string error'
  }

  async newMethodThrowsObject(_data: string) {
    throw { code: 500, message: 'server error' }
  }

  async newMethodThrowsNumber(_data: string) {
    throw 42
  }

  async onlyNewMethod(data: string) {
    return `only:${data}`
  }
}

describe('ApiProxy', () => {
  let client: MockBaseAPI & BaseAPI
  let proxy: ApiProxy<MockBaseAPI & BaseAPI>

  beforeEach(() => {
    client = new MockBaseAPI() as MockBaseAPI & BaseAPI
    proxy = new ApiProxy(client)
    apiVersionManager.useDeprecatedMethods = null
  })

  describe('call()', () => {
    it('should call new method when useDeprecatedMethods is false', async () => {
      apiVersionManager.useDeprecatedMethods = false
      const result = await proxy.call('newMethod', 'deprecatedMethod', 'test')
      expect(result).toBe('new:test')
    })

    it('should call deprecated method when useDeprecatedMethods is true', async () => {
      apiVersionManager.useDeprecatedMethods = true
      const result = await proxy.call('newMethod', 'deprecatedMethod', 'test')
      expect(result).toBe('deprecated:test')
    })

    it('should call new method and set useDeprecatedMethods to false on success when null', async () => {
      expect(apiVersionManager.useDeprecatedMethods).toBeNull()
      const result = await proxy.call('newMethod', 'deprecatedMethod', 'test')
      expect(result).toBe('new:test')
      expect(apiVersionManager.useDeprecatedMethods).toBe(false)
    })

    it('should fall back to deprecated method and set useDeprecatedMethods to true when new method fails and null', async () => {
      expect(apiVersionManager.useDeprecatedMethods).toBeNull()
      const result = await proxy.call(
        'newMethodFails' as unknown as 'newMethod',
        'deprecatedMethod',
        'test',
      )
      expect(result).toBe('deprecated:test')
      expect(apiVersionManager.useDeprecatedMethods).toBe(true)
    })

    it('should pass multiple arguments to the method', async () => {
      apiVersionManager.useDeprecatedMethods = false
      const newMethodSpy = vi.spyOn(client, 'newMethod' as any)
      await proxy.call('newMethod', 'deprecatedMethod', 'arg1', 'arg2')
      expect(newMethodSpy).toHaveBeenCalledWith('arg1', 'arg2')
    })

    it('should fall back to deprecated method when new method throws a string error', async () => {
      expect(apiVersionManager.useDeprecatedMethods).toBeNull()
      const result = await proxy.call(
        'newMethodThrowsString' as unknown as 'newMethod',
        'deprecatedMethod',
        'test',
      )
      expect(result).toBe('deprecated:test')
      expect(apiVersionManager.useDeprecatedMethods).toBe(true)
    })

    it('should call new method directly when only new method name is provided (duplicate names)', async () => {
      apiVersionManager.useDeprecatedMethods = false
      const result = await proxy.call('onlyNewMethod', 'onlyNewMethod', 'data')
      expect(result).toBe('only:data')
    })

    it('should call deprecated method when only new method exists and useDeprecatedMethods is true (duplicate names)', async () => {
      apiVersionManager.useDeprecatedMethods = true
      const result = await proxy.call('onlyNewMethod', 'onlyNewMethod', 'data')
      expect(result).toBe('only:data')
    })

    it('should handle when only new method exists and new method does not throw', async () => {
      apiVersionManager.useDeprecatedMethods = null
      const result = await proxy.call('onlyNewMethod', 'onlyNewMethod', 'data')
      expect(result).toBe('only:data')
      expect(apiVersionManager.useDeprecatedMethods).toBe(false)
    })

    it('should call deprecated method without attempting new method when useDeprecatedMethods is true even if new method would fail', async () => {
      apiVersionManager.useDeprecatedMethods = true
      const newMethodSpy = vi.spyOn(client, 'newMethodFails' as any)
      const deprecatedMethodSpy = vi.spyOn(client, 'deprecatedMethod' as any)
      const result = await proxy.call(
        'newMethodFails' as unknown as 'newMethod',
        'deprecatedMethod',
        'test',
      )
      expect(result).toBe('deprecated:test')
      expect(newMethodSpy).not.toHaveBeenCalled()
      expect(deprecatedMethodSpy).toHaveBeenCalledWith('test')
    })

    it('should try new method first and fall back to deprecated when new method throws Error and useDeprecatedMethods is null', async () => {
      const newMethodSpy = vi.spyOn(client, 'newMethodFails' as any)
      const deprecatedMethodSpy = vi.spyOn(client, 'deprecatedMethod' as any)
      const result = await proxy.call(
        'newMethodFails' as unknown as 'newMethod',
        'deprecatedMethod',
        'test',
      )
      expect(result).toBe('deprecated:test')
      expect(newMethodSpy).toHaveBeenCalledWith('test')
      expect(deprecatedMethodSpy).toHaveBeenCalledWith('test')
      expect(apiVersionManager.useDeprecatedMethods).toBe(true)
    })

    it('should fall back to deprecated method when new method throws an object (non-Error)', async () => {
      const result = await proxy.call(
        'newMethodThrowsObject' as unknown as 'newMethod',
        'deprecatedMethod',
        'test',
      )
      expect(result).toBe('deprecated:test')
      expect(apiVersionManager.useDeprecatedMethods).toBe(true)
    })

    it('should fall back to deprecated method when new method throws a number (non-Error)', async () => {
      const result = await proxy.call(
        'newMethodThrowsNumber' as unknown as 'newMethod',
        'deprecatedMethod',
        'test',
      )
      expect(result).toBe('deprecated:test')
      expect(apiVersionManager.useDeprecatedMethods).toBe(true)
    })
  })
})
