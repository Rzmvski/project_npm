import {
  ReviseReplicationServiceApi,
  ScriptServiceApi,
  UserServiceApi,
  ZoneIndexServiceApi,
  ClusterManagementServiceApi,
  ConnectionPoolManagementServiceApi,
  MetadataManagementServiceApi,
  MonitoringManagementServiceApi,
  GeoBalancingManagementServiceApi,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'
import {
  ClientTransferServiceApi,
  OperationDayServiceApi,
  ProcessManagementServiceApi,
} from '@sber-pprb-tkp/tcpf-support-admin-api'
import { describe, it, expect } from 'vitest'

import {
  reviseReplicationService,
  scriptService,
  userService,
  zoneIndexService,
  clusterManagementService,
  connectionPoolManagementService,
  metadataManagementService,
  monitoringManagementService,
  geoBalancingManagementService,
  clientTransferService,
  odService,
  processManagementService,
} from '../services'

describe('services', () => {
  it('should export reviseReplicationService', () => {
    expect(reviseReplicationService).toBeDefined()
  })

  it('should export scriptService', () => {
    expect(scriptService).toBeDefined()
  })

  it('should export userService', () => {
    expect(userService).toBeDefined()
  })

  it('should export zoneIndexService', () => {
    expect(zoneIndexService).toBeDefined()
  })

  it('should export clusterManagementService', () => {
    expect(clusterManagementService).toBeDefined()
  })

  it('should export connectionPoolManagementService', () => {
    expect(connectionPoolManagementService).toBeDefined()
  })

  it('should export metadataManagementService', () => {
    expect(metadataManagementService).toBeDefined()
  })

  it('should export monitoringManagementService', () => {
    expect(monitoringManagementService).toBeDefined()
  })

  it('should export geoBalancingManagementService', () => {
    expect(geoBalancingManagementService).toBeDefined()
  })

  it('should export clientTransferService', () => {
    expect(clientTransferService).toBeDefined()
  })

  it('should export odService', () => {
    expect(odService).toBeDefined()
  })

  it('should export processManagementService', () => {
    expect(processManagementService).toBeDefined()
  })

  it('should have all 12 services defined', () => {
    const services = [
      reviseReplicationService,
      scriptService,
      userService,
      zoneIndexService,
      clusterManagementService,
      connectionPoolManagementService,
      metadataManagementService,
      monitoringManagementService,
      geoBalancingManagementService,
      clientTransferService,
      odService,
      processManagementService,
    ]
    expect(services).toHaveLength(12)
    services.forEach((service) => {
      expect(service).toBeDefined()
    })
  })

  describe('instance types', () => {
    it('reviseReplicationService should be instance of ReviseReplicationServiceApi', () => {
      expect(reviseReplicationService).toBeInstanceOf(ReviseReplicationServiceApi)
    })

    it('scriptService should be instance of ScriptServiceApi', () => {
      expect(scriptService).toBeInstanceOf(ScriptServiceApi)
    })

    it('userService should be instance of UserServiceApi', () => {
      expect(userService).toBeInstanceOf(UserServiceApi)
    })

    it('zoneIndexService should be instance of ZoneIndexServiceApi', () => {
      expect(zoneIndexService).toBeInstanceOf(ZoneIndexServiceApi)
    })

    it('clusterManagementService should be instance of ClusterManagementServiceApi', () => {
      expect(clusterManagementService).toBeInstanceOf(ClusterManagementServiceApi)
    })

    it('connectionPoolManagementService should be instance of ConnectionPoolManagementServiceApi', () => {
      expect(connectionPoolManagementService).toBeInstanceOf(ConnectionPoolManagementServiceApi)
    })

    it('metadataManagementService should be instance of MetadataManagementServiceApi', () => {
      expect(metadataManagementService).toBeInstanceOf(MetadataManagementServiceApi)
    })

    it('monitoringManagementService should be instance of MonitoringManagementServiceApi', () => {
      expect(monitoringManagementService).toBeInstanceOf(MonitoringManagementServiceApi)
    })

    it('geoBalancingManagementService should be instance of GeoBalancingManagementServiceApi', () => {
      expect(geoBalancingManagementService).toBeInstanceOf(GeoBalancingManagementServiceApi)
    })

    it('clientTransferService should be instance of ClientTransferServiceApi', () => {
      expect(clientTransferService).toBeInstanceOf(ClientTransferServiceApi)
    })

    it('odService should be instance of OperationDayServiceApi', () => {
      expect(odService).toBeInstanceOf(OperationDayServiceApi)
    })

    it('processManagementService should be instance of ProcessManagementServiceApi', () => {
      expect(processManagementService).toBeInstanceOf(ProcessManagementServiceApi)
    })
  })

  describe('service methods', () => {
    const serviceList = [
      { name: 'reviseReplicationService', service: reviseReplicationService },
      { name: 'scriptService', service: scriptService },
      { name: 'userService', service: userService },
      { name: 'zoneIndexService', service: zoneIndexService },
      { name: 'clusterManagementService', service: clusterManagementService },
      {
        name: 'connectionPoolManagementService',
        service: connectionPoolManagementService,
      },
      { name: 'metadataManagementService', service: metadataManagementService },
      { name: 'monitoringManagementService', service: monitoringManagementService },
      { name: 'geoBalancingManagementService', service: geoBalancingManagementService },
      { name: 'clientTransferService', service: clientTransferService },
      { name: 'odService', service: odService },
      { name: 'processManagementService', service: processManagementService },
    ]

    it.each(serviceList)('$name should have at least one method', ({ service }) => {
      const methodNames = Object.getOwnPropertyNames(Object.getPrototypeOf(service)).filter(
        (key) => key !== 'constructor' && typeof (service as any)[key] === 'function',
      )
      expect(methodNames.length).toBeGreaterThan(0)
    })

    it('each service should be an object (not null, not primitive)', () => {
      serviceList.forEach(({ service }) => {
        expect(service).toBeTruthy()
        expect(typeof service).toBe('object')
      })
    })
  })

  describe('service configuration', () => {
    it('platform services should share the same request configuration', () => {
      const platformServices = [
        reviseReplicationService,
        scriptService,
        userService,
        zoneIndexService,
        clusterManagementService,
        connectionPoolManagementService,
        metadataManagementService,
        monitoringManagementService,
        geoBalancingManagementService,
      ]
      platformServices.forEach((service) => {
        expect((service as any).configuration).toBeDefined()
        expect(typeof (service as any).configuration).toBe('object')
      })
    })

    it('tkp services should share the same request configuration', () => {
      const tkpServices = [clientTransferService, odService, processManagementService]
      tkpServices.forEach((service) => {
        expect((service as any).configuration).toBeDefined()
        expect(typeof (service as any).configuration).toBe('object')
      })
    })
  })
})
