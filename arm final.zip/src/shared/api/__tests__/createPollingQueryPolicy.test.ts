import { describe, it, expect, vi } from 'vitest'

import { createPollingQueryPolicy } from '../createPollingQueryPolicy'

import type { QueryObserverResult } from '@tanstack/react-query'

describe('createPollingQueryPolicy', () => {
  const getRefetchInterval = (policy: ReturnType<typeof createPollingQueryPolicy>) =>
    policy.refetchInterval as (query: unknown) => number | false | undefined

  const defaultParams = {
    stopPredicate: vi.fn(),
  }

  it('should return refetchInterval and retry', () => {
    const policy = createPollingQueryPolicy(defaultParams)
    expect(policy).toHaveProperty('refetchInterval')
    expect(policy).toHaveProperty('retry')
  })

  it('should return refetchInterval as a function', () => {
    const policy = createPollingQueryPolicy(defaultParams)
    expect(typeof policy.refetchInterval).toBe('function')
  })

  it('should default retry to false', () => {
    const policy = createPollingQueryPolicy(defaultParams)
    expect(policy.retry).toBe(false)
  })

  it('should use provided retry value', () => {
    const policy = createPollingQueryPolicy({
      ...defaultParams,
      retry: true,
    })
    expect(policy.retry).toBe(true)
  })

  it('should use default interval of 2000ms', () => {
    const stopPredicate = vi.fn().mockReturnValue(false)
    const policy = createPollingQueryPolicy({ stopPredicate })
    const interval = getRefetchInterval(policy)({
      state: {
        status: 'success',
        data: 'some data',
      },
    } as unknown as QueryObserverResult<unknown, unknown> & {
      state: { status: string; data: unknown }
    })
    expect(interval).toBe(2000)
  })

  it('should use custom intervalMs', () => {
    const stopPredicate = vi.fn().mockReturnValue(false)
    const policy = createPollingQueryPolicy({
      stopPredicate,
      intervalMs: 5000,
    })
    const interval = getRefetchInterval(policy)({
      state: {
        status: 'success',
        data: 'some data',
      },
    } as unknown as QueryObserverResult<unknown, unknown> & {
      state: { status: string; data: unknown }
    })
    expect(interval).toBe(5000)
  })

  it('should return false when status is error', () => {
    const stopPredicate = vi.fn()
    const policy = createPollingQueryPolicy({ stopPredicate })
    const interval = getRefetchInterval(policy)({
      state: {
        status: 'error',
        data: undefined,
      },
    } as unknown as QueryObserverResult<unknown, unknown> & {
      state: { status: string; data: unknown }
    })
    expect(interval).toBe(false)
  })

  it('should return false when stopPredicate returns true', () => {
    const stopPredicate = vi.fn().mockReturnValue(true)
    const policy = createPollingQueryPolicy({ stopPredicate })
    const interval = getRefetchInterval(policy)({
      state: {
        status: 'success',
        data: { completed: true },
      },
    } as unknown as QueryObserverResult<unknown, unknown> & {
      state: { status: string; data: unknown }
    })
    expect(interval).toBe(false)
    expect(stopPredicate).toHaveBeenCalledWith({ completed: true })
  })

  it('should return false when data is null/undefined (shouldStop guard)', () => {
    const stopPredicate = vi.fn()
    const policy = createPollingQueryPolicy({ stopPredicate })
    const interval = getRefetchInterval(policy)({
      state: {
        status: 'success',
        data: null,
      },
    } as unknown as QueryObserverResult<unknown, unknown> & {
      state: { status: string; data: unknown }
    })
    expect(interval).toBe(2000)
    expect(stopPredicate).not.toHaveBeenCalled()
  })

  it('should return intervalMs when shouldStop is false and data exists', () => {
    const stopPredicate = vi.fn().mockReturnValue(false)
    const policy = createPollingQueryPolicy({
      stopPredicate,
      intervalMs: 3000,
    })
    const interval = getRefetchInterval(policy)({
      state: {
        status: 'success',
        data: { progress: 50 },
      },
    } as unknown as QueryObserverResult<unknown, unknown> & {
      state: { status: string; data: unknown }
    })
    expect(interval).toBe(3000)
    expect(stopPredicate).toHaveBeenCalledWith({ progress: 50 })
  })

  it('should return default intervalMs when status is pending', () => {
    const stopPredicate = vi.fn()
    const policy = createPollingQueryPolicy({ stopPredicate })
    const interval = getRefetchInterval(policy)({
      state: {
        status: 'pending',
        data: undefined,
      },
    } as unknown as QueryObserverResult<unknown, unknown> & {
      state: { status: string; data: unknown }
    })
    expect(interval).toBe(2000)
  })

  it('should return custom intervalMs when status is pending', () => {
    const stopPredicate = vi.fn()
    const policy = createPollingQueryPolicy({ stopPredicate, intervalMs: 5000 })
    const interval = getRefetchInterval(policy)({
      state: {
        status: 'pending',
        data: undefined,
      },
    } as unknown as QueryObserverResult<unknown, unknown> & {
      state: { status: string; data: unknown }
    })
    expect(interval).toBe(5000)
  })

  it('should return intervalMs for success status when stopPredicate returns false', () => {
    const stopPredicate = vi.fn().mockReturnValue(false)
    const policy = createPollingQueryPolicy({ stopPredicate, intervalMs: 4000 })
    const interval = getRefetchInterval(policy)({
      state: {
        status: 'success',
        data: 'some result',
      },
    } as unknown as QueryObserverResult<unknown, unknown> & {
      state: { status: string; data: unknown }
    })
    expect(interval).toBe(4000)
    expect(stopPredicate).toHaveBeenCalledWith('some result')
  })
})
