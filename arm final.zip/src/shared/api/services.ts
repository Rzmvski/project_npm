import {
  ClusterManagementServiceApiSse,
  ConnectionPoolManagementServiceApiSse,
  FeatureTogglingServiceApi,
  GeoBalancingManagementServiceApiSse,
  MetadataManagementServiceApiSse,
  MonitoringManagementServiceApiSse,
  ReviseReplicationServiceApi,
  ScriptServiceApi,
  UserServiceApi,
  ZoneIndexServiceApi,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'
import {
  ClientTransferServiceApi,
  OperationDayServiceApi,
  ProcessManagementServiceApi,
} from '@sber-pprb-tkp/tcpf-support-admin-api'

import { platformRequestConfiguration, tkpRequestConfiguration } from '@/shared/config'

type WithoutJsonOperations<TApi, TOperation extends string> = Omit<
  TApi,
  TOperation | `${TOperation}Raw`
>

type ClusterManagementService = WithoutJsonOperations<
  ClusterManagementServiceApiSse,
  | 'changeClusterState'
  | 'semaphoreInfo'
  | 'getShards'
  | 'updateNodesOfShardById'
  | 'updateSemaphoresOfShardById'
  | 'getNodes'
>

type ConnectionPoolManagementService = WithoutJsonOperations<
  ConnectionPoolManagementServiceApiSse,
  'getPools' | 'changePoolState'
>

type MetadataManagementService = WithoutJsonOperations<
  MetadataManagementServiceApiSse,
  'refreshMetadataOnNode'
>

type MonitoringManagementService = WithoutJsonOperations<
  MonitoringManagementServiceApiSse,
  'getDbMonitorings' | 'getIgniteMonitorings'
>

type GeoBalancingManagementService = WithoutJsonOperations<
  GeoBalancingManagementServiceApiSse,
  | 'getGeoBalancingServices'
  | 'getDataCenters'
  | 'getTrafficRestrictions'
  | 'createTrafficRestriction'
  | 'getTrafficRestrictionById'
  | 'updateTrafficRestriction'
  | 'removeTrafficRestrictionById'
>

// Для stream-only операций публичный тип скрывает унаследованные JSON и Raw
// методы генератора. Приложение использует только `<operationId>Stream()`.
// Обычные JSON-операции смешанных сервисов остаются доступны.

export const featureTogglingService = new FeatureTogglingServiceApi(
  platformRequestConfiguration,
)
export const reviseReplicationService = new ReviseReplicationServiceApi(
  platformRequestConfiguration,
)
export const scriptService = new ScriptServiceApi(platformRequestConfiguration)
export const userService = new UserServiceApi(platformRequestConfiguration)
export const zoneIndexService = new ZoneIndexServiceApi(platformRequestConfiguration)
export const metadataManagementService: MetadataManagementService =
  new MetadataManagementServiceApiSse(platformRequestConfiguration)

export const clusterManagementService: ClusterManagementService =
  new ClusterManagementServiceApiSse(platformRequestConfiguration)
export const monitoringManagementService: MonitoringManagementService =
  new MonitoringManagementServiceApiSse(platformRequestConfiguration)
export const geoBalancingManagementService: GeoBalancingManagementService =
  new GeoBalancingManagementServiceApiSse(platformRequestConfiguration)
export const connectionPoolManagementService: ConnectionPoolManagementService =
  new ConnectionPoolManagementServiceApiSse(platformRequestConfiguration)

export const clientTransferService = new ClientTransferServiceApi(tkpRequestConfiguration)
export const odService = new OperationDayServiceApi(tkpRequestConfiguration)
export const processManagementService = new ProcessManagementServiceApi(tkpRequestConfiguration)
