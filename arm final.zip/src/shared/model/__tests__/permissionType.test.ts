import { describe, it, expect } from 'vitest'

import { Permissions } from '../permissionType'

import type { PermissionType } from '../permissionType'

describe('permissionType', () => {
  describe('Permissions const enum', () => {
    it('should have GET_DICTIONARY permission', () => {
      expect(Permissions.GET_DICTIONARY).toBe('dictionariesService_getDictionary')
    })

    it('should have GET_CURRENT_OPERATIONS_DAY permission', () => {
      expect(Permissions.GET_CURRENT_OPERATIONS_DAY).toBe(
        'closingOperationDayService_getCurrentOperationDay',
      )
    })

    it('should have START_CLOSING_OPERATION_DAY permission', () => {
      expect(Permissions.START_CLOSING_OPERATION_DAY).toBe(
        'closingOperationDayService_startClosingOperationDay',
      )
    })

    it('should have GET_RESULT_OF_CLOSING_OPERATIONS_DAY permission', () => {
      expect(Permissions.GET_RESULT_OF_CLOSING_OPERATIONS_DAY).toBe(
        'closingOperationDayService_getResultOfClosingOperationDay',
      )
    })

    it('should have GET_FAILED_CONTRACTS_WITH_STEPS permission', () => {
      expect(Permissions.GET_FAILED_CONTRACTS_WITH_STEPS).toBe(
        'closingOperationDayService_getFailedContractsWithSteps',
      )
    })

    it('should have GET_HISTORY_OF_CLOSING_OPERATIONS_DAY permission', () => {
      expect(Permissions.GET_HISTORY_OF_CLOSING_OPERATIONS_DAY).toBe(
        'closingOperationDayService_getHistory',
      )
    })

    it('should have GET_HISTORY_DETAILED_OF_CLOSING_OPERATIONS_DAY permission', () => {
      expect(Permissions.GET_HISTORY_DETAILED_OF_CLOSING_OPERATIONS_DAY).toBe(
        'closingOperationDayService_getHistoryDetailed',
      )
    })

    it('should have START_FOR_PROCESSES_GROUP permission', () => {
      expect(Permissions.START_FOR_PROCESSES_GROUP).toBe(
        'processManagementService_startProcess',
      )
    })

    it('should have GET_HISTORY_FOR_PROCESSES_GROUP permission', () => {
      expect(Permissions.GET_HISTORY_FOR_PROCESSES_GROUP).toBe(
        'processManagementService_getHistory',
      )
    })

    it('should have GET_OPERATION_DAYS_IN_HEADER permission', () => {
      expect(Permissions.GET_OPERATION_DAYS_IN_HEADER).toBe(
        'closingOperationDayService_getOperationDays',
      )
    })

    it('should have GET_STAND_IN_STATUS permission', () => {
      expect(Permissions.GET_STAND_IN_STATUS).toBe('standInService_getStandInStatus')
    })

    it('should have ADMIN_PROCESSES permission', () => {
      expect(Permissions.ADMIN_PROCESSES).toBe('userService_getPermissions')
    })

    it('should have CLUSTER_INFO permission', () => {
      expect(Permissions.CLUSTER_INFO).toBe('zoneIndexService_getClusterInfo')
    })

    it('should have SHARD_INFO permission', () => {
      expect(Permissions.SHARD_INFO).toBe('shardInfoService_getInfo')
    })

    it('should have RUN_SCRIPT permission', () => {
      expect(Permissions.RUN_SCRIPT).toBe('scriptService_createScriptRequest')
    })

    it('should have CLIENT_TRANSFER permission', () => {
      expect(Permissions.CLIENT_TRANSFER).toBe('clientTransferService_transfer')
    })

    it('should have FEATURE_TOGGLING permission', () => {
      expect(Permissions.FEATURE_TOGGLING).toBe('featureTogglingService_getInfo')
    })

    it('should have CLUSTER_MANAGEMENT permission', () => {
      expect(Permissions.CLUSTER_MANAGEMENT).toBe('clusterManagementService_getShard')
    })

    it('should have REVISE_REPLICATION permission', () => {
      expect(Permissions.REVISE_REPLICATION).toBe('revisionService_runRevision')
    })
  })

  describe('PermissionType type', () => {
    it('should accept Permissions value', () => {
      const permission: PermissionType = Permissions.GET_DICTIONARY
      expect(permission).toBe('dictionariesService_getDictionary')
    })

    it('should accept arbitrary string', () => {
      const permission: PermissionType = 'any_custom_permission'
      expect(permission).toBe('any_custom_permission')
    })
  })
})
