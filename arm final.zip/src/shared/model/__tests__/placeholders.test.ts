import { describe, it, expect } from 'vitest'

import { NOTHING } from '../placeholders'

describe('placeholders', () => {
  describe('NOTHING', () => {
    it('should be an en dash character', () => {
      expect(NOTHING).toBe('\u2013')
    })

    it('should be the string "–"', () => {
      expect(NOTHING).toBe('–')
    })

    it('should have length 1', () => {
      expect(NOTHING).toHaveLength(1)
    })

    it('should be defined as a constant', () => {
      expect(NOTHING).toBeDefined()
    })
  })
})
