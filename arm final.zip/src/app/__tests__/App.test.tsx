import { render, screen } from '@testing-library/react'
import { describe, it, expect, vi } from 'vitest'

vi.mock('@/app/providers', () => ({
  AppProviders: () => <div data-testid='app-providers'>AppProviders</div>,
}))

vi.mock('@/app/styles/global.scss', () => ({}))
vi.mock('@/shared/styles/tokens.scss', () => ({}))

import { App } from '../App'

describe('App', () => {
  it('рендерит AppProviders', () => {
    render(<App />)

    expect(screen.getByTestId('app-providers')).toBeInTheDocument()
  })
})
