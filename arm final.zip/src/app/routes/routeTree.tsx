import {
  createRootRouteWithContext,
  createRoute,
  lazyRouteComponent,
  redirect,
  type RouteComponent,
} from '@tanstack/react-router'

import { AppLayout, ServiceLayout } from '@/app/layouts'
import { type RouterContext } from '@/app/routes/routerContext'
import { ServiceId, serviceRegistry } from '@/entities/service'
import { userQueryOptions } from '@/entities/user'
import { hasAllAuthorities, hasAuthorityWithSubstring } from '@/features/access-check/lib'
import { DesktopPage } from '@/pages/desktop'
import { ErrorPage } from '@/pages/error'
import { ForbiddenPage } from '@/pages/forbidden'
import { NotFoundPage } from '@/pages/not-found'
import { ROUTES } from '@/shared/config'

const CloseTradingDayPage = lazyRouteComponent(
  () => import('@/pages/close-od'),
  'CloseTradingDayPage',
)

const StartProcessGroupPage = lazyRouteComponent(
  () => import('@/pages/start-process-group'),
  'StartProcessGroupPage',
)

const IndexManagementPage = lazyRouteComponent(
  () => import('@/pages/index-management'),
  'IndexManagementPage',
)

const ShardInfoPage = lazyRouteComponent(() => import('@/pages/shard-info'), 'ShardInfoPage')

const ScriptRunnerPage = lazyRouteComponent(
  () => import('@/pages/script-runner'),
  'ScriptRunnerPage',
)

const NodeBalancingPage = lazyRouteComponent(
  () => import('@/pages/node-balancing'),
  'NodeBalancingPage',
)

const FeatureTogglingPage = lazyRouteComponent(
  () => import('@/pages/feature-toggling'),
  'FeatureTogglingPage',
)

const ClusterManagementPage = lazyRouteComponent(
  () => import('@/pages/cluster-management'),
  'ClusterManagementPage',
)

const ReviseReplicationPage = lazyRouteComponent(
  () => import('@/pages/revise-replication'),
  'ReviseReplicationPage',
)

const GeoBalancingPage = lazyRouteComponent(
  () => import('@/pages/geo-balancing'),
  'GeoBalancingPage',
)

export const rootRoute = createRootRouteWithContext<RouterContext>()({
  component: AppLayout,

  notFoundComponent: () => (
    <ServiceLayout>
      <NotFoundPage />
    </ServiceLayout>
  ),
})

const indexRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/',

  beforeLoad: async ({ context }) => {
    const { roles } = await context.queryClient.ensureQueryData(userQueryOptions())
    if (!hasAuthorityWithSubstring(roles, 'ADMIN')) {
      throw redirect({
        to: ROUTES.FORBIDDEN,
        replace: true,
      })
    }
  },

  component: DesktopPage,
})

const serviceLayoutRoute = createRoute({
  getParentRoute: () => rootRoute,
  id: 'service-layout',
  component: ServiceLayout,

  errorComponent: ({ reset }) => (
    <ServiceLayout>
      <ErrorPage onRetry={reset} />
    </ServiceLayout>
  ),
})

function createSecuredServiceRoute<TPath extends string>(
  serviceId: ServiceId,
  component: RouteComponent,
  path?: TPath,
) {
  const service = serviceRegistry[serviceId]

  return createRoute({
    getParentRoute: () => serviceLayoutRoute,
    path: path ?? service.route,

    beforeLoad: async ({ context }) => {
      const { permissions } = await context.queryClient.ensureQueryData(userQueryOptions())
      const required = service.permissions
      if (!hasAllAuthorities(permissions, required)) {
        throw redirect({
          to: ROUTES.FORBIDDEN,
          replace: true,
        })
      }
    },

    head: () => ({
      meta: [
        {
          title: service.title,
        },
      ],
    }),

    component,
  })
}

const closeTradingDayRoute = createSecuredServiceRoute(
  ServiceId.CLOSE_TRADING_DAY,
  CloseTradingDayPage,
  `${ROUTES.CLOSE_TRADING_DAY}/{-$tab}`,
)

const startProcessGroupRoute = createSecuredServiceRoute(
  ServiceId.START_PROCESS_GROUP,
  StartProcessGroupPage,
  `${ROUTES.START_PROCESS_GROUP}/{-$tab}`,
)

const indexManagementRoute = createSecuredServiceRoute(
  ServiceId.INDEX_MANAGEMENT,
  IndexManagementPage,
)

const shardInfoRoute = createSecuredServiceRoute(ServiceId.SHARD_INFO, ShardInfoPage)

const scriptRunnerRoute = createSecuredServiceRoute(
  ServiceId.SCRIPT_RUNNER,
  ScriptRunnerPage,
  `${ROUTES.SCRIPT_RUNNER}/{-$tab}`,
)

const nodeBalancingRoute = createSecuredServiceRoute(
  ServiceId.NODE_BALANCING,
  NodeBalancingPage,
  `${ROUTES.NODE_BALANCING}/{-$tab}`,
)

const featureTogglingRoute = createSecuredServiceRoute(
  ServiceId.FEATURE_TOGGLING,
  FeatureTogglingPage,
  `${ROUTES.FEATURE_TOGGLING}/{-$tab}`,
)

const clusterManagementRoute = createSecuredServiceRoute(
  ServiceId.CLUSTER_MANAGEMENT,
  ClusterManagementPage,
  `${ROUTES.CLUSTER_MANAGEMENT}/{-$tab}`,
)

const reviseReplicationRoute = createSecuredServiceRoute(
  ServiceId.REVISE_REPLICATION,
  ReviseReplicationPage,
  `${ROUTES.REVISE_REPLICATION}/{-$tab}`,
)

const geoBalancingRoute = createSecuredServiceRoute(ServiceId.GEO_BALANCING, GeoBalancingPage)

const forbiddenRoute = createRoute({
  getParentRoute: () => serviceLayoutRoute,
  path: ROUTES.FORBIDDEN,

  head: () => ({
    meta: [{ title: 'Нет доступа' }],
  }),

  component: ForbiddenPage,
})

const notFoundRoute = createRoute({
  getParentRoute: () => serviceLayoutRoute,
  path: ROUTES.NOT_FOUND,

  head: () => ({
    meta: [{ title: 'Страница не найдена' }],
  }),

  component: NotFoundPage,
})

const errorRoute = createRoute({
  getParentRoute: () => serviceLayoutRoute,
  path: ROUTES.ERROR,

  head: () => ({
    meta: [{ title: 'Ошибка' }],
  }),

  component: ErrorPage,
})

const serviceRoutes = serviceLayoutRoute.addChildren([
  closeTradingDayRoute,
  startProcessGroupRoute,
  indexManagementRoute,
  shardInfoRoute,
  scriptRunnerRoute,
  nodeBalancingRoute,
  featureTogglingRoute,
  clusterManagementRoute,
  reviseReplicationRoute,
  geoBalancingRoute,

  forbiddenRoute,
  notFoundRoute,
  errorRoute,
])

export const routeTree = rootRoute.addChildren([indexRoute, serviceRoutes])
