import { QueryClient } from '@tanstack/react-query'
import { createMemoryHistory, RouterProvider } from '@tanstack/react-router'
import { render, screen } from '@testing-library/react'

import { createAppRouter } from '../router'

export class AppRoutesTestModel {
  private constructor() {}

  static open(path: string) {
    const queryClient = new QueryClient({
      defaultOptions: {
        queries: {
          retry: false,
        },
      },
    })
    const router = createAppRouter(queryClient, createMemoryHistory({ initialEntries: [path] }))

    render(<RouterProvider router={router} />)

    return new AppRoutesTestModel()
  }

  expectPage(name: string) {
    return screen.findByRole('heading', { name })
  }
}
