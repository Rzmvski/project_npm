import { Outlet } from '@tanstack/react-router'
import { screen } from '@testing-library/react'
import { beforeEach, describe, expect, it, vi } from 'vitest'

import { AppRoutesTestModel } from './routeTree.test-model'

vi.mock('@/app/layouts', () => ({
  AppLayout: () => (
    <main aria-label='Приложение'>
      <Outlet />
    </main>
  ),
  ServiceLayout: ({ children }: { children?: React.ReactNode }) => (
    <section aria-label='Сервис'>{children ?? <Outlet />}</section>
  ),
}))

vi.mock('@/pages/desktop', () => ({
  DesktopPage: () => <h1>Главная страница</h1>,
}))

vi.mock('@/pages/forbidden', () => ({
  ForbiddenPage: () => <h1>Доступ запрещён</h1>,
}))

vi.mock('@/pages/error', () => ({
  ErrorPage: () => <h1>Что-то пошло не так</h1>,
}))

vi.mock('@/pages/not-found', () => ({
  NotFoundPage: () => <h1>Страница не найдена</h1>,
}))

vi.mock('@/pages/close-od', () => ({ CloseTradingDayPage: () => <h1>Закрытие дня</h1> }))
vi.mock('@/pages/start-process-group', () => ({
  StartProcessGroupPage: () => <h1>Запуск процессов</h1>,
}))
vi.mock('@/pages/index-management', () => ({
  IndexManagementPage: () => <h1>Индексы</h1>,
}))
vi.mock('@/pages/shard-info', () => ({ ShardInfoPage: () => <h1>Поиск шарда</h1> }))
vi.mock('@/pages/script-runner', () => ({ ScriptRunnerPage: () => <h1>Скрипты</h1> }))
vi.mock('@/pages/node-balancing', () => ({ NodeBalancingPage: () => <h1>Ноды</h1> }))
vi.mock('@/pages/feature-toggling', () => ({
  FeatureTogglingPage: () => <h1>Фичи</h1>,
}))
vi.mock('@/pages/cluster-management', () => ({
  ClusterManagementPage: () => <h1>Кластеры</h1>,
}))
vi.mock('@/pages/revise-replication', () => ({
  ReviseReplicationPage: () => <h1>Сверка</h1>,
}))
vi.mock('@/pages/geo-balancing', () => ({ GeoBalancingPage: () => <h1>Трафик</h1> }))

vi.mock('@/features/access-check', () => ({
  AccessGuard: ({ children }: { children: React.ReactNode }) => children,
}))

vi.mock('@/shared/ui/ErrorBoundary', () => ({
  ErrorBoundary: () => <h1>Ошибка сервиса</h1>,
}))

const loadUser = vi.hoisted(() => vi.fn())

vi.mock('@/entities/user', () => ({
  userQueryOptions: () => ({
    queryKey: ['user'],
    queryFn: loadUser,
    staleTime: Number.POSITIVE_INFINITY,
  }),
}))

vi.mock('@/features/access-check/lib', () => ({
  hasAllAuthorities: () => true,
  hasAuthorityWithSubstring: () => true,
}))

describe('application routes', () => {
  beforeEach(() => {
    loadUser.mockResolvedValue({ roles: [], permissions: [] })
  })

  it.each([
    ['/', 'Главная страница'],
    ['/forbidden', 'Доступ запрещён'],
    ['/error', 'Что-то пошло не так'],
    ['/unknown', 'Страница не найдена'],
    ['/close-trading-day', 'Закрытие дня'],
    ['/close-trading-day/close-od-history', 'Закрытие дня'],
    ['/start-process-group', 'Запуск процессов'],
    ['/start-process-group/process-group-history', 'Запуск процессов'],
    ['/index-management', 'Индексы'],
    ['/shard-info', 'Поиск шарда'],
    ['/script-runner', 'Скрипты'],
    ['/script-runner/requests', 'Скрипты'],
    ['/node-balancing', 'Ноды'],
    ['/node-balancing/history', 'Ноды'],
    ['/feature-toggling', 'Фичи'],
    ['/feature-toggling/statistics', 'Фичи'],
    ['/cluster-management', 'Кластеры'],
    ['/cluster-management/semaphore-management', 'Кластеры'],
    ['/revise-replication', 'Сверка'],
    ['/revise-replication/history', 'Сверка'],
    ['/geo-balancing', 'Трафик'],
  ])('renders the page assigned to %s', async (path, heading) => {
    const app = AppRoutesTestModel.open(path)

    expect(await app.expectPage(heading)).toBeVisible()
  })

  it.each(['/forbidden', '/error', '/not-found', '/unknown'])(
    'renders the system page %s inside ServiceLayout',
    async (path) => {
      AppRoutesTestModel.open(path)

      expect(await screen.findByRole('region', { name: 'Сервис' })).toBeVisible()
    },
  )

  it.each([
    ['/', 'roles'],
    ['/script-runner', 'permissions'],
  ])(
    'renders the application error page at %s when %s cannot be loaded',
    async (path, kind) => {
      vi.spyOn(console, 'error').mockImplementation(() => undefined)
      vi.spyOn(console, 'warn').mockImplementation(() => undefined)
      loadUser.mockRejectedValueOnce(new Error(`${kind} request failed`))

      AppRoutesTestModel.open(path)

      expect(await screen.findByRole('heading', { name: 'Что-то пошло не так' })).toBeVisible()
    },
  )
})
