import { createHashHistory, createRouter } from '@tanstack/react-router'

import { type RouterContext } from '@/app/routes/routerContext'
import { Spinner } from '@/shared/ui/Spinner'

import { RouteErrorComponent } from './RouteErrorComponent'
import { routeTree } from './routeTree'

export const createAppRouter = (
  queryClient: RouterContext['queryClient'],
  history = createHashHistory(),
) =>
  createRouter({
    routeTree,
    history,
    context: {
      queryClient,
    },
    defaultErrorComponent: RouteErrorComponent,
    defaultPendingComponent: Spinner,
    defaultPendingMs: 0,
    defaultPendingMinMs: 300,
  })

type AppRouter = ReturnType<typeof createAppRouter>

declare module '@tanstack/react-router' {
  interface Register {
    router: AppRouter
  }
}
