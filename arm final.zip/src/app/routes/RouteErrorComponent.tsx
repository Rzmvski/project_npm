import { type ErrorComponentProps } from '@tanstack/react-router'

import { ErrorPage } from '@/pages/error'

export const RouteErrorComponent = ({ reset }: ErrorComponentProps) => {
  return <ErrorPage onRetry={reset} />
}
