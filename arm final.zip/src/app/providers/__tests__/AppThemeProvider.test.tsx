import { render, screen } from '@testing-library/react'
import { describe, it, expect } from 'vitest'

import { AppThemeProvider } from '../AppThemeProvider'

describe('AppThemeProvider', () => {
  it('рендерит children', () => {
    render(
      <AppThemeProvider>
        <div data-testid='child'>Hello Theme</div>
      </AppThemeProvider>,
    )

    expect(screen.getByTestId('child')).toHaveTextContent('Hello Theme')
  })
})
