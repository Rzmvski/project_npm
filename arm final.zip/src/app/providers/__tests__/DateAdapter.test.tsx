import { render, screen } from '@testing-library/react'
import { describe, it, expect } from 'vitest'

import { DateAdapter } from '../DateAdapter'

describe('DateAdapter', () => {
  it('рендерит children', () => {
    render(
      <DateAdapter>
        <div data-testid='child'>Hello Date</div>
      </DateAdapter>,
    )

    expect(screen.getByTestId('child')).toHaveTextContent('Hello Date')
  })
})
