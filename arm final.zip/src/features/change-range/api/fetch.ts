import { type BucketRangeDto, type ShardDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { clusterManagementService } from '@/shared/api'

/** Ответ приходит SSE-потоком шард — собираем его целиком. */
export const fetchChangeSemaphore = async (
  shardId: number,
  changedBucketRanges: BucketRangeDto[],
) => {
  const shards: ShardDto[] = []
  for await (const shard of clusterManagementService.updateSemaphoresOfShardByIdStream(
    shardId,
    {
      changedBucketRanges,
    },
  )) {
    shards.push(shard)
  }
  return shards
}
