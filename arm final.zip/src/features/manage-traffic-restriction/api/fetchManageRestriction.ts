import { type TrafficRestriction } from '@/entities/traffic-restriction'
import { geoBalancingManagementService } from '@/shared/api'

// Все три операции объявлены в контракте как Mono с `text/event-stream`:
// итерируем ответ напрямую и даём потоку завершиться после единственного события.
export const fetchCreateRestriction = async (restriction: TrafficRestriction) => {
  const { createComment } = restriction
  let response: TrafficRestriction | undefined

  for await (const item of geoBalancingManagementService.createTrafficRestrictionStream({
    ...restriction,
    comment: createComment,
  })) {
    response = item as TrafficRestriction
  }
  return response
}

export const fetchUpdateRestriction = async (restriction: TrafficRestriction) => {
  const { id, createComment } = restriction
  if (!id) {
    throw Error('restriction id not provided')
  }

  let response: TrafficRestriction | undefined
  for await (const item of geoBalancingManagementService.updateTrafficRestrictionStream(id, {
    ...restriction,
    comment: createComment,
  })) {
    response = item as TrafficRestriction
  }
  return response
}

export const fetchRemoveRestriction = async (id: string): Promise<void> => {
  for await (const _ of geoBalancingManagementService.removeTrafficRestrictionByIdStream(id)) {
    // Mono завершается сам; тело ответа здесь не нужно.
  }
}
