import { useMemo } from 'react'
import { type Control, useWatch } from 'react-hook-form'

import { usePools } from '@/entities/connection-pool'
import { DbType, useMonitoring } from '@/entities/monitoring'
import { type ScriptSchemaType } from '@/features/run-script/model/schema'

import { getScriptRestrictionWarnings } from './getScriptRestrictionWarnings'

export const useScriptRestrictionWarnings = (control: Control<ScriptSchemaType>) => {
  const restrictionMode = useWatch({ control, name: 'restrictionMode' })
  const selectedNodeKeys = useWatch({ control, name: 'nodes' })
  const { data: pools } = usePools()
  const { monitoringEntities } = useMonitoring({ monitoringType: DbType.DB })

  return useMemo(() => {
    if (restrictionMode !== 'enabled') return []

    return getScriptRestrictionWarnings(selectedNodeKeys ?? [], pools, monitoringEntities)
  }, [monitoringEntities, pools, restrictionMode, selectedNodeKeys])
}
