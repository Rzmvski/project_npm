import { type CreateScriptApplicationRequestDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { scriptService } from '@/shared/api'

export const saveScriptApplication = (application: CreateScriptApplicationRequestDto) => {
  return scriptService.saveScriptApplication(application)
}
