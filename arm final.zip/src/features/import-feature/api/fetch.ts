import { type Feature, mapFeatureDatesToApi } from '@/entities/feature'
import { featureTogglingService } from '@/shared/api'

export const fetchLoadDump = (permissionId: string, dump: Feature[]) => {
  return featureTogglingService.loadFeatureDump({
    requestId: permissionId,
    dump: dump.map(mapFeatureDatesToApi),
  })
}
