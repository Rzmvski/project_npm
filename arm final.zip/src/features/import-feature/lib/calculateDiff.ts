import { type CustomPropertyDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { isSameDay } from 'date-fns'
import { isEqual, keyBy } from 'lodash-es'

import {
  type Feature,
  type FeatureActivation,
  FeatureActivationType,
  type FeatureConfiguration,
} from '@/entities/feature'
import { type FeatureChange, type FeatureImportDiff } from '@/features/import-feature/model'

const addChange = (
  changes: FeatureChange[],
  field: string,
  before: unknown,
  after: unknown,
) => {
  if (!isEqual(before, after)) {
    changes.push({
      field,
      before,
      after,
    })
  }
}

const addDateChange = (
  changes: FeatureChange[],
  field: string,
  before?: Date,
  after?: Date,
) => {
  if (!before || !after) {
    addChange(changes, field, before, after)
    return
  }

  if (!isSameDay(before, after)) {
    changes.push({
      field,
      before,
      after,
    })
  }
}

const addActivationChanges = (
  changes: FeatureChange[],
  before: FeatureActivation,
  after: FeatureActivation,
) => {
  if (before.type !== after.type) {
    addChange(changes, 'strategy', before.type, after.type)

    if (
      before.type === FeatureActivationType.Manual &&
      after.type === FeatureActivationType.OdRelease
    ) {
      addDateChange(changes, 'releaseDate', undefined, after.releaseDate)
    }

    if (
      before.type === FeatureActivationType.OdRelease &&
      after.type === FeatureActivationType.Manual
    ) {
      addChange(changes, 'enabled', undefined, after.enabled)
    }
  }

  if (
    before.type === FeatureActivationType.Manual &&
    after.type === FeatureActivationType.Manual
  ) {
    addChange(changes, 'enabled', before.enabled, after.enabled)

    return
  }

  if (
    before.type === FeatureActivationType.OdRelease &&
    after.type === FeatureActivationType.OdRelease
  ) {
    addDateChange(changes, 'releaseDate', before.releaseDate, after.releaseDate)
  }
}

const addCustomPropertiesChanges = (
  changes: FeatureChange[],
  current: CustomPropertyDto[] = [],
  imported: CustomPropertyDto[] = [],
) => {
  const currentProperties = keyBy(current, 'name')

  const importedProperties = keyBy(imported, 'name')

  const names = new Set([...Object.keys(currentProperties), ...Object.keys(importedProperties)])

  names.forEach((name) => {
    const before = currentProperties[name]
    const after = importedProperties[name]

    addChange(changes, `customProperties.${name}.type`, before?.type, after?.type)
    addChange(changes, `customProperties.${name}.value`, before?.value, after?.value)
  })
}

export const getFeatureChanges = (
  current: FeatureConfiguration,
  imported: FeatureConfiguration,
): FeatureChange[] => {
  const changes: FeatureChange[] = []

  addChange(changes, 'description', current.description, imported.description)

  addActivationChanges(changes, current.activation, imported.activation)
  addCustomPropertiesChanges(changes, current.customProperties, imported.customProperties)

  return changes
}

export const calculateDiff = (current: Feature[], imported: Feature[]): FeatureImportDiff[] => {
  const currentByUid = new Map(current.map((feature) => [feature.uid, feature]))

  return imported.map((feature): FeatureImportDiff => {
    const existing = currentByUid.get(feature.uid)

    if (!existing) {
      return {
        type: 'create',
        uid: feature.uid,
        feature,
      }
    }

    const changes = getFeatureChanges(existing.config, feature.config)

    if (!changes.length) {
      return {
        type: 'skip',
        uid: feature.uid,
        feature,
      }
    }

    return {
      type: 'update',
      uid: feature.uid,
      current: existing,
      imported: feature,
      changes,
    }
  })
}
