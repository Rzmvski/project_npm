import { useMutation, useQueryClient } from '@tanstack/react-query'
import { notification } from '@v-uik/base'

import { type Feature } from '@/entities/feature'
import { featureApplicationQueryKey } from '@/entities/feature-application'
import { fetchLoadDump } from '@/features/import-feature/api'

type UseLoadDumpMutationOptions = {
  permissionId: string
  dump: Feature[]
}

export const useLoadDumpMutation = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: ({ permissionId, dump }: UseLoadDumpMutationOptions) =>
      fetchLoadDump(permissionId, dump),
    onSuccess: async ({ skipped, created, updated }) => {
      notification.success(
        `
        Импорт завершен. 
        Создано заявок на добавление фичей: ${created}, 
        на обновление фичей: ${updated}. 
        
        Пропущено: ${skipped}
        `,
        {
          direction: 'vertical',
        },
      )
      await queryClient.invalidateQueries({
        queryKey: featureApplicationQueryKey,
      })
    },
  })
}
