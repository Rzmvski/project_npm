import {
  createUseStyles,
  generateId,
  modal,
  ModalBody,
  ModalHeader,
  type ShowOptions,
} from '@v-uik/base'
import React from 'react'

import { BeansExplorer } from '@/features/beans-introspection'

const useStyles = createUseStyles(() => ({
  modalContent: {
    width: '80vw',
    minWidth: '80vw',
    height: '90vh',
    maxWidth: 'calc(100vw - 32px)',
    maxHeight: 'calc(100vh - 32px)',
  },
}))

export const useBeansExplorer = () => {
  const modalId = generateId()
  const { modalContent } = useStyles()

  const open = () => {
    modal.show(modalId, {
      classes: {
        modalContent,
      },
      content: (
        <React.Fragment>
          <ModalHeader>{'Доступные бины среды выполнения скрипта'}</ModalHeader>
          <ModalBody>
            <BeansExplorer />
          </ModalBody>
        </React.Fragment>
      ),
    } as ShowOptions)
  }

  return {
    open,
  }
}
