import { type Feature, mapFeatureDatesToApi } from '@/entities/feature'
import { featureTogglingService } from '@/shared/api'

/**
 * Запрос для обновления хотконфигов
 * Method: PATCH
 * URL: /invoke/support-admin/feature-toggling-service/features/hotconfigs
 * @param features - список измененных фич
 */
export function fetchUpdateHotConfigs(features: Feature[]): Promise<void> {
  return featureTogglingService.editHotConfigFeatures(features.map(mapFeatureDatesToApi))
}
