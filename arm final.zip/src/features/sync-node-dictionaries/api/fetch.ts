import { type MetadataDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { metadataManagementService } from '@/shared/api'

/**
 * Отправка запроса на обновление метаданных схем базы данных и справочников
 * Method: PUT
 * URL: /invoke/support-admin/cluster-management-service/nodes/{nodeKey}/metadatas
 *
 * Ответ приходит одним SSE-событием: эндпоинт объявлен в контракте только как
 * `text/event-stream`.
 */
export const fetchSchemaMetadataRefresh = async (
  nodeKey: string,
): Promise<MetadataDto | undefined> => {
  let response: MetadataDto | undefined
  for await (const item of metadataManagementService.refreshMetadataOnNodeStream(nodeKey)) {
    response = item
  }
  return response
}
