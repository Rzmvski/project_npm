import { ClusterStateDto, type ShardDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { useQuery } from '@tanstack/react-query'
import { groupBy } from 'lodash-es'

import { convertRange, type Rangeble } from '@/entities/range'
import { type Semaphore, streamSemaphores } from '@/entities/semaphore'
import { clusterManagementService, createPollingQueryPolicy } from '@/shared/api'

// Начиная с platform-api 2.1 semaphoreInfo() отдаёт только данные семафорного
// кластера (без диапазонов бакетов), а диапазоны переехали в bucketRanges
// шард (getShards()). Собираем их вместе по ключу семафорного кластера:
// BucketRangeDto.semaphoreClusterKey === Semaphore.clusterKey.
const convert = (semaphores: Semaphore[], shards: ShardDto[]): Rangeble<Semaphore>[] => {
  const bucketRanges = shards.flatMap((shard) => shard.bucketRanges ?? [])
  const rangesByCluster = groupBy(bucketRanges, (range) => range.semaphoreClusterKey)

  return semaphores.map((semaphore) => ({
    ...semaphore,
    ranges: (rangesByCluster[semaphore.clusterKey] ?? []).map(convertRange),
  }))
}

export const useSemaphoreDetails = () => {
  const query = useQuery<Rangeble<Semaphore>[], unknown>({
    queryKey: ['semaphores-details'],
    queryFn: async ({ signal }) => {
      const semaphores: Semaphore[] = []
      const shards: ShardDto[] = []

      await Promise.all([
        (async () => {
          for await (const semaphore of streamSemaphores(signal)) {
            semaphores.push(semaphore)
          }
        })(),
        (async () => {
          for await (const shard of clusterManagementService.getShardsStream({ signal })) {
            shards.push(shard)
          }
        })(),
      ])

      return convert(semaphores, shards)
    },
    ...createPollingQueryPolicy({
      stopPredicate: (data: Rangeble<Semaphore>[]) =>
        data.every((s) => s.status !== ClusterStateDto.Creating),
    }),
  })

  return { ...query, data: query.data ?? [] }
}
