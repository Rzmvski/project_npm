import { type ClusterStateDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { type ActionFormValues } from '@/features/change-semaphore-state/model'
import { clusterManagementService } from '@/shared/api'

/**
 * Операция объявлена в контракте только как `text/event-stream`, тела у ответа
 * нет. Поток всё равно нужно вычитать — иначе запрос не уйдёт: генератор
 * ничего не делает, пока его не начали итерировать.
 */
export const fetchChangeSemaphoreState = async (
  clusterKey: string,
  status: ClusterStateDto,
  additionalOptions?: ActionFormValues,
): Promise<void> => {
  for await (const _ of clusterManagementService.changeClusterStateStream(clusterKey, {
    ...additionalOptions,
    status,
  })) {
    // Mono завершается сам; тело ответа здесь не нужно.
  }
}
