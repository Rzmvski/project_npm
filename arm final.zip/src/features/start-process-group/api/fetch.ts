import { type ProcessDtoDto, toLocalDate } from '@sber-pprb-tkp/tcpf-support-admin-api'

import { processManagementService } from '@/shared/api'

import { type StartProcessOutputValues } from '../model/schema'

export const fetchStartProcessGroup = ({
  od,
  group,
}: StartProcessOutputValues): Promise<ProcessDtoDto> => {
  const { id } = group
  return processManagementService.startProcess(Number(id), toLocalDate(od))
}
