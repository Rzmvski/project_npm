import { type PoolStateDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { connectionPoolManagementService } from '@/shared/api'

/**
 * Запрос на изменение пула коннектов
 * Method: PUT
 * URL: /invoke/support-admin/cluster-management-service/nodes/{nodeKey}/pools
 *
 * Эндпоинт отвечает `text/event-stream` без тела — поток нужно вычитать,
 * иначе запрос не уйдёт.
 */
export const fetchChangePoolState = async (
  nodeKey: string,
  poolState: PoolStateDto,
): Promise<void> => {
  for await (const _ of connectionPoolManagementService.changePoolStateStream(
    nodeKey,
    poolState,
  )) {
    // Mono завершается сам; тело ответа здесь не нужно.
  }
}
