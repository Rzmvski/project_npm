import {
  type ApplicationStatusDto,
  type ScriptApplicationDto,
} from '@sber-pprb-tkp/tcpf-platform-admin-api'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { notification } from '@v-uik/base'

import { fetchResolveScriptApplication } from '@/features/manage-script-requests/api'

type ChangeRequestStatusParams = {
  application: ScriptApplicationDto
  targetStatus: ApplicationStatusDto
}

export const useChangeRequestStatus = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: ({ application, targetStatus }: ChangeRequestStatusParams) => {
      const { reasonId } = application
      return fetchResolveScriptApplication(reasonId, { status: targetStatus })
    },
    onSuccess: (result) => {
      queryClient.setQueryData<ScriptApplicationDto[]>(['scriptRequests'], (requests = []) =>
        requests.map((request) => (request.reasonId === result.reasonId ? result : request)),
      )
      void queryClient.invalidateQueries({ queryKey: ['scriptRequests'] })
      notification.success('Запрос на изменение статуса успешно отправлен')
    },
  })
}
