import { type NodeType } from '@/entities/range'

export type { NodeType }

export interface Loadable {
  nodeKey: string
  type: NodeType
  load: number
}

export type ShardBoundaryValues = {
  boundary: number[]
  nodes: Loadable[]
}
