import { useMutation, useQueryClient } from '@tanstack/react-query'
import { notification } from '@v-uik/base'

import { nodesQueryKey } from '@/entities/node'
import { availableShardsQueryKey } from '@/entities/routing-shard'
import { fetchUpdateBucketRatio } from '@/features/change-shard-boundary/api'

export const useChangeNodeBoundaryMutation = (shardId: number) => {
  const client = useQueryClient()

  return useMutation({
    mutationFn: (bucketBoundary: number[]) => fetchUpdateBucketRatio(shardId, bucketBoundary),
    onSuccess: () => {
      notification.success(`Нагрузка на шарде ${shardId} успешно изменена`, {
        direction: 'vertical',
      })

      return Promise.all([
        client.invalidateQueries({ queryKey: nodesQueryKey }),
        client.invalidateQueries({ queryKey: availableShardsQueryKey }),
      ])
    },
    onError: () =>
      notification.error(`При изменении нагрузки на шарде ${shardId} возникла ошибка`, {
        direction: 'vertical',
      }),
  })
}
