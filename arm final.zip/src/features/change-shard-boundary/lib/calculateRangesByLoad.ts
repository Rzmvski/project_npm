import { MAX_BUCKET_VALUE, type RangeBounds } from '@/entities/range'
import { type Loadable } from '@/features/change-shard-boundary/model'

export const calculateRangesByLoad = (nodes: Loadable[]): Record<string, RangeBounds[]> => {
  let accumulatedLoad = 0
  let start = 0

  return Object.fromEntries(
    nodes.map(({ nodeKey, load }) => {
      accumulatedLoad += Math.max(0, Number(load) || 0)
      const endExclusive = Math.min(
        MAX_BUCKET_VALUE,
        Math.max(start, Math.round((accumulatedLoad / 100) * MAX_BUCKET_VALUE)),
      )
      const ranges = endExclusive > start ? [{ start, end: endExclusive - 1 }] : []
      start = endExclusive

      return [nodeKey, ranges]
    }),
  )
}
