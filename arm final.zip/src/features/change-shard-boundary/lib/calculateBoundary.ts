import { MAX_BUCKET_VALUE } from '@/entities/range'
import { type Loadable } from '@/features/change-shard-boundary/model'

export const calculateBoundary = (nodes: Array<Loadable>): number[] => {
  return nodes
    .reduce(
      ({ boundaries, accumulated }, { load }) => {
        accumulated += load / 100
        boundaries.push(Math.round(accumulated * MAX_BUCKET_VALUE))
        return { boundaries, accumulated }
      },
      { boundaries: [] as number[], accumulated: 0 },
    )
    .boundaries.slice(0, -1)
}
