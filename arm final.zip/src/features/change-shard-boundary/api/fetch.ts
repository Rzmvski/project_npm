import { type ShardDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { clusterManagementService } from '@/shared/api'

/** Ответ приходит SSE-потоком шард — собираем его целиком. */
export const fetchUpdateBucketRatio = async (shardId: number, bucketBoundary: number[]) => {
  const shards: ShardDto[] = []
  for await (const shard of clusterManagementService.updateNodesOfShardByIdStream([shardId], {
    bucketBoundary,
  })) {
    shards.push(shard)
  }
  return shards
}
