import { type PoolStateDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'

import { type Range } from '@/entities/range'
import { type NodeType } from '@/features/change-shard-boundary'

export interface Shard {
  id: number
  nodes: Node[]
  disabled: boolean
}

export interface Node {
  nodeKey: string
  type: NodeType
  load: number
  connectionState: PoolStateDto
  ranges: Range[]
  frozen: boolean
  dcKey?: string
}
