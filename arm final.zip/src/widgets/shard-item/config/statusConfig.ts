import { type UnderlayStatusType } from '@v-uik/underlay/dist/esm/Underlay'
import {
  AlertTriangleIcon,
  CheckCircle2Icon,
  CircleXIcon,
  InfoIcon,
  LockIcon,
} from 'lucide-react'
import { type ComponentType } from 'react'

import { ShardState } from '@/entities/shard-replication'
import {
  RetryReplicationButton,
  StartReplicationButton,
  UndoReplicationButton,
} from '@/features/run-shard-replication'

type Config = {
  Icon: ComponentType
  text: string
  underlayStatus: UnderlayStatusType
  Action?: ComponentType<{ shardId: number }>
}

export const statusConfig: Record<ShardState, Config> = {
  [ShardState.SERVICE_MODE_REQUIRED]: {
    Icon: LockIcon,
    text: 'Для изменения нагрузки необходимо включить сервисный режим',
    underlayStatus: 'neutral',
  },
  [ShardState.SYNC_REQUIRED]: {
    Icon: AlertTriangleIcon,
    text: 'Перед изменением нагрузки требуется выравнивание',
    underlayStatus: 'warning',
    Action: StartReplicationButton,
  },
  [ShardState.SYNCING]: {
    Icon: InfoIcon,
    text: 'Выполняется выравнивание шарда',
    underlayStatus: 'info',
  },
  [ShardState.READY]: {
    Icon: CheckCircle2Icon,
    text: 'Шард выровнен и готов к изменению нагрузки',
    underlayStatus: 'success',
    Action: UndoReplicationButton,
  },
  [ShardState.FAILED]: {
    Icon: CircleXIcon,
    text: 'Ошибка при выравнивании шарда',
    underlayStatus: 'error',
    Action: RetryReplicationButton,
  },
}
