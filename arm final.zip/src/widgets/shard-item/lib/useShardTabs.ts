import { type ReactNode, useMemo, useState } from 'react'

type SettingType = 'load' | 'ranges'

type SettingItem = {
  id: SettingType
  title: string
  content: ReactNode
  disabled?: boolean
}

export const useShardTabs = (settings: SettingItem[]) => {
  const [activeTab, setActiveTab] = useState<SettingType>('load')

  const activeTabItem = useMemo(() => {
    const tab = settings.find(({ id }) => id == activeTab)

    if (!tab) {
      throw Error(`tab ${activeTab} not found`)
    }

    return tab
  }, [activeTab, settings])

  const { content } = activeTabItem

  return {
    tabs: settings,
    activeTab,
    activeTabContent: content,
    setActiveTab,
  }
}
