import { LinearProgress, Text, Underlay } from '@v-uik/base'
import React, { type FC } from 'react'

import { useActiveProcesses, useProcessColumns } from '@/entities/process'
import { ProcessGroupDictionary } from '@/entities/process-group'
import { CloseOdForm, fetchCloseTradingDay } from '@/features/close-od'
import { formatDate, useBeforeUnload } from '@/shared/lib'
import { Table } from '@/shared/ui/Table'

import styles from './CloseOd.module.scss'

const NOTHING = '–'

export const CloseOd: FC = () => {
  const { setActiveProcessId, activeProcess, hasActiveProcess } =
    useActiveProcesses(ProcessGroupDictionary.EOD_AND_OOD_BY_CONTRACT)

  const columns = useProcessColumns()

  useBeforeUnload({
    isPending: hasActiveProcess,
  })

  const onSubmitHandler = (od: Date) => {
    fetchCloseTradingDay(od).then(({ idOfStartedProcess, errorMessage }) => {
      if (!idOfStartedProcess || errorMessage) {
        throw Error(errorMessage)
      }
      setActiveProcessId(idOfStartedProcess)
    })
  }

  const processData = activeProcess?.data

  return (
    <div className={styles.container}>
      <Underlay>
        <CloseOdForm disabled={hasActiveProcess} onSubmit={onSubmitHandler} />
      </Underlay>
      {processData && (
        <div className={styles.tableSection}>
          <div className={styles.tableContent}>
            <Table
              data={processData.groupOfProcesses.fields ?? []}
              columns={columns}
              noDataText={'Нет данных по ЗОДу'}
            />
            {hasActiveProcess && <LinearProgress />}
          </div>
          <div className={styles.footer}>
            <span className={styles.footerLabel}>{'Последнее обновление:'}</span>
            <Text kind={'codeSm'}>
              {formatDate(processData.lastUpdate ?? null, 'HH:mm:ss') || NOTHING}
            </Text>
          </div>
        </div>
      )}
    </div>
  )
}
