import { Link, useLocation } from '@tanstack/react-router'
import classNames from 'classnames'
import React, { type FC, useLayoutEffect, useRef } from 'react'

import { AccessGuard } from '@/features/access-check'
import { useServices } from '@/features/service-config'

import styles from './Sidebar.module.scss'

export const Sidebar: FC = () => {
  const { services } = useServices()
  const { pathname } = useLocation()
  const menuRef = useRef<HTMLElement>(null)

  useLayoutEffect(() => {
    const activeLink = menuRef.current?.querySelector('[aria-current="page"]')
    activeLink?.scrollIntoView({ block: 'nearest', inline: 'nearest' })
  }, [pathname])

  return (
    <nav ref={menuRef} className={styles.adminProcessesMenu} aria-label={'Сервисы'}>
      <div className={styles.header}>
        <span className={styles.title}>Сервисы</span>
      </div>

      <div className={styles.links}>
        {services.map(({ route, permissions, title, Icon }) => (
          <AccessGuard key={route} requiredPermissions={permissions}>
            <Link
              to={route}
              title={title}
              activeOptions={{ exact: false }}
              inactiveProps={{ className: styles.link }}
              activeProps={{ className: classNames(styles.link, styles.linkActive) }}
            >
              <span className={styles.icon} aria-hidden={'true'}>
                <Icon />
              </span>
              <span className={styles.linkText}>{title}</span>
            </Link>
          </AccessGuard>
        ))}
      </div>
    </nav>
  )
}
