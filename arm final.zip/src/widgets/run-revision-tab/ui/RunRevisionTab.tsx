import { type RevisionInfoDto } from '@sber-pprb-tkp/tcpf-platform-admin-api'
import {
  Button,
  createUseStyles,
  generateId,
  LoadingButton,
  modal,
  ModalBody,
  ModalFooter,
  ModalHeader,
  type ShowOptions,
} from '@v-uik/base'
import { Play, PlusIcon } from 'lucide-react'
import React, { type FC } from 'react'

import {
  RevisionActions,
  RevisionTable,
  showRevisionDetails,
} from '@/entities/revision'
import {
  RevisionForm,
  RevisionRowActions,
  useRunRevision,
  useRevisionRequestForm,
} from '@/features/manage-revision'

import styles from './RunRevisionTab.module.scss'

const revisionsQueryKey = ['revisions']

const useStyles = createUseStyles({
  revisionModalContent: {
    height: '70vh',
  },
})

export const RunRevisionTab: FC = () => {
  const classes = useStyles()
  const {
    control,
    handleSubmit,
    formState: { isValid, isSubmitting },
    reset,
  } = useRevisionRequestForm()
  const { mutate, isPending: isRevisionPending } = useRunRevision({
    queryKey: revisionsQueryKey,
  })

  const showDetails = ({ shardId, id, tablesTotal }: RevisionInfoDto) => {
    showRevisionDetails({
      revisionId: id,
      queryKey: ['revisionDetails', shardId, id],
      shardId,
      tablesTotal,
      actions: (details) => (
        <RevisionRowActions
          {...details}
          shardId={shardId}
          id={id}
          inlineTypes={[RevisionActions.RUN, RevisionActions.RECHECK]}
          dropdownTypes={[
            RevisionActions.ALIGN_LEFT,
            RevisionActions.ALIGN_RIGHT,
            RevisionActions.STOP,
            RevisionActions.DOWNLOAD,
          ]}
        />
      ),
    })
  }

  const handleRevisionActions = ({
    id,
    shardId,
    status,
    updated,
    ...rest
  }: RevisionInfoDto) => (
    <RevisionRowActions
      shardId={shardId}
      id={id}
      status={status}
      updated={updated}
      detailsAction={() =>
        showDetails({ shardId, id, updated, status, ...rest })
      }
      {...rest}
      inlineTypes={[RevisionActions.RUN, RevisionActions.RECHECK]}
      dropdownTypes={[
        RevisionActions.DETAILS,
        RevisionActions.ALIGN_LEFT,
        RevisionActions.ALIGN_RIGHT,
        RevisionActions.STOP,
        RevisionActions.DOWNLOAD,
      ]}
    />
  )

  const handleCreateRevisionClick = () => {
    const id = generateId()

    const onSubmitHandler = handleSubmit((data) => {
      mutate(data)
      reset()
      modal.close(id)
    })

    modal.show(id, {
      width: '50vw',
      content: (
        <>
          <ModalHeader>{'Запуск новой сверки'}</ModalHeader>
          <ModalBody className={classes.revisionModalContent}>
            <RevisionForm control={control} />
          </ModalBody>
          <ModalFooter>
            <LoadingButton
              isLoading={isSubmitting || isRevisionPending}
              kind={'outlined'}
              prefixIcon={<Play />}
              onClick={onSubmitHandler}
              disabled={isSubmitting && !isValid}
            >
              {'Выполнить'}
            </LoadingButton>
          </ModalFooter>
        </>
      ),
    } as ShowOptions)
  }

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <Button
          size={'sm'}
          kind={'outlined'}
          prefixIcon={<PlusIcon />}
          onClick={handleCreateRevisionClick}
        >
          {'Выполнить сверку'}
        </Button>
      </div>
      <div className={styles.tableWrapper}>
        <RevisionTable
          queryKey={revisionsQueryKey}
          revisionActions={handleRevisionActions}
        />
      </div>
    </div>
  )
}
