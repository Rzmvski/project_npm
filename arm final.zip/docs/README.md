# Документация

Здесь находятся только поддерживаемые руководства по текущему TCPF Support Admin UI. Исторические отчёты, миграционные заметки и копии внешних контрактов в `docs` не хранятся.

| Документ                                 | Когда читать                          |
| ---------------------------------------- | ------------------------------------- |
| [`../README.md`](../README.md)           | Запуск и обзор продукта               |
| [`architecture.md`](architecture.md)     | Слои, маршруты, состояние и API       |
| [`sdk-contract.md`](sdk-contract.md)     | Использование DTO, SDK и SSE          |
| [`mock-server.md`](mock-server.md)       | Express mock API, fixtures и отладка  |
| [`access-control.md`](access-control.md) | Роли, permissions и guards            |
| [`design-system.md`](design-system.md)   | VUIK, токены, SCSS и UI-состояния     |
| [`forms.md`](forms.md)                   | React Hook Form и Zod                 |
| [`table-plugins.md`](table-plugins.md)   | Расширение общей таблицы плагинами    |
| [`testing.md`](testing.md)               | Подход к тестам                       |
| [`code-quality.md`](code-quality.md)     | Инструменты и обязательные соглашения |
| [`validation.md`](validation.md)         | Проверка изменений перед передачей    |

Инструкции для GigaCode находятся в корневом [`GIGACODE.md`](../GIGACODE.md), проектные skills — в `.gigacode/skills`, а субагенты — в `.gigacode/agents`.

## Источники истины

- Frontend-контракты: public exports зафиксированных версий `@sber-pprb-tkp/tcpf-*-admin-api`; локальные `file:`-ссылки временны.
- Версии зависимостей и команды: корневой `package.json`.
- Маршруты: `src/shared/config/routes.ts` и `src/app/routes/routeTree.tsx`.
- Права: `src/shared/model/permissionType.ts` и `src/entities/service/model/registry.ts`.
- Тема: `src/shared/styles/tokens.scss` и `src/app/providers/AppThemeProvider.tsx`.

Документация не должна утверждать наличие скрипта, файла или проверки, которых нет в репозитории.
