# Testing guide

Проект использует Vitest, React Testing Library, `user-event` и jsdom. Тестовые
файлы выполняются в изолированных процессах, чтобы моки не протекали между
файлами, а память освобождалась после каждой группы.

| Уровень      | Назначение                             |
| ------------ | -------------------------------------- |
| Unit         | schema, selector, formatter, mapper    |
| Component    | наблюдаемое UI-поведение               |
| Query        | cache key, polling, SSE и invalidation |
| Route/access | guard, redirect, lazy page             |
| API contract | SDK boundary, request и response shape |

Тест проверяет результат для пользователя, не VUIK markup или CSS class. Interaction выполняется через `user-event`; async rendering — `findBy*`/`waitFor`, без sleep. Мокировать следует API boundary, сохраняя реальными форму, query и store настолько, насколько это разумно.

Тесты сгруппированы в `__tests__` рядом с проверяемым модулем: например,
`ui/Component.tsx` и `ui/__tests__/Component.test.tsx`. Так тест сохраняет связь
с FSD-slice, но не перемешивается с production-файлами. Предметный test model для
многошагового UI лежит в том же `__tests__` и называется
`Component.test-model.tsx`. Он предоставляет пользовательские действия
(`submitRequest`, `selectNode`, `openRanges`), а не оборачивает все DOM API подряд.
Простым компонентам без сценария test model он не нужен.

Coverage собирается по всем production-файлам, в том числе по тем, которые не
импортированы тестами. Обязательные пороги: 80% lines/functions/statements и
60% branches. Полный coverage-прогон должен завершаться ошибкой, если хотя бы
один из этих показателей ниже порога.

```bash
npm test
npx vitest run path/to/file.test.tsx
npx vitest run -t "case name"
npm run test:coverage
```

Express mock проверяется в `mock-server/__tests__/index.test.js`, а ключевые пользовательские сценарии дополнительно проходят через запущенное приложение. Эти проверки входят в `npm test` вместе с unit/component-тестами фронтенда.
