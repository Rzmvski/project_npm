# Code quality guide

## Команды

| Команда                     | Что проверяет                               |
| --------------------------- | ------------------------------------------- |
| `npm run format:check`      | Форматирование исходников и docs            |
| `npm run lint:eslint`       | TypeScript, imports, hooks и FSD boundaries |
| `npm run lint:styles`       | SCSS через Stylelint 16                     |
| `npm run lint`              | ESLint + Stylelint + Prettier               |
| `npm run lint:architecture` | FSD через Steiger                           |
| `npm run typecheck`         | `tsc -b`                                    |
| `npm test`                  | Vitest run, не более двух workers           |
| `npm run test:coverage`     | Vitest с coverage                           |
| `npm run build`             | Production Vite bundle                      |
| `npm run check`             | Полная последовательность проверок          |

`build` не заменяет typecheck. Если полный baseline не зелёный, в отчёте отдельно указываются существующие ошибки и новые regressions с командами, которыми они воспроизведены.

## Обязательные правила

- Не подавлять TypeScript/ESLint без локального объяснения; предпочитать `@ts-expect-error` с причиной.
- Не оставлять `console.log`, тестовые данные и временные feature flags в production-коде.
- Не импортировать `src/*` из npm-пакетов и внутренности чужого slice.
- Hooks вызываются только в компонентах или custom hooks, не в произвольных table callbacks.
- Async effect должен иметь cleanup/abort, если результат может прийти после unmount.
- Ошибка API не маскируется успешным fallback без проверки причины.
- Форматирование большого legacy-массива выполняется отдельным изменением.

## Git hooks

- `pre-commit` запускает `npm run lint:staged`.
- `commit-msg` запускает Commitlint с conventional config.
- `pre-push` намеренно отсутствует: полный Vitest, typecheck, build и архитектурный анализ слишком медленные или нестабильные для каждого push.

Hooks должны давать обратную связь за секунды и проверять только локально изменяемый контекст. Vitest и production build выполняются в Docker/CI; focused-тесты разработчик запускает перед commit по таблице из `validation.md`. Полный `npm run validate` используется для cross-cutting изменений и как целевой quality gate после устранения известных baseline-ошибок.

`prepare` устанавливает Husky только внутри git-репозитория. При изменении hooks одновременно обновляются `code-quality.md` и `validation.md`.
