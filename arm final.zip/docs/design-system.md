# Design system guide

## Основа

VUIK (`@v-uik/base`) — источник стандартных controls и accessibility. `AppThemeProvider` связывает VUIK с CSS variables из `src/shared/styles/tokens.scss`. Общие Sass variables/mixins находятся в `_variables.scss` и `_mixins.scss`.

`shared/ui` допустим для поведения, которого нет у примитива VUIK, или устойчивой композиции, используемой несколькими slices. Wrapper, который только переименовывает props, не добавляется.

Перед созданием button, input, select, checkbox, tag, progress, modal, notification, tabs или date control сначала проверяются exports/types `@v-uik/base` и существующее использование. При миграции legacy UI сохраняются пользовательское поведение и accessibility name; локальный CSS, имитирующий состояния VUIK, удаляется.

## CSS

- Компонент использует `ComponentName.module.scss`.
- Сначала искать semantic variable в `tokens.scss`/`_variables.scss`.
- Новый повторяемый цвет, spacing или radius добавляется как token.
- Class names — camelCase; глобальные selectors ограничены reset, font и интеграцией внешней библиотеки.
- `!important` требует документированной причины.
- Legacy Less не расширяется; при изменении экрана стили постепенно переводятся в SCSS Modules.

## UI-состояния

Каждый data-driven экран проектируется для loading, empty, error, populated и mutation-pending состояний. Icon-only action имеет доступное имя. Modal сохраняет форму при серверной ошибке и блокирует повторный submit.

Для визуального изменения проверяются обычный laptop width, узкая область рядом с sidebar, длинные русские строки, ошибки и таблица с прокруткой. Миграция UI-библиотеки не смешивается с изменением бизнес-правил без необходимости.
