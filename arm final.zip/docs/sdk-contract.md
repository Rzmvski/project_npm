# SDK contract guide

## Контракты

Фронтенд работает с двумя сгенерированными библиотеками:

| Префикс     | Библиотека                               | Dev backend      |
| ----------- | ---------------------------------------- | ---------------- |
| `/tkp`      | `@sber-pprb-tkp/tcpf-support-admin-api`  | `127.0.0.1:8092` |
| `/platform` | `@sber-pprb-tkp/tcpf-platform-admin-api` | `127.0.0.1:8091` |

Пакеты должны устанавливаться как обычные semver-зависимости из внутреннего npm registry. Текущие `file:`-ссылки на `/Users/rzmvski/Downloads/@sber-pprb-tkp` временны и не являются частью архитектуры приложения. Зафиксированная в корневых `package.json` и lockfile версия и её public exports — источник истины для DTO, enum, сервисов, `LocalDate` и SSE. В development префикс удаляется proxy в `vite.config.ts`; в production `platformRequestConfiguration` дополнительно использует выбранный контур.

## Правила изменения

1. Проверить public exports зафиксированной версии библиотеки и существующее использование аналогичного сервиса. Для временной `file:`-зависимости можно читать её `package.json` и `dist/index.d.ts` в `Downloads`.
2. Если контракт библиотеки изменён, установить новую опубликованную semver-версию и обновить lockfile. Локальную сборку использовать только до публикации.
3. Вызывать SDK только из `api`-сегмента сущности/фичи; конфигурацию брать из `shared/config`.
4. Не импортировать `dist/*`, `src/*`, generated-файлы по прямому пути или содержимое `node_modules`: production-код импортирует типы и сервисы только из корня пакета.
5. Обновить Express mock и тесты в соответствии с фактическими сигнатурами библиотеки.
6. Проверить сериализацию query/body, обработку response/error и затронутый пользовательский сценарий через запущенный UI.

Для календарных дат используй экспортируемые библиотекой `LocalDate`, `localDate`, `toLocalDate` и `fromLocalDate`. Собственные адаптеры для старой генерации `Date` не добавляются.

Если требуемого метода, DTO или enum нет в public exports, frontend не угадывает контракт. Это blocker для обновления библиотеки `@sber-pprb-tkp/*`.

## SSE

Операции, помеченные в контракте `x-sse: true`, генерируются в классы `*ApiSse` (`ClusterManagementServiceApiSse`, `ConnectionPoolManagementServiceApiSse`, `GeoBalancingManagementServiceApiSse`, `MonitoringManagementServiceApiSse`, `MetadataManagementServiceApiSse`). Класс `*ApiSse` наследует обычные методы без изменений и добавляет `<operationId>Stream()` — `AsyncGenerator` поверх `fetch` с заголовком `Accept: text/event-stream`. Путь у потока тот же, что у обычной операции.

Правила:

1. SSE подключается только к тем сервисам, у которых в библиотеке есть класс `*ApiSse` с методами `*Stream()`. `EventSource` и ручная сборка URL не используются.
2. Query-операции с Flux идут через `useSseQuery`. Хук кладёт каждый объект в react-query кэш, а после последнего объекта конечный Flux естественно завершает query. Отдельные `collectSse`/`firstSse` не используются.
3. Тот же `useSseQuery` держит бесконечный DB-monitoring Sink и обновляет сущности по `id`. Mono-операции в mutation API итерируются напрямую и завершаются после одного объекта.
4. Middleware в `shared/config/http.ts` отменяет клон тела для `text/event-stream`: иначе непрочитанная ветка `tee` буферизуется всё время жизни потока.

## Ошибки

Middleware в `src/shared/config/http.ts` превращает неуспешные ответы в `HttpError` и показывает VUIK notification. Mock возвращает единый JSON-формат ошибки: `timestamp`, `status`, `message`, `path`.

Fallback между новыми и deprecated методами допустим только для ошибок отсутствующего endpoint (`404`/`405`), а не для сетевых ошибок или `5xx`: иначе реальный сбой маскируется переключением API.
