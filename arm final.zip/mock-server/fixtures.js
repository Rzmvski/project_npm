const NOW = '2026-08-12T09:30:00.000Z'

export const BALANCING_SHARD_COUNT = 20
export const TRANSFER_STATUS_COUNT = BALANCING_SHARD_COUNT
export const ACTIVE_TRANSFER_PROCESS_COUNT = 5
export const ACTIVE_CREATE_TASK_SESSION_ID = 7002
export const ACTIVE_TRANSFER_SESSION_ID = 7003
export const TRANSFER_PROCESS_DURATION_MS = 2 * 60 * 1000
// Стартовые процессы завершаются быстро, чтобы полный цикл был виден в UI.
const INITIAL_ACTIVE_PROCESS_DURATION_MS = 30 * 1000

export const enabledServices = [
  'closeTradingDay',
  'startProcessGroup',
  'indexManagement',
  'shardInfo',
  'scriptRunner',
  'nodeBalancing',
  'featureToggling',
  'clusterManagement',
  'reviseReplication',
  'geoBalancing',
]

export const permissions = [
  'dictionariesService_getDictionary',
  'closingOperationDayService_getCurrentOperationDay',
  'closingOperationDayService_startClosingOperationDay',
  'closingOperationDayService_getResultOfClosingOperationDay',
  'closingOperationDayService_getFailedContractsWithSteps',
  'closingOperationDayService_getHistory',
  'closingOperationDayService_getHistoryDetailed',
  'closingOperationDayService_getOperationDays',
  'processManagementService_startProcess',
  'processManagementService_getHistory',
  'userService_getPermissions',
  'zoneIndexService_getClusterInfo',
  'shardInfoService_getInfo',
  'scriptService_createScriptRequest',
  'clientTransferService_transfer',
  'featureTogglingService_getInfo',
  'clusterManagementService_getShard',
  'revisionService_runRevision',
]

export const processFields = [
  {
    name: 'Подготовка операционного дня',
    code: 'PREPARE_OD',
    status: 'COMPLETED',
    startTime: '2026-08-12T09:10:00.000Z',
    endTime: '2026-08-12T09:12:00.000Z',
    recordsWillBeProcessed: '1250',
    totalRecords: '1250',
    recordsProcessed: '1250',
    processedCorrectly: '1248',
    processedWithError: '2',
    loading: '1',
    numberMinutesAtWork: '2',
    lastUpdate: '2026-08-12T09:12:00.000Z',
    description: 'Подготовка данных завершена',
    stepInGroup: '1',
    nodeCode: 'P1',
  },
  {
    name: 'Расчёт итогов',
    code: 'CALCULATE_TOTALS',
    status: 'RUNNING',
    startTime: '2026-08-12T09:12:00.000Z',
    recordsWillBeProcessed: '850',
    totalRecords: '850',
    recordsProcessed: '510',
    processedCorrectly: '508',
    processedWithError: '2',
    loading: '0.6',
    numberMinutesAtWork: '18',
    lastUpdate: NOW,
    description: 'Выполняется расчёт итоговых записей',
    stepInGroup: '2',
    nodeCode: 'P2',
  },
]

const makeRevision = (id, shardId, status = 'NOT_MATCHED') => ({
  id,
  shardId: String(shardId),
  part: 100,
  tablesTotal: 3,
  status,
  job: 'REVISE',
  jobStatus: status === 'WORKING' ? 'RUNNING' : 'COMPLETED',
  rowsTotal: 15000,
  rowsDiff: status === 'MATCHED' ? 0 : 12,
  rowsDiffSaved: 12,
  tasksProcessed: 3,
  tasksTotal: 3,
  jobRowsProcessed: 15000,
  jobRowsTotal: 15000,
  rowsSyncLeft: 7,
  rowsSyncRight: 5,
  cursorFinished: true,
  created: '2026-08-12T08:00:00.000Z',
  updated: NOW,
})

// A larger, spread-out dataset for the "История" tab (revision history),
// which pages through results via useInfiniteScroll + useVirtualization.
// The 2-row `revisions` fixture above is too small to exercise scrolling,
// pagination, or the sticky header while more pages load.
const REVISION_HISTORY_STATUSES = [
  'MATCHED',
  'NOT_MATCHED',
  'MATCHED',
  'FAILED',
  'MATCHED',
  'NOT_MATCHED',
  'ABORTED',
  'MATCHED',
]
const REVISION_HISTORY_SHARD_IDS = [1, 2, 3, 4]

const makeRevisionHistoryList = (count = 140) => {
  const startId = 200
  const nowMs = new Date(NOW).getTime()

  return Array.from({ length: count }, (_, i) => {
    const shardId = REVISION_HISTORY_SHARD_IDS[i % REVISION_HISTORY_SHARD_IDS.length]
    const status = REVISION_HISTORY_STATUSES[i % REVISION_HISTORY_STATUSES.length]
    const daysAgo = Math.floor(i / REVISION_HISTORY_SHARD_IDS.length)
    const updated = new Date(
      nowMs - daysAgo * 24 * 60 * 60 * 1000 - (i % 7) * 60 * 60 * 1000,
    ).toISOString()
    const created = new Date(new Date(updated).getTime() - 4 * 60 * 1000).toISOString()

    return {
      ...makeRevision(startId + i, shardId, status),
      created,
      updated,
    }
  })
}

// Один семафорный кластер может обслуживать на одной ноде несколько
// несмежных диапазонов. Генерируем записи из компактной раскладки, чтобы в
// фикстурах явно было видно распределение бакетов и было сложнее случайно
// создать пересечение копированием одного объекта.
const makeSemaphoreRanges = ({ ranges, ...semaphore }) =>
  ranges.map(([startInclusive, endExclusive]) => ({
    ...semaphore,
    startInclusive,
    endExclusive,
  }))

// Начиная с platform-api 2.1 NodeDto/getNodes(), ShardDto/getShards() и
// semaphoreInfo() — три отдельных, более "плоских" эндпоинта: нода больше не
// содержит вложенные semaphores/connectionPool. Ниже описываем стартовые
// данные в прежнем "богатом" виде (в одном месте на ноду), а фактические
// коллекции state.nodes/state.pools/state.shards/state.semaphores выводим
// из него — так фикстуры остаются читаемыми, а форма ответов соответствует
// новому контракту.
const buildAdditionalRawNodes = () =>
  Array.from({ length: BALANCING_SHARD_COUNT - 5 }, (_, index) => index + 6).flatMap(
    (shardId) => {
      const recordsAmount = 90000 + shardId * 7000
      const primaryDc = shardId % 2 === 0 ? 'MSK' : 'SPB'
      const replicaDc = primaryDc === 'MSK' ? 'SPB' : 'MSK'
      const clusterKey = `cluster-shard-${shardId}`

      return [
        {
          shardId,
          nodeKey: `P${shardId}`,
          dcKey: primaryDc,
          connectionPool: 'ACTIVE',
          semaphores: [
            {
              nodeKey: `P${shardId}`,
              clusterKey,
              startInclusive: 0,
              endExclusive: 16384,
              status: 'ACTIVE',
              recordsAmount,
              frozenNode: false,
              frozenSemaphoreCluster: false,
              dcKey: primaryDc,
              sameDc: true,
            },
          ],
        },
        {
          shardId,
          nodeKey: `S${shardId}`,
          dcKey: replicaDc,
          connectionPool: 'ACTIVE',
          semaphores: [
            {
              nodeKey: `S${shardId}`,
              clusterKey,
              startInclusive: 16384,
              endExclusive: 32768,
              status: 'ACTIVE',
              recordsAmount,
              frozenNode: false,
              frozenSemaphoreCluster: false,
              dcKey: replicaDc,
              sameDc: false,
            },
          ],
        },
      ]
    },
  )

const buildRawNodes = () => [
  {
    shardId: 1,
    nodeKey: 'P1',
    dcKey: 'MSK',
    connectionPool: 'ACTIVE',
    semaphores: makeSemaphoreRanges({
      nodeKey: 'P1',
      clusterKey: 'cluster-main',
      status: 'ACTIVE',
      recordsAmount: 245000,
      frozenNode: false,
      frozenSemaphoreCluster: false,
      dcKey: 'MSK',
      sameDc: true,
      ranges: [
        [0, 8192],
        [16384, 24576],
      ],
    }),
  },
  {
    shardId: 1,
    nodeKey: 'S1',
    dcKey: 'SPB',
    connectionPool: 'ACTIVE',
    semaphores: makeSemaphoreRanges({
      nodeKey: 'S1',
      clusterKey: 'cluster-main',
      status: 'ACTIVE',
      recordsAmount: 245000,
      frozenNode: false,
      frozenSemaphoreCluster: false,
      dcKey: 'SPB',
      sameDc: false,
      ranges: [
        [8192, 16384],
        [24576, 32768],
      ],
    }),
  },
  {
    shardId: 2,
    nodeKey: 'P2',
    dcKey: 'SPB',
    // Отдельный стартовый сценарий для UI: коннекты выключены, но сам
    // мониторинг ноды доступен. Так предупреждения о пуле и DOWN можно
    // проверить независимо друг от друга на разных шардах.
    connectionPool: 'SUSPENDED',
    monitoringState: 'UP',
    semaphores: [
      {
        nodeKey: 'P2',
        clusterKey: 'cluster-reserve',
        startInclusive: 0,
        endExclusive: 0,
        status: 'INACTIVE',
        recordsAmount: 182000,
        frozenNode: false,
        frozenSemaphoreCluster: false,
        dcKey: 'SPB',
        sameDc: true,
      },
    ],
  },
  {
    shardId: 2,
    nodeKey: 'S2',
    dcKey: 'MSK',
    connectionPool: 'ACTIVE',
    semaphores: [
      {
        nodeKey: 'S2',
        clusterKey: 'cluster-reserve',
        startInclusive: 0,
        endExclusive: 32768,
        status: 'INACTIVE',
        recordsAmount: 182000,
        frozenNode: false,
        frozenSemaphoreCluster: false,
        dcKey: 'MSK',
        sameDc: false,
      },
    ],
  },
  {
    shardId: 3,
    nodeKey: 'P3',
    dcKey: 'MSK',
    connectionPool: 'ACTIVE',
    // Вторая проблемная шарда стартует с недоступным мониторингом на одной
    // ноде, независимо от состояния её пула коннектов.
    monitoringState: 'DOWN',
    semaphores: [
      {
        nodeKey: 'P3',
        clusterKey: 'cluster-archive',
        startInclusive: 0,
        endExclusive: 16384,
        status: 'ACTIVE',
        recordsAmount: 98000,
        frozenNode: false,
        frozenSemaphoreCluster: false,
        dcKey: 'MSK',
        sameDc: true,
      },
    ],
  },
  {
    shardId: 3,
    nodeKey: 'S3',
    dcKey: 'SPB',
    connectionPool: 'ACTIVE',
    semaphores: [
      {
        nodeKey: 'S3',
        clusterKey: 'cluster-archive',
        startInclusive: 16384,
        endExclusive: 32768,
        status: 'ACTIVE',
        recordsAmount: 98000,
        frozenNode: true,
        frozenSemaphoreCluster: false,
        dcKey: 'SPB',
        sameDc: false,
      },
    ],
  },
  {
    shardId: 4,
    nodeKey: 'P4',
    dcKey: 'MSK',
    connectionPool: 'ACTIVE',
    semaphores: [
      {
        nodeKey: 'P4',
        clusterKey: 'cluster-backup',
        startInclusive: 0,
        endExclusive: 16384,
        status: 'ACTIVE',
        recordsAmount: 150000,
        frozenNode: false,
        frozenSemaphoreCluster: false,
        dcKey: 'MSK',
        sameDc: true,
      },
    ],
  },
  {
    shardId: 4,
    nodeKey: 'S4',
    dcKey: 'SPB',
    connectionPool: 'ACTIVE',
    monitoringState: 'ONLY_READ',
    semaphores: [
      {
        nodeKey: 'S4',
        clusterKey: 'cluster-backup',
        startInclusive: 16384,
        endExclusive: 32768,
        status: 'ACTIVE',
        recordsAmount: 150000,
        frozenNode: false,
        frozenSemaphoreCluster: false,
        dcKey: 'SPB',
        sameDc: false,
      },
    ],
  },
  // Шард с тремя нодами: каждый бакет принадлежит ровно одной ноде. Границу
  // шарда (PUT .../shard/{ids}/nodes) сервер по-прежнему принимает только для
  // шардов из двух нод — на трёх нодах диапазоны меняются через
  // .../shard/{id}/semaphores.
  {
    shardId: 5,
    nodeKey: 'P5',
    dcKey: 'MSK',
    connectionPool: 'ACTIVE',
    semaphores: [
      {
        nodeKey: 'P5',
        clusterKey: 'cluster-triple',
        startInclusive: 0,
        endExclusive: 10922,
        status: 'ACTIVE',
        recordsAmount: 120000,
        frozenNode: false,
        frozenSemaphoreCluster: false,
        dcKey: 'MSK',
        sameDc: true,
      },
    ],
  },
  {
    shardId: 5,
    nodeKey: 'S5',
    dcKey: 'SPB',
    connectionPool: 'ACTIVE',
    semaphores: [
      {
        nodeKey: 'S5',
        clusterKey: 'cluster-triple',
        startInclusive: 10922,
        endExclusive: 21844,
        status: 'ACTIVE',
        recordsAmount: 119000,
        frozenNode: false,
        frozenSemaphoreCluster: false,
        dcKey: 'SPB',
        sameDc: false,
      },
    ],
  },
  {
    shardId: 5,
    nodeKey: 'R5',
    dcKey: 'MSK',
    connectionPool: 'ACTIVE',
    monitoringState: 'ONLY_READ',
    semaphores: [
      {
        nodeKey: 'R5',
        clusterKey: 'cluster-triple',
        startInclusive: 21844,
        endExclusive: 32768,
        status: 'ACTIVE',
        recordsAmount: 121000,
        frozenNode: false,
        frozenSemaphoreCluster: false,
        dcKey: 'MSK',
        sameDc: true,
      },
    ],
  },
  ...buildAdditionalRawNodes(),
]

// NodeDto (getNodes()) — только идентификация и статус ноды, без
// вложенных данных о нагрузке/коннектах.
const deriveNodes = (rawNodes) =>
  rawNodes.map((node, index) => ({
    id: index + 1,
    key: node.nodeKey,
    shardId: node.shardId,
    status: 'WORKING',
    dcKey: node.dcKey,
    // Внутреннее поле мока для dbMonitorings(), не часть контракта NodeDto —
    // GET .../nodes явно отбирает только поля NodeDto перед ответом.
    monitoringState: node.monitoringState,
  }))

// PoolDto (ConnectionPoolManagementServiceApi.getPools()) — статус пула
// коннектов теперь отдельный ресурс, привязанный к ноде по ключу.
const derivePools = (rawNodes) =>
  rawNodes.map((node) => ({
    key: node.nodeKey,
    status: node.connectionPool ?? 'UNKNOWN',
    updated: NOW,
  }))

// BucketRangeDto — раньше жил внутри NodeDto.semaphores, теперь это часть
// bucketRanges соответствующей шарды (ShardDto).
const deriveBucketRanges = (rawNodes) =>
  rawNodes.flatMap((node) =>
    (node.semaphores ?? []).map((semaphore) => ({
      startInclusive: semaphore.startInclusive,
      endExclusive: semaphore.endExclusive,
      semaphoreClusterKey: semaphore.clusterKey,
      nodeKey: node.nodeKey,
      frozenNode: semaphore.frozenNode ?? false,
      frozenSemaphoreCluster: semaphore.frozenSemaphoreCluster ?? false,
      sameDC: semaphore.sameDc ?? false,
    })),
  )

// ShardDto (getShards()) — id шарды плюс её диапазоны бакетов.
const deriveShards = (rawNodes) => {
  const bucketRanges = deriveBucketRanges(rawNodes)
  const nodeKeyToShardId = new Map(rawNodes.map((node) => [node.nodeKey, node.shardId]))
  const shardIds = [...new Set(rawNodes.map((node) => node.shardId))].sort((a, b) => a - b)

  return shardIds.map((id) => ({
    id,
    bucketRanges: bucketRanges.filter((range) => nodeKeyToShardId.get(range.nodeKey) === id),
  }))
}

// SemaphoreDto (semaphoreInfo()) — теперь одна запись на семафорный кластер
// (а не на пару кластер+диапазон, как раньше). "Домашний" dcKey и статус
// кластера берём из диапазона его же ДЦ (semaphore.sameDc === true).
const deriveSemaphores = (rawNodes) => {
  const byClusterKey = new Map()

  for (const node of rawNodes) {
    for (const semaphore of node.semaphores ?? []) {
      const isHomeRange = semaphore.sameDc === true || !byClusterKey.has(semaphore.clusterKey)
      if (isHomeRange) {
        byClusterKey.set(semaphore.clusterKey, {
          clusterKey: semaphore.clusterKey,
          status: semaphore.status,
          dcKey: semaphore.dcKey,
          recordsAmount: semaphore.recordsAmount,
          updated: NOW,
        })
      }
    }
  }

  return [...byClusterKey.values()]
}

const makeTransferStatuses = (count = TRANSFER_STATUS_COUNT) =>
  Array.from({ length: count }, (_, index) => {
    const shardId = index + 1

    return {
      shard: {
        id: shardId,
        name: `TKP-${String(shardId).padStart(2, '0')}`,
        type: 'POSTGRESQL',
      },
      taskAmount: 6 + ((index * 11) % 43),
      attemptTaskAmount: index % 4 === 0 ? 1 + (index % 5) : index % 7 === 0 ? 2 : 0,
    }
  })

// Шаблоны сгруппированы по реальным пользовательским задачам. Последний
// сегмент path всегда является именем файла, а все предыдущие — категориями,
// которые отображаются в дереве выбора шаблона.
const MOCK_TEMPLATE_GROUPS = [
  {
    path: 'Обслуживание/Индексы',
    author: 'platform-team',
    templates: [
      [
        'rebuild-client-index',
        'Перестроение клиентского индекса',
        'Безопасно перестраивает индекс клиентов и возвращает итоговый статус',
        ['index', 'maintenance', 'clients'],
        "indexService.rebuild('client-index')\nreturn 'OK'",
      ],
      [
        'check-index-status',
        'Проверка состояния индекса',
        'Показывает состояние индекса перед операциями обслуживания',
        ['index', 'status', 'diagnostics'],
      ],
      [
        'rebuild-contract-index',
        'Перестроение индекса договоров',
        'Запускает перестроение поискового индекса договоров',
        ['index', 'maintenance', 'contracts'],
      ],
      [
        'remove-stale-index',
        'Удаление устаревшего индекса',
        'Удаляет неиспользуемую версию индекса после миграции',
        ['index', 'cleanup', 'migration'],
      ],
    ],
  },
  {
    path: 'Обслуживание/Кэш',
    author: 'platform-team',
    templates: [
      [
        'clear-client-cache',
        'Очистка кэша клиентов',
        'Сбрасывает записи клиентского кэша по идентификатору',
        ['cache', 'clients', 'cleanup'],
      ],
      [
        'warmup-dictionary-cache',
        'Прогрев кэша справочников',
        'Загружает основные справочники в кэш до открытия нагрузки',
        ['cache', 'dictionary', 'warmup'],
      ],
      [
        'inspect-cache-keys',
        'Проверка ключей кэша',
        'Возвращает список ключей выбранного пространства кэша',
        ['cache', 'diagnostics', 'keys'],
      ],
      [
        'evict-expired-cache',
        'Удаление просроченных записей',
        'Очищает просроченные записи без полного сброса кэша',
        ['cache', 'cleanup', 'expired'],
      ],
    ],
  },
  {
    path: 'Диагностика/Клиенты',
    author: 'support-team',
    templates: [
      [
        'find-client',
        'Поиск клиента по параметрам',
        'Ищет клиента по идентификатору, региону и периоду создания',
        ['diagnostics', 'clients', 'sql'],
        "return jdbcTemplate.queryForList(\"select * from {{TABLE_NAME}} where client_id = '{{CLIENT_ID}}' and region = '{{REGION_CODE}}'\")",
      ],
      [
        'inspect-client-profile',
        'Проверка профиля клиента',
        'Собирает основные атрибуты профиля для разбора обращения',
        ['diagnostics', 'clients', 'profile'],
      ],
      [
        'list-client-accounts',
        'Список счетов клиента',
        'Показывает активные и закрытые счета выбранного клиента',
        ['diagnostics', 'clients', 'accounts'],
      ],
      [
        'inspect-client-locks',
        'Проверка блокировок клиента',
        'Находит активные технические и бизнес-блокировки',
        ['diagnostics', 'clients', 'locks'],
      ],
    ],
  },
  {
    path: 'Диагностика/Платежи',
    author: 'support-team',
    templates: [
      [
        'find-payment',
        'Поиск платежа',
        'Находит платёж по внешнему или внутреннему идентификатору',
        ['diagnostics', 'payments', 'search'],
      ],
      [
        'inspect-payment-route',
        'Проверка маршрута платежа',
        'Показывает этапы маршрутизации и выбранные обработчики',
        ['diagnostics', 'payments', 'routing'],
      ],
      [
        'list-stuck-payments',
        'Зависшие платежи',
        'Возвращает платежи без обновления статуса за заданный период',
        ['diagnostics', 'payments', 'stuck'],
      ],
      [
        'verify-payment-balance',
        'Сверка баланса платежа',
        'Сравнивает проводки платежа с текущим состоянием баланса',
        ['diagnostics', 'payments', 'balance'],
      ],
    ],
  },
  {
    path: 'Мониторинг/Репликация',
    author: 'sre-team',
    templates: [
      [
        'check-replication-lag',
        'Проверка задержки репликации',
        'Показывает текущий lag по всем активным репликам',
        ['monitoring', 'replication', 'lag'],
      ],
      [
        'compare-replica-counts',
        'Сравнение количества записей',
        'Сравнивает количество записей на основной и резервной нодах',
        ['monitoring', 'replication', 'records'],
      ],
      [
        'inspect-replica-health',
        'Состояние реплик',
        'Собирает технические статусы реплик выбранного шарда',
        ['monitoring', 'replication', 'health'],
      ],
      [
        'list-replication-errors',
        'Ошибки репликации',
        'Возвращает последние ошибки потока репликации',
        ['monitoring', 'replication', 'errors'],
      ],
    ],
  },
  {
    path: 'Мониторинг/Очереди',
    author: 'sre-team',
    templates: [
      [
        'inspect-queue-depth',
        'Глубина очередей',
        'Показывает количество ожидающих сообщений по очередям',
        ['monitoring', 'queue', 'depth'],
      ],
      [
        'find-dead-letter-messages',
        'Сообщения в DLQ',
        'Ищет сообщения, перемещённые в очередь ошибок',
        ['monitoring', 'queue', 'dlq'],
      ],
      [
        'inspect-consumer-lag',
        'Задержка обработчиков очереди',
        'Показывает отставание групп потребителей',
        ['monitoring', 'queue', 'consumer'],
      ],
      [
        'check-queue-throughput',
        'Пропускная способность очередей',
        'Собирает скорость публикации и обработки сообщений',
        ['monitoring', 'queue', 'throughput'],
      ],
    ],
  },
  {
    path: 'Восстановление/Данные',
    author: 'recovery-team',
    templates: [
      [
        'restore-client-status',
        'Восстановление статуса клиента',
        'Возвращает согласованный статус клиента после сбоя обработки',
        ['recovery', 'clients', 'status'],
      ],
      [
        'replay-domain-event',
        'Повторная обработка события',
        'Повторно публикует выбранное доменное событие',
        ['recovery', 'events', 'replay'],
      ],
      [
        'repair-missing-record',
        'Восстановление отсутствующей записи',
        'Создаёт пропущенную запись на основании журнала операций',
        ['recovery', 'records', 'repair'],
      ],
      [
        'reconcile-client-data',
        'Сверка данных клиента',
        'Сверяет связанные записи клиента и формирует отчёт расхождений',
        ['recovery', 'clients', 'reconcile'],
      ],
    ],
  },
  {
    path: 'Миграции/Справочники',
    author: 'migration-team',
    templates: [
      [
        'migrate-region-codes',
        'Миграция кодов регионов',
        'Обновляет устаревшие коды регионов пакетами',
        ['migration', 'dictionary', 'regions'],
      ],
      [
        'normalize-currency-codes',
        'Нормализация кодов валют',
        'Приводит коды валют к актуальному справочнику',
        ['migration', 'dictionary', 'currency'],
      ],
      [
        'validate-dictionary-links',
        'Проверка ссылок на справочники',
        'Находит записи со ссылками на отсутствующие элементы справочника',
        ['migration', 'dictionary', 'validation'],
      ],
      [
        'backfill-dictionary-values',
        'Заполнение значений справочника',
        'Заполняет новые атрибуты для существующих справочных записей',
        ['migration', 'dictionary', 'backfill'],
      ],
    ],
  },
]

export const SCRIPT_TEMPLATE_COUNT = MOCK_TEMPLATE_GROUPS.reduce(
  (count, group) => count + group.templates.length,
  0,
)

const buildScriptTemplates = () => {
  const templates = []
  const templateBodies = {}
  let sequence = 0

  MOCK_TEMPLATE_GROUPS.forEach(({ path, author, templates: groupTemplates }) => {
    groupTemplates.forEach(([slug, title, description, tags, body]) => {
      const hashcode = 10101 + sequence
      sequence += 1

      templates.push({
        hashcode,
        path: `${path}/${slug}.groovy`,
        title,
        extension: 'groovy',
        description,
        tags,
        author,
      })
      templateBodies[hashcode] =
        body ?? `// ${title}\n// Категория: ${path}\nreturn [status: 'OK', template: '${slug}']`
    })
  })

  return { templates, templateBodies }
}

export const createTransferProcessState = ({
  sessionId,
  shardIds = Array.from({ length: ACTIVE_TRANSFER_PROCESS_COUNT }, (_, index) => index + 1),
  now = Date.now(),
  durationMs = TRANSFER_PROCESS_DURATION_MS,
  elapsedMs = 0,
}) => {
  const startedAtMs = now - elapsedMs
  const startTime = new Date(startedAtMs).toISOString()

  return {
    process: {
      sessionId,
      processGroupId: 71,
      done: false,
      data: {
        lastUpdate: new Date(now).toISOString(),
        groupOfProcesses: {
          statusGroup: 'RUNNING',
          numbersMinutesAtWork: '0',
          timeStart: startTime,
          dateOD: new Date(now).toISOString().slice(0, 10),
          fields: shardIds.map((shardId, index) => {
            const totalRecords = 180 + ((index * 137) % 620)

            return {
              name: 'Перенос клиентов',
              code: `TRANSFER_CLIENTS_${shardId}`,
              status: 'RUNNING',
              nodeCode: String(shardId),
              recordsWillBeProcessed: String(totalRecords),
              totalRecords: String(totalRecords),
              recordsProcessed: '0',
              processedCorrectly: '0',
              processedWithError: '0',
              loading: '0',
              numberMinutesAtWork: '0',
              startTime,
              lastUpdate: new Date(now).toISOString(),
              description: `Перенос клиентов шарда ${shardId}`,
              stepInGroup: String(index + 1),
            }
          }),
        },
      },
    },
    timeline: {
      startedAtMs,
      durationMs,
    },
  }
}

export const createTaskFormationProcessState = (options) => {
  const processState = createTransferProcessState(options)
  const fields = processState.process.data.groupOfProcesses.fields

  processState.process.processGroupId = 70
  processState.process.data.groupOfProcesses.fields = fields.map((field) => {
    const shardId = Number(field.nodeCode)

    return {
      ...field,
      name: 'Формирование задания',
      code: `CREATE_TRANSFER_TASK_${shardId}`,
      nodeCode: String(shardId),
      description: `Формирование задания для шарда ${shardId}`,
    }
  })

  return processState
}

export const createInitialState = () => {
  const now = Date.now()
  const { templates, templateBodies } = buildScriptTemplates()
  // Процесс уже немного поработал к первому открытию страницы, поэтому в UI
  // сразу виден ненулевой прогресс. Оставшегося времени всё ещё достаточно,
  // чтобы проверить polling и автоматическое завершение.
  const activeTransfer = createTransferProcessState({
    sessionId: ACTIVE_TRANSFER_SESSION_ID,
    now,
    elapsedMs: 2 * 1000,
    durationMs: INITIAL_ACTIVE_PROCESS_DURATION_MS,
  })
  const activeTaskFormation = createTaskFormationProcessState({
    sessionId: ACTIVE_CREATE_TASK_SESSION_ID,
    now,
    elapsedMs: 4 * 1000,
    durationMs: INITIAL_ACTIVE_PROCESS_DURATION_MS,
  })

  return {
    nextProcessId: 7004,
    nextRevisionId: 103,
    nextRestrictionId: 3,
    serviceMode: 'DISABLED',
    operationDays: {
      currentOperationDay: '2026-08-12',
      closedOperationDay: '2026-08-11',
    },
    processes: {
      [ACTIVE_CREATE_TASK_SESSION_ID]: activeTaskFormation.process,
      [ACTIVE_TRANSFER_SESSION_ID]: activeTransfer.process,
    },
    processTimelines: {
      [ACTIVE_CREATE_TASK_SESSION_ID]: activeTaskFormation.timeline,
      [ACTIVE_TRANSFER_SESSION_ID]: activeTransfer.timeline,
    },
    processHistory: [
      {
        groupId: '1',
        sessionId: '6901',
        dateOD: '2026-08-11',
        timeStart: '2026-08-11T19:00:00.000Z',
        timeEnd: '2026-08-11T19:14:00.000Z',
        statusGroup: 'COMPLETED',
        numbersMinutesAtWork: '14',
        groupDescription: 'Регламентное закрытие дня',
      },
      {
        groupId: '2',
        sessionId: '6902',
        dateOD: '2026-08-10',
        timeStart: '2026-08-10T18:45:00.000Z',
        timeEnd: '2026-08-10T19:02:00.000Z',
        statusGroup: 'FAILED',
        numbersMinutesAtWork: '17',
        groupDescription: 'Пересчёт клиентских данных',
      },
    ],
    nodes: deriveNodes(buildRawNodes()),
    pools: derivePools(buildRawNodes()),
    shards: deriveShards(buildRawNodes()),
    semaphores: deriveSemaphores(buildRawNodes()),
    replications: {
      1: {
        status: 'DONE',
        startedAt: '2026-08-12T08:00:00.000Z',
        finishedAt: '2026-08-12T08:04:00.000Z',
      },
      2: { status: 'REQUIRED', startedAt: '2026-08-12T09:00:00.000Z' },
      3: {
        status: 'DONE',
        startedAt: '2026-08-12T08:00:00.000Z',
        finishedAt: '2026-08-12T08:04:00.000Z',
      },
      4: {
        status: 'DONE',
        startedAt: '2026-08-12T08:00:00.000Z',
        finishedAt: '2026-08-12T08:04:00.000Z',
      },
      5: {
        status: 'DONE',
        startedAt: '2026-08-12T08:00:00.000Z',
        finishedAt: '2026-08-12T08:04:00.000Z',
      },
    },
    clusters: [
      {
        clusterId: 'client-index',
        state: 'ACTIVE',
        availableActions: 'DEACTIVATE',
        indexesCount: 8,
        updateRequired: false,
      },
      {
        clusterId: 'contract-index',
        state: 'ON_LOADING',
        availableActions: 'CANCEL_LOADING',
        indexesCount: 5,
        updateRequired: true,
        transitionStartedAt: Date.now() - 2000,
      },
    ],
    revisions: [makeRevision(101, 1), makeRevision(102, 2, 'MATCHED')],
    revisionHistory: makeRevisionHistoryList(),
    scriptApplications: [
      {
        id: 501,
        type: 'script',
        reasonId: 'CHG-2026-1042',
        jiraId: 'TKP-1042',
        rqUid: '9a5a7375-1ef2-41b1-a024-3f3a575b4fd4',
        shardId: 1,
        status: 'PENDING',
        restrictions: { enabled: true, allowedNodes: ['P1'] },
        scriptBody: "return 'fixture result'",
        created: '2026-08-12T08:20:00.000Z',
        createdBy: 'mock.admin',
        requestTtl: 'PT24H',
      },
    ],
    templates,
    templateBodies,
    features: [
      {
        name: 'client-transfer-v2',
        target: { type: 'DIRECT', module: 'tcpf-transfer' },
        hot: true,
        config: {
          activation: { type: 'MANUAL', enabled: true },
          description: 'Новый алгоритм переноса',
          customProperties: [{ name: 'batchSize', value: '500', type: 'INTEGER' }],
        },
        created: '2026-08-01T10:00:00.000Z',
        updated: NOW,
      },
      {
        name: 'revision-auto-sync',
        target: {
          type: 'SHARD',
          nodeKeys: ['P1', 'P2'],
          module: 'tcpf-revision',
        },
        hot: false,
        config: {
          activation: { type: 'OD_RELEASE', releaseDate: '2026-08-15' },
          description: 'Автосинхронизация расхождений',
          customProperties: [],
        },
        created: '2026-08-02T10:00:00.000Z',
        updated: NOW,
      },
    ],
    featureApplications: [
      {
        id: 601,
        type: 'feature',
        uid: 'feature-request-601',
        reasonId: 'CHG-2026-1050',
        featureName: 'client-transfer-v2',
        target: { type: 'DIRECT', module: 'tcpf-transfer' },
        status: 'PENDING',
        action: 'UPDATE',
        before: {
          activation: { type: 'MANUAL', enabled: false },
          customProperties: [],
        },
        after: {
          activation: { type: 'MANUAL', enabled: true },
          customProperties: [{ name: 'batchSize', value: '500', type: 'INTEGER' }],
        },
        created: NOW,
        createdBy: 'mock.admin',
      },
    ],
    trafficRestrictions: [
      {
        id: '1',
        name: 'Резервный ЦОД',
        services: ['tcpf-client-app'],
        dataCenters: ['SPB'],
        created: '2026-08-10T10:00:00.000Z',
        createdBy: 'mock.admin',
        comment: 'Плановые работы',
      },
      {
        id: '2',
        name: 'Глобальное ограничение MSK',
        services: [],
        dataCenters: ['MSK'],
        created: '2026-08-11T10:00:00.000Z',
        createdBy: 'mock.admin',
        comment: 'Проверка аварийного сценария',
      },
    ],
    transferStatus: makeTransferStatuses(),
  }
}

// ===== Spring context beans =====
// A small hand-written set of beans that are actually referenced by the
// example script templates, plus a large deterministically-generated
// registry standing in for the rest of a real application context.

const CURATED_BEANS = [
  {
    name: 'clientService',
    className: 'ClientService',
    packageName: 'ru.sber.tcpf.service.ClientService',
    methods: [
      { name: 'findClient', returnType: 'Client', parameters: ['String'] },
      { name: 'recalculate', returnType: 'void', parameters: ['String', 'LocalDate'] },
    ],
  },
  {
    name: 'indexService',
    className: 'IndexService',
    packageName: 'ru.sber.tcpf.service.IndexService',
    methods: [
      { name: 'rebuild', returnType: 'String', parameters: ['String'] },
      { name: 'dropIndex', returnType: 'void', parameters: ['String'] },
      { name: 'getStatus', returnType: 'IndexStatus', parameters: ['String'] },
    ],
  },
  {
    name: 'jdbcTemplate',
    className: 'JdbcTemplate',
    packageName: 'org.springframework.jdbc.core.JdbcTemplate',
    methods: [
      { name: 'queryForList', returnType: 'List', parameters: ['String'] },
      { name: 'update', returnType: 'int', parameters: ['String', 'Object...'] },
    ],
  },
  {
    name: 'nodeRoutingService',
    className: 'NodeRoutingService',
    packageName: 'ru.sber.tcpf.service.NodeRoutingService',
    methods: [
      { name: 'getActiveNodes', returnType: 'List<Node>', parameters: ['String'] },
      { name: 'freezeNode', returnType: 'void', parameters: ['String'] },
      { name: 'unfreezeNode', returnType: 'void', parameters: ['String'] },
    ],
  },
  {
    name: 'notificationService',
    className: 'NotificationService',
    packageName: 'ru.sber.tcpf.service.NotificationService',
    methods: [{ name: 'notify', returnType: 'void', parameters: ['String', 'String'] }],
  },
]

// Deterministic PRNG (mulberry32) so the generated registry is identical on
// every restart instead of reshuffling and confusing anyone looking at it.
const mulberry32 = (seed) => {
  let a = seed
  return () => {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

const beanRandom = mulberry32(20260814)
const beanRandomInt = (min, max) => min + Math.floor(beanRandom() * (max - min + 1))
const beanPick = (arr) => arr[beanRandomInt(0, arr.length - 1)]
const capitalize = (word) => word.charAt(0).toUpperCase() + word.slice(1)
const lowerFirst = (word) => word.charAt(0).toLowerCase() + word.slice(1)

const BEAN_DOMAIN_WORDS = [
  'client',
  'contract',
  'node',
  'shard',
  'script',
  'template',
  'notification',
  'index',
  'routing',
  'feature',
  'toggle',
  'semaphore',
  'replica',
  'traffic',
  'operation',
  'process',
  'audit',
  'user',
  'permission',
  'session',
  'account',
  'balance',
  'payment',
  'transaction',
  'invoice',
  'order',
  'product',
  'catalog',
  'region',
  'branch',
  'employee',
  'role',
  'group',
  'event',
  'metric',
  'health',
  'config',
  'lock',
  'migration',
  'encryption',
  'integration',
  'gateway',
  'report',
  'export',
  'import',
  'document',
  'file',
  'storage',
  'queue',
  'message',
  'alert',
  'webhook',
  'security',
  'token',
  'certificate',
  'cache',
  'database',
  'connection',
  'pool',
  'thread',
  'task',
  'job',
  'workflow',
  'approval',
  'escalation',
  'ticket',
  'incident',
  'log',
  'trace',
  'dashboard',
  'statistic',
  'aggregation',
  'calculation',
  'rule',
  'policy',
  'limit',
  'quota',
  'throttle',
  'rate',
  'currency',
  'exchange',
  'tariff',
  'fee',
  'discount',
  'subscription',
  'license',
  'agreement',
  'party',
  'counterparty',
  'beneficiary',
  'signature',
  'verification',
  'risk',
  'score',
  'fraud',
  'compliance',
  'jurisdiction',
  'tax',
  'receipt',
  'statement',
  'reconciliation',
  'settlement',
  'clearing',
  'portfolio',
  'position',
  'instrument',
  'loan',
  'deposit',
  'credit',
  'ledger',
  'journal',
  'entry',
  'batch',
  'partition',
  'cluster',
  'schedule',
  'backup',
  'restore',
  'snapshot',
  'archive',
  'retention',
  'cleanup',
  'validation',
  'mapping',
  'conversion',
  'serialization',
  'monitoring',
  'sampling',
  'versioning',
  'deployment',
  'provisioning',
  'orchestration',
  'discovery',
  'registry',
]

const randomBeanParams = () => {
  const templates = [
    [],
    [],
    ['String'],
    ['Long'],
    ['String', 'LocalDate'],
    ['String', 'String'],
    ['Long', 'BigDecimal'],
    ['List<String>'],
    ['String', 'Object...'],
    ['UUID'],
    ['String', 'Map<String, Object>'],
  ]
  return beanPick(templates)
}

// Each archetype describes how a bean/class name is built, which package it
// lives in, and a pool of method factories keyed off the derived entity name.
const BEAN_ARCHETYPES = [
  {
    suffix: 'Service',
    pkg: 'service',
    methods: (e) => [
      () => ({
        name: `find${e}`,
        returnType: `Optional<${e}>`,
        parameters: [beanPick(['String', 'Long', 'UUID'])],
      }),
      () => ({
        name: `findAll${e}s`,
        returnType: `List<${e}>`,
        parameters: randomBeanParams(),
      }),
      () => ({ name: `create${e}`, returnType: e, parameters: [`${e}Dto`] }),
      () => ({
        name: `update${e}`,
        returnType: e,
        parameters: [beanPick(['Long', 'String']), `${e}Dto`],
      }),
      () => ({
        name: `delete${e}`,
        returnType: 'void',
        parameters: [beanPick(['Long', 'String'])],
      }),
      () => ({
        name: `process${e}`,
        returnType: 'void',
        parameters: [beanPick(['String', 'Long'])],
      }),
      () => ({ name: 'recalculate', returnType: 'void', parameters: ['String', 'LocalDate'] }),
      () => ({ name: `validate${e}`, returnType: 'boolean', parameters: [e] }),
      () => ({ name: `sync${e}`, returnType: 'void', parameters: ['String'] }),
      () => ({ name: 'notify', returnType: 'void', parameters: ['String', 'String'] }),
    ],
  },
  {
    suffix: 'Repository',
    pkg: 'repository',
    methods: (e) => [
      () => ({
        name: 'findById',
        returnType: `Optional<${e}>`,
        parameters: [beanPick(['Long', 'String', 'UUID'])],
      }),
      () => ({ name: 'findAll', returnType: `List<${e}>`, parameters: [] }),
      () => ({ name: 'save', returnType: e, parameters: [e] }),
      () => ({
        name: 'deleteById',
        returnType: 'void',
        parameters: [beanPick(['Long', 'String'])],
      }),
      () => ({
        name: 'existsById',
        returnType: 'boolean',
        parameters: [beanPick(['Long', 'String'])],
      }),
      () => ({
        name: `countBy${capitalize(beanPick(['status', 'code', 'region']))}`,
        returnType: 'long',
        parameters: ['String'],
      }),
      () => ({
        name: `findBy${capitalize(beanPick(['status', 'code', 'ownerId']))}`,
        returnType: `List<${e}>`,
        parameters: ['String'],
      }),
    ],
  },
  {
    suffix: 'Mapper',
    pkg: 'mapper',
    methods: (e) => [
      () => ({ name: 'toDto', returnType: `${e}Dto`, parameters: [e] }),
      () => ({ name: 'toEntity', returnType: e, parameters: [`${e}Dto`] }),
      () => ({ name: 'toDtoList', returnType: `List<${e}Dto>`, parameters: [`List<${e}>`] }),
      () => ({ name: 'merge', returnType: e, parameters: [e, `${e}Dto`] }),
    ],
  },
  {
    suffix: 'Validator',
    pkg: 'validation',
    methods: (e) => [
      () => ({ name: 'validate', returnType: 'ValidationResult', parameters: [e] }),
      () => ({ name: 'isValid', returnType: 'boolean', parameters: [e] }),
      () => ({ name: 'check', returnType: 'void', parameters: [e] }),
    ],
  },
  {
    suffix: 'Client',
    pkg: 'client',
    methods: (e) => [
      () => ({
        name: `fetch${e}`,
        returnType: `ResponseEntity<${e}Dto>`,
        parameters: ['String'],
      }),
      () => ({
        name: 'send',
        returnType: 'ResponseEntity<String>',
        parameters: ['String', 'Object'],
      }),
      () => ({
        name: 'call',
        returnType: 'String',
        parameters: ['String', 'Map<String, Object>'],
      }),
      () => ({ name: 'ping', returnType: 'boolean', parameters: [] }),
    ],
  },
  {
    suffix: 'Handler',
    pkg: 'handler',
    methods: (e) => [
      () => ({ name: 'handle', returnType: 'void', parameters: [`${e}Event`] }),
      () => ({ name: 'canHandle', returnType: 'boolean', parameters: [`${e}Event`] }),
    ],
  },
  {
    suffix: 'Listener',
    pkg: 'listener',
    methods: (e) => [
      () => ({ name: 'onEvent', returnType: 'void', parameters: [`${e}Event`] }),
      () => ({ name: 'onMessage', returnType: 'void', parameters: ['String'] }),
    ],
  },
  {
    suffix: 'Publisher',
    pkg: 'publisher',
    methods: (e) => [
      () => ({ name: 'publish', returnType: 'void', parameters: [`${e}Event`] }),
      () => ({ name: 'broadcast', returnType: 'void', parameters: ['String', 'Object'] }),
    ],
  },
  {
    suffix: 'Manager',
    pkg: 'manager',
    methods: (e) => [
      () => ({
        name: `manage${e}`,
        returnType: 'void',
        parameters: [beanPick(['String', 'Long'])],
      }),
      () => ({ name: 'start', returnType: 'void', parameters: [] }),
      () => ({ name: 'stop', returnType: 'void', parameters: [] }),
      () => ({ name: 'getStatus', returnType: `${e}Status`, parameters: ['String'] }),
    ],
  },
  {
    suffix: 'Resolver',
    pkg: 'resolver',
    methods: (e) => [
      () => ({ name: 'resolve', returnType: e, parameters: ['String'] }),
      () => ({ name: 'canResolve', returnType: 'boolean', parameters: ['String'] }),
    ],
  },
  {
    suffix: 'Provider',
    pkg: 'provider',
    methods: (e) => [
      () => ({ name: 'provide', returnType: e, parameters: [] }),
      () => ({ name: 'get', returnType: e, parameters: ['String'] }),
    ],
  },
  {
    suffix: 'Factory',
    pkg: 'factory',
    methods: (e) => [
      () => ({ name: 'create', returnType: e, parameters: [`${e}Dto`] }),
      () => ({ name: 'createDefault', returnType: e, parameters: [] }),
    ],
  },
  {
    suffix: 'Gateway',
    pkg: 'gateway',
    methods: (e) => [
      () => ({ name: 'send', returnType: 'void', parameters: [e] }),
      () => ({ name: 'receive', returnType: e, parameters: ['String'] }),
    ],
  },
  {
    suffix: 'Cache',
    pkg: 'cache',
    methods: () => [
      () => ({ name: 'get', returnType: 'Object', parameters: ['String'] }),
      () => ({ name: 'put', returnType: 'void', parameters: ['String', 'Object'] }),
      () => ({ name: 'evict', returnType: 'void', parameters: ['String'] }),
      () => ({ name: 'clear', returnType: 'void', parameters: [] }),
    ],
  },
  {
    suffix: 'Scheduler',
    pkg: 'scheduler',
    methods: () => [
      () => ({ name: 'schedule', returnType: 'void', parameters: ['String', 'LocalDateTime'] }),
      () => ({ name: 'trigger', returnType: 'void', parameters: ['String'] }),
      () => ({ name: 'cancel', returnType: 'boolean', parameters: ['String'] }),
    ],
  },
  {
    suffix: 'Config',
    pkg: 'config',
    methods: () => [
      () => ({
        name: `get${capitalize(beanPick(['timeout', 'retryCount', 'batchSize', 'enabled']))}`,
        returnType: beanPick(['int', 'boolean', 'String']),
        parameters: [],
      }),
    ],
  },
  {
    suffix: 'Facade',
    pkg: 'facade',
    methods: (e) => [
      () => ({ name: `process${e}`, returnType: 'void', parameters: ['String'] }),
      () => ({ name: 'execute', returnType: 'ExecutionResult', parameters: [`${e}Dto`] }),
    ],
  },
  {
    suffix: 'Aggregator',
    pkg: 'aggregation',
    methods: (e) => [
      () => ({ name: 'aggregate', returnType: `${e}Summary`, parameters: [`List<${e}>`] }),
      () => ({ name: 'merge', returnType: `${e}Summary`, parameters: [`List<${e}Summary>`] }),
    ],
  },
  {
    suffix: 'Registry',
    pkg: 'registry',
    methods: (e) => [
      () => ({ name: 'register', returnType: 'void', parameters: [e] }),
      () => ({ name: 'unregister', returnType: 'void', parameters: ['String'] }),
      () => ({ name: 'contains', returnType: 'boolean', parameters: ['String'] }),
    ],
  },
]

// A curated set of real, recognizable framework/infrastructure beans that
// would normally show up in a Spring Boot application context, so the list
// doesn't read as purely synthetic.
const FRAMEWORK_BEANS = [
  [
    'dataSource',
    'HikariDataSource',
    'com.zaxxer.hikari.HikariDataSource',
    [
      { name: 'getConnection', returnType: 'Connection', parameters: [] },
      { name: 'getMaximumPoolSize', returnType: 'int', parameters: [] },
    ],
  ],
  [
    'namedParameterJdbcTemplate',
    'NamedParameterJdbcTemplate',
    'org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate',
    [
      {
        name: 'query',
        returnType: 'List<Map<String, Object>>',
        parameters: ['String', 'Map<String, Object>'],
      },
      { name: 'update', returnType: 'int', parameters: ['String', 'Map<String, Object>'] },
    ],
  ],
  [
    'transactionManager',
    'PlatformTransactionManager',
    'org.springframework.transaction.PlatformTransactionManager',
    [
      {
        name: 'getTransaction',
        returnType: 'TransactionStatus',
        parameters: ['TransactionDefinition'],
      },
      { name: 'commit', returnType: 'void', parameters: ['TransactionStatus'] },
      { name: 'rollback', returnType: 'void', parameters: ['TransactionStatus'] },
    ],
  ],
  [
    'entityManagerFactory',
    'LocalContainerEntityManagerFactoryBean',
    'org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean',
    [{ name: 'createEntityManager', returnType: 'EntityManager', parameters: [] }],
  ],
  [
    'objectMapper',
    'ObjectMapper',
    'com.fasterxml.jackson.databind.ObjectMapper',
    [
      { name: 'writeValueAsString', returnType: 'String', parameters: ['Object'] },
      { name: 'readValue', returnType: 'T', parameters: ['String', 'Class<T>'] },
    ],
  ],
  [
    'restTemplate',
    'RestTemplate',
    'org.springframework.web.client.RestTemplate',
    [
      { name: 'getForObject', returnType: 'T', parameters: ['String', 'Class<T>'] },
      {
        name: 'postForEntity',
        returnType: 'ResponseEntity<T>',
        parameters: ['String', 'Object', 'Class<T>'],
      },
    ],
  ],
  [
    'webClient',
    'WebClient',
    'org.springframework.web.reactive.function.client.WebClient',
    [
      { name: 'get', returnType: 'RequestHeadersUriSpec', parameters: [] },
      { name: 'post', returnType: 'RequestBodyUriSpec', parameters: [] },
    ],
  ],
  [
    'kafkaTemplate',
    'KafkaTemplate',
    'org.springframework.kafka.core.KafkaTemplate',
    [
      {
        name: 'send',
        returnType: 'ListenableFuture<SendResult>',
        parameters: ['String', 'Object'],
      },
    ],
  ],
  [
    'redisTemplate',
    'RedisTemplate',
    'org.springframework.data.redis.core.RedisTemplate',
    [
      { name: 'opsForValue', returnType: 'ValueOperations', parameters: [] },
      { name: 'delete', returnType: 'Boolean', parameters: ['String'] },
    ],
  ],
  [
    'stringRedisTemplate',
    'StringRedisTemplate',
    'org.springframework.data.redis.core.StringRedisTemplate',
    [{ name: 'opsForHash', returnType: 'HashOperations', parameters: [] }],
  ],
  [
    'cacheManager',
    'CaffeineCacheManager',
    'org.springframework.cache.caffeine.CaffeineCacheManager',
    [{ name: 'getCache', returnType: 'Cache', parameters: ['String'] }],
  ],
  [
    'taskExecutor',
    'ThreadPoolTaskExecutor',
    'org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor',
    [
      { name: 'execute', returnType: 'void', parameters: ['Runnable'] },
      { name: 'getActiveCount', returnType: 'int', parameters: [] },
    ],
  ],
  [
    'taskScheduler',
    'ThreadPoolTaskScheduler',
    'org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler',
    [{ name: 'schedule', returnType: 'ScheduledFuture', parameters: ['Runnable', 'Trigger'] }],
  ],
  [
    'applicationEventMulticaster',
    'SimpleApplicationEventMulticaster',
    'org.springframework.context.event.SimpleApplicationEventMulticaster',
    [{ name: 'multicastEvent', returnType: 'void', parameters: ['ApplicationEvent'] }],
  ],
  [
    'messageSource',
    'ResourceBundleMessageSource',
    'org.springframework.context.support.ResourceBundleMessageSource',
    [
      {
        name: 'getMessage',
        returnType: 'String',
        parameters: ['String', 'Object[]', 'Locale'],
      },
    ],
  ],
  [
    'requestMappingHandlerMapping',
    'RequestMappingHandlerMapping',
    'org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping',
    [
      {
        name: 'getHandler',
        returnType: 'HandlerExecutionChain',
        parameters: ['HttpServletRequest'],
      },
    ],
  ],
  [
    'multipartResolver',
    'StandardServletMultipartResolver',
    'org.springframework.web.multipart.support.StandardServletMultipartResolver',
    [
      {
        name: 'resolveMultipart',
        returnType: 'MultipartHttpServletRequest',
        parameters: ['HttpServletRequest'],
      },
    ],
  ],
  [
    'localeResolver',
    'AcceptHeaderLocaleResolver',
    'org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver',
    [{ name: 'resolveLocale', returnType: 'Locale', parameters: ['HttpServletRequest'] }],
  ],
  [
    'securityFilterChain',
    'SecurityFilterChain',
    'org.springframework.security.web.SecurityFilterChain',
    [{ name: 'matches', returnType: 'boolean', parameters: ['HttpServletRequest'] }],
  ],
  [
    'authenticationManager',
    'ProviderManager',
    'org.springframework.security.authentication.ProviderManager',
    [{ name: 'authenticate', returnType: 'Authentication', parameters: ['Authentication'] }],
  ],
  [
    'passwordEncoder',
    'BCryptPasswordEncoder',
    'org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder',
    [
      { name: 'encode', returnType: 'String', parameters: ['CharSequence'] },
      { name: 'matches', returnType: 'boolean', parameters: ['CharSequence', 'String'] },
    ],
  ],
  [
    'corsConfigurationSource',
    'UrlBasedCorsConfigurationSource',
    'org.springframework.web.cors.UrlBasedCorsConfigurationSource',
    [
      {
        name: 'getCorsConfiguration',
        returnType: 'CorsConfiguration',
        parameters: ['HttpServletRequest'],
      },
    ],
  ],
  [
    'mvcConversionService',
    'DefaultFormattingConversionService',
    'org.springframework.format.support.DefaultFormattingConversionService',
    [{ name: 'convert', returnType: 'T', parameters: ['Object', 'Class<T>'] }],
  ],
  [
    'jackson2ObjectMapperBuilder',
    'Jackson2ObjectMapperBuilder',
    'org.springframework.http.converter.json.Jackson2ObjectMapperBuilder',
    [{ name: 'build', returnType: 'ObjectMapper', parameters: [] }],
  ],
  [
    'connectionFactory',
    'CachingConnectionFactory',
    'org.springframework.jms.connection.CachingConnectionFactory',
    [{ name: 'createConnection', returnType: 'Connection', parameters: [] }],
  ],
  [
    'jmsTemplate',
    'JmsTemplate',
    'org.springframework.jms.core.JmsTemplate',
    [{ name: 'send', returnType: 'void', parameters: ['String', 'MessageCreator'] }],
  ],
  [
    'javaMailSender',
    'JavaMailSenderImpl',
    'org.springframework.mail.javamail.JavaMailSenderImpl',
    [{ name: 'send', returnType: 'void', parameters: ['SimpleMailMessage'] }],
  ],
  [
    'flywayInitializer',
    'FlywayMigrationInitializer',
    'org.springframework.boot.autoconfigure.flyway.FlywayMigrationInitializer',
    [{ name: 'afterPropertiesSet', returnType: 'void', parameters: [] }],
  ],
  [
    'liquibase',
    'SpringLiquibase',
    'liquibase.integration.spring.SpringLiquibase',
    [{ name: 'afterPropertiesSet', returnType: 'void', parameters: [] }],
  ],
  [
    'validatorFactoryBean',
    'LocalValidatorFactoryBean',
    'org.springframework.validation.beanvalidation.LocalValidatorFactoryBean',
    [{ name: 'validate', returnType: 'Set<ConstraintViolation<T>>', parameters: ['T'] }],
  ],
  [
    'methodValidationPostProcessor',
    'MethodValidationPostProcessor',
    'org.springframework.validation.beanvalidation.MethodValidationPostProcessor',
    [{ name: 'setValidator', returnType: 'void', parameters: ['Validator'] }],
  ],
  [
    'healthEndpoint',
    'HealthEndpoint',
    'org.springframework.boot.actuate.health.HealthEndpoint',
    [{ name: 'health', returnType: 'HealthComponent', parameters: [] }],
  ],
  [
    'metricsEndpoint',
    'MetricsEndpoint',
    'org.springframework.boot.actuate.metrics.MetricsEndpoint',
    [{ name: 'listNames', returnType: 'ListNamesResponse', parameters: [] }],
  ],
  [
    'meterRegistry',
    'PrometheusMeterRegistry',
    'io.micrometer.prometheus.PrometheusMeterRegistry',
    [
      { name: 'counter', returnType: 'Counter', parameters: ['String', 'String[]'] },
      { name: 'timer', returnType: 'Timer', parameters: ['String'] },
    ],
  ],
  [
    'circuitBreakerRegistry',
    'CircuitBreakerRegistry',
    'io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry',
    [{ name: 'circuitBreaker', returnType: 'CircuitBreaker', parameters: ['String'] }],
  ],
  [
    'retryRegistry',
    'RetryRegistry',
    'io.github.resilience4j.retry.RetryRegistry',
    [{ name: 'retry', returnType: 'Retry', parameters: ['String'] }],
  ],
  [
    'springApplicationAdminRegistrar',
    'SpringApplicationAdminMXBeanRegistrar',
    'org.springframework.boot.admin.SpringApplicationAdminMXBeanRegistrar',
    [{ name: 'isReady', returnType: 'boolean', parameters: [] }],
  ],
  [
    'requestContextFilter',
    'RequestContextFilter',
    'org.springframework.web.filter.RequestContextFilter',
    [
      {
        name: 'doFilter',
        returnType: 'void',
        parameters: ['ServletRequest', 'ServletResponse', 'FilterChain'],
      },
    ],
  ],
  [
    'characterEncodingFilter',
    'CharacterEncodingFilter',
    'org.springframework.web.filter.CharacterEncodingFilter',
    [
      {
        name: 'doFilterInternal',
        returnType: 'void',
        parameters: ['HttpServletRequest', 'HttpServletResponse', 'FilterChain'],
      },
    ],
  ],
  [
    'sessionRegistry',
    'SessionRegistryImpl',
    'org.springframework.security.core.session.SessionRegistryImpl',
    [{ name: 'getAllPrincipals', returnType: 'List<Object>', parameters: [] }],
  ],
]

const buildGeneratedBean = (domainWord, archetype, usedNames) => {
  const entity = capitalize(domainWord)
  const beanName = lowerFirst(`${domainWord}${archetype.suffix}`)
  if (usedNames.has(beanName)) return null
  usedNames.add(beanName)

  const factories = archetype.methods(entity)
  const methodCount = beanRandomInt(1, Math.min(4, factories.length))
  const pool = [...factories]
  const methods = []
  const usedMethodNames = new Set()

  for (let i = 0; i < methodCount && pool.length; i += 1) {
    const index = beanRandomInt(0, pool.length - 1)
    const [factory] = pool.splice(index, 1)
    const method = factory()
    if (usedMethodNames.has(method.name)) continue
    usedMethodNames.add(method.name)
    methods.push(method)
  }

  return {
    name: beanName,
    className: `${entity}${archetype.suffix}`,
    packageName: `ru.sber.tcpf.${archetype.pkg}.${entity}${archetype.suffix}`,
    methods,
  }
}

// Deterministically generates ~targetCount beans in total, reusing the given
// bean names as already taken so nothing collides with the curated list.
const generateBeans = (targetCount, reservedNames) => {
  const usedNames = new Set(reservedNames)
  const generated = []

  FRAMEWORK_BEANS.forEach(([name, className, packageName, methods]) => {
    if (usedNames.has(name)) return
    usedNames.add(name)
    generated.push({ name, className, packageName, methods })
  })

  const remaining = targetCount - reservedNames.length - generated.length
  let guard = 0

  while (generated.length < remaining + FRAMEWORK_BEANS.length && guard < remaining * 20) {
    guard += 1
    const domainWord = beanPick(BEAN_DOMAIN_WORDS)
    const archetype = beanPick(BEAN_ARCHETYPES)
    const bean = buildGeneratedBean(domainWord, archetype, usedNames)
    if (bean) generated.push(bean)
  }

  return generated
}

export const beans = [
  ...CURATED_BEANS,
  ...generateBeans(
    500,
    CURATED_BEANS.map(({ name }) => name),
  ),
]
